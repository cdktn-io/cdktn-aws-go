import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfAutomationRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#description TfAutomationRule#description}
    */
    readonly description: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#is_terminal TfAutomationRule#is_terminal}
    */
    readonly isTerminal?: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#region TfAutomationRule#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#rule_name TfAutomationRule#rule_name}
    */
    readonly ruleName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#rule_order TfAutomationRule#rule_order}
    */
    readonly ruleOrder: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#rule_status TfAutomationRule#rule_status}
    */
    readonly ruleStatus?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#tags TfAutomationRule#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * actions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#actions TfAutomationRule#actions}
    */
    readonly actions?: TfAutomationRule.ActionsProperty[] | cdktn.IResolvable;
    /**
    * criteria block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#criteria TfAutomationRule#criteria}
    */
    readonly criteria?: TfAutomationRule.CriteriaProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule aws_securityhub_automation_rule}
*/
export declare class TfAutomationRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_securityhub_automation_rule";
    /**
    * Generates CDKTN code for importing a TfAutomationRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfAutomationRule to import
    * @param importFromId The id of the existing TfAutomationRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfAutomationRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule aws_securityhub_automation_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfAutomationRuleConfig
    */
    constructor(scope: Construct, id: string, config: TfAutomationRuleConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    get id(): string;
    private _isTerminal?;
    get isTerminal(): boolean | cdktn.IResolvable;
    set isTerminal(value: boolean | cdktn.IResolvable);
    resetIsTerminal(): void;
    get isTerminalInput(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _ruleName?;
    get ruleName(): string;
    set ruleName(value: string);
    get ruleNameInput(): string | undefined;
    private _ruleOrder?;
    get ruleOrder(): number;
    set ruleOrder(value: number);
    get ruleOrderInput(): number | undefined;
    private _ruleStatus?;
    get ruleStatus(): string;
    set ruleStatus(value: string);
    resetRuleStatus(): void;
    get ruleStatusInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _actions;
    get actions(): TfAutomationRule.ActionsPropertyList;
    putActions(value: TfAutomationRule.ActionsProperty[] | cdktn.IResolvable): void;
    resetActions(): void;
    get actionsInput(): cdktn.IResolvable | TfAutomationRule.ActionsProperty[] | undefined;
    private _criteria;
    get criteria(): TfAutomationRule.CriteriaPropertyList;
    putCriteria(value: TfAutomationRule.CriteriaProperty[] | cdktn.IResolvable): void;
    resetCriteria(): void;
    get criteriaInput(): cdktn.IResolvable | TfAutomationRule.CriteriaProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfAutomationRuleNotePropertyToTerraform(struct?: TfAutomationRule.NoteProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleNotePropertyToHclTerraform(struct?: TfAutomationRule.NoteProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleRelatedFindingsPropertyToTerraform(struct?: TfAutomationRule.RelatedFindingsProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleRelatedFindingsPropertyToHclTerraform(struct?: TfAutomationRule.RelatedFindingsProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleSeverityPropertyToTerraform(struct?: TfAutomationRule.SeverityProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleSeverityPropertyToHclTerraform(struct?: TfAutomationRule.SeverityProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleWorkflowPropertyToTerraform(struct?: TfAutomationRule.WorkflowProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleWorkflowPropertyToHclTerraform(struct?: TfAutomationRule.WorkflowProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleFindingFieldsUpdatePropertyToTerraform(struct?: TfAutomationRule.FindingFieldsUpdateProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleFindingFieldsUpdatePropertyToHclTerraform(struct?: TfAutomationRule.FindingFieldsUpdateProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleActionsPropertyToTerraform(struct?: TfAutomationRule.ActionsProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleActionsPropertyToHclTerraform(struct?: TfAutomationRule.ActionsProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleAwsAccountIdPropertyToTerraform(struct?: TfAutomationRule.AwsAccountIdProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleAwsAccountIdPropertyToHclTerraform(struct?: TfAutomationRule.AwsAccountIdProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleAwsAccountNamePropertyToTerraform(struct?: TfAutomationRule.AwsAccountNameProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleAwsAccountNamePropertyToHclTerraform(struct?: TfAutomationRule.AwsAccountNameProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleCompanyNamePropertyToTerraform(struct?: TfAutomationRule.CompanyNameProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleCompanyNamePropertyToHclTerraform(struct?: TfAutomationRule.CompanyNameProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleComplianceAssociatedStandardsIdPropertyToTerraform(struct?: TfAutomationRule.ComplianceAssociatedStandardsIdProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleComplianceAssociatedStandardsIdPropertyToHclTerraform(struct?: TfAutomationRule.ComplianceAssociatedStandardsIdProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleComplianceSecurityControlIdPropertyToTerraform(struct?: TfAutomationRule.ComplianceSecurityControlIdProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleComplianceSecurityControlIdPropertyToHclTerraform(struct?: TfAutomationRule.ComplianceSecurityControlIdProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleComplianceStatusPropertyToTerraform(struct?: TfAutomationRule.ComplianceStatusProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleComplianceStatusPropertyToHclTerraform(struct?: TfAutomationRule.ComplianceStatusProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleConfidencePropertyToTerraform(struct?: TfAutomationRule.ConfidenceProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleConfidencePropertyToHclTerraform(struct?: TfAutomationRule.ConfidenceProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleCriteriaCreatedAtDateRangePropertyToTerraform(struct?: TfAutomationRule.CriteriaCreatedAtDateRangeProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleCriteriaCreatedAtDateRangePropertyToHclTerraform(struct?: TfAutomationRule.CriteriaCreatedAtDateRangeProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleCreatedAtPropertyToTerraform(struct?: TfAutomationRule.CreatedAtProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleCreatedAtPropertyToHclTerraform(struct?: TfAutomationRule.CreatedAtProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleCriticalityPropertyToTerraform(struct?: TfAutomationRule.CriticalityProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleCriticalityPropertyToHclTerraform(struct?: TfAutomationRule.CriticalityProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleDescriptionPropertyToTerraform(struct?: TfAutomationRule.DescriptionProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleDescriptionPropertyToHclTerraform(struct?: TfAutomationRule.DescriptionProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleCriteriaFirstObservedAtDateRangePropertyToTerraform(struct?: TfAutomationRule.CriteriaFirstObservedAtDateRangeProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleCriteriaFirstObservedAtDateRangePropertyToHclTerraform(struct?: TfAutomationRule.CriteriaFirstObservedAtDateRangeProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleFirstObservedAtPropertyToTerraform(struct?: TfAutomationRule.FirstObservedAtProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleFirstObservedAtPropertyToHclTerraform(struct?: TfAutomationRule.FirstObservedAtProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleGeneratorIdPropertyToTerraform(struct?: TfAutomationRule.GeneratorIdProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleGeneratorIdPropertyToHclTerraform(struct?: TfAutomationRule.GeneratorIdProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleIdPropertyToTerraform(struct?: TfAutomationRule.IdProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleIdPropertyToHclTerraform(struct?: TfAutomationRule.IdProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleCriteriaLastObservedAtDateRangePropertyToTerraform(struct?: TfAutomationRule.CriteriaLastObservedAtDateRangeProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleCriteriaLastObservedAtDateRangePropertyToHclTerraform(struct?: TfAutomationRule.CriteriaLastObservedAtDateRangeProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleLastObservedAtPropertyToTerraform(struct?: TfAutomationRule.LastObservedAtProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleLastObservedAtPropertyToHclTerraform(struct?: TfAutomationRule.LastObservedAtProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleNoteTextPropertyToTerraform(struct?: TfAutomationRule.NoteTextProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleNoteTextPropertyToHclTerraform(struct?: TfAutomationRule.NoteTextProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleCriteriaNoteUpdatedAtDateRangePropertyToTerraform(struct?: TfAutomationRule.CriteriaNoteUpdatedAtDateRangeProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleCriteriaNoteUpdatedAtDateRangePropertyToHclTerraform(struct?: TfAutomationRule.CriteriaNoteUpdatedAtDateRangeProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleNoteUpdatedAtPropertyToTerraform(struct?: TfAutomationRule.NoteUpdatedAtProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleNoteUpdatedAtPropertyToHclTerraform(struct?: TfAutomationRule.NoteUpdatedAtProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleNoteUpdatedByPropertyToTerraform(struct?: TfAutomationRule.NoteUpdatedByProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleNoteUpdatedByPropertyToHclTerraform(struct?: TfAutomationRule.NoteUpdatedByProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleProductArnPropertyToTerraform(struct?: TfAutomationRule.ProductArnProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleProductArnPropertyToHclTerraform(struct?: TfAutomationRule.ProductArnProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleProductNamePropertyToTerraform(struct?: TfAutomationRule.ProductNameProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleProductNamePropertyToHclTerraform(struct?: TfAutomationRule.ProductNameProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleRecordStatePropertyToTerraform(struct?: TfAutomationRule.RecordStateProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleRecordStatePropertyToHclTerraform(struct?: TfAutomationRule.RecordStateProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleRelatedFindingsIdPropertyToTerraform(struct?: TfAutomationRule.RelatedFindingsIdProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleRelatedFindingsIdPropertyToHclTerraform(struct?: TfAutomationRule.RelatedFindingsIdProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleRelatedFindingsProductArnPropertyToTerraform(struct?: TfAutomationRule.RelatedFindingsProductArnProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleRelatedFindingsProductArnPropertyToHclTerraform(struct?: TfAutomationRule.RelatedFindingsProductArnProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleResourceApplicationArnPropertyToTerraform(struct?: TfAutomationRule.ResourceApplicationArnProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleResourceApplicationArnPropertyToHclTerraform(struct?: TfAutomationRule.ResourceApplicationArnProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleResourceApplicationNamePropertyToTerraform(struct?: TfAutomationRule.ResourceApplicationNameProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleResourceApplicationNamePropertyToHclTerraform(struct?: TfAutomationRule.ResourceApplicationNameProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleResourceDetailsOtherPropertyToTerraform(struct?: TfAutomationRule.ResourceDetailsOtherProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleResourceDetailsOtherPropertyToHclTerraform(struct?: TfAutomationRule.ResourceDetailsOtherProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleResourceIdPropertyToTerraform(struct?: TfAutomationRule.ResourceIdProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleResourceIdPropertyToHclTerraform(struct?: TfAutomationRule.ResourceIdProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleResourcePartitionPropertyToTerraform(struct?: TfAutomationRule.ResourcePartitionProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleResourcePartitionPropertyToHclTerraform(struct?: TfAutomationRule.ResourcePartitionProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleResourceRegionPropertyToTerraform(struct?: TfAutomationRule.ResourceRegionProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleResourceRegionPropertyToHclTerraform(struct?: TfAutomationRule.ResourceRegionProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleResourceTagsPropertyToTerraform(struct?: TfAutomationRule.ResourceTagsProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleResourceTagsPropertyToHclTerraform(struct?: TfAutomationRule.ResourceTagsProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleResourceTypePropertyToTerraform(struct?: TfAutomationRule.ResourceTypeProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleResourceTypePropertyToHclTerraform(struct?: TfAutomationRule.ResourceTypeProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleSeverityLabelPropertyToTerraform(struct?: TfAutomationRule.SeverityLabelProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleSeverityLabelPropertyToHclTerraform(struct?: TfAutomationRule.SeverityLabelProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleSourceUrlPropertyToTerraform(struct?: TfAutomationRule.SourceUrlProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleSourceUrlPropertyToHclTerraform(struct?: TfAutomationRule.SourceUrlProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleTitlePropertyToTerraform(struct?: TfAutomationRule.TitleProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleTitlePropertyToHclTerraform(struct?: TfAutomationRule.TitleProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleTypePropertyToTerraform(struct?: TfAutomationRule.TypeProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleTypePropertyToHclTerraform(struct?: TfAutomationRule.TypeProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleCriteriaUpdatedAtDateRangePropertyToTerraform(struct?: TfAutomationRule.CriteriaUpdatedAtDateRangeProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleCriteriaUpdatedAtDateRangePropertyToHclTerraform(struct?: TfAutomationRule.CriteriaUpdatedAtDateRangeProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleUpdatedAtPropertyToTerraform(struct?: TfAutomationRule.UpdatedAtProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleUpdatedAtPropertyToHclTerraform(struct?: TfAutomationRule.UpdatedAtProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleUserDefinedFieldsPropertyToTerraform(struct?: TfAutomationRule.UserDefinedFieldsProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleUserDefinedFieldsPropertyToHclTerraform(struct?: TfAutomationRule.UserDefinedFieldsProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleVerificationStatePropertyToTerraform(struct?: TfAutomationRule.VerificationStateProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleVerificationStatePropertyToHclTerraform(struct?: TfAutomationRule.VerificationStateProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleWorkflowStatusPropertyToTerraform(struct?: TfAutomationRule.WorkflowStatusProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleWorkflowStatusPropertyToHclTerraform(struct?: TfAutomationRule.WorkflowStatusProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleCriteriaPropertyToTerraform(struct?: TfAutomationRule.CriteriaProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleCriteriaPropertyToHclTerraform(struct?: TfAutomationRule.CriteriaProperty | cdktn.IResolvable): any;
export declare namespace TfAutomationRule {
    interface NoteProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#text TfAutomationRule#text}
        */
        readonly text: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#updated_by TfAutomationRule#updated_by}
        */
        readonly updatedBy: string;
    }
    class NotePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NoteProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NoteProperty | cdktn.IResolvable | undefined);
        private _text?;
        get text(): string;
        set text(value: string);
        get textInput(): string | undefined;
        private _updatedBy?;
        get updatedBy(): string;
        set updatedBy(value: string);
        get updatedByInput(): string | undefined;
    }
    class NotePropertyList extends cdktn.ComplexList {
        internalValue?: NoteProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NotePropertyOutputReference;
    }
    interface RelatedFindingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#id TfAutomationRule#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#product_arn TfAutomationRule#product_arn}
        */
        readonly productArn: string;
    }
    class RelatedFindingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RelatedFindingsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RelatedFindingsProperty | cdktn.IResolvable | undefined);
        private _id?;
        get id(): string;
        set id(value: string);
        get idInput(): string | undefined;
        private _productArn?;
        get productArn(): string;
        set productArn(value: string);
        get productArnInput(): string | undefined;
    }
    class RelatedFindingsPropertyList extends cdktn.ComplexList {
        internalValue?: RelatedFindingsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RelatedFindingsPropertyOutputReference;
    }
    interface SeverityProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#label TfAutomationRule#label}
        */
        readonly label?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#product TfAutomationRule#product}
        */
        readonly product?: number;
    }
    class SeverityPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SeverityProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SeverityProperty | cdktn.IResolvable | undefined);
        private _label?;
        get label(): string;
        set label(value: string);
        resetLabel(): void;
        get labelInput(): string | undefined;
        private _product?;
        get product(): number;
        set product(value: number);
        resetProduct(): void;
        get productInput(): number | undefined;
    }
    class SeverityPropertyList extends cdktn.ComplexList {
        internalValue?: SeverityProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SeverityPropertyOutputReference;
    }
    interface WorkflowProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#status TfAutomationRule#status}
        */
        readonly status?: string;
    }
    class WorkflowPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowProperty | cdktn.IResolvable | undefined);
        private _status?;
        get status(): string;
        set status(value: string);
        resetStatus(): void;
        get statusInput(): string | undefined;
    }
    class WorkflowPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowPropertyOutputReference;
    }
    interface FindingFieldsUpdateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#confidence TfAutomationRule#confidence}
        */
        readonly confidence?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#criticality TfAutomationRule#criticality}
        */
        readonly criticality?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#types TfAutomationRule#types}
        */
        readonly types?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#user_defined_fields TfAutomationRule#user_defined_fields}
        */
        readonly userDefinedFields?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#verification_state TfAutomationRule#verification_state}
        */
        readonly verificationState?: string;
        /**
        * note block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#note TfAutomationRule#note}
        */
        readonly note?: NoteProperty[] | cdktn.IResolvable;
        /**
        * related_findings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#related_findings TfAutomationRule#related_findings}
        */
        readonly relatedFindings?: RelatedFindingsProperty[] | cdktn.IResolvable;
        /**
        * severity block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#severity TfAutomationRule#severity}
        */
        readonly severity?: SeverityProperty[] | cdktn.IResolvable;
        /**
        * workflow block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#workflow TfAutomationRule#workflow}
        */
        readonly workflow?: WorkflowProperty[] | cdktn.IResolvable;
    }
    class FindingFieldsUpdatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FindingFieldsUpdateProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FindingFieldsUpdateProperty | cdktn.IResolvable | undefined);
        private _confidence?;
        get confidence(): number;
        set confidence(value: number);
        resetConfidence(): void;
        get confidenceInput(): number | undefined;
        private _criticality?;
        get criticality(): number;
        set criticality(value: number);
        resetCriticality(): void;
        get criticalityInput(): number | undefined;
        private _types?;
        get types(): string[];
        set types(value: string[]);
        resetTypes(): void;
        get typesInput(): string[] | undefined;
        private _userDefinedFields?;
        get userDefinedFields(): {
            [key: string]: string;
        };
        set userDefinedFields(value: {
            [key: string]: string;
        });
        resetUserDefinedFields(): void;
        get userDefinedFieldsInput(): {
            [key: string]: string;
        } | undefined;
        private _verificationState?;
        get verificationState(): string;
        set verificationState(value: string);
        resetVerificationState(): void;
        get verificationStateInput(): string | undefined;
        private _note;
        get note(): NotePropertyList;
        putNote(value: NoteProperty[] | cdktn.IResolvable): void;
        resetNote(): void;
        get noteInput(): cdktn.IResolvable | NoteProperty[] | undefined;
        private _relatedFindings;
        get relatedFindings(): RelatedFindingsPropertyList;
        putRelatedFindings(value: RelatedFindingsProperty[] | cdktn.IResolvable): void;
        resetRelatedFindings(): void;
        get relatedFindingsInput(): cdktn.IResolvable | RelatedFindingsProperty[] | undefined;
        private _severity;
        get severity(): SeverityPropertyList;
        putSeverity(value: SeverityProperty[] | cdktn.IResolvable): void;
        resetSeverity(): void;
        get severityInput(): cdktn.IResolvable | SeverityProperty[] | undefined;
        private _workflow;
        get workflow(): WorkflowPropertyList;
        putWorkflow(value: WorkflowProperty[] | cdktn.IResolvable): void;
        resetWorkflow(): void;
        get workflowInput(): cdktn.IResolvable | WorkflowProperty[] | undefined;
    }
    class FindingFieldsUpdatePropertyList extends cdktn.ComplexList {
        internalValue?: FindingFieldsUpdateProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FindingFieldsUpdatePropertyOutputReference;
    }
    interface ActionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#type TfAutomationRule#type}
        */
        readonly type?: string;
        /**
        * finding_fields_update block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#finding_fields_update TfAutomationRule#finding_fields_update}
        */
        readonly findingFieldsUpdate?: FindingFieldsUpdateProperty[] | cdktn.IResolvable;
    }
    class ActionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ActionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ActionsProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
        private _findingFieldsUpdate;
        get findingFieldsUpdate(): FindingFieldsUpdatePropertyList;
        putFindingFieldsUpdate(value: FindingFieldsUpdateProperty[] | cdktn.IResolvable): void;
        resetFindingFieldsUpdate(): void;
        get findingFieldsUpdateInput(): cdktn.IResolvable | FindingFieldsUpdateProperty[] | undefined;
    }
    class ActionsPropertyList extends cdktn.ComplexList {
        internalValue?: ActionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ActionsPropertyOutputReference;
    }
    interface AwsAccountIdProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#comparison TfAutomationRule#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#value TfAutomationRule#value}
        */
        readonly value: string;
    }
    class AwsAccountIdPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AwsAccountIdProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AwsAccountIdProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class AwsAccountIdPropertyList extends cdktn.ComplexList {
        internalValue?: AwsAccountIdProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AwsAccountIdPropertyOutputReference;
    }
    interface AwsAccountNameProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#comparison TfAutomationRule#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#value TfAutomationRule#value}
        */
        readonly value: string;
    }
    class AwsAccountNamePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AwsAccountNameProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AwsAccountNameProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class AwsAccountNamePropertyList extends cdktn.ComplexList {
        internalValue?: AwsAccountNameProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AwsAccountNamePropertyOutputReference;
    }
    interface CompanyNameProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#comparison TfAutomationRule#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#value TfAutomationRule#value}
        */
        readonly value: string;
    }
    class CompanyNamePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CompanyNameProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CompanyNameProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class CompanyNamePropertyList extends cdktn.ComplexList {
        internalValue?: CompanyNameProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CompanyNamePropertyOutputReference;
    }
    interface ComplianceAssociatedStandardsIdProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#comparison TfAutomationRule#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#value TfAutomationRule#value}
        */
        readonly value: string;
    }
    class ComplianceAssociatedStandardsIdPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ComplianceAssociatedStandardsIdProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ComplianceAssociatedStandardsIdProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ComplianceAssociatedStandardsIdPropertyList extends cdktn.ComplexList {
        internalValue?: ComplianceAssociatedStandardsIdProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ComplianceAssociatedStandardsIdPropertyOutputReference;
    }
    interface ComplianceSecurityControlIdProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#comparison TfAutomationRule#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#value TfAutomationRule#value}
        */
        readonly value: string;
    }
    class ComplianceSecurityControlIdPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ComplianceSecurityControlIdProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ComplianceSecurityControlIdProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ComplianceSecurityControlIdPropertyList extends cdktn.ComplexList {
        internalValue?: ComplianceSecurityControlIdProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ComplianceSecurityControlIdPropertyOutputReference;
    }
    interface ComplianceStatusProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#comparison TfAutomationRule#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#value TfAutomationRule#value}
        */
        readonly value: string;
    }
    class ComplianceStatusPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ComplianceStatusProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ComplianceStatusProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ComplianceStatusPropertyList extends cdktn.ComplexList {
        internalValue?: ComplianceStatusProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ComplianceStatusPropertyOutputReference;
    }
    interface ConfidenceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#eq TfAutomationRule#eq}
        */
        readonly eq?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#gt TfAutomationRule#gt}
        */
        readonly gt?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#gte TfAutomationRule#gte}
        */
        readonly gte?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#lt TfAutomationRule#lt}
        */
        readonly lt?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#lte TfAutomationRule#lte}
        */
        readonly lte?: number;
    }
    class ConfidencePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConfidenceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConfidenceProperty | cdktn.IResolvable | undefined);
        private _eq?;
        get eq(): number;
        set eq(value: number);
        resetEq(): void;
        get eqInput(): number | undefined;
        private _gt?;
        get gt(): number;
        set gt(value: number);
        resetGt(): void;
        get gtInput(): number | undefined;
        private _gte?;
        get gte(): number;
        set gte(value: number);
        resetGte(): void;
        get gteInput(): number | undefined;
        private _lt?;
        get lt(): number;
        set lt(value: number);
        resetLt(): void;
        get ltInput(): number | undefined;
        private _lte?;
        get lte(): number;
        set lte(value: number);
        resetLte(): void;
        get lteInput(): number | undefined;
    }
    class ConfidencePropertyList extends cdktn.ComplexList {
        internalValue?: ConfidenceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConfidencePropertyOutputReference;
    }
    interface CriteriaCreatedAtDateRangeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#unit TfAutomationRule#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#value TfAutomationRule#value}
        */
        readonly value: number;
    }
    class CriteriaCreatedAtDateRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CriteriaCreatedAtDateRangeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CriteriaCreatedAtDateRangeProperty | cdktn.IResolvable | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    class CriteriaCreatedAtDateRangePropertyList extends cdktn.ComplexList {
        internalValue?: CriteriaCreatedAtDateRangeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CriteriaCreatedAtDateRangePropertyOutputReference;
    }
    interface CreatedAtProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#end TfAutomationRule#end}
        */
        readonly end?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#start TfAutomationRule#start}
        */
        readonly start?: string;
        /**
        * date_range block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#date_range TfAutomationRule#date_range}
        */
        readonly dateRange?: CriteriaCreatedAtDateRangeProperty[] | cdktn.IResolvable;
    }
    class CreatedAtPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CreatedAtProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CreatedAtProperty | cdktn.IResolvable | undefined);
        private _end?;
        get end(): string;
        set end(value: string);
        resetEnd(): void;
        get endInput(): string | undefined;
        private _start?;
        get start(): string;
        set start(value: string);
        resetStart(): void;
        get startInput(): string | undefined;
        private _dateRange;
        get dateRange(): CriteriaCreatedAtDateRangePropertyList;
        putDateRange(value: CriteriaCreatedAtDateRangeProperty[] | cdktn.IResolvable): void;
        resetDateRange(): void;
        get dateRangeInput(): cdktn.IResolvable | CriteriaCreatedAtDateRangeProperty[] | undefined;
    }
    class CreatedAtPropertyList extends cdktn.ComplexList {
        internalValue?: CreatedAtProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CreatedAtPropertyOutputReference;
    }
    interface CriticalityProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#eq TfAutomationRule#eq}
        */
        readonly eq?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#gt TfAutomationRule#gt}
        */
        readonly gt?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#gte TfAutomationRule#gte}
        */
        readonly gte?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#lt TfAutomationRule#lt}
        */
        readonly lt?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#lte TfAutomationRule#lte}
        */
        readonly lte?: number;
    }
    class CriticalityPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CriticalityProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CriticalityProperty | cdktn.IResolvable | undefined);
        private _eq?;
        get eq(): number;
        set eq(value: number);
        resetEq(): void;
        get eqInput(): number | undefined;
        private _gt?;
        get gt(): number;
        set gt(value: number);
        resetGt(): void;
        get gtInput(): number | undefined;
        private _gte?;
        get gte(): number;
        set gte(value: number);
        resetGte(): void;
        get gteInput(): number | undefined;
        private _lt?;
        get lt(): number;
        set lt(value: number);
        resetLt(): void;
        get ltInput(): number | undefined;
        private _lte?;
        get lte(): number;
        set lte(value: number);
        resetLte(): void;
        get lteInput(): number | undefined;
    }
    class CriticalityPropertyList extends cdktn.ComplexList {
        internalValue?: CriticalityProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CriticalityPropertyOutputReference;
    }
    interface DescriptionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#comparison TfAutomationRule#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#value TfAutomationRule#value}
        */
        readonly value: string;
    }
    class DescriptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DescriptionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DescriptionProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class DescriptionPropertyList extends cdktn.ComplexList {
        internalValue?: DescriptionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DescriptionPropertyOutputReference;
    }
    interface CriteriaFirstObservedAtDateRangeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#unit TfAutomationRule#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#value TfAutomationRule#value}
        */
        readonly value: number;
    }
    class CriteriaFirstObservedAtDateRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CriteriaFirstObservedAtDateRangeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CriteriaFirstObservedAtDateRangeProperty | cdktn.IResolvable | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    class CriteriaFirstObservedAtDateRangePropertyList extends cdktn.ComplexList {
        internalValue?: CriteriaFirstObservedAtDateRangeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CriteriaFirstObservedAtDateRangePropertyOutputReference;
    }
    interface FirstObservedAtProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#end TfAutomationRule#end}
        */
        readonly end?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#start TfAutomationRule#start}
        */
        readonly start?: string;
        /**
        * date_range block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#date_range TfAutomationRule#date_range}
        */
        readonly dateRange?: CriteriaFirstObservedAtDateRangeProperty[] | cdktn.IResolvable;
    }
    class FirstObservedAtPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FirstObservedAtProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FirstObservedAtProperty | cdktn.IResolvable | undefined);
        private _end?;
        get end(): string;
        set end(value: string);
        resetEnd(): void;
        get endInput(): string | undefined;
        private _start?;
        get start(): string;
        set start(value: string);
        resetStart(): void;
        get startInput(): string | undefined;
        private _dateRange;
        get dateRange(): CriteriaFirstObservedAtDateRangePropertyList;
        putDateRange(value: CriteriaFirstObservedAtDateRangeProperty[] | cdktn.IResolvable): void;
        resetDateRange(): void;
        get dateRangeInput(): cdktn.IResolvable | CriteriaFirstObservedAtDateRangeProperty[] | undefined;
    }
    class FirstObservedAtPropertyList extends cdktn.ComplexList {
        internalValue?: FirstObservedAtProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FirstObservedAtPropertyOutputReference;
    }
    interface GeneratorIdProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#comparison TfAutomationRule#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#value TfAutomationRule#value}
        */
        readonly value: string;
    }
    class GeneratorIdPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GeneratorIdProperty | cdktn.IResolvable | undefined;
        set internalValue(value: GeneratorIdProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class GeneratorIdPropertyList extends cdktn.ComplexList {
        internalValue?: GeneratorIdProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GeneratorIdPropertyOutputReference;
    }
    interface IdProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#comparison TfAutomationRule#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#value TfAutomationRule#value}
        */
        readonly value: string;
    }
    class IdPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IdProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IdProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class IdPropertyList extends cdktn.ComplexList {
        internalValue?: IdProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IdPropertyOutputReference;
    }
    interface CriteriaLastObservedAtDateRangeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#unit TfAutomationRule#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#value TfAutomationRule#value}
        */
        readonly value: number;
    }
    class CriteriaLastObservedAtDateRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CriteriaLastObservedAtDateRangeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CriteriaLastObservedAtDateRangeProperty | cdktn.IResolvable | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    class CriteriaLastObservedAtDateRangePropertyList extends cdktn.ComplexList {
        internalValue?: CriteriaLastObservedAtDateRangeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CriteriaLastObservedAtDateRangePropertyOutputReference;
    }
    interface LastObservedAtProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#end TfAutomationRule#end}
        */
        readonly end?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#start TfAutomationRule#start}
        */
        readonly start?: string;
        /**
        * date_range block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#date_range TfAutomationRule#date_range}
        */
        readonly dateRange?: CriteriaLastObservedAtDateRangeProperty[] | cdktn.IResolvable;
    }
    class LastObservedAtPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LastObservedAtProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LastObservedAtProperty | cdktn.IResolvable | undefined);
        private _end?;
        get end(): string;
        set end(value: string);
        resetEnd(): void;
        get endInput(): string | undefined;
        private _start?;
        get start(): string;
        set start(value: string);
        resetStart(): void;
        get startInput(): string | undefined;
        private _dateRange;
        get dateRange(): CriteriaLastObservedAtDateRangePropertyList;
        putDateRange(value: CriteriaLastObservedAtDateRangeProperty[] | cdktn.IResolvable): void;
        resetDateRange(): void;
        get dateRangeInput(): cdktn.IResolvable | CriteriaLastObservedAtDateRangeProperty[] | undefined;
    }
    class LastObservedAtPropertyList extends cdktn.ComplexList {
        internalValue?: LastObservedAtProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LastObservedAtPropertyOutputReference;
    }
    interface NoteTextProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#comparison TfAutomationRule#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#value TfAutomationRule#value}
        */
        readonly value: string;
    }
    class NoteTextPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NoteTextProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NoteTextProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class NoteTextPropertyList extends cdktn.ComplexList {
        internalValue?: NoteTextProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NoteTextPropertyOutputReference;
    }
    interface CriteriaNoteUpdatedAtDateRangeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#unit TfAutomationRule#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#value TfAutomationRule#value}
        */
        readonly value: number;
    }
    class CriteriaNoteUpdatedAtDateRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CriteriaNoteUpdatedAtDateRangeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CriteriaNoteUpdatedAtDateRangeProperty | cdktn.IResolvable | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    class CriteriaNoteUpdatedAtDateRangePropertyList extends cdktn.ComplexList {
        internalValue?: CriteriaNoteUpdatedAtDateRangeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CriteriaNoteUpdatedAtDateRangePropertyOutputReference;
    }
    interface NoteUpdatedAtProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#end TfAutomationRule#end}
        */
        readonly end?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#start TfAutomationRule#start}
        */
        readonly start?: string;
        /**
        * date_range block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#date_range TfAutomationRule#date_range}
        */
        readonly dateRange?: CriteriaNoteUpdatedAtDateRangeProperty[] | cdktn.IResolvable;
    }
    class NoteUpdatedAtPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NoteUpdatedAtProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NoteUpdatedAtProperty | cdktn.IResolvable | undefined);
        private _end?;
        get end(): string;
        set end(value: string);
        resetEnd(): void;
        get endInput(): string | undefined;
        private _start?;
        get start(): string;
        set start(value: string);
        resetStart(): void;
        get startInput(): string | undefined;
        private _dateRange;
        get dateRange(): CriteriaNoteUpdatedAtDateRangePropertyList;
        putDateRange(value: CriteriaNoteUpdatedAtDateRangeProperty[] | cdktn.IResolvable): void;
        resetDateRange(): void;
        get dateRangeInput(): cdktn.IResolvable | CriteriaNoteUpdatedAtDateRangeProperty[] | undefined;
    }
    class NoteUpdatedAtPropertyList extends cdktn.ComplexList {
        internalValue?: NoteUpdatedAtProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NoteUpdatedAtPropertyOutputReference;
    }
    interface NoteUpdatedByProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#comparison TfAutomationRule#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#value TfAutomationRule#value}
        */
        readonly value: string;
    }
    class NoteUpdatedByPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NoteUpdatedByProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NoteUpdatedByProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class NoteUpdatedByPropertyList extends cdktn.ComplexList {
        internalValue?: NoteUpdatedByProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NoteUpdatedByPropertyOutputReference;
    }
    interface ProductArnProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#comparison TfAutomationRule#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#value TfAutomationRule#value}
        */
        readonly value: string;
    }
    class ProductArnPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ProductArnProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ProductArnProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ProductArnPropertyList extends cdktn.ComplexList {
        internalValue?: ProductArnProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ProductArnPropertyOutputReference;
    }
    interface ProductNameProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#comparison TfAutomationRule#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#value TfAutomationRule#value}
        */
        readonly value: string;
    }
    class ProductNamePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ProductNameProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ProductNameProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ProductNamePropertyList extends cdktn.ComplexList {
        internalValue?: ProductNameProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ProductNamePropertyOutputReference;
    }
    interface RecordStateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#comparison TfAutomationRule#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#value TfAutomationRule#value}
        */
        readonly value: string;
    }
    class RecordStatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RecordStateProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RecordStateProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class RecordStatePropertyList extends cdktn.ComplexList {
        internalValue?: RecordStateProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RecordStatePropertyOutputReference;
    }
    interface RelatedFindingsIdProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#comparison TfAutomationRule#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#value TfAutomationRule#value}
        */
        readonly value: string;
    }
    class RelatedFindingsIdPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RelatedFindingsIdProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RelatedFindingsIdProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class RelatedFindingsIdPropertyList extends cdktn.ComplexList {
        internalValue?: RelatedFindingsIdProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RelatedFindingsIdPropertyOutputReference;
    }
    interface RelatedFindingsProductArnProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#comparison TfAutomationRule#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#value TfAutomationRule#value}
        */
        readonly value: string;
    }
    class RelatedFindingsProductArnPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RelatedFindingsProductArnProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RelatedFindingsProductArnProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class RelatedFindingsProductArnPropertyList extends cdktn.ComplexList {
        internalValue?: RelatedFindingsProductArnProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RelatedFindingsProductArnPropertyOutputReference;
    }
    interface ResourceApplicationArnProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#comparison TfAutomationRule#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#value TfAutomationRule#value}
        */
        readonly value: string;
    }
    class ResourceApplicationArnPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceApplicationArnProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceApplicationArnProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ResourceApplicationArnPropertyList extends cdktn.ComplexList {
        internalValue?: ResourceApplicationArnProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceApplicationArnPropertyOutputReference;
    }
    interface ResourceApplicationNameProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#comparison TfAutomationRule#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#value TfAutomationRule#value}
        */
        readonly value: string;
    }
    class ResourceApplicationNamePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceApplicationNameProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceApplicationNameProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ResourceApplicationNamePropertyList extends cdktn.ComplexList {
        internalValue?: ResourceApplicationNameProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceApplicationNamePropertyOutputReference;
    }
    interface ResourceDetailsOtherProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#comparison TfAutomationRule#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#key TfAutomationRule#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#value TfAutomationRule#value}
        */
        readonly value: string;
    }
    class ResourceDetailsOtherPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceDetailsOtherProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceDetailsOtherProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ResourceDetailsOtherPropertyList extends cdktn.ComplexList {
        internalValue?: ResourceDetailsOtherProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceDetailsOtherPropertyOutputReference;
    }
    interface ResourceIdProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#comparison TfAutomationRule#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#value TfAutomationRule#value}
        */
        readonly value: string;
    }
    class ResourceIdPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceIdProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceIdProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ResourceIdPropertyList extends cdktn.ComplexList {
        internalValue?: ResourceIdProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceIdPropertyOutputReference;
    }
    interface ResourcePartitionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#comparison TfAutomationRule#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#value TfAutomationRule#value}
        */
        readonly value: string;
    }
    class ResourcePartitionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourcePartitionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourcePartitionProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ResourcePartitionPropertyList extends cdktn.ComplexList {
        internalValue?: ResourcePartitionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourcePartitionPropertyOutputReference;
    }
    interface ResourceRegionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#comparison TfAutomationRule#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#value TfAutomationRule#value}
        */
        readonly value: string;
    }
    class ResourceRegionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceRegionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceRegionProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ResourceRegionPropertyList extends cdktn.ComplexList {
        internalValue?: ResourceRegionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceRegionPropertyOutputReference;
    }
    interface ResourceTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#comparison TfAutomationRule#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#key TfAutomationRule#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#value TfAutomationRule#value}
        */
        readonly value: string;
    }
    class ResourceTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceTagsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceTagsProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ResourceTagsPropertyList extends cdktn.ComplexList {
        internalValue?: ResourceTagsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceTagsPropertyOutputReference;
    }
    interface ResourceTypeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#comparison TfAutomationRule#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#value TfAutomationRule#value}
        */
        readonly value: string;
    }
    class ResourceTypePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceTypeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceTypeProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ResourceTypePropertyList extends cdktn.ComplexList {
        internalValue?: ResourceTypeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceTypePropertyOutputReference;
    }
    interface SeverityLabelProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#comparison TfAutomationRule#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#value TfAutomationRule#value}
        */
        readonly value: string;
    }
    class SeverityLabelPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SeverityLabelProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SeverityLabelProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class SeverityLabelPropertyList extends cdktn.ComplexList {
        internalValue?: SeverityLabelProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SeverityLabelPropertyOutputReference;
    }
    interface SourceUrlProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#comparison TfAutomationRule#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#value TfAutomationRule#value}
        */
        readonly value: string;
    }
    class SourceUrlPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SourceUrlProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SourceUrlProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class SourceUrlPropertyList extends cdktn.ComplexList {
        internalValue?: SourceUrlProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SourceUrlPropertyOutputReference;
    }
    interface TitleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#comparison TfAutomationRule#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#value TfAutomationRule#value}
        */
        readonly value: string;
    }
    class TitlePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TitleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TitleProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class TitlePropertyList extends cdktn.ComplexList {
        internalValue?: TitleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TitlePropertyOutputReference;
    }
    interface TypeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#comparison TfAutomationRule#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#value TfAutomationRule#value}
        */
        readonly value: string;
    }
    class TypePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TypeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TypeProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class TypePropertyList extends cdktn.ComplexList {
        internalValue?: TypeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TypePropertyOutputReference;
    }
    interface CriteriaUpdatedAtDateRangeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#unit TfAutomationRule#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#value TfAutomationRule#value}
        */
        readonly value: number;
    }
    class CriteriaUpdatedAtDateRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CriteriaUpdatedAtDateRangeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CriteriaUpdatedAtDateRangeProperty | cdktn.IResolvable | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    class CriteriaUpdatedAtDateRangePropertyList extends cdktn.ComplexList {
        internalValue?: CriteriaUpdatedAtDateRangeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CriteriaUpdatedAtDateRangePropertyOutputReference;
    }
    interface UpdatedAtProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#end TfAutomationRule#end}
        */
        readonly end?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#start TfAutomationRule#start}
        */
        readonly start?: string;
        /**
        * date_range block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#date_range TfAutomationRule#date_range}
        */
        readonly dateRange?: CriteriaUpdatedAtDateRangeProperty[] | cdktn.IResolvable;
    }
    class UpdatedAtPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): UpdatedAtProperty | cdktn.IResolvable | undefined;
        set internalValue(value: UpdatedAtProperty | cdktn.IResolvable | undefined);
        private _end?;
        get end(): string;
        set end(value: string);
        resetEnd(): void;
        get endInput(): string | undefined;
        private _start?;
        get start(): string;
        set start(value: string);
        resetStart(): void;
        get startInput(): string | undefined;
        private _dateRange;
        get dateRange(): CriteriaUpdatedAtDateRangePropertyList;
        putDateRange(value: CriteriaUpdatedAtDateRangeProperty[] | cdktn.IResolvable): void;
        resetDateRange(): void;
        get dateRangeInput(): cdktn.IResolvable | CriteriaUpdatedAtDateRangeProperty[] | undefined;
    }
    class UpdatedAtPropertyList extends cdktn.ComplexList {
        internalValue?: UpdatedAtProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): UpdatedAtPropertyOutputReference;
    }
    interface UserDefinedFieldsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#comparison TfAutomationRule#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#key TfAutomationRule#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#value TfAutomationRule#value}
        */
        readonly value: string;
    }
    class UserDefinedFieldsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): UserDefinedFieldsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: UserDefinedFieldsProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class UserDefinedFieldsPropertyList extends cdktn.ComplexList {
        internalValue?: UserDefinedFieldsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): UserDefinedFieldsPropertyOutputReference;
    }
    interface VerificationStateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#comparison TfAutomationRule#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#value TfAutomationRule#value}
        */
        readonly value: string;
    }
    class VerificationStatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VerificationStateProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VerificationStateProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class VerificationStatePropertyList extends cdktn.ComplexList {
        internalValue?: VerificationStateProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VerificationStatePropertyOutputReference;
    }
    interface WorkflowStatusProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#comparison TfAutomationRule#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#value TfAutomationRule#value}
        */
        readonly value: string;
    }
    class WorkflowStatusPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStatusProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStatusProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class WorkflowStatusPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStatusProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStatusPropertyOutputReference;
    }
    interface CriteriaProperty {
        /**
        * aws_account_id block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#aws_account_id TfAutomationRule#aws_account_id}
        */
        readonly awsAccountId?: AwsAccountIdProperty[] | cdktn.IResolvable;
        /**
        * aws_account_name block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#aws_account_name TfAutomationRule#aws_account_name}
        */
        readonly awsAccountName?: AwsAccountNameProperty[] | cdktn.IResolvable;
        /**
        * company_name block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#company_name TfAutomationRule#company_name}
        */
        readonly companyName?: CompanyNameProperty[] | cdktn.IResolvable;
        /**
        * compliance_associated_standards_id block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#compliance_associated_standards_id TfAutomationRule#compliance_associated_standards_id}
        */
        readonly complianceAssociatedStandardsId?: ComplianceAssociatedStandardsIdProperty[] | cdktn.IResolvable;
        /**
        * compliance_security_control_id block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#compliance_security_control_id TfAutomationRule#compliance_security_control_id}
        */
        readonly complianceSecurityControlId?: ComplianceSecurityControlIdProperty[] | cdktn.IResolvable;
        /**
        * compliance_status block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#compliance_status TfAutomationRule#compliance_status}
        */
        readonly complianceStatus?: ComplianceStatusProperty[] | cdktn.IResolvable;
        /**
        * confidence block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#confidence TfAutomationRule#confidence}
        */
        readonly confidence?: ConfidenceProperty[] | cdktn.IResolvable;
        /**
        * created_at block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#created_at TfAutomationRule#created_at}
        */
        readonly createdAt?: CreatedAtProperty[] | cdktn.IResolvable;
        /**
        * criticality block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#criticality TfAutomationRule#criticality}
        */
        readonly criticality?: CriticalityProperty[] | cdktn.IResolvable;
        /**
        * description block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#description TfAutomationRule#description}
        */
        readonly description?: DescriptionProperty[] | cdktn.IResolvable;
        /**
        * first_observed_at block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#first_observed_at TfAutomationRule#first_observed_at}
        */
        readonly firstObservedAt?: FirstObservedAtProperty[] | cdktn.IResolvable;
        /**
        * generator_id block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#generator_id TfAutomationRule#generator_id}
        */
        readonly generatorId?: GeneratorIdProperty[] | cdktn.IResolvable;
        /**
        * id block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#id TfAutomationRule#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id?: IdProperty[] | cdktn.IResolvable;
        /**
        * last_observed_at block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#last_observed_at TfAutomationRule#last_observed_at}
        */
        readonly lastObservedAt?: LastObservedAtProperty[] | cdktn.IResolvable;
        /**
        * note_text block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#note_text TfAutomationRule#note_text}
        */
        readonly noteText?: NoteTextProperty[] | cdktn.IResolvable;
        /**
        * note_updated_at block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#note_updated_at TfAutomationRule#note_updated_at}
        */
        readonly noteUpdatedAt?: NoteUpdatedAtProperty[] | cdktn.IResolvable;
        /**
        * note_updated_by block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#note_updated_by TfAutomationRule#note_updated_by}
        */
        readonly noteUpdatedBy?: NoteUpdatedByProperty[] | cdktn.IResolvable;
        /**
        * product_arn block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#product_arn TfAutomationRule#product_arn}
        */
        readonly productArn?: ProductArnProperty[] | cdktn.IResolvable;
        /**
        * product_name block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#product_name TfAutomationRule#product_name}
        */
        readonly productName?: ProductNameProperty[] | cdktn.IResolvable;
        /**
        * record_state block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#record_state TfAutomationRule#record_state}
        */
        readonly recordState?: RecordStateProperty[] | cdktn.IResolvable;
        /**
        * related_findings_id block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#related_findings_id TfAutomationRule#related_findings_id}
        */
        readonly relatedFindingsId?: RelatedFindingsIdProperty[] | cdktn.IResolvable;
        /**
        * related_findings_product_arn block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#related_findings_product_arn TfAutomationRule#related_findings_product_arn}
        */
        readonly relatedFindingsProductArn?: RelatedFindingsProductArnProperty[] | cdktn.IResolvable;
        /**
        * resource_application_arn block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#resource_application_arn TfAutomationRule#resource_application_arn}
        */
        readonly resourceApplicationArn?: ResourceApplicationArnProperty[] | cdktn.IResolvable;
        /**
        * resource_application_name block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#resource_application_name TfAutomationRule#resource_application_name}
        */
        readonly resourceApplicationName?: ResourceApplicationNameProperty[] | cdktn.IResolvable;
        /**
        * resource_details_other block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#resource_details_other TfAutomationRule#resource_details_other}
        */
        readonly resourceDetailsOther?: ResourceDetailsOtherProperty[] | cdktn.IResolvable;
        /**
        * resource_id block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#resource_id TfAutomationRule#resource_id}
        */
        readonly resourceId?: ResourceIdProperty[] | cdktn.IResolvable;
        /**
        * resource_partition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#resource_partition TfAutomationRule#resource_partition}
        */
        readonly resourcePartition?: ResourcePartitionProperty[] | cdktn.IResolvable;
        /**
        * resource_region block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#resource_region TfAutomationRule#resource_region}
        */
        readonly resourceRegion?: ResourceRegionProperty[] | cdktn.IResolvable;
        /**
        * resource_tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#resource_tags TfAutomationRule#resource_tags}
        */
        readonly resourceTags?: ResourceTagsProperty[] | cdktn.IResolvable;
        /**
        * resource_type block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#resource_type TfAutomationRule#resource_type}
        */
        readonly resourceType?: ResourceTypeProperty[] | cdktn.IResolvable;
        /**
        * severity_label block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#severity_label TfAutomationRule#severity_label}
        */
        readonly severityLabel?: SeverityLabelProperty[] | cdktn.IResolvable;
        /**
        * source_url block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#source_url TfAutomationRule#source_url}
        */
        readonly sourceUrl?: SourceUrlProperty[] | cdktn.IResolvable;
        /**
        * title block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#title TfAutomationRule#title}
        */
        readonly title?: TitleProperty[] | cdktn.IResolvable;
        /**
        * type block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#type TfAutomationRule#type}
        */
        readonly type?: TypeProperty[] | cdktn.IResolvable;
        /**
        * updated_at block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#updated_at TfAutomationRule#updated_at}
        */
        readonly updatedAt?: UpdatedAtProperty[] | cdktn.IResolvable;
        /**
        * user_defined_fields block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#user_defined_fields TfAutomationRule#user_defined_fields}
        */
        readonly userDefinedFields?: UserDefinedFieldsProperty[] | cdktn.IResolvable;
        /**
        * verification_state block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#verification_state TfAutomationRule#verification_state}
        */
        readonly verificationState?: VerificationStateProperty[] | cdktn.IResolvable;
        /**
        * workflow_status block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule#workflow_status TfAutomationRule#workflow_status}
        */
        readonly workflowStatus?: WorkflowStatusProperty[] | cdktn.IResolvable;
    }
    class CriteriaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CriteriaProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CriteriaProperty | cdktn.IResolvable | undefined);
        private _awsAccountId;
        get awsAccountId(): AwsAccountIdPropertyList;
        putAwsAccountId(value: AwsAccountIdProperty[] | cdktn.IResolvable): void;
        resetAwsAccountId(): void;
        get awsAccountIdInput(): cdktn.IResolvable | AwsAccountIdProperty[] | undefined;
        private _awsAccountName;
        get awsAccountName(): AwsAccountNamePropertyList;
        putAwsAccountName(value: AwsAccountNameProperty[] | cdktn.IResolvable): void;
        resetAwsAccountName(): void;
        get awsAccountNameInput(): cdktn.IResolvable | AwsAccountNameProperty[] | undefined;
        private _companyName;
        get companyName(): CompanyNamePropertyList;
        putCompanyName(value: CompanyNameProperty[] | cdktn.IResolvable): void;
        resetCompanyName(): void;
        get companyNameInput(): cdktn.IResolvable | CompanyNameProperty[] | undefined;
        private _complianceAssociatedStandardsId;
        get complianceAssociatedStandardsId(): ComplianceAssociatedStandardsIdPropertyList;
        putComplianceAssociatedStandardsId(value: ComplianceAssociatedStandardsIdProperty[] | cdktn.IResolvable): void;
        resetComplianceAssociatedStandardsId(): void;
        get complianceAssociatedStandardsIdInput(): cdktn.IResolvable | ComplianceAssociatedStandardsIdProperty[] | undefined;
        private _complianceSecurityControlId;
        get complianceSecurityControlId(): ComplianceSecurityControlIdPropertyList;
        putComplianceSecurityControlId(value: ComplianceSecurityControlIdProperty[] | cdktn.IResolvable): void;
        resetComplianceSecurityControlId(): void;
        get complianceSecurityControlIdInput(): cdktn.IResolvable | ComplianceSecurityControlIdProperty[] | undefined;
        private _complianceStatus;
        get complianceStatus(): ComplianceStatusPropertyList;
        putComplianceStatus(value: ComplianceStatusProperty[] | cdktn.IResolvable): void;
        resetComplianceStatus(): void;
        get complianceStatusInput(): cdktn.IResolvable | ComplianceStatusProperty[] | undefined;
        private _confidence;
        get confidence(): ConfidencePropertyList;
        putConfidence(value: ConfidenceProperty[] | cdktn.IResolvable): void;
        resetConfidence(): void;
        get confidenceInput(): cdktn.IResolvable | ConfidenceProperty[] | undefined;
        private _createdAt;
        get createdAt(): CreatedAtPropertyList;
        putCreatedAt(value: CreatedAtProperty[] | cdktn.IResolvable): void;
        resetCreatedAt(): void;
        get createdAtInput(): cdktn.IResolvable | CreatedAtProperty[] | undefined;
        private _criticality;
        get criticality(): CriticalityPropertyList;
        putCriticality(value: CriticalityProperty[] | cdktn.IResolvable): void;
        resetCriticality(): void;
        get criticalityInput(): cdktn.IResolvable | CriticalityProperty[] | undefined;
        private _description;
        get description(): DescriptionPropertyList;
        putDescription(value: DescriptionProperty[] | cdktn.IResolvable): void;
        resetDescription(): void;
        get descriptionInput(): cdktn.IResolvable | DescriptionProperty[] | undefined;
        private _firstObservedAt;
        get firstObservedAt(): FirstObservedAtPropertyList;
        putFirstObservedAt(value: FirstObservedAtProperty[] | cdktn.IResolvable): void;
        resetFirstObservedAt(): void;
        get firstObservedAtInput(): cdktn.IResolvable | FirstObservedAtProperty[] | undefined;
        private _generatorId;
        get generatorId(): GeneratorIdPropertyList;
        putGeneratorId(value: GeneratorIdProperty[] | cdktn.IResolvable): void;
        resetGeneratorId(): void;
        get generatorIdInput(): cdktn.IResolvable | GeneratorIdProperty[] | undefined;
        private _id;
        get id(): IdPropertyList;
        putId(value: IdProperty[] | cdktn.IResolvable): void;
        resetId(): void;
        get idInput(): cdktn.IResolvable | IdProperty[] | undefined;
        private _lastObservedAt;
        get lastObservedAt(): LastObservedAtPropertyList;
        putLastObservedAt(value: LastObservedAtProperty[] | cdktn.IResolvable): void;
        resetLastObservedAt(): void;
        get lastObservedAtInput(): cdktn.IResolvable | LastObservedAtProperty[] | undefined;
        private _noteText;
        get noteText(): NoteTextPropertyList;
        putNoteText(value: NoteTextProperty[] | cdktn.IResolvable): void;
        resetNoteText(): void;
        get noteTextInput(): cdktn.IResolvable | NoteTextProperty[] | undefined;
        private _noteUpdatedAt;
        get noteUpdatedAt(): NoteUpdatedAtPropertyList;
        putNoteUpdatedAt(value: NoteUpdatedAtProperty[] | cdktn.IResolvable): void;
        resetNoteUpdatedAt(): void;
        get noteUpdatedAtInput(): cdktn.IResolvable | NoteUpdatedAtProperty[] | undefined;
        private _noteUpdatedBy;
        get noteUpdatedBy(): NoteUpdatedByPropertyList;
        putNoteUpdatedBy(value: NoteUpdatedByProperty[] | cdktn.IResolvable): void;
        resetNoteUpdatedBy(): void;
        get noteUpdatedByInput(): cdktn.IResolvable | NoteUpdatedByProperty[] | undefined;
        private _productArn;
        get productArn(): ProductArnPropertyList;
        putProductArn(value: ProductArnProperty[] | cdktn.IResolvable): void;
        resetProductArn(): void;
        get productArnInput(): cdktn.IResolvable | ProductArnProperty[] | undefined;
        private _productName;
        get productName(): ProductNamePropertyList;
        putProductName(value: ProductNameProperty[] | cdktn.IResolvable): void;
        resetProductName(): void;
        get productNameInput(): cdktn.IResolvable | ProductNameProperty[] | undefined;
        private _recordState;
        get recordState(): RecordStatePropertyList;
        putRecordState(value: RecordStateProperty[] | cdktn.IResolvable): void;
        resetRecordState(): void;
        get recordStateInput(): cdktn.IResolvable | RecordStateProperty[] | undefined;
        private _relatedFindingsId;
        get relatedFindingsId(): RelatedFindingsIdPropertyList;
        putRelatedFindingsId(value: RelatedFindingsIdProperty[] | cdktn.IResolvable): void;
        resetRelatedFindingsId(): void;
        get relatedFindingsIdInput(): cdktn.IResolvable | RelatedFindingsIdProperty[] | undefined;
        private _relatedFindingsProductArn;
        get relatedFindingsProductArn(): RelatedFindingsProductArnPropertyList;
        putRelatedFindingsProductArn(value: RelatedFindingsProductArnProperty[] | cdktn.IResolvable): void;
        resetRelatedFindingsProductArn(): void;
        get relatedFindingsProductArnInput(): cdktn.IResolvable | RelatedFindingsProductArnProperty[] | undefined;
        private _resourceApplicationArn;
        get resourceApplicationArn(): ResourceApplicationArnPropertyList;
        putResourceApplicationArn(value: ResourceApplicationArnProperty[] | cdktn.IResolvable): void;
        resetResourceApplicationArn(): void;
        get resourceApplicationArnInput(): cdktn.IResolvable | ResourceApplicationArnProperty[] | undefined;
        private _resourceApplicationName;
        get resourceApplicationName(): ResourceApplicationNamePropertyList;
        putResourceApplicationName(value: ResourceApplicationNameProperty[] | cdktn.IResolvable): void;
        resetResourceApplicationName(): void;
        get resourceApplicationNameInput(): cdktn.IResolvable | ResourceApplicationNameProperty[] | undefined;
        private _resourceDetailsOther;
        get resourceDetailsOther(): ResourceDetailsOtherPropertyList;
        putResourceDetailsOther(value: ResourceDetailsOtherProperty[] | cdktn.IResolvable): void;
        resetResourceDetailsOther(): void;
        get resourceDetailsOtherInput(): cdktn.IResolvable | ResourceDetailsOtherProperty[] | undefined;
        private _resourceId;
        get resourceId(): ResourceIdPropertyList;
        putResourceId(value: ResourceIdProperty[] | cdktn.IResolvable): void;
        resetResourceId(): void;
        get resourceIdInput(): cdktn.IResolvable | ResourceIdProperty[] | undefined;
        private _resourcePartition;
        get resourcePartition(): ResourcePartitionPropertyList;
        putResourcePartition(value: ResourcePartitionProperty[] | cdktn.IResolvable): void;
        resetResourcePartition(): void;
        get resourcePartitionInput(): cdktn.IResolvable | ResourcePartitionProperty[] | undefined;
        private _resourceRegion;
        get resourceRegion(): ResourceRegionPropertyList;
        putResourceRegion(value: ResourceRegionProperty[] | cdktn.IResolvable): void;
        resetResourceRegion(): void;
        get resourceRegionInput(): cdktn.IResolvable | ResourceRegionProperty[] | undefined;
        private _resourceTags;
        get resourceTags(): ResourceTagsPropertyList;
        putResourceTags(value: ResourceTagsProperty[] | cdktn.IResolvable): void;
        resetResourceTags(): void;
        get resourceTagsInput(): cdktn.IResolvable | ResourceTagsProperty[] | undefined;
        private _resourceType;
        get resourceType(): ResourceTypePropertyList;
        putResourceType(value: ResourceTypeProperty[] | cdktn.IResolvable): void;
        resetResourceType(): void;
        get resourceTypeInput(): cdktn.IResolvable | ResourceTypeProperty[] | undefined;
        private _severityLabel;
        get severityLabel(): SeverityLabelPropertyList;
        putSeverityLabel(value: SeverityLabelProperty[] | cdktn.IResolvable): void;
        resetSeverityLabel(): void;
        get severityLabelInput(): cdktn.IResolvable | SeverityLabelProperty[] | undefined;
        private _sourceUrl;
        get sourceUrl(): SourceUrlPropertyList;
        putSourceUrl(value: SourceUrlProperty[] | cdktn.IResolvable): void;
        resetSourceUrl(): void;
        get sourceUrlInput(): cdktn.IResolvable | SourceUrlProperty[] | undefined;
        private _title;
        get title(): TitlePropertyList;
        putTitle(value: TitleProperty[] | cdktn.IResolvable): void;
        resetTitle(): void;
        get titleInput(): cdktn.IResolvable | TitleProperty[] | undefined;
        private _type;
        get type(): TypePropertyList;
        putType(value: TypeProperty[] | cdktn.IResolvable): void;
        resetType(): void;
        get typeInput(): cdktn.IResolvable | TypeProperty[] | undefined;
        private _updatedAt;
        get updatedAt(): UpdatedAtPropertyList;
        putUpdatedAt(value: UpdatedAtProperty[] | cdktn.IResolvable): void;
        resetUpdatedAt(): void;
        get updatedAtInput(): cdktn.IResolvable | UpdatedAtProperty[] | undefined;
        private _userDefinedFields;
        get userDefinedFields(): UserDefinedFieldsPropertyList;
        putUserDefinedFields(value: UserDefinedFieldsProperty[] | cdktn.IResolvable): void;
        resetUserDefinedFields(): void;
        get userDefinedFieldsInput(): cdktn.IResolvable | UserDefinedFieldsProperty[] | undefined;
        private _verificationState;
        get verificationState(): VerificationStatePropertyList;
        putVerificationState(value: VerificationStateProperty[] | cdktn.IResolvable): void;
        resetVerificationState(): void;
        get verificationStateInput(): cdktn.IResolvable | VerificationStateProperty[] | undefined;
        private _workflowStatus;
        get workflowStatus(): WorkflowStatusPropertyList;
        putWorkflowStatus(value: WorkflowStatusProperty[] | cdktn.IResolvable): void;
        resetWorkflowStatus(): void;
        get workflowStatusInput(): cdktn.IResolvable | WorkflowStatusProperty[] | undefined;
    }
    class CriteriaPropertyList extends cdktn.ComplexList {
        internalValue?: CriteriaProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CriteriaPropertyOutputReference;
    }
}
