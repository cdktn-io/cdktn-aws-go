import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSecurityhubConfigurationPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#description AwsSecurityhubConfigurationPolicy#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#id AwsSecurityhubConfigurationPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#name AwsSecurityhubConfigurationPolicy#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#region AwsSecurityhubConfigurationPolicy#region}
    */
    readonly region?: string;
    /**
    * configuration_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#configuration_policy AwsSecurityhubConfigurationPolicy#configuration_policy}
    */
    readonly configurationPolicy: AwsSecurityhubConfigurationPolicy.ConfigurationPolicyProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy aws_securityhub_configuration_policy}
*/
export declare class AwsSecurityhubConfigurationPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_securityhub_configuration_policy";
    /**
    * Generates CDKTN code for importing a AwsSecurityhubConfigurationPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSecurityhubConfigurationPolicy to import
    * @param importFromId The id of the existing AwsSecurityhubConfigurationPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSecurityhubConfigurationPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy aws_securityhub_configuration_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSecurityhubConfigurationPolicyConfig
    */
    constructor(scope: Construct, id: string, config: AwsSecurityhubConfigurationPolicyConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _configurationPolicy;
    get configurationPolicy(): AwsSecurityhubConfigurationPolicy.ConfigurationPolicyPropertyOutputReference;
    putConfigurationPolicy(value: AwsSecurityhubConfigurationPolicy.ConfigurationPolicyProperty): void;
    get configurationPolicyInput(): AwsSecurityhubConfigurationPolicy.ConfigurationPolicyProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsSecurityhubConfigurationPolicyBoolPropertyToTerraform(struct?: AwsSecurityhubConfigurationPolicy.BoolPropertyOutputReference | AwsSecurityhubConfigurationPolicy.BoolProperty): any;
export declare function awsSecurityhubConfigurationPolicyBoolPropertyToHclTerraform(struct?: AwsSecurityhubConfigurationPolicy.BoolPropertyOutputReference | AwsSecurityhubConfigurationPolicy.BoolProperty): any;
export declare function awsSecurityhubConfigurationPolicyDoublePropertyToTerraform(struct?: AwsSecurityhubConfigurationPolicy.DoublePropertyOutputReference | AwsSecurityhubConfigurationPolicy.DoubleProperty): any;
export declare function awsSecurityhubConfigurationPolicyDoublePropertyToHclTerraform(struct?: AwsSecurityhubConfigurationPolicy.DoublePropertyOutputReference | AwsSecurityhubConfigurationPolicy.DoubleProperty): any;
export declare function awsSecurityhubConfigurationPolicyEnumPropertyToTerraform(struct?: AwsSecurityhubConfigurationPolicy.EnumPropertyOutputReference | AwsSecurityhubConfigurationPolicy.EnumProperty): any;
export declare function awsSecurityhubConfigurationPolicyEnumPropertyToHclTerraform(struct?: AwsSecurityhubConfigurationPolicy.EnumPropertyOutputReference | AwsSecurityhubConfigurationPolicy.EnumProperty): any;
export declare function awsSecurityhubConfigurationPolicyEnumListPropertyToTerraform(struct?: AwsSecurityhubConfigurationPolicy.EnumListPropertyOutputReference | AwsSecurityhubConfigurationPolicy.EnumListProperty): any;
export declare function awsSecurityhubConfigurationPolicyEnumListPropertyToHclTerraform(struct?: AwsSecurityhubConfigurationPolicy.EnumListPropertyOutputReference | AwsSecurityhubConfigurationPolicy.EnumListProperty): any;
export declare function awsSecurityhubConfigurationPolicyIntPropertyToTerraform(struct?: AwsSecurityhubConfigurationPolicy.IntPropertyOutputReference | AwsSecurityhubConfigurationPolicy.IntProperty): any;
export declare function awsSecurityhubConfigurationPolicyIntPropertyToHclTerraform(struct?: AwsSecurityhubConfigurationPolicy.IntPropertyOutputReference | AwsSecurityhubConfigurationPolicy.IntProperty): any;
export declare function awsSecurityhubConfigurationPolicyIntListPropertyToTerraform(struct?: AwsSecurityhubConfigurationPolicy.IntListPropertyOutputReference | AwsSecurityhubConfigurationPolicy.IntListProperty): any;
export declare function awsSecurityhubConfigurationPolicyIntListPropertyToHclTerraform(struct?: AwsSecurityhubConfigurationPolicy.IntListPropertyOutputReference | AwsSecurityhubConfigurationPolicy.IntListProperty): any;
export declare function awsSecurityhubConfigurationPolicyStringPropertyToTerraform(struct?: AwsSecurityhubConfigurationPolicy.StringPropertyOutputReference | AwsSecurityhubConfigurationPolicy.StringProperty): any;
export declare function awsSecurityhubConfigurationPolicyStringPropertyToHclTerraform(struct?: AwsSecurityhubConfigurationPolicy.StringPropertyOutputReference | AwsSecurityhubConfigurationPolicy.StringProperty): any;
export declare function awsSecurityhubConfigurationPolicyStringListPropertyToTerraform(struct?: AwsSecurityhubConfigurationPolicy.StringListPropertyOutputReference | AwsSecurityhubConfigurationPolicy.StringListProperty): any;
export declare function awsSecurityhubConfigurationPolicyStringListPropertyToHclTerraform(struct?: AwsSecurityhubConfigurationPolicy.StringListPropertyOutputReference | AwsSecurityhubConfigurationPolicy.StringListProperty): any;
export declare function awsSecurityhubConfigurationPolicyParameterPropertyToTerraform(struct?: AwsSecurityhubConfigurationPolicy.ParameterProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubConfigurationPolicyParameterPropertyToHclTerraform(struct?: AwsSecurityhubConfigurationPolicy.ParameterProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubConfigurationPolicySecurityControlCustomParameterPropertyToTerraform(struct?: AwsSecurityhubConfigurationPolicy.SecurityControlCustomParameterProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubConfigurationPolicySecurityControlCustomParameterPropertyToHclTerraform(struct?: AwsSecurityhubConfigurationPolicy.SecurityControlCustomParameterProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubConfigurationPolicySecurityControlsConfigurationPropertyToTerraform(struct?: AwsSecurityhubConfigurationPolicy.SecurityControlsConfigurationPropertyOutputReference | AwsSecurityhubConfigurationPolicy.SecurityControlsConfigurationProperty): any;
export declare function awsSecurityhubConfigurationPolicySecurityControlsConfigurationPropertyToHclTerraform(struct?: AwsSecurityhubConfigurationPolicy.SecurityControlsConfigurationPropertyOutputReference | AwsSecurityhubConfigurationPolicy.SecurityControlsConfigurationProperty): any;
export declare function awsSecurityhubConfigurationPolicyConfigurationPolicyPropertyToTerraform(struct?: AwsSecurityhubConfigurationPolicy.ConfigurationPolicyPropertyOutputReference | AwsSecurityhubConfigurationPolicy.ConfigurationPolicyProperty): any;
export declare function awsSecurityhubConfigurationPolicyConfigurationPolicyPropertyToHclTerraform(struct?: AwsSecurityhubConfigurationPolicy.ConfigurationPolicyPropertyOutputReference | AwsSecurityhubConfigurationPolicy.ConfigurationPolicyProperty): any;
export declare namespace AwsSecurityhubConfigurationPolicy {
    interface BoolProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#value AwsSecurityhubConfigurationPolicy#value}
        */
        readonly value: boolean | cdktn.IResolvable;
    }
    class BoolPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BoolProperty | undefined;
        set internalValue(value: BoolProperty | undefined);
        private _value?;
        get value(): boolean | cdktn.IResolvable;
        set value(value: boolean | cdktn.IResolvable);
        get valueInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface DoubleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#value AwsSecurityhubConfigurationPolicy#value}
        */
        readonly value: number;
    }
    class DoublePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DoubleProperty | undefined;
        set internalValue(value: DoubleProperty | undefined);
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface EnumProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#value AwsSecurityhubConfigurationPolicy#value}
        */
        readonly value: string;
    }
    class EnumPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EnumProperty | undefined;
        set internalValue(value: EnumProperty | undefined);
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    interface EnumListProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#value AwsSecurityhubConfigurationPolicy#value}
        */
        readonly value: string[];
    }
    class EnumListPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EnumListProperty | undefined;
        set internalValue(value: EnumListProperty | undefined);
        private _value?;
        get value(): string[];
        set value(value: string[]);
        get valueInput(): string[] | undefined;
    }
    interface IntProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#value AwsSecurityhubConfigurationPolicy#value}
        */
        readonly value: number;
    }
    class IntPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IntProperty | undefined;
        set internalValue(value: IntProperty | undefined);
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface IntListProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#value AwsSecurityhubConfigurationPolicy#value}
        */
        readonly value: number[];
    }
    class IntListPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IntListProperty | undefined;
        set internalValue(value: IntListProperty | undefined);
        private _value?;
        get value(): number[];
        set value(value: number[]);
        get valueInput(): number[] | undefined;
    }
    interface StringProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#value AwsSecurityhubConfigurationPolicy#value}
        */
        readonly value: string;
    }
    class StringPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StringProperty | undefined;
        set internalValue(value: StringProperty | undefined);
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    interface StringListProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#value AwsSecurityhubConfigurationPolicy#value}
        */
        readonly value: string[];
    }
    class StringListPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StringListProperty | undefined;
        set internalValue(value: StringListProperty | undefined);
        private _value?;
        get value(): string[];
        set value(value: string[]);
        get valueInput(): string[] | undefined;
    }
    interface ParameterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#name AwsSecurityhubConfigurationPolicy#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#value_type AwsSecurityhubConfigurationPolicy#value_type}
        */
        readonly valueType: string;
        /**
        * bool block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#bool AwsSecurityhubConfigurationPolicy#bool}
        */
        readonly bool?: BoolProperty;
        /**
        * double block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#double AwsSecurityhubConfigurationPolicy#double}
        */
        readonly double?: DoubleProperty;
        /**
        * enum block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#enum AwsSecurityhubConfigurationPolicy#enum}
        */
        readonly enum?: EnumProperty;
        /**
        * enum_list block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#enum_list AwsSecurityhubConfigurationPolicy#enum_list}
        */
        readonly enumList?: EnumListProperty;
        /**
        * int block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#int AwsSecurityhubConfigurationPolicy#int}
        */
        readonly int?: IntProperty;
        /**
        * int_list block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#int_list AwsSecurityhubConfigurationPolicy#int_list}
        */
        readonly intList?: IntListProperty;
        /**
        * string block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#string AwsSecurityhubConfigurationPolicy#string}
        */
        readonly string?: StringProperty;
        /**
        * string_list block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#string_list AwsSecurityhubConfigurationPolicy#string_list}
        */
        readonly stringList?: StringListProperty;
    }
    class ParameterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ParameterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ParameterProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _valueType?;
        get valueType(): string;
        set valueType(value: string);
        get valueTypeInput(): string | undefined;
        private _bool;
        get bool(): BoolPropertyOutputReference;
        putBool(value: BoolProperty): void;
        resetBool(): void;
        get boolInput(): BoolProperty | undefined;
        private _double;
        get double(): DoublePropertyOutputReference;
        putDouble(value: DoubleProperty): void;
        resetDouble(): void;
        get doubleInput(): DoubleProperty | undefined;
        private _enum;
        get enum(): EnumPropertyOutputReference;
        putEnum(value: EnumProperty): void;
        resetEnum(): void;
        get enumInput(): EnumProperty | undefined;
        private _enumList;
        get enumList(): EnumListPropertyOutputReference;
        putEnumList(value: EnumListProperty): void;
        resetEnumList(): void;
        get enumListInput(): EnumListProperty | undefined;
        private _int;
        get int(): IntPropertyOutputReference;
        putInt(value: IntProperty): void;
        resetInt(): void;
        get intInput(): IntProperty | undefined;
        private _intList;
        get intList(): IntListPropertyOutputReference;
        putIntList(value: IntListProperty): void;
        resetIntList(): void;
        get intListInput(): IntListProperty | undefined;
        private _string;
        get string(): StringPropertyOutputReference;
        putString(value: StringProperty): void;
        resetString(): void;
        get stringInput(): StringProperty | undefined;
        private _stringList;
        get stringList(): StringListPropertyOutputReference;
        putStringList(value: StringListProperty): void;
        resetStringList(): void;
        get stringListInput(): StringListProperty | undefined;
    }
    class ParameterPropertyList extends cdktn.ComplexList {
        internalValue?: ParameterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ParameterPropertyOutputReference;
    }
    interface SecurityControlCustomParameterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#security_control_id AwsSecurityhubConfigurationPolicy#security_control_id}
        */
        readonly securityControlId: string;
        /**
        * parameter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#parameter AwsSecurityhubConfigurationPolicy#parameter}
        */
        readonly parameter: ParameterProperty[] | cdktn.IResolvable;
    }
    class SecurityControlCustomParameterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SecurityControlCustomParameterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SecurityControlCustomParameterProperty | cdktn.IResolvable | undefined);
        private _securityControlId?;
        get securityControlId(): string;
        set securityControlId(value: string);
        get securityControlIdInput(): string | undefined;
        private _parameter;
        get parameter(): ParameterPropertyList;
        putParameter(value: ParameterProperty[] | cdktn.IResolvable): void;
        get parameterInput(): cdktn.IResolvable | ParameterProperty[] | undefined;
    }
    class SecurityControlCustomParameterPropertyList extends cdktn.ComplexList {
        internalValue?: SecurityControlCustomParameterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SecurityControlCustomParameterPropertyOutputReference;
    }
    interface SecurityControlsConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#disabled_control_identifiers AwsSecurityhubConfigurationPolicy#disabled_control_identifiers}
        */
        readonly disabledControlIdentifiers?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#enabled_control_identifiers AwsSecurityhubConfigurationPolicy#enabled_control_identifiers}
        */
        readonly enabledControlIdentifiers?: string[];
        /**
        * security_control_custom_parameter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#security_control_custom_parameter AwsSecurityhubConfigurationPolicy#security_control_custom_parameter}
        */
        readonly securityControlCustomParameter?: SecurityControlCustomParameterProperty[] | cdktn.IResolvable;
    }
    class SecurityControlsConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SecurityControlsConfigurationProperty | undefined;
        set internalValue(value: SecurityControlsConfigurationProperty | undefined);
        private _disabledControlIdentifiers?;
        get disabledControlIdentifiers(): string[];
        set disabledControlIdentifiers(value: string[]);
        resetDisabledControlIdentifiers(): void;
        get disabledControlIdentifiersInput(): string[] | undefined;
        private _enabledControlIdentifiers?;
        get enabledControlIdentifiers(): string[];
        set enabledControlIdentifiers(value: string[]);
        resetEnabledControlIdentifiers(): void;
        get enabledControlIdentifiersInput(): string[] | undefined;
        private _securityControlCustomParameter;
        get securityControlCustomParameter(): SecurityControlCustomParameterPropertyList;
        putSecurityControlCustomParameter(value: SecurityControlCustomParameterProperty[] | cdktn.IResolvable): void;
        resetSecurityControlCustomParameter(): void;
        get securityControlCustomParameterInput(): cdktn.IResolvable | SecurityControlCustomParameterProperty[] | undefined;
    }
    interface ConfigurationPolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#enabled_standard_arns AwsSecurityhubConfigurationPolicy#enabled_standard_arns}
        */
        readonly enabledStandardArns?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#service_enabled AwsSecurityhubConfigurationPolicy#service_enabled}
        */
        readonly serviceEnabled: boolean | cdktn.IResolvable;
        /**
        * security_controls_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#security_controls_configuration AwsSecurityhubConfigurationPolicy#security_controls_configuration}
        */
        readonly securityControlsConfiguration?: SecurityControlsConfigurationProperty;
    }
    class ConfigurationPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConfigurationPolicyProperty | undefined;
        set internalValue(value: ConfigurationPolicyProperty | undefined);
        private _enabledStandardArns?;
        get enabledStandardArns(): string[];
        set enabledStandardArns(value: string[]);
        resetEnabledStandardArns(): void;
        get enabledStandardArnsInput(): string[] | undefined;
        private _serviceEnabled?;
        get serviceEnabled(): boolean | cdktn.IResolvable;
        set serviceEnabled(value: boolean | cdktn.IResolvable);
        get serviceEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _securityControlsConfiguration;
        get securityControlsConfiguration(): SecurityControlsConfigurationPropertyOutputReference;
        putSecurityControlsConfiguration(value: SecurityControlsConfigurationProperty): void;
        resetSecurityControlsConfiguration(): void;
        get securityControlsConfigurationInput(): SecurityControlsConfigurationProperty | undefined;
    }
}
