import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSecurityhubStandardsControlConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_standards_control#control_status AwsSecurityhubStandardsControl#control_status}
    */
    readonly controlStatus: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_standards_control#disabled_reason AwsSecurityhubStandardsControl#disabled_reason}
    */
    readonly disabledReason?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_standards_control#id AwsSecurityhubStandardsControl#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_standards_control#region AwsSecurityhubStandardsControl#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_standards_control#standards_control_arn AwsSecurityhubStandardsControl#standards_control_arn}
    */
    readonly standardsControlArn: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_standards_control aws_securityhub_standards_control}
*/
export declare class AwsSecurityhubStandardsControl extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_securityhub_standards_control";
    /**
    * Generates CDKTN code for importing a AwsSecurityhubStandardsControl resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSecurityhubStandardsControl to import
    * @param importFromId The id of the existing AwsSecurityhubStandardsControl that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_standards_control#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSecurityhubStandardsControl to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_standards_control aws_securityhub_standards_control} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSecurityhubStandardsControlConfig
    */
    constructor(scope: Construct, id: string, config: AwsSecurityhubStandardsControlConfig);
    get controlId(): string;
    private _controlStatus?;
    get controlStatus(): string;
    set controlStatus(value: string);
    get controlStatusInput(): string | undefined;
    get controlStatusUpdatedAt(): string;
    get description(): string;
    private _disabledReason?;
    get disabledReason(): string;
    set disabledReason(value: string);
    resetDisabledReason(): void;
    get disabledReasonInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get relatedRequirements(): string[];
    get remediationUrl(): string;
    get severityRating(): string;
    private _standardsControlArn?;
    get standardsControlArn(): string;
    set standardsControlArn(value: string);
    get standardsControlArnInput(): string | undefined;
    get title(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
