import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSecurityhubInsightConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#group_by_attribute AwsSecurityhubInsight#group_by_attribute}
    */
    readonly groupByAttribute: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#id AwsSecurityhubInsight#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#name AwsSecurityhubInsight#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#region AwsSecurityhubInsight#region}
    */
    readonly region?: string;
    /**
    * filters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#filters AwsSecurityhubInsight#filters}
    */
    readonly filters: AwsSecurityhubInsight.FiltersProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight aws_securityhub_insight}
*/
export declare class AwsSecurityhubInsight extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_securityhub_insight";
    /**
    * Generates CDKTN code for importing a AwsSecurityhubInsight resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSecurityhubInsight to import
    * @param importFromId The id of the existing AwsSecurityhubInsight that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSecurityhubInsight to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight aws_securityhub_insight} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSecurityhubInsightConfig
    */
    constructor(scope: Construct, id: string, config: AwsSecurityhubInsightConfig);
    get arn(): string;
    private _groupByAttribute?;
    get groupByAttribute(): string;
    set groupByAttribute(value: string);
    get groupByAttributeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _filters;
    get filters(): AwsSecurityhubInsight.FiltersPropertyOutputReference;
    putFilters(value: AwsSecurityhubInsight.FiltersProperty): void;
    get filtersInput(): AwsSecurityhubInsight.FiltersProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsSecurityhubInsightAwsAccountIdPropertyToTerraform(struct?: AwsSecurityhubInsight.AwsAccountIdProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightAwsAccountIdPropertyToHclTerraform(struct?: AwsSecurityhubInsight.AwsAccountIdProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightAwsAccountNamePropertyToTerraform(struct?: AwsSecurityhubInsight.AwsAccountNameProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightAwsAccountNamePropertyToHclTerraform(struct?: AwsSecurityhubInsight.AwsAccountNameProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightCompanyNamePropertyToTerraform(struct?: AwsSecurityhubInsight.CompanyNameProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightCompanyNamePropertyToHclTerraform(struct?: AwsSecurityhubInsight.CompanyNameProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightComplianceAssociatedStandardsIdPropertyToTerraform(struct?: AwsSecurityhubInsight.ComplianceAssociatedStandardsIdProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightComplianceAssociatedStandardsIdPropertyToHclTerraform(struct?: AwsSecurityhubInsight.ComplianceAssociatedStandardsIdProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightComplianceSecurityControlIdPropertyToTerraform(struct?: AwsSecurityhubInsight.ComplianceSecurityControlIdProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightComplianceSecurityControlIdPropertyToHclTerraform(struct?: AwsSecurityhubInsight.ComplianceSecurityControlIdProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightComplianceSecurityControlParametersNamePropertyToTerraform(struct?: AwsSecurityhubInsight.ComplianceSecurityControlParametersNameProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightComplianceSecurityControlParametersNamePropertyToHclTerraform(struct?: AwsSecurityhubInsight.ComplianceSecurityControlParametersNameProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightComplianceSecurityControlParametersValuePropertyToTerraform(struct?: AwsSecurityhubInsight.ComplianceSecurityControlParametersValueProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightComplianceSecurityControlParametersValuePropertyToHclTerraform(struct?: AwsSecurityhubInsight.ComplianceSecurityControlParametersValueProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightComplianceStatusPropertyToTerraform(struct?: AwsSecurityhubInsight.ComplianceStatusProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightComplianceStatusPropertyToHclTerraform(struct?: AwsSecurityhubInsight.ComplianceStatusProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightConfidencePropertyToTerraform(struct?: AwsSecurityhubInsight.ConfidenceProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightConfidencePropertyToHclTerraform(struct?: AwsSecurityhubInsight.ConfidenceProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightFiltersCreatedAtDateRangePropertyToTerraform(struct?: AwsSecurityhubInsight.FiltersCreatedAtDateRangePropertyOutputReference | AwsSecurityhubInsight.FiltersCreatedAtDateRangeProperty): any;
export declare function awsSecurityhubInsightFiltersCreatedAtDateRangePropertyToHclTerraform(struct?: AwsSecurityhubInsight.FiltersCreatedAtDateRangePropertyOutputReference | AwsSecurityhubInsight.FiltersCreatedAtDateRangeProperty): any;
export declare function awsSecurityhubInsightCreatedAtPropertyToTerraform(struct?: AwsSecurityhubInsight.CreatedAtProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightCreatedAtPropertyToHclTerraform(struct?: AwsSecurityhubInsight.CreatedAtProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightCriticalityPropertyToTerraform(struct?: AwsSecurityhubInsight.CriticalityProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightCriticalityPropertyToHclTerraform(struct?: AwsSecurityhubInsight.CriticalityProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightDescriptionPropertyToTerraform(struct?: AwsSecurityhubInsight.DescriptionProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightDescriptionPropertyToHclTerraform(struct?: AwsSecurityhubInsight.DescriptionProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightFindingProviderFieldsConfidencePropertyToTerraform(struct?: AwsSecurityhubInsight.FindingProviderFieldsConfidenceProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightFindingProviderFieldsConfidencePropertyToHclTerraform(struct?: AwsSecurityhubInsight.FindingProviderFieldsConfidenceProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightFindingProviderFieldsCriticalityPropertyToTerraform(struct?: AwsSecurityhubInsight.FindingProviderFieldsCriticalityProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightFindingProviderFieldsCriticalityPropertyToHclTerraform(struct?: AwsSecurityhubInsight.FindingProviderFieldsCriticalityProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightFindingProviderFieldsRelatedFindingsIdPropertyToTerraform(struct?: AwsSecurityhubInsight.FindingProviderFieldsRelatedFindingsIdProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightFindingProviderFieldsRelatedFindingsIdPropertyToHclTerraform(struct?: AwsSecurityhubInsight.FindingProviderFieldsRelatedFindingsIdProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightFindingProviderFieldsRelatedFindingsProductArnPropertyToTerraform(struct?: AwsSecurityhubInsight.FindingProviderFieldsRelatedFindingsProductArnProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightFindingProviderFieldsRelatedFindingsProductArnPropertyToHclTerraform(struct?: AwsSecurityhubInsight.FindingProviderFieldsRelatedFindingsProductArnProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightFindingProviderFieldsSeverityLabelPropertyToTerraform(struct?: AwsSecurityhubInsight.FindingProviderFieldsSeverityLabelProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightFindingProviderFieldsSeverityLabelPropertyToHclTerraform(struct?: AwsSecurityhubInsight.FindingProviderFieldsSeverityLabelProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightFindingProviderFieldsSeverityOriginalPropertyToTerraform(struct?: AwsSecurityhubInsight.FindingProviderFieldsSeverityOriginalProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightFindingProviderFieldsSeverityOriginalPropertyToHclTerraform(struct?: AwsSecurityhubInsight.FindingProviderFieldsSeverityOriginalProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightFindingProviderFieldsTypesPropertyToTerraform(struct?: AwsSecurityhubInsight.FindingProviderFieldsTypesProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightFindingProviderFieldsTypesPropertyToHclTerraform(struct?: AwsSecurityhubInsight.FindingProviderFieldsTypesProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightFiltersFirstObservedAtDateRangePropertyToTerraform(struct?: AwsSecurityhubInsight.FiltersFirstObservedAtDateRangePropertyOutputReference | AwsSecurityhubInsight.FiltersFirstObservedAtDateRangeProperty): any;
export declare function awsSecurityhubInsightFiltersFirstObservedAtDateRangePropertyToHclTerraform(struct?: AwsSecurityhubInsight.FiltersFirstObservedAtDateRangePropertyOutputReference | AwsSecurityhubInsight.FiltersFirstObservedAtDateRangeProperty): any;
export declare function awsSecurityhubInsightFirstObservedAtPropertyToTerraform(struct?: AwsSecurityhubInsight.FirstObservedAtProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightFirstObservedAtPropertyToHclTerraform(struct?: AwsSecurityhubInsight.FirstObservedAtProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightGeneratorIdPropertyToTerraform(struct?: AwsSecurityhubInsight.GeneratorIdProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightGeneratorIdPropertyToHclTerraform(struct?: AwsSecurityhubInsight.GeneratorIdProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightIdPropertyToTerraform(struct?: AwsSecurityhubInsight.IdProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightIdPropertyToHclTerraform(struct?: AwsSecurityhubInsight.IdProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightKeywordPropertyToTerraform(struct?: AwsSecurityhubInsight.KeywordProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightKeywordPropertyToHclTerraform(struct?: AwsSecurityhubInsight.KeywordProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightFiltersLastObservedAtDateRangePropertyToTerraform(struct?: AwsSecurityhubInsight.FiltersLastObservedAtDateRangePropertyOutputReference | AwsSecurityhubInsight.FiltersLastObservedAtDateRangeProperty): any;
export declare function awsSecurityhubInsightFiltersLastObservedAtDateRangePropertyToHclTerraform(struct?: AwsSecurityhubInsight.FiltersLastObservedAtDateRangePropertyOutputReference | AwsSecurityhubInsight.FiltersLastObservedAtDateRangeProperty): any;
export declare function awsSecurityhubInsightLastObservedAtPropertyToTerraform(struct?: AwsSecurityhubInsight.LastObservedAtProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightLastObservedAtPropertyToHclTerraform(struct?: AwsSecurityhubInsight.LastObservedAtProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightMalwareNamePropertyToTerraform(struct?: AwsSecurityhubInsight.MalwareNameProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightMalwareNamePropertyToHclTerraform(struct?: AwsSecurityhubInsight.MalwareNameProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightMalwarePathPropertyToTerraform(struct?: AwsSecurityhubInsight.MalwarePathProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightMalwarePathPropertyToHclTerraform(struct?: AwsSecurityhubInsight.MalwarePathProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightMalwareStatePropertyToTerraform(struct?: AwsSecurityhubInsight.MalwareStateProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightMalwareStatePropertyToHclTerraform(struct?: AwsSecurityhubInsight.MalwareStateProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightMalwareTypePropertyToTerraform(struct?: AwsSecurityhubInsight.MalwareTypeProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightMalwareTypePropertyToHclTerraform(struct?: AwsSecurityhubInsight.MalwareTypeProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightNetworkDestinationDomainPropertyToTerraform(struct?: AwsSecurityhubInsight.NetworkDestinationDomainProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightNetworkDestinationDomainPropertyToHclTerraform(struct?: AwsSecurityhubInsight.NetworkDestinationDomainProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightNetworkDestinationIpv4PropertyToTerraform(struct?: AwsSecurityhubInsight.NetworkDestinationIpv4Property | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightNetworkDestinationIpv4PropertyToHclTerraform(struct?: AwsSecurityhubInsight.NetworkDestinationIpv4Property | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightNetworkDestinationIpv6PropertyToTerraform(struct?: AwsSecurityhubInsight.NetworkDestinationIpv6Property | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightNetworkDestinationIpv6PropertyToHclTerraform(struct?: AwsSecurityhubInsight.NetworkDestinationIpv6Property | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightNetworkDestinationPortPropertyToTerraform(struct?: AwsSecurityhubInsight.NetworkDestinationPortProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightNetworkDestinationPortPropertyToHclTerraform(struct?: AwsSecurityhubInsight.NetworkDestinationPortProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightNetworkDirectionPropertyToTerraform(struct?: AwsSecurityhubInsight.NetworkDirectionProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightNetworkDirectionPropertyToHclTerraform(struct?: AwsSecurityhubInsight.NetworkDirectionProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightNetworkProtocolPropertyToTerraform(struct?: AwsSecurityhubInsight.NetworkProtocolProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightNetworkProtocolPropertyToHclTerraform(struct?: AwsSecurityhubInsight.NetworkProtocolProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightNetworkSourceDomainPropertyToTerraform(struct?: AwsSecurityhubInsight.NetworkSourceDomainProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightNetworkSourceDomainPropertyToHclTerraform(struct?: AwsSecurityhubInsight.NetworkSourceDomainProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightNetworkSourceIpv4PropertyToTerraform(struct?: AwsSecurityhubInsight.NetworkSourceIpv4Property | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightNetworkSourceIpv4PropertyToHclTerraform(struct?: AwsSecurityhubInsight.NetworkSourceIpv4Property | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightNetworkSourceIpv6PropertyToTerraform(struct?: AwsSecurityhubInsight.NetworkSourceIpv6Property | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightNetworkSourceIpv6PropertyToHclTerraform(struct?: AwsSecurityhubInsight.NetworkSourceIpv6Property | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightNetworkSourceMacPropertyToTerraform(struct?: AwsSecurityhubInsight.NetworkSourceMacProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightNetworkSourceMacPropertyToHclTerraform(struct?: AwsSecurityhubInsight.NetworkSourceMacProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightNetworkSourcePortPropertyToTerraform(struct?: AwsSecurityhubInsight.NetworkSourcePortProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightNetworkSourcePortPropertyToHclTerraform(struct?: AwsSecurityhubInsight.NetworkSourcePortProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightNoteTextPropertyToTerraform(struct?: AwsSecurityhubInsight.NoteTextProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightNoteTextPropertyToHclTerraform(struct?: AwsSecurityhubInsight.NoteTextProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightFiltersNoteUpdatedAtDateRangePropertyToTerraform(struct?: AwsSecurityhubInsight.FiltersNoteUpdatedAtDateRangePropertyOutputReference | AwsSecurityhubInsight.FiltersNoteUpdatedAtDateRangeProperty): any;
export declare function awsSecurityhubInsightFiltersNoteUpdatedAtDateRangePropertyToHclTerraform(struct?: AwsSecurityhubInsight.FiltersNoteUpdatedAtDateRangePropertyOutputReference | AwsSecurityhubInsight.FiltersNoteUpdatedAtDateRangeProperty): any;
export declare function awsSecurityhubInsightNoteUpdatedAtPropertyToTerraform(struct?: AwsSecurityhubInsight.NoteUpdatedAtProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightNoteUpdatedAtPropertyToHclTerraform(struct?: AwsSecurityhubInsight.NoteUpdatedAtProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightNoteUpdatedByPropertyToTerraform(struct?: AwsSecurityhubInsight.NoteUpdatedByProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightNoteUpdatedByPropertyToHclTerraform(struct?: AwsSecurityhubInsight.NoteUpdatedByProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightFiltersProcessLaunchedAtDateRangePropertyToTerraform(struct?: AwsSecurityhubInsight.FiltersProcessLaunchedAtDateRangePropertyOutputReference | AwsSecurityhubInsight.FiltersProcessLaunchedAtDateRangeProperty): any;
export declare function awsSecurityhubInsightFiltersProcessLaunchedAtDateRangePropertyToHclTerraform(struct?: AwsSecurityhubInsight.FiltersProcessLaunchedAtDateRangePropertyOutputReference | AwsSecurityhubInsight.FiltersProcessLaunchedAtDateRangeProperty): any;
export declare function awsSecurityhubInsightProcessLaunchedAtPropertyToTerraform(struct?: AwsSecurityhubInsight.ProcessLaunchedAtProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightProcessLaunchedAtPropertyToHclTerraform(struct?: AwsSecurityhubInsight.ProcessLaunchedAtProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightProcessNamePropertyToTerraform(struct?: AwsSecurityhubInsight.ProcessNameProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightProcessNamePropertyToHclTerraform(struct?: AwsSecurityhubInsight.ProcessNameProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightProcessParentPidPropertyToTerraform(struct?: AwsSecurityhubInsight.ProcessParentPidProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightProcessParentPidPropertyToHclTerraform(struct?: AwsSecurityhubInsight.ProcessParentPidProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightProcessPathPropertyToTerraform(struct?: AwsSecurityhubInsight.ProcessPathProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightProcessPathPropertyToHclTerraform(struct?: AwsSecurityhubInsight.ProcessPathProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightProcessPidPropertyToTerraform(struct?: AwsSecurityhubInsight.ProcessPidProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightProcessPidPropertyToHclTerraform(struct?: AwsSecurityhubInsight.ProcessPidProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightFiltersProcessTerminatedAtDateRangePropertyToTerraform(struct?: AwsSecurityhubInsight.FiltersProcessTerminatedAtDateRangePropertyOutputReference | AwsSecurityhubInsight.FiltersProcessTerminatedAtDateRangeProperty): any;
export declare function awsSecurityhubInsightFiltersProcessTerminatedAtDateRangePropertyToHclTerraform(struct?: AwsSecurityhubInsight.FiltersProcessTerminatedAtDateRangePropertyOutputReference | AwsSecurityhubInsight.FiltersProcessTerminatedAtDateRangeProperty): any;
export declare function awsSecurityhubInsightProcessTerminatedAtPropertyToTerraform(struct?: AwsSecurityhubInsight.ProcessTerminatedAtProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightProcessTerminatedAtPropertyToHclTerraform(struct?: AwsSecurityhubInsight.ProcessTerminatedAtProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightProductArnPropertyToTerraform(struct?: AwsSecurityhubInsight.ProductArnProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightProductArnPropertyToHclTerraform(struct?: AwsSecurityhubInsight.ProductArnProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightProductFieldsPropertyToTerraform(struct?: AwsSecurityhubInsight.ProductFieldsProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightProductFieldsPropertyToHclTerraform(struct?: AwsSecurityhubInsight.ProductFieldsProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightProductNamePropertyToTerraform(struct?: AwsSecurityhubInsight.ProductNameProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightProductNamePropertyToHclTerraform(struct?: AwsSecurityhubInsight.ProductNameProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightRecommendationTextPropertyToTerraform(struct?: AwsSecurityhubInsight.RecommendationTextProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightRecommendationTextPropertyToHclTerraform(struct?: AwsSecurityhubInsight.RecommendationTextProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightRecordStatePropertyToTerraform(struct?: AwsSecurityhubInsight.RecordStateProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightRecordStatePropertyToHclTerraform(struct?: AwsSecurityhubInsight.RecordStateProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightRelatedFindingsIdPropertyToTerraform(struct?: AwsSecurityhubInsight.RelatedFindingsIdProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightRelatedFindingsIdPropertyToHclTerraform(struct?: AwsSecurityhubInsight.RelatedFindingsIdProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightRelatedFindingsProductArnPropertyToTerraform(struct?: AwsSecurityhubInsight.RelatedFindingsProductArnProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightRelatedFindingsProductArnPropertyToHclTerraform(struct?: AwsSecurityhubInsight.RelatedFindingsProductArnProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightResourceAwsEc2InstanceIamInstanceProfileArnPropertyToTerraform(struct?: AwsSecurityhubInsight.ResourceAwsEc2InstanceIamInstanceProfileArnProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightResourceAwsEc2InstanceIamInstanceProfileArnPropertyToHclTerraform(struct?: AwsSecurityhubInsight.ResourceAwsEc2InstanceIamInstanceProfileArnProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightResourceAwsEc2InstanceImageIdPropertyToTerraform(struct?: AwsSecurityhubInsight.ResourceAwsEc2InstanceImageIdProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightResourceAwsEc2InstanceImageIdPropertyToHclTerraform(struct?: AwsSecurityhubInsight.ResourceAwsEc2InstanceImageIdProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightResourceAwsEc2InstanceIpv4AddressesPropertyToTerraform(struct?: AwsSecurityhubInsight.ResourceAwsEc2InstanceIpv4AddressesProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightResourceAwsEc2InstanceIpv4AddressesPropertyToHclTerraform(struct?: AwsSecurityhubInsight.ResourceAwsEc2InstanceIpv4AddressesProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightResourceAwsEc2InstanceIpv6AddressesPropertyToTerraform(struct?: AwsSecurityhubInsight.ResourceAwsEc2InstanceIpv6AddressesProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightResourceAwsEc2InstanceIpv6AddressesPropertyToHclTerraform(struct?: AwsSecurityhubInsight.ResourceAwsEc2InstanceIpv6AddressesProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightResourceAwsEc2InstanceKeyNamePropertyToTerraform(struct?: AwsSecurityhubInsight.ResourceAwsEc2InstanceKeyNameProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightResourceAwsEc2InstanceKeyNamePropertyToHclTerraform(struct?: AwsSecurityhubInsight.ResourceAwsEc2InstanceKeyNameProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightFiltersResourceAwsEc2InstanceLaunchedAtDateRangePropertyToTerraform(struct?: AwsSecurityhubInsight.FiltersResourceAwsEc2InstanceLaunchedAtDateRangePropertyOutputReference | AwsSecurityhubInsight.FiltersResourceAwsEc2InstanceLaunchedAtDateRangeProperty): any;
export declare function awsSecurityhubInsightFiltersResourceAwsEc2InstanceLaunchedAtDateRangePropertyToHclTerraform(struct?: AwsSecurityhubInsight.FiltersResourceAwsEc2InstanceLaunchedAtDateRangePropertyOutputReference | AwsSecurityhubInsight.FiltersResourceAwsEc2InstanceLaunchedAtDateRangeProperty): any;
export declare function awsSecurityhubInsightResourceAwsEc2InstanceLaunchedAtPropertyToTerraform(struct?: AwsSecurityhubInsight.ResourceAwsEc2InstanceLaunchedAtProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightResourceAwsEc2InstanceLaunchedAtPropertyToHclTerraform(struct?: AwsSecurityhubInsight.ResourceAwsEc2InstanceLaunchedAtProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightResourceAwsEc2InstanceSubnetIdPropertyToTerraform(struct?: AwsSecurityhubInsight.ResourceAwsEc2InstanceSubnetIdProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightResourceAwsEc2InstanceSubnetIdPropertyToHclTerraform(struct?: AwsSecurityhubInsight.ResourceAwsEc2InstanceSubnetIdProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightResourceAwsEc2InstanceTypePropertyToTerraform(struct?: AwsSecurityhubInsight.ResourceAwsEc2InstanceTypeProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightResourceAwsEc2InstanceTypePropertyToHclTerraform(struct?: AwsSecurityhubInsight.ResourceAwsEc2InstanceTypeProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightResourceAwsEc2InstanceVpcIdPropertyToTerraform(struct?: AwsSecurityhubInsight.ResourceAwsEc2InstanceVpcIdProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightResourceAwsEc2InstanceVpcIdPropertyToHclTerraform(struct?: AwsSecurityhubInsight.ResourceAwsEc2InstanceVpcIdProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightFiltersResourceAwsIamAccessKeyCreatedAtDateRangePropertyToTerraform(struct?: AwsSecurityhubInsight.FiltersResourceAwsIamAccessKeyCreatedAtDateRangePropertyOutputReference | AwsSecurityhubInsight.FiltersResourceAwsIamAccessKeyCreatedAtDateRangeProperty): any;
export declare function awsSecurityhubInsightFiltersResourceAwsIamAccessKeyCreatedAtDateRangePropertyToHclTerraform(struct?: AwsSecurityhubInsight.FiltersResourceAwsIamAccessKeyCreatedAtDateRangePropertyOutputReference | AwsSecurityhubInsight.FiltersResourceAwsIamAccessKeyCreatedAtDateRangeProperty): any;
export declare function awsSecurityhubInsightResourceAwsIamAccessKeyCreatedAtPropertyToTerraform(struct?: AwsSecurityhubInsight.ResourceAwsIamAccessKeyCreatedAtProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightResourceAwsIamAccessKeyCreatedAtPropertyToHclTerraform(struct?: AwsSecurityhubInsight.ResourceAwsIamAccessKeyCreatedAtProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightResourceAwsIamAccessKeyStatusPropertyToTerraform(struct?: AwsSecurityhubInsight.ResourceAwsIamAccessKeyStatusProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightResourceAwsIamAccessKeyStatusPropertyToHclTerraform(struct?: AwsSecurityhubInsight.ResourceAwsIamAccessKeyStatusProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightResourceAwsIamAccessKeyUserNamePropertyToTerraform(struct?: AwsSecurityhubInsight.ResourceAwsIamAccessKeyUserNameProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightResourceAwsIamAccessKeyUserNamePropertyToHclTerraform(struct?: AwsSecurityhubInsight.ResourceAwsIamAccessKeyUserNameProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightResourceAwsS3BucketOwnerIdPropertyToTerraform(struct?: AwsSecurityhubInsight.ResourceAwsS3BucketOwnerIdProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightResourceAwsS3BucketOwnerIdPropertyToHclTerraform(struct?: AwsSecurityhubInsight.ResourceAwsS3BucketOwnerIdProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightResourceAwsS3BucketOwnerNamePropertyToTerraform(struct?: AwsSecurityhubInsight.ResourceAwsS3BucketOwnerNameProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightResourceAwsS3BucketOwnerNamePropertyToHclTerraform(struct?: AwsSecurityhubInsight.ResourceAwsS3BucketOwnerNameProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightResourceContainerImageIdPropertyToTerraform(struct?: AwsSecurityhubInsight.ResourceContainerImageIdProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightResourceContainerImageIdPropertyToHclTerraform(struct?: AwsSecurityhubInsight.ResourceContainerImageIdProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightResourceContainerImageNamePropertyToTerraform(struct?: AwsSecurityhubInsight.ResourceContainerImageNameProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightResourceContainerImageNamePropertyToHclTerraform(struct?: AwsSecurityhubInsight.ResourceContainerImageNameProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightFiltersResourceContainerLaunchedAtDateRangePropertyToTerraform(struct?: AwsSecurityhubInsight.FiltersResourceContainerLaunchedAtDateRangePropertyOutputReference | AwsSecurityhubInsight.FiltersResourceContainerLaunchedAtDateRangeProperty): any;
export declare function awsSecurityhubInsightFiltersResourceContainerLaunchedAtDateRangePropertyToHclTerraform(struct?: AwsSecurityhubInsight.FiltersResourceContainerLaunchedAtDateRangePropertyOutputReference | AwsSecurityhubInsight.FiltersResourceContainerLaunchedAtDateRangeProperty): any;
export declare function awsSecurityhubInsightResourceContainerLaunchedAtPropertyToTerraform(struct?: AwsSecurityhubInsight.ResourceContainerLaunchedAtProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightResourceContainerLaunchedAtPropertyToHclTerraform(struct?: AwsSecurityhubInsight.ResourceContainerLaunchedAtProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightResourceContainerNamePropertyToTerraform(struct?: AwsSecurityhubInsight.ResourceContainerNameProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightResourceContainerNamePropertyToHclTerraform(struct?: AwsSecurityhubInsight.ResourceContainerNameProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightResourceDetailsOtherPropertyToTerraform(struct?: AwsSecurityhubInsight.ResourceDetailsOtherProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightResourceDetailsOtherPropertyToHclTerraform(struct?: AwsSecurityhubInsight.ResourceDetailsOtherProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightResourceIdPropertyToTerraform(struct?: AwsSecurityhubInsight.ResourceIdProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightResourceIdPropertyToHclTerraform(struct?: AwsSecurityhubInsight.ResourceIdProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightResourcePartitionPropertyToTerraform(struct?: AwsSecurityhubInsight.ResourcePartitionProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightResourcePartitionPropertyToHclTerraform(struct?: AwsSecurityhubInsight.ResourcePartitionProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightResourceRegionPropertyToTerraform(struct?: AwsSecurityhubInsight.ResourceRegionProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightResourceRegionPropertyToHclTerraform(struct?: AwsSecurityhubInsight.ResourceRegionProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightResourceTagsPropertyToTerraform(struct?: AwsSecurityhubInsight.ResourceTagsProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightResourceTagsPropertyToHclTerraform(struct?: AwsSecurityhubInsight.ResourceTagsProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightResourceTypePropertyToTerraform(struct?: AwsSecurityhubInsight.ResourceTypeProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightResourceTypePropertyToHclTerraform(struct?: AwsSecurityhubInsight.ResourceTypeProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightSeverityLabelPropertyToTerraform(struct?: AwsSecurityhubInsight.SeverityLabelProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightSeverityLabelPropertyToHclTerraform(struct?: AwsSecurityhubInsight.SeverityLabelProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightSourceUrlPropertyToTerraform(struct?: AwsSecurityhubInsight.SourceUrlProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightSourceUrlPropertyToHclTerraform(struct?: AwsSecurityhubInsight.SourceUrlProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightThreatIntelIndicatorCategoryPropertyToTerraform(struct?: AwsSecurityhubInsight.ThreatIntelIndicatorCategoryProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightThreatIntelIndicatorCategoryPropertyToHclTerraform(struct?: AwsSecurityhubInsight.ThreatIntelIndicatorCategoryProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightFiltersThreatIntelIndicatorLastObservedAtDateRangePropertyToTerraform(struct?: AwsSecurityhubInsight.FiltersThreatIntelIndicatorLastObservedAtDateRangePropertyOutputReference | AwsSecurityhubInsight.FiltersThreatIntelIndicatorLastObservedAtDateRangeProperty): any;
export declare function awsSecurityhubInsightFiltersThreatIntelIndicatorLastObservedAtDateRangePropertyToHclTerraform(struct?: AwsSecurityhubInsight.FiltersThreatIntelIndicatorLastObservedAtDateRangePropertyOutputReference | AwsSecurityhubInsight.FiltersThreatIntelIndicatorLastObservedAtDateRangeProperty): any;
export declare function awsSecurityhubInsightThreatIntelIndicatorLastObservedAtPropertyToTerraform(struct?: AwsSecurityhubInsight.ThreatIntelIndicatorLastObservedAtProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightThreatIntelIndicatorLastObservedAtPropertyToHclTerraform(struct?: AwsSecurityhubInsight.ThreatIntelIndicatorLastObservedAtProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightThreatIntelIndicatorSourcePropertyToTerraform(struct?: AwsSecurityhubInsight.ThreatIntelIndicatorSourceProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightThreatIntelIndicatorSourcePropertyToHclTerraform(struct?: AwsSecurityhubInsight.ThreatIntelIndicatorSourceProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightThreatIntelIndicatorSourceUrlPropertyToTerraform(struct?: AwsSecurityhubInsight.ThreatIntelIndicatorSourceUrlProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightThreatIntelIndicatorSourceUrlPropertyToHclTerraform(struct?: AwsSecurityhubInsight.ThreatIntelIndicatorSourceUrlProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightThreatIntelIndicatorTypePropertyToTerraform(struct?: AwsSecurityhubInsight.ThreatIntelIndicatorTypeProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightThreatIntelIndicatorTypePropertyToHclTerraform(struct?: AwsSecurityhubInsight.ThreatIntelIndicatorTypeProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightThreatIntelIndicatorValuePropertyToTerraform(struct?: AwsSecurityhubInsight.ThreatIntelIndicatorValueProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightThreatIntelIndicatorValuePropertyToHclTerraform(struct?: AwsSecurityhubInsight.ThreatIntelIndicatorValueProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightTitlePropertyToTerraform(struct?: AwsSecurityhubInsight.TitleProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightTitlePropertyToHclTerraform(struct?: AwsSecurityhubInsight.TitleProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightTypePropertyToTerraform(struct?: AwsSecurityhubInsight.TypeProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightTypePropertyToHclTerraform(struct?: AwsSecurityhubInsight.TypeProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightFiltersUpdatedAtDateRangePropertyToTerraform(struct?: AwsSecurityhubInsight.FiltersUpdatedAtDateRangePropertyOutputReference | AwsSecurityhubInsight.FiltersUpdatedAtDateRangeProperty): any;
export declare function awsSecurityhubInsightFiltersUpdatedAtDateRangePropertyToHclTerraform(struct?: AwsSecurityhubInsight.FiltersUpdatedAtDateRangePropertyOutputReference | AwsSecurityhubInsight.FiltersUpdatedAtDateRangeProperty): any;
export declare function awsSecurityhubInsightUpdatedAtPropertyToTerraform(struct?: AwsSecurityhubInsight.UpdatedAtProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightUpdatedAtPropertyToHclTerraform(struct?: AwsSecurityhubInsight.UpdatedAtProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightUserDefinedValuesPropertyToTerraform(struct?: AwsSecurityhubInsight.UserDefinedValuesProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightUserDefinedValuesPropertyToHclTerraform(struct?: AwsSecurityhubInsight.UserDefinedValuesProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightVerificationStatePropertyToTerraform(struct?: AwsSecurityhubInsight.VerificationStateProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightVerificationStatePropertyToHclTerraform(struct?: AwsSecurityhubInsight.VerificationStateProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightWorkflowStatusPropertyToTerraform(struct?: AwsSecurityhubInsight.WorkflowStatusProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightWorkflowStatusPropertyToHclTerraform(struct?: AwsSecurityhubInsight.WorkflowStatusProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubInsightFiltersPropertyToTerraform(struct?: AwsSecurityhubInsight.FiltersPropertyOutputReference | AwsSecurityhubInsight.FiltersProperty): any;
export declare function awsSecurityhubInsightFiltersPropertyToHclTerraform(struct?: AwsSecurityhubInsight.FiltersPropertyOutputReference | AwsSecurityhubInsight.FiltersProperty): any;
export declare namespace AwsSecurityhubInsight {
    interface AwsAccountIdProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class AwsAccountIdPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AwsAccountIdProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AwsAccountIdProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class AwsAccountIdPropertyList extends cdktn.ComplexList {
        internalValue?: AwsAccountIdProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AwsAccountIdPropertyOutputReference;
    }
    interface AwsAccountNameProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class AwsAccountNamePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AwsAccountNameProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AwsAccountNameProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class AwsAccountNamePropertyList extends cdktn.ComplexList {
        internalValue?: AwsAccountNameProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AwsAccountNamePropertyOutputReference;
    }
    interface CompanyNameProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class CompanyNamePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CompanyNameProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CompanyNameProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class CompanyNamePropertyList extends cdktn.ComplexList {
        internalValue?: CompanyNameProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CompanyNamePropertyOutputReference;
    }
    interface ComplianceAssociatedStandardsIdProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class ComplianceAssociatedStandardsIdPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ComplianceAssociatedStandardsIdProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ComplianceAssociatedStandardsIdProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ComplianceAssociatedStandardsIdPropertyList extends cdktn.ComplexList {
        internalValue?: ComplianceAssociatedStandardsIdProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ComplianceAssociatedStandardsIdPropertyOutputReference;
    }
    interface ComplianceSecurityControlIdProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class ComplianceSecurityControlIdPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ComplianceSecurityControlIdProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ComplianceSecurityControlIdProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ComplianceSecurityControlIdPropertyList extends cdktn.ComplexList {
        internalValue?: ComplianceSecurityControlIdProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ComplianceSecurityControlIdPropertyOutputReference;
    }
    interface ComplianceSecurityControlParametersNameProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class ComplianceSecurityControlParametersNamePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ComplianceSecurityControlParametersNameProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ComplianceSecurityControlParametersNameProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ComplianceSecurityControlParametersNamePropertyList extends cdktn.ComplexList {
        internalValue?: ComplianceSecurityControlParametersNameProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ComplianceSecurityControlParametersNamePropertyOutputReference;
    }
    interface ComplianceSecurityControlParametersValueProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class ComplianceSecurityControlParametersValuePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ComplianceSecurityControlParametersValueProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ComplianceSecurityControlParametersValueProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ComplianceSecurityControlParametersValuePropertyList extends cdktn.ComplexList {
        internalValue?: ComplianceSecurityControlParametersValueProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ComplianceSecurityControlParametersValuePropertyOutputReference;
    }
    interface ComplianceStatusProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class ComplianceStatusPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ComplianceStatusProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ComplianceStatusProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ComplianceStatusPropertyList extends cdktn.ComplexList {
        internalValue?: ComplianceStatusProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ComplianceStatusPropertyOutputReference;
    }
    interface ConfidenceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#eq AwsSecurityhubInsight#eq}
        */
        readonly eq?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#gte AwsSecurityhubInsight#gte}
        */
        readonly gte?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#lte AwsSecurityhubInsight#lte}
        */
        readonly lte?: string;
    }
    class ConfidencePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConfidenceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConfidenceProperty | cdktn.IResolvable | undefined);
        private _eq?;
        get eq(): string;
        set eq(value: string);
        resetEq(): void;
        get eqInput(): string | undefined;
        private _gte?;
        get gte(): string;
        set gte(value: string);
        resetGte(): void;
        get gteInput(): string | undefined;
        private _lte?;
        get lte(): string;
        set lte(value: string);
        resetLte(): void;
        get lteInput(): string | undefined;
    }
    class ConfidencePropertyList extends cdktn.ComplexList {
        internalValue?: ConfidenceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConfidencePropertyOutputReference;
    }
    interface FiltersCreatedAtDateRangeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#unit AwsSecurityhubInsight#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: number;
    }
    class FiltersCreatedAtDateRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FiltersCreatedAtDateRangeProperty | undefined;
        set internalValue(value: FiltersCreatedAtDateRangeProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface CreatedAtProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#end AwsSecurityhubInsight#end}
        */
        readonly end?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#start AwsSecurityhubInsight#start}
        */
        readonly start?: string;
        /**
        * date_range block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#date_range AwsSecurityhubInsight#date_range}
        */
        readonly dateRange?: FiltersCreatedAtDateRangeProperty;
    }
    class CreatedAtPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CreatedAtProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CreatedAtProperty | cdktn.IResolvable | undefined);
        private _end?;
        get end(): string;
        set end(value: string);
        resetEnd(): void;
        get endInput(): string | undefined;
        private _start?;
        get start(): string;
        set start(value: string);
        resetStart(): void;
        get startInput(): string | undefined;
        private _dateRange;
        get dateRange(): FiltersCreatedAtDateRangePropertyOutputReference;
        putDateRange(value: FiltersCreatedAtDateRangeProperty): void;
        resetDateRange(): void;
        get dateRangeInput(): FiltersCreatedAtDateRangeProperty | undefined;
    }
    class CreatedAtPropertyList extends cdktn.ComplexList {
        internalValue?: CreatedAtProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CreatedAtPropertyOutputReference;
    }
    interface CriticalityProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#eq AwsSecurityhubInsight#eq}
        */
        readonly eq?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#gte AwsSecurityhubInsight#gte}
        */
        readonly gte?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#lte AwsSecurityhubInsight#lte}
        */
        readonly lte?: string;
    }
    class CriticalityPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CriticalityProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CriticalityProperty | cdktn.IResolvable | undefined);
        private _eq?;
        get eq(): string;
        set eq(value: string);
        resetEq(): void;
        get eqInput(): string | undefined;
        private _gte?;
        get gte(): string;
        set gte(value: string);
        resetGte(): void;
        get gteInput(): string | undefined;
        private _lte?;
        get lte(): string;
        set lte(value: string);
        resetLte(): void;
        get lteInput(): string | undefined;
    }
    class CriticalityPropertyList extends cdktn.ComplexList {
        internalValue?: CriticalityProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CriticalityPropertyOutputReference;
    }
    interface DescriptionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class DescriptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DescriptionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DescriptionProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class DescriptionPropertyList extends cdktn.ComplexList {
        internalValue?: DescriptionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DescriptionPropertyOutputReference;
    }
    interface FindingProviderFieldsConfidenceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#eq AwsSecurityhubInsight#eq}
        */
        readonly eq?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#gte AwsSecurityhubInsight#gte}
        */
        readonly gte?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#lte AwsSecurityhubInsight#lte}
        */
        readonly lte?: string;
    }
    class FindingProviderFieldsConfidencePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FindingProviderFieldsConfidenceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FindingProviderFieldsConfidenceProperty | cdktn.IResolvable | undefined);
        private _eq?;
        get eq(): string;
        set eq(value: string);
        resetEq(): void;
        get eqInput(): string | undefined;
        private _gte?;
        get gte(): string;
        set gte(value: string);
        resetGte(): void;
        get gteInput(): string | undefined;
        private _lte?;
        get lte(): string;
        set lte(value: string);
        resetLte(): void;
        get lteInput(): string | undefined;
    }
    class FindingProviderFieldsConfidencePropertyList extends cdktn.ComplexList {
        internalValue?: FindingProviderFieldsConfidenceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FindingProviderFieldsConfidencePropertyOutputReference;
    }
    interface FindingProviderFieldsCriticalityProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#eq AwsSecurityhubInsight#eq}
        */
        readonly eq?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#gte AwsSecurityhubInsight#gte}
        */
        readonly gte?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#lte AwsSecurityhubInsight#lte}
        */
        readonly lte?: string;
    }
    class FindingProviderFieldsCriticalityPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FindingProviderFieldsCriticalityProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FindingProviderFieldsCriticalityProperty | cdktn.IResolvable | undefined);
        private _eq?;
        get eq(): string;
        set eq(value: string);
        resetEq(): void;
        get eqInput(): string | undefined;
        private _gte?;
        get gte(): string;
        set gte(value: string);
        resetGte(): void;
        get gteInput(): string | undefined;
        private _lte?;
        get lte(): string;
        set lte(value: string);
        resetLte(): void;
        get lteInput(): string | undefined;
    }
    class FindingProviderFieldsCriticalityPropertyList extends cdktn.ComplexList {
        internalValue?: FindingProviderFieldsCriticalityProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FindingProviderFieldsCriticalityPropertyOutputReference;
    }
    interface FindingProviderFieldsRelatedFindingsIdProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class FindingProviderFieldsRelatedFindingsIdPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FindingProviderFieldsRelatedFindingsIdProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FindingProviderFieldsRelatedFindingsIdProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class FindingProviderFieldsRelatedFindingsIdPropertyList extends cdktn.ComplexList {
        internalValue?: FindingProviderFieldsRelatedFindingsIdProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FindingProviderFieldsRelatedFindingsIdPropertyOutputReference;
    }
    interface FindingProviderFieldsRelatedFindingsProductArnProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class FindingProviderFieldsRelatedFindingsProductArnPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FindingProviderFieldsRelatedFindingsProductArnProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FindingProviderFieldsRelatedFindingsProductArnProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class FindingProviderFieldsRelatedFindingsProductArnPropertyList extends cdktn.ComplexList {
        internalValue?: FindingProviderFieldsRelatedFindingsProductArnProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FindingProviderFieldsRelatedFindingsProductArnPropertyOutputReference;
    }
    interface FindingProviderFieldsSeverityLabelProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class FindingProviderFieldsSeverityLabelPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FindingProviderFieldsSeverityLabelProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FindingProviderFieldsSeverityLabelProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class FindingProviderFieldsSeverityLabelPropertyList extends cdktn.ComplexList {
        internalValue?: FindingProviderFieldsSeverityLabelProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FindingProviderFieldsSeverityLabelPropertyOutputReference;
    }
    interface FindingProviderFieldsSeverityOriginalProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class FindingProviderFieldsSeverityOriginalPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FindingProviderFieldsSeverityOriginalProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FindingProviderFieldsSeverityOriginalProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class FindingProviderFieldsSeverityOriginalPropertyList extends cdktn.ComplexList {
        internalValue?: FindingProviderFieldsSeverityOriginalProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FindingProviderFieldsSeverityOriginalPropertyOutputReference;
    }
    interface FindingProviderFieldsTypesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class FindingProviderFieldsTypesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FindingProviderFieldsTypesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FindingProviderFieldsTypesProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class FindingProviderFieldsTypesPropertyList extends cdktn.ComplexList {
        internalValue?: FindingProviderFieldsTypesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FindingProviderFieldsTypesPropertyOutputReference;
    }
    interface FiltersFirstObservedAtDateRangeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#unit AwsSecurityhubInsight#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: number;
    }
    class FiltersFirstObservedAtDateRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FiltersFirstObservedAtDateRangeProperty | undefined;
        set internalValue(value: FiltersFirstObservedAtDateRangeProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface FirstObservedAtProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#end AwsSecurityhubInsight#end}
        */
        readonly end?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#start AwsSecurityhubInsight#start}
        */
        readonly start?: string;
        /**
        * date_range block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#date_range AwsSecurityhubInsight#date_range}
        */
        readonly dateRange?: FiltersFirstObservedAtDateRangeProperty;
    }
    class FirstObservedAtPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FirstObservedAtProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FirstObservedAtProperty | cdktn.IResolvable | undefined);
        private _end?;
        get end(): string;
        set end(value: string);
        resetEnd(): void;
        get endInput(): string | undefined;
        private _start?;
        get start(): string;
        set start(value: string);
        resetStart(): void;
        get startInput(): string | undefined;
        private _dateRange;
        get dateRange(): FiltersFirstObservedAtDateRangePropertyOutputReference;
        putDateRange(value: FiltersFirstObservedAtDateRangeProperty): void;
        resetDateRange(): void;
        get dateRangeInput(): FiltersFirstObservedAtDateRangeProperty | undefined;
    }
    class FirstObservedAtPropertyList extends cdktn.ComplexList {
        internalValue?: FirstObservedAtProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FirstObservedAtPropertyOutputReference;
    }
    interface GeneratorIdProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class GeneratorIdPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GeneratorIdProperty | cdktn.IResolvable | undefined;
        set internalValue(value: GeneratorIdProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class GeneratorIdPropertyList extends cdktn.ComplexList {
        internalValue?: GeneratorIdProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GeneratorIdPropertyOutputReference;
    }
    interface IdProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class IdPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IdProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IdProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class IdPropertyList extends cdktn.ComplexList {
        internalValue?: IdProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IdPropertyOutputReference;
    }
    interface KeywordProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class KeywordPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KeywordProperty | cdktn.IResolvable | undefined;
        set internalValue(value: KeywordProperty | cdktn.IResolvable | undefined);
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class KeywordPropertyList extends cdktn.ComplexList {
        internalValue?: KeywordProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KeywordPropertyOutputReference;
    }
    interface FiltersLastObservedAtDateRangeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#unit AwsSecurityhubInsight#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: number;
    }
    class FiltersLastObservedAtDateRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FiltersLastObservedAtDateRangeProperty | undefined;
        set internalValue(value: FiltersLastObservedAtDateRangeProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface LastObservedAtProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#end AwsSecurityhubInsight#end}
        */
        readonly end?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#start AwsSecurityhubInsight#start}
        */
        readonly start?: string;
        /**
        * date_range block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#date_range AwsSecurityhubInsight#date_range}
        */
        readonly dateRange?: FiltersLastObservedAtDateRangeProperty;
    }
    class LastObservedAtPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LastObservedAtProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LastObservedAtProperty | cdktn.IResolvable | undefined);
        private _end?;
        get end(): string;
        set end(value: string);
        resetEnd(): void;
        get endInput(): string | undefined;
        private _start?;
        get start(): string;
        set start(value: string);
        resetStart(): void;
        get startInput(): string | undefined;
        private _dateRange;
        get dateRange(): FiltersLastObservedAtDateRangePropertyOutputReference;
        putDateRange(value: FiltersLastObservedAtDateRangeProperty): void;
        resetDateRange(): void;
        get dateRangeInput(): FiltersLastObservedAtDateRangeProperty | undefined;
    }
    class LastObservedAtPropertyList extends cdktn.ComplexList {
        internalValue?: LastObservedAtProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LastObservedAtPropertyOutputReference;
    }
    interface MalwareNameProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class MalwareNamePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MalwareNameProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MalwareNameProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class MalwareNamePropertyList extends cdktn.ComplexList {
        internalValue?: MalwareNameProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MalwareNamePropertyOutputReference;
    }
    interface MalwarePathProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class MalwarePathPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MalwarePathProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MalwarePathProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class MalwarePathPropertyList extends cdktn.ComplexList {
        internalValue?: MalwarePathProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MalwarePathPropertyOutputReference;
    }
    interface MalwareStateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class MalwareStatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MalwareStateProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MalwareStateProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class MalwareStatePropertyList extends cdktn.ComplexList {
        internalValue?: MalwareStateProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MalwareStatePropertyOutputReference;
    }
    interface MalwareTypeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class MalwareTypePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MalwareTypeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MalwareTypeProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class MalwareTypePropertyList extends cdktn.ComplexList {
        internalValue?: MalwareTypeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MalwareTypePropertyOutputReference;
    }
    interface NetworkDestinationDomainProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class NetworkDestinationDomainPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NetworkDestinationDomainProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NetworkDestinationDomainProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class NetworkDestinationDomainPropertyList extends cdktn.ComplexList {
        internalValue?: NetworkDestinationDomainProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NetworkDestinationDomainPropertyOutputReference;
    }
    interface NetworkDestinationIpv4Property {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#cidr AwsSecurityhubInsight#cidr}
        */
        readonly cidr: string;
    }
    class NetworkDestinationIpv4PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NetworkDestinationIpv4Property | cdktn.IResolvable | undefined;
        set internalValue(value: NetworkDestinationIpv4Property | cdktn.IResolvable | undefined);
        private _cidr?;
        get cidr(): string;
        set cidr(value: string);
        get cidrInput(): string | undefined;
    }
    class NetworkDestinationIpv4PropertyList extends cdktn.ComplexList {
        internalValue?: NetworkDestinationIpv4Property[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NetworkDestinationIpv4PropertyOutputReference;
    }
    interface NetworkDestinationIpv6Property {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#cidr AwsSecurityhubInsight#cidr}
        */
        readonly cidr: string;
    }
    class NetworkDestinationIpv6PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NetworkDestinationIpv6Property | cdktn.IResolvable | undefined;
        set internalValue(value: NetworkDestinationIpv6Property | cdktn.IResolvable | undefined);
        private _cidr?;
        get cidr(): string;
        set cidr(value: string);
        get cidrInput(): string | undefined;
    }
    class NetworkDestinationIpv6PropertyList extends cdktn.ComplexList {
        internalValue?: NetworkDestinationIpv6Property[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NetworkDestinationIpv6PropertyOutputReference;
    }
    interface NetworkDestinationPortProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#eq AwsSecurityhubInsight#eq}
        */
        readonly eq?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#gte AwsSecurityhubInsight#gte}
        */
        readonly gte?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#lte AwsSecurityhubInsight#lte}
        */
        readonly lte?: string;
    }
    class NetworkDestinationPortPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NetworkDestinationPortProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NetworkDestinationPortProperty | cdktn.IResolvable | undefined);
        private _eq?;
        get eq(): string;
        set eq(value: string);
        resetEq(): void;
        get eqInput(): string | undefined;
        private _gte?;
        get gte(): string;
        set gte(value: string);
        resetGte(): void;
        get gteInput(): string | undefined;
        private _lte?;
        get lte(): string;
        set lte(value: string);
        resetLte(): void;
        get lteInput(): string | undefined;
    }
    class NetworkDestinationPortPropertyList extends cdktn.ComplexList {
        internalValue?: NetworkDestinationPortProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NetworkDestinationPortPropertyOutputReference;
    }
    interface NetworkDirectionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class NetworkDirectionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NetworkDirectionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NetworkDirectionProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class NetworkDirectionPropertyList extends cdktn.ComplexList {
        internalValue?: NetworkDirectionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NetworkDirectionPropertyOutputReference;
    }
    interface NetworkProtocolProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class NetworkProtocolPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NetworkProtocolProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NetworkProtocolProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class NetworkProtocolPropertyList extends cdktn.ComplexList {
        internalValue?: NetworkProtocolProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NetworkProtocolPropertyOutputReference;
    }
    interface NetworkSourceDomainProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class NetworkSourceDomainPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NetworkSourceDomainProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NetworkSourceDomainProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class NetworkSourceDomainPropertyList extends cdktn.ComplexList {
        internalValue?: NetworkSourceDomainProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NetworkSourceDomainPropertyOutputReference;
    }
    interface NetworkSourceIpv4Property {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#cidr AwsSecurityhubInsight#cidr}
        */
        readonly cidr: string;
    }
    class NetworkSourceIpv4PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NetworkSourceIpv4Property | cdktn.IResolvable | undefined;
        set internalValue(value: NetworkSourceIpv4Property | cdktn.IResolvable | undefined);
        private _cidr?;
        get cidr(): string;
        set cidr(value: string);
        get cidrInput(): string | undefined;
    }
    class NetworkSourceIpv4PropertyList extends cdktn.ComplexList {
        internalValue?: NetworkSourceIpv4Property[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NetworkSourceIpv4PropertyOutputReference;
    }
    interface NetworkSourceIpv6Property {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#cidr AwsSecurityhubInsight#cidr}
        */
        readonly cidr: string;
    }
    class NetworkSourceIpv6PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NetworkSourceIpv6Property | cdktn.IResolvable | undefined;
        set internalValue(value: NetworkSourceIpv6Property | cdktn.IResolvable | undefined);
        private _cidr?;
        get cidr(): string;
        set cidr(value: string);
        get cidrInput(): string | undefined;
    }
    class NetworkSourceIpv6PropertyList extends cdktn.ComplexList {
        internalValue?: NetworkSourceIpv6Property[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NetworkSourceIpv6PropertyOutputReference;
    }
    interface NetworkSourceMacProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class NetworkSourceMacPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NetworkSourceMacProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NetworkSourceMacProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class NetworkSourceMacPropertyList extends cdktn.ComplexList {
        internalValue?: NetworkSourceMacProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NetworkSourceMacPropertyOutputReference;
    }
    interface NetworkSourcePortProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#eq AwsSecurityhubInsight#eq}
        */
        readonly eq?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#gte AwsSecurityhubInsight#gte}
        */
        readonly gte?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#lte AwsSecurityhubInsight#lte}
        */
        readonly lte?: string;
    }
    class NetworkSourcePortPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NetworkSourcePortProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NetworkSourcePortProperty | cdktn.IResolvable | undefined);
        private _eq?;
        get eq(): string;
        set eq(value: string);
        resetEq(): void;
        get eqInput(): string | undefined;
        private _gte?;
        get gte(): string;
        set gte(value: string);
        resetGte(): void;
        get gteInput(): string | undefined;
        private _lte?;
        get lte(): string;
        set lte(value: string);
        resetLte(): void;
        get lteInput(): string | undefined;
    }
    class NetworkSourcePortPropertyList extends cdktn.ComplexList {
        internalValue?: NetworkSourcePortProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NetworkSourcePortPropertyOutputReference;
    }
    interface NoteTextProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class NoteTextPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NoteTextProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NoteTextProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class NoteTextPropertyList extends cdktn.ComplexList {
        internalValue?: NoteTextProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NoteTextPropertyOutputReference;
    }
    interface FiltersNoteUpdatedAtDateRangeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#unit AwsSecurityhubInsight#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: number;
    }
    class FiltersNoteUpdatedAtDateRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FiltersNoteUpdatedAtDateRangeProperty | undefined;
        set internalValue(value: FiltersNoteUpdatedAtDateRangeProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface NoteUpdatedAtProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#end AwsSecurityhubInsight#end}
        */
        readonly end?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#start AwsSecurityhubInsight#start}
        */
        readonly start?: string;
        /**
        * date_range block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#date_range AwsSecurityhubInsight#date_range}
        */
        readonly dateRange?: FiltersNoteUpdatedAtDateRangeProperty;
    }
    class NoteUpdatedAtPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NoteUpdatedAtProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NoteUpdatedAtProperty | cdktn.IResolvable | undefined);
        private _end?;
        get end(): string;
        set end(value: string);
        resetEnd(): void;
        get endInput(): string | undefined;
        private _start?;
        get start(): string;
        set start(value: string);
        resetStart(): void;
        get startInput(): string | undefined;
        private _dateRange;
        get dateRange(): FiltersNoteUpdatedAtDateRangePropertyOutputReference;
        putDateRange(value: FiltersNoteUpdatedAtDateRangeProperty): void;
        resetDateRange(): void;
        get dateRangeInput(): FiltersNoteUpdatedAtDateRangeProperty | undefined;
    }
    class NoteUpdatedAtPropertyList extends cdktn.ComplexList {
        internalValue?: NoteUpdatedAtProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NoteUpdatedAtPropertyOutputReference;
    }
    interface NoteUpdatedByProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class NoteUpdatedByPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NoteUpdatedByProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NoteUpdatedByProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class NoteUpdatedByPropertyList extends cdktn.ComplexList {
        internalValue?: NoteUpdatedByProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NoteUpdatedByPropertyOutputReference;
    }
    interface FiltersProcessLaunchedAtDateRangeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#unit AwsSecurityhubInsight#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: number;
    }
    class FiltersProcessLaunchedAtDateRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FiltersProcessLaunchedAtDateRangeProperty | undefined;
        set internalValue(value: FiltersProcessLaunchedAtDateRangeProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface ProcessLaunchedAtProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#end AwsSecurityhubInsight#end}
        */
        readonly end?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#start AwsSecurityhubInsight#start}
        */
        readonly start?: string;
        /**
        * date_range block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#date_range AwsSecurityhubInsight#date_range}
        */
        readonly dateRange?: FiltersProcessLaunchedAtDateRangeProperty;
    }
    class ProcessLaunchedAtPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ProcessLaunchedAtProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ProcessLaunchedAtProperty | cdktn.IResolvable | undefined);
        private _end?;
        get end(): string;
        set end(value: string);
        resetEnd(): void;
        get endInput(): string | undefined;
        private _start?;
        get start(): string;
        set start(value: string);
        resetStart(): void;
        get startInput(): string | undefined;
        private _dateRange;
        get dateRange(): FiltersProcessLaunchedAtDateRangePropertyOutputReference;
        putDateRange(value: FiltersProcessLaunchedAtDateRangeProperty): void;
        resetDateRange(): void;
        get dateRangeInput(): FiltersProcessLaunchedAtDateRangeProperty | undefined;
    }
    class ProcessLaunchedAtPropertyList extends cdktn.ComplexList {
        internalValue?: ProcessLaunchedAtProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ProcessLaunchedAtPropertyOutputReference;
    }
    interface ProcessNameProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class ProcessNamePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ProcessNameProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ProcessNameProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ProcessNamePropertyList extends cdktn.ComplexList {
        internalValue?: ProcessNameProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ProcessNamePropertyOutputReference;
    }
    interface ProcessParentPidProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#eq AwsSecurityhubInsight#eq}
        */
        readonly eq?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#gte AwsSecurityhubInsight#gte}
        */
        readonly gte?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#lte AwsSecurityhubInsight#lte}
        */
        readonly lte?: string;
    }
    class ProcessParentPidPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ProcessParentPidProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ProcessParentPidProperty | cdktn.IResolvable | undefined);
        private _eq?;
        get eq(): string;
        set eq(value: string);
        resetEq(): void;
        get eqInput(): string | undefined;
        private _gte?;
        get gte(): string;
        set gte(value: string);
        resetGte(): void;
        get gteInput(): string | undefined;
        private _lte?;
        get lte(): string;
        set lte(value: string);
        resetLte(): void;
        get lteInput(): string | undefined;
    }
    class ProcessParentPidPropertyList extends cdktn.ComplexList {
        internalValue?: ProcessParentPidProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ProcessParentPidPropertyOutputReference;
    }
    interface ProcessPathProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class ProcessPathPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ProcessPathProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ProcessPathProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ProcessPathPropertyList extends cdktn.ComplexList {
        internalValue?: ProcessPathProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ProcessPathPropertyOutputReference;
    }
    interface ProcessPidProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#eq AwsSecurityhubInsight#eq}
        */
        readonly eq?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#gte AwsSecurityhubInsight#gte}
        */
        readonly gte?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#lte AwsSecurityhubInsight#lte}
        */
        readonly lte?: string;
    }
    class ProcessPidPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ProcessPidProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ProcessPidProperty | cdktn.IResolvable | undefined);
        private _eq?;
        get eq(): string;
        set eq(value: string);
        resetEq(): void;
        get eqInput(): string | undefined;
        private _gte?;
        get gte(): string;
        set gte(value: string);
        resetGte(): void;
        get gteInput(): string | undefined;
        private _lte?;
        get lte(): string;
        set lte(value: string);
        resetLte(): void;
        get lteInput(): string | undefined;
    }
    class ProcessPidPropertyList extends cdktn.ComplexList {
        internalValue?: ProcessPidProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ProcessPidPropertyOutputReference;
    }
    interface FiltersProcessTerminatedAtDateRangeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#unit AwsSecurityhubInsight#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: number;
    }
    class FiltersProcessTerminatedAtDateRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FiltersProcessTerminatedAtDateRangeProperty | undefined;
        set internalValue(value: FiltersProcessTerminatedAtDateRangeProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface ProcessTerminatedAtProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#end AwsSecurityhubInsight#end}
        */
        readonly end?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#start AwsSecurityhubInsight#start}
        */
        readonly start?: string;
        /**
        * date_range block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#date_range AwsSecurityhubInsight#date_range}
        */
        readonly dateRange?: FiltersProcessTerminatedAtDateRangeProperty;
    }
    class ProcessTerminatedAtPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ProcessTerminatedAtProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ProcessTerminatedAtProperty | cdktn.IResolvable | undefined);
        private _end?;
        get end(): string;
        set end(value: string);
        resetEnd(): void;
        get endInput(): string | undefined;
        private _start?;
        get start(): string;
        set start(value: string);
        resetStart(): void;
        get startInput(): string | undefined;
        private _dateRange;
        get dateRange(): FiltersProcessTerminatedAtDateRangePropertyOutputReference;
        putDateRange(value: FiltersProcessTerminatedAtDateRangeProperty): void;
        resetDateRange(): void;
        get dateRangeInput(): FiltersProcessTerminatedAtDateRangeProperty | undefined;
    }
    class ProcessTerminatedAtPropertyList extends cdktn.ComplexList {
        internalValue?: ProcessTerminatedAtProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ProcessTerminatedAtPropertyOutputReference;
    }
    interface ProductArnProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class ProductArnPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ProductArnProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ProductArnProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ProductArnPropertyList extends cdktn.ComplexList {
        internalValue?: ProductArnProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ProductArnPropertyOutputReference;
    }
    interface ProductFieldsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#key AwsSecurityhubInsight#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class ProductFieldsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ProductFieldsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ProductFieldsProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ProductFieldsPropertyList extends cdktn.ComplexList {
        internalValue?: ProductFieldsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ProductFieldsPropertyOutputReference;
    }
    interface ProductNameProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class ProductNamePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ProductNameProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ProductNameProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ProductNamePropertyList extends cdktn.ComplexList {
        internalValue?: ProductNameProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ProductNamePropertyOutputReference;
    }
    interface RecommendationTextProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class RecommendationTextPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RecommendationTextProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RecommendationTextProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class RecommendationTextPropertyList extends cdktn.ComplexList {
        internalValue?: RecommendationTextProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RecommendationTextPropertyOutputReference;
    }
    interface RecordStateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class RecordStatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RecordStateProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RecordStateProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class RecordStatePropertyList extends cdktn.ComplexList {
        internalValue?: RecordStateProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RecordStatePropertyOutputReference;
    }
    interface RelatedFindingsIdProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class RelatedFindingsIdPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RelatedFindingsIdProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RelatedFindingsIdProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class RelatedFindingsIdPropertyList extends cdktn.ComplexList {
        internalValue?: RelatedFindingsIdProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RelatedFindingsIdPropertyOutputReference;
    }
    interface RelatedFindingsProductArnProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class RelatedFindingsProductArnPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RelatedFindingsProductArnProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RelatedFindingsProductArnProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class RelatedFindingsProductArnPropertyList extends cdktn.ComplexList {
        internalValue?: RelatedFindingsProductArnProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RelatedFindingsProductArnPropertyOutputReference;
    }
    interface ResourceAwsEc2InstanceIamInstanceProfileArnProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class ResourceAwsEc2InstanceIamInstanceProfileArnPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceAwsEc2InstanceIamInstanceProfileArnProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceAwsEc2InstanceIamInstanceProfileArnProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ResourceAwsEc2InstanceIamInstanceProfileArnPropertyList extends cdktn.ComplexList {
        internalValue?: ResourceAwsEc2InstanceIamInstanceProfileArnProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceAwsEc2InstanceIamInstanceProfileArnPropertyOutputReference;
    }
    interface ResourceAwsEc2InstanceImageIdProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class ResourceAwsEc2InstanceImageIdPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceAwsEc2InstanceImageIdProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceAwsEc2InstanceImageIdProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ResourceAwsEc2InstanceImageIdPropertyList extends cdktn.ComplexList {
        internalValue?: ResourceAwsEc2InstanceImageIdProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceAwsEc2InstanceImageIdPropertyOutputReference;
    }
    interface ResourceAwsEc2InstanceIpv4AddressesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#cidr AwsSecurityhubInsight#cidr}
        */
        readonly cidr: string;
    }
    class ResourceAwsEc2InstanceIpv4AddressesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceAwsEc2InstanceIpv4AddressesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceAwsEc2InstanceIpv4AddressesProperty | cdktn.IResolvable | undefined);
        private _cidr?;
        get cidr(): string;
        set cidr(value: string);
        get cidrInput(): string | undefined;
    }
    class ResourceAwsEc2InstanceIpv4AddressesPropertyList extends cdktn.ComplexList {
        internalValue?: ResourceAwsEc2InstanceIpv4AddressesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceAwsEc2InstanceIpv4AddressesPropertyOutputReference;
    }
    interface ResourceAwsEc2InstanceIpv6AddressesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#cidr AwsSecurityhubInsight#cidr}
        */
        readonly cidr: string;
    }
    class ResourceAwsEc2InstanceIpv6AddressesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceAwsEc2InstanceIpv6AddressesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceAwsEc2InstanceIpv6AddressesProperty | cdktn.IResolvable | undefined);
        private _cidr?;
        get cidr(): string;
        set cidr(value: string);
        get cidrInput(): string | undefined;
    }
    class ResourceAwsEc2InstanceIpv6AddressesPropertyList extends cdktn.ComplexList {
        internalValue?: ResourceAwsEc2InstanceIpv6AddressesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceAwsEc2InstanceIpv6AddressesPropertyOutputReference;
    }
    interface ResourceAwsEc2InstanceKeyNameProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class ResourceAwsEc2InstanceKeyNamePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceAwsEc2InstanceKeyNameProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceAwsEc2InstanceKeyNameProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ResourceAwsEc2InstanceKeyNamePropertyList extends cdktn.ComplexList {
        internalValue?: ResourceAwsEc2InstanceKeyNameProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceAwsEc2InstanceKeyNamePropertyOutputReference;
    }
    interface FiltersResourceAwsEc2InstanceLaunchedAtDateRangeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#unit AwsSecurityhubInsight#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: number;
    }
    class FiltersResourceAwsEc2InstanceLaunchedAtDateRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FiltersResourceAwsEc2InstanceLaunchedAtDateRangeProperty | undefined;
        set internalValue(value: FiltersResourceAwsEc2InstanceLaunchedAtDateRangeProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface ResourceAwsEc2InstanceLaunchedAtProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#end AwsSecurityhubInsight#end}
        */
        readonly end?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#start AwsSecurityhubInsight#start}
        */
        readonly start?: string;
        /**
        * date_range block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#date_range AwsSecurityhubInsight#date_range}
        */
        readonly dateRange?: FiltersResourceAwsEc2InstanceLaunchedAtDateRangeProperty;
    }
    class ResourceAwsEc2InstanceLaunchedAtPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceAwsEc2InstanceLaunchedAtProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceAwsEc2InstanceLaunchedAtProperty | cdktn.IResolvable | undefined);
        private _end?;
        get end(): string;
        set end(value: string);
        resetEnd(): void;
        get endInput(): string | undefined;
        private _start?;
        get start(): string;
        set start(value: string);
        resetStart(): void;
        get startInput(): string | undefined;
        private _dateRange;
        get dateRange(): FiltersResourceAwsEc2InstanceLaunchedAtDateRangePropertyOutputReference;
        putDateRange(value: FiltersResourceAwsEc2InstanceLaunchedAtDateRangeProperty): void;
        resetDateRange(): void;
        get dateRangeInput(): FiltersResourceAwsEc2InstanceLaunchedAtDateRangeProperty | undefined;
    }
    class ResourceAwsEc2InstanceLaunchedAtPropertyList extends cdktn.ComplexList {
        internalValue?: ResourceAwsEc2InstanceLaunchedAtProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceAwsEc2InstanceLaunchedAtPropertyOutputReference;
    }
    interface ResourceAwsEc2InstanceSubnetIdProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class ResourceAwsEc2InstanceSubnetIdPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceAwsEc2InstanceSubnetIdProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceAwsEc2InstanceSubnetIdProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ResourceAwsEc2InstanceSubnetIdPropertyList extends cdktn.ComplexList {
        internalValue?: ResourceAwsEc2InstanceSubnetIdProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceAwsEc2InstanceSubnetIdPropertyOutputReference;
    }
    interface ResourceAwsEc2InstanceTypeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class ResourceAwsEc2InstanceTypePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceAwsEc2InstanceTypeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceAwsEc2InstanceTypeProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ResourceAwsEc2InstanceTypePropertyList extends cdktn.ComplexList {
        internalValue?: ResourceAwsEc2InstanceTypeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceAwsEc2InstanceTypePropertyOutputReference;
    }
    interface ResourceAwsEc2InstanceVpcIdProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class ResourceAwsEc2InstanceVpcIdPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceAwsEc2InstanceVpcIdProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceAwsEc2InstanceVpcIdProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ResourceAwsEc2InstanceVpcIdPropertyList extends cdktn.ComplexList {
        internalValue?: ResourceAwsEc2InstanceVpcIdProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceAwsEc2InstanceVpcIdPropertyOutputReference;
    }
    interface FiltersResourceAwsIamAccessKeyCreatedAtDateRangeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#unit AwsSecurityhubInsight#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: number;
    }
    class FiltersResourceAwsIamAccessKeyCreatedAtDateRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FiltersResourceAwsIamAccessKeyCreatedAtDateRangeProperty | undefined;
        set internalValue(value: FiltersResourceAwsIamAccessKeyCreatedAtDateRangeProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface ResourceAwsIamAccessKeyCreatedAtProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#end AwsSecurityhubInsight#end}
        */
        readonly end?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#start AwsSecurityhubInsight#start}
        */
        readonly start?: string;
        /**
        * date_range block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#date_range AwsSecurityhubInsight#date_range}
        */
        readonly dateRange?: FiltersResourceAwsIamAccessKeyCreatedAtDateRangeProperty;
    }
    class ResourceAwsIamAccessKeyCreatedAtPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceAwsIamAccessKeyCreatedAtProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceAwsIamAccessKeyCreatedAtProperty | cdktn.IResolvable | undefined);
        private _end?;
        get end(): string;
        set end(value: string);
        resetEnd(): void;
        get endInput(): string | undefined;
        private _start?;
        get start(): string;
        set start(value: string);
        resetStart(): void;
        get startInput(): string | undefined;
        private _dateRange;
        get dateRange(): FiltersResourceAwsIamAccessKeyCreatedAtDateRangePropertyOutputReference;
        putDateRange(value: FiltersResourceAwsIamAccessKeyCreatedAtDateRangeProperty): void;
        resetDateRange(): void;
        get dateRangeInput(): FiltersResourceAwsIamAccessKeyCreatedAtDateRangeProperty | undefined;
    }
    class ResourceAwsIamAccessKeyCreatedAtPropertyList extends cdktn.ComplexList {
        internalValue?: ResourceAwsIamAccessKeyCreatedAtProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceAwsIamAccessKeyCreatedAtPropertyOutputReference;
    }
    interface ResourceAwsIamAccessKeyStatusProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class ResourceAwsIamAccessKeyStatusPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceAwsIamAccessKeyStatusProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceAwsIamAccessKeyStatusProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ResourceAwsIamAccessKeyStatusPropertyList extends cdktn.ComplexList {
        internalValue?: ResourceAwsIamAccessKeyStatusProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceAwsIamAccessKeyStatusPropertyOutputReference;
    }
    interface ResourceAwsIamAccessKeyUserNameProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class ResourceAwsIamAccessKeyUserNamePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceAwsIamAccessKeyUserNameProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceAwsIamAccessKeyUserNameProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ResourceAwsIamAccessKeyUserNamePropertyList extends cdktn.ComplexList {
        internalValue?: ResourceAwsIamAccessKeyUserNameProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceAwsIamAccessKeyUserNamePropertyOutputReference;
    }
    interface ResourceAwsS3BucketOwnerIdProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class ResourceAwsS3BucketOwnerIdPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceAwsS3BucketOwnerIdProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceAwsS3BucketOwnerIdProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ResourceAwsS3BucketOwnerIdPropertyList extends cdktn.ComplexList {
        internalValue?: ResourceAwsS3BucketOwnerIdProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceAwsS3BucketOwnerIdPropertyOutputReference;
    }
    interface ResourceAwsS3BucketOwnerNameProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class ResourceAwsS3BucketOwnerNamePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceAwsS3BucketOwnerNameProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceAwsS3BucketOwnerNameProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ResourceAwsS3BucketOwnerNamePropertyList extends cdktn.ComplexList {
        internalValue?: ResourceAwsS3BucketOwnerNameProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceAwsS3BucketOwnerNamePropertyOutputReference;
    }
    interface ResourceContainerImageIdProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class ResourceContainerImageIdPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceContainerImageIdProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceContainerImageIdProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ResourceContainerImageIdPropertyList extends cdktn.ComplexList {
        internalValue?: ResourceContainerImageIdProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceContainerImageIdPropertyOutputReference;
    }
    interface ResourceContainerImageNameProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class ResourceContainerImageNamePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceContainerImageNameProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceContainerImageNameProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ResourceContainerImageNamePropertyList extends cdktn.ComplexList {
        internalValue?: ResourceContainerImageNameProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceContainerImageNamePropertyOutputReference;
    }
    interface FiltersResourceContainerLaunchedAtDateRangeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#unit AwsSecurityhubInsight#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: number;
    }
    class FiltersResourceContainerLaunchedAtDateRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FiltersResourceContainerLaunchedAtDateRangeProperty | undefined;
        set internalValue(value: FiltersResourceContainerLaunchedAtDateRangeProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface ResourceContainerLaunchedAtProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#end AwsSecurityhubInsight#end}
        */
        readonly end?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#start AwsSecurityhubInsight#start}
        */
        readonly start?: string;
        /**
        * date_range block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#date_range AwsSecurityhubInsight#date_range}
        */
        readonly dateRange?: FiltersResourceContainerLaunchedAtDateRangeProperty;
    }
    class ResourceContainerLaunchedAtPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceContainerLaunchedAtProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceContainerLaunchedAtProperty | cdktn.IResolvable | undefined);
        private _end?;
        get end(): string;
        set end(value: string);
        resetEnd(): void;
        get endInput(): string | undefined;
        private _start?;
        get start(): string;
        set start(value: string);
        resetStart(): void;
        get startInput(): string | undefined;
        private _dateRange;
        get dateRange(): FiltersResourceContainerLaunchedAtDateRangePropertyOutputReference;
        putDateRange(value: FiltersResourceContainerLaunchedAtDateRangeProperty): void;
        resetDateRange(): void;
        get dateRangeInput(): FiltersResourceContainerLaunchedAtDateRangeProperty | undefined;
    }
    class ResourceContainerLaunchedAtPropertyList extends cdktn.ComplexList {
        internalValue?: ResourceContainerLaunchedAtProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceContainerLaunchedAtPropertyOutputReference;
    }
    interface ResourceContainerNameProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class ResourceContainerNamePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceContainerNameProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceContainerNameProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ResourceContainerNamePropertyList extends cdktn.ComplexList {
        internalValue?: ResourceContainerNameProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceContainerNamePropertyOutputReference;
    }
    interface ResourceDetailsOtherProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#key AwsSecurityhubInsight#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class ResourceDetailsOtherPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceDetailsOtherProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceDetailsOtherProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ResourceDetailsOtherPropertyList extends cdktn.ComplexList {
        internalValue?: ResourceDetailsOtherProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceDetailsOtherPropertyOutputReference;
    }
    interface ResourceIdProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class ResourceIdPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceIdProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceIdProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ResourceIdPropertyList extends cdktn.ComplexList {
        internalValue?: ResourceIdProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceIdPropertyOutputReference;
    }
    interface ResourcePartitionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class ResourcePartitionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourcePartitionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourcePartitionProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ResourcePartitionPropertyList extends cdktn.ComplexList {
        internalValue?: ResourcePartitionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourcePartitionPropertyOutputReference;
    }
    interface ResourceRegionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class ResourceRegionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceRegionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceRegionProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ResourceRegionPropertyList extends cdktn.ComplexList {
        internalValue?: ResourceRegionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceRegionPropertyOutputReference;
    }
    interface ResourceTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#key AwsSecurityhubInsight#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class ResourceTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceTagsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceTagsProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ResourceTagsPropertyList extends cdktn.ComplexList {
        internalValue?: ResourceTagsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceTagsPropertyOutputReference;
    }
    interface ResourceTypeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class ResourceTypePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceTypeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceTypeProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ResourceTypePropertyList extends cdktn.ComplexList {
        internalValue?: ResourceTypeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceTypePropertyOutputReference;
    }
    interface SeverityLabelProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class SeverityLabelPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SeverityLabelProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SeverityLabelProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class SeverityLabelPropertyList extends cdktn.ComplexList {
        internalValue?: SeverityLabelProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SeverityLabelPropertyOutputReference;
    }
    interface SourceUrlProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class SourceUrlPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SourceUrlProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SourceUrlProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class SourceUrlPropertyList extends cdktn.ComplexList {
        internalValue?: SourceUrlProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SourceUrlPropertyOutputReference;
    }
    interface ThreatIntelIndicatorCategoryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class ThreatIntelIndicatorCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ThreatIntelIndicatorCategoryProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ThreatIntelIndicatorCategoryProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ThreatIntelIndicatorCategoryPropertyList extends cdktn.ComplexList {
        internalValue?: ThreatIntelIndicatorCategoryProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ThreatIntelIndicatorCategoryPropertyOutputReference;
    }
    interface FiltersThreatIntelIndicatorLastObservedAtDateRangeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#unit AwsSecurityhubInsight#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: number;
    }
    class FiltersThreatIntelIndicatorLastObservedAtDateRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FiltersThreatIntelIndicatorLastObservedAtDateRangeProperty | undefined;
        set internalValue(value: FiltersThreatIntelIndicatorLastObservedAtDateRangeProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface ThreatIntelIndicatorLastObservedAtProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#end AwsSecurityhubInsight#end}
        */
        readonly end?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#start AwsSecurityhubInsight#start}
        */
        readonly start?: string;
        /**
        * date_range block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#date_range AwsSecurityhubInsight#date_range}
        */
        readonly dateRange?: FiltersThreatIntelIndicatorLastObservedAtDateRangeProperty;
    }
    class ThreatIntelIndicatorLastObservedAtPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ThreatIntelIndicatorLastObservedAtProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ThreatIntelIndicatorLastObservedAtProperty | cdktn.IResolvable | undefined);
        private _end?;
        get end(): string;
        set end(value: string);
        resetEnd(): void;
        get endInput(): string | undefined;
        private _start?;
        get start(): string;
        set start(value: string);
        resetStart(): void;
        get startInput(): string | undefined;
        private _dateRange;
        get dateRange(): FiltersThreatIntelIndicatorLastObservedAtDateRangePropertyOutputReference;
        putDateRange(value: FiltersThreatIntelIndicatorLastObservedAtDateRangeProperty): void;
        resetDateRange(): void;
        get dateRangeInput(): FiltersThreatIntelIndicatorLastObservedAtDateRangeProperty | undefined;
    }
    class ThreatIntelIndicatorLastObservedAtPropertyList extends cdktn.ComplexList {
        internalValue?: ThreatIntelIndicatorLastObservedAtProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ThreatIntelIndicatorLastObservedAtPropertyOutputReference;
    }
    interface ThreatIntelIndicatorSourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class ThreatIntelIndicatorSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ThreatIntelIndicatorSourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ThreatIntelIndicatorSourceProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ThreatIntelIndicatorSourcePropertyList extends cdktn.ComplexList {
        internalValue?: ThreatIntelIndicatorSourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ThreatIntelIndicatorSourcePropertyOutputReference;
    }
    interface ThreatIntelIndicatorSourceUrlProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class ThreatIntelIndicatorSourceUrlPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ThreatIntelIndicatorSourceUrlProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ThreatIntelIndicatorSourceUrlProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ThreatIntelIndicatorSourceUrlPropertyList extends cdktn.ComplexList {
        internalValue?: ThreatIntelIndicatorSourceUrlProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ThreatIntelIndicatorSourceUrlPropertyOutputReference;
    }
    interface ThreatIntelIndicatorTypeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class ThreatIntelIndicatorTypePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ThreatIntelIndicatorTypeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ThreatIntelIndicatorTypeProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ThreatIntelIndicatorTypePropertyList extends cdktn.ComplexList {
        internalValue?: ThreatIntelIndicatorTypeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ThreatIntelIndicatorTypePropertyOutputReference;
    }
    interface ThreatIntelIndicatorValueProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class ThreatIntelIndicatorValuePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ThreatIntelIndicatorValueProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ThreatIntelIndicatorValueProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ThreatIntelIndicatorValuePropertyList extends cdktn.ComplexList {
        internalValue?: ThreatIntelIndicatorValueProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ThreatIntelIndicatorValuePropertyOutputReference;
    }
    interface TitleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class TitlePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TitleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TitleProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class TitlePropertyList extends cdktn.ComplexList {
        internalValue?: TitleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TitlePropertyOutputReference;
    }
    interface TypeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class TypePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TypeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TypeProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class TypePropertyList extends cdktn.ComplexList {
        internalValue?: TypeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TypePropertyOutputReference;
    }
    interface FiltersUpdatedAtDateRangeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#unit AwsSecurityhubInsight#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: number;
    }
    class FiltersUpdatedAtDateRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FiltersUpdatedAtDateRangeProperty | undefined;
        set internalValue(value: FiltersUpdatedAtDateRangeProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface UpdatedAtProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#end AwsSecurityhubInsight#end}
        */
        readonly end?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#start AwsSecurityhubInsight#start}
        */
        readonly start?: string;
        /**
        * date_range block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#date_range AwsSecurityhubInsight#date_range}
        */
        readonly dateRange?: FiltersUpdatedAtDateRangeProperty;
    }
    class UpdatedAtPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): UpdatedAtProperty | cdktn.IResolvable | undefined;
        set internalValue(value: UpdatedAtProperty | cdktn.IResolvable | undefined);
        private _end?;
        get end(): string;
        set end(value: string);
        resetEnd(): void;
        get endInput(): string | undefined;
        private _start?;
        get start(): string;
        set start(value: string);
        resetStart(): void;
        get startInput(): string | undefined;
        private _dateRange;
        get dateRange(): FiltersUpdatedAtDateRangePropertyOutputReference;
        putDateRange(value: FiltersUpdatedAtDateRangeProperty): void;
        resetDateRange(): void;
        get dateRangeInput(): FiltersUpdatedAtDateRangeProperty | undefined;
    }
    class UpdatedAtPropertyList extends cdktn.ComplexList {
        internalValue?: UpdatedAtProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): UpdatedAtPropertyOutputReference;
    }
    interface UserDefinedValuesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#key AwsSecurityhubInsight#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class UserDefinedValuesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): UserDefinedValuesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: UserDefinedValuesProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class UserDefinedValuesPropertyList extends cdktn.ComplexList {
        internalValue?: UserDefinedValuesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): UserDefinedValuesPropertyOutputReference;
    }
    interface VerificationStateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class VerificationStatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VerificationStateProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VerificationStateProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class VerificationStatePropertyList extends cdktn.ComplexList {
        internalValue?: VerificationStateProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VerificationStatePropertyOutputReference;
    }
    interface WorkflowStatusProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#comparison AwsSecurityhubInsight#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#value AwsSecurityhubInsight#value}
        */
        readonly value: string;
    }
    class WorkflowStatusPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStatusProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStatusProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class WorkflowStatusPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStatusProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStatusPropertyOutputReference;
    }
    interface FiltersProperty {
        /**
        * aws_account_id block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#aws_account_id AwsSecurityhubInsight#aws_account_id}
        */
        readonly awsAccountId?: AwsAccountIdProperty[] | cdktn.IResolvable;
        /**
        * aws_account_name block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#aws_account_name AwsSecurityhubInsight#aws_account_name}
        */
        readonly awsAccountName?: AwsAccountNameProperty[] | cdktn.IResolvable;
        /**
        * company_name block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#company_name AwsSecurityhubInsight#company_name}
        */
        readonly companyName?: CompanyNameProperty[] | cdktn.IResolvable;
        /**
        * compliance_associated_standards_id block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#compliance_associated_standards_id AwsSecurityhubInsight#compliance_associated_standards_id}
        */
        readonly complianceAssociatedStandardsId?: ComplianceAssociatedStandardsIdProperty[] | cdktn.IResolvable;
        /**
        * compliance_security_control_id block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#compliance_security_control_id AwsSecurityhubInsight#compliance_security_control_id}
        */
        readonly complianceSecurityControlId?: ComplianceSecurityControlIdProperty[] | cdktn.IResolvable;
        /**
        * compliance_security_control_parameters_name block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#compliance_security_control_parameters_name AwsSecurityhubInsight#compliance_security_control_parameters_name}
        */
        readonly complianceSecurityControlParametersName?: ComplianceSecurityControlParametersNameProperty[] | cdktn.IResolvable;
        /**
        * compliance_security_control_parameters_value block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#compliance_security_control_parameters_value AwsSecurityhubInsight#compliance_security_control_parameters_value}
        */
        readonly complianceSecurityControlParametersValue?: ComplianceSecurityControlParametersValueProperty[] | cdktn.IResolvable;
        /**
        * compliance_status block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#compliance_status AwsSecurityhubInsight#compliance_status}
        */
        readonly complianceStatus?: ComplianceStatusProperty[] | cdktn.IResolvable;
        /**
        * confidence block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#confidence AwsSecurityhubInsight#confidence}
        */
        readonly confidence?: ConfidenceProperty[] | cdktn.IResolvable;
        /**
        * created_at block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#created_at AwsSecurityhubInsight#created_at}
        */
        readonly createdAt?: CreatedAtProperty[] | cdktn.IResolvable;
        /**
        * criticality block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#criticality AwsSecurityhubInsight#criticality}
        */
        readonly criticality?: CriticalityProperty[] | cdktn.IResolvable;
        /**
        * description block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#description AwsSecurityhubInsight#description}
        */
        readonly description?: DescriptionProperty[] | cdktn.IResolvable;
        /**
        * finding_provider_fields_confidence block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#finding_provider_fields_confidence AwsSecurityhubInsight#finding_provider_fields_confidence}
        */
        readonly findingProviderFieldsConfidence?: FindingProviderFieldsConfidenceProperty[] | cdktn.IResolvable;
        /**
        * finding_provider_fields_criticality block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#finding_provider_fields_criticality AwsSecurityhubInsight#finding_provider_fields_criticality}
        */
        readonly findingProviderFieldsCriticality?: FindingProviderFieldsCriticalityProperty[] | cdktn.IResolvable;
        /**
        * finding_provider_fields_related_findings_id block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#finding_provider_fields_related_findings_id AwsSecurityhubInsight#finding_provider_fields_related_findings_id}
        */
        readonly findingProviderFieldsRelatedFindingsId?: FindingProviderFieldsRelatedFindingsIdProperty[] | cdktn.IResolvable;
        /**
        * finding_provider_fields_related_findings_product_arn block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#finding_provider_fields_related_findings_product_arn AwsSecurityhubInsight#finding_provider_fields_related_findings_product_arn}
        */
        readonly findingProviderFieldsRelatedFindingsProductArn?: FindingProviderFieldsRelatedFindingsProductArnProperty[] | cdktn.IResolvable;
        /**
        * finding_provider_fields_severity_label block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#finding_provider_fields_severity_label AwsSecurityhubInsight#finding_provider_fields_severity_label}
        */
        readonly findingProviderFieldsSeverityLabel?: FindingProviderFieldsSeverityLabelProperty[] | cdktn.IResolvable;
        /**
        * finding_provider_fields_severity_original block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#finding_provider_fields_severity_original AwsSecurityhubInsight#finding_provider_fields_severity_original}
        */
        readonly findingProviderFieldsSeverityOriginal?: FindingProviderFieldsSeverityOriginalProperty[] | cdktn.IResolvable;
        /**
        * finding_provider_fields_types block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#finding_provider_fields_types AwsSecurityhubInsight#finding_provider_fields_types}
        */
        readonly findingProviderFieldsTypes?: FindingProviderFieldsTypesProperty[] | cdktn.IResolvable;
        /**
        * first_observed_at block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#first_observed_at AwsSecurityhubInsight#first_observed_at}
        */
        readonly firstObservedAt?: FirstObservedAtProperty[] | cdktn.IResolvable;
        /**
        * generator_id block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#generator_id AwsSecurityhubInsight#generator_id}
        */
        readonly generatorId?: GeneratorIdProperty[] | cdktn.IResolvable;
        /**
        * id block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#id AwsSecurityhubInsight#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id?: IdProperty[] | cdktn.IResolvable;
        /**
        * keyword block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#keyword AwsSecurityhubInsight#keyword}
        */
        readonly keyword?: KeywordProperty[] | cdktn.IResolvable;
        /**
        * last_observed_at block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#last_observed_at AwsSecurityhubInsight#last_observed_at}
        */
        readonly lastObservedAt?: LastObservedAtProperty[] | cdktn.IResolvable;
        /**
        * malware_name block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#malware_name AwsSecurityhubInsight#malware_name}
        */
        readonly malwareName?: MalwareNameProperty[] | cdktn.IResolvable;
        /**
        * malware_path block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#malware_path AwsSecurityhubInsight#malware_path}
        */
        readonly malwarePath?: MalwarePathProperty[] | cdktn.IResolvable;
        /**
        * malware_state block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#malware_state AwsSecurityhubInsight#malware_state}
        */
        readonly malwareState?: MalwareStateProperty[] | cdktn.IResolvable;
        /**
        * malware_type block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#malware_type AwsSecurityhubInsight#malware_type}
        */
        readonly malwareType?: MalwareTypeProperty[] | cdktn.IResolvable;
        /**
        * network_destination_domain block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#network_destination_domain AwsSecurityhubInsight#network_destination_domain}
        */
        readonly networkDestinationDomain?: NetworkDestinationDomainProperty[] | cdktn.IResolvable;
        /**
        * network_destination_ipv4 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#network_destination_ipv4 AwsSecurityhubInsight#network_destination_ipv4}
        */
        readonly networkDestinationIpv4?: NetworkDestinationIpv4Property[] | cdktn.IResolvable;
        /**
        * network_destination_ipv6 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#network_destination_ipv6 AwsSecurityhubInsight#network_destination_ipv6}
        */
        readonly networkDestinationIpv6?: NetworkDestinationIpv6Property[] | cdktn.IResolvable;
        /**
        * network_destination_port block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#network_destination_port AwsSecurityhubInsight#network_destination_port}
        */
        readonly networkDestinationPort?: NetworkDestinationPortProperty[] | cdktn.IResolvable;
        /**
        * network_direction block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#network_direction AwsSecurityhubInsight#network_direction}
        */
        readonly networkDirection?: NetworkDirectionProperty[] | cdktn.IResolvable;
        /**
        * network_protocol block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#network_protocol AwsSecurityhubInsight#network_protocol}
        */
        readonly networkProtocol?: NetworkProtocolProperty[] | cdktn.IResolvable;
        /**
        * network_source_domain block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#network_source_domain AwsSecurityhubInsight#network_source_domain}
        */
        readonly networkSourceDomain?: NetworkSourceDomainProperty[] | cdktn.IResolvable;
        /**
        * network_source_ipv4 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#network_source_ipv4 AwsSecurityhubInsight#network_source_ipv4}
        */
        readonly networkSourceIpv4?: NetworkSourceIpv4Property[] | cdktn.IResolvable;
        /**
        * network_source_ipv6 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#network_source_ipv6 AwsSecurityhubInsight#network_source_ipv6}
        */
        readonly networkSourceIpv6?: NetworkSourceIpv6Property[] | cdktn.IResolvable;
        /**
        * network_source_mac block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#network_source_mac AwsSecurityhubInsight#network_source_mac}
        */
        readonly networkSourceMac?: NetworkSourceMacProperty[] | cdktn.IResolvable;
        /**
        * network_source_port block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#network_source_port AwsSecurityhubInsight#network_source_port}
        */
        readonly networkSourcePort?: NetworkSourcePortProperty[] | cdktn.IResolvable;
        /**
        * note_text block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#note_text AwsSecurityhubInsight#note_text}
        */
        readonly noteText?: NoteTextProperty[] | cdktn.IResolvable;
        /**
        * note_updated_at block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#note_updated_at AwsSecurityhubInsight#note_updated_at}
        */
        readonly noteUpdatedAt?: NoteUpdatedAtProperty[] | cdktn.IResolvable;
        /**
        * note_updated_by block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#note_updated_by AwsSecurityhubInsight#note_updated_by}
        */
        readonly noteUpdatedBy?: NoteUpdatedByProperty[] | cdktn.IResolvable;
        /**
        * process_launched_at block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#process_launched_at AwsSecurityhubInsight#process_launched_at}
        */
        readonly processLaunchedAt?: ProcessLaunchedAtProperty[] | cdktn.IResolvable;
        /**
        * process_name block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#process_name AwsSecurityhubInsight#process_name}
        */
        readonly processName?: ProcessNameProperty[] | cdktn.IResolvable;
        /**
        * process_parent_pid block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#process_parent_pid AwsSecurityhubInsight#process_parent_pid}
        */
        readonly processParentPid?: ProcessParentPidProperty[] | cdktn.IResolvable;
        /**
        * process_path block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#process_path AwsSecurityhubInsight#process_path}
        */
        readonly processPath?: ProcessPathProperty[] | cdktn.IResolvable;
        /**
        * process_pid block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#process_pid AwsSecurityhubInsight#process_pid}
        */
        readonly processPid?: ProcessPidProperty[] | cdktn.IResolvable;
        /**
        * process_terminated_at block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#process_terminated_at AwsSecurityhubInsight#process_terminated_at}
        */
        readonly processTerminatedAt?: ProcessTerminatedAtProperty[] | cdktn.IResolvable;
        /**
        * product_arn block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#product_arn AwsSecurityhubInsight#product_arn}
        */
        readonly productArn?: ProductArnProperty[] | cdktn.IResolvable;
        /**
        * product_fields block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#product_fields AwsSecurityhubInsight#product_fields}
        */
        readonly productFields?: ProductFieldsProperty[] | cdktn.IResolvable;
        /**
        * product_name block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#product_name AwsSecurityhubInsight#product_name}
        */
        readonly productName?: ProductNameProperty[] | cdktn.IResolvable;
        /**
        * recommendation_text block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#recommendation_text AwsSecurityhubInsight#recommendation_text}
        */
        readonly recommendationText?: RecommendationTextProperty[] | cdktn.IResolvable;
        /**
        * record_state block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#record_state AwsSecurityhubInsight#record_state}
        */
        readonly recordState?: RecordStateProperty[] | cdktn.IResolvable;
        /**
        * related_findings_id block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#related_findings_id AwsSecurityhubInsight#related_findings_id}
        */
        readonly relatedFindingsId?: RelatedFindingsIdProperty[] | cdktn.IResolvable;
        /**
        * related_findings_product_arn block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#related_findings_product_arn AwsSecurityhubInsight#related_findings_product_arn}
        */
        readonly relatedFindingsProductArn?: RelatedFindingsProductArnProperty[] | cdktn.IResolvable;
        /**
        * resource_aws_ec2_instance_iam_instance_profile_arn block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#resource_aws_ec2_instance_iam_instance_profile_arn AwsSecurityhubInsight#resource_aws_ec2_instance_iam_instance_profile_arn}
        */
        readonly resourceAwsEc2InstanceIamInstanceProfileArn?: ResourceAwsEc2InstanceIamInstanceProfileArnProperty[] | cdktn.IResolvable;
        /**
        * resource_aws_ec2_instance_image_id block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#resource_aws_ec2_instance_image_id AwsSecurityhubInsight#resource_aws_ec2_instance_image_id}
        */
        readonly resourceAwsEc2InstanceImageId?: ResourceAwsEc2InstanceImageIdProperty[] | cdktn.IResolvable;
        /**
        * resource_aws_ec2_instance_ipv4_addresses block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#resource_aws_ec2_instance_ipv4_addresses AwsSecurityhubInsight#resource_aws_ec2_instance_ipv4_addresses}
        */
        readonly resourceAwsEc2InstanceIpv4Addresses?: ResourceAwsEc2InstanceIpv4AddressesProperty[] | cdktn.IResolvable;
        /**
        * resource_aws_ec2_instance_ipv6_addresses block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#resource_aws_ec2_instance_ipv6_addresses AwsSecurityhubInsight#resource_aws_ec2_instance_ipv6_addresses}
        */
        readonly resourceAwsEc2InstanceIpv6Addresses?: ResourceAwsEc2InstanceIpv6AddressesProperty[] | cdktn.IResolvable;
        /**
        * resource_aws_ec2_instance_key_name block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#resource_aws_ec2_instance_key_name AwsSecurityhubInsight#resource_aws_ec2_instance_key_name}
        */
        readonly resourceAwsEc2InstanceKeyName?: ResourceAwsEc2InstanceKeyNameProperty[] | cdktn.IResolvable;
        /**
        * resource_aws_ec2_instance_launched_at block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#resource_aws_ec2_instance_launched_at AwsSecurityhubInsight#resource_aws_ec2_instance_launched_at}
        */
        readonly resourceAwsEc2InstanceLaunchedAt?: ResourceAwsEc2InstanceLaunchedAtProperty[] | cdktn.IResolvable;
        /**
        * resource_aws_ec2_instance_subnet_id block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#resource_aws_ec2_instance_subnet_id AwsSecurityhubInsight#resource_aws_ec2_instance_subnet_id}
        */
        readonly resourceAwsEc2InstanceSubnetId?: ResourceAwsEc2InstanceSubnetIdProperty[] | cdktn.IResolvable;
        /**
        * resource_aws_ec2_instance_type block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#resource_aws_ec2_instance_type AwsSecurityhubInsight#resource_aws_ec2_instance_type}
        */
        readonly resourceAwsEc2InstanceType?: ResourceAwsEc2InstanceTypeProperty[] | cdktn.IResolvable;
        /**
        * resource_aws_ec2_instance_vpc_id block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#resource_aws_ec2_instance_vpc_id AwsSecurityhubInsight#resource_aws_ec2_instance_vpc_id}
        */
        readonly resourceAwsEc2InstanceVpcId?: ResourceAwsEc2InstanceVpcIdProperty[] | cdktn.IResolvable;
        /**
        * resource_aws_iam_access_key_created_at block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#resource_aws_iam_access_key_created_at AwsSecurityhubInsight#resource_aws_iam_access_key_created_at}
        */
        readonly resourceAwsIamAccessKeyCreatedAt?: ResourceAwsIamAccessKeyCreatedAtProperty[] | cdktn.IResolvable;
        /**
        * resource_aws_iam_access_key_status block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#resource_aws_iam_access_key_status AwsSecurityhubInsight#resource_aws_iam_access_key_status}
        */
        readonly resourceAwsIamAccessKeyStatus?: ResourceAwsIamAccessKeyStatusProperty[] | cdktn.IResolvable;
        /**
        * resource_aws_iam_access_key_user_name block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#resource_aws_iam_access_key_user_name AwsSecurityhubInsight#resource_aws_iam_access_key_user_name}
        */
        readonly resourceAwsIamAccessKeyUserName?: ResourceAwsIamAccessKeyUserNameProperty[] | cdktn.IResolvable;
        /**
        * resource_aws_s3_bucket_owner_id block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#resource_aws_s3_bucket_owner_id AwsSecurityhubInsight#resource_aws_s3_bucket_owner_id}
        */
        readonly resourceAwsS3BucketOwnerId?: ResourceAwsS3BucketOwnerIdProperty[] | cdktn.IResolvable;
        /**
        * resource_aws_s3_bucket_owner_name block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#resource_aws_s3_bucket_owner_name AwsSecurityhubInsight#resource_aws_s3_bucket_owner_name}
        */
        readonly resourceAwsS3BucketOwnerName?: ResourceAwsS3BucketOwnerNameProperty[] | cdktn.IResolvable;
        /**
        * resource_container_image_id block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#resource_container_image_id AwsSecurityhubInsight#resource_container_image_id}
        */
        readonly resourceContainerImageId?: ResourceContainerImageIdProperty[] | cdktn.IResolvable;
        /**
        * resource_container_image_name block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#resource_container_image_name AwsSecurityhubInsight#resource_container_image_name}
        */
        readonly resourceContainerImageName?: ResourceContainerImageNameProperty[] | cdktn.IResolvable;
        /**
        * resource_container_launched_at block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#resource_container_launched_at AwsSecurityhubInsight#resource_container_launched_at}
        */
        readonly resourceContainerLaunchedAt?: ResourceContainerLaunchedAtProperty[] | cdktn.IResolvable;
        /**
        * resource_container_name block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#resource_container_name AwsSecurityhubInsight#resource_container_name}
        */
        readonly resourceContainerName?: ResourceContainerNameProperty[] | cdktn.IResolvable;
        /**
        * resource_details_other block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#resource_details_other AwsSecurityhubInsight#resource_details_other}
        */
        readonly resourceDetailsOther?: ResourceDetailsOtherProperty[] | cdktn.IResolvable;
        /**
        * resource_id block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#resource_id AwsSecurityhubInsight#resource_id}
        */
        readonly resourceId?: ResourceIdProperty[] | cdktn.IResolvable;
        /**
        * resource_partition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#resource_partition AwsSecurityhubInsight#resource_partition}
        */
        readonly resourcePartition?: ResourcePartitionProperty[] | cdktn.IResolvable;
        /**
        * resource_region block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#resource_region AwsSecurityhubInsight#resource_region}
        */
        readonly resourceRegion?: ResourceRegionProperty[] | cdktn.IResolvable;
        /**
        * resource_tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#resource_tags AwsSecurityhubInsight#resource_tags}
        */
        readonly resourceTags?: ResourceTagsProperty[] | cdktn.IResolvable;
        /**
        * resource_type block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#resource_type AwsSecurityhubInsight#resource_type}
        */
        readonly resourceType?: ResourceTypeProperty[] | cdktn.IResolvable;
        /**
        * severity_label block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#severity_label AwsSecurityhubInsight#severity_label}
        */
        readonly severityLabel?: SeverityLabelProperty[] | cdktn.IResolvable;
        /**
        * source_url block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#source_url AwsSecurityhubInsight#source_url}
        */
        readonly sourceUrl?: SourceUrlProperty[] | cdktn.IResolvable;
        /**
        * threat_intel_indicator_category block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#threat_intel_indicator_category AwsSecurityhubInsight#threat_intel_indicator_category}
        */
        readonly threatIntelIndicatorCategory?: ThreatIntelIndicatorCategoryProperty[] | cdktn.IResolvable;
        /**
        * threat_intel_indicator_last_observed_at block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#threat_intel_indicator_last_observed_at AwsSecurityhubInsight#threat_intel_indicator_last_observed_at}
        */
        readonly threatIntelIndicatorLastObservedAt?: ThreatIntelIndicatorLastObservedAtProperty[] | cdktn.IResolvable;
        /**
        * threat_intel_indicator_source block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#threat_intel_indicator_source AwsSecurityhubInsight#threat_intel_indicator_source}
        */
        readonly threatIntelIndicatorSource?: ThreatIntelIndicatorSourceProperty[] | cdktn.IResolvable;
        /**
        * threat_intel_indicator_source_url block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#threat_intel_indicator_source_url AwsSecurityhubInsight#threat_intel_indicator_source_url}
        */
        readonly threatIntelIndicatorSourceUrl?: ThreatIntelIndicatorSourceUrlProperty[] | cdktn.IResolvable;
        /**
        * threat_intel_indicator_type block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#threat_intel_indicator_type AwsSecurityhubInsight#threat_intel_indicator_type}
        */
        readonly threatIntelIndicatorType?: ThreatIntelIndicatorTypeProperty[] | cdktn.IResolvable;
        /**
        * threat_intel_indicator_value block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#threat_intel_indicator_value AwsSecurityhubInsight#threat_intel_indicator_value}
        */
        readonly threatIntelIndicatorValue?: ThreatIntelIndicatorValueProperty[] | cdktn.IResolvable;
        /**
        * title block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#title AwsSecurityhubInsight#title}
        */
        readonly title?: TitleProperty[] | cdktn.IResolvable;
        /**
        * type block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#type AwsSecurityhubInsight#type}
        */
        readonly type?: TypeProperty[] | cdktn.IResolvable;
        /**
        * updated_at block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#updated_at AwsSecurityhubInsight#updated_at}
        */
        readonly updatedAt?: UpdatedAtProperty[] | cdktn.IResolvable;
        /**
        * user_defined_values block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#user_defined_values AwsSecurityhubInsight#user_defined_values}
        */
        readonly userDefinedValues?: UserDefinedValuesProperty[] | cdktn.IResolvable;
        /**
        * verification_state block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#verification_state AwsSecurityhubInsight#verification_state}
        */
        readonly verificationState?: VerificationStateProperty[] | cdktn.IResolvable;
        /**
        * workflow_status block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_insight#workflow_status AwsSecurityhubInsight#workflow_status}
        */
        readonly workflowStatus?: WorkflowStatusProperty[] | cdktn.IResolvable;
    }
    class FiltersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FiltersProperty | undefined;
        set internalValue(value: FiltersProperty | undefined);
        private _awsAccountId;
        get awsAccountId(): AwsAccountIdPropertyList;
        putAwsAccountId(value: AwsAccountIdProperty[] | cdktn.IResolvable): void;
        resetAwsAccountId(): void;
        get awsAccountIdInput(): cdktn.IResolvable | AwsAccountIdProperty[] | undefined;
        private _awsAccountName;
        get awsAccountName(): AwsAccountNamePropertyList;
        putAwsAccountName(value: AwsAccountNameProperty[] | cdktn.IResolvable): void;
        resetAwsAccountName(): void;
        get awsAccountNameInput(): cdktn.IResolvable | AwsAccountNameProperty[] | undefined;
        private _companyName;
        get companyName(): CompanyNamePropertyList;
        putCompanyName(value: CompanyNameProperty[] | cdktn.IResolvable): void;
        resetCompanyName(): void;
        get companyNameInput(): cdktn.IResolvable | CompanyNameProperty[] | undefined;
        private _complianceAssociatedStandardsId;
        get complianceAssociatedStandardsId(): ComplianceAssociatedStandardsIdPropertyList;
        putComplianceAssociatedStandardsId(value: ComplianceAssociatedStandardsIdProperty[] | cdktn.IResolvable): void;
        resetComplianceAssociatedStandardsId(): void;
        get complianceAssociatedStandardsIdInput(): cdktn.IResolvable | ComplianceAssociatedStandardsIdProperty[] | undefined;
        private _complianceSecurityControlId;
        get complianceSecurityControlId(): ComplianceSecurityControlIdPropertyList;
        putComplianceSecurityControlId(value: ComplianceSecurityControlIdProperty[] | cdktn.IResolvable): void;
        resetComplianceSecurityControlId(): void;
        get complianceSecurityControlIdInput(): cdktn.IResolvable | ComplianceSecurityControlIdProperty[] | undefined;
        private _complianceSecurityControlParametersName;
        get complianceSecurityControlParametersName(): ComplianceSecurityControlParametersNamePropertyList;
        putComplianceSecurityControlParametersName(value: ComplianceSecurityControlParametersNameProperty[] | cdktn.IResolvable): void;
        resetComplianceSecurityControlParametersName(): void;
        get complianceSecurityControlParametersNameInput(): cdktn.IResolvable | ComplianceSecurityControlParametersNameProperty[] | undefined;
        private _complianceSecurityControlParametersValue;
        get complianceSecurityControlParametersValue(): ComplianceSecurityControlParametersValuePropertyList;
        putComplianceSecurityControlParametersValue(value: ComplianceSecurityControlParametersValueProperty[] | cdktn.IResolvable): void;
        resetComplianceSecurityControlParametersValue(): void;
        get complianceSecurityControlParametersValueInput(): cdktn.IResolvable | ComplianceSecurityControlParametersValueProperty[] | undefined;
        private _complianceStatus;
        get complianceStatus(): ComplianceStatusPropertyList;
        putComplianceStatus(value: ComplianceStatusProperty[] | cdktn.IResolvable): void;
        resetComplianceStatus(): void;
        get complianceStatusInput(): cdktn.IResolvable | ComplianceStatusProperty[] | undefined;
        private _confidence;
        get confidence(): ConfidencePropertyList;
        putConfidence(value: ConfidenceProperty[] | cdktn.IResolvable): void;
        resetConfidence(): void;
        get confidenceInput(): cdktn.IResolvable | ConfidenceProperty[] | undefined;
        private _createdAt;
        get createdAt(): CreatedAtPropertyList;
        putCreatedAt(value: CreatedAtProperty[] | cdktn.IResolvable): void;
        resetCreatedAt(): void;
        get createdAtInput(): cdktn.IResolvable | CreatedAtProperty[] | undefined;
        private _criticality;
        get criticality(): CriticalityPropertyList;
        putCriticality(value: CriticalityProperty[] | cdktn.IResolvable): void;
        resetCriticality(): void;
        get criticalityInput(): cdktn.IResolvable | CriticalityProperty[] | undefined;
        private _description;
        get description(): DescriptionPropertyList;
        putDescription(value: DescriptionProperty[] | cdktn.IResolvable): void;
        resetDescription(): void;
        get descriptionInput(): cdktn.IResolvable | DescriptionProperty[] | undefined;
        private _findingProviderFieldsConfidence;
        get findingProviderFieldsConfidence(): FindingProviderFieldsConfidencePropertyList;
        putFindingProviderFieldsConfidence(value: FindingProviderFieldsConfidenceProperty[] | cdktn.IResolvable): void;
        resetFindingProviderFieldsConfidence(): void;
        get findingProviderFieldsConfidenceInput(): cdktn.IResolvable | FindingProviderFieldsConfidenceProperty[] | undefined;
        private _findingProviderFieldsCriticality;
        get findingProviderFieldsCriticality(): FindingProviderFieldsCriticalityPropertyList;
        putFindingProviderFieldsCriticality(value: FindingProviderFieldsCriticalityProperty[] | cdktn.IResolvable): void;
        resetFindingProviderFieldsCriticality(): void;
        get findingProviderFieldsCriticalityInput(): cdktn.IResolvable | FindingProviderFieldsCriticalityProperty[] | undefined;
        private _findingProviderFieldsRelatedFindingsId;
        get findingProviderFieldsRelatedFindingsId(): FindingProviderFieldsRelatedFindingsIdPropertyList;
        putFindingProviderFieldsRelatedFindingsId(value: FindingProviderFieldsRelatedFindingsIdProperty[] | cdktn.IResolvable): void;
        resetFindingProviderFieldsRelatedFindingsId(): void;
        get findingProviderFieldsRelatedFindingsIdInput(): cdktn.IResolvable | FindingProviderFieldsRelatedFindingsIdProperty[] | undefined;
        private _findingProviderFieldsRelatedFindingsProductArn;
        get findingProviderFieldsRelatedFindingsProductArn(): FindingProviderFieldsRelatedFindingsProductArnPropertyList;
        putFindingProviderFieldsRelatedFindingsProductArn(value: FindingProviderFieldsRelatedFindingsProductArnProperty[] | cdktn.IResolvable): void;
        resetFindingProviderFieldsRelatedFindingsProductArn(): void;
        get findingProviderFieldsRelatedFindingsProductArnInput(): cdktn.IResolvable | FindingProviderFieldsRelatedFindingsProductArnProperty[] | undefined;
        private _findingProviderFieldsSeverityLabel;
        get findingProviderFieldsSeverityLabel(): FindingProviderFieldsSeverityLabelPropertyList;
        putFindingProviderFieldsSeverityLabel(value: FindingProviderFieldsSeverityLabelProperty[] | cdktn.IResolvable): void;
        resetFindingProviderFieldsSeverityLabel(): void;
        get findingProviderFieldsSeverityLabelInput(): cdktn.IResolvable | FindingProviderFieldsSeverityLabelProperty[] | undefined;
        private _findingProviderFieldsSeverityOriginal;
        get findingProviderFieldsSeverityOriginal(): FindingProviderFieldsSeverityOriginalPropertyList;
        putFindingProviderFieldsSeverityOriginal(value: FindingProviderFieldsSeverityOriginalProperty[] | cdktn.IResolvable): void;
        resetFindingProviderFieldsSeverityOriginal(): void;
        get findingProviderFieldsSeverityOriginalInput(): cdktn.IResolvable | FindingProviderFieldsSeverityOriginalProperty[] | undefined;
        private _findingProviderFieldsTypes;
        get findingProviderFieldsTypes(): FindingProviderFieldsTypesPropertyList;
        putFindingProviderFieldsTypes(value: FindingProviderFieldsTypesProperty[] | cdktn.IResolvable): void;
        resetFindingProviderFieldsTypes(): void;
        get findingProviderFieldsTypesInput(): cdktn.IResolvable | FindingProviderFieldsTypesProperty[] | undefined;
        private _firstObservedAt;
        get firstObservedAt(): FirstObservedAtPropertyList;
        putFirstObservedAt(value: FirstObservedAtProperty[] | cdktn.IResolvable): void;
        resetFirstObservedAt(): void;
        get firstObservedAtInput(): cdktn.IResolvable | FirstObservedAtProperty[] | undefined;
        private _generatorId;
        get generatorId(): GeneratorIdPropertyList;
        putGeneratorId(value: GeneratorIdProperty[] | cdktn.IResolvable): void;
        resetGeneratorId(): void;
        get generatorIdInput(): cdktn.IResolvable | GeneratorIdProperty[] | undefined;
        private _id;
        get id(): IdPropertyList;
        putId(value: IdProperty[] | cdktn.IResolvable): void;
        resetId(): void;
        get idInput(): cdktn.IResolvable | IdProperty[] | undefined;
        private _keyword;
        get keyword(): KeywordPropertyList;
        putKeyword(value: KeywordProperty[] | cdktn.IResolvable): void;
        resetKeyword(): void;
        get keywordInput(): cdktn.IResolvable | KeywordProperty[] | undefined;
        private _lastObservedAt;
        get lastObservedAt(): LastObservedAtPropertyList;
        putLastObservedAt(value: LastObservedAtProperty[] | cdktn.IResolvable): void;
        resetLastObservedAt(): void;
        get lastObservedAtInput(): cdktn.IResolvable | LastObservedAtProperty[] | undefined;
        private _malwareName;
        get malwareName(): MalwareNamePropertyList;
        putMalwareName(value: MalwareNameProperty[] | cdktn.IResolvable): void;
        resetMalwareName(): void;
        get malwareNameInput(): cdktn.IResolvable | MalwareNameProperty[] | undefined;
        private _malwarePath;
        get malwarePath(): MalwarePathPropertyList;
        putMalwarePath(value: MalwarePathProperty[] | cdktn.IResolvable): void;
        resetMalwarePath(): void;
        get malwarePathInput(): cdktn.IResolvable | MalwarePathProperty[] | undefined;
        private _malwareState;
        get malwareState(): MalwareStatePropertyList;
        putMalwareState(value: MalwareStateProperty[] | cdktn.IResolvable): void;
        resetMalwareState(): void;
        get malwareStateInput(): cdktn.IResolvable | MalwareStateProperty[] | undefined;
        private _malwareType;
        get malwareType(): MalwareTypePropertyList;
        putMalwareType(value: MalwareTypeProperty[] | cdktn.IResolvable): void;
        resetMalwareType(): void;
        get malwareTypeInput(): cdktn.IResolvable | MalwareTypeProperty[] | undefined;
        private _networkDestinationDomain;
        get networkDestinationDomain(): NetworkDestinationDomainPropertyList;
        putNetworkDestinationDomain(value: NetworkDestinationDomainProperty[] | cdktn.IResolvable): void;
        resetNetworkDestinationDomain(): void;
        get networkDestinationDomainInput(): cdktn.IResolvable | NetworkDestinationDomainProperty[] | undefined;
        private _networkDestinationIpv4;
        get networkDestinationIpv4(): NetworkDestinationIpv4PropertyList;
        putNetworkDestinationIpv4(value: NetworkDestinationIpv4Property[] | cdktn.IResolvable): void;
        resetNetworkDestinationIpv4(): void;
        get networkDestinationIpv4Input(): cdktn.IResolvable | NetworkDestinationIpv4Property[] | undefined;
        private _networkDestinationIpv6;
        get networkDestinationIpv6(): NetworkDestinationIpv6PropertyList;
        putNetworkDestinationIpv6(value: NetworkDestinationIpv6Property[] | cdktn.IResolvable): void;
        resetNetworkDestinationIpv6(): void;
        get networkDestinationIpv6Input(): cdktn.IResolvable | NetworkDestinationIpv6Property[] | undefined;
        private _networkDestinationPort;
        get networkDestinationPort(): NetworkDestinationPortPropertyList;
        putNetworkDestinationPort(value: NetworkDestinationPortProperty[] | cdktn.IResolvable): void;
        resetNetworkDestinationPort(): void;
        get networkDestinationPortInput(): cdktn.IResolvable | NetworkDestinationPortProperty[] | undefined;
        private _networkDirection;
        get networkDirection(): NetworkDirectionPropertyList;
        putNetworkDirection(value: NetworkDirectionProperty[] | cdktn.IResolvable): void;
        resetNetworkDirection(): void;
        get networkDirectionInput(): cdktn.IResolvable | NetworkDirectionProperty[] | undefined;
        private _networkProtocol;
        get networkProtocol(): NetworkProtocolPropertyList;
        putNetworkProtocol(value: NetworkProtocolProperty[] | cdktn.IResolvable): void;
        resetNetworkProtocol(): void;
        get networkProtocolInput(): cdktn.IResolvable | NetworkProtocolProperty[] | undefined;
        private _networkSourceDomain;
        get networkSourceDomain(): NetworkSourceDomainPropertyList;
        putNetworkSourceDomain(value: NetworkSourceDomainProperty[] | cdktn.IResolvable): void;
        resetNetworkSourceDomain(): void;
        get networkSourceDomainInput(): cdktn.IResolvable | NetworkSourceDomainProperty[] | undefined;
        private _networkSourceIpv4;
        get networkSourceIpv4(): NetworkSourceIpv4PropertyList;
        putNetworkSourceIpv4(value: NetworkSourceIpv4Property[] | cdktn.IResolvable): void;
        resetNetworkSourceIpv4(): void;
        get networkSourceIpv4Input(): cdktn.IResolvable | NetworkSourceIpv4Property[] | undefined;
        private _networkSourceIpv6;
        get networkSourceIpv6(): NetworkSourceIpv6PropertyList;
        putNetworkSourceIpv6(value: NetworkSourceIpv6Property[] | cdktn.IResolvable): void;
        resetNetworkSourceIpv6(): void;
        get networkSourceIpv6Input(): cdktn.IResolvable | NetworkSourceIpv6Property[] | undefined;
        private _networkSourceMac;
        get networkSourceMac(): NetworkSourceMacPropertyList;
        putNetworkSourceMac(value: NetworkSourceMacProperty[] | cdktn.IResolvable): void;
        resetNetworkSourceMac(): void;
        get networkSourceMacInput(): cdktn.IResolvable | NetworkSourceMacProperty[] | undefined;
        private _networkSourcePort;
        get networkSourcePort(): NetworkSourcePortPropertyList;
        putNetworkSourcePort(value: NetworkSourcePortProperty[] | cdktn.IResolvable): void;
        resetNetworkSourcePort(): void;
        get networkSourcePortInput(): cdktn.IResolvable | NetworkSourcePortProperty[] | undefined;
        private _noteText;
        get noteText(): NoteTextPropertyList;
        putNoteText(value: NoteTextProperty[] | cdktn.IResolvable): void;
        resetNoteText(): void;
        get noteTextInput(): cdktn.IResolvable | NoteTextProperty[] | undefined;
        private _noteUpdatedAt;
        get noteUpdatedAt(): NoteUpdatedAtPropertyList;
        putNoteUpdatedAt(value: NoteUpdatedAtProperty[] | cdktn.IResolvable): void;
        resetNoteUpdatedAt(): void;
        get noteUpdatedAtInput(): cdktn.IResolvable | NoteUpdatedAtProperty[] | undefined;
        private _noteUpdatedBy;
        get noteUpdatedBy(): NoteUpdatedByPropertyList;
        putNoteUpdatedBy(value: NoteUpdatedByProperty[] | cdktn.IResolvable): void;
        resetNoteUpdatedBy(): void;
        get noteUpdatedByInput(): cdktn.IResolvable | NoteUpdatedByProperty[] | undefined;
        private _processLaunchedAt;
        get processLaunchedAt(): ProcessLaunchedAtPropertyList;
        putProcessLaunchedAt(value: ProcessLaunchedAtProperty[] | cdktn.IResolvable): void;
        resetProcessLaunchedAt(): void;
        get processLaunchedAtInput(): cdktn.IResolvable | ProcessLaunchedAtProperty[] | undefined;
        private _processName;
        get processName(): ProcessNamePropertyList;
        putProcessName(value: ProcessNameProperty[] | cdktn.IResolvable): void;
        resetProcessName(): void;
        get processNameInput(): cdktn.IResolvable | ProcessNameProperty[] | undefined;
        private _processParentPid;
        get processParentPid(): ProcessParentPidPropertyList;
        putProcessParentPid(value: ProcessParentPidProperty[] | cdktn.IResolvable): void;
        resetProcessParentPid(): void;
        get processParentPidInput(): cdktn.IResolvable | ProcessParentPidProperty[] | undefined;
        private _processPath;
        get processPath(): ProcessPathPropertyList;
        putProcessPath(value: ProcessPathProperty[] | cdktn.IResolvable): void;
        resetProcessPath(): void;
        get processPathInput(): cdktn.IResolvable | ProcessPathProperty[] | undefined;
        private _processPid;
        get processPid(): ProcessPidPropertyList;
        putProcessPid(value: ProcessPidProperty[] | cdktn.IResolvable): void;
        resetProcessPid(): void;
        get processPidInput(): cdktn.IResolvable | ProcessPidProperty[] | undefined;
        private _processTerminatedAt;
        get processTerminatedAt(): ProcessTerminatedAtPropertyList;
        putProcessTerminatedAt(value: ProcessTerminatedAtProperty[] | cdktn.IResolvable): void;
        resetProcessTerminatedAt(): void;
        get processTerminatedAtInput(): cdktn.IResolvable | ProcessTerminatedAtProperty[] | undefined;
        private _productArn;
        get productArn(): ProductArnPropertyList;
        putProductArn(value: ProductArnProperty[] | cdktn.IResolvable): void;
        resetProductArn(): void;
        get productArnInput(): cdktn.IResolvable | ProductArnProperty[] | undefined;
        private _productFields;
        get productFields(): ProductFieldsPropertyList;
        putProductFields(value: ProductFieldsProperty[] | cdktn.IResolvable): void;
        resetProductFields(): void;
        get productFieldsInput(): cdktn.IResolvable | ProductFieldsProperty[] | undefined;
        private _productName;
        get productName(): ProductNamePropertyList;
        putProductName(value: ProductNameProperty[] | cdktn.IResolvable): void;
        resetProductName(): void;
        get productNameInput(): cdktn.IResolvable | ProductNameProperty[] | undefined;
        private _recommendationText;
        get recommendationText(): RecommendationTextPropertyList;
        putRecommendationText(value: RecommendationTextProperty[] | cdktn.IResolvable): void;
        resetRecommendationText(): void;
        get recommendationTextInput(): cdktn.IResolvable | RecommendationTextProperty[] | undefined;
        private _recordState;
        get recordState(): RecordStatePropertyList;
        putRecordState(value: RecordStateProperty[] | cdktn.IResolvable): void;
        resetRecordState(): void;
        get recordStateInput(): cdktn.IResolvable | RecordStateProperty[] | undefined;
        private _relatedFindingsId;
        get relatedFindingsId(): RelatedFindingsIdPropertyList;
        putRelatedFindingsId(value: RelatedFindingsIdProperty[] | cdktn.IResolvable): void;
        resetRelatedFindingsId(): void;
        get relatedFindingsIdInput(): cdktn.IResolvable | RelatedFindingsIdProperty[] | undefined;
        private _relatedFindingsProductArn;
        get relatedFindingsProductArn(): RelatedFindingsProductArnPropertyList;
        putRelatedFindingsProductArn(value: RelatedFindingsProductArnProperty[] | cdktn.IResolvable): void;
        resetRelatedFindingsProductArn(): void;
        get relatedFindingsProductArnInput(): cdktn.IResolvable | RelatedFindingsProductArnProperty[] | undefined;
        private _resourceAwsEc2InstanceIamInstanceProfileArn;
        get resourceAwsEc2InstanceIamInstanceProfileArn(): ResourceAwsEc2InstanceIamInstanceProfileArnPropertyList;
        putResourceAwsEc2InstanceIamInstanceProfileArn(value: ResourceAwsEc2InstanceIamInstanceProfileArnProperty[] | cdktn.IResolvable): void;
        resetResourceAwsEc2InstanceIamInstanceProfileArn(): void;
        get resourceAwsEc2InstanceIamInstanceProfileArnInput(): cdktn.IResolvable | ResourceAwsEc2InstanceIamInstanceProfileArnProperty[] | undefined;
        private _resourceAwsEc2InstanceImageId;
        get resourceAwsEc2InstanceImageId(): ResourceAwsEc2InstanceImageIdPropertyList;
        putResourceAwsEc2InstanceImageId(value: ResourceAwsEc2InstanceImageIdProperty[] | cdktn.IResolvable): void;
        resetResourceAwsEc2InstanceImageId(): void;
        get resourceAwsEc2InstanceImageIdInput(): cdktn.IResolvable | ResourceAwsEc2InstanceImageIdProperty[] | undefined;
        private _resourceAwsEc2InstanceIpv4Addresses;
        get resourceAwsEc2InstanceIpv4Addresses(): ResourceAwsEc2InstanceIpv4AddressesPropertyList;
        putResourceAwsEc2InstanceIpv4Addresses(value: ResourceAwsEc2InstanceIpv4AddressesProperty[] | cdktn.IResolvable): void;
        resetResourceAwsEc2InstanceIpv4Addresses(): void;
        get resourceAwsEc2InstanceIpv4AddressesInput(): cdktn.IResolvable | ResourceAwsEc2InstanceIpv4AddressesProperty[] | undefined;
        private _resourceAwsEc2InstanceIpv6Addresses;
        get resourceAwsEc2InstanceIpv6Addresses(): ResourceAwsEc2InstanceIpv6AddressesPropertyList;
        putResourceAwsEc2InstanceIpv6Addresses(value: ResourceAwsEc2InstanceIpv6AddressesProperty[] | cdktn.IResolvable): void;
        resetResourceAwsEc2InstanceIpv6Addresses(): void;
        get resourceAwsEc2InstanceIpv6AddressesInput(): cdktn.IResolvable | ResourceAwsEc2InstanceIpv6AddressesProperty[] | undefined;
        private _resourceAwsEc2InstanceKeyName;
        get resourceAwsEc2InstanceKeyName(): ResourceAwsEc2InstanceKeyNamePropertyList;
        putResourceAwsEc2InstanceKeyName(value: ResourceAwsEc2InstanceKeyNameProperty[] | cdktn.IResolvable): void;
        resetResourceAwsEc2InstanceKeyName(): void;
        get resourceAwsEc2InstanceKeyNameInput(): cdktn.IResolvable | ResourceAwsEc2InstanceKeyNameProperty[] | undefined;
        private _resourceAwsEc2InstanceLaunchedAt;
        get resourceAwsEc2InstanceLaunchedAt(): ResourceAwsEc2InstanceLaunchedAtPropertyList;
        putResourceAwsEc2InstanceLaunchedAt(value: ResourceAwsEc2InstanceLaunchedAtProperty[] | cdktn.IResolvable): void;
        resetResourceAwsEc2InstanceLaunchedAt(): void;
        get resourceAwsEc2InstanceLaunchedAtInput(): cdktn.IResolvable | ResourceAwsEc2InstanceLaunchedAtProperty[] | undefined;
        private _resourceAwsEc2InstanceSubnetId;
        get resourceAwsEc2InstanceSubnetId(): ResourceAwsEc2InstanceSubnetIdPropertyList;
        putResourceAwsEc2InstanceSubnetId(value: ResourceAwsEc2InstanceSubnetIdProperty[] | cdktn.IResolvable): void;
        resetResourceAwsEc2InstanceSubnetId(): void;
        get resourceAwsEc2InstanceSubnetIdInput(): cdktn.IResolvable | ResourceAwsEc2InstanceSubnetIdProperty[] | undefined;
        private _resourceAwsEc2InstanceType;
        get resourceAwsEc2InstanceType(): ResourceAwsEc2InstanceTypePropertyList;
        putResourceAwsEc2InstanceType(value: ResourceAwsEc2InstanceTypeProperty[] | cdktn.IResolvable): void;
        resetResourceAwsEc2InstanceType(): void;
        get resourceAwsEc2InstanceTypeInput(): cdktn.IResolvable | ResourceAwsEc2InstanceTypeProperty[] | undefined;
        private _resourceAwsEc2InstanceVpcId;
        get resourceAwsEc2InstanceVpcId(): ResourceAwsEc2InstanceVpcIdPropertyList;
        putResourceAwsEc2InstanceVpcId(value: ResourceAwsEc2InstanceVpcIdProperty[] | cdktn.IResolvable): void;
        resetResourceAwsEc2InstanceVpcId(): void;
        get resourceAwsEc2InstanceVpcIdInput(): cdktn.IResolvable | ResourceAwsEc2InstanceVpcIdProperty[] | undefined;
        private _resourceAwsIamAccessKeyCreatedAt;
        get resourceAwsIamAccessKeyCreatedAt(): ResourceAwsIamAccessKeyCreatedAtPropertyList;
        putResourceAwsIamAccessKeyCreatedAt(value: ResourceAwsIamAccessKeyCreatedAtProperty[] | cdktn.IResolvable): void;
        resetResourceAwsIamAccessKeyCreatedAt(): void;
        get resourceAwsIamAccessKeyCreatedAtInput(): cdktn.IResolvable | ResourceAwsIamAccessKeyCreatedAtProperty[] | undefined;
        private _resourceAwsIamAccessKeyStatus;
        get resourceAwsIamAccessKeyStatus(): ResourceAwsIamAccessKeyStatusPropertyList;
        putResourceAwsIamAccessKeyStatus(value: ResourceAwsIamAccessKeyStatusProperty[] | cdktn.IResolvable): void;
        resetResourceAwsIamAccessKeyStatus(): void;
        get resourceAwsIamAccessKeyStatusInput(): cdktn.IResolvable | ResourceAwsIamAccessKeyStatusProperty[] | undefined;
        private _resourceAwsIamAccessKeyUserName;
        get resourceAwsIamAccessKeyUserName(): ResourceAwsIamAccessKeyUserNamePropertyList;
        putResourceAwsIamAccessKeyUserName(value: ResourceAwsIamAccessKeyUserNameProperty[] | cdktn.IResolvable): void;
        resetResourceAwsIamAccessKeyUserName(): void;
        get resourceAwsIamAccessKeyUserNameInput(): cdktn.IResolvable | ResourceAwsIamAccessKeyUserNameProperty[] | undefined;
        private _resourceAwsS3BucketOwnerId;
        get resourceAwsS3BucketOwnerId(): ResourceAwsS3BucketOwnerIdPropertyList;
        putResourceAwsS3BucketOwnerId(value: ResourceAwsS3BucketOwnerIdProperty[] | cdktn.IResolvable): void;
        resetResourceAwsS3BucketOwnerId(): void;
        get resourceAwsS3BucketOwnerIdInput(): cdktn.IResolvable | ResourceAwsS3BucketOwnerIdProperty[] | undefined;
        private _resourceAwsS3BucketOwnerName;
        get resourceAwsS3BucketOwnerName(): ResourceAwsS3BucketOwnerNamePropertyList;
        putResourceAwsS3BucketOwnerName(value: ResourceAwsS3BucketOwnerNameProperty[] | cdktn.IResolvable): void;
        resetResourceAwsS3BucketOwnerName(): void;
        get resourceAwsS3BucketOwnerNameInput(): cdktn.IResolvable | ResourceAwsS3BucketOwnerNameProperty[] | undefined;
        private _resourceContainerImageId;
        get resourceContainerImageId(): ResourceContainerImageIdPropertyList;
        putResourceContainerImageId(value: ResourceContainerImageIdProperty[] | cdktn.IResolvable): void;
        resetResourceContainerImageId(): void;
        get resourceContainerImageIdInput(): cdktn.IResolvable | ResourceContainerImageIdProperty[] | undefined;
        private _resourceContainerImageName;
        get resourceContainerImageName(): ResourceContainerImageNamePropertyList;
        putResourceContainerImageName(value: ResourceContainerImageNameProperty[] | cdktn.IResolvable): void;
        resetResourceContainerImageName(): void;
        get resourceContainerImageNameInput(): cdktn.IResolvable | ResourceContainerImageNameProperty[] | undefined;
        private _resourceContainerLaunchedAt;
        get resourceContainerLaunchedAt(): ResourceContainerLaunchedAtPropertyList;
        putResourceContainerLaunchedAt(value: ResourceContainerLaunchedAtProperty[] | cdktn.IResolvable): void;
        resetResourceContainerLaunchedAt(): void;
        get resourceContainerLaunchedAtInput(): cdktn.IResolvable | ResourceContainerLaunchedAtProperty[] | undefined;
        private _resourceContainerName;
        get resourceContainerName(): ResourceContainerNamePropertyList;
        putResourceContainerName(value: ResourceContainerNameProperty[] | cdktn.IResolvable): void;
        resetResourceContainerName(): void;
        get resourceContainerNameInput(): cdktn.IResolvable | ResourceContainerNameProperty[] | undefined;
        private _resourceDetailsOther;
        get resourceDetailsOther(): ResourceDetailsOtherPropertyList;
        putResourceDetailsOther(value: ResourceDetailsOtherProperty[] | cdktn.IResolvable): void;
        resetResourceDetailsOther(): void;
        get resourceDetailsOtherInput(): cdktn.IResolvable | ResourceDetailsOtherProperty[] | undefined;
        private _resourceId;
        get resourceId(): ResourceIdPropertyList;
        putResourceId(value: ResourceIdProperty[] | cdktn.IResolvable): void;
        resetResourceId(): void;
        get resourceIdInput(): cdktn.IResolvable | ResourceIdProperty[] | undefined;
        private _resourcePartition;
        get resourcePartition(): ResourcePartitionPropertyList;
        putResourcePartition(value: ResourcePartitionProperty[] | cdktn.IResolvable): void;
        resetResourcePartition(): void;
        get resourcePartitionInput(): cdktn.IResolvable | ResourcePartitionProperty[] | undefined;
        private _resourceRegion;
        get resourceRegion(): ResourceRegionPropertyList;
        putResourceRegion(value: ResourceRegionProperty[] | cdktn.IResolvable): void;
        resetResourceRegion(): void;
        get resourceRegionInput(): cdktn.IResolvable | ResourceRegionProperty[] | undefined;
        private _resourceTags;
        get resourceTags(): ResourceTagsPropertyList;
        putResourceTags(value: ResourceTagsProperty[] | cdktn.IResolvable): void;
        resetResourceTags(): void;
        get resourceTagsInput(): cdktn.IResolvable | ResourceTagsProperty[] | undefined;
        private _resourceType;
        get resourceType(): ResourceTypePropertyList;
        putResourceType(value: ResourceTypeProperty[] | cdktn.IResolvable): void;
        resetResourceType(): void;
        get resourceTypeInput(): cdktn.IResolvable | ResourceTypeProperty[] | undefined;
        private _severityLabel;
        get severityLabel(): SeverityLabelPropertyList;
        putSeverityLabel(value: SeverityLabelProperty[] | cdktn.IResolvable): void;
        resetSeverityLabel(): void;
        get severityLabelInput(): cdktn.IResolvable | SeverityLabelProperty[] | undefined;
        private _sourceUrl;
        get sourceUrl(): SourceUrlPropertyList;
        putSourceUrl(value: SourceUrlProperty[] | cdktn.IResolvable): void;
        resetSourceUrl(): void;
        get sourceUrlInput(): cdktn.IResolvable | SourceUrlProperty[] | undefined;
        private _threatIntelIndicatorCategory;
        get threatIntelIndicatorCategory(): ThreatIntelIndicatorCategoryPropertyList;
        putThreatIntelIndicatorCategory(value: ThreatIntelIndicatorCategoryProperty[] | cdktn.IResolvable): void;
        resetThreatIntelIndicatorCategory(): void;
        get threatIntelIndicatorCategoryInput(): cdktn.IResolvable | ThreatIntelIndicatorCategoryProperty[] | undefined;
        private _threatIntelIndicatorLastObservedAt;
        get threatIntelIndicatorLastObservedAt(): ThreatIntelIndicatorLastObservedAtPropertyList;
        putThreatIntelIndicatorLastObservedAt(value: ThreatIntelIndicatorLastObservedAtProperty[] | cdktn.IResolvable): void;
        resetThreatIntelIndicatorLastObservedAt(): void;
        get threatIntelIndicatorLastObservedAtInput(): cdktn.IResolvable | ThreatIntelIndicatorLastObservedAtProperty[] | undefined;
        private _threatIntelIndicatorSource;
        get threatIntelIndicatorSource(): ThreatIntelIndicatorSourcePropertyList;
        putThreatIntelIndicatorSource(value: ThreatIntelIndicatorSourceProperty[] | cdktn.IResolvable): void;
        resetThreatIntelIndicatorSource(): void;
        get threatIntelIndicatorSourceInput(): cdktn.IResolvable | ThreatIntelIndicatorSourceProperty[] | undefined;
        private _threatIntelIndicatorSourceUrl;
        get threatIntelIndicatorSourceUrl(): ThreatIntelIndicatorSourceUrlPropertyList;
        putThreatIntelIndicatorSourceUrl(value: ThreatIntelIndicatorSourceUrlProperty[] | cdktn.IResolvable): void;
        resetThreatIntelIndicatorSourceUrl(): void;
        get threatIntelIndicatorSourceUrlInput(): cdktn.IResolvable | ThreatIntelIndicatorSourceUrlProperty[] | undefined;
        private _threatIntelIndicatorType;
        get threatIntelIndicatorType(): ThreatIntelIndicatorTypePropertyList;
        putThreatIntelIndicatorType(value: ThreatIntelIndicatorTypeProperty[] | cdktn.IResolvable): void;
        resetThreatIntelIndicatorType(): void;
        get threatIntelIndicatorTypeInput(): cdktn.IResolvable | ThreatIntelIndicatorTypeProperty[] | undefined;
        private _threatIntelIndicatorValue;
        get threatIntelIndicatorValue(): ThreatIntelIndicatorValuePropertyList;
        putThreatIntelIndicatorValue(value: ThreatIntelIndicatorValueProperty[] | cdktn.IResolvable): void;
        resetThreatIntelIndicatorValue(): void;
        get threatIntelIndicatorValueInput(): cdktn.IResolvable | ThreatIntelIndicatorValueProperty[] | undefined;
        private _title;
        get title(): TitlePropertyList;
        putTitle(value: TitleProperty[] | cdktn.IResolvable): void;
        resetTitle(): void;
        get titleInput(): cdktn.IResolvable | TitleProperty[] | undefined;
        private _type;
        get type(): TypePropertyList;
        putType(value: TypeProperty[] | cdktn.IResolvable): void;
        resetType(): void;
        get typeInput(): cdktn.IResolvable | TypeProperty[] | undefined;
        private _updatedAt;
        get updatedAt(): UpdatedAtPropertyList;
        putUpdatedAt(value: UpdatedAtProperty[] | cdktn.IResolvable): void;
        resetUpdatedAt(): void;
        get updatedAtInput(): cdktn.IResolvable | UpdatedAtProperty[] | undefined;
        private _userDefinedValues;
        get userDefinedValues(): UserDefinedValuesPropertyList;
        putUserDefinedValues(value: UserDefinedValuesProperty[] | cdktn.IResolvable): void;
        resetUserDefinedValues(): void;
        get userDefinedValuesInput(): cdktn.IResolvable | UserDefinedValuesProperty[] | undefined;
        private _verificationState;
        get verificationState(): VerificationStatePropertyList;
        putVerificationState(value: VerificationStateProperty[] | cdktn.IResolvable): void;
        resetVerificationState(): void;
        get verificationStateInput(): cdktn.IResolvable | VerificationStateProperty[] | undefined;
        private _workflowStatus;
        get workflowStatus(): WorkflowStatusPropertyList;
        putWorkflowStatus(value: WorkflowStatusProperty[] | cdktn.IResolvable): void;
        resetWorkflowStatus(): void;
        get workflowStatusInput(): cdktn.IResolvable | WorkflowStatusProperty[] | undefined;
    }
}
