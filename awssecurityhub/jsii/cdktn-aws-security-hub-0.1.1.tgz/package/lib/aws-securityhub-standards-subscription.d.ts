import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSecurityhubStandardsSubscriptionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_standards_subscription#id AwsSecurityhubStandardsSubscription#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_standards_subscription#region AwsSecurityhubStandardsSubscription#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_standards_subscription#standards_arn AwsSecurityhubStandardsSubscription#standards_arn}
    */
    readonly standardsArn: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_standards_subscription#timeouts AwsSecurityhubStandardsSubscription#timeouts}
    */
    readonly timeouts?: AwsSecurityhubStandardsSubscription.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_standards_subscription aws_securityhub_standards_subscription}
*/
export declare class AwsSecurityhubStandardsSubscription extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_securityhub_standards_subscription";
    /**
    * Generates CDKTN code for importing a AwsSecurityhubStandardsSubscription resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSecurityhubStandardsSubscription to import
    * @param importFromId The id of the existing AwsSecurityhubStandardsSubscription that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_standards_subscription#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSecurityhubStandardsSubscription to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_standards_subscription aws_securityhub_standards_subscription} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSecurityhubStandardsSubscriptionConfig
    */
    constructor(scope: Construct, id: string, config: AwsSecurityhubStandardsSubscriptionConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _standardsArn?;
    get standardsArn(): string;
    set standardsArn(value: string);
    get standardsArnInput(): string | undefined;
    private _timeouts;
    get timeouts(): AwsSecurityhubStandardsSubscription.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsSecurityhubStandardsSubscription.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsSecurityhubStandardsSubscription.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsSecurityhubStandardsSubscriptionTimeoutsPropertyToTerraform(struct?: AwsSecurityhubStandardsSubscription.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsSecurityhubStandardsSubscriptionTimeoutsPropertyToHclTerraform(struct?: AwsSecurityhubStandardsSubscription.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsSecurityhubStandardsSubscription {
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_standards_subscription#create AwsSecurityhubStandardsSubscription#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_standards_subscription#delete AwsSecurityhubStandardsSubscription#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
