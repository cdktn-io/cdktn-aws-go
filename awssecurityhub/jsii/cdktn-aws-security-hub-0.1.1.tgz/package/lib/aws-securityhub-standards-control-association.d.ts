import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSecurityhubStandardsControlAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_standards_control_association#association_status AwsSecurityhubStandardsControlAssociation#association_status}
    */
    readonly associationStatus: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_standards_control_association#region AwsSecurityhubStandardsControlAssociation#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_standards_control_association#security_control_id AwsSecurityhubStandardsControlAssociation#security_control_id}
    */
    readonly securityControlId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_standards_control_association#standards_arn AwsSecurityhubStandardsControlAssociation#standards_arn}
    */
    readonly standardsArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_standards_control_association#updated_reason AwsSecurityhubStandardsControlAssociation#updated_reason}
    */
    readonly updatedReason?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_standards_control_association aws_securityhub_standards_control_association}
*/
export declare class AwsSecurityhubStandardsControlAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_securityhub_standards_control_association";
    /**
    * Generates CDKTN code for importing a AwsSecurityhubStandardsControlAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSecurityhubStandardsControlAssociation to import
    * @param importFromId The id of the existing AwsSecurityhubStandardsControlAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_standards_control_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSecurityhubStandardsControlAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_standards_control_association aws_securityhub_standards_control_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSecurityhubStandardsControlAssociationConfig
    */
    constructor(scope: Construct, id: string, config: AwsSecurityhubStandardsControlAssociationConfig);
    private _associationStatus?;
    get associationStatus(): string;
    set associationStatus(value: string);
    get associationStatusInput(): string | undefined;
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _securityControlId?;
    get securityControlId(): string;
    set securityControlId(value: string);
    get securityControlIdInput(): string | undefined;
    private _standardsArn?;
    get standardsArn(): string;
    set standardsArn(value: string);
    get standardsArnInput(): string | undefined;
    private _updatedReason?;
    get updatedReason(): string;
    set updatedReason(value: string);
    resetUpdatedReason(): void;
    get updatedReasonInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
