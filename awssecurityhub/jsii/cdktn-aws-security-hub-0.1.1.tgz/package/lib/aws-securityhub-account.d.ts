import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSecurityhubAccountConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_account#auto_enable_controls AwsSecurityhubAccount#auto_enable_controls}
    */
    readonly autoEnableControls?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_account#control_finding_generator AwsSecurityhubAccount#control_finding_generator}
    */
    readonly controlFindingGenerator?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_account#enable_default_standards AwsSecurityhubAccount#enable_default_standards}
    */
    readonly enableDefaultStandards?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_account#id AwsSecurityhubAccount#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_account#region AwsSecurityhubAccount#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_account aws_securityhub_account}
*/
export declare class AwsSecurityhubAccount extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_securityhub_account";
    /**
    * Generates CDKTN code for importing a AwsSecurityhubAccount resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSecurityhubAccount to import
    * @param importFromId The id of the existing AwsSecurityhubAccount that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_account#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSecurityhubAccount to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_account aws_securityhub_account} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSecurityhubAccountConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AwsSecurityhubAccountConfig);
    get arn(): string;
    private _autoEnableControls?;
    get autoEnableControls(): boolean | cdktn.IResolvable;
    set autoEnableControls(value: boolean | cdktn.IResolvable);
    resetAutoEnableControls(): void;
    get autoEnableControlsInput(): boolean | cdktn.IResolvable | undefined;
    private _controlFindingGenerator?;
    get controlFindingGenerator(): string;
    set controlFindingGenerator(value: string);
    resetControlFindingGenerator(): void;
    get controlFindingGeneratorInput(): string | undefined;
    private _enableDefaultStandards?;
    get enableDefaultStandards(): boolean | cdktn.IResolvable;
    set enableDefaultStandards(value: boolean | cdktn.IResolvable);
    resetEnableDefaultStandards(): void;
    get enableDefaultStandardsInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
