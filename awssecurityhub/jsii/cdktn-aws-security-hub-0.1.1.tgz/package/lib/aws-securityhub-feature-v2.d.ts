import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSecurityhubFeatureV2Config extends cdktn.TerraformMetaArguments {
    /**
    * The name of the opt-in feature to enable. Valid values: NETWORK_SCANNING.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_feature_v2#feature_name AwsSecurityhubFeatureV2#feature_name}
    */
    readonly featureName: string;
    /**
    * The current enablement status of the feature. Valid values: ENABLED, DISABLED.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_feature_v2#feature_status AwsSecurityhubFeatureV2#feature_status}
    */
    readonly featureStatus: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_feature_v2#region AwsSecurityhubFeatureV2#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_feature_v2 aws_securityhub_feature_v2}
*/
export declare class AwsSecurityhubFeatureV2 extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_securityhub_feature_v2";
    /**
    * Generates CDKTN code for importing a AwsSecurityhubFeatureV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSecurityhubFeatureV2 to import
    * @param importFromId The id of the existing AwsSecurityhubFeatureV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_feature_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSecurityhubFeatureV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_feature_v2 aws_securityhub_feature_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSecurityhubFeatureV2Config
    */
    constructor(scope: Construct, id: string, config: AwsSecurityhubFeatureV2Config);
    private _featureName?;
    get featureName(): string;
    set featureName(value: string);
    get featureNameInput(): string | undefined;
    private _featureStatus?;
    get featureStatus(): string;
    set featureStatus(value: string);
    get featureStatusInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
