import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDlmLifecyclePolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#default_policy AwsDlmLifecyclePolicy#default_policy}
    */
    readonly defaultPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#description AwsDlmLifecyclePolicy#description}
    */
    readonly description: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#execution_role_arn AwsDlmLifecyclePolicy#execution_role_arn}
    */
    readonly executionRoleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#id AwsDlmLifecyclePolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#region AwsDlmLifecyclePolicy#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#state AwsDlmLifecyclePolicy#state}
    */
    readonly state?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#tags AwsDlmLifecyclePolicy#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#tags_all AwsDlmLifecyclePolicy#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * policy_details block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#policy_details AwsDlmLifecyclePolicy#policy_details}
    */
    readonly policyDetails: AwsDlmLifecyclePolicy.PolicyDetailsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy aws_dlm_lifecycle_policy}
*/
export declare class AwsDlmLifecyclePolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_dlm_lifecycle_policy";
    /**
    * Generates CDKTN code for importing a AwsDlmLifecyclePolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDlmLifecyclePolicy to import
    * @param importFromId The id of the existing AwsDlmLifecyclePolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDlmLifecyclePolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy aws_dlm_lifecycle_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDlmLifecyclePolicyConfig
    */
    constructor(scope: Construct, id: string, config: AwsDlmLifecyclePolicyConfig);
    get arn(): string;
    private _defaultPolicy?;
    get defaultPolicy(): string;
    set defaultPolicy(value: string);
    resetDefaultPolicy(): void;
    get defaultPolicyInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    private _executionRoleArn?;
    get executionRoleArn(): string;
    set executionRoleArn(value: string);
    get executionRoleArnInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _policyDetails;
    get policyDetails(): AwsDlmLifecyclePolicy.PolicyDetailsPropertyOutputReference;
    putPolicyDetails(value: AwsDlmLifecyclePolicy.PolicyDetailsProperty): void;
    get policyDetailsInput(): AwsDlmLifecyclePolicy.PolicyDetailsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsDlmLifecyclePolicyEncryptionConfigurationPropertyToTerraform(struct?: AwsDlmLifecyclePolicy.EncryptionConfigurationPropertyOutputReference | AwsDlmLifecyclePolicy.EncryptionConfigurationProperty): any;
export declare function awsDlmLifecyclePolicyEncryptionConfigurationPropertyToHclTerraform(struct?: AwsDlmLifecyclePolicy.EncryptionConfigurationPropertyOutputReference | AwsDlmLifecyclePolicy.EncryptionConfigurationProperty): any;
export declare function awsDlmLifecyclePolicyPolicyDetailsActionCrossRegionCopyRetainRulePropertyToTerraform(struct?: AwsDlmLifecyclePolicy.PolicyDetailsActionCrossRegionCopyRetainRulePropertyOutputReference | AwsDlmLifecyclePolicy.PolicyDetailsActionCrossRegionCopyRetainRuleProperty): any;
export declare function awsDlmLifecyclePolicyPolicyDetailsActionCrossRegionCopyRetainRulePropertyToHclTerraform(struct?: AwsDlmLifecyclePolicy.PolicyDetailsActionCrossRegionCopyRetainRulePropertyOutputReference | AwsDlmLifecyclePolicy.PolicyDetailsActionCrossRegionCopyRetainRuleProperty): any;
export declare function awsDlmLifecyclePolicyCrossRegionCopyPropertyToTerraform(struct?: AwsDlmLifecyclePolicy.CrossRegionCopyProperty | cdktn.IResolvable): any;
export declare function awsDlmLifecyclePolicyCrossRegionCopyPropertyToHclTerraform(struct?: AwsDlmLifecyclePolicy.CrossRegionCopyProperty | cdktn.IResolvable): any;
export declare function awsDlmLifecyclePolicyActionPropertyToTerraform(struct?: AwsDlmLifecyclePolicy.ActionPropertyOutputReference | AwsDlmLifecyclePolicy.ActionProperty): any;
export declare function awsDlmLifecyclePolicyActionPropertyToHclTerraform(struct?: AwsDlmLifecyclePolicy.ActionPropertyOutputReference | AwsDlmLifecyclePolicy.ActionProperty): any;
export declare function awsDlmLifecyclePolicyPolicyDetailsEventSourceParametersPropertyToTerraform(struct?: AwsDlmLifecyclePolicy.PolicyDetailsEventSourceParametersPropertyOutputReference | AwsDlmLifecyclePolicy.PolicyDetailsEventSourceParametersProperty): any;
export declare function awsDlmLifecyclePolicyPolicyDetailsEventSourceParametersPropertyToHclTerraform(struct?: AwsDlmLifecyclePolicy.PolicyDetailsEventSourceParametersPropertyOutputReference | AwsDlmLifecyclePolicy.PolicyDetailsEventSourceParametersProperty): any;
export declare function awsDlmLifecyclePolicyEventSourcePropertyToTerraform(struct?: AwsDlmLifecyclePolicy.EventSourcePropertyOutputReference | AwsDlmLifecyclePolicy.EventSourceProperty): any;
export declare function awsDlmLifecyclePolicyEventSourcePropertyToHclTerraform(struct?: AwsDlmLifecyclePolicy.EventSourcePropertyOutputReference | AwsDlmLifecyclePolicy.EventSourceProperty): any;
export declare function awsDlmLifecyclePolicyExclusionsPropertyToTerraform(struct?: AwsDlmLifecyclePolicy.ExclusionsPropertyOutputReference | AwsDlmLifecyclePolicy.ExclusionsProperty): any;
export declare function awsDlmLifecyclePolicyExclusionsPropertyToHclTerraform(struct?: AwsDlmLifecyclePolicy.ExclusionsPropertyOutputReference | AwsDlmLifecyclePolicy.ExclusionsProperty): any;
export declare function awsDlmLifecyclePolicyPolicyDetailsParametersPropertyToTerraform(struct?: AwsDlmLifecyclePolicy.PolicyDetailsParametersPropertyOutputReference | AwsDlmLifecyclePolicy.PolicyDetailsParametersProperty): any;
export declare function awsDlmLifecyclePolicyPolicyDetailsParametersPropertyToHclTerraform(struct?: AwsDlmLifecyclePolicy.PolicyDetailsParametersPropertyOutputReference | AwsDlmLifecyclePolicy.PolicyDetailsParametersProperty): any;
export declare function awsDlmLifecyclePolicyRetentionArchiveTierPropertyToTerraform(struct?: AwsDlmLifecyclePolicy.RetentionArchiveTierPropertyOutputReference | AwsDlmLifecyclePolicy.RetentionArchiveTierProperty): any;
export declare function awsDlmLifecyclePolicyRetentionArchiveTierPropertyToHclTerraform(struct?: AwsDlmLifecyclePolicy.RetentionArchiveTierPropertyOutputReference | AwsDlmLifecyclePolicy.RetentionArchiveTierProperty): any;
export declare function awsDlmLifecyclePolicyArchiveRetainRulePropertyToTerraform(struct?: AwsDlmLifecyclePolicy.ArchiveRetainRulePropertyOutputReference | AwsDlmLifecyclePolicy.ArchiveRetainRuleProperty): any;
export declare function awsDlmLifecyclePolicyArchiveRetainRulePropertyToHclTerraform(struct?: AwsDlmLifecyclePolicy.ArchiveRetainRulePropertyOutputReference | AwsDlmLifecyclePolicy.ArchiveRetainRuleProperty): any;
export declare function awsDlmLifecyclePolicyArchiveRulePropertyToTerraform(struct?: AwsDlmLifecyclePolicy.ArchiveRulePropertyOutputReference | AwsDlmLifecyclePolicy.ArchiveRuleProperty): any;
export declare function awsDlmLifecyclePolicyArchiveRulePropertyToHclTerraform(struct?: AwsDlmLifecyclePolicy.ArchiveRulePropertyOutputReference | AwsDlmLifecyclePolicy.ArchiveRuleProperty): any;
export declare function awsDlmLifecyclePolicyScriptsPropertyToTerraform(struct?: AwsDlmLifecyclePolicy.ScriptsPropertyOutputReference | AwsDlmLifecyclePolicy.ScriptsProperty): any;
export declare function awsDlmLifecyclePolicyScriptsPropertyToHclTerraform(struct?: AwsDlmLifecyclePolicy.ScriptsPropertyOutputReference | AwsDlmLifecyclePolicy.ScriptsProperty): any;
export declare function awsDlmLifecyclePolicyCreateRulePropertyToTerraform(struct?: AwsDlmLifecyclePolicy.CreateRulePropertyOutputReference | AwsDlmLifecyclePolicy.CreateRuleProperty): any;
export declare function awsDlmLifecyclePolicyCreateRulePropertyToHclTerraform(struct?: AwsDlmLifecyclePolicy.CreateRulePropertyOutputReference | AwsDlmLifecyclePolicy.CreateRuleProperty): any;
export declare function awsDlmLifecyclePolicyPolicyDetailsScheduleCrossRegionCopyRuleDeprecateRulePropertyToTerraform(struct?: AwsDlmLifecyclePolicy.PolicyDetailsScheduleCrossRegionCopyRuleDeprecateRulePropertyOutputReference | AwsDlmLifecyclePolicy.PolicyDetailsScheduleCrossRegionCopyRuleDeprecateRuleProperty): any;
export declare function awsDlmLifecyclePolicyPolicyDetailsScheduleCrossRegionCopyRuleDeprecateRulePropertyToHclTerraform(struct?: AwsDlmLifecyclePolicy.PolicyDetailsScheduleCrossRegionCopyRuleDeprecateRulePropertyOutputReference | AwsDlmLifecyclePolicy.PolicyDetailsScheduleCrossRegionCopyRuleDeprecateRuleProperty): any;
export declare function awsDlmLifecyclePolicyPolicyDetailsScheduleCrossRegionCopyRuleRetainRulePropertyToTerraform(struct?: AwsDlmLifecyclePolicy.PolicyDetailsScheduleCrossRegionCopyRuleRetainRulePropertyOutputReference | AwsDlmLifecyclePolicy.PolicyDetailsScheduleCrossRegionCopyRuleRetainRuleProperty): any;
export declare function awsDlmLifecyclePolicyPolicyDetailsScheduleCrossRegionCopyRuleRetainRulePropertyToHclTerraform(struct?: AwsDlmLifecyclePolicy.PolicyDetailsScheduleCrossRegionCopyRuleRetainRulePropertyOutputReference | AwsDlmLifecyclePolicy.PolicyDetailsScheduleCrossRegionCopyRuleRetainRuleProperty): any;
export declare function awsDlmLifecyclePolicyCrossRegionCopyRulePropertyToTerraform(struct?: AwsDlmLifecyclePolicy.CrossRegionCopyRuleProperty | cdktn.IResolvable): any;
export declare function awsDlmLifecyclePolicyCrossRegionCopyRulePropertyToHclTerraform(struct?: AwsDlmLifecyclePolicy.CrossRegionCopyRuleProperty | cdktn.IResolvable): any;
export declare function awsDlmLifecyclePolicyPolicyDetailsScheduleDeprecateRulePropertyToTerraform(struct?: AwsDlmLifecyclePolicy.PolicyDetailsScheduleDeprecateRulePropertyOutputReference | AwsDlmLifecyclePolicy.PolicyDetailsScheduleDeprecateRuleProperty): any;
export declare function awsDlmLifecyclePolicyPolicyDetailsScheduleDeprecateRulePropertyToHclTerraform(struct?: AwsDlmLifecyclePolicy.PolicyDetailsScheduleDeprecateRulePropertyOutputReference | AwsDlmLifecyclePolicy.PolicyDetailsScheduleDeprecateRuleProperty): any;
export declare function awsDlmLifecyclePolicyFastRestoreRulePropertyToTerraform(struct?: AwsDlmLifecyclePolicy.FastRestoreRulePropertyOutputReference | AwsDlmLifecyclePolicy.FastRestoreRuleProperty): any;
export declare function awsDlmLifecyclePolicyFastRestoreRulePropertyToHclTerraform(struct?: AwsDlmLifecyclePolicy.FastRestoreRulePropertyOutputReference | AwsDlmLifecyclePolicy.FastRestoreRuleProperty): any;
export declare function awsDlmLifecyclePolicyPolicyDetailsScheduleRetainRulePropertyToTerraform(struct?: AwsDlmLifecyclePolicy.PolicyDetailsScheduleRetainRulePropertyOutputReference | AwsDlmLifecyclePolicy.PolicyDetailsScheduleRetainRuleProperty): any;
export declare function awsDlmLifecyclePolicyPolicyDetailsScheduleRetainRulePropertyToHclTerraform(struct?: AwsDlmLifecyclePolicy.PolicyDetailsScheduleRetainRulePropertyOutputReference | AwsDlmLifecyclePolicy.PolicyDetailsScheduleRetainRuleProperty): any;
export declare function awsDlmLifecyclePolicyShareRulePropertyToTerraform(struct?: AwsDlmLifecyclePolicy.ShareRulePropertyOutputReference | AwsDlmLifecyclePolicy.ShareRuleProperty): any;
export declare function awsDlmLifecyclePolicyShareRulePropertyToHclTerraform(struct?: AwsDlmLifecyclePolicy.ShareRulePropertyOutputReference | AwsDlmLifecyclePolicy.ShareRuleProperty): any;
export declare function awsDlmLifecyclePolicySchedulePropertyToTerraform(struct?: AwsDlmLifecyclePolicy.ScheduleProperty | cdktn.IResolvable): any;
export declare function awsDlmLifecyclePolicySchedulePropertyToHclTerraform(struct?: AwsDlmLifecyclePolicy.ScheduleProperty | cdktn.IResolvable): any;
export declare function awsDlmLifecyclePolicyPolicyDetailsPropertyToTerraform(struct?: AwsDlmLifecyclePolicy.PolicyDetailsPropertyOutputReference | AwsDlmLifecyclePolicy.PolicyDetailsProperty): any;
export declare function awsDlmLifecyclePolicyPolicyDetailsPropertyToHclTerraform(struct?: AwsDlmLifecyclePolicy.PolicyDetailsPropertyOutputReference | AwsDlmLifecyclePolicy.PolicyDetailsProperty): any;
export declare namespace AwsDlmLifecyclePolicy {
    interface EncryptionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#cmk_arn AwsDlmLifecyclePolicy#cmk_arn}
        */
        readonly cmkArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#encrypted AwsDlmLifecyclePolicy#encrypted}
        */
        readonly encrypted?: boolean | cdktn.IResolvable;
    }
    class EncryptionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncryptionConfigurationProperty | undefined;
        set internalValue(value: EncryptionConfigurationProperty | undefined);
        private _cmkArn?;
        get cmkArn(): string;
        set cmkArn(value: string);
        resetCmkArn(): void;
        get cmkArnInput(): string | undefined;
        private _encrypted?;
        get encrypted(): boolean | cdktn.IResolvable;
        set encrypted(value: boolean | cdktn.IResolvable);
        resetEncrypted(): void;
        get encryptedInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface PolicyDetailsActionCrossRegionCopyRetainRuleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#interval AwsDlmLifecyclePolicy#interval}
        */
        readonly interval: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#interval_unit AwsDlmLifecyclePolicy#interval_unit}
        */
        readonly intervalUnit: string;
    }
    class PolicyDetailsActionCrossRegionCopyRetainRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PolicyDetailsActionCrossRegionCopyRetainRuleProperty | undefined;
        set internalValue(value: PolicyDetailsActionCrossRegionCopyRetainRuleProperty | undefined);
        private _interval?;
        get interval(): number;
        set interval(value: number);
        get intervalInput(): number | undefined;
        private _intervalUnit?;
        get intervalUnit(): string;
        set intervalUnit(value: string);
        get intervalUnitInput(): string | undefined;
    }
    interface CrossRegionCopyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#target AwsDlmLifecyclePolicy#target}
        */
        readonly target: string;
        /**
        * encryption_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#encryption_configuration AwsDlmLifecyclePolicy#encryption_configuration}
        */
        readonly encryptionConfiguration: EncryptionConfigurationProperty;
        /**
        * retain_rule block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#retain_rule AwsDlmLifecyclePolicy#retain_rule}
        */
        readonly retainRule?: PolicyDetailsActionCrossRegionCopyRetainRuleProperty;
    }
    class CrossRegionCopyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CrossRegionCopyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CrossRegionCopyProperty | cdktn.IResolvable | undefined);
        private _target?;
        get target(): string;
        set target(value: string);
        get targetInput(): string | undefined;
        private _encryptionConfiguration;
        get encryptionConfiguration(): EncryptionConfigurationPropertyOutputReference;
        putEncryptionConfiguration(value: EncryptionConfigurationProperty): void;
        get encryptionConfigurationInput(): EncryptionConfigurationProperty | undefined;
        private _retainRule;
        get retainRule(): PolicyDetailsActionCrossRegionCopyRetainRulePropertyOutputReference;
        putRetainRule(value: PolicyDetailsActionCrossRegionCopyRetainRuleProperty): void;
        resetRetainRule(): void;
        get retainRuleInput(): PolicyDetailsActionCrossRegionCopyRetainRuleProperty | undefined;
    }
    class CrossRegionCopyPropertyList extends cdktn.ComplexList {
        internalValue?: CrossRegionCopyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CrossRegionCopyPropertyOutputReference;
    }
    interface ActionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#name AwsDlmLifecyclePolicy#name}
        */
        readonly name: string;
        /**
        * cross_region_copy block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#cross_region_copy AwsDlmLifecyclePolicy#cross_region_copy}
        */
        readonly crossRegionCopy: CrossRegionCopyProperty[] | cdktn.IResolvable;
    }
    class ActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ActionProperty | undefined;
        set internalValue(value: ActionProperty | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _crossRegionCopy;
        get crossRegionCopy(): CrossRegionCopyPropertyList;
        putCrossRegionCopy(value: CrossRegionCopyProperty[] | cdktn.IResolvable): void;
        get crossRegionCopyInput(): cdktn.IResolvable | CrossRegionCopyProperty[] | undefined;
    }
    interface PolicyDetailsEventSourceParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#description_regex AwsDlmLifecyclePolicy#description_regex}
        */
        readonly descriptionRegex: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#event_type AwsDlmLifecyclePolicy#event_type}
        */
        readonly eventType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#snapshot_owner AwsDlmLifecyclePolicy#snapshot_owner}
        */
        readonly snapshotOwner: string[];
    }
    class PolicyDetailsEventSourceParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PolicyDetailsEventSourceParametersProperty | undefined;
        set internalValue(value: PolicyDetailsEventSourceParametersProperty | undefined);
        private _descriptionRegex?;
        get descriptionRegex(): string;
        set descriptionRegex(value: string);
        get descriptionRegexInput(): string | undefined;
        private _eventType?;
        get eventType(): string;
        set eventType(value: string);
        get eventTypeInput(): string | undefined;
        private _snapshotOwner?;
        get snapshotOwner(): string[];
        set snapshotOwner(value: string[]);
        get snapshotOwnerInput(): string[] | undefined;
    }
    interface EventSourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#type AwsDlmLifecyclePolicy#type}
        */
        readonly type: string;
        /**
        * parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#parameters AwsDlmLifecyclePolicy#parameters}
        */
        readonly parameters: PolicyDetailsEventSourceParametersProperty;
    }
    class EventSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EventSourceProperty | undefined;
        set internalValue(value: EventSourceProperty | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _parameters;
        get parameters(): PolicyDetailsEventSourceParametersPropertyOutputReference;
        putParameters(value: PolicyDetailsEventSourceParametersProperty): void;
        get parametersInput(): PolicyDetailsEventSourceParametersProperty | undefined;
    }
    interface ExclusionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#exclude_boot_volumes AwsDlmLifecyclePolicy#exclude_boot_volumes}
        */
        readonly excludeBootVolumes?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#exclude_tags AwsDlmLifecyclePolicy#exclude_tags}
        */
        readonly excludeTags?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#exclude_volume_types AwsDlmLifecyclePolicy#exclude_volume_types}
        */
        readonly excludeVolumeTypes?: string[];
    }
    class ExclusionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ExclusionsProperty | undefined;
        set internalValue(value: ExclusionsProperty | undefined);
        private _excludeBootVolumes?;
        get excludeBootVolumes(): boolean | cdktn.IResolvable;
        set excludeBootVolumes(value: boolean | cdktn.IResolvable);
        resetExcludeBootVolumes(): void;
        get excludeBootVolumesInput(): boolean | cdktn.IResolvable | undefined;
        private _excludeTags?;
        get excludeTags(): {
            [key: string]: string;
        };
        set excludeTags(value: {
            [key: string]: string;
        });
        resetExcludeTags(): void;
        get excludeTagsInput(): {
            [key: string]: string;
        } | undefined;
        private _excludeVolumeTypes?;
        get excludeVolumeTypes(): string[];
        set excludeVolumeTypes(value: string[]);
        resetExcludeVolumeTypes(): void;
        get excludeVolumeTypesInput(): string[] | undefined;
    }
    interface PolicyDetailsParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#exclude_boot_volume AwsDlmLifecyclePolicy#exclude_boot_volume}
        */
        readonly excludeBootVolume?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#exclude_data_volume_tags AwsDlmLifecyclePolicy#exclude_data_volume_tags}
        */
        readonly excludeDataVolumeTags?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#no_reboot AwsDlmLifecyclePolicy#no_reboot}
        */
        readonly noReboot?: boolean | cdktn.IResolvable;
    }
    class PolicyDetailsParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PolicyDetailsParametersProperty | undefined;
        set internalValue(value: PolicyDetailsParametersProperty | undefined);
        private _excludeBootVolume?;
        get excludeBootVolume(): boolean | cdktn.IResolvable;
        set excludeBootVolume(value: boolean | cdktn.IResolvable);
        resetExcludeBootVolume(): void;
        get excludeBootVolumeInput(): boolean | cdktn.IResolvable | undefined;
        private _excludeDataVolumeTags?;
        get excludeDataVolumeTags(): {
            [key: string]: string;
        };
        set excludeDataVolumeTags(value: {
            [key: string]: string;
        });
        resetExcludeDataVolumeTags(): void;
        get excludeDataVolumeTagsInput(): {
            [key: string]: string;
        } | undefined;
        private _noReboot?;
        get noReboot(): boolean | cdktn.IResolvable;
        set noReboot(value: boolean | cdktn.IResolvable);
        resetNoReboot(): void;
        get noRebootInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface RetentionArchiveTierProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#count AwsDlmLifecyclePolicy#count}
        */
        readonly count?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#interval AwsDlmLifecyclePolicy#interval}
        */
        readonly interval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#interval_unit AwsDlmLifecyclePolicy#interval_unit}
        */
        readonly intervalUnit?: string;
    }
    class RetentionArchiveTierPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RetentionArchiveTierProperty | undefined;
        set internalValue(value: RetentionArchiveTierProperty | undefined);
        private _count?;
        get count(): number;
        set count(value: number);
        resetCount(): void;
        get countInput(): number | undefined;
        private _interval?;
        get interval(): number;
        set interval(value: number);
        resetInterval(): void;
        get intervalInput(): number | undefined;
        private _intervalUnit?;
        get intervalUnit(): string;
        set intervalUnit(value: string);
        resetIntervalUnit(): void;
        get intervalUnitInput(): string | undefined;
    }
    interface ArchiveRetainRuleProperty {
        /**
        * retention_archive_tier block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#retention_archive_tier AwsDlmLifecyclePolicy#retention_archive_tier}
        */
        readonly retentionArchiveTier: RetentionArchiveTierProperty;
    }
    class ArchiveRetainRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ArchiveRetainRuleProperty | undefined;
        set internalValue(value: ArchiveRetainRuleProperty | undefined);
        private _retentionArchiveTier;
        get retentionArchiveTier(): RetentionArchiveTierPropertyOutputReference;
        putRetentionArchiveTier(value: RetentionArchiveTierProperty): void;
        get retentionArchiveTierInput(): RetentionArchiveTierProperty | undefined;
    }
    interface ArchiveRuleProperty {
        /**
        * archive_retain_rule block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#archive_retain_rule AwsDlmLifecyclePolicy#archive_retain_rule}
        */
        readonly archiveRetainRule: ArchiveRetainRuleProperty;
    }
    class ArchiveRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ArchiveRuleProperty | undefined;
        set internalValue(value: ArchiveRuleProperty | undefined);
        private _archiveRetainRule;
        get archiveRetainRule(): ArchiveRetainRulePropertyOutputReference;
        putArchiveRetainRule(value: ArchiveRetainRuleProperty): void;
        get archiveRetainRuleInput(): ArchiveRetainRuleProperty | undefined;
    }
    interface ScriptsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#execute_operation_on_script_failure AwsDlmLifecyclePolicy#execute_operation_on_script_failure}
        */
        readonly executeOperationOnScriptFailure?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#execution_handler AwsDlmLifecyclePolicy#execution_handler}
        */
        readonly executionHandler: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#execution_handler_service AwsDlmLifecyclePolicy#execution_handler_service}
        */
        readonly executionHandlerService?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#execution_timeout AwsDlmLifecyclePolicy#execution_timeout}
        */
        readonly executionTimeout?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#maximum_retry_count AwsDlmLifecyclePolicy#maximum_retry_count}
        */
        readonly maximumRetryCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#stages AwsDlmLifecyclePolicy#stages}
        */
        readonly stages?: string[];
    }
    class ScriptsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ScriptsProperty | undefined;
        set internalValue(value: ScriptsProperty | undefined);
        private _executeOperationOnScriptFailure?;
        get executeOperationOnScriptFailure(): boolean | cdktn.IResolvable;
        set executeOperationOnScriptFailure(value: boolean | cdktn.IResolvable);
        resetExecuteOperationOnScriptFailure(): void;
        get executeOperationOnScriptFailureInput(): boolean | cdktn.IResolvable | undefined;
        private _executionHandler?;
        get executionHandler(): string;
        set executionHandler(value: string);
        get executionHandlerInput(): string | undefined;
        private _executionHandlerService?;
        get executionHandlerService(): string;
        set executionHandlerService(value: string);
        resetExecutionHandlerService(): void;
        get executionHandlerServiceInput(): string | undefined;
        private _executionTimeout?;
        get executionTimeout(): number;
        set executionTimeout(value: number);
        resetExecutionTimeout(): void;
        get executionTimeoutInput(): number | undefined;
        private _maximumRetryCount?;
        get maximumRetryCount(): number;
        set maximumRetryCount(value: number);
        resetMaximumRetryCount(): void;
        get maximumRetryCountInput(): number | undefined;
        private _stages?;
        get stages(): string[];
        set stages(value: string[]);
        resetStages(): void;
        get stagesInput(): string[] | undefined;
    }
    interface CreateRuleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#cron_expression AwsDlmLifecyclePolicy#cron_expression}
        */
        readonly cronExpression?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#interval AwsDlmLifecyclePolicy#interval}
        */
        readonly interval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#interval_unit AwsDlmLifecyclePolicy#interval_unit}
        */
        readonly intervalUnit?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#location AwsDlmLifecyclePolicy#location}
        */
        readonly location?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#times AwsDlmLifecyclePolicy#times}
        */
        readonly times?: string[];
        /**
        * scripts block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#scripts AwsDlmLifecyclePolicy#scripts}
        */
        readonly scripts?: ScriptsProperty;
    }
    class CreateRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CreateRuleProperty | undefined;
        set internalValue(value: CreateRuleProperty | undefined);
        private _cronExpression?;
        get cronExpression(): string;
        set cronExpression(value: string);
        resetCronExpression(): void;
        get cronExpressionInput(): string | undefined;
        private _interval?;
        get interval(): number;
        set interval(value: number);
        resetInterval(): void;
        get intervalInput(): number | undefined;
        private _intervalUnit?;
        get intervalUnit(): string;
        set intervalUnit(value: string);
        resetIntervalUnit(): void;
        get intervalUnitInput(): string | undefined;
        private _location?;
        get location(): string;
        set location(value: string);
        resetLocation(): void;
        get locationInput(): string | undefined;
        private _times?;
        get times(): string[];
        set times(value: string[]);
        resetTimes(): void;
        get timesInput(): string[] | undefined;
        private _scripts;
        get scripts(): ScriptsPropertyOutputReference;
        putScripts(value: ScriptsProperty): void;
        resetScripts(): void;
        get scriptsInput(): ScriptsProperty | undefined;
    }
    interface PolicyDetailsScheduleCrossRegionCopyRuleDeprecateRuleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#interval AwsDlmLifecyclePolicy#interval}
        */
        readonly interval: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#interval_unit AwsDlmLifecyclePolicy#interval_unit}
        */
        readonly intervalUnit: string;
    }
    class PolicyDetailsScheduleCrossRegionCopyRuleDeprecateRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PolicyDetailsScheduleCrossRegionCopyRuleDeprecateRuleProperty | undefined;
        set internalValue(value: PolicyDetailsScheduleCrossRegionCopyRuleDeprecateRuleProperty | undefined);
        private _interval?;
        get interval(): number;
        set interval(value: number);
        get intervalInput(): number | undefined;
        private _intervalUnit?;
        get intervalUnit(): string;
        set intervalUnit(value: string);
        get intervalUnitInput(): string | undefined;
    }
    interface PolicyDetailsScheduleCrossRegionCopyRuleRetainRuleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#interval AwsDlmLifecyclePolicy#interval}
        */
        readonly interval: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#interval_unit AwsDlmLifecyclePolicy#interval_unit}
        */
        readonly intervalUnit: string;
    }
    class PolicyDetailsScheduleCrossRegionCopyRuleRetainRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PolicyDetailsScheduleCrossRegionCopyRuleRetainRuleProperty | undefined;
        set internalValue(value: PolicyDetailsScheduleCrossRegionCopyRuleRetainRuleProperty | undefined);
        private _interval?;
        get interval(): number;
        set interval(value: number);
        get intervalInput(): number | undefined;
        private _intervalUnit?;
        get intervalUnit(): string;
        set intervalUnit(value: string);
        get intervalUnitInput(): string | undefined;
    }
    interface CrossRegionCopyRuleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#cmk_arn AwsDlmLifecyclePolicy#cmk_arn}
        */
        readonly cmkArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#copy_tags AwsDlmLifecyclePolicy#copy_tags}
        */
        readonly copyTags?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#encrypted AwsDlmLifecyclePolicy#encrypted}
        */
        readonly encrypted: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#target AwsDlmLifecyclePolicy#target}
        */
        readonly target?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#target_region AwsDlmLifecyclePolicy#target_region}
        */
        readonly targetRegion?: string;
        /**
        * deprecate_rule block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#deprecate_rule AwsDlmLifecyclePolicy#deprecate_rule}
        */
        readonly deprecateRule?: PolicyDetailsScheduleCrossRegionCopyRuleDeprecateRuleProperty;
        /**
        * retain_rule block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#retain_rule AwsDlmLifecyclePolicy#retain_rule}
        */
        readonly retainRule?: PolicyDetailsScheduleCrossRegionCopyRuleRetainRuleProperty;
    }
    class CrossRegionCopyRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CrossRegionCopyRuleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CrossRegionCopyRuleProperty | cdktn.IResolvable | undefined);
        private _cmkArn?;
        get cmkArn(): string;
        set cmkArn(value: string);
        resetCmkArn(): void;
        get cmkArnInput(): string | undefined;
        private _copyTags?;
        get copyTags(): boolean | cdktn.IResolvable;
        set copyTags(value: boolean | cdktn.IResolvable);
        resetCopyTags(): void;
        get copyTagsInput(): boolean | cdktn.IResolvable | undefined;
        private _encrypted?;
        get encrypted(): boolean | cdktn.IResolvable;
        set encrypted(value: boolean | cdktn.IResolvable);
        get encryptedInput(): boolean | cdktn.IResolvable | undefined;
        private _target?;
        get target(): string;
        set target(value: string);
        resetTarget(): void;
        get targetInput(): string | undefined;
        private _targetRegion?;
        get targetRegion(): string;
        set targetRegion(value: string);
        resetTargetRegion(): void;
        get targetRegionInput(): string | undefined;
        private _deprecateRule;
        get deprecateRule(): PolicyDetailsScheduleCrossRegionCopyRuleDeprecateRulePropertyOutputReference;
        putDeprecateRule(value: PolicyDetailsScheduleCrossRegionCopyRuleDeprecateRuleProperty): void;
        resetDeprecateRule(): void;
        get deprecateRuleInput(): PolicyDetailsScheduleCrossRegionCopyRuleDeprecateRuleProperty | undefined;
        private _retainRule;
        get retainRule(): PolicyDetailsScheduleCrossRegionCopyRuleRetainRulePropertyOutputReference;
        putRetainRule(value: PolicyDetailsScheduleCrossRegionCopyRuleRetainRuleProperty): void;
        resetRetainRule(): void;
        get retainRuleInput(): PolicyDetailsScheduleCrossRegionCopyRuleRetainRuleProperty | undefined;
    }
    class CrossRegionCopyRulePropertyList extends cdktn.ComplexList {
        internalValue?: CrossRegionCopyRuleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CrossRegionCopyRulePropertyOutputReference;
    }
    interface PolicyDetailsScheduleDeprecateRuleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#count AwsDlmLifecyclePolicy#count}
        */
        readonly count?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#interval AwsDlmLifecyclePolicy#interval}
        */
        readonly interval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#interval_unit AwsDlmLifecyclePolicy#interval_unit}
        */
        readonly intervalUnit?: string;
    }
    class PolicyDetailsScheduleDeprecateRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PolicyDetailsScheduleDeprecateRuleProperty | undefined;
        set internalValue(value: PolicyDetailsScheduleDeprecateRuleProperty | undefined);
        private _count?;
        get count(): number;
        set count(value: number);
        resetCount(): void;
        get countInput(): number | undefined;
        private _interval?;
        get interval(): number;
        set interval(value: number);
        resetInterval(): void;
        get intervalInput(): number | undefined;
        private _intervalUnit?;
        get intervalUnit(): string;
        set intervalUnit(value: string);
        resetIntervalUnit(): void;
        get intervalUnitInput(): string | undefined;
    }
    interface FastRestoreRuleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#availability_zones AwsDlmLifecyclePolicy#availability_zones}
        */
        readonly availabilityZones: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#count AwsDlmLifecyclePolicy#count}
        */
        readonly count?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#interval AwsDlmLifecyclePolicy#interval}
        */
        readonly interval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#interval_unit AwsDlmLifecyclePolicy#interval_unit}
        */
        readonly intervalUnit?: string;
    }
    class FastRestoreRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FastRestoreRuleProperty | undefined;
        set internalValue(value: FastRestoreRuleProperty | undefined);
        private _availabilityZones?;
        get availabilityZones(): string[];
        set availabilityZones(value: string[]);
        get availabilityZonesInput(): string[] | undefined;
        private _count?;
        get count(): number;
        set count(value: number);
        resetCount(): void;
        get countInput(): number | undefined;
        private _interval?;
        get interval(): number;
        set interval(value: number);
        resetInterval(): void;
        get intervalInput(): number | undefined;
        private _intervalUnit?;
        get intervalUnit(): string;
        set intervalUnit(value: string);
        resetIntervalUnit(): void;
        get intervalUnitInput(): string | undefined;
    }
    interface PolicyDetailsScheduleRetainRuleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#count AwsDlmLifecyclePolicy#count}
        */
        readonly count?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#interval AwsDlmLifecyclePolicy#interval}
        */
        readonly interval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#interval_unit AwsDlmLifecyclePolicy#interval_unit}
        */
        readonly intervalUnit?: string;
    }
    class PolicyDetailsScheduleRetainRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PolicyDetailsScheduleRetainRuleProperty | undefined;
        set internalValue(value: PolicyDetailsScheduleRetainRuleProperty | undefined);
        private _count?;
        get count(): number;
        set count(value: number);
        resetCount(): void;
        get countInput(): number | undefined;
        private _interval?;
        get interval(): number;
        set interval(value: number);
        resetInterval(): void;
        get intervalInput(): number | undefined;
        private _intervalUnit?;
        get intervalUnit(): string;
        set intervalUnit(value: string);
        resetIntervalUnit(): void;
        get intervalUnitInput(): string | undefined;
    }
    interface ShareRuleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#target_accounts AwsDlmLifecyclePolicy#target_accounts}
        */
        readonly targetAccounts: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#unshare_interval AwsDlmLifecyclePolicy#unshare_interval}
        */
        readonly unshareInterval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#unshare_interval_unit AwsDlmLifecyclePolicy#unshare_interval_unit}
        */
        readonly unshareIntervalUnit?: string;
    }
    class ShareRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ShareRuleProperty | undefined;
        set internalValue(value: ShareRuleProperty | undefined);
        private _targetAccounts?;
        get targetAccounts(): string[];
        set targetAccounts(value: string[]);
        get targetAccountsInput(): string[] | undefined;
        private _unshareInterval?;
        get unshareInterval(): number;
        set unshareInterval(value: number);
        resetUnshareInterval(): void;
        get unshareIntervalInput(): number | undefined;
        private _unshareIntervalUnit?;
        get unshareIntervalUnit(): string;
        set unshareIntervalUnit(value: string);
        resetUnshareIntervalUnit(): void;
        get unshareIntervalUnitInput(): string | undefined;
    }
    interface ScheduleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#copy_tags AwsDlmLifecyclePolicy#copy_tags}
        */
        readonly copyTags?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#name AwsDlmLifecyclePolicy#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#tags_to_add AwsDlmLifecyclePolicy#tags_to_add}
        */
        readonly tagsToAdd?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#variable_tags AwsDlmLifecyclePolicy#variable_tags}
        */
        readonly variableTags?: {
            [key: string]: string;
        };
        /**
        * archive_rule block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#archive_rule AwsDlmLifecyclePolicy#archive_rule}
        */
        readonly archiveRule?: ArchiveRuleProperty;
        /**
        * create_rule block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#create_rule AwsDlmLifecyclePolicy#create_rule}
        */
        readonly createRule: CreateRuleProperty;
        /**
        * cross_region_copy_rule block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#cross_region_copy_rule AwsDlmLifecyclePolicy#cross_region_copy_rule}
        */
        readonly crossRegionCopyRule?: CrossRegionCopyRuleProperty[] | cdktn.IResolvable;
        /**
        * deprecate_rule block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#deprecate_rule AwsDlmLifecyclePolicy#deprecate_rule}
        */
        readonly deprecateRule?: PolicyDetailsScheduleDeprecateRuleProperty;
        /**
        * fast_restore_rule block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#fast_restore_rule AwsDlmLifecyclePolicy#fast_restore_rule}
        */
        readonly fastRestoreRule?: FastRestoreRuleProperty;
        /**
        * retain_rule block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#retain_rule AwsDlmLifecyclePolicy#retain_rule}
        */
        readonly retainRule: PolicyDetailsScheduleRetainRuleProperty;
        /**
        * share_rule block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#share_rule AwsDlmLifecyclePolicy#share_rule}
        */
        readonly shareRule?: ShareRuleProperty;
    }
    class SchedulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ScheduleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ScheduleProperty | cdktn.IResolvable | undefined);
        private _copyTags?;
        get copyTags(): boolean | cdktn.IResolvable;
        set copyTags(value: boolean | cdktn.IResolvable);
        resetCopyTags(): void;
        get copyTagsInput(): boolean | cdktn.IResolvable | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _tagsToAdd?;
        get tagsToAdd(): {
            [key: string]: string;
        };
        set tagsToAdd(value: {
            [key: string]: string;
        });
        resetTagsToAdd(): void;
        get tagsToAddInput(): {
            [key: string]: string;
        } | undefined;
        private _variableTags?;
        get variableTags(): {
            [key: string]: string;
        };
        set variableTags(value: {
            [key: string]: string;
        });
        resetVariableTags(): void;
        get variableTagsInput(): {
            [key: string]: string;
        } | undefined;
        private _archiveRule;
        get archiveRule(): ArchiveRulePropertyOutputReference;
        putArchiveRule(value: ArchiveRuleProperty): void;
        resetArchiveRule(): void;
        get archiveRuleInput(): ArchiveRuleProperty | undefined;
        private _createRule;
        get createRule(): CreateRulePropertyOutputReference;
        putCreateRule(value: CreateRuleProperty): void;
        get createRuleInput(): CreateRuleProperty | undefined;
        private _crossRegionCopyRule;
        get crossRegionCopyRule(): CrossRegionCopyRulePropertyList;
        putCrossRegionCopyRule(value: CrossRegionCopyRuleProperty[] | cdktn.IResolvable): void;
        resetCrossRegionCopyRule(): void;
        get crossRegionCopyRuleInput(): cdktn.IResolvable | CrossRegionCopyRuleProperty[] | undefined;
        private _deprecateRule;
        get deprecateRule(): PolicyDetailsScheduleDeprecateRulePropertyOutputReference;
        putDeprecateRule(value: PolicyDetailsScheduleDeprecateRuleProperty): void;
        resetDeprecateRule(): void;
        get deprecateRuleInput(): PolicyDetailsScheduleDeprecateRuleProperty | undefined;
        private _fastRestoreRule;
        get fastRestoreRule(): FastRestoreRulePropertyOutputReference;
        putFastRestoreRule(value: FastRestoreRuleProperty): void;
        resetFastRestoreRule(): void;
        get fastRestoreRuleInput(): FastRestoreRuleProperty | undefined;
        private _retainRule;
        get retainRule(): PolicyDetailsScheduleRetainRulePropertyOutputReference;
        putRetainRule(value: PolicyDetailsScheduleRetainRuleProperty): void;
        get retainRuleInput(): PolicyDetailsScheduleRetainRuleProperty | undefined;
        private _shareRule;
        get shareRule(): ShareRulePropertyOutputReference;
        putShareRule(value: ShareRuleProperty): void;
        resetShareRule(): void;
        get shareRuleInput(): ShareRuleProperty | undefined;
    }
    class SchedulePropertyList extends cdktn.ComplexList {
        internalValue?: ScheduleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SchedulePropertyOutputReference;
    }
    interface PolicyDetailsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#copy_tags AwsDlmLifecyclePolicy#copy_tags}
        */
        readonly copyTags?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#create_interval AwsDlmLifecyclePolicy#create_interval}
        */
        readonly createInterval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#extend_deletion AwsDlmLifecyclePolicy#extend_deletion}
        */
        readonly extendDeletion?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#policy_language AwsDlmLifecyclePolicy#policy_language}
        */
        readonly policyLanguage?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#policy_type AwsDlmLifecyclePolicy#policy_type}
        */
        readonly policyType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#resource_locations AwsDlmLifecyclePolicy#resource_locations}
        */
        readonly resourceLocations?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#resource_type AwsDlmLifecyclePolicy#resource_type}
        */
        readonly resourceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#resource_types AwsDlmLifecyclePolicy#resource_types}
        */
        readonly resourceTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#retain_interval AwsDlmLifecyclePolicy#retain_interval}
        */
        readonly retainInterval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#target_tags AwsDlmLifecyclePolicy#target_tags}
        */
        readonly targetTags?: {
            [key: string]: string;
        };
        /**
        * action block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#action AwsDlmLifecyclePolicy#action}
        */
        readonly action?: ActionProperty;
        /**
        * event_source block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#event_source AwsDlmLifecyclePolicy#event_source}
        */
        readonly eventSource?: EventSourceProperty;
        /**
        * exclusions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#exclusions AwsDlmLifecyclePolicy#exclusions}
        */
        readonly exclusions?: ExclusionsProperty;
        /**
        * parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#parameters AwsDlmLifecyclePolicy#parameters}
        */
        readonly parameters?: PolicyDetailsParametersProperty;
        /**
        * schedule block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dlm_lifecycle_policy#schedule AwsDlmLifecyclePolicy#schedule}
        */
        readonly schedule?: ScheduleProperty[] | cdktn.IResolvable;
    }
    class PolicyDetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PolicyDetailsProperty | undefined;
        set internalValue(value: PolicyDetailsProperty | undefined);
        private _copyTags?;
        get copyTags(): boolean | cdktn.IResolvable;
        set copyTags(value: boolean | cdktn.IResolvable);
        resetCopyTags(): void;
        get copyTagsInput(): boolean | cdktn.IResolvable | undefined;
        private _createInterval?;
        get createInterval(): number;
        set createInterval(value: number);
        resetCreateInterval(): void;
        get createIntervalInput(): number | undefined;
        private _extendDeletion?;
        get extendDeletion(): boolean | cdktn.IResolvable;
        set extendDeletion(value: boolean | cdktn.IResolvable);
        resetExtendDeletion(): void;
        get extendDeletionInput(): boolean | cdktn.IResolvable | undefined;
        private _policyLanguage?;
        get policyLanguage(): string;
        set policyLanguage(value: string);
        resetPolicyLanguage(): void;
        get policyLanguageInput(): string | undefined;
        private _policyType?;
        get policyType(): string;
        set policyType(value: string);
        resetPolicyType(): void;
        get policyTypeInput(): string | undefined;
        private _resourceLocations?;
        get resourceLocations(): string[];
        set resourceLocations(value: string[]);
        resetResourceLocations(): void;
        get resourceLocationsInput(): string[] | undefined;
        private _resourceType?;
        get resourceType(): string;
        set resourceType(value: string);
        resetResourceType(): void;
        get resourceTypeInput(): string | undefined;
        private _resourceTypes?;
        get resourceTypes(): string[];
        set resourceTypes(value: string[]);
        resetResourceTypes(): void;
        get resourceTypesInput(): string[] | undefined;
        private _retainInterval?;
        get retainInterval(): number;
        set retainInterval(value: number);
        resetRetainInterval(): void;
        get retainIntervalInput(): number | undefined;
        private _targetTags?;
        get targetTags(): {
            [key: string]: string;
        };
        set targetTags(value: {
            [key: string]: string;
        });
        resetTargetTags(): void;
        get targetTagsInput(): {
            [key: string]: string;
        } | undefined;
        private _action;
        get action(): ActionPropertyOutputReference;
        putAction(value: ActionProperty): void;
        resetAction(): void;
        get actionInput(): ActionProperty | undefined;
        private _eventSource;
        get eventSource(): EventSourcePropertyOutputReference;
        putEventSource(value: EventSourceProperty): void;
        resetEventSource(): void;
        get eventSourceInput(): EventSourceProperty | undefined;
        private _exclusions;
        get exclusions(): ExclusionsPropertyOutputReference;
        putExclusions(value: ExclusionsProperty): void;
        resetExclusions(): void;
        get exclusionsInput(): ExclusionsProperty | undefined;
        private _parameters;
        get parameters(): PolicyDetailsParametersPropertyOutputReference;
        putParameters(value: PolicyDetailsParametersProperty): void;
        resetParameters(): void;
        get parametersInput(): PolicyDetailsParametersProperty | undefined;
        private _schedule;
        get schedule(): SchedulePropertyList;
        putSchedule(value: ScheduleProperty[] | cdktn.IResolvable): void;
        resetSchedule(): void;
        get scheduleInput(): cdktn.IResolvable | ScheduleProperty[] | undefined;
    }
}
