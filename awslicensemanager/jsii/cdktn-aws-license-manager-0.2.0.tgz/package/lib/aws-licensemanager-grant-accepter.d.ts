import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfGrantAccepterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Amazon Resource Name (ARN) of the grant.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/licensemanager_grant_accepter#grant_arn TfGrantAccepter#grant_arn}
    */
    readonly grantArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/licensemanager_grant_accepter#id TfGrantAccepter#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/licensemanager_grant_accepter#region TfGrantAccepter#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/licensemanager_grant_accepter aws_licensemanager_grant_accepter}
*/
export declare class TfGrantAccepter extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_licensemanager_grant_accepter";
    /**
    * Generates CDKTN code for importing a TfGrantAccepter resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfGrantAccepter to import
    * @param importFromId The id of the existing TfGrantAccepter that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/licensemanager_grant_accepter#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfGrantAccepter to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/licensemanager_grant_accepter aws_licensemanager_grant_accepter} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfGrantAccepterConfig
    */
    constructor(scope: Construct, id: string, config: TfGrantAccepterConfig);
    get allowedOperations(): string[];
    private _grantArn?;
    get grantArn(): string;
    set grantArn(value: string);
    get grantArnInput(): string | undefined;
    get homeRegion(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get licenseArn(): string;
    get name(): string;
    get parentArn(): string;
    get principal(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    get version(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
