import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfReceivedLicenseConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/licensemanager_received_license#id DataTfReceivedLicense#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/licensemanager_received_license#license_arn DataTfReceivedLicense#license_arn}
    */
    readonly licenseArn: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/licensemanager_received_license#region DataTfReceivedLicense#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/licensemanager_received_license aws_licensemanager_received_license}
*/
export declare class DataTfReceivedLicense extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_licensemanager_received_license";
    /**
    * Generates CDKTN code for importing a DataTfReceivedLicense resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfReceivedLicense to import
    * @param importFromId The id of the existing DataTfReceivedLicense that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/licensemanager_received_license#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfReceivedLicense to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/licensemanager_received_license aws_licensemanager_received_license} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfReceivedLicenseConfig
    */
    constructor(scope: Construct, id: string, config: DataTfReceivedLicenseConfig);
    get beneficiary(): string;
    private _consumptionConfiguration;
    get consumptionConfiguration(): DataTfReceivedLicense.ConsumptionConfigurationPropertyList;
    get createTime(): string;
    private _entitlements;
    get entitlements(): DataTfReceivedLicense.EntitlementsPropertyList;
    get homeRegion(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _issuer;
    get issuer(): DataTfReceivedLicense.IssuerPropertyList;
    private _licenseArn?;
    get licenseArn(): string;
    set licenseArn(value: string);
    get licenseArnInput(): string | undefined;
    private _licenseMetadata;
    get licenseMetadata(): DataTfReceivedLicense.LicenseMetadataPropertyList;
    get licenseName(): string;
    get productName(): string;
    get productSku(): string;
    private _receivedMetadata;
    get receivedMetadata(): DataTfReceivedLicense.ReceivedMetadataPropertyList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    private _validity;
    get validity(): DataTfReceivedLicense.ValidityPropertyList;
    get version(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfReceivedLicenseBorrowConfigurationPropertyToTerraform(struct?: DataTfReceivedLicense.BorrowConfigurationProperty): any;
export declare function dataTfReceivedLicenseBorrowConfigurationPropertyToHclTerraform(struct?: DataTfReceivedLicense.BorrowConfigurationProperty): any;
export declare function dataTfReceivedLicenseProvisionalConfigurationPropertyToTerraform(struct?: DataTfReceivedLicense.ProvisionalConfigurationProperty): any;
export declare function dataTfReceivedLicenseProvisionalConfigurationPropertyToHclTerraform(struct?: DataTfReceivedLicense.ProvisionalConfigurationProperty): any;
export declare function dataTfReceivedLicenseConsumptionConfigurationPropertyToTerraform(struct?: DataTfReceivedLicense.ConsumptionConfigurationProperty): any;
export declare function dataTfReceivedLicenseConsumptionConfigurationPropertyToHclTerraform(struct?: DataTfReceivedLicense.ConsumptionConfigurationProperty): any;
export declare function dataTfReceivedLicenseEntitlementsPropertyToTerraform(struct?: DataTfReceivedLicense.EntitlementsProperty): any;
export declare function dataTfReceivedLicenseEntitlementsPropertyToHclTerraform(struct?: DataTfReceivedLicense.EntitlementsProperty): any;
export declare function dataTfReceivedLicenseIssuerPropertyToTerraform(struct?: DataTfReceivedLicense.IssuerProperty): any;
export declare function dataTfReceivedLicenseIssuerPropertyToHclTerraform(struct?: DataTfReceivedLicense.IssuerProperty): any;
export declare function dataTfReceivedLicenseLicenseMetadataPropertyToTerraform(struct?: DataTfReceivedLicense.LicenseMetadataProperty): any;
export declare function dataTfReceivedLicenseLicenseMetadataPropertyToHclTerraform(struct?: DataTfReceivedLicense.LicenseMetadataProperty): any;
export declare function dataTfReceivedLicenseReceivedMetadataPropertyToTerraform(struct?: DataTfReceivedLicense.ReceivedMetadataProperty): any;
export declare function dataTfReceivedLicenseReceivedMetadataPropertyToHclTerraform(struct?: DataTfReceivedLicense.ReceivedMetadataProperty): any;
export declare function dataTfReceivedLicenseValidityPropertyToTerraform(struct?: DataTfReceivedLicense.ValidityProperty): any;
export declare function dataTfReceivedLicenseValidityPropertyToHclTerraform(struct?: DataTfReceivedLicense.ValidityProperty): any;
export declare namespace DataTfReceivedLicense {
    interface BorrowConfigurationProperty {
    }
    class BorrowConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BorrowConfigurationProperty | undefined;
        set internalValue(value: BorrowConfigurationProperty | undefined);
        get allowEarlyCheckIn(): cdktn.IResolvable;
        get maxTimeToLiveInMinutes(): number;
    }
    class BorrowConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BorrowConfigurationPropertyOutputReference;
    }
    interface ProvisionalConfigurationProperty {
    }
    class ProvisionalConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ProvisionalConfigurationProperty | undefined;
        set internalValue(value: ProvisionalConfigurationProperty | undefined);
        get maxTimeToLiveInMinutes(): number;
    }
    class ProvisionalConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ProvisionalConfigurationPropertyOutputReference;
    }
    interface ConsumptionConfigurationProperty {
    }
    class ConsumptionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConsumptionConfigurationProperty | undefined;
        set internalValue(value: ConsumptionConfigurationProperty | undefined);
        private _borrowConfiguration;
        get borrowConfiguration(): BorrowConfigurationPropertyList;
        private _provisionalConfiguration;
        get provisionalConfiguration(): ProvisionalConfigurationPropertyList;
        get renewType(): string;
    }
    class ConsumptionConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConsumptionConfigurationPropertyOutputReference;
    }
    interface EntitlementsProperty {
    }
    class EntitlementsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EntitlementsProperty | undefined;
        set internalValue(value: EntitlementsProperty | undefined);
        get allowCheckIn(): cdktn.IResolvable;
        get maxCount(): number;
        get name(): string;
        get overage(): cdktn.IResolvable;
        get unit(): string;
        get value(): string;
    }
    class EntitlementsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EntitlementsPropertyOutputReference;
    }
    interface IssuerProperty {
    }
    class IssuerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IssuerProperty | undefined;
        set internalValue(value: IssuerProperty | undefined);
        get keyFingerprint(): string;
        get name(): string;
        get signKey(): string;
    }
    class IssuerPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IssuerPropertyOutputReference;
    }
    interface LicenseMetadataProperty {
    }
    class LicenseMetadataPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LicenseMetadataProperty | undefined;
        set internalValue(value: LicenseMetadataProperty | undefined);
        get name(): string;
        get value(): string;
    }
    class LicenseMetadataPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LicenseMetadataPropertyOutputReference;
    }
    interface ReceivedMetadataProperty {
    }
    class ReceivedMetadataPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReceivedMetadataProperty | undefined;
        set internalValue(value: ReceivedMetadataProperty | undefined);
        get allowedOperations(): string[];
        get receivedStatus(): string;
        get receivedStatusReason(): string;
    }
    class ReceivedMetadataPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReceivedMetadataPropertyOutputReference;
    }
    interface ValidityProperty {
    }
    class ValidityPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ValidityProperty | undefined;
        set internalValue(value: ValidityProperty | undefined);
        get begin(): string;
        get end(): string;
    }
    class ValidityPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ValidityPropertyOutputReference;
    }
}
