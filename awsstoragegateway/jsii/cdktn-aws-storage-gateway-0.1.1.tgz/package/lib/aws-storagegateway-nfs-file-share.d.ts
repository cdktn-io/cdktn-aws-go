import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsStoragegatewayNfsFileShareConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#audit_destination_arn AwsStoragegatewayNfsFileShare#audit_destination_arn}
    */
    readonly auditDestinationArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#bucket_region AwsStoragegatewayNfsFileShare#bucket_region}
    */
    readonly bucketRegion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#client_list AwsStoragegatewayNfsFileShare#client_list}
    */
    readonly clientList: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#default_storage_class AwsStoragegatewayNfsFileShare#default_storage_class}
    */
    readonly defaultStorageClass?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#file_share_name AwsStoragegatewayNfsFileShare#file_share_name}
    */
    readonly fileShareName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#gateway_arn AwsStoragegatewayNfsFileShare#gateway_arn}
    */
    readonly gatewayArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#guess_mime_type_enabled AwsStoragegatewayNfsFileShare#guess_mime_type_enabled}
    */
    readonly guessMimeTypeEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#id AwsStoragegatewayNfsFileShare#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#kms_encrypted AwsStoragegatewayNfsFileShare#kms_encrypted}
    */
    readonly kmsEncrypted?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#kms_key_arn AwsStoragegatewayNfsFileShare#kms_key_arn}
    */
    readonly kmsKeyArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#location_arn AwsStoragegatewayNfsFileShare#location_arn}
    */
    readonly locationArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#notification_policy AwsStoragegatewayNfsFileShare#notification_policy}
    */
    readonly notificationPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#object_acl AwsStoragegatewayNfsFileShare#object_acl}
    */
    readonly objectAcl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#read_only AwsStoragegatewayNfsFileShare#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#region AwsStoragegatewayNfsFileShare#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#requester_pays AwsStoragegatewayNfsFileShare#requester_pays}
    */
    readonly requesterPays?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#role_arn AwsStoragegatewayNfsFileShare#role_arn}
    */
    readonly roleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#squash AwsStoragegatewayNfsFileShare#squash}
    */
    readonly squash?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#tags AwsStoragegatewayNfsFileShare#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#tags_all AwsStoragegatewayNfsFileShare#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#vpc_endpoint_dns_name AwsStoragegatewayNfsFileShare#vpc_endpoint_dns_name}
    */
    readonly vpcEndpointDnsName?: string;
    /**
    * cache_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#cache_attributes AwsStoragegatewayNfsFileShare#cache_attributes}
    */
    readonly cacheAttributes?: AwsStoragegatewayNfsFileShare.CacheAttributesProperty;
    /**
    * nfs_file_share_defaults block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#nfs_file_share_defaults AwsStoragegatewayNfsFileShare#nfs_file_share_defaults}
    */
    readonly nfsFileShareDefaults?: AwsStoragegatewayNfsFileShare.NfsFileShareDefaultsProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#timeouts AwsStoragegatewayNfsFileShare#timeouts}
    */
    readonly timeouts?: AwsStoragegatewayNfsFileShare.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share aws_storagegateway_nfs_file_share}
*/
export declare class AwsStoragegatewayNfsFileShare extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_storagegateway_nfs_file_share";
    /**
    * Generates CDKTN code for importing a AwsStoragegatewayNfsFileShare resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsStoragegatewayNfsFileShare to import
    * @param importFromId The id of the existing AwsStoragegatewayNfsFileShare that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsStoragegatewayNfsFileShare to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share aws_storagegateway_nfs_file_share} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsStoragegatewayNfsFileShareConfig
    */
    constructor(scope: Construct, id: string, config: AwsStoragegatewayNfsFileShareConfig);
    get arn(): string;
    private _auditDestinationArn?;
    get auditDestinationArn(): string;
    set auditDestinationArn(value: string);
    resetAuditDestinationArn(): void;
    get auditDestinationArnInput(): string | undefined;
    private _bucketRegion?;
    get bucketRegion(): string;
    set bucketRegion(value: string);
    resetBucketRegion(): void;
    get bucketRegionInput(): string | undefined;
    private _clientList?;
    get clientList(): string[];
    set clientList(value: string[]);
    get clientListInput(): string[] | undefined;
    private _defaultStorageClass?;
    get defaultStorageClass(): string;
    set defaultStorageClass(value: string);
    resetDefaultStorageClass(): void;
    get defaultStorageClassInput(): string | undefined;
    private _fileShareName?;
    get fileShareName(): string;
    set fileShareName(value: string);
    resetFileShareName(): void;
    get fileShareNameInput(): string | undefined;
    get fileshareId(): string;
    private _gatewayArn?;
    get gatewayArn(): string;
    set gatewayArn(value: string);
    get gatewayArnInput(): string | undefined;
    private _guessMimeTypeEnabled?;
    get guessMimeTypeEnabled(): boolean | cdktn.IResolvable;
    set guessMimeTypeEnabled(value: boolean | cdktn.IResolvable);
    resetGuessMimeTypeEnabled(): void;
    get guessMimeTypeEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _kmsEncrypted?;
    get kmsEncrypted(): boolean | cdktn.IResolvable;
    set kmsEncrypted(value: boolean | cdktn.IResolvable);
    resetKmsEncrypted(): void;
    get kmsEncryptedInput(): boolean | cdktn.IResolvable | undefined;
    private _kmsKeyArn?;
    get kmsKeyArn(): string;
    set kmsKeyArn(value: string);
    resetKmsKeyArn(): void;
    get kmsKeyArnInput(): string | undefined;
    private _locationArn?;
    get locationArn(): string;
    set locationArn(value: string);
    get locationArnInput(): string | undefined;
    private _notificationPolicy?;
    get notificationPolicy(): string;
    set notificationPolicy(value: string);
    resetNotificationPolicy(): void;
    get notificationPolicyInput(): string | undefined;
    private _objectAcl?;
    get objectAcl(): string;
    set objectAcl(value: string);
    resetObjectAcl(): void;
    get objectAclInput(): string | undefined;
    get path(): string;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _requesterPays?;
    get requesterPays(): boolean | cdktn.IResolvable;
    set requesterPays(value: boolean | cdktn.IResolvable);
    resetRequesterPays(): void;
    get requesterPaysInput(): boolean | cdktn.IResolvable | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    private _squash?;
    get squash(): string;
    set squash(value: string);
    resetSquash(): void;
    get squashInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _vpcEndpointDnsName?;
    get vpcEndpointDnsName(): string;
    set vpcEndpointDnsName(value: string);
    resetVpcEndpointDnsName(): void;
    get vpcEndpointDnsNameInput(): string | undefined;
    private _cacheAttributes;
    get cacheAttributes(): AwsStoragegatewayNfsFileShare.CacheAttributesPropertyOutputReference;
    putCacheAttributes(value: AwsStoragegatewayNfsFileShare.CacheAttributesProperty): void;
    resetCacheAttributes(): void;
    get cacheAttributesInput(): AwsStoragegatewayNfsFileShare.CacheAttributesProperty | undefined;
    private _nfsFileShareDefaults;
    get nfsFileShareDefaults(): AwsStoragegatewayNfsFileShare.NfsFileShareDefaultsPropertyOutputReference;
    putNfsFileShareDefaults(value: AwsStoragegatewayNfsFileShare.NfsFileShareDefaultsProperty): void;
    resetNfsFileShareDefaults(): void;
    get nfsFileShareDefaultsInput(): AwsStoragegatewayNfsFileShare.NfsFileShareDefaultsProperty | undefined;
    private _timeouts;
    get timeouts(): AwsStoragegatewayNfsFileShare.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsStoragegatewayNfsFileShare.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsStoragegatewayNfsFileShare.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsStoragegatewayNfsFileShareCacheAttributesPropertyToTerraform(struct?: AwsStoragegatewayNfsFileShare.CacheAttributesPropertyOutputReference | AwsStoragegatewayNfsFileShare.CacheAttributesProperty): any;
export declare function awsStoragegatewayNfsFileShareCacheAttributesPropertyToHclTerraform(struct?: AwsStoragegatewayNfsFileShare.CacheAttributesPropertyOutputReference | AwsStoragegatewayNfsFileShare.CacheAttributesProperty): any;
export declare function awsStoragegatewayNfsFileShareNfsFileShareDefaultsPropertyToTerraform(struct?: AwsStoragegatewayNfsFileShare.NfsFileShareDefaultsPropertyOutputReference | AwsStoragegatewayNfsFileShare.NfsFileShareDefaultsProperty): any;
export declare function awsStoragegatewayNfsFileShareNfsFileShareDefaultsPropertyToHclTerraform(struct?: AwsStoragegatewayNfsFileShare.NfsFileShareDefaultsPropertyOutputReference | AwsStoragegatewayNfsFileShare.NfsFileShareDefaultsProperty): any;
export declare function awsStoragegatewayNfsFileShareTimeoutsPropertyToTerraform(struct?: AwsStoragegatewayNfsFileShare.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsStoragegatewayNfsFileShareTimeoutsPropertyToHclTerraform(struct?: AwsStoragegatewayNfsFileShare.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsStoragegatewayNfsFileShare {
    interface CacheAttributesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#cache_stale_timeout_in_seconds AwsStoragegatewayNfsFileShare#cache_stale_timeout_in_seconds}
        */
        readonly cacheStaleTimeoutInSeconds?: number;
    }
    class CacheAttributesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CacheAttributesProperty | undefined;
        set internalValue(value: CacheAttributesProperty | undefined);
        private _cacheStaleTimeoutInSeconds?;
        get cacheStaleTimeoutInSeconds(): number;
        set cacheStaleTimeoutInSeconds(value: number);
        resetCacheStaleTimeoutInSeconds(): void;
        get cacheStaleTimeoutInSecondsInput(): number | undefined;
    }
    interface NfsFileShareDefaultsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#directory_mode AwsStoragegatewayNfsFileShare#directory_mode}
        */
        readonly directoryMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#file_mode AwsStoragegatewayNfsFileShare#file_mode}
        */
        readonly fileMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#group_id AwsStoragegatewayNfsFileShare#group_id}
        */
        readonly groupId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#owner_id AwsStoragegatewayNfsFileShare#owner_id}
        */
        readonly ownerId?: string;
    }
    class NfsFileShareDefaultsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NfsFileShareDefaultsProperty | undefined;
        set internalValue(value: NfsFileShareDefaultsProperty | undefined);
        private _directoryMode?;
        get directoryMode(): string;
        set directoryMode(value: string);
        resetDirectoryMode(): void;
        get directoryModeInput(): string | undefined;
        private _fileMode?;
        get fileMode(): string;
        set fileMode(value: string);
        resetFileMode(): void;
        get fileModeInput(): string | undefined;
        private _groupId?;
        get groupId(): string;
        set groupId(value: string);
        resetGroupId(): void;
        get groupIdInput(): string | undefined;
        private _ownerId?;
        get ownerId(): string;
        set ownerId(value: string);
        resetOwnerId(): void;
        get ownerIdInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#create AwsStoragegatewayNfsFileShare#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#delete AwsStoragegatewayNfsFileShare#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#update AwsStoragegatewayNfsFileShare#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
