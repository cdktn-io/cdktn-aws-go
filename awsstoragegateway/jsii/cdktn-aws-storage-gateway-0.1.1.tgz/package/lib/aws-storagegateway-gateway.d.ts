import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsStoragegatewayGatewayConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_gateway#activation_key AwsStoragegatewayGateway#activation_key}
    */
    readonly activationKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_gateway#average_download_rate_limit_in_bits_per_sec AwsStoragegatewayGateway#average_download_rate_limit_in_bits_per_sec}
    */
    readonly averageDownloadRateLimitInBitsPerSec?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_gateway#average_upload_rate_limit_in_bits_per_sec AwsStoragegatewayGateway#average_upload_rate_limit_in_bits_per_sec}
    */
    readonly averageUploadRateLimitInBitsPerSec?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_gateway#cloudwatch_log_group_arn AwsStoragegatewayGateway#cloudwatch_log_group_arn}
    */
    readonly cloudwatchLogGroupArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_gateway#gateway_ip_address AwsStoragegatewayGateway#gateway_ip_address}
    */
    readonly gatewayIpAddress?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_gateway#gateway_name AwsStoragegatewayGateway#gateway_name}
    */
    readonly gatewayName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_gateway#gateway_timezone AwsStoragegatewayGateway#gateway_timezone}
    */
    readonly gatewayTimezone: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_gateway#gateway_type AwsStoragegatewayGateway#gateway_type}
    */
    readonly gatewayType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_gateway#gateway_vpc_endpoint AwsStoragegatewayGateway#gateway_vpc_endpoint}
    */
    readonly gatewayVpcEndpoint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_gateway#id AwsStoragegatewayGateway#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_gateway#medium_changer_type AwsStoragegatewayGateway#medium_changer_type}
    */
    readonly mediumChangerType?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_gateway#region AwsStoragegatewayGateway#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_gateway#smb_file_share_visibility AwsStoragegatewayGateway#smb_file_share_visibility}
    */
    readonly smbFileShareVisibility?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_gateway#smb_guest_password AwsStoragegatewayGateway#smb_guest_password}
    */
    readonly smbGuestPassword?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_gateway#smb_security_strategy AwsStoragegatewayGateway#smb_security_strategy}
    */
    readonly smbSecurityStrategy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_gateway#tags AwsStoragegatewayGateway#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_gateway#tags_all AwsStoragegatewayGateway#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_gateway#tape_drive_type AwsStoragegatewayGateway#tape_drive_type}
    */
    readonly tapeDriveType?: string;
    /**
    * maintenance_start_time block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_gateway#maintenance_start_time AwsStoragegatewayGateway#maintenance_start_time}
    */
    readonly maintenanceStartTime?: AwsStoragegatewayGateway.MaintenanceStartTimeProperty;
    /**
    * smb_active_directory_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_gateway#smb_active_directory_settings AwsStoragegatewayGateway#smb_active_directory_settings}
    */
    readonly smbActiveDirectorySettings?: AwsStoragegatewayGateway.SmbActiveDirectorySettingsProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_gateway#timeouts AwsStoragegatewayGateway#timeouts}
    */
    readonly timeouts?: AwsStoragegatewayGateway.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_gateway aws_storagegateway_gateway}
*/
export declare class AwsStoragegatewayGateway extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_storagegateway_gateway";
    /**
    * Generates CDKTN code for importing a AwsStoragegatewayGateway resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsStoragegatewayGateway to import
    * @param importFromId The id of the existing AwsStoragegatewayGateway that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_gateway#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsStoragegatewayGateway to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_gateway aws_storagegateway_gateway} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsStoragegatewayGatewayConfig
    */
    constructor(scope: Construct, id: string, config: AwsStoragegatewayGatewayConfig);
    private _activationKey?;
    get activationKey(): string;
    set activationKey(value: string);
    resetActivationKey(): void;
    get activationKeyInput(): string | undefined;
    get arn(): string;
    private _averageDownloadRateLimitInBitsPerSec?;
    get averageDownloadRateLimitInBitsPerSec(): number;
    set averageDownloadRateLimitInBitsPerSec(value: number);
    resetAverageDownloadRateLimitInBitsPerSec(): void;
    get averageDownloadRateLimitInBitsPerSecInput(): number | undefined;
    private _averageUploadRateLimitInBitsPerSec?;
    get averageUploadRateLimitInBitsPerSec(): number;
    set averageUploadRateLimitInBitsPerSec(value: number);
    resetAverageUploadRateLimitInBitsPerSec(): void;
    get averageUploadRateLimitInBitsPerSecInput(): number | undefined;
    private _cloudwatchLogGroupArn?;
    get cloudwatchLogGroupArn(): string;
    set cloudwatchLogGroupArn(value: string);
    resetCloudwatchLogGroupArn(): void;
    get cloudwatchLogGroupArnInput(): string | undefined;
    get ec2InstanceId(): string;
    get endpointType(): string;
    get gatewayId(): string;
    private _gatewayIpAddress?;
    get gatewayIpAddress(): string;
    set gatewayIpAddress(value: string);
    resetGatewayIpAddress(): void;
    get gatewayIpAddressInput(): string | undefined;
    private _gatewayName?;
    get gatewayName(): string;
    set gatewayName(value: string);
    get gatewayNameInput(): string | undefined;
    private _gatewayNetworkInterface;
    get gatewayNetworkInterface(): AwsStoragegatewayGateway.GatewayNetworkInterfacePropertyList;
    private _gatewayTimezone?;
    get gatewayTimezone(): string;
    set gatewayTimezone(value: string);
    get gatewayTimezoneInput(): string | undefined;
    private _gatewayType?;
    get gatewayType(): string;
    set gatewayType(value: string);
    resetGatewayType(): void;
    get gatewayTypeInput(): string | undefined;
    private _gatewayVpcEndpoint?;
    get gatewayVpcEndpoint(): string;
    set gatewayVpcEndpoint(value: string);
    resetGatewayVpcEndpoint(): void;
    get gatewayVpcEndpointInput(): string | undefined;
    get hostEnvironment(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _mediumChangerType?;
    get mediumChangerType(): string;
    set mediumChangerType(value: string);
    resetMediumChangerType(): void;
    get mediumChangerTypeInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _smbFileShareVisibility?;
    get smbFileShareVisibility(): boolean | cdktn.IResolvable;
    set smbFileShareVisibility(value: boolean | cdktn.IResolvable);
    resetSmbFileShareVisibility(): void;
    get smbFileShareVisibilityInput(): boolean | cdktn.IResolvable | undefined;
    private _smbGuestPassword?;
    get smbGuestPassword(): string;
    set smbGuestPassword(value: string);
    resetSmbGuestPassword(): void;
    get smbGuestPasswordInput(): string | undefined;
    private _smbSecurityStrategy?;
    get smbSecurityStrategy(): string;
    set smbSecurityStrategy(value: string);
    resetSmbSecurityStrategy(): void;
    get smbSecurityStrategyInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _tapeDriveType?;
    get tapeDriveType(): string;
    set tapeDriveType(value: string);
    resetTapeDriveType(): void;
    get tapeDriveTypeInput(): string | undefined;
    private _maintenanceStartTime;
    get maintenanceStartTime(): AwsStoragegatewayGateway.MaintenanceStartTimePropertyOutputReference;
    putMaintenanceStartTime(value: AwsStoragegatewayGateway.MaintenanceStartTimeProperty): void;
    resetMaintenanceStartTime(): void;
    get maintenanceStartTimeInput(): AwsStoragegatewayGateway.MaintenanceStartTimeProperty | undefined;
    private _smbActiveDirectorySettings;
    get smbActiveDirectorySettings(): AwsStoragegatewayGateway.SmbActiveDirectorySettingsPropertyOutputReference;
    putSmbActiveDirectorySettings(value: AwsStoragegatewayGateway.SmbActiveDirectorySettingsProperty): void;
    resetSmbActiveDirectorySettings(): void;
    get smbActiveDirectorySettingsInput(): AwsStoragegatewayGateway.SmbActiveDirectorySettingsProperty | undefined;
    private _timeouts;
    get timeouts(): AwsStoragegatewayGateway.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsStoragegatewayGateway.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsStoragegatewayGateway.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsStoragegatewayGatewayGatewayNetworkInterfacePropertyToTerraform(struct?: AwsStoragegatewayGateway.GatewayNetworkInterfaceProperty): any;
export declare function awsStoragegatewayGatewayGatewayNetworkInterfacePropertyToHclTerraform(struct?: AwsStoragegatewayGateway.GatewayNetworkInterfaceProperty): any;
export declare function awsStoragegatewayGatewayMaintenanceStartTimePropertyToTerraform(struct?: AwsStoragegatewayGateway.MaintenanceStartTimePropertyOutputReference | AwsStoragegatewayGateway.MaintenanceStartTimeProperty): any;
export declare function awsStoragegatewayGatewayMaintenanceStartTimePropertyToHclTerraform(struct?: AwsStoragegatewayGateway.MaintenanceStartTimePropertyOutputReference | AwsStoragegatewayGateway.MaintenanceStartTimeProperty): any;
export declare function awsStoragegatewayGatewaySmbActiveDirectorySettingsPropertyToTerraform(struct?: AwsStoragegatewayGateway.SmbActiveDirectorySettingsPropertyOutputReference | AwsStoragegatewayGateway.SmbActiveDirectorySettingsProperty): any;
export declare function awsStoragegatewayGatewaySmbActiveDirectorySettingsPropertyToHclTerraform(struct?: AwsStoragegatewayGateway.SmbActiveDirectorySettingsPropertyOutputReference | AwsStoragegatewayGateway.SmbActiveDirectorySettingsProperty): any;
export declare function awsStoragegatewayGatewayTimeoutsPropertyToTerraform(struct?: AwsStoragegatewayGateway.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsStoragegatewayGatewayTimeoutsPropertyToHclTerraform(struct?: AwsStoragegatewayGateway.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsStoragegatewayGateway {
    interface GatewayNetworkInterfaceProperty {
    }
    class GatewayNetworkInterfacePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GatewayNetworkInterfaceProperty | undefined;
        set internalValue(value: GatewayNetworkInterfaceProperty | undefined);
        get ipv4Address(): string;
    }
    class GatewayNetworkInterfacePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GatewayNetworkInterfacePropertyOutputReference;
    }
    interface MaintenanceStartTimeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_gateway#day_of_month AwsStoragegatewayGateway#day_of_month}
        */
        readonly dayOfMonth?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_gateway#day_of_week AwsStoragegatewayGateway#day_of_week}
        */
        readonly dayOfWeek?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_gateway#hour_of_day AwsStoragegatewayGateway#hour_of_day}
        */
        readonly hourOfDay: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_gateway#minute_of_hour AwsStoragegatewayGateway#minute_of_hour}
        */
        readonly minuteOfHour?: number;
    }
    class MaintenanceStartTimePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MaintenanceStartTimeProperty | undefined;
        set internalValue(value: MaintenanceStartTimeProperty | undefined);
        private _dayOfMonth?;
        get dayOfMonth(): string;
        set dayOfMonth(value: string);
        resetDayOfMonth(): void;
        get dayOfMonthInput(): string | undefined;
        private _dayOfWeek?;
        get dayOfWeek(): string;
        set dayOfWeek(value: string);
        resetDayOfWeek(): void;
        get dayOfWeekInput(): string | undefined;
        private _hourOfDay?;
        get hourOfDay(): number;
        set hourOfDay(value: number);
        get hourOfDayInput(): number | undefined;
        private _minuteOfHour?;
        get minuteOfHour(): number;
        set minuteOfHour(value: number);
        resetMinuteOfHour(): void;
        get minuteOfHourInput(): number | undefined;
    }
    interface SmbActiveDirectorySettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_gateway#domain_controllers AwsStoragegatewayGateway#domain_controllers}
        */
        readonly domainControllers?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_gateway#domain_name AwsStoragegatewayGateway#domain_name}
        */
        readonly domainName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_gateway#organizational_unit AwsStoragegatewayGateway#organizational_unit}
        */
        readonly organizationalUnit?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_gateway#password AwsStoragegatewayGateway#password}
        */
        readonly password: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_gateway#timeout_in_seconds AwsStoragegatewayGateway#timeout_in_seconds}
        */
        readonly timeoutInSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_gateway#username AwsStoragegatewayGateway#username}
        */
        readonly username: string;
    }
    class SmbActiveDirectorySettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SmbActiveDirectorySettingsProperty | undefined;
        set internalValue(value: SmbActiveDirectorySettingsProperty | undefined);
        get activeDirectoryStatus(): string;
        private _domainControllers?;
        get domainControllers(): string[];
        set domainControllers(value: string[]);
        resetDomainControllers(): void;
        get domainControllersInput(): string[] | undefined;
        private _domainName?;
        get domainName(): string;
        set domainName(value: string);
        get domainNameInput(): string | undefined;
        private _organizationalUnit?;
        get organizationalUnit(): string;
        set organizationalUnit(value: string);
        resetOrganizationalUnit(): void;
        get organizationalUnitInput(): string | undefined;
        private _password?;
        get password(): string;
        set password(value: string);
        get passwordInput(): string | undefined;
        private _timeoutInSeconds?;
        get timeoutInSeconds(): number;
        set timeoutInSeconds(value: number);
        resetTimeoutInSeconds(): void;
        get timeoutInSecondsInput(): number | undefined;
        private _username?;
        get username(): string;
        set username(value: string);
        get usernameInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_gateway#create AwsStoragegatewayGateway#create}
        */
        readonly create?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
    }
}
