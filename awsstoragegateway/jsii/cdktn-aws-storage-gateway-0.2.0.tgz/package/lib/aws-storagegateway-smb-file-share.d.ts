import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfSmbFileShareConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_smb_file_share#access_based_enumeration TfSmbFileShare#access_based_enumeration}
    */
    readonly accessBasedEnumeration?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_smb_file_share#admin_user_list TfSmbFileShare#admin_user_list}
    */
    readonly adminUserList?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_smb_file_share#audit_destination_arn TfSmbFileShare#audit_destination_arn}
    */
    readonly auditDestinationArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_smb_file_share#authentication TfSmbFileShare#authentication}
    */
    readonly authentication?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_smb_file_share#bucket_region TfSmbFileShare#bucket_region}
    */
    readonly bucketRegion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_smb_file_share#case_sensitivity TfSmbFileShare#case_sensitivity}
    */
    readonly caseSensitivity?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_smb_file_share#default_storage_class TfSmbFileShare#default_storage_class}
    */
    readonly defaultStorageClass?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_smb_file_share#file_share_name TfSmbFileShare#file_share_name}
    */
    readonly fileShareName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_smb_file_share#gateway_arn TfSmbFileShare#gateway_arn}
    */
    readonly gatewayArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_smb_file_share#guess_mime_type_enabled TfSmbFileShare#guess_mime_type_enabled}
    */
    readonly guessMimeTypeEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_smb_file_share#id TfSmbFileShare#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_smb_file_share#invalid_user_list TfSmbFileShare#invalid_user_list}
    */
    readonly invalidUserList?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_smb_file_share#kms_encrypted TfSmbFileShare#kms_encrypted}
    */
    readonly kmsEncrypted?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_smb_file_share#kms_key_arn TfSmbFileShare#kms_key_arn}
    */
    readonly kmsKeyArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_smb_file_share#location_arn TfSmbFileShare#location_arn}
    */
    readonly locationArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_smb_file_share#notification_policy TfSmbFileShare#notification_policy}
    */
    readonly notificationPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_smb_file_share#object_acl TfSmbFileShare#object_acl}
    */
    readonly objectAcl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_smb_file_share#oplocks_enabled TfSmbFileShare#oplocks_enabled}
    */
    readonly oplocksEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_smb_file_share#read_only TfSmbFileShare#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_smb_file_share#region TfSmbFileShare#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_smb_file_share#requester_pays TfSmbFileShare#requester_pays}
    */
    readonly requesterPays?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_smb_file_share#role_arn TfSmbFileShare#role_arn}
    */
    readonly roleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_smb_file_share#smb_acl_enabled TfSmbFileShare#smb_acl_enabled}
    */
    readonly smbAclEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_smb_file_share#tags TfSmbFileShare#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_smb_file_share#tags_all TfSmbFileShare#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_smb_file_share#valid_user_list TfSmbFileShare#valid_user_list}
    */
    readonly validUserList?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_smb_file_share#vpc_endpoint_dns_name TfSmbFileShare#vpc_endpoint_dns_name}
    */
    readonly vpcEndpointDnsName?: string;
    /**
    * cache_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_smb_file_share#cache_attributes TfSmbFileShare#cache_attributes}
    */
    readonly cacheAttributes?: TfSmbFileShare.CacheAttributesProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_smb_file_share#timeouts TfSmbFileShare#timeouts}
    */
    readonly timeouts?: TfSmbFileShare.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_smb_file_share aws_storagegateway_smb_file_share}
*/
export declare class TfSmbFileShare extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_storagegateway_smb_file_share";
    /**
    * Generates CDKTN code for importing a TfSmbFileShare resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfSmbFileShare to import
    * @param importFromId The id of the existing TfSmbFileShare that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_smb_file_share#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfSmbFileShare to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_smb_file_share aws_storagegateway_smb_file_share} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfSmbFileShareConfig
    */
    constructor(scope: Construct, id: string, config: TfSmbFileShareConfig);
    private _accessBasedEnumeration?;
    get accessBasedEnumeration(): boolean | cdktn.IResolvable;
    set accessBasedEnumeration(value: boolean | cdktn.IResolvable);
    resetAccessBasedEnumeration(): void;
    get accessBasedEnumerationInput(): boolean | cdktn.IResolvable | undefined;
    private _adminUserList?;
    get adminUserList(): string[];
    set adminUserList(value: string[]);
    resetAdminUserList(): void;
    get adminUserListInput(): string[] | undefined;
    get arn(): string;
    private _auditDestinationArn?;
    get auditDestinationArn(): string;
    set auditDestinationArn(value: string);
    resetAuditDestinationArn(): void;
    get auditDestinationArnInput(): string | undefined;
    private _authentication?;
    get authentication(): string;
    set authentication(value: string);
    resetAuthentication(): void;
    get authenticationInput(): string | undefined;
    private _bucketRegion?;
    get bucketRegion(): string;
    set bucketRegion(value: string);
    resetBucketRegion(): void;
    get bucketRegionInput(): string | undefined;
    private _caseSensitivity?;
    get caseSensitivity(): string;
    set caseSensitivity(value: string);
    resetCaseSensitivity(): void;
    get caseSensitivityInput(): string | undefined;
    private _defaultStorageClass?;
    get defaultStorageClass(): string;
    set defaultStorageClass(value: string);
    resetDefaultStorageClass(): void;
    get defaultStorageClassInput(): string | undefined;
    private _fileShareName?;
    get fileShareName(): string;
    set fileShareName(value: string);
    resetFileShareName(): void;
    get fileShareNameInput(): string | undefined;
    get fileshareId(): string;
    private _gatewayArn?;
    get gatewayArn(): string;
    set gatewayArn(value: string);
    get gatewayArnInput(): string | undefined;
    private _guessMimeTypeEnabled?;
    get guessMimeTypeEnabled(): boolean | cdktn.IResolvable;
    set guessMimeTypeEnabled(value: boolean | cdktn.IResolvable);
    resetGuessMimeTypeEnabled(): void;
    get guessMimeTypeEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _invalidUserList?;
    get invalidUserList(): string[];
    set invalidUserList(value: string[]);
    resetInvalidUserList(): void;
    get invalidUserListInput(): string[] | undefined;
    private _kmsEncrypted?;
    get kmsEncrypted(): boolean | cdktn.IResolvable;
    set kmsEncrypted(value: boolean | cdktn.IResolvable);
    resetKmsEncrypted(): void;
    get kmsEncryptedInput(): boolean | cdktn.IResolvable | undefined;
    private _kmsKeyArn?;
    get kmsKeyArn(): string;
    set kmsKeyArn(value: string);
    resetKmsKeyArn(): void;
    get kmsKeyArnInput(): string | undefined;
    private _locationArn?;
    get locationArn(): string;
    set locationArn(value: string);
    get locationArnInput(): string | undefined;
    private _notificationPolicy?;
    get notificationPolicy(): string;
    set notificationPolicy(value: string);
    resetNotificationPolicy(): void;
    get notificationPolicyInput(): string | undefined;
    private _objectAcl?;
    get objectAcl(): string;
    set objectAcl(value: string);
    resetObjectAcl(): void;
    get objectAclInput(): string | undefined;
    private _oplocksEnabled?;
    get oplocksEnabled(): boolean | cdktn.IResolvable;
    set oplocksEnabled(value: boolean | cdktn.IResolvable);
    resetOplocksEnabled(): void;
    get oplocksEnabledInput(): boolean | cdktn.IResolvable | undefined;
    get path(): string;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _requesterPays?;
    get requesterPays(): boolean | cdktn.IResolvable;
    set requesterPays(value: boolean | cdktn.IResolvable);
    resetRequesterPays(): void;
    get requesterPaysInput(): boolean | cdktn.IResolvable | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    private _smbAclEnabled?;
    get smbAclEnabled(): boolean | cdktn.IResolvable;
    set smbAclEnabled(value: boolean | cdktn.IResolvable);
    resetSmbAclEnabled(): void;
    get smbAclEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _validUserList?;
    get validUserList(): string[];
    set validUserList(value: string[]);
    resetValidUserList(): void;
    get validUserListInput(): string[] | undefined;
    private _vpcEndpointDnsName?;
    get vpcEndpointDnsName(): string;
    set vpcEndpointDnsName(value: string);
    resetVpcEndpointDnsName(): void;
    get vpcEndpointDnsNameInput(): string | undefined;
    private _cacheAttributes;
    get cacheAttributes(): TfSmbFileShare.CacheAttributesPropertyOutputReference;
    putCacheAttributes(value: TfSmbFileShare.CacheAttributesProperty): void;
    resetCacheAttributes(): void;
    get cacheAttributesInput(): TfSmbFileShare.CacheAttributesProperty | undefined;
    private _timeouts;
    get timeouts(): TfSmbFileShare.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfSmbFileShare.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfSmbFileShare.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfSmbFileShareCacheAttributesPropertyToTerraform(struct?: TfSmbFileShare.CacheAttributesPropertyOutputReference | TfSmbFileShare.CacheAttributesProperty): any;
export declare function tfSmbFileShareCacheAttributesPropertyToHclTerraform(struct?: TfSmbFileShare.CacheAttributesPropertyOutputReference | TfSmbFileShare.CacheAttributesProperty): any;
export declare function tfSmbFileShareTimeoutsPropertyToTerraform(struct?: TfSmbFileShare.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfSmbFileShareTimeoutsPropertyToHclTerraform(struct?: TfSmbFileShare.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfSmbFileShare {
    interface CacheAttributesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_smb_file_share#cache_stale_timeout_in_seconds TfSmbFileShare#cache_stale_timeout_in_seconds}
        */
        readonly cacheStaleTimeoutInSeconds?: number;
    }
    class CacheAttributesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CacheAttributesProperty | undefined;
        set internalValue(value: CacheAttributesProperty | undefined);
        private _cacheStaleTimeoutInSeconds?;
        get cacheStaleTimeoutInSeconds(): number;
        set cacheStaleTimeoutInSeconds(value: number);
        resetCacheStaleTimeoutInSeconds(): void;
        get cacheStaleTimeoutInSecondsInput(): number | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_smb_file_share#create TfSmbFileShare#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_smb_file_share#delete TfSmbFileShare#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_smb_file_share#update TfSmbFileShare#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
