import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfNfsFileShareConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#audit_destination_arn TfNfsFileShare#audit_destination_arn}
    */
    readonly auditDestinationArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#bucket_region TfNfsFileShare#bucket_region}
    */
    readonly bucketRegion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#client_list TfNfsFileShare#client_list}
    */
    readonly clientList: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#default_storage_class TfNfsFileShare#default_storage_class}
    */
    readonly defaultStorageClass?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#file_share_name TfNfsFileShare#file_share_name}
    */
    readonly fileShareName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#gateway_arn TfNfsFileShare#gateway_arn}
    */
    readonly gatewayArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#guess_mime_type_enabled TfNfsFileShare#guess_mime_type_enabled}
    */
    readonly guessMimeTypeEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#id TfNfsFileShare#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#kms_encrypted TfNfsFileShare#kms_encrypted}
    */
    readonly kmsEncrypted?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#kms_key_arn TfNfsFileShare#kms_key_arn}
    */
    readonly kmsKeyArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#location_arn TfNfsFileShare#location_arn}
    */
    readonly locationArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#notification_policy TfNfsFileShare#notification_policy}
    */
    readonly notificationPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#object_acl TfNfsFileShare#object_acl}
    */
    readonly objectAcl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#read_only TfNfsFileShare#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#region TfNfsFileShare#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#requester_pays TfNfsFileShare#requester_pays}
    */
    readonly requesterPays?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#role_arn TfNfsFileShare#role_arn}
    */
    readonly roleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#squash TfNfsFileShare#squash}
    */
    readonly squash?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#tags TfNfsFileShare#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#tags_all TfNfsFileShare#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#vpc_endpoint_dns_name TfNfsFileShare#vpc_endpoint_dns_name}
    */
    readonly vpcEndpointDnsName?: string;
    /**
    * cache_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#cache_attributes TfNfsFileShare#cache_attributes}
    */
    readonly cacheAttributes?: TfNfsFileShare.CacheAttributesProperty;
    /**
    * nfs_file_share_defaults block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#nfs_file_share_defaults TfNfsFileShare#nfs_file_share_defaults}
    */
    readonly nfsFileShareDefaults?: TfNfsFileShare.NfsFileShareDefaultsProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#timeouts TfNfsFileShare#timeouts}
    */
    readonly timeouts?: TfNfsFileShare.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share aws_storagegateway_nfs_file_share}
*/
export declare class TfNfsFileShare extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_storagegateway_nfs_file_share";
    /**
    * Generates CDKTN code for importing a TfNfsFileShare resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfNfsFileShare to import
    * @param importFromId The id of the existing TfNfsFileShare that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfNfsFileShare to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share aws_storagegateway_nfs_file_share} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfNfsFileShareConfig
    */
    constructor(scope: Construct, id: string, config: TfNfsFileShareConfig);
    get arn(): string;
    private _auditDestinationArn?;
    get auditDestinationArn(): string;
    set auditDestinationArn(value: string);
    resetAuditDestinationArn(): void;
    get auditDestinationArnInput(): string | undefined;
    private _bucketRegion?;
    get bucketRegion(): string;
    set bucketRegion(value: string);
    resetBucketRegion(): void;
    get bucketRegionInput(): string | undefined;
    private _clientList?;
    get clientList(): string[];
    set clientList(value: string[]);
    get clientListInput(): string[] | undefined;
    private _defaultStorageClass?;
    get defaultStorageClass(): string;
    set defaultStorageClass(value: string);
    resetDefaultStorageClass(): void;
    get defaultStorageClassInput(): string | undefined;
    private _fileShareName?;
    get fileShareName(): string;
    set fileShareName(value: string);
    resetFileShareName(): void;
    get fileShareNameInput(): string | undefined;
    get fileshareId(): string;
    private _gatewayArn?;
    get gatewayArn(): string;
    set gatewayArn(value: string);
    get gatewayArnInput(): string | undefined;
    private _guessMimeTypeEnabled?;
    get guessMimeTypeEnabled(): boolean | cdktn.IResolvable;
    set guessMimeTypeEnabled(value: boolean | cdktn.IResolvable);
    resetGuessMimeTypeEnabled(): void;
    get guessMimeTypeEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _kmsEncrypted?;
    get kmsEncrypted(): boolean | cdktn.IResolvable;
    set kmsEncrypted(value: boolean | cdktn.IResolvable);
    resetKmsEncrypted(): void;
    get kmsEncryptedInput(): boolean | cdktn.IResolvable | undefined;
    private _kmsKeyArn?;
    get kmsKeyArn(): string;
    set kmsKeyArn(value: string);
    resetKmsKeyArn(): void;
    get kmsKeyArnInput(): string | undefined;
    private _locationArn?;
    get locationArn(): string;
    set locationArn(value: string);
    get locationArnInput(): string | undefined;
    private _notificationPolicy?;
    get notificationPolicy(): string;
    set notificationPolicy(value: string);
    resetNotificationPolicy(): void;
    get notificationPolicyInput(): string | undefined;
    private _objectAcl?;
    get objectAcl(): string;
    set objectAcl(value: string);
    resetObjectAcl(): void;
    get objectAclInput(): string | undefined;
    get path(): string;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _requesterPays?;
    get requesterPays(): boolean | cdktn.IResolvable;
    set requesterPays(value: boolean | cdktn.IResolvable);
    resetRequesterPays(): void;
    get requesterPaysInput(): boolean | cdktn.IResolvable | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    private _squash?;
    get squash(): string;
    set squash(value: string);
    resetSquash(): void;
    get squashInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _vpcEndpointDnsName?;
    get vpcEndpointDnsName(): string;
    set vpcEndpointDnsName(value: string);
    resetVpcEndpointDnsName(): void;
    get vpcEndpointDnsNameInput(): string | undefined;
    private _cacheAttributes;
    get cacheAttributes(): TfNfsFileShare.CacheAttributesPropertyOutputReference;
    putCacheAttributes(value: TfNfsFileShare.CacheAttributesProperty): void;
    resetCacheAttributes(): void;
    get cacheAttributesInput(): TfNfsFileShare.CacheAttributesProperty | undefined;
    private _nfsFileShareDefaults;
    get nfsFileShareDefaults(): TfNfsFileShare.NfsFileShareDefaultsPropertyOutputReference;
    putNfsFileShareDefaults(value: TfNfsFileShare.NfsFileShareDefaultsProperty): void;
    resetNfsFileShareDefaults(): void;
    get nfsFileShareDefaultsInput(): TfNfsFileShare.NfsFileShareDefaultsProperty | undefined;
    private _timeouts;
    get timeouts(): TfNfsFileShare.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfNfsFileShare.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfNfsFileShare.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfNfsFileShareCacheAttributesPropertyToTerraform(struct?: TfNfsFileShare.CacheAttributesPropertyOutputReference | TfNfsFileShare.CacheAttributesProperty): any;
export declare function tfNfsFileShareCacheAttributesPropertyToHclTerraform(struct?: TfNfsFileShare.CacheAttributesPropertyOutputReference | TfNfsFileShare.CacheAttributesProperty): any;
export declare function tfNfsFileShareNfsFileShareDefaultsPropertyToTerraform(struct?: TfNfsFileShare.NfsFileShareDefaultsPropertyOutputReference | TfNfsFileShare.NfsFileShareDefaultsProperty): any;
export declare function tfNfsFileShareNfsFileShareDefaultsPropertyToHclTerraform(struct?: TfNfsFileShare.NfsFileShareDefaultsPropertyOutputReference | TfNfsFileShare.NfsFileShareDefaultsProperty): any;
export declare function tfNfsFileShareTimeoutsPropertyToTerraform(struct?: TfNfsFileShare.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfNfsFileShareTimeoutsPropertyToHclTerraform(struct?: TfNfsFileShare.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfNfsFileShare {
    interface CacheAttributesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#cache_stale_timeout_in_seconds TfNfsFileShare#cache_stale_timeout_in_seconds}
        */
        readonly cacheStaleTimeoutInSeconds?: number;
    }
    class CacheAttributesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CacheAttributesProperty | undefined;
        set internalValue(value: CacheAttributesProperty | undefined);
        private _cacheStaleTimeoutInSeconds?;
        get cacheStaleTimeoutInSeconds(): number;
        set cacheStaleTimeoutInSeconds(value: number);
        resetCacheStaleTimeoutInSeconds(): void;
        get cacheStaleTimeoutInSecondsInput(): number | undefined;
    }
    interface NfsFileShareDefaultsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#directory_mode TfNfsFileShare#directory_mode}
        */
        readonly directoryMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#file_mode TfNfsFileShare#file_mode}
        */
        readonly fileMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#group_id TfNfsFileShare#group_id}
        */
        readonly groupId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#owner_id TfNfsFileShare#owner_id}
        */
        readonly ownerId?: string;
    }
    class NfsFileShareDefaultsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NfsFileShareDefaultsProperty | undefined;
        set internalValue(value: NfsFileShareDefaultsProperty | undefined);
        private _directoryMode?;
        get directoryMode(): string;
        set directoryMode(value: string);
        resetDirectoryMode(): void;
        get directoryModeInput(): string | undefined;
        private _fileMode?;
        get fileMode(): string;
        set fileMode(value: string);
        resetFileMode(): void;
        get fileModeInput(): string | undefined;
        private _groupId?;
        get groupId(): string;
        set groupId(value: string);
        resetGroupId(): void;
        get groupIdInput(): string | undefined;
        private _ownerId?;
        get ownerId(): string;
        set ownerId(value: string);
        resetOwnerId(): void;
        get ownerIdInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#create TfNfsFileShare#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#delete TfNfsFileShare#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/storagegateway_nfs_file_share#update TfNfsFileShare#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
