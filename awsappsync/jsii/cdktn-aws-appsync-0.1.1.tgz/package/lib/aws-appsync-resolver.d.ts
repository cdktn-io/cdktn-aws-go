import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAppsyncResolverConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver#api_id AwsAppsyncResolver#api_id}
    */
    readonly apiId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver#code AwsAppsyncResolver#code}
    */
    readonly code?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver#data_source AwsAppsyncResolver#data_source}
    */
    readonly dataSource?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver#field AwsAppsyncResolver#field}
    */
    readonly field: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver#id AwsAppsyncResolver#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver#kind AwsAppsyncResolver#kind}
    */
    readonly kind?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver#max_batch_size AwsAppsyncResolver#max_batch_size}
    */
    readonly maxBatchSize?: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver#region AwsAppsyncResolver#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver#request_template AwsAppsyncResolver#request_template}
    */
    readonly requestTemplate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver#response_template AwsAppsyncResolver#response_template}
    */
    readonly responseTemplate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver#type AwsAppsyncResolver#type}
    */
    readonly type: string;
    /**
    * caching_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver#caching_config AwsAppsyncResolver#caching_config}
    */
    readonly cachingConfig?: AwsAppsyncResolver.CachingConfigProperty;
    /**
    * pipeline_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver#pipeline_config AwsAppsyncResolver#pipeline_config}
    */
    readonly pipelineConfig?: AwsAppsyncResolver.PipelineConfigProperty;
    /**
    * runtime block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver#runtime AwsAppsyncResolver#runtime}
    */
    readonly runtime?: AwsAppsyncResolver.RuntimeProperty;
    /**
    * sync_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver#sync_config AwsAppsyncResolver#sync_config}
    */
    readonly syncConfig?: AwsAppsyncResolver.SyncConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver aws_appsync_resolver}
*/
export declare class AwsAppsyncResolver extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_appsync_resolver";
    /**
    * Generates CDKTN code for importing a AwsAppsyncResolver resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsAppsyncResolver to import
    * @param importFromId The id of the existing AwsAppsyncResolver that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsAppsyncResolver to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver aws_appsync_resolver} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAppsyncResolverConfig
    */
    constructor(scope: Construct, id: string, config: AwsAppsyncResolverConfig);
    private _apiId?;
    get apiId(): string;
    set apiId(value: string);
    get apiIdInput(): string | undefined;
    get arn(): string;
    private _code?;
    get code(): string;
    set code(value: string);
    resetCode(): void;
    get codeInput(): string | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    resetDataSource(): void;
    get dataSourceInput(): string | undefined;
    private _field?;
    get field(): string;
    set field(value: string);
    get fieldInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _kind?;
    get kind(): string;
    set kind(value: string);
    resetKind(): void;
    get kindInput(): string | undefined;
    private _maxBatchSize?;
    get maxBatchSize(): number;
    set maxBatchSize(value: number);
    resetMaxBatchSize(): void;
    get maxBatchSizeInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _requestTemplate?;
    get requestTemplate(): string;
    set requestTemplate(value: string);
    resetRequestTemplate(): void;
    get requestTemplateInput(): string | undefined;
    private _responseTemplate?;
    get responseTemplate(): string;
    set responseTemplate(value: string);
    resetResponseTemplate(): void;
    get responseTemplateInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _cachingConfig;
    get cachingConfig(): AwsAppsyncResolver.CachingConfigPropertyOutputReference;
    putCachingConfig(value: AwsAppsyncResolver.CachingConfigProperty): void;
    resetCachingConfig(): void;
    get cachingConfigInput(): AwsAppsyncResolver.CachingConfigProperty | undefined;
    private _pipelineConfig;
    get pipelineConfig(): AwsAppsyncResolver.PipelineConfigPropertyOutputReference;
    putPipelineConfig(value: AwsAppsyncResolver.PipelineConfigProperty): void;
    resetPipelineConfig(): void;
    get pipelineConfigInput(): AwsAppsyncResolver.PipelineConfigProperty | undefined;
    private _runtime;
    get runtime(): AwsAppsyncResolver.RuntimePropertyOutputReference;
    putRuntime(value: AwsAppsyncResolver.RuntimeProperty): void;
    resetRuntime(): void;
    get runtimeInput(): AwsAppsyncResolver.RuntimeProperty | undefined;
    private _syncConfig;
    get syncConfig(): AwsAppsyncResolver.SyncConfigPropertyOutputReference;
    putSyncConfig(value: AwsAppsyncResolver.SyncConfigProperty): void;
    resetSyncConfig(): void;
    get syncConfigInput(): AwsAppsyncResolver.SyncConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsAppsyncResolverCachingConfigPropertyToTerraform(struct?: AwsAppsyncResolver.CachingConfigPropertyOutputReference | AwsAppsyncResolver.CachingConfigProperty): any;
export declare function awsAppsyncResolverCachingConfigPropertyToHclTerraform(struct?: AwsAppsyncResolver.CachingConfigPropertyOutputReference | AwsAppsyncResolver.CachingConfigProperty): any;
export declare function awsAppsyncResolverPipelineConfigPropertyToTerraform(struct?: AwsAppsyncResolver.PipelineConfigPropertyOutputReference | AwsAppsyncResolver.PipelineConfigProperty): any;
export declare function awsAppsyncResolverPipelineConfigPropertyToHclTerraform(struct?: AwsAppsyncResolver.PipelineConfigPropertyOutputReference | AwsAppsyncResolver.PipelineConfigProperty): any;
export declare function awsAppsyncResolverRuntimePropertyToTerraform(struct?: AwsAppsyncResolver.RuntimePropertyOutputReference | AwsAppsyncResolver.RuntimeProperty): any;
export declare function awsAppsyncResolverRuntimePropertyToHclTerraform(struct?: AwsAppsyncResolver.RuntimePropertyOutputReference | AwsAppsyncResolver.RuntimeProperty): any;
export declare function awsAppsyncResolverLambdaConflictHandlerConfigPropertyToTerraform(struct?: AwsAppsyncResolver.LambdaConflictHandlerConfigPropertyOutputReference | AwsAppsyncResolver.LambdaConflictHandlerConfigProperty): any;
export declare function awsAppsyncResolverLambdaConflictHandlerConfigPropertyToHclTerraform(struct?: AwsAppsyncResolver.LambdaConflictHandlerConfigPropertyOutputReference | AwsAppsyncResolver.LambdaConflictHandlerConfigProperty): any;
export declare function awsAppsyncResolverSyncConfigPropertyToTerraform(struct?: AwsAppsyncResolver.SyncConfigPropertyOutputReference | AwsAppsyncResolver.SyncConfigProperty): any;
export declare function awsAppsyncResolverSyncConfigPropertyToHclTerraform(struct?: AwsAppsyncResolver.SyncConfigPropertyOutputReference | AwsAppsyncResolver.SyncConfigProperty): any;
export declare namespace AwsAppsyncResolver {
    interface CachingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver#caching_keys AwsAppsyncResolver#caching_keys}
        */
        readonly cachingKeys?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver#ttl AwsAppsyncResolver#ttl}
        */
        readonly ttl?: number;
    }
    class CachingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CachingConfigProperty | undefined;
        set internalValue(value: CachingConfigProperty | undefined);
        private _cachingKeys?;
        get cachingKeys(): string[];
        set cachingKeys(value: string[]);
        resetCachingKeys(): void;
        get cachingKeysInput(): string[] | undefined;
        private _ttl?;
        get ttl(): number;
        set ttl(value: number);
        resetTtl(): void;
        get ttlInput(): number | undefined;
    }
    interface PipelineConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver#functions AwsAppsyncResolver#functions}
        */
        readonly functions?: string[];
    }
    class PipelineConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PipelineConfigProperty | undefined;
        set internalValue(value: PipelineConfigProperty | undefined);
        private _functions?;
        get functions(): string[];
        set functions(value: string[]);
        resetFunctions(): void;
        get functionsInput(): string[] | undefined;
    }
    interface RuntimeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver#name AwsAppsyncResolver#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver#runtime_version AwsAppsyncResolver#runtime_version}
        */
        readonly runtimeVersion: string;
    }
    class RuntimePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuntimeProperty | undefined;
        set internalValue(value: RuntimeProperty | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _runtimeVersion?;
        get runtimeVersion(): string;
        set runtimeVersion(value: string);
        get runtimeVersionInput(): string | undefined;
    }
    interface LambdaConflictHandlerConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver#lambda_conflict_handler_arn AwsAppsyncResolver#lambda_conflict_handler_arn}
        */
        readonly lambdaConflictHandlerArn?: string;
    }
    class LambdaConflictHandlerConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LambdaConflictHandlerConfigProperty | undefined;
        set internalValue(value: LambdaConflictHandlerConfigProperty | undefined);
        private _lambdaConflictHandlerArn?;
        get lambdaConflictHandlerArn(): string;
        set lambdaConflictHandlerArn(value: string);
        resetLambdaConflictHandlerArn(): void;
        get lambdaConflictHandlerArnInput(): string | undefined;
    }
    interface SyncConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver#conflict_detection AwsAppsyncResolver#conflict_detection}
        */
        readonly conflictDetection?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver#conflict_handler AwsAppsyncResolver#conflict_handler}
        */
        readonly conflictHandler?: string;
        /**
        * lambda_conflict_handler_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver#lambda_conflict_handler_config AwsAppsyncResolver#lambda_conflict_handler_config}
        */
        readonly lambdaConflictHandlerConfig?: LambdaConflictHandlerConfigProperty;
    }
    class SyncConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SyncConfigProperty | undefined;
        set internalValue(value: SyncConfigProperty | undefined);
        private _conflictDetection?;
        get conflictDetection(): string;
        set conflictDetection(value: string);
        resetConflictDetection(): void;
        get conflictDetectionInput(): string | undefined;
        private _conflictHandler?;
        get conflictHandler(): string;
        set conflictHandler(value: string);
        resetConflictHandler(): void;
        get conflictHandlerInput(): string | undefined;
        private _lambdaConflictHandlerConfig;
        get lambdaConflictHandlerConfig(): LambdaConflictHandlerConfigPropertyOutputReference;
        putLambdaConflictHandlerConfig(value: LambdaConflictHandlerConfigProperty): void;
        resetLambdaConflictHandlerConfig(): void;
        get lambdaConflictHandlerConfigInput(): LambdaConflictHandlerConfigProperty | undefined;
    }
}
