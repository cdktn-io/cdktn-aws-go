import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfChannelNamespaceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_channel_namespace#api_id TfChannelNamespace#api_id}
    */
    readonly apiId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_channel_namespace#code_handlers TfChannelNamespace#code_handlers}
    */
    readonly codeHandlers?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_channel_namespace#name TfChannelNamespace#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_channel_namespace#region TfChannelNamespace#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_channel_namespace#tags TfChannelNamespace#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * handler_configs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_channel_namespace#handler_configs TfChannelNamespace#handler_configs}
    */
    readonly handlerConfigs?: TfChannelNamespace.HandlerConfigsProperty[] | cdktn.IResolvable;
    /**
    * publish_auth_mode block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_channel_namespace#publish_auth_mode TfChannelNamespace#publish_auth_mode}
    */
    readonly publishAuthMode?: TfChannelNamespace.PublishAuthModeProperty[] | cdktn.IResolvable;
    /**
    * subscribe_auth_mode block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_channel_namespace#subscribe_auth_mode TfChannelNamespace#subscribe_auth_mode}
    */
    readonly subscribeAuthMode?: TfChannelNamespace.SubscribeAuthModeProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_channel_namespace aws_appsync_channel_namespace}
*/
export declare class TfChannelNamespace extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_appsync_channel_namespace";
    /**
    * Generates CDKTN code for importing a TfChannelNamespace resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfChannelNamespace to import
    * @param importFromId The id of the existing TfChannelNamespace that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_channel_namespace#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfChannelNamespace to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_channel_namespace aws_appsync_channel_namespace} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfChannelNamespaceConfig
    */
    constructor(scope: Construct, id: string, config: TfChannelNamespaceConfig);
    private _apiId?;
    get apiId(): string;
    set apiId(value: string);
    get apiIdInput(): string | undefined;
    get channelNamespaceArn(): string;
    private _codeHandlers?;
    get codeHandlers(): string;
    set codeHandlers(value: string);
    resetCodeHandlers(): void;
    get codeHandlersInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _handlerConfigs;
    get handlerConfigs(): TfChannelNamespace.HandlerConfigsPropertyList;
    putHandlerConfigs(value: TfChannelNamespace.HandlerConfigsProperty[] | cdktn.IResolvable): void;
    resetHandlerConfigs(): void;
    get handlerConfigsInput(): cdktn.IResolvable | TfChannelNamespace.HandlerConfigsProperty[] | undefined;
    private _publishAuthMode;
    get publishAuthMode(): TfChannelNamespace.PublishAuthModePropertyList;
    putPublishAuthMode(value: TfChannelNamespace.PublishAuthModeProperty[] | cdktn.IResolvable): void;
    resetPublishAuthMode(): void;
    get publishAuthModeInput(): cdktn.IResolvable | TfChannelNamespace.PublishAuthModeProperty[] | undefined;
    private _subscribeAuthMode;
    get subscribeAuthMode(): TfChannelNamespace.SubscribeAuthModePropertyList;
    putSubscribeAuthMode(value: TfChannelNamespace.SubscribeAuthModeProperty[] | cdktn.IResolvable): void;
    resetSubscribeAuthMode(): void;
    get subscribeAuthModeInput(): cdktn.IResolvable | TfChannelNamespace.SubscribeAuthModeProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfChannelNamespaceHandlerConfigsOnPublishIntegrationLambdaConfigPropertyToTerraform(struct?: TfChannelNamespace.HandlerConfigsOnPublishIntegrationLambdaConfigProperty | cdktn.IResolvable): any;
export declare function tfChannelNamespaceHandlerConfigsOnPublishIntegrationLambdaConfigPropertyToHclTerraform(struct?: TfChannelNamespace.HandlerConfigsOnPublishIntegrationLambdaConfigProperty | cdktn.IResolvable): any;
export declare function tfChannelNamespaceHandlerConfigsOnPublishIntegrationPropertyToTerraform(struct?: TfChannelNamespace.HandlerConfigsOnPublishIntegrationProperty | cdktn.IResolvable): any;
export declare function tfChannelNamespaceHandlerConfigsOnPublishIntegrationPropertyToHclTerraform(struct?: TfChannelNamespace.HandlerConfigsOnPublishIntegrationProperty | cdktn.IResolvable): any;
export declare function tfChannelNamespaceOnPublishPropertyToTerraform(struct?: TfChannelNamespace.OnPublishProperty | cdktn.IResolvable): any;
export declare function tfChannelNamespaceOnPublishPropertyToHclTerraform(struct?: TfChannelNamespace.OnPublishProperty | cdktn.IResolvable): any;
export declare function tfChannelNamespaceHandlerConfigsOnSubscribeIntegrationLambdaConfigPropertyToTerraform(struct?: TfChannelNamespace.HandlerConfigsOnSubscribeIntegrationLambdaConfigProperty | cdktn.IResolvable): any;
export declare function tfChannelNamespaceHandlerConfigsOnSubscribeIntegrationLambdaConfigPropertyToHclTerraform(struct?: TfChannelNamespace.HandlerConfigsOnSubscribeIntegrationLambdaConfigProperty | cdktn.IResolvable): any;
export declare function tfChannelNamespaceHandlerConfigsOnSubscribeIntegrationPropertyToTerraform(struct?: TfChannelNamespace.HandlerConfigsOnSubscribeIntegrationProperty | cdktn.IResolvable): any;
export declare function tfChannelNamespaceHandlerConfigsOnSubscribeIntegrationPropertyToHclTerraform(struct?: TfChannelNamespace.HandlerConfigsOnSubscribeIntegrationProperty | cdktn.IResolvable): any;
export declare function tfChannelNamespaceOnSubscribePropertyToTerraform(struct?: TfChannelNamespace.OnSubscribeProperty | cdktn.IResolvable): any;
export declare function tfChannelNamespaceOnSubscribePropertyToHclTerraform(struct?: TfChannelNamespace.OnSubscribeProperty | cdktn.IResolvable): any;
export declare function tfChannelNamespaceHandlerConfigsPropertyToTerraform(struct?: TfChannelNamespace.HandlerConfigsProperty | cdktn.IResolvable): any;
export declare function tfChannelNamespaceHandlerConfigsPropertyToHclTerraform(struct?: TfChannelNamespace.HandlerConfigsProperty | cdktn.IResolvable): any;
export declare function tfChannelNamespacePublishAuthModePropertyToTerraform(struct?: TfChannelNamespace.PublishAuthModeProperty | cdktn.IResolvable): any;
export declare function tfChannelNamespacePublishAuthModePropertyToHclTerraform(struct?: TfChannelNamespace.PublishAuthModeProperty | cdktn.IResolvable): any;
export declare function tfChannelNamespaceSubscribeAuthModePropertyToTerraform(struct?: TfChannelNamespace.SubscribeAuthModeProperty | cdktn.IResolvable): any;
export declare function tfChannelNamespaceSubscribeAuthModePropertyToHclTerraform(struct?: TfChannelNamespace.SubscribeAuthModeProperty | cdktn.IResolvable): any;
export declare namespace TfChannelNamespace {
    interface HandlerConfigsOnPublishIntegrationLambdaConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_channel_namespace#invoke_type TfChannelNamespace#invoke_type}
        */
        readonly invokeType?: string;
    }
    class HandlerConfigsOnPublishIntegrationLambdaConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HandlerConfigsOnPublishIntegrationLambdaConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: HandlerConfigsOnPublishIntegrationLambdaConfigProperty | cdktn.IResolvable | undefined);
        private _invokeType?;
        get invokeType(): string;
        set invokeType(value: string);
        resetInvokeType(): void;
        get invokeTypeInput(): string | undefined;
    }
    class HandlerConfigsOnPublishIntegrationLambdaConfigPropertyList extends cdktn.ComplexList {
        internalValue?: HandlerConfigsOnPublishIntegrationLambdaConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HandlerConfigsOnPublishIntegrationLambdaConfigPropertyOutputReference;
    }
    interface HandlerConfigsOnPublishIntegrationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_channel_namespace#data_source_name TfChannelNamespace#data_source_name}
        */
        readonly dataSourceName: string;
        /**
        * lambda_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_channel_namespace#lambda_config TfChannelNamespace#lambda_config}
        */
        readonly lambdaConfig?: HandlerConfigsOnPublishIntegrationLambdaConfigProperty[] | cdktn.IResolvable;
    }
    class HandlerConfigsOnPublishIntegrationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HandlerConfigsOnPublishIntegrationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: HandlerConfigsOnPublishIntegrationProperty | cdktn.IResolvable | undefined);
        private _dataSourceName?;
        get dataSourceName(): string;
        set dataSourceName(value: string);
        get dataSourceNameInput(): string | undefined;
        private _lambdaConfig;
        get lambdaConfig(): HandlerConfigsOnPublishIntegrationLambdaConfigPropertyList;
        putLambdaConfig(value: HandlerConfigsOnPublishIntegrationLambdaConfigProperty[] | cdktn.IResolvable): void;
        resetLambdaConfig(): void;
        get lambdaConfigInput(): cdktn.IResolvable | HandlerConfigsOnPublishIntegrationLambdaConfigProperty[] | undefined;
    }
    class HandlerConfigsOnPublishIntegrationPropertyList extends cdktn.ComplexList {
        internalValue?: HandlerConfigsOnPublishIntegrationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HandlerConfigsOnPublishIntegrationPropertyOutputReference;
    }
    interface OnPublishProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_channel_namespace#behavior TfChannelNamespace#behavior}
        */
        readonly behavior: string;
        /**
        * integration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_channel_namespace#integration TfChannelNamespace#integration}
        */
        readonly integration?: HandlerConfigsOnPublishIntegrationProperty[] | cdktn.IResolvable;
    }
    class OnPublishPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OnPublishProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OnPublishProperty | cdktn.IResolvable | undefined);
        private _behavior?;
        get behavior(): string;
        set behavior(value: string);
        get behaviorInput(): string | undefined;
        private _integration;
        get integration(): HandlerConfigsOnPublishIntegrationPropertyList;
        putIntegration(value: HandlerConfigsOnPublishIntegrationProperty[] | cdktn.IResolvable): void;
        resetIntegration(): void;
        get integrationInput(): cdktn.IResolvable | HandlerConfigsOnPublishIntegrationProperty[] | undefined;
    }
    class OnPublishPropertyList extends cdktn.ComplexList {
        internalValue?: OnPublishProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OnPublishPropertyOutputReference;
    }
    interface HandlerConfigsOnSubscribeIntegrationLambdaConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_channel_namespace#invoke_type TfChannelNamespace#invoke_type}
        */
        readonly invokeType?: string;
    }
    class HandlerConfigsOnSubscribeIntegrationLambdaConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HandlerConfigsOnSubscribeIntegrationLambdaConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: HandlerConfigsOnSubscribeIntegrationLambdaConfigProperty | cdktn.IResolvable | undefined);
        private _invokeType?;
        get invokeType(): string;
        set invokeType(value: string);
        resetInvokeType(): void;
        get invokeTypeInput(): string | undefined;
    }
    class HandlerConfigsOnSubscribeIntegrationLambdaConfigPropertyList extends cdktn.ComplexList {
        internalValue?: HandlerConfigsOnSubscribeIntegrationLambdaConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HandlerConfigsOnSubscribeIntegrationLambdaConfigPropertyOutputReference;
    }
    interface HandlerConfigsOnSubscribeIntegrationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_channel_namespace#data_source_name TfChannelNamespace#data_source_name}
        */
        readonly dataSourceName: string;
        /**
        * lambda_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_channel_namespace#lambda_config TfChannelNamespace#lambda_config}
        */
        readonly lambdaConfig?: HandlerConfigsOnSubscribeIntegrationLambdaConfigProperty[] | cdktn.IResolvable;
    }
    class HandlerConfigsOnSubscribeIntegrationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HandlerConfigsOnSubscribeIntegrationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: HandlerConfigsOnSubscribeIntegrationProperty | cdktn.IResolvable | undefined);
        private _dataSourceName?;
        get dataSourceName(): string;
        set dataSourceName(value: string);
        get dataSourceNameInput(): string | undefined;
        private _lambdaConfig;
        get lambdaConfig(): HandlerConfigsOnSubscribeIntegrationLambdaConfigPropertyList;
        putLambdaConfig(value: HandlerConfigsOnSubscribeIntegrationLambdaConfigProperty[] | cdktn.IResolvable): void;
        resetLambdaConfig(): void;
        get lambdaConfigInput(): cdktn.IResolvable | HandlerConfigsOnSubscribeIntegrationLambdaConfigProperty[] | undefined;
    }
    class HandlerConfigsOnSubscribeIntegrationPropertyList extends cdktn.ComplexList {
        internalValue?: HandlerConfigsOnSubscribeIntegrationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HandlerConfigsOnSubscribeIntegrationPropertyOutputReference;
    }
    interface OnSubscribeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_channel_namespace#behavior TfChannelNamespace#behavior}
        */
        readonly behavior: string;
        /**
        * integration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_channel_namespace#integration TfChannelNamespace#integration}
        */
        readonly integration?: HandlerConfigsOnSubscribeIntegrationProperty[] | cdktn.IResolvable;
    }
    class OnSubscribePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OnSubscribeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OnSubscribeProperty | cdktn.IResolvable | undefined);
        private _behavior?;
        get behavior(): string;
        set behavior(value: string);
        get behaviorInput(): string | undefined;
        private _integration;
        get integration(): HandlerConfigsOnSubscribeIntegrationPropertyList;
        putIntegration(value: HandlerConfigsOnSubscribeIntegrationProperty[] | cdktn.IResolvable): void;
        resetIntegration(): void;
        get integrationInput(): cdktn.IResolvable | HandlerConfigsOnSubscribeIntegrationProperty[] | undefined;
    }
    class OnSubscribePropertyList extends cdktn.ComplexList {
        internalValue?: OnSubscribeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OnSubscribePropertyOutputReference;
    }
    interface HandlerConfigsProperty {
        /**
        * on_publish block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_channel_namespace#on_publish TfChannelNamespace#on_publish}
        */
        readonly onPublish?: OnPublishProperty[] | cdktn.IResolvable;
        /**
        * on_subscribe block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_channel_namespace#on_subscribe TfChannelNamespace#on_subscribe}
        */
        readonly onSubscribe?: OnSubscribeProperty[] | cdktn.IResolvable;
    }
    class HandlerConfigsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HandlerConfigsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: HandlerConfigsProperty | cdktn.IResolvable | undefined);
        private _onPublish;
        get onPublish(): OnPublishPropertyList;
        putOnPublish(value: OnPublishProperty[] | cdktn.IResolvable): void;
        resetOnPublish(): void;
        get onPublishInput(): cdktn.IResolvable | OnPublishProperty[] | undefined;
        private _onSubscribe;
        get onSubscribe(): OnSubscribePropertyList;
        putOnSubscribe(value: OnSubscribeProperty[] | cdktn.IResolvable): void;
        resetOnSubscribe(): void;
        get onSubscribeInput(): cdktn.IResolvable | OnSubscribeProperty[] | undefined;
    }
    class HandlerConfigsPropertyList extends cdktn.ComplexList {
        internalValue?: HandlerConfigsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HandlerConfigsPropertyOutputReference;
    }
    interface PublishAuthModeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_channel_namespace#auth_type TfChannelNamespace#auth_type}
        */
        readonly authType: string;
    }
    class PublishAuthModePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PublishAuthModeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PublishAuthModeProperty | cdktn.IResolvable | undefined);
        private _authType?;
        get authType(): string;
        set authType(value: string);
        get authTypeInput(): string | undefined;
    }
    class PublishAuthModePropertyList extends cdktn.ComplexList {
        internalValue?: PublishAuthModeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PublishAuthModePropertyOutputReference;
    }
    interface SubscribeAuthModeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_channel_namespace#auth_type TfChannelNamespace#auth_type}
        */
        readonly authType: string;
    }
    class SubscribeAuthModePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SubscribeAuthModeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SubscribeAuthModeProperty | cdktn.IResolvable | undefined);
        private _authType?;
        get authType(): string;
        set authType(value: string);
        get authTypeInput(): string | undefined;
    }
    class SubscribeAuthModePropertyList extends cdktn.ComplexList {
        internalValue?: SubscribeAuthModeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SubscribeAuthModePropertyOutputReference;
    }
}
