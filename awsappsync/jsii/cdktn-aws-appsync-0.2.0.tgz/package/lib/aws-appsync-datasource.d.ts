import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfDatasourceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#api_id TfDatasource#api_id}
    */
    readonly apiId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#description TfDatasource#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#id TfDatasource#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#name TfDatasource#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#region TfDatasource#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#service_role_arn TfDatasource#service_role_arn}
    */
    readonly serviceRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#type TfDatasource#type}
    */
    readonly type: string;
    /**
    * dynamodb_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#dynamodb_config TfDatasource#dynamodb_config}
    */
    readonly dynamodbConfig?: TfDatasource.DynamodbConfigProperty;
    /**
    * elasticsearch_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#elasticsearch_config TfDatasource#elasticsearch_config}
    */
    readonly elasticsearchConfig?: TfDatasource.ElasticsearchConfigProperty;
    /**
    * event_bridge_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#event_bridge_config TfDatasource#event_bridge_config}
    */
    readonly eventBridgeConfig?: TfDatasource.EventBridgeConfigProperty;
    /**
    * http_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#http_config TfDatasource#http_config}
    */
    readonly httpConfig?: TfDatasource.HttpConfigProperty;
    /**
    * lambda_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#lambda_config TfDatasource#lambda_config}
    */
    readonly lambdaConfig?: TfDatasource.LambdaConfigProperty;
    /**
    * opensearchservice_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#opensearchservice_config TfDatasource#opensearchservice_config}
    */
    readonly opensearchserviceConfig?: TfDatasource.OpensearchserviceConfigProperty;
    /**
    * relational_database_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#relational_database_config TfDatasource#relational_database_config}
    */
    readonly relationalDatabaseConfig?: TfDatasource.RelationalDatabaseConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource aws_appsync_datasource}
*/
export declare class TfDatasource extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_appsync_datasource";
    /**
    * Generates CDKTN code for importing a TfDatasource resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfDatasource to import
    * @param importFromId The id of the existing TfDatasource that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfDatasource to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource aws_appsync_datasource} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfDatasourceConfig
    */
    constructor(scope: Construct, id: string, config: TfDatasourceConfig);
    private _apiId?;
    get apiId(): string;
    set apiId(value: string);
    get apiIdInput(): string | undefined;
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _serviceRoleArn?;
    get serviceRoleArn(): string;
    set serviceRoleArn(value: string);
    resetServiceRoleArn(): void;
    get serviceRoleArnInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _dynamodbConfig;
    get dynamodbConfig(): TfDatasource.DynamodbConfigPropertyOutputReference;
    putDynamodbConfig(value: TfDatasource.DynamodbConfigProperty): void;
    resetDynamodbConfig(): void;
    get dynamodbConfigInput(): TfDatasource.DynamodbConfigProperty | undefined;
    private _elasticsearchConfig;
    get elasticsearchConfig(): TfDatasource.ElasticsearchConfigPropertyOutputReference;
    putElasticsearchConfig(value: TfDatasource.ElasticsearchConfigProperty): void;
    resetElasticsearchConfig(): void;
    get elasticsearchConfigInput(): TfDatasource.ElasticsearchConfigProperty | undefined;
    private _eventBridgeConfig;
    get eventBridgeConfig(): TfDatasource.EventBridgeConfigPropertyOutputReference;
    putEventBridgeConfig(value: TfDatasource.EventBridgeConfigProperty): void;
    resetEventBridgeConfig(): void;
    get eventBridgeConfigInput(): TfDatasource.EventBridgeConfigProperty | undefined;
    private _httpConfig;
    get httpConfig(): TfDatasource.HttpConfigPropertyOutputReference;
    putHttpConfig(value: TfDatasource.HttpConfigProperty): void;
    resetHttpConfig(): void;
    get httpConfigInput(): TfDatasource.HttpConfigProperty | undefined;
    private _lambdaConfig;
    get lambdaConfig(): TfDatasource.LambdaConfigPropertyOutputReference;
    putLambdaConfig(value: TfDatasource.LambdaConfigProperty): void;
    resetLambdaConfig(): void;
    get lambdaConfigInput(): TfDatasource.LambdaConfigProperty | undefined;
    private _opensearchserviceConfig;
    get opensearchserviceConfig(): TfDatasource.OpensearchserviceConfigPropertyOutputReference;
    putOpensearchserviceConfig(value: TfDatasource.OpensearchserviceConfigProperty): void;
    resetOpensearchserviceConfig(): void;
    get opensearchserviceConfigInput(): TfDatasource.OpensearchserviceConfigProperty | undefined;
    private _relationalDatabaseConfig;
    get relationalDatabaseConfig(): TfDatasource.RelationalDatabaseConfigPropertyOutputReference;
    putRelationalDatabaseConfig(value: TfDatasource.RelationalDatabaseConfigProperty): void;
    resetRelationalDatabaseConfig(): void;
    get relationalDatabaseConfigInput(): TfDatasource.RelationalDatabaseConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfDatasourceDeltaSyncConfigPropertyToTerraform(struct?: TfDatasource.DeltaSyncConfigPropertyOutputReference | TfDatasource.DeltaSyncConfigProperty): any;
export declare function tfDatasourceDeltaSyncConfigPropertyToHclTerraform(struct?: TfDatasource.DeltaSyncConfigPropertyOutputReference | TfDatasource.DeltaSyncConfigProperty): any;
export declare function tfDatasourceDynamodbConfigPropertyToTerraform(struct?: TfDatasource.DynamodbConfigPropertyOutputReference | TfDatasource.DynamodbConfigProperty): any;
export declare function tfDatasourceDynamodbConfigPropertyToHclTerraform(struct?: TfDatasource.DynamodbConfigPropertyOutputReference | TfDatasource.DynamodbConfigProperty): any;
export declare function tfDatasourceElasticsearchConfigPropertyToTerraform(struct?: TfDatasource.ElasticsearchConfigPropertyOutputReference | TfDatasource.ElasticsearchConfigProperty): any;
export declare function tfDatasourceElasticsearchConfigPropertyToHclTerraform(struct?: TfDatasource.ElasticsearchConfigPropertyOutputReference | TfDatasource.ElasticsearchConfigProperty): any;
export declare function tfDatasourceEventBridgeConfigPropertyToTerraform(struct?: TfDatasource.EventBridgeConfigPropertyOutputReference | TfDatasource.EventBridgeConfigProperty): any;
export declare function tfDatasourceEventBridgeConfigPropertyToHclTerraform(struct?: TfDatasource.EventBridgeConfigPropertyOutputReference | TfDatasource.EventBridgeConfigProperty): any;
export declare function tfDatasourceAwsIamConfigPropertyToTerraform(struct?: TfDatasource.AwsIamConfigPropertyOutputReference | TfDatasource.AwsIamConfigProperty): any;
export declare function tfDatasourceAwsIamConfigPropertyToHclTerraform(struct?: TfDatasource.AwsIamConfigPropertyOutputReference | TfDatasource.AwsIamConfigProperty): any;
export declare function tfDatasourceAuthorizationConfigPropertyToTerraform(struct?: TfDatasource.AuthorizationConfigPropertyOutputReference | TfDatasource.AuthorizationConfigProperty): any;
export declare function tfDatasourceAuthorizationConfigPropertyToHclTerraform(struct?: TfDatasource.AuthorizationConfigPropertyOutputReference | TfDatasource.AuthorizationConfigProperty): any;
export declare function tfDatasourceHttpConfigPropertyToTerraform(struct?: TfDatasource.HttpConfigPropertyOutputReference | TfDatasource.HttpConfigProperty): any;
export declare function tfDatasourceHttpConfigPropertyToHclTerraform(struct?: TfDatasource.HttpConfigPropertyOutputReference | TfDatasource.HttpConfigProperty): any;
export declare function tfDatasourceLambdaConfigPropertyToTerraform(struct?: TfDatasource.LambdaConfigPropertyOutputReference | TfDatasource.LambdaConfigProperty): any;
export declare function tfDatasourceLambdaConfigPropertyToHclTerraform(struct?: TfDatasource.LambdaConfigPropertyOutputReference | TfDatasource.LambdaConfigProperty): any;
export declare function tfDatasourceOpensearchserviceConfigPropertyToTerraform(struct?: TfDatasource.OpensearchserviceConfigPropertyOutputReference | TfDatasource.OpensearchserviceConfigProperty): any;
export declare function tfDatasourceOpensearchserviceConfigPropertyToHclTerraform(struct?: TfDatasource.OpensearchserviceConfigPropertyOutputReference | TfDatasource.OpensearchserviceConfigProperty): any;
export declare function tfDatasourceHttpEndpointConfigPropertyToTerraform(struct?: TfDatasource.HttpEndpointConfigPropertyOutputReference | TfDatasource.HttpEndpointConfigProperty): any;
export declare function tfDatasourceHttpEndpointConfigPropertyToHclTerraform(struct?: TfDatasource.HttpEndpointConfigPropertyOutputReference | TfDatasource.HttpEndpointConfigProperty): any;
export declare function tfDatasourceRelationalDatabaseConfigPropertyToTerraform(struct?: TfDatasource.RelationalDatabaseConfigPropertyOutputReference | TfDatasource.RelationalDatabaseConfigProperty): any;
export declare function tfDatasourceRelationalDatabaseConfigPropertyToHclTerraform(struct?: TfDatasource.RelationalDatabaseConfigPropertyOutputReference | TfDatasource.RelationalDatabaseConfigProperty): any;
export declare namespace TfDatasource {
    interface DeltaSyncConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#base_table_ttl TfDatasource#base_table_ttl}
        */
        readonly baseTableTtl?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#delta_sync_table_name TfDatasource#delta_sync_table_name}
        */
        readonly deltaSyncTableName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#delta_sync_table_ttl TfDatasource#delta_sync_table_ttl}
        */
        readonly deltaSyncTableTtl?: number;
    }
    class DeltaSyncConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DeltaSyncConfigProperty | undefined;
        set internalValue(value: DeltaSyncConfigProperty | undefined);
        private _baseTableTtl?;
        get baseTableTtl(): number;
        set baseTableTtl(value: number);
        resetBaseTableTtl(): void;
        get baseTableTtlInput(): number | undefined;
        private _deltaSyncTableName?;
        get deltaSyncTableName(): string;
        set deltaSyncTableName(value: string);
        get deltaSyncTableNameInput(): string | undefined;
        private _deltaSyncTableTtl?;
        get deltaSyncTableTtl(): number;
        set deltaSyncTableTtl(value: number);
        resetDeltaSyncTableTtl(): void;
        get deltaSyncTableTtlInput(): number | undefined;
    }
    interface DynamodbConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#region TfDatasource#region}
        */
        readonly region?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#table_name TfDatasource#table_name}
        */
        readonly tableName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#use_caller_credentials TfDatasource#use_caller_credentials}
        */
        readonly useCallerCredentials?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#versioned TfDatasource#versioned}
        */
        readonly versioned?: boolean | cdktn.IResolvable;
        /**
        * delta_sync_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#delta_sync_config TfDatasource#delta_sync_config}
        */
        readonly deltaSyncConfig?: DeltaSyncConfigProperty;
    }
    class DynamodbConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DynamodbConfigProperty | undefined;
        set internalValue(value: DynamodbConfigProperty | undefined);
        private _region?;
        get region(): string;
        set region(value: string);
        resetRegion(): void;
        get regionInput(): string | undefined;
        private _tableName?;
        get tableName(): string;
        set tableName(value: string);
        get tableNameInput(): string | undefined;
        private _useCallerCredentials?;
        get useCallerCredentials(): boolean | cdktn.IResolvable;
        set useCallerCredentials(value: boolean | cdktn.IResolvable);
        resetUseCallerCredentials(): void;
        get useCallerCredentialsInput(): boolean | cdktn.IResolvable | undefined;
        private _versioned?;
        get versioned(): boolean | cdktn.IResolvable;
        set versioned(value: boolean | cdktn.IResolvable);
        resetVersioned(): void;
        get versionedInput(): boolean | cdktn.IResolvable | undefined;
        private _deltaSyncConfig;
        get deltaSyncConfig(): DeltaSyncConfigPropertyOutputReference;
        putDeltaSyncConfig(value: DeltaSyncConfigProperty): void;
        resetDeltaSyncConfig(): void;
        get deltaSyncConfigInput(): DeltaSyncConfigProperty | undefined;
    }
    interface ElasticsearchConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#endpoint TfDatasource#endpoint}
        */
        readonly endpoint: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#region TfDatasource#region}
        */
        readonly region?: string;
    }
    class ElasticsearchConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ElasticsearchConfigProperty | undefined;
        set internalValue(value: ElasticsearchConfigProperty | undefined);
        private _endpoint?;
        get endpoint(): string;
        set endpoint(value: string);
        get endpointInput(): string | undefined;
        private _region?;
        get region(): string;
        set region(value: string);
        resetRegion(): void;
        get regionInput(): string | undefined;
    }
    interface EventBridgeConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#event_bus_arn TfDatasource#event_bus_arn}
        */
        readonly eventBusArn: string;
    }
    class EventBridgeConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EventBridgeConfigProperty | undefined;
        set internalValue(value: EventBridgeConfigProperty | undefined);
        private _eventBusArn?;
        get eventBusArn(): string;
        set eventBusArn(value: string);
        get eventBusArnInput(): string | undefined;
    }
    interface AwsIamConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#signing_region TfDatasource#signing_region}
        */
        readonly signingRegion?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#signing_service_name TfDatasource#signing_service_name}
        */
        readonly signingServiceName?: string;
    }
    class AwsIamConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AwsIamConfigProperty | undefined;
        set internalValue(value: AwsIamConfigProperty | undefined);
        private _signingRegion?;
        get signingRegion(): string;
        set signingRegion(value: string);
        resetSigningRegion(): void;
        get signingRegionInput(): string | undefined;
        private _signingServiceName?;
        get signingServiceName(): string;
        set signingServiceName(value: string);
        resetSigningServiceName(): void;
        get signingServiceNameInput(): string | undefined;
    }
    interface AuthorizationConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#authorization_type TfDatasource#authorization_type}
        */
        readonly authorizationType?: string;
        /**
        * aws_iam_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#aws_iam_config TfDatasource#aws_iam_config}
        */
        readonly awsIamConfig?: AwsIamConfigProperty;
    }
    class AuthorizationConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AuthorizationConfigProperty | undefined;
        set internalValue(value: AuthorizationConfigProperty | undefined);
        private _authorizationType?;
        get authorizationType(): string;
        set authorizationType(value: string);
        resetAuthorizationType(): void;
        get authorizationTypeInput(): string | undefined;
        private _awsIamConfig;
        get awsIamConfig(): AwsIamConfigPropertyOutputReference;
        putAwsIamConfig(value: AwsIamConfigProperty): void;
        resetAwsIamConfig(): void;
        get awsIamConfigInput(): AwsIamConfigProperty | undefined;
    }
    interface HttpConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#endpoint TfDatasource#endpoint}
        */
        readonly endpoint: string;
        /**
        * authorization_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#authorization_config TfDatasource#authorization_config}
        */
        readonly authorizationConfig?: AuthorizationConfigProperty;
    }
    class HttpConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HttpConfigProperty | undefined;
        set internalValue(value: HttpConfigProperty | undefined);
        private _endpoint?;
        get endpoint(): string;
        set endpoint(value: string);
        get endpointInput(): string | undefined;
        private _authorizationConfig;
        get authorizationConfig(): AuthorizationConfigPropertyOutputReference;
        putAuthorizationConfig(value: AuthorizationConfigProperty): void;
        resetAuthorizationConfig(): void;
        get authorizationConfigInput(): AuthorizationConfigProperty | undefined;
    }
    interface LambdaConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#function_arn TfDatasource#function_arn}
        */
        readonly functionArn: string;
    }
    class LambdaConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LambdaConfigProperty | undefined;
        set internalValue(value: LambdaConfigProperty | undefined);
        private _functionArn?;
        get functionArn(): string;
        set functionArn(value: string);
        get functionArnInput(): string | undefined;
    }
    interface OpensearchserviceConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#endpoint TfDatasource#endpoint}
        */
        readonly endpoint: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#region TfDatasource#region}
        */
        readonly region?: string;
    }
    class OpensearchserviceConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OpensearchserviceConfigProperty | undefined;
        set internalValue(value: OpensearchserviceConfigProperty | undefined);
        private _endpoint?;
        get endpoint(): string;
        set endpoint(value: string);
        get endpointInput(): string | undefined;
        private _region?;
        get region(): string;
        set region(value: string);
        resetRegion(): void;
        get regionInput(): string | undefined;
    }
    interface HttpEndpointConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#aws_secret_store_arn TfDatasource#aws_secret_store_arn}
        */
        readonly awsSecretStoreArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#database_name TfDatasource#database_name}
        */
        readonly databaseName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#db_cluster_identifier TfDatasource#db_cluster_identifier}
        */
        readonly dbClusterIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#region TfDatasource#region}
        */
        readonly region?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#schema TfDatasource#schema}
        */
        readonly schema?: string;
    }
    class HttpEndpointConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HttpEndpointConfigProperty | undefined;
        set internalValue(value: HttpEndpointConfigProperty | undefined);
        private _awsSecretStoreArn?;
        get awsSecretStoreArn(): string;
        set awsSecretStoreArn(value: string);
        get awsSecretStoreArnInput(): string | undefined;
        private _databaseName?;
        get databaseName(): string;
        set databaseName(value: string);
        resetDatabaseName(): void;
        get databaseNameInput(): string | undefined;
        private _dbClusterIdentifier?;
        get dbClusterIdentifier(): string;
        set dbClusterIdentifier(value: string);
        get dbClusterIdentifierInput(): string | undefined;
        private _region?;
        get region(): string;
        set region(value: string);
        resetRegion(): void;
        get regionInput(): string | undefined;
        private _schema?;
        get schema(): string;
        set schema(value: string);
        resetSchema(): void;
        get schemaInput(): string | undefined;
    }
    interface RelationalDatabaseConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#source_type TfDatasource#source_type}
        */
        readonly sourceType?: string;
        /**
        * http_endpoint_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#http_endpoint_config TfDatasource#http_endpoint_config}
        */
        readonly httpEndpointConfig?: HttpEndpointConfigProperty;
    }
    class RelationalDatabaseConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RelationalDatabaseConfigProperty | undefined;
        set internalValue(value: RelationalDatabaseConfigProperty | undefined);
        private _sourceType?;
        get sourceType(): string;
        set sourceType(value: string);
        resetSourceType(): void;
        get sourceTypeInput(): string | undefined;
        private _httpEndpointConfig;
        get httpEndpointConfig(): HttpEndpointConfigPropertyOutputReference;
        putHttpEndpointConfig(value: HttpEndpointConfigProperty): void;
        resetHttpEndpointConfig(): void;
        get httpEndpointConfigInput(): HttpEndpointConfigProperty | undefined;
    }
}
