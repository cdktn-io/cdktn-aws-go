import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSlotTypeConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_slot_type#bot_id AwsSlotType#bot_id}
    */
    readonly botId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_slot_type#bot_version AwsSlotType#bot_version}
    */
    readonly botVersion: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_slot_type#description AwsSlotType#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_slot_type#locale_id AwsSlotType#locale_id}
    */
    readonly localeId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_slot_type#name AwsSlotType#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_slot_type#parent_slot_type_signature AwsSlotType#parent_slot_type_signature}
    */
    readonly parentSlotTypeSignature?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_slot_type#region AwsSlotType#region}
    */
    readonly region?: string;
    /**
    * composite_slot_type_setting block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_slot_type#composite_slot_type_setting AwsSlotType#composite_slot_type_setting}
    */
    readonly compositeSlotTypeSetting?: AwsSlotType.CompositeSlotTypeSettingProperty[] | cdktn.IResolvable;
    /**
    * external_source_setting block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_slot_type#external_source_setting AwsSlotType#external_source_setting}
    */
    readonly externalSourceSetting?: AwsSlotType.ExternalSourceSettingProperty[] | cdktn.IResolvable;
    /**
    * slot_type_values block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_slot_type#slot_type_values AwsSlotType#slot_type_values}
    */
    readonly slotTypeValues?: AwsSlotType.SlotTypeValuesProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_slot_type#timeouts AwsSlotType#timeouts}
    */
    readonly timeouts?: AwsSlotType.TimeoutsProperty;
    /**
    * value_selection_setting block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_slot_type#value_selection_setting AwsSlotType#value_selection_setting}
    */
    readonly valueSelectionSetting?: AwsSlotType.ValueSelectionSettingProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_slot_type aws_lexv2models_slot_type}
*/
export declare class AwsSlotType extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_lexv2models_slot_type";
    /**
    * Generates CDKTN code for importing a AwsSlotType resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSlotType to import
    * @param importFromId The id of the existing AwsSlotType that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_slot_type#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSlotType to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_slot_type aws_lexv2models_slot_type} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSlotTypeConfig
    */
    constructor(scope: Construct, id: string, config: AwsSlotTypeConfig);
    private _botId?;
    get botId(): string;
    set botId(value: string);
    get botIdInput(): string | undefined;
    private _botVersion?;
    get botVersion(): string;
    set botVersion(value: string);
    get botVersionInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _localeId?;
    get localeId(): string;
    set localeId(value: string);
    get localeIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parentSlotTypeSignature?;
    get parentSlotTypeSignature(): string;
    set parentSlotTypeSignature(value: string);
    resetParentSlotTypeSignature(): void;
    get parentSlotTypeSignatureInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get slotTypeId(): string;
    private _compositeSlotTypeSetting;
    get compositeSlotTypeSetting(): AwsSlotType.CompositeSlotTypeSettingPropertyList;
    putCompositeSlotTypeSetting(value: AwsSlotType.CompositeSlotTypeSettingProperty[] | cdktn.IResolvable): void;
    resetCompositeSlotTypeSetting(): void;
    get compositeSlotTypeSettingInput(): cdktn.IResolvable | AwsSlotType.CompositeSlotTypeSettingProperty[] | undefined;
    private _externalSourceSetting;
    get externalSourceSetting(): AwsSlotType.ExternalSourceSettingPropertyList;
    putExternalSourceSetting(value: AwsSlotType.ExternalSourceSettingProperty[] | cdktn.IResolvable): void;
    resetExternalSourceSetting(): void;
    get externalSourceSettingInput(): cdktn.IResolvable | AwsSlotType.ExternalSourceSettingProperty[] | undefined;
    private _slotTypeValues;
    get slotTypeValues(): AwsSlotType.SlotTypeValuesPropertyList;
    putSlotTypeValues(value: AwsSlotType.SlotTypeValuesProperty[] | cdktn.IResolvable): void;
    resetSlotTypeValues(): void;
    get slotTypeValuesInput(): cdktn.IResolvable | AwsSlotType.SlotTypeValuesProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsSlotType.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsSlotType.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsSlotType.TimeoutsProperty | undefined;
    private _valueSelectionSetting;
    get valueSelectionSetting(): AwsSlotType.ValueSelectionSettingPropertyList;
    putValueSelectionSetting(value: AwsSlotType.ValueSelectionSettingProperty[] | cdktn.IResolvable): void;
    resetValueSelectionSetting(): void;
    get valueSelectionSettingInput(): cdktn.IResolvable | AwsSlotType.ValueSelectionSettingProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsSlotTypeSubSlotsPropertyToTerraform(struct?: AwsSlotType.SubSlotsProperty | cdktn.IResolvable): any;
export declare function awsSlotTypeSubSlotsPropertyToHclTerraform(struct?: AwsSlotType.SubSlotsProperty | cdktn.IResolvable): any;
export declare function awsSlotTypeCompositeSlotTypeSettingPropertyToTerraform(struct?: AwsSlotType.CompositeSlotTypeSettingProperty | cdktn.IResolvable): any;
export declare function awsSlotTypeCompositeSlotTypeSettingPropertyToHclTerraform(struct?: AwsSlotType.CompositeSlotTypeSettingProperty | cdktn.IResolvable): any;
export declare function awsSlotTypeSourcePropertyToTerraform(struct?: AwsSlotType.SourceProperty | cdktn.IResolvable): any;
export declare function awsSlotTypeSourcePropertyToHclTerraform(struct?: AwsSlotType.SourceProperty | cdktn.IResolvable): any;
export declare function awsSlotTypeGrammarSlotTypeSettingPropertyToTerraform(struct?: AwsSlotType.GrammarSlotTypeSettingProperty | cdktn.IResolvable): any;
export declare function awsSlotTypeGrammarSlotTypeSettingPropertyToHclTerraform(struct?: AwsSlotType.GrammarSlotTypeSettingProperty | cdktn.IResolvable): any;
export declare function awsSlotTypeExternalSourceSettingPropertyToTerraform(struct?: AwsSlotType.ExternalSourceSettingProperty | cdktn.IResolvable): any;
export declare function awsSlotTypeExternalSourceSettingPropertyToHclTerraform(struct?: AwsSlotType.ExternalSourceSettingProperty | cdktn.IResolvable): any;
export declare function awsSlotTypeSampleValuePropertyToTerraform(struct?: AwsSlotType.SampleValueProperty | cdktn.IResolvable): any;
export declare function awsSlotTypeSampleValuePropertyToHclTerraform(struct?: AwsSlotType.SampleValueProperty | cdktn.IResolvable): any;
export declare function awsSlotTypeSynonymsPropertyToTerraform(struct?: AwsSlotType.SynonymsProperty | cdktn.IResolvable): any;
export declare function awsSlotTypeSynonymsPropertyToHclTerraform(struct?: AwsSlotType.SynonymsProperty | cdktn.IResolvable): any;
export declare function awsSlotTypeSlotTypeValuesPropertyToTerraform(struct?: AwsSlotType.SlotTypeValuesProperty | cdktn.IResolvable): any;
export declare function awsSlotTypeSlotTypeValuesPropertyToHclTerraform(struct?: AwsSlotType.SlotTypeValuesProperty | cdktn.IResolvable): any;
export declare function awsSlotTypeTimeoutsPropertyToTerraform(struct?: AwsSlotType.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsSlotTypeTimeoutsPropertyToHclTerraform(struct?: AwsSlotType.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsSlotTypeAdvancedRecognitionSettingPropertyToTerraform(struct?: AwsSlotType.AdvancedRecognitionSettingProperty | cdktn.IResolvable): any;
export declare function awsSlotTypeAdvancedRecognitionSettingPropertyToHclTerraform(struct?: AwsSlotType.AdvancedRecognitionSettingProperty | cdktn.IResolvable): any;
export declare function awsSlotTypeRegexFilterPropertyToTerraform(struct?: AwsSlotType.RegexFilterProperty | cdktn.IResolvable): any;
export declare function awsSlotTypeRegexFilterPropertyToHclTerraform(struct?: AwsSlotType.RegexFilterProperty | cdktn.IResolvable): any;
export declare function awsSlotTypeValueSelectionSettingPropertyToTerraform(struct?: AwsSlotType.ValueSelectionSettingProperty | cdktn.IResolvable): any;
export declare function awsSlotTypeValueSelectionSettingPropertyToHclTerraform(struct?: AwsSlotType.ValueSelectionSettingProperty | cdktn.IResolvable): any;
export declare namespace AwsSlotType {
    interface SubSlotsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_slot_type#name AwsSlotType#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_slot_type#slot_type_id AwsSlotType#slot_type_id}
        */
        readonly slotTypeId: string;
    }
    class SubSlotsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SubSlotsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SubSlotsProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _slotTypeId?;
        get slotTypeId(): string;
        set slotTypeId(value: string);
        get slotTypeIdInput(): string | undefined;
    }
    class SubSlotsPropertyList extends cdktn.ComplexList {
        internalValue?: SubSlotsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SubSlotsPropertyOutputReference;
    }
    interface CompositeSlotTypeSettingProperty {
        /**
        * sub_slots block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_slot_type#sub_slots AwsSlotType#sub_slots}
        */
        readonly subSlots?: SubSlotsProperty[] | cdktn.IResolvable;
    }
    class CompositeSlotTypeSettingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CompositeSlotTypeSettingProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CompositeSlotTypeSettingProperty | cdktn.IResolvable | undefined);
        private _subSlots;
        get subSlots(): SubSlotsPropertyList;
        putSubSlots(value: SubSlotsProperty[] | cdktn.IResolvable): void;
        resetSubSlots(): void;
        get subSlotsInput(): cdktn.IResolvable | SubSlotsProperty[] | undefined;
    }
    class CompositeSlotTypeSettingPropertyList extends cdktn.ComplexList {
        internalValue?: CompositeSlotTypeSettingProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CompositeSlotTypeSettingPropertyOutputReference;
    }
    interface SourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_slot_type#kms_key_arn AwsSlotType#kms_key_arn}
        */
        readonly kmsKeyArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_slot_type#s3_bucket_name AwsSlotType#s3_bucket_name}
        */
        readonly s3BucketName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_slot_type#s3_object_key AwsSlotType#s3_object_key}
        */
        readonly s3ObjectKey: string;
    }
    class SourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SourceProperty | cdktn.IResolvable | undefined);
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        get kmsKeyArnInput(): string | undefined;
        private _s3BucketName?;
        get s3BucketName(): string;
        set s3BucketName(value: string);
        get s3BucketNameInput(): string | undefined;
        private _s3ObjectKey?;
        get s3ObjectKey(): string;
        set s3ObjectKey(value: string);
        get s3ObjectKeyInput(): string | undefined;
    }
    class SourcePropertyList extends cdktn.ComplexList {
        internalValue?: SourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SourcePropertyOutputReference;
    }
    interface GrammarSlotTypeSettingProperty {
        /**
        * source block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_slot_type#source AwsSlotType#source}
        */
        readonly source?: SourceProperty[] | cdktn.IResolvable;
    }
    class GrammarSlotTypeSettingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GrammarSlotTypeSettingProperty | cdktn.IResolvable | undefined;
        set internalValue(value: GrammarSlotTypeSettingProperty | cdktn.IResolvable | undefined);
        private _source;
        get source(): SourcePropertyList;
        putSource(value: SourceProperty[] | cdktn.IResolvable): void;
        resetSource(): void;
        get sourceInput(): cdktn.IResolvable | SourceProperty[] | undefined;
    }
    class GrammarSlotTypeSettingPropertyList extends cdktn.ComplexList {
        internalValue?: GrammarSlotTypeSettingProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GrammarSlotTypeSettingPropertyOutputReference;
    }
    interface ExternalSourceSettingProperty {
        /**
        * grammar_slot_type_setting block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_slot_type#grammar_slot_type_setting AwsSlotType#grammar_slot_type_setting}
        */
        readonly grammarSlotTypeSetting?: GrammarSlotTypeSettingProperty[] | cdktn.IResolvable;
    }
    class ExternalSourceSettingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExternalSourceSettingProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ExternalSourceSettingProperty | cdktn.IResolvable | undefined);
        private _grammarSlotTypeSetting;
        get grammarSlotTypeSetting(): GrammarSlotTypeSettingPropertyList;
        putGrammarSlotTypeSetting(value: GrammarSlotTypeSettingProperty[] | cdktn.IResolvable): void;
        resetGrammarSlotTypeSetting(): void;
        get grammarSlotTypeSettingInput(): cdktn.IResolvable | GrammarSlotTypeSettingProperty[] | undefined;
    }
    class ExternalSourceSettingPropertyList extends cdktn.ComplexList {
        internalValue?: ExternalSourceSettingProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExternalSourceSettingPropertyOutputReference;
    }
    interface SampleValueProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_slot_type#value AwsSlotType#value}
        */
        readonly value: string;
    }
    class SampleValuePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SampleValueProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SampleValueProperty | cdktn.IResolvable | undefined);
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class SampleValuePropertyList extends cdktn.ComplexList {
        internalValue?: SampleValueProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SampleValuePropertyOutputReference;
    }
    interface SynonymsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_slot_type#value AwsSlotType#value}
        */
        readonly value: string;
    }
    class SynonymsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SynonymsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SynonymsProperty | cdktn.IResolvable | undefined);
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class SynonymsPropertyList extends cdktn.ComplexList {
        internalValue?: SynonymsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SynonymsPropertyOutputReference;
    }
    interface SlotTypeValuesProperty {
        /**
        * sample_value block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_slot_type#sample_value AwsSlotType#sample_value}
        */
        readonly sampleValue?: SampleValueProperty[] | cdktn.IResolvable;
        /**
        * synonyms block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_slot_type#synonyms AwsSlotType#synonyms}
        */
        readonly synonyms?: SynonymsProperty[] | cdktn.IResolvable;
    }
    class SlotTypeValuesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SlotTypeValuesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SlotTypeValuesProperty | cdktn.IResolvable | undefined);
        private _sampleValue;
        get sampleValue(): SampleValuePropertyList;
        putSampleValue(value: SampleValueProperty[] | cdktn.IResolvable): void;
        resetSampleValue(): void;
        get sampleValueInput(): cdktn.IResolvable | SampleValueProperty[] | undefined;
        private _synonyms;
        get synonyms(): SynonymsPropertyList;
        putSynonyms(value: SynonymsProperty[] | cdktn.IResolvable): void;
        resetSynonyms(): void;
        get synonymsInput(): cdktn.IResolvable | SynonymsProperty[] | undefined;
    }
    class SlotTypeValuesPropertyList extends cdktn.ComplexList {
        internalValue?: SlotTypeValuesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SlotTypeValuesPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_slot_type#create AwsSlotType#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_slot_type#delete AwsSlotType#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_slot_type#update AwsSlotType#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface AdvancedRecognitionSettingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_slot_type#audio_recognition_strategy AwsSlotType#audio_recognition_strategy}
        */
        readonly audioRecognitionStrategy?: string;
    }
    class AdvancedRecognitionSettingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AdvancedRecognitionSettingProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AdvancedRecognitionSettingProperty | cdktn.IResolvable | undefined);
        private _audioRecognitionStrategy?;
        get audioRecognitionStrategy(): string;
        set audioRecognitionStrategy(value: string);
        resetAudioRecognitionStrategy(): void;
        get audioRecognitionStrategyInput(): string | undefined;
    }
    class AdvancedRecognitionSettingPropertyList extends cdktn.ComplexList {
        internalValue?: AdvancedRecognitionSettingProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AdvancedRecognitionSettingPropertyOutputReference;
    }
    interface RegexFilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_slot_type#pattern AwsSlotType#pattern}
        */
        readonly pattern: string;
    }
    class RegexFilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RegexFilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RegexFilterProperty | cdktn.IResolvable | undefined);
        private _pattern?;
        get pattern(): string;
        set pattern(value: string);
        get patternInput(): string | undefined;
    }
    class RegexFilterPropertyList extends cdktn.ComplexList {
        internalValue?: RegexFilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RegexFilterPropertyOutputReference;
    }
    interface ValueSelectionSettingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_slot_type#resolution_strategy AwsSlotType#resolution_strategy}
        */
        readonly resolutionStrategy: string;
        /**
        * advanced_recognition_setting block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_slot_type#advanced_recognition_setting AwsSlotType#advanced_recognition_setting}
        */
        readonly advancedRecognitionSetting?: AdvancedRecognitionSettingProperty[] | cdktn.IResolvable;
        /**
        * regex_filter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_slot_type#regex_filter AwsSlotType#regex_filter}
        */
        readonly regexFilter?: RegexFilterProperty[] | cdktn.IResolvable;
    }
    class ValueSelectionSettingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ValueSelectionSettingProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ValueSelectionSettingProperty | cdktn.IResolvable | undefined);
        private _resolutionStrategy?;
        get resolutionStrategy(): string;
        set resolutionStrategy(value: string);
        get resolutionStrategyInput(): string | undefined;
        private _advancedRecognitionSetting;
        get advancedRecognitionSetting(): AdvancedRecognitionSettingPropertyList;
        putAdvancedRecognitionSetting(value: AdvancedRecognitionSettingProperty[] | cdktn.IResolvable): void;
        resetAdvancedRecognitionSetting(): void;
        get advancedRecognitionSettingInput(): cdktn.IResolvable | AdvancedRecognitionSettingProperty[] | undefined;
        private _regexFilter;
        get regexFilter(): RegexFilterPropertyList;
        putRegexFilter(value: RegexFilterProperty[] | cdktn.IResolvable): void;
        resetRegexFilter(): void;
        get regexFilterInput(): cdktn.IResolvable | RegexFilterProperty[] | undefined;
    }
    class ValueSelectionSettingPropertyList extends cdktn.ComplexList {
        internalValue?: ValueSelectionSettingProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ValueSelectionSettingPropertyOutputReference;
    }
}
