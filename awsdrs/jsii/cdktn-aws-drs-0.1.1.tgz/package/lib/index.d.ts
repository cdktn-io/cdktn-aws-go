export * from './aws-drs-replication-configuration-template';
