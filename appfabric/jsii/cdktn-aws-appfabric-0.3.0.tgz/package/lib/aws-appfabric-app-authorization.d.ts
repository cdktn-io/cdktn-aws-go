import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAppAuthorizationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_app_authorization#app AwsAppAuthorization#app}
    */
    readonly app: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_app_authorization#app_bundle_arn AwsAppAuthorization#app_bundle_arn}
    */
    readonly appBundleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_app_authorization#auth_type AwsAppAuthorization#auth_type}
    */
    readonly authType: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_app_authorization#region AwsAppAuthorization#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_app_authorization#tags AwsAppAuthorization#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * credential block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_app_authorization#credential AwsAppAuthorization#credential}
    */
    readonly credential?: AwsAppAuthorization.CredentialProperty[] | cdktn.IResolvable;
    /**
    * tenant block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_app_authorization#tenant AwsAppAuthorization#tenant}
    */
    readonly tenant?: AwsAppAuthorization.TenantProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_app_authorization#timeouts AwsAppAuthorization#timeouts}
    */
    readonly timeouts?: AwsAppAuthorization.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_app_authorization aws_appfabric_app_authorization}
*/
export declare class AwsAppAuthorization extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_appfabric_app_authorization";
    /**
    * Generates CDKTN code for importing a AwsAppAuthorization resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsAppAuthorization to import
    * @param importFromId The id of the existing AwsAppAuthorization that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_app_authorization#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsAppAuthorization to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_app_authorization aws_appfabric_app_authorization} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAppAuthorizationConfig
    */
    constructor(scope: Construct, id: string, config: AwsAppAuthorizationConfig);
    private _app?;
    get app(): string;
    set app(value: string);
    get appInput(): string | undefined;
    private _appBundleArn?;
    get appBundleArn(): string;
    set appBundleArn(value: string);
    get appBundleArnInput(): string | undefined;
    get arn(): string;
    private _authType?;
    get authType(): string;
    set authType(value: string);
    get authTypeInput(): string | undefined;
    get authUrl(): string;
    get createdAt(): string;
    get id(): string;
    get persona(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    get updatedAt(): string;
    private _credential;
    get credential(): AwsAppAuthorization.CredentialPropertyList;
    putCredential(value: AwsAppAuthorization.CredentialProperty[] | cdktn.IResolvable): void;
    resetCredential(): void;
    get credentialInput(): cdktn.IResolvable | AwsAppAuthorization.CredentialProperty[] | undefined;
    private _tenant;
    get tenant(): AwsAppAuthorization.TenantPropertyList;
    putTenant(value: AwsAppAuthorization.TenantProperty[] | cdktn.IResolvable): void;
    resetTenant(): void;
    get tenantInput(): cdktn.IResolvable | AwsAppAuthorization.TenantProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsAppAuthorization.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsAppAuthorization.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsAppAuthorization.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsAppAuthorizationApiKeyCredentialPropertyToTerraform(struct?: AwsAppAuthorization.ApiKeyCredentialProperty | cdktn.IResolvable): any;
export declare function awsAppAuthorizationApiKeyCredentialPropertyToHclTerraform(struct?: AwsAppAuthorization.ApiKeyCredentialProperty | cdktn.IResolvable): any;
export declare function awsAppAuthorizationOauth2CredentialPropertyToTerraform(struct?: AwsAppAuthorization.Oauth2CredentialProperty | cdktn.IResolvable): any;
export declare function awsAppAuthorizationOauth2CredentialPropertyToHclTerraform(struct?: AwsAppAuthorization.Oauth2CredentialProperty | cdktn.IResolvable): any;
export declare function awsAppAuthorizationCredentialPropertyToTerraform(struct?: AwsAppAuthorization.CredentialProperty | cdktn.IResolvable): any;
export declare function awsAppAuthorizationCredentialPropertyToHclTerraform(struct?: AwsAppAuthorization.CredentialProperty | cdktn.IResolvable): any;
export declare function awsAppAuthorizationTenantPropertyToTerraform(struct?: AwsAppAuthorization.TenantProperty | cdktn.IResolvable): any;
export declare function awsAppAuthorizationTenantPropertyToHclTerraform(struct?: AwsAppAuthorization.TenantProperty | cdktn.IResolvable): any;
export declare function awsAppAuthorizationTimeoutsPropertyToTerraform(struct?: AwsAppAuthorization.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsAppAuthorizationTimeoutsPropertyToHclTerraform(struct?: AwsAppAuthorization.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsAppAuthorization {
    interface ApiKeyCredentialProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_app_authorization#api_key AwsAppAuthorization#api_key}
        */
        readonly apiKey: string;
    }
    class ApiKeyCredentialPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ApiKeyCredentialProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ApiKeyCredentialProperty | cdktn.IResolvable | undefined);
        private _apiKey?;
        get apiKey(): string;
        set apiKey(value: string);
        get apiKeyInput(): string | undefined;
    }
    class ApiKeyCredentialPropertyList extends cdktn.ComplexList {
        internalValue?: ApiKeyCredentialProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ApiKeyCredentialPropertyOutputReference;
    }
    interface Oauth2CredentialProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_app_authorization#client_id AwsAppAuthorization#client_id}
        */
        readonly clientId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_app_authorization#client_secret AwsAppAuthorization#client_secret}
        */
        readonly clientSecret: string;
    }
    class Oauth2CredentialPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): Oauth2CredentialProperty | cdktn.IResolvable | undefined;
        set internalValue(value: Oauth2CredentialProperty | cdktn.IResolvable | undefined);
        private _clientId?;
        get clientId(): string;
        set clientId(value: string);
        get clientIdInput(): string | undefined;
        private _clientSecret?;
        get clientSecret(): string;
        set clientSecret(value: string);
        get clientSecretInput(): string | undefined;
    }
    class Oauth2CredentialPropertyList extends cdktn.ComplexList {
        internalValue?: Oauth2CredentialProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): Oauth2CredentialPropertyOutputReference;
    }
    interface CredentialProperty {
        /**
        * api_key_credential block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_app_authorization#api_key_credential AwsAppAuthorization#api_key_credential}
        */
        readonly apiKeyCredential?: ApiKeyCredentialProperty[] | cdktn.IResolvable;
        /**
        * oauth2_credential block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_app_authorization#oauth2_credential AwsAppAuthorization#oauth2_credential}
        */
        readonly oauth2Credential?: Oauth2CredentialProperty[] | cdktn.IResolvable;
    }
    class CredentialPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CredentialProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CredentialProperty | cdktn.IResolvable | undefined);
        private _apiKeyCredential;
        get apiKeyCredential(): ApiKeyCredentialPropertyList;
        putApiKeyCredential(value: ApiKeyCredentialProperty[] | cdktn.IResolvable): void;
        resetApiKeyCredential(): void;
        get apiKeyCredentialInput(): cdktn.IResolvable | ApiKeyCredentialProperty[] | undefined;
        private _oauth2Credential;
        get oauth2Credential(): Oauth2CredentialPropertyList;
        putOauth2Credential(value: Oauth2CredentialProperty[] | cdktn.IResolvable): void;
        resetOauth2Credential(): void;
        get oauth2CredentialInput(): cdktn.IResolvable | Oauth2CredentialProperty[] | undefined;
    }
    class CredentialPropertyList extends cdktn.ComplexList {
        internalValue?: CredentialProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CredentialPropertyOutputReference;
    }
    interface TenantProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_app_authorization#tenant_display_name AwsAppAuthorization#tenant_display_name}
        */
        readonly tenantDisplayName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_app_authorization#tenant_identifier AwsAppAuthorization#tenant_identifier}
        */
        readonly tenantIdentifier: string;
    }
    class TenantPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TenantProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TenantProperty | cdktn.IResolvable | undefined);
        private _tenantDisplayName?;
        get tenantDisplayName(): string;
        set tenantDisplayName(value: string);
        get tenantDisplayNameInput(): string | undefined;
        private _tenantIdentifier?;
        get tenantIdentifier(): string;
        set tenantIdentifier(value: string);
        get tenantIdentifierInput(): string | undefined;
    }
    class TenantPropertyList extends cdktn.ComplexList {
        internalValue?: TenantProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TenantPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_app_authorization#create AwsAppAuthorization#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_app_authorization#delete AwsAppAuthorization#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_app_authorization#update AwsAppAuthorization#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
