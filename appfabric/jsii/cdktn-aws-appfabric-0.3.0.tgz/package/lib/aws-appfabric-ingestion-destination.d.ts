import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsIngestionDestinationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_ingestion_destination#app_bundle_arn AwsIngestionDestination#app_bundle_arn}
    */
    readonly appBundleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_ingestion_destination#ingestion_arn AwsIngestionDestination#ingestion_arn}
    */
    readonly ingestionArn: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_ingestion_destination#region AwsIngestionDestination#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_ingestion_destination#tags AwsIngestionDestination#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * destination_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_ingestion_destination#destination_configuration AwsIngestionDestination#destination_configuration}
    */
    readonly destinationConfiguration?: AwsIngestionDestination.DestinationConfigurationProperty[] | cdktn.IResolvable;
    /**
    * processing_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_ingestion_destination#processing_configuration AwsIngestionDestination#processing_configuration}
    */
    readonly processingConfiguration?: AwsIngestionDestination.ProcessingConfigurationProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_ingestion_destination#timeouts AwsIngestionDestination#timeouts}
    */
    readonly timeouts?: AwsIngestionDestination.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_ingestion_destination aws_appfabric_ingestion_destination}
*/
export declare class AwsIngestionDestination extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_appfabric_ingestion_destination";
    /**
    * Generates CDKTN code for importing a AwsIngestionDestination resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsIngestionDestination to import
    * @param importFromId The id of the existing AwsIngestionDestination that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_ingestion_destination#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsIngestionDestination to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_ingestion_destination aws_appfabric_ingestion_destination} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsIngestionDestinationConfig
    */
    constructor(scope: Construct, id: string, config: AwsIngestionDestinationConfig);
    private _appBundleArn?;
    get appBundleArn(): string;
    set appBundleArn(value: string);
    get appBundleArnInput(): string | undefined;
    get arn(): string;
    get id(): string;
    private _ingestionArn?;
    get ingestionArn(): string;
    set ingestionArn(value: string);
    get ingestionArnInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _destinationConfiguration;
    get destinationConfiguration(): AwsIngestionDestination.DestinationConfigurationPropertyList;
    putDestinationConfiguration(value: AwsIngestionDestination.DestinationConfigurationProperty[] | cdktn.IResolvable): void;
    resetDestinationConfiguration(): void;
    get destinationConfigurationInput(): cdktn.IResolvable | AwsIngestionDestination.DestinationConfigurationProperty[] | undefined;
    private _processingConfiguration;
    get processingConfiguration(): AwsIngestionDestination.ProcessingConfigurationPropertyList;
    putProcessingConfiguration(value: AwsIngestionDestination.ProcessingConfigurationProperty[] | cdktn.IResolvable): void;
    resetProcessingConfiguration(): void;
    get processingConfigurationInput(): cdktn.IResolvable | AwsIngestionDestination.ProcessingConfigurationProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsIngestionDestination.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsIngestionDestination.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsIngestionDestination.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsIngestionDestinationFirehoseStreamPropertyToTerraform(struct?: AwsIngestionDestination.FirehoseStreamProperty | cdktn.IResolvable): any;
export declare function awsIngestionDestinationFirehoseStreamPropertyToHclTerraform(struct?: AwsIngestionDestination.FirehoseStreamProperty | cdktn.IResolvable): any;
export declare function awsIngestionDestinationS3BucketPropertyToTerraform(struct?: AwsIngestionDestination.S3BucketProperty | cdktn.IResolvable): any;
export declare function awsIngestionDestinationS3BucketPropertyToHclTerraform(struct?: AwsIngestionDestination.S3BucketProperty | cdktn.IResolvable): any;
export declare function awsIngestionDestinationDestinationPropertyToTerraform(struct?: AwsIngestionDestination.DestinationProperty | cdktn.IResolvable): any;
export declare function awsIngestionDestinationDestinationPropertyToHclTerraform(struct?: AwsIngestionDestination.DestinationProperty | cdktn.IResolvable): any;
export declare function awsIngestionDestinationDestinationConfigurationAuditLogPropertyToTerraform(struct?: AwsIngestionDestination.DestinationConfigurationAuditLogProperty | cdktn.IResolvable): any;
export declare function awsIngestionDestinationDestinationConfigurationAuditLogPropertyToHclTerraform(struct?: AwsIngestionDestination.DestinationConfigurationAuditLogProperty | cdktn.IResolvable): any;
export declare function awsIngestionDestinationDestinationConfigurationPropertyToTerraform(struct?: AwsIngestionDestination.DestinationConfigurationProperty | cdktn.IResolvable): any;
export declare function awsIngestionDestinationDestinationConfigurationPropertyToHclTerraform(struct?: AwsIngestionDestination.DestinationConfigurationProperty | cdktn.IResolvable): any;
export declare function awsIngestionDestinationProcessingConfigurationAuditLogPropertyToTerraform(struct?: AwsIngestionDestination.ProcessingConfigurationAuditLogProperty | cdktn.IResolvable): any;
export declare function awsIngestionDestinationProcessingConfigurationAuditLogPropertyToHclTerraform(struct?: AwsIngestionDestination.ProcessingConfigurationAuditLogProperty | cdktn.IResolvable): any;
export declare function awsIngestionDestinationProcessingConfigurationPropertyToTerraform(struct?: AwsIngestionDestination.ProcessingConfigurationProperty | cdktn.IResolvable): any;
export declare function awsIngestionDestinationProcessingConfigurationPropertyToHclTerraform(struct?: AwsIngestionDestination.ProcessingConfigurationProperty | cdktn.IResolvable): any;
export declare function awsIngestionDestinationTimeoutsPropertyToTerraform(struct?: AwsIngestionDestination.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsIngestionDestinationTimeoutsPropertyToHclTerraform(struct?: AwsIngestionDestination.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsIngestionDestination {
    interface FirehoseStreamProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_ingestion_destination#stream_name AwsIngestionDestination#stream_name}
        */
        readonly streamName: string;
    }
    class FirehoseStreamPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FirehoseStreamProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FirehoseStreamProperty | cdktn.IResolvable | undefined);
        private _streamName?;
        get streamName(): string;
        set streamName(value: string);
        get streamNameInput(): string | undefined;
    }
    class FirehoseStreamPropertyList extends cdktn.ComplexList {
        internalValue?: FirehoseStreamProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FirehoseStreamPropertyOutputReference;
    }
    interface S3BucketProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_ingestion_destination#bucket_name AwsIngestionDestination#bucket_name}
        */
        readonly bucketName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_ingestion_destination#prefix AwsIngestionDestination#prefix}
        */
        readonly prefix?: string;
    }
    class S3BucketPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3BucketProperty | cdktn.IResolvable | undefined;
        set internalValue(value: S3BucketProperty | cdktn.IResolvable | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        get bucketNameInput(): string | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
    }
    class S3BucketPropertyList extends cdktn.ComplexList {
        internalValue?: S3BucketProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3BucketPropertyOutputReference;
    }
    interface DestinationProperty {
        /**
        * firehose_stream block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_ingestion_destination#firehose_stream AwsIngestionDestination#firehose_stream}
        */
        readonly firehoseStream?: FirehoseStreamProperty[] | cdktn.IResolvable;
        /**
        * s3_bucket block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_ingestion_destination#s3_bucket AwsIngestionDestination#s3_bucket}
        */
        readonly s3Bucket?: S3BucketProperty[] | cdktn.IResolvable;
    }
    class DestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DestinationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DestinationProperty | cdktn.IResolvable | undefined);
        private _firehoseStream;
        get firehoseStream(): FirehoseStreamPropertyList;
        putFirehoseStream(value: FirehoseStreamProperty[] | cdktn.IResolvable): void;
        resetFirehoseStream(): void;
        get firehoseStreamInput(): cdktn.IResolvable | FirehoseStreamProperty[] | undefined;
        private _s3Bucket;
        get s3Bucket(): S3BucketPropertyList;
        putS3Bucket(value: S3BucketProperty[] | cdktn.IResolvable): void;
        resetS3Bucket(): void;
        get s3BucketInput(): cdktn.IResolvable | S3BucketProperty[] | undefined;
    }
    class DestinationPropertyList extends cdktn.ComplexList {
        internalValue?: DestinationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DestinationPropertyOutputReference;
    }
    interface DestinationConfigurationAuditLogProperty {
        /**
        * destination block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_ingestion_destination#destination AwsIngestionDestination#destination}
        */
        readonly destination?: DestinationProperty[] | cdktn.IResolvable;
    }
    class DestinationConfigurationAuditLogPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DestinationConfigurationAuditLogProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DestinationConfigurationAuditLogProperty | cdktn.IResolvable | undefined);
        private _destination;
        get destination(): DestinationPropertyList;
        putDestination(value: DestinationProperty[] | cdktn.IResolvable): void;
        resetDestination(): void;
        get destinationInput(): cdktn.IResolvable | DestinationProperty[] | undefined;
    }
    class DestinationConfigurationAuditLogPropertyList extends cdktn.ComplexList {
        internalValue?: DestinationConfigurationAuditLogProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DestinationConfigurationAuditLogPropertyOutputReference;
    }
    interface DestinationConfigurationProperty {
        /**
        * audit_log block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_ingestion_destination#audit_log AwsIngestionDestination#audit_log}
        */
        readonly auditLog?: DestinationConfigurationAuditLogProperty[] | cdktn.IResolvable;
    }
    class DestinationConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DestinationConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DestinationConfigurationProperty | cdktn.IResolvable | undefined);
        private _auditLog;
        get auditLog(): DestinationConfigurationAuditLogPropertyList;
        putAuditLog(value: DestinationConfigurationAuditLogProperty[] | cdktn.IResolvable): void;
        resetAuditLog(): void;
        get auditLogInput(): cdktn.IResolvable | DestinationConfigurationAuditLogProperty[] | undefined;
    }
    class DestinationConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: DestinationConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DestinationConfigurationPropertyOutputReference;
    }
    interface ProcessingConfigurationAuditLogProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_ingestion_destination#format AwsIngestionDestination#format}
        */
        readonly format: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_ingestion_destination#schema AwsIngestionDestination#schema}
        */
        readonly schema: string;
    }
    class ProcessingConfigurationAuditLogPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ProcessingConfigurationAuditLogProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ProcessingConfigurationAuditLogProperty | cdktn.IResolvable | undefined);
        private _format?;
        get format(): string;
        set format(value: string);
        get formatInput(): string | undefined;
        private _schema?;
        get schema(): string;
        set schema(value: string);
        get schemaInput(): string | undefined;
    }
    class ProcessingConfigurationAuditLogPropertyList extends cdktn.ComplexList {
        internalValue?: ProcessingConfigurationAuditLogProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ProcessingConfigurationAuditLogPropertyOutputReference;
    }
    interface ProcessingConfigurationProperty {
        /**
        * audit_log block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_ingestion_destination#audit_log AwsIngestionDestination#audit_log}
        */
        readonly auditLog?: ProcessingConfigurationAuditLogProperty[] | cdktn.IResolvable;
    }
    class ProcessingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ProcessingConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ProcessingConfigurationProperty | cdktn.IResolvable | undefined);
        private _auditLog;
        get auditLog(): ProcessingConfigurationAuditLogPropertyList;
        putAuditLog(value: ProcessingConfigurationAuditLogProperty[] | cdktn.IResolvable): void;
        resetAuditLog(): void;
        get auditLogInput(): cdktn.IResolvable | ProcessingConfigurationAuditLogProperty[] | undefined;
    }
    class ProcessingConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: ProcessingConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ProcessingConfigurationPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_ingestion_destination#create AwsIngestionDestination#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_ingestion_destination#delete AwsIngestionDestination#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_ingestion_destination#update AwsIngestionDestination#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
