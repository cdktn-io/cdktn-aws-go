import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAppBundleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_app_bundle#customer_managed_key_arn AwsAppBundle#customer_managed_key_arn}
    */
    readonly customerManagedKeyArn?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_app_bundle#region AwsAppBundle#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_app_bundle#tags AwsAppBundle#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_app_bundle aws_appfabric_app_bundle}
*/
export declare class AwsAppBundle extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_appfabric_app_bundle";
    /**
    * Generates CDKTN code for importing a AwsAppBundle resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsAppBundle to import
    * @param importFromId The id of the existing AwsAppBundle that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_app_bundle#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsAppBundle to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_app_bundle aws_appfabric_app_bundle} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAppBundleConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AwsAppBundleConfig);
    get arn(): string;
    private _customerManagedKeyArn?;
    get customerManagedKeyArn(): string;
    set customerManagedKeyArn(value: string);
    resetCustomerManagedKeyArn(): void;
    get customerManagedKeyArnInput(): string | undefined;
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
