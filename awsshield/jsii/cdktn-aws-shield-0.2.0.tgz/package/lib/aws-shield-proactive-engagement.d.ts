import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfProactiveEngagementConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_proactive_engagement#enabled TfProactiveEngagement#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * emergency_contact block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_proactive_engagement#emergency_contact TfProactiveEngagement#emergency_contact}
    */
    readonly emergencyContact?: TfProactiveEngagement.EmergencyContactProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_proactive_engagement aws_shield_proactive_engagement}
*/
export declare class TfProactiveEngagement extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_shield_proactive_engagement";
    /**
    * Generates CDKTN code for importing a TfProactiveEngagement resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfProactiveEngagement to import
    * @param importFromId The id of the existing TfProactiveEngagement that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_proactive_engagement#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfProactiveEngagement to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_proactive_engagement aws_shield_proactive_engagement} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfProactiveEngagementConfig
    */
    constructor(scope: Construct, id: string, config: TfProactiveEngagementConfig);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    private _emergencyContact;
    get emergencyContact(): TfProactiveEngagement.EmergencyContactPropertyList;
    putEmergencyContact(value: TfProactiveEngagement.EmergencyContactProperty[] | cdktn.IResolvable): void;
    resetEmergencyContact(): void;
    get emergencyContactInput(): cdktn.IResolvable | TfProactiveEngagement.EmergencyContactProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfProactiveEngagementEmergencyContactPropertyToTerraform(struct?: TfProactiveEngagement.EmergencyContactProperty | cdktn.IResolvable): any;
export declare function tfProactiveEngagementEmergencyContactPropertyToHclTerraform(struct?: TfProactiveEngagement.EmergencyContactProperty | cdktn.IResolvable): any;
export declare namespace TfProactiveEngagement {
    interface EmergencyContactProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_proactive_engagement#contact_notes TfProactiveEngagement#contact_notes}
        */
        readonly contactNotes?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_proactive_engagement#email_address TfProactiveEngagement#email_address}
        */
        readonly emailAddress: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_proactive_engagement#phone_number TfProactiveEngagement#phone_number}
        */
        readonly phoneNumber?: string;
    }
    class EmergencyContactPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EmergencyContactProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EmergencyContactProperty | cdktn.IResolvable | undefined);
        private _contactNotes?;
        get contactNotes(): string;
        set contactNotes(value: string);
        resetContactNotes(): void;
        get contactNotesInput(): string | undefined;
        private _emailAddress?;
        get emailAddress(): string;
        set emailAddress(value: string);
        get emailAddressInput(): string | undefined;
        private _phoneNumber?;
        get phoneNumber(): string;
        set phoneNumber(value: string);
        resetPhoneNumber(): void;
        get phoneNumberInput(): string | undefined;
    }
    class EmergencyContactPropertyList extends cdktn.ComplexList {
        internalValue?: EmergencyContactProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EmergencyContactPropertyOutputReference;
    }
}
