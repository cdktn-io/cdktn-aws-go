import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfSubscriptionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether to automatically renew the subscription when it expires.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_subscription#auto_renew TfSubscription#auto_renew}
    */
    readonly autoRenew?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_subscription#skip_destroy TfSubscription#skip_destroy}
    */
    readonly skipDestroy?: boolean | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_subscription aws_shield_subscription}
*/
export declare class TfSubscription extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_shield_subscription";
    /**
    * Generates CDKTN code for importing a TfSubscription resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfSubscription to import
    * @param importFromId The id of the existing TfSubscription that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_subscription#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfSubscription to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_subscription aws_shield_subscription} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfSubscriptionConfig = {}
    */
    constructor(scope: Construct, id: string, config?: TfSubscriptionConfig);
    private _autoRenew?;
    get autoRenew(): string;
    set autoRenew(value: string);
    resetAutoRenew(): void;
    get autoRenewInput(): string | undefined;
    get id(): string;
    private _skipDestroy?;
    get skipDestroy(): boolean | cdktn.IResolvable;
    set skipDestroy(value: boolean | cdktn.IResolvable);
    resetSkipDestroy(): void;
    get skipDestroyInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
