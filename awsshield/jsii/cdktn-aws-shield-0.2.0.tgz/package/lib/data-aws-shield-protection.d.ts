import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfProtectionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/shield_protection#protection_id DataTfProtection#protection_id}
    */
    readonly protectionId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/shield_protection#resource_arn DataTfProtection#resource_arn}
    */
    readonly resourceArn?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/shield_protection aws_shield_protection}
*/
export declare class DataTfProtection extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_shield_protection";
    /**
    * Generates CDKTN code for importing a DataTfProtection resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfProtection to import
    * @param importFromId The id of the existing DataTfProtection that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/shield_protection#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfProtection to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/shield_protection aws_shield_protection} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfProtectionConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataTfProtectionConfig);
    get id(): string;
    get name(): string;
    get protectionArn(): string;
    private _protectionId?;
    get protectionId(): string;
    set protectionId(value: string);
    resetProtectionId(): void;
    get protectionIdInput(): string | undefined;
    private _resourceArn?;
    get resourceArn(): string;
    set resourceArn(value: string);
    resetResourceArn(): void;
    get resourceArnInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
