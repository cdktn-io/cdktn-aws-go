import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfApplicationLayerAutomaticResponseConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_application_layer_automatic_response#action TfApplicationLayerAutomaticResponse#action}
    */
    readonly action: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_application_layer_automatic_response#resource_arn TfApplicationLayerAutomaticResponse#resource_arn}
    */
    readonly resourceArn: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_application_layer_automatic_response#timeouts TfApplicationLayerAutomaticResponse#timeouts}
    */
    readonly timeouts?: TfApplicationLayerAutomaticResponse.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_application_layer_automatic_response aws_shield_application_layer_automatic_response}
*/
export declare class TfApplicationLayerAutomaticResponse extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_shield_application_layer_automatic_response";
    /**
    * Generates CDKTN code for importing a TfApplicationLayerAutomaticResponse resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfApplicationLayerAutomaticResponse to import
    * @param importFromId The id of the existing TfApplicationLayerAutomaticResponse that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_application_layer_automatic_response#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfApplicationLayerAutomaticResponse to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_application_layer_automatic_response aws_shield_application_layer_automatic_response} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfApplicationLayerAutomaticResponseConfig
    */
    constructor(scope: Construct, id: string, config: TfApplicationLayerAutomaticResponseConfig);
    private _action?;
    get action(): string;
    set action(value: string);
    get actionInput(): string | undefined;
    get id(): string;
    private _resourceArn?;
    get resourceArn(): string;
    set resourceArn(value: string);
    get resourceArnInput(): string | undefined;
    private _timeouts;
    get timeouts(): TfApplicationLayerAutomaticResponse.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfApplicationLayerAutomaticResponse.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): TfApplicationLayerAutomaticResponse.TimeoutsProperty | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfApplicationLayerAutomaticResponseTimeoutsPropertyToTerraform(struct?: TfApplicationLayerAutomaticResponse.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfApplicationLayerAutomaticResponseTimeoutsPropertyToHclTerraform(struct?: TfApplicationLayerAutomaticResponse.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfApplicationLayerAutomaticResponse {
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_application_layer_automatic_response#create TfApplicationLayerAutomaticResponse#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_application_layer_automatic_response#delete TfApplicationLayerAutomaticResponse#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_application_layer_automatic_response#update TfApplicationLayerAutomaticResponse#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
