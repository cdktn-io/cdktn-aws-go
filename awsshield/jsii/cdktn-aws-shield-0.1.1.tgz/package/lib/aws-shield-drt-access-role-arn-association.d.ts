import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsShieldDrtAccessRoleArnAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_drt_access_role_arn_association#role_arn AwsShieldDrtAccessRoleArnAssociation#role_arn}
    */
    readonly roleArn: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_drt_access_role_arn_association#timeouts AwsShieldDrtAccessRoleArnAssociation#timeouts}
    */
    readonly timeouts?: AwsShieldDrtAccessRoleArnAssociation.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_drt_access_role_arn_association aws_shield_drt_access_role_arn_association}
*/
export declare class AwsShieldDrtAccessRoleArnAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_shield_drt_access_role_arn_association";
    /**
    * Generates CDKTN code for importing a AwsShieldDrtAccessRoleArnAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsShieldDrtAccessRoleArnAssociation to import
    * @param importFromId The id of the existing AwsShieldDrtAccessRoleArnAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_drt_access_role_arn_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsShieldDrtAccessRoleArnAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_drt_access_role_arn_association aws_shield_drt_access_role_arn_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsShieldDrtAccessRoleArnAssociationConfig
    */
    constructor(scope: Construct, id: string, config: AwsShieldDrtAccessRoleArnAssociationConfig);
    get id(): string;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    private _timeouts;
    get timeouts(): AwsShieldDrtAccessRoleArnAssociation.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsShieldDrtAccessRoleArnAssociation.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsShieldDrtAccessRoleArnAssociation.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsShieldDrtAccessRoleArnAssociationTimeoutsPropertyToTerraform(struct?: AwsShieldDrtAccessRoleArnAssociation.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsShieldDrtAccessRoleArnAssociationTimeoutsPropertyToHclTerraform(struct?: AwsShieldDrtAccessRoleArnAssociation.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsShieldDrtAccessRoleArnAssociation {
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_drt_access_role_arn_association#create AwsShieldDrtAccessRoleArnAssociation#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_drt_access_role_arn_association#delete AwsShieldDrtAccessRoleArnAssociation#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_drt_access_role_arn_association#update AwsShieldDrtAccessRoleArnAssociation#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
