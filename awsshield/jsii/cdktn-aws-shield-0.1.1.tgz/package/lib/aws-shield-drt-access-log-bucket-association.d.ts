import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsShieldDrtAccessLogBucketAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_drt_access_log_bucket_association#log_bucket AwsShieldDrtAccessLogBucketAssociation#log_bucket}
    */
    readonly logBucket: string;
    /**
    * Unused
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_drt_access_log_bucket_association#role_arn_association_id AwsShieldDrtAccessLogBucketAssociation#role_arn_association_id}
    */
    readonly roleArnAssociationId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_drt_access_log_bucket_association#timeouts AwsShieldDrtAccessLogBucketAssociation#timeouts}
    */
    readonly timeouts?: AwsShieldDrtAccessLogBucketAssociation.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_drt_access_log_bucket_association aws_shield_drt_access_log_bucket_association}
*/
export declare class AwsShieldDrtAccessLogBucketAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_shield_drt_access_log_bucket_association";
    /**
    * Generates CDKTN code for importing a AwsShieldDrtAccessLogBucketAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsShieldDrtAccessLogBucketAssociation to import
    * @param importFromId The id of the existing AwsShieldDrtAccessLogBucketAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_drt_access_log_bucket_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsShieldDrtAccessLogBucketAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_drt_access_log_bucket_association aws_shield_drt_access_log_bucket_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsShieldDrtAccessLogBucketAssociationConfig
    */
    constructor(scope: Construct, id: string, config: AwsShieldDrtAccessLogBucketAssociationConfig);
    get id(): string;
    private _logBucket?;
    get logBucket(): string;
    set logBucket(value: string);
    get logBucketInput(): string | undefined;
    private _roleArnAssociationId?;
    get roleArnAssociationId(): string;
    set roleArnAssociationId(value: string);
    get roleArnAssociationIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): AwsShieldDrtAccessLogBucketAssociation.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsShieldDrtAccessLogBucketAssociation.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsShieldDrtAccessLogBucketAssociation.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsShieldDrtAccessLogBucketAssociationTimeoutsPropertyToTerraform(struct?: AwsShieldDrtAccessLogBucketAssociation.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsShieldDrtAccessLogBucketAssociationTimeoutsPropertyToHclTerraform(struct?: AwsShieldDrtAccessLogBucketAssociation.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsShieldDrtAccessLogBucketAssociation {
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_drt_access_log_bucket_association#create AwsShieldDrtAccessLogBucketAssociation#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_drt_access_log_bucket_association#delete AwsShieldDrtAccessLogBucketAssociation#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
