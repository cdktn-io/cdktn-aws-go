import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsFleetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#context AwsFleet#context}
    */
    readonly context?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#excess_capacity_termination_policy AwsFleet#excess_capacity_termination_policy}
    */
    readonly excessCapacityTerminationPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#fleet_state AwsFleet#fleet_state}
    */
    readonly fleetState?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#fulfilled_capacity AwsFleet#fulfilled_capacity}
    */
    readonly fulfilledCapacity?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#fulfilled_on_demand_capacity AwsFleet#fulfilled_on_demand_capacity}
    */
    readonly fulfilledOnDemandCapacity?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#id AwsFleet#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#region AwsFleet#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#replace_unhealthy_instances AwsFleet#replace_unhealthy_instances}
    */
    readonly replaceUnhealthyInstances?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#tags AwsFleet#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#tags_all AwsFleet#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#terminate_instances AwsFleet#terminate_instances}
    */
    readonly terminateInstances?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#terminate_instances_with_expiration AwsFleet#terminate_instances_with_expiration}
    */
    readonly terminateInstancesWithExpiration?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#type AwsFleet#type}
    */
    readonly type?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#valid_from AwsFleet#valid_from}
    */
    readonly validFrom?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#valid_until AwsFleet#valid_until}
    */
    readonly validUntil?: string;
    /**
    * fleet_instance_set block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#fleet_instance_set AwsFleet#fleet_instance_set}
    */
    readonly fleetInstanceSet?: AwsFleet.FleetInstanceSetProperty[] | cdktn.IResolvable;
    /**
    * launch_template_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#launch_template_config AwsFleet#launch_template_config}
    */
    readonly launchTemplateConfig: AwsFleet.LaunchTemplateConfigProperty[] | cdktn.IResolvable;
    /**
    * on_demand_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#on_demand_options AwsFleet#on_demand_options}
    */
    readonly onDemandOptions?: AwsFleet.OnDemandOptionsProperty;
    /**
    * spot_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#spot_options AwsFleet#spot_options}
    */
    readonly spotOptions?: AwsFleet.SpotOptionsProperty;
    /**
    * target_capacity_specification block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#target_capacity_specification AwsFleet#target_capacity_specification}
    */
    readonly targetCapacitySpecification: AwsFleet.TargetCapacitySpecificationProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#timeouts AwsFleet#timeouts}
    */
    readonly timeouts?: AwsFleet.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet aws_ec2_fleet}
*/
export declare class AwsFleet extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ec2_fleet";
    /**
    * Generates CDKTN code for importing a AwsFleet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsFleet to import
    * @param importFromId The id of the existing AwsFleet that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsFleet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet aws_ec2_fleet} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsFleetConfig
    */
    constructor(scope: Construct, id: string, config: AwsFleetConfig);
    get arn(): string;
    private _context?;
    get context(): string;
    set context(value: string);
    resetContext(): void;
    get contextInput(): string | undefined;
    private _excessCapacityTerminationPolicy?;
    get excessCapacityTerminationPolicy(): string;
    set excessCapacityTerminationPolicy(value: string);
    resetExcessCapacityTerminationPolicy(): void;
    get excessCapacityTerminationPolicyInput(): string | undefined;
    private _fleetState?;
    get fleetState(): string;
    set fleetState(value: string);
    resetFleetState(): void;
    get fleetStateInput(): string | undefined;
    private _fulfilledCapacity?;
    get fulfilledCapacity(): number;
    set fulfilledCapacity(value: number);
    resetFulfilledCapacity(): void;
    get fulfilledCapacityInput(): number | undefined;
    private _fulfilledOnDemandCapacity?;
    get fulfilledOnDemandCapacity(): number;
    set fulfilledOnDemandCapacity(value: number);
    resetFulfilledOnDemandCapacity(): void;
    get fulfilledOnDemandCapacityInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _replaceUnhealthyInstances?;
    get replaceUnhealthyInstances(): boolean | cdktn.IResolvable;
    set replaceUnhealthyInstances(value: boolean | cdktn.IResolvable);
    resetReplaceUnhealthyInstances(): void;
    get replaceUnhealthyInstancesInput(): boolean | cdktn.IResolvable | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _terminateInstances?;
    get terminateInstances(): boolean | cdktn.IResolvable;
    set terminateInstances(value: boolean | cdktn.IResolvable);
    resetTerminateInstances(): void;
    get terminateInstancesInput(): boolean | cdktn.IResolvable | undefined;
    private _terminateInstancesWithExpiration?;
    get terminateInstancesWithExpiration(): boolean | cdktn.IResolvable;
    set terminateInstancesWithExpiration(value: boolean | cdktn.IResolvable);
    resetTerminateInstancesWithExpiration(): void;
    get terminateInstancesWithExpirationInput(): boolean | cdktn.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _validFrom?;
    get validFrom(): string;
    set validFrom(value: string);
    resetValidFrom(): void;
    get validFromInput(): string | undefined;
    private _validUntil?;
    get validUntil(): string;
    set validUntil(value: string);
    resetValidUntil(): void;
    get validUntilInput(): string | undefined;
    private _fleetInstanceSet;
    get fleetInstanceSet(): AwsFleet.FleetInstanceSetPropertyList;
    putFleetInstanceSet(value: AwsFleet.FleetInstanceSetProperty[] | cdktn.IResolvable): void;
    resetFleetInstanceSet(): void;
    get fleetInstanceSetInput(): cdktn.IResolvable | AwsFleet.FleetInstanceSetProperty[] | undefined;
    private _launchTemplateConfig;
    get launchTemplateConfig(): AwsFleet.LaunchTemplateConfigPropertyList;
    putLaunchTemplateConfig(value: AwsFleet.LaunchTemplateConfigProperty[] | cdktn.IResolvable): void;
    get launchTemplateConfigInput(): cdktn.IResolvable | AwsFleet.LaunchTemplateConfigProperty[] | undefined;
    private _onDemandOptions;
    get onDemandOptions(): AwsFleet.OnDemandOptionsPropertyOutputReference;
    putOnDemandOptions(value: AwsFleet.OnDemandOptionsProperty): void;
    resetOnDemandOptions(): void;
    get onDemandOptionsInput(): AwsFleet.OnDemandOptionsProperty | undefined;
    private _spotOptions;
    get spotOptions(): AwsFleet.SpotOptionsPropertyOutputReference;
    putSpotOptions(value: AwsFleet.SpotOptionsProperty): void;
    resetSpotOptions(): void;
    get spotOptionsInput(): AwsFleet.SpotOptionsProperty | undefined;
    private _targetCapacitySpecification;
    get targetCapacitySpecification(): AwsFleet.TargetCapacitySpecificationPropertyOutputReference;
    putTargetCapacitySpecification(value: AwsFleet.TargetCapacitySpecificationProperty): void;
    get targetCapacitySpecificationInput(): AwsFleet.TargetCapacitySpecificationProperty | undefined;
    private _timeouts;
    get timeouts(): AwsFleet.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsFleet.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsFleet.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsFleetFleetInstanceSetPropertyToTerraform(struct?: AwsFleet.FleetInstanceSetProperty | cdktn.IResolvable): any;
export declare function awsFleetFleetInstanceSetPropertyToHclTerraform(struct?: AwsFleet.FleetInstanceSetProperty | cdktn.IResolvable): any;
export declare function awsFleetLaunchTemplateSpecificationPropertyToTerraform(struct?: AwsFleet.LaunchTemplateSpecificationPropertyOutputReference | AwsFleet.LaunchTemplateSpecificationProperty): any;
export declare function awsFleetLaunchTemplateSpecificationPropertyToHclTerraform(struct?: AwsFleet.LaunchTemplateSpecificationPropertyOutputReference | AwsFleet.LaunchTemplateSpecificationProperty): any;
export declare function awsFleetAcceleratorCountPropertyToTerraform(struct?: AwsFleet.AcceleratorCountPropertyOutputReference | AwsFleet.AcceleratorCountProperty): any;
export declare function awsFleetAcceleratorCountPropertyToHclTerraform(struct?: AwsFleet.AcceleratorCountPropertyOutputReference | AwsFleet.AcceleratorCountProperty): any;
export declare function awsFleetAcceleratorTotalMemoryMibPropertyToTerraform(struct?: AwsFleet.AcceleratorTotalMemoryMibPropertyOutputReference | AwsFleet.AcceleratorTotalMemoryMibProperty): any;
export declare function awsFleetAcceleratorTotalMemoryMibPropertyToHclTerraform(struct?: AwsFleet.AcceleratorTotalMemoryMibPropertyOutputReference | AwsFleet.AcceleratorTotalMemoryMibProperty): any;
export declare function awsFleetBaselineEbsBandwidthMbpsPropertyToTerraform(struct?: AwsFleet.BaselineEbsBandwidthMbpsPropertyOutputReference | AwsFleet.BaselineEbsBandwidthMbpsProperty): any;
export declare function awsFleetBaselineEbsBandwidthMbpsPropertyToHclTerraform(struct?: AwsFleet.BaselineEbsBandwidthMbpsPropertyOutputReference | AwsFleet.BaselineEbsBandwidthMbpsProperty): any;
export declare function awsFleetMemoryGibPerVcpuPropertyToTerraform(struct?: AwsFleet.MemoryGibPerVcpuPropertyOutputReference | AwsFleet.MemoryGibPerVcpuProperty): any;
export declare function awsFleetMemoryGibPerVcpuPropertyToHclTerraform(struct?: AwsFleet.MemoryGibPerVcpuPropertyOutputReference | AwsFleet.MemoryGibPerVcpuProperty): any;
export declare function awsFleetMemoryMibPropertyToTerraform(struct?: AwsFleet.MemoryMibPropertyOutputReference | AwsFleet.MemoryMibProperty): any;
export declare function awsFleetMemoryMibPropertyToHclTerraform(struct?: AwsFleet.MemoryMibPropertyOutputReference | AwsFleet.MemoryMibProperty): any;
export declare function awsFleetNetworkBandwidthGbpsPropertyToTerraform(struct?: AwsFleet.NetworkBandwidthGbpsPropertyOutputReference | AwsFleet.NetworkBandwidthGbpsProperty): any;
export declare function awsFleetNetworkBandwidthGbpsPropertyToHclTerraform(struct?: AwsFleet.NetworkBandwidthGbpsPropertyOutputReference | AwsFleet.NetworkBandwidthGbpsProperty): any;
export declare function awsFleetNetworkInterfaceCountPropertyToTerraform(struct?: AwsFleet.NetworkInterfaceCountPropertyOutputReference | AwsFleet.NetworkInterfaceCountProperty): any;
export declare function awsFleetNetworkInterfaceCountPropertyToHclTerraform(struct?: AwsFleet.NetworkInterfaceCountPropertyOutputReference | AwsFleet.NetworkInterfaceCountProperty): any;
export declare function awsFleetTotalLocalStorageGbPropertyToTerraform(struct?: AwsFleet.TotalLocalStorageGbPropertyOutputReference | AwsFleet.TotalLocalStorageGbProperty): any;
export declare function awsFleetTotalLocalStorageGbPropertyToHclTerraform(struct?: AwsFleet.TotalLocalStorageGbPropertyOutputReference | AwsFleet.TotalLocalStorageGbProperty): any;
export declare function awsFleetVcpuCountPropertyToTerraform(struct?: AwsFleet.VcpuCountPropertyOutputReference | AwsFleet.VcpuCountProperty): any;
export declare function awsFleetVcpuCountPropertyToHclTerraform(struct?: AwsFleet.VcpuCountPropertyOutputReference | AwsFleet.VcpuCountProperty): any;
export declare function awsFleetInstanceRequirementsPropertyToTerraform(struct?: AwsFleet.InstanceRequirementsPropertyOutputReference | AwsFleet.InstanceRequirementsProperty): any;
export declare function awsFleetInstanceRequirementsPropertyToHclTerraform(struct?: AwsFleet.InstanceRequirementsPropertyOutputReference | AwsFleet.InstanceRequirementsProperty): any;
export declare function awsFleetOverridePropertyToTerraform(struct?: AwsFleet.OverrideProperty | cdktn.IResolvable): any;
export declare function awsFleetOverridePropertyToHclTerraform(struct?: AwsFleet.OverrideProperty | cdktn.IResolvable): any;
export declare function awsFleetLaunchTemplateConfigPropertyToTerraform(struct?: AwsFleet.LaunchTemplateConfigProperty | cdktn.IResolvable): any;
export declare function awsFleetLaunchTemplateConfigPropertyToHclTerraform(struct?: AwsFleet.LaunchTemplateConfigProperty | cdktn.IResolvable): any;
export declare function awsFleetCapacityReservationOptionsPropertyToTerraform(struct?: AwsFleet.CapacityReservationOptionsPropertyOutputReference | AwsFleet.CapacityReservationOptionsProperty): any;
export declare function awsFleetCapacityReservationOptionsPropertyToHclTerraform(struct?: AwsFleet.CapacityReservationOptionsPropertyOutputReference | AwsFleet.CapacityReservationOptionsProperty): any;
export declare function awsFleetOnDemandOptionsPropertyToTerraform(struct?: AwsFleet.OnDemandOptionsPropertyOutputReference | AwsFleet.OnDemandOptionsProperty): any;
export declare function awsFleetOnDemandOptionsPropertyToHclTerraform(struct?: AwsFleet.OnDemandOptionsPropertyOutputReference | AwsFleet.OnDemandOptionsProperty): any;
export declare function awsFleetCapacityRebalancePropertyToTerraform(struct?: AwsFleet.CapacityRebalancePropertyOutputReference | AwsFleet.CapacityRebalanceProperty): any;
export declare function awsFleetCapacityRebalancePropertyToHclTerraform(struct?: AwsFleet.CapacityRebalancePropertyOutputReference | AwsFleet.CapacityRebalanceProperty): any;
export declare function awsFleetMaintenanceStrategiesPropertyToTerraform(struct?: AwsFleet.MaintenanceStrategiesPropertyOutputReference | AwsFleet.MaintenanceStrategiesProperty): any;
export declare function awsFleetMaintenanceStrategiesPropertyToHclTerraform(struct?: AwsFleet.MaintenanceStrategiesPropertyOutputReference | AwsFleet.MaintenanceStrategiesProperty): any;
export declare function awsFleetSpotOptionsPropertyToTerraform(struct?: AwsFleet.SpotOptionsPropertyOutputReference | AwsFleet.SpotOptionsProperty): any;
export declare function awsFleetSpotOptionsPropertyToHclTerraform(struct?: AwsFleet.SpotOptionsPropertyOutputReference | AwsFleet.SpotOptionsProperty): any;
export declare function awsFleetTargetCapacitySpecificationPropertyToTerraform(struct?: AwsFleet.TargetCapacitySpecificationPropertyOutputReference | AwsFleet.TargetCapacitySpecificationProperty): any;
export declare function awsFleetTargetCapacitySpecificationPropertyToHclTerraform(struct?: AwsFleet.TargetCapacitySpecificationPropertyOutputReference | AwsFleet.TargetCapacitySpecificationProperty): any;
export declare function awsFleetTimeoutsPropertyToTerraform(struct?: AwsFleet.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsFleetTimeoutsPropertyToHclTerraform(struct?: AwsFleet.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsFleet {
    interface FleetInstanceSetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#instance_ids AwsFleet#instance_ids}
        */
        readonly instanceIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#instance_type AwsFleet#instance_type}
        */
        readonly instanceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#lifecycle AwsFleet#lifecycle}
        */
        readonly lifecycle?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#platform AwsFleet#platform}
        */
        readonly platform?: string;
    }
    class FleetInstanceSetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FleetInstanceSetProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FleetInstanceSetProperty | cdktn.IResolvable | undefined);
        private _instanceIds?;
        get instanceIds(): string[];
        set instanceIds(value: string[]);
        resetInstanceIds(): void;
        get instanceIdsInput(): string[] | undefined;
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        resetInstanceType(): void;
        get instanceTypeInput(): string | undefined;
        private _lifecycle?;
        get lifecycle(): string;
        set lifecycle(value: string);
        resetLifecycle(): void;
        get lifecycleInput(): string | undefined;
        private _platform?;
        get platform(): string;
        set platform(value: string);
        resetPlatform(): void;
        get platformInput(): string | undefined;
    }
    class FleetInstanceSetPropertyList extends cdktn.ComplexList {
        internalValue?: FleetInstanceSetProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FleetInstanceSetPropertyOutputReference;
    }
    interface LaunchTemplateSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#launch_template_id AwsFleet#launch_template_id}
        */
        readonly launchTemplateId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#launch_template_name AwsFleet#launch_template_name}
        */
        readonly launchTemplateName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#version AwsFleet#version}
        */
        readonly version: string;
    }
    class LaunchTemplateSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LaunchTemplateSpecificationProperty | undefined;
        set internalValue(value: LaunchTemplateSpecificationProperty | undefined);
        private _launchTemplateId?;
        get launchTemplateId(): string;
        set launchTemplateId(value: string);
        resetLaunchTemplateId(): void;
        get launchTemplateIdInput(): string | undefined;
        private _launchTemplateName?;
        get launchTemplateName(): string;
        set launchTemplateName(value: string);
        resetLaunchTemplateName(): void;
        get launchTemplateNameInput(): string | undefined;
        private _version?;
        get version(): string;
        set version(value: string);
        get versionInput(): string | undefined;
    }
    interface AcceleratorCountProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#max AwsFleet#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#min AwsFleet#min}
        */
        readonly min?: number;
    }
    class AcceleratorCountPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AcceleratorCountProperty | undefined;
        set internalValue(value: AcceleratorCountProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface AcceleratorTotalMemoryMibProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#max AwsFleet#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#min AwsFleet#min}
        */
        readonly min?: number;
    }
    class AcceleratorTotalMemoryMibPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AcceleratorTotalMemoryMibProperty | undefined;
        set internalValue(value: AcceleratorTotalMemoryMibProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface BaselineEbsBandwidthMbpsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#max AwsFleet#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#min AwsFleet#min}
        */
        readonly min?: number;
    }
    class BaselineEbsBandwidthMbpsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BaselineEbsBandwidthMbpsProperty | undefined;
        set internalValue(value: BaselineEbsBandwidthMbpsProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface MemoryGibPerVcpuProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#max AwsFleet#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#min AwsFleet#min}
        */
        readonly min?: number;
    }
    class MemoryGibPerVcpuPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MemoryGibPerVcpuProperty | undefined;
        set internalValue(value: MemoryGibPerVcpuProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface MemoryMibProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#max AwsFleet#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#min AwsFleet#min}
        */
        readonly min: number;
    }
    class MemoryMibPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MemoryMibProperty | undefined;
        set internalValue(value: MemoryMibProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        get minInput(): number | undefined;
    }
    interface NetworkBandwidthGbpsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#max AwsFleet#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#min AwsFleet#min}
        */
        readonly min?: number;
    }
    class NetworkBandwidthGbpsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NetworkBandwidthGbpsProperty | undefined;
        set internalValue(value: NetworkBandwidthGbpsProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface NetworkInterfaceCountProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#max AwsFleet#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#min AwsFleet#min}
        */
        readonly min?: number;
    }
    class NetworkInterfaceCountPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NetworkInterfaceCountProperty | undefined;
        set internalValue(value: NetworkInterfaceCountProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface TotalLocalStorageGbProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#max AwsFleet#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#min AwsFleet#min}
        */
        readonly min?: number;
    }
    class TotalLocalStorageGbPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TotalLocalStorageGbProperty | undefined;
        set internalValue(value: TotalLocalStorageGbProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface VcpuCountProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#max AwsFleet#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#min AwsFleet#min}
        */
        readonly min: number;
    }
    class VcpuCountPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VcpuCountProperty | undefined;
        set internalValue(value: VcpuCountProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        get minInput(): number | undefined;
    }
    interface InstanceRequirementsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#accelerator_manufacturers AwsFleet#accelerator_manufacturers}
        */
        readonly acceleratorManufacturers?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#accelerator_names AwsFleet#accelerator_names}
        */
        readonly acceleratorNames?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#accelerator_types AwsFleet#accelerator_types}
        */
        readonly acceleratorTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#allowed_instance_types AwsFleet#allowed_instance_types}
        */
        readonly allowedInstanceTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#bare_metal AwsFleet#bare_metal}
        */
        readonly bareMetal?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#burstable_performance AwsFleet#burstable_performance}
        */
        readonly burstablePerformance?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#cpu_manufacturers AwsFleet#cpu_manufacturers}
        */
        readonly cpuManufacturers?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#excluded_instance_types AwsFleet#excluded_instance_types}
        */
        readonly excludedInstanceTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#instance_generations AwsFleet#instance_generations}
        */
        readonly instanceGenerations?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#local_storage AwsFleet#local_storage}
        */
        readonly localStorage?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#local_storage_types AwsFleet#local_storage_types}
        */
        readonly localStorageTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#max_spot_price_as_percentage_of_optimal_on_demand_price AwsFleet#max_spot_price_as_percentage_of_optimal_on_demand_price}
        */
        readonly maxSpotPriceAsPercentageOfOptimalOnDemandPrice?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#on_demand_max_price_percentage_over_lowest_price AwsFleet#on_demand_max_price_percentage_over_lowest_price}
        */
        readonly onDemandMaxPricePercentageOverLowestPrice?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#require_hibernate_support AwsFleet#require_hibernate_support}
        */
        readonly requireHibernateSupport?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#spot_max_price_percentage_over_lowest_price AwsFleet#spot_max_price_percentage_over_lowest_price}
        */
        readonly spotMaxPricePercentageOverLowestPrice?: number;
        /**
        * accelerator_count block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#accelerator_count AwsFleet#accelerator_count}
        */
        readonly acceleratorCount?: AcceleratorCountProperty;
        /**
        * accelerator_total_memory_mib block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#accelerator_total_memory_mib AwsFleet#accelerator_total_memory_mib}
        */
        readonly acceleratorTotalMemoryMib?: AcceleratorTotalMemoryMibProperty;
        /**
        * baseline_ebs_bandwidth_mbps block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#baseline_ebs_bandwidth_mbps AwsFleet#baseline_ebs_bandwidth_mbps}
        */
        readonly baselineEbsBandwidthMbps?: BaselineEbsBandwidthMbpsProperty;
        /**
        * memory_gib_per_vcpu block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#memory_gib_per_vcpu AwsFleet#memory_gib_per_vcpu}
        */
        readonly memoryGibPerVcpu?: MemoryGibPerVcpuProperty;
        /**
        * memory_mib block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#memory_mib AwsFleet#memory_mib}
        */
        readonly memoryMib: MemoryMibProperty;
        /**
        * network_bandwidth_gbps block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#network_bandwidth_gbps AwsFleet#network_bandwidth_gbps}
        */
        readonly networkBandwidthGbps?: NetworkBandwidthGbpsProperty;
        /**
        * network_interface_count block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#network_interface_count AwsFleet#network_interface_count}
        */
        readonly networkInterfaceCount?: NetworkInterfaceCountProperty;
        /**
        * total_local_storage_gb block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#total_local_storage_gb AwsFleet#total_local_storage_gb}
        */
        readonly totalLocalStorageGb?: TotalLocalStorageGbProperty;
        /**
        * vcpu_count block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#vcpu_count AwsFleet#vcpu_count}
        */
        readonly vcpuCount: VcpuCountProperty;
    }
    class InstanceRequirementsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InstanceRequirementsProperty | undefined;
        set internalValue(value: InstanceRequirementsProperty | undefined);
        private _acceleratorManufacturers?;
        get acceleratorManufacturers(): string[];
        set acceleratorManufacturers(value: string[]);
        resetAcceleratorManufacturers(): void;
        get acceleratorManufacturersInput(): string[] | undefined;
        private _acceleratorNames?;
        get acceleratorNames(): string[];
        set acceleratorNames(value: string[]);
        resetAcceleratorNames(): void;
        get acceleratorNamesInput(): string[] | undefined;
        private _acceleratorTypes?;
        get acceleratorTypes(): string[];
        set acceleratorTypes(value: string[]);
        resetAcceleratorTypes(): void;
        get acceleratorTypesInput(): string[] | undefined;
        private _allowedInstanceTypes?;
        get allowedInstanceTypes(): string[];
        set allowedInstanceTypes(value: string[]);
        resetAllowedInstanceTypes(): void;
        get allowedInstanceTypesInput(): string[] | undefined;
        private _bareMetal?;
        get bareMetal(): string;
        set bareMetal(value: string);
        resetBareMetal(): void;
        get bareMetalInput(): string | undefined;
        private _burstablePerformance?;
        get burstablePerformance(): string;
        set burstablePerformance(value: string);
        resetBurstablePerformance(): void;
        get burstablePerformanceInput(): string | undefined;
        private _cpuManufacturers?;
        get cpuManufacturers(): string[];
        set cpuManufacturers(value: string[]);
        resetCpuManufacturers(): void;
        get cpuManufacturersInput(): string[] | undefined;
        private _excludedInstanceTypes?;
        get excludedInstanceTypes(): string[];
        set excludedInstanceTypes(value: string[]);
        resetExcludedInstanceTypes(): void;
        get excludedInstanceTypesInput(): string[] | undefined;
        private _instanceGenerations?;
        get instanceGenerations(): string[];
        set instanceGenerations(value: string[]);
        resetInstanceGenerations(): void;
        get instanceGenerationsInput(): string[] | undefined;
        private _localStorage?;
        get localStorage(): string;
        set localStorage(value: string);
        resetLocalStorage(): void;
        get localStorageInput(): string | undefined;
        private _localStorageTypes?;
        get localStorageTypes(): string[];
        set localStorageTypes(value: string[]);
        resetLocalStorageTypes(): void;
        get localStorageTypesInput(): string[] | undefined;
        private _maxSpotPriceAsPercentageOfOptimalOnDemandPrice?;
        get maxSpotPriceAsPercentageOfOptimalOnDemandPrice(): number;
        set maxSpotPriceAsPercentageOfOptimalOnDemandPrice(value: number);
        resetMaxSpotPriceAsPercentageOfOptimalOnDemandPrice(): void;
        get maxSpotPriceAsPercentageOfOptimalOnDemandPriceInput(): number | undefined;
        private _onDemandMaxPricePercentageOverLowestPrice?;
        get onDemandMaxPricePercentageOverLowestPrice(): number;
        set onDemandMaxPricePercentageOverLowestPrice(value: number);
        resetOnDemandMaxPricePercentageOverLowestPrice(): void;
        get onDemandMaxPricePercentageOverLowestPriceInput(): number | undefined;
        private _requireHibernateSupport?;
        get requireHibernateSupport(): boolean | cdktn.IResolvable;
        set requireHibernateSupport(value: boolean | cdktn.IResolvable);
        resetRequireHibernateSupport(): void;
        get requireHibernateSupportInput(): boolean | cdktn.IResolvable | undefined;
        private _spotMaxPricePercentageOverLowestPrice?;
        get spotMaxPricePercentageOverLowestPrice(): number;
        set spotMaxPricePercentageOverLowestPrice(value: number);
        resetSpotMaxPricePercentageOverLowestPrice(): void;
        get spotMaxPricePercentageOverLowestPriceInput(): number | undefined;
        private _acceleratorCount;
        get acceleratorCount(): AcceleratorCountPropertyOutputReference;
        putAcceleratorCount(value: AcceleratorCountProperty): void;
        resetAcceleratorCount(): void;
        get acceleratorCountInput(): AcceleratorCountProperty | undefined;
        private _acceleratorTotalMemoryMib;
        get acceleratorTotalMemoryMib(): AcceleratorTotalMemoryMibPropertyOutputReference;
        putAcceleratorTotalMemoryMib(value: AcceleratorTotalMemoryMibProperty): void;
        resetAcceleratorTotalMemoryMib(): void;
        get acceleratorTotalMemoryMibInput(): AcceleratorTotalMemoryMibProperty | undefined;
        private _baselineEbsBandwidthMbps;
        get baselineEbsBandwidthMbps(): BaselineEbsBandwidthMbpsPropertyOutputReference;
        putBaselineEbsBandwidthMbps(value: BaselineEbsBandwidthMbpsProperty): void;
        resetBaselineEbsBandwidthMbps(): void;
        get baselineEbsBandwidthMbpsInput(): BaselineEbsBandwidthMbpsProperty | undefined;
        private _memoryGibPerVcpu;
        get memoryGibPerVcpu(): MemoryGibPerVcpuPropertyOutputReference;
        putMemoryGibPerVcpu(value: MemoryGibPerVcpuProperty): void;
        resetMemoryGibPerVcpu(): void;
        get memoryGibPerVcpuInput(): MemoryGibPerVcpuProperty | undefined;
        private _memoryMib;
        get memoryMib(): MemoryMibPropertyOutputReference;
        putMemoryMib(value: MemoryMibProperty): void;
        get memoryMibInput(): MemoryMibProperty | undefined;
        private _networkBandwidthGbps;
        get networkBandwidthGbps(): NetworkBandwidthGbpsPropertyOutputReference;
        putNetworkBandwidthGbps(value: NetworkBandwidthGbpsProperty): void;
        resetNetworkBandwidthGbps(): void;
        get networkBandwidthGbpsInput(): NetworkBandwidthGbpsProperty | undefined;
        private _networkInterfaceCount;
        get networkInterfaceCount(): NetworkInterfaceCountPropertyOutputReference;
        putNetworkInterfaceCount(value: NetworkInterfaceCountProperty): void;
        resetNetworkInterfaceCount(): void;
        get networkInterfaceCountInput(): NetworkInterfaceCountProperty | undefined;
        private _totalLocalStorageGb;
        get totalLocalStorageGb(): TotalLocalStorageGbPropertyOutputReference;
        putTotalLocalStorageGb(value: TotalLocalStorageGbProperty): void;
        resetTotalLocalStorageGb(): void;
        get totalLocalStorageGbInput(): TotalLocalStorageGbProperty | undefined;
        private _vcpuCount;
        get vcpuCount(): VcpuCountPropertyOutputReference;
        putVcpuCount(value: VcpuCountProperty): void;
        get vcpuCountInput(): VcpuCountProperty | undefined;
    }
    interface OverrideProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#availability_zone AwsFleet#availability_zone}
        */
        readonly availabilityZone?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#instance_type AwsFleet#instance_type}
        */
        readonly instanceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#max_price AwsFleet#max_price}
        */
        readonly maxPrice?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#priority AwsFleet#priority}
        */
        readonly priority?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#subnet_id AwsFleet#subnet_id}
        */
        readonly subnetId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#weighted_capacity AwsFleet#weighted_capacity}
        */
        readonly weightedCapacity?: number;
        /**
        * instance_requirements block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#instance_requirements AwsFleet#instance_requirements}
        */
        readonly instanceRequirements?: InstanceRequirementsProperty;
    }
    class OverridePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OverrideProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OverrideProperty | cdktn.IResolvable | undefined);
        private _availabilityZone?;
        get availabilityZone(): string;
        set availabilityZone(value: string);
        resetAvailabilityZone(): void;
        get availabilityZoneInput(): string | undefined;
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        resetInstanceType(): void;
        get instanceTypeInput(): string | undefined;
        private _maxPrice?;
        get maxPrice(): string;
        set maxPrice(value: string);
        resetMaxPrice(): void;
        get maxPriceInput(): string | undefined;
        private _priority?;
        get priority(): number;
        set priority(value: number);
        resetPriority(): void;
        get priorityInput(): number | undefined;
        private _subnetId?;
        get subnetId(): string;
        set subnetId(value: string);
        resetSubnetId(): void;
        get subnetIdInput(): string | undefined;
        private _weightedCapacity?;
        get weightedCapacity(): number;
        set weightedCapacity(value: number);
        resetWeightedCapacity(): void;
        get weightedCapacityInput(): number | undefined;
        private _instanceRequirements;
        get instanceRequirements(): InstanceRequirementsPropertyOutputReference;
        putInstanceRequirements(value: InstanceRequirementsProperty): void;
        resetInstanceRequirements(): void;
        get instanceRequirementsInput(): InstanceRequirementsProperty | undefined;
    }
    class OverridePropertyList extends cdktn.ComplexList {
        internalValue?: OverrideProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OverridePropertyOutputReference;
    }
    interface LaunchTemplateConfigProperty {
        /**
        * launch_template_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#launch_template_specification AwsFleet#launch_template_specification}
        */
        readonly launchTemplateSpecification?: LaunchTemplateSpecificationProperty;
        /**
        * override block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#override AwsFleet#override}
        */
        readonly override?: OverrideProperty[] | cdktn.IResolvable;
    }
    class LaunchTemplateConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LaunchTemplateConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LaunchTemplateConfigProperty | cdktn.IResolvable | undefined);
        private _launchTemplateSpecification;
        get launchTemplateSpecification(): LaunchTemplateSpecificationPropertyOutputReference;
        putLaunchTemplateSpecification(value: LaunchTemplateSpecificationProperty): void;
        resetLaunchTemplateSpecification(): void;
        get launchTemplateSpecificationInput(): LaunchTemplateSpecificationProperty | undefined;
        private _override;
        get override(): OverridePropertyList;
        putOverride(value: OverrideProperty[] | cdktn.IResolvable): void;
        resetOverride(): void;
        get overrideInput(): cdktn.IResolvable | OverrideProperty[] | undefined;
    }
    class LaunchTemplateConfigPropertyList extends cdktn.ComplexList {
        internalValue?: LaunchTemplateConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LaunchTemplateConfigPropertyOutputReference;
    }
    interface CapacityReservationOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#usage_strategy AwsFleet#usage_strategy}
        */
        readonly usageStrategy?: string;
    }
    class CapacityReservationOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CapacityReservationOptionsProperty | undefined;
        set internalValue(value: CapacityReservationOptionsProperty | undefined);
        private _usageStrategy?;
        get usageStrategy(): string;
        set usageStrategy(value: string);
        resetUsageStrategy(): void;
        get usageStrategyInput(): string | undefined;
    }
    interface OnDemandOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#allocation_strategy AwsFleet#allocation_strategy}
        */
        readonly allocationStrategy?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#max_total_price AwsFleet#max_total_price}
        */
        readonly maxTotalPrice?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#min_target_capacity AwsFleet#min_target_capacity}
        */
        readonly minTargetCapacity?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#single_availability_zone AwsFleet#single_availability_zone}
        */
        readonly singleAvailabilityZone?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#single_instance_type AwsFleet#single_instance_type}
        */
        readonly singleInstanceType?: boolean | cdktn.IResolvable;
        /**
        * capacity_reservation_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#capacity_reservation_options AwsFleet#capacity_reservation_options}
        */
        readonly capacityReservationOptions?: CapacityReservationOptionsProperty;
    }
    class OnDemandOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OnDemandOptionsProperty | undefined;
        set internalValue(value: OnDemandOptionsProperty | undefined);
        private _allocationStrategy?;
        get allocationStrategy(): string;
        set allocationStrategy(value: string);
        resetAllocationStrategy(): void;
        get allocationStrategyInput(): string | undefined;
        private _maxTotalPrice?;
        get maxTotalPrice(): string;
        set maxTotalPrice(value: string);
        resetMaxTotalPrice(): void;
        get maxTotalPriceInput(): string | undefined;
        private _minTargetCapacity?;
        get minTargetCapacity(): number;
        set minTargetCapacity(value: number);
        resetMinTargetCapacity(): void;
        get minTargetCapacityInput(): number | undefined;
        private _singleAvailabilityZone?;
        get singleAvailabilityZone(): boolean | cdktn.IResolvable;
        set singleAvailabilityZone(value: boolean | cdktn.IResolvable);
        resetSingleAvailabilityZone(): void;
        get singleAvailabilityZoneInput(): boolean | cdktn.IResolvable | undefined;
        private _singleInstanceType?;
        get singleInstanceType(): boolean | cdktn.IResolvable;
        set singleInstanceType(value: boolean | cdktn.IResolvable);
        resetSingleInstanceType(): void;
        get singleInstanceTypeInput(): boolean | cdktn.IResolvable | undefined;
        private _capacityReservationOptions;
        get capacityReservationOptions(): CapacityReservationOptionsPropertyOutputReference;
        putCapacityReservationOptions(value: CapacityReservationOptionsProperty): void;
        resetCapacityReservationOptions(): void;
        get capacityReservationOptionsInput(): CapacityReservationOptionsProperty | undefined;
    }
    interface CapacityRebalanceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#replacement_strategy AwsFleet#replacement_strategy}
        */
        readonly replacementStrategy?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#termination_delay AwsFleet#termination_delay}
        */
        readonly terminationDelay?: number;
    }
    class CapacityRebalancePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CapacityRebalanceProperty | undefined;
        set internalValue(value: CapacityRebalanceProperty | undefined);
        private _replacementStrategy?;
        get replacementStrategy(): string;
        set replacementStrategy(value: string);
        resetReplacementStrategy(): void;
        get replacementStrategyInput(): string | undefined;
        private _terminationDelay?;
        get terminationDelay(): number;
        set terminationDelay(value: number);
        resetTerminationDelay(): void;
        get terminationDelayInput(): number | undefined;
    }
    interface MaintenanceStrategiesProperty {
        /**
        * capacity_rebalance block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#capacity_rebalance AwsFleet#capacity_rebalance}
        */
        readonly capacityRebalance?: CapacityRebalanceProperty;
    }
    class MaintenanceStrategiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MaintenanceStrategiesProperty | undefined;
        set internalValue(value: MaintenanceStrategiesProperty | undefined);
        private _capacityRebalance;
        get capacityRebalance(): CapacityRebalancePropertyOutputReference;
        putCapacityRebalance(value: CapacityRebalanceProperty): void;
        resetCapacityRebalance(): void;
        get capacityRebalanceInput(): CapacityRebalanceProperty | undefined;
    }
    interface SpotOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#allocation_strategy AwsFleet#allocation_strategy}
        */
        readonly allocationStrategy?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#instance_interruption_behavior AwsFleet#instance_interruption_behavior}
        */
        readonly instanceInterruptionBehavior?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#instance_pools_to_use_count AwsFleet#instance_pools_to_use_count}
        */
        readonly instancePoolsToUseCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#max_total_price AwsFleet#max_total_price}
        */
        readonly maxTotalPrice?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#min_target_capacity AwsFleet#min_target_capacity}
        */
        readonly minTargetCapacity?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#single_availability_zone AwsFleet#single_availability_zone}
        */
        readonly singleAvailabilityZone?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#single_instance_type AwsFleet#single_instance_type}
        */
        readonly singleInstanceType?: boolean | cdktn.IResolvable;
        /**
        * maintenance_strategies block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#maintenance_strategies AwsFleet#maintenance_strategies}
        */
        readonly maintenanceStrategies?: MaintenanceStrategiesProperty;
    }
    class SpotOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpotOptionsProperty | undefined;
        set internalValue(value: SpotOptionsProperty | undefined);
        private _allocationStrategy?;
        get allocationStrategy(): string;
        set allocationStrategy(value: string);
        resetAllocationStrategy(): void;
        get allocationStrategyInput(): string | undefined;
        private _instanceInterruptionBehavior?;
        get instanceInterruptionBehavior(): string;
        set instanceInterruptionBehavior(value: string);
        resetInstanceInterruptionBehavior(): void;
        get instanceInterruptionBehaviorInput(): string | undefined;
        private _instancePoolsToUseCount?;
        get instancePoolsToUseCount(): number;
        set instancePoolsToUseCount(value: number);
        resetInstancePoolsToUseCount(): void;
        get instancePoolsToUseCountInput(): number | undefined;
        private _maxTotalPrice?;
        get maxTotalPrice(): string;
        set maxTotalPrice(value: string);
        resetMaxTotalPrice(): void;
        get maxTotalPriceInput(): string | undefined;
        private _minTargetCapacity?;
        get minTargetCapacity(): number;
        set minTargetCapacity(value: number);
        resetMinTargetCapacity(): void;
        get minTargetCapacityInput(): number | undefined;
        private _singleAvailabilityZone?;
        get singleAvailabilityZone(): boolean | cdktn.IResolvable;
        set singleAvailabilityZone(value: boolean | cdktn.IResolvable);
        resetSingleAvailabilityZone(): void;
        get singleAvailabilityZoneInput(): boolean | cdktn.IResolvable | undefined;
        private _singleInstanceType?;
        get singleInstanceType(): boolean | cdktn.IResolvable;
        set singleInstanceType(value: boolean | cdktn.IResolvable);
        resetSingleInstanceType(): void;
        get singleInstanceTypeInput(): boolean | cdktn.IResolvable | undefined;
        private _maintenanceStrategies;
        get maintenanceStrategies(): MaintenanceStrategiesPropertyOutputReference;
        putMaintenanceStrategies(value: MaintenanceStrategiesProperty): void;
        resetMaintenanceStrategies(): void;
        get maintenanceStrategiesInput(): MaintenanceStrategiesProperty | undefined;
    }
    interface TargetCapacitySpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#default_target_capacity_type AwsFleet#default_target_capacity_type}
        */
        readonly defaultTargetCapacityType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#on_demand_target_capacity AwsFleet#on_demand_target_capacity}
        */
        readonly onDemandTargetCapacity?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#spot_target_capacity AwsFleet#spot_target_capacity}
        */
        readonly spotTargetCapacity?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#target_capacity_unit_type AwsFleet#target_capacity_unit_type}
        */
        readonly targetCapacityUnitType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#total_target_capacity AwsFleet#total_target_capacity}
        */
        readonly totalTargetCapacity: number;
    }
    class TargetCapacitySpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TargetCapacitySpecificationProperty | undefined;
        set internalValue(value: TargetCapacitySpecificationProperty | undefined);
        private _defaultTargetCapacityType?;
        get defaultTargetCapacityType(): string;
        set defaultTargetCapacityType(value: string);
        get defaultTargetCapacityTypeInput(): string | undefined;
        private _onDemandTargetCapacity?;
        get onDemandTargetCapacity(): number;
        set onDemandTargetCapacity(value: number);
        resetOnDemandTargetCapacity(): void;
        get onDemandTargetCapacityInput(): number | undefined;
        private _spotTargetCapacity?;
        get spotTargetCapacity(): number;
        set spotTargetCapacity(value: number);
        resetSpotTargetCapacity(): void;
        get spotTargetCapacityInput(): number | undefined;
        private _targetCapacityUnitType?;
        get targetCapacityUnitType(): string;
        set targetCapacityUnitType(value: string);
        resetTargetCapacityUnitType(): void;
        get targetCapacityUnitTypeInput(): string | undefined;
        private _totalTargetCapacity?;
        get totalTargetCapacity(): number;
        set totalTargetCapacity(value: number);
        get totalTargetCapacityInput(): number | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#create AwsFleet#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#delete AwsFleet#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#update AwsFleet#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
