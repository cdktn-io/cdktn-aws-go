import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsInstanceTypeConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_instance_type#id DataAwsInstanceType#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_instance_type#instance_type DataAwsInstanceType#instance_type}
    */
    readonly instanceType: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_instance_type#region DataAwsInstanceType#region}
    */
    readonly region?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_instance_type#timeouts DataAwsInstanceType#timeouts}
    */
    readonly timeouts?: DataAwsInstanceType.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_instance_type aws_ec2_instance_type}
*/
export declare class DataAwsInstanceType extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_ec2_instance_type";
    /**
    * Generates CDKTN code for importing a DataAwsInstanceType resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsInstanceType to import
    * @param importFromId The id of the existing DataAwsInstanceType that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_instance_type#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsInstanceType to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_instance_type aws_ec2_instance_type} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsInstanceTypeConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsInstanceTypeConfig);
    get autoRecoverySupported(): cdktn.IResolvable;
    get bandwidthWeightings(): string[];
    get bareMetal(): cdktn.IResolvable;
    get bootModes(): string[];
    get burstablePerformanceSupported(): cdktn.IResolvable;
    get currentGeneration(): cdktn.IResolvable;
    get dedicatedHostsSupported(): cdktn.IResolvable;
    get defaultCores(): number;
    get defaultNetworkCardIndex(): number;
    get defaultThreadsPerCore(): number;
    get defaultVcpus(): number;
    get ebsEncryptionSupport(): string;
    get ebsNvmeSupport(): string;
    get ebsOptimizedSupport(): string;
    get ebsPerformanceBaselineBandwidth(): number;
    get ebsPerformanceBaselineIops(): number;
    get ebsPerformanceBaselineThroughput(): number;
    get ebsPerformanceMaximumBandwidth(): number;
    get ebsPerformanceMaximumIops(): number;
    get ebsPerformanceMaximumThroughput(): number;
    get efaMaximumInterfaces(): number;
    get efaSupported(): cdktn.IResolvable;
    get enaSrdSupported(): cdktn.IResolvable;
    get enaSupport(): string;
    get encryptionInTransitSupported(): cdktn.IResolvable;
    private _fpgas;
    get fpgas(): DataAwsInstanceType.FpgasPropertyList;
    get freeTierEligible(): cdktn.IResolvable;
    private _gpus;
    get gpus(): DataAwsInstanceType.GpusPropertyList;
    get hibernationSupported(): cdktn.IResolvable;
    get hypervisor(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _inferenceAccelerators;
    get inferenceAccelerators(): DataAwsInstanceType.InferenceAcceleratorsPropertyList;
    private _instanceDisks;
    get instanceDisks(): DataAwsInstanceType.InstanceDisksPropertyList;
    get instanceStorageSupported(): cdktn.IResolvable;
    private _instanceType?;
    get instanceType(): string;
    set instanceType(value: string);
    get instanceTypeInput(): string | undefined;
    get ipv6Supported(): cdktn.IResolvable;
    get maximumIpv4AddressesPerInterface(): number;
    get maximumIpv6AddressesPerInterface(): number;
    get maximumNetworkCards(): number;
    get maximumNetworkInterfaces(): number;
    private _mediaAccelerators;
    get mediaAccelerators(): DataAwsInstanceType.MediaAcceleratorsPropertyList;
    get memorySize(): number;
    private _networkCards;
    get networkCards(): DataAwsInstanceType.NetworkCardsPropertyList;
    get networkPerformance(): string;
    private _neuronDevices;
    get neuronDevices(): DataAwsInstanceType.NeuronDevicesPropertyList;
    get nitroEnclavesSupport(): string;
    get nitroTpmSupport(): string;
    get nitroTpmSupportedVersions(): string[];
    get phcSupport(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get supportedArchitectures(): string[];
    get supportedCpuFeatures(): string[];
    get supportedPlacementStrategies(): string[];
    get supportedRootDeviceTypes(): string[];
    get supportedUsagesClasses(): string[];
    get supportedVirtualizationTypes(): string[];
    get sustainedClockSpeed(): number;
    get totalFpgaMemory(): number;
    get totalGpuMemory(): number;
    get totalInferenceMemory(): number;
    get totalInstanceStorage(): number;
    get totalMediaMemory(): number;
    get totalNeuronDeviceMemory(): number;
    get validCores(): number[];
    get validThreadsPerCore(): number[];
    private _timeouts;
    get timeouts(): DataAwsInstanceType.TimeoutsPropertyOutputReference;
    putTimeouts(value: DataAwsInstanceType.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAwsInstanceType.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsInstanceTypeFpgasPropertyToTerraform(struct?: DataAwsInstanceType.FpgasProperty): any;
export declare function dataAwsInstanceTypeFpgasPropertyToHclTerraform(struct?: DataAwsInstanceType.FpgasProperty): any;
export declare function dataAwsInstanceTypeGpusPropertyToTerraform(struct?: DataAwsInstanceType.GpusProperty): any;
export declare function dataAwsInstanceTypeGpusPropertyToHclTerraform(struct?: DataAwsInstanceType.GpusProperty): any;
export declare function dataAwsInstanceTypeInferenceAcceleratorsPropertyToTerraform(struct?: DataAwsInstanceType.InferenceAcceleratorsProperty): any;
export declare function dataAwsInstanceTypeInferenceAcceleratorsPropertyToHclTerraform(struct?: DataAwsInstanceType.InferenceAcceleratorsProperty): any;
export declare function dataAwsInstanceTypeInstanceDisksPropertyToTerraform(struct?: DataAwsInstanceType.InstanceDisksProperty): any;
export declare function dataAwsInstanceTypeInstanceDisksPropertyToHclTerraform(struct?: DataAwsInstanceType.InstanceDisksProperty): any;
export declare function dataAwsInstanceTypeMediaAcceleratorsPropertyToTerraform(struct?: DataAwsInstanceType.MediaAcceleratorsProperty): any;
export declare function dataAwsInstanceTypeMediaAcceleratorsPropertyToHclTerraform(struct?: DataAwsInstanceType.MediaAcceleratorsProperty): any;
export declare function dataAwsInstanceTypeNetworkCardsPropertyToTerraform(struct?: DataAwsInstanceType.NetworkCardsProperty): any;
export declare function dataAwsInstanceTypeNetworkCardsPropertyToHclTerraform(struct?: DataAwsInstanceType.NetworkCardsProperty): any;
export declare function dataAwsInstanceTypeNeuronDevicesPropertyToTerraform(struct?: DataAwsInstanceType.NeuronDevicesProperty): any;
export declare function dataAwsInstanceTypeNeuronDevicesPropertyToHclTerraform(struct?: DataAwsInstanceType.NeuronDevicesProperty): any;
export declare function dataAwsInstanceTypeTimeoutsPropertyToTerraform(struct?: DataAwsInstanceType.TimeoutsProperty | cdktn.IResolvable): any;
export declare function dataAwsInstanceTypeTimeoutsPropertyToHclTerraform(struct?: DataAwsInstanceType.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace DataAwsInstanceType {
    interface FpgasProperty {
    }
    class FpgasPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FpgasProperty | undefined;
        set internalValue(value: FpgasProperty | undefined);
        get count(): number;
        get manufacturer(): string;
        get memorySize(): number;
        get name(): string;
    }
    class FpgasPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FpgasPropertyOutputReference;
    }
    interface GpusProperty {
    }
    class GpusPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GpusProperty | undefined;
        set internalValue(value: GpusProperty | undefined);
        get count(): number;
        get manufacturer(): string;
        get memorySize(): number;
        get name(): string;
    }
    class GpusPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GpusPropertyOutputReference;
    }
    interface InferenceAcceleratorsProperty {
    }
    class InferenceAcceleratorsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InferenceAcceleratorsProperty | undefined;
        set internalValue(value: InferenceAcceleratorsProperty | undefined);
        get count(): number;
        get manufacturer(): string;
        get memorySize(): number;
        get name(): string;
    }
    class InferenceAcceleratorsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InferenceAcceleratorsPropertyOutputReference;
    }
    interface InstanceDisksProperty {
    }
    class InstanceDisksPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InstanceDisksProperty | undefined;
        set internalValue(value: InstanceDisksProperty | undefined);
        get count(): number;
        get size(): number;
        get type(): string;
    }
    class InstanceDisksPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InstanceDisksPropertyOutputReference;
    }
    interface MediaAcceleratorsProperty {
    }
    class MediaAcceleratorsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MediaAcceleratorsProperty | undefined;
        set internalValue(value: MediaAcceleratorsProperty | undefined);
        get count(): number;
        get manufacturer(): string;
        get memorySize(): number;
        get name(): string;
    }
    class MediaAcceleratorsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MediaAcceleratorsPropertyOutputReference;
    }
    interface NetworkCardsProperty {
    }
    class NetworkCardsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NetworkCardsProperty | undefined;
        set internalValue(value: NetworkCardsProperty | undefined);
        get baselineBandwidth(): number;
        get index(): number;
        get maximumInterfaces(): number;
        get peakBandwidth(): number;
        get performance(): string;
    }
    class NetworkCardsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NetworkCardsPropertyOutputReference;
    }
    interface NeuronDevicesProperty {
    }
    class NeuronDevicesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NeuronDevicesProperty | undefined;
        set internalValue(value: NeuronDevicesProperty | undefined);
        get coreCount(): number;
        get coreVersion(): number;
        get count(): number;
        get memorySize(): number;
        get name(): string;
    }
    class NeuronDevicesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NeuronDevicesPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_instance_type#read DataAwsInstanceType#read}
        */
        readonly read?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _read?;
        get read(): string;
        set read(value: string);
        resetRead(): void;
        get readInput(): string | undefined;
    }
}
