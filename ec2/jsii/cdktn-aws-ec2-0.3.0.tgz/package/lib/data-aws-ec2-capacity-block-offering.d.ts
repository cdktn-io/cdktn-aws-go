import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsCapacityBlockOfferingConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_capacity_block_offering#capacity_duration_hours DataAwsCapacityBlockOffering#capacity_duration_hours}
    */
    readonly capacityDurationHours: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_capacity_block_offering#end_date_range DataAwsCapacityBlockOffering#end_date_range}
    */
    readonly endDateRange?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_capacity_block_offering#instance_count DataAwsCapacityBlockOffering#instance_count}
    */
    readonly instanceCount: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_capacity_block_offering#instance_type DataAwsCapacityBlockOffering#instance_type}
    */
    readonly instanceType: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_capacity_block_offering#region DataAwsCapacityBlockOffering#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_capacity_block_offering#start_date_range DataAwsCapacityBlockOffering#start_date_range}
    */
    readonly startDateRange?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_capacity_block_offering aws_ec2_capacity_block_offering}
*/
export declare class DataAwsCapacityBlockOffering extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_ec2_capacity_block_offering";
    /**
    * Generates CDKTN code for importing a DataAwsCapacityBlockOffering resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsCapacityBlockOffering to import
    * @param importFromId The id of the existing DataAwsCapacityBlockOffering that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_capacity_block_offering#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsCapacityBlockOffering to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_capacity_block_offering aws_ec2_capacity_block_offering} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsCapacityBlockOfferingConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsCapacityBlockOfferingConfig);
    get availabilityZone(): string;
    get capacityBlockOfferingId(): string;
    private _capacityDurationHours?;
    get capacityDurationHours(): number;
    set capacityDurationHours(value: number);
    get capacityDurationHoursInput(): number | undefined;
    get currencyCode(): string;
    private _endDateRange?;
    get endDateRange(): string;
    set endDateRange(value: string);
    resetEndDateRange(): void;
    get endDateRangeInput(): string | undefined;
    private _instanceCount?;
    get instanceCount(): number;
    set instanceCount(value: number);
    get instanceCountInput(): number | undefined;
    private _instanceType?;
    get instanceType(): string;
    set instanceType(value: string);
    get instanceTypeInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _startDateRange?;
    get startDateRange(): string;
    set startDateRange(value: string);
    resetStartDateRange(): void;
    get startDateRangeInput(): string | undefined;
    get tenancy(): string;
    get upfrontFee(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
