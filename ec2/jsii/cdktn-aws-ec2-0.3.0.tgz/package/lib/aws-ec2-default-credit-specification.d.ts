import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDefaultCreditSpecificationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_default_credit_specification#cpu_credits AwsDefaultCreditSpecification#cpu_credits}
    */
    readonly cpuCredits: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_default_credit_specification#instance_family AwsDefaultCreditSpecification#instance_family}
    */
    readonly instanceFamily: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_default_credit_specification#region AwsDefaultCreditSpecification#region}
    */
    readonly region?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_default_credit_specification#timeouts AwsDefaultCreditSpecification#timeouts}
    */
    readonly timeouts?: AwsDefaultCreditSpecification.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_default_credit_specification aws_ec2_default_credit_specification}
*/
export declare class AwsDefaultCreditSpecification extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ec2_default_credit_specification";
    /**
    * Generates CDKTN code for importing a AwsDefaultCreditSpecification resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDefaultCreditSpecification to import
    * @param importFromId The id of the existing AwsDefaultCreditSpecification that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_default_credit_specification#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDefaultCreditSpecification to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_default_credit_specification aws_ec2_default_credit_specification} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDefaultCreditSpecificationConfig
    */
    constructor(scope: Construct, id: string, config: AwsDefaultCreditSpecificationConfig);
    private _cpuCredits?;
    get cpuCredits(): string;
    set cpuCredits(value: string);
    get cpuCreditsInput(): string | undefined;
    private _instanceFamily?;
    get instanceFamily(): string;
    set instanceFamily(value: string);
    get instanceFamilyInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _timeouts;
    get timeouts(): AwsDefaultCreditSpecification.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsDefaultCreditSpecification.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsDefaultCreditSpecification.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsDefaultCreditSpecificationTimeoutsPropertyToTerraform(struct?: AwsDefaultCreditSpecification.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsDefaultCreditSpecificationTimeoutsPropertyToHclTerraform(struct?: AwsDefaultCreditSpecification.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsDefaultCreditSpecification {
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_default_credit_specification#create AwsDefaultCreditSpecification#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_default_credit_specification#update AwsDefaultCreditSpecification#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
