import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsHostConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_host#host_id DataAwsHost#host_id}
    */
    readonly hostId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_host#id DataAwsHost#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_host#region DataAwsHost#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_host#tags DataAwsHost#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_host#filter DataAwsHost#filter}
    */
    readonly filter?: DataAwsHost.FilterProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_host#timeouts DataAwsHost#timeouts}
    */
    readonly timeouts?: DataAwsHost.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_host aws_ec2_host}
*/
export declare class DataAwsHost extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_ec2_host";
    /**
    * Generates CDKTN code for importing a DataAwsHost resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsHost to import
    * @param importFromId The id of the existing DataAwsHost that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_host#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsHost to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_host aws_ec2_host} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsHostConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsHostConfig);
    get allocationTime(): string;
    get allowsMultipleInstanceTypes(): string;
    get arn(): string;
    get assetId(): string;
    get autoPlacement(): string;
    get availabilityZone(): string;
    get availabilityZoneId(): string;
    private _availableCapacity;
    get availableCapacity(): DataAwsHost.AvailableCapacityPropertyList;
    get cores(): number;
    private _hostId?;
    get hostId(): string;
    set hostId(value: string);
    resetHostId(): void;
    get hostIdInput(): string | undefined;
    get hostMaintenance(): string;
    get hostRecovery(): string;
    get hostReservationId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get instanceFamily(): string;
    get instanceType(): string;
    private _instances;
    get instances(): DataAwsHost.InstancesPropertyList;
    get memberOfServiceLinkedResourceGroup(): cdktn.IResolvable;
    get outpostArn(): string;
    get ownerId(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get releaseTime(): string;
    get sockets(): number;
    get state(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    get totalVcpus(): number;
    private _filter;
    get filter(): DataAwsHost.FilterPropertyList;
    putFilter(value: DataAwsHost.FilterProperty[] | cdktn.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataAwsHost.FilterProperty[] | undefined;
    private _timeouts;
    get timeouts(): DataAwsHost.TimeoutsPropertyOutputReference;
    putTimeouts(value: DataAwsHost.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAwsHost.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsHostAvailableInstanceCapacityPropertyToTerraform(struct?: DataAwsHost.AvailableInstanceCapacityProperty): any;
export declare function dataAwsHostAvailableInstanceCapacityPropertyToHclTerraform(struct?: DataAwsHost.AvailableInstanceCapacityProperty): any;
export declare function dataAwsHostAvailableCapacityPropertyToTerraform(struct?: DataAwsHost.AvailableCapacityProperty): any;
export declare function dataAwsHostAvailableCapacityPropertyToHclTerraform(struct?: DataAwsHost.AvailableCapacityProperty): any;
export declare function dataAwsHostInstancesPropertyToTerraform(struct?: DataAwsHost.InstancesProperty): any;
export declare function dataAwsHostInstancesPropertyToHclTerraform(struct?: DataAwsHost.InstancesProperty): any;
export declare function dataAwsHostFilterPropertyToTerraform(struct?: DataAwsHost.FilterProperty | cdktn.IResolvable): any;
export declare function dataAwsHostFilterPropertyToHclTerraform(struct?: DataAwsHost.FilterProperty | cdktn.IResolvable): any;
export declare function dataAwsHostTimeoutsPropertyToTerraform(struct?: DataAwsHost.TimeoutsProperty | cdktn.IResolvable): any;
export declare function dataAwsHostTimeoutsPropertyToHclTerraform(struct?: DataAwsHost.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace DataAwsHost {
    interface AvailableInstanceCapacityProperty {
    }
    class AvailableInstanceCapacityPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AvailableInstanceCapacityProperty | undefined;
        set internalValue(value: AvailableInstanceCapacityProperty | undefined);
        get availableCapacity(): number;
        get instanceType(): string;
        get totalCapacity(): number;
    }
    class AvailableInstanceCapacityPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AvailableInstanceCapacityPropertyOutputReference;
    }
    interface AvailableCapacityProperty {
    }
    class AvailableCapacityPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AvailableCapacityProperty | undefined;
        set internalValue(value: AvailableCapacityProperty | undefined);
        private _availableInstanceCapacity;
        get availableInstanceCapacity(): AvailableInstanceCapacityPropertyList;
        get availableVcpus(): number;
    }
    class AvailableCapacityPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AvailableCapacityPropertyOutputReference;
    }
    interface InstancesProperty {
    }
    class InstancesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InstancesProperty | undefined;
        set internalValue(value: InstancesProperty | undefined);
        get instanceId(): string;
        get instanceType(): string;
        get ownerId(): string;
    }
    class InstancesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InstancesPropertyOutputReference;
    }
    interface FilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_host#name DataAwsHost#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_host#values DataAwsHost#values}
        */
        readonly values: string[];
    }
    class FilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FilterProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class FilterPropertyList extends cdktn.ComplexList {
        internalValue?: FilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_host#read DataAwsHost#read}
        */
        readonly read?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _read?;
        get read(): string;
        set read(value: string);
        resetRead(): void;
        get readInput(): string | undefined;
    }
}
