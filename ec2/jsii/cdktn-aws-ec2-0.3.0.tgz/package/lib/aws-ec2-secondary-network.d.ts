import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSecondaryNetworkConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_secondary_network#ipv4_cidr_block AwsSecondaryNetwork#ipv4_cidr_block}
    */
    readonly ipv4CidrBlock: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_secondary_network#network_type AwsSecondaryNetwork#network_type}
    */
    readonly networkType: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_secondary_network#region AwsSecondaryNetwork#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_secondary_network#tags AwsSecondaryNetwork#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_secondary_network#timeouts AwsSecondaryNetwork#timeouts}
    */
    readonly timeouts?: AwsSecondaryNetwork.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_secondary_network aws_ec2_secondary_network}
*/
export declare class AwsSecondaryNetwork extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ec2_secondary_network";
    /**
    * Generates CDKTN code for importing a AwsSecondaryNetwork resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSecondaryNetwork to import
    * @param importFromId The id of the existing AwsSecondaryNetwork that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_secondary_network#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSecondaryNetwork to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_secondary_network aws_ec2_secondary_network} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSecondaryNetworkConfig
    */
    constructor(scope: Construct, id: string, config: AwsSecondaryNetworkConfig);
    get arn(): string;
    get id(): string;
    private _ipv4CidrBlock?;
    get ipv4CidrBlock(): string;
    set ipv4CidrBlock(value: string);
    get ipv4CidrBlockInput(): string | undefined;
    private _ipv4CidrBlockAssociations;
    get ipv4CidrBlockAssociations(): AwsSecondaryNetwork.Ipv4CidrBlockAssociationsPropertyList;
    private _networkType?;
    get networkType(): string;
    set networkType(value: string);
    get networkTypeInput(): string | undefined;
    get ownerId(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get secondaryNetworkId(): string;
    get state(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _timeouts;
    get timeouts(): AwsSecondaryNetwork.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsSecondaryNetwork.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsSecondaryNetwork.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsSecondaryNetworkIpv4CidrBlockAssociationsPropertyToTerraform(struct?: AwsSecondaryNetwork.Ipv4CidrBlockAssociationsProperty): any;
export declare function awsSecondaryNetworkIpv4CidrBlockAssociationsPropertyToHclTerraform(struct?: AwsSecondaryNetwork.Ipv4CidrBlockAssociationsProperty): any;
export declare function awsSecondaryNetworkTimeoutsPropertyToTerraform(struct?: AwsSecondaryNetwork.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsSecondaryNetworkTimeoutsPropertyToHclTerraform(struct?: AwsSecondaryNetwork.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsSecondaryNetwork {
    interface Ipv4CidrBlockAssociationsProperty {
    }
    class Ipv4CidrBlockAssociationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): Ipv4CidrBlockAssociationsProperty | undefined;
        set internalValue(value: Ipv4CidrBlockAssociationsProperty | undefined);
        get associationId(): string;
        get cidrBlock(): string;
        get state(): string;
    }
    class Ipv4CidrBlockAssociationsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): Ipv4CidrBlockAssociationsPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_secondary_network#create AwsSecondaryNetwork#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_secondary_network#delete AwsSecondaryNetwork#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_secondary_network#update AwsSecondaryNetwork#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
