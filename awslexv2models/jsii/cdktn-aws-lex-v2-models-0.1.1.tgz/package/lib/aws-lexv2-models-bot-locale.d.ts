import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsLexv2ModelsBotLocaleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_bot_locale#bot_id AwsLexv2ModelsBotLocale#bot_id}
    */
    readonly botId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_bot_locale#bot_version AwsLexv2ModelsBotLocale#bot_version}
    */
    readonly botVersion: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_bot_locale#description AwsLexv2ModelsBotLocale#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_bot_locale#locale_id AwsLexv2ModelsBotLocale#locale_id}
    */
    readonly localeId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_bot_locale#n_lu_intent_confidence_threshold AwsLexv2ModelsBotLocale#n_lu_intent_confidence_threshold}
    */
    readonly nLuIntentConfidenceThreshold: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_bot_locale#name AwsLexv2ModelsBotLocale#name}
    */
    readonly name?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_bot_locale#region AwsLexv2ModelsBotLocale#region}
    */
    readonly region?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_bot_locale#timeouts AwsLexv2ModelsBotLocale#timeouts}
    */
    readonly timeouts?: AwsLexv2ModelsBotLocale.TimeoutsProperty;
    /**
    * voice_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_bot_locale#voice_settings AwsLexv2ModelsBotLocale#voice_settings}
    */
    readonly voiceSettings?: AwsLexv2ModelsBotLocale.VoiceSettingsProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_bot_locale aws_lexv2models_bot_locale}
*/
export declare class AwsLexv2ModelsBotLocale extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_lexv2models_bot_locale";
    /**
    * Generates CDKTN code for importing a AwsLexv2ModelsBotLocale resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsLexv2ModelsBotLocale to import
    * @param importFromId The id of the existing AwsLexv2ModelsBotLocale that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_bot_locale#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsLexv2ModelsBotLocale to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_bot_locale aws_lexv2models_bot_locale} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsLexv2ModelsBotLocaleConfig
    */
    constructor(scope: Construct, id: string, config: AwsLexv2ModelsBotLocaleConfig);
    private _botId?;
    get botId(): string;
    set botId(value: string);
    get botIdInput(): string | undefined;
    private _botVersion?;
    get botVersion(): string;
    set botVersion(value: string);
    get botVersionInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _localeId?;
    get localeId(): string;
    set localeId(value: string);
    get localeIdInput(): string | undefined;
    private _nLuIntentConfidenceThreshold?;
    get nLuIntentConfidenceThreshold(): number;
    set nLuIntentConfidenceThreshold(value: number);
    get nLuIntentConfidenceThresholdInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _timeouts;
    get timeouts(): AwsLexv2ModelsBotLocale.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsLexv2ModelsBotLocale.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): AwsLexv2ModelsBotLocale.TimeoutsProperty | cdktn.IResolvable | undefined;
    private _voiceSettings;
    get voiceSettings(): AwsLexv2ModelsBotLocale.VoiceSettingsPropertyList;
    putVoiceSettings(value: AwsLexv2ModelsBotLocale.VoiceSettingsProperty[] | cdktn.IResolvable): void;
    resetVoiceSettings(): void;
    get voiceSettingsInput(): cdktn.IResolvable | AwsLexv2ModelsBotLocale.VoiceSettingsProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsLexv2ModelsBotLocaleTimeoutsPropertyToTerraform(struct?: AwsLexv2ModelsBotLocale.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsLexv2ModelsBotLocaleTimeoutsPropertyToHclTerraform(struct?: AwsLexv2ModelsBotLocale.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsLexv2ModelsBotLocaleVoiceSettingsPropertyToTerraform(struct?: AwsLexv2ModelsBotLocale.VoiceSettingsProperty | cdktn.IResolvable): any;
export declare function awsLexv2ModelsBotLocaleVoiceSettingsPropertyToHclTerraform(struct?: AwsLexv2ModelsBotLocale.VoiceSettingsProperty | cdktn.IResolvable): any;
export declare namespace AwsLexv2ModelsBotLocale {
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_bot_locale#create AwsLexv2ModelsBotLocale#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_bot_locale#delete AwsLexv2ModelsBotLocale#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_bot_locale#update AwsLexv2ModelsBotLocale#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface VoiceSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_bot_locale#engine AwsLexv2ModelsBotLocale#engine}
        */
        readonly engine?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_bot_locale#voice_id AwsLexv2ModelsBotLocale#voice_id}
        */
        readonly voiceId: string;
    }
    class VoiceSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VoiceSettingsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VoiceSettingsProperty | cdktn.IResolvable | undefined);
        private _engine?;
        get engine(): string;
        set engine(value: string);
        resetEngine(): void;
        get engineInput(): string | undefined;
        private _voiceId?;
        get voiceId(): string;
        set voiceId(value: string);
        get voiceIdInput(): string | undefined;
    }
    class VoiceSettingsPropertyList extends cdktn.ComplexList {
        internalValue?: VoiceSettingsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VoiceSettingsPropertyOutputReference;
    }
}
