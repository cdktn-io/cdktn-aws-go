import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsLexv2ModelsBotVersionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_bot_version#bot_id AwsLexv2ModelsBotVersion#bot_id}
    */
    readonly botId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_bot_version#bot_version AwsLexv2ModelsBotVersion#bot_version}
    */
    readonly botVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_bot_version#description AwsLexv2ModelsBotVersion#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_bot_version#locale_specification AwsLexv2ModelsBotVersion#locale_specification}
    */
    readonly localeSpecification: {
        [key: string]: AwsLexv2ModelsBotVersion.LocaleSpecificationProperty;
    } | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_bot_version#region AwsLexv2ModelsBotVersion#region}
    */
    readonly region?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_bot_version#timeouts AwsLexv2ModelsBotVersion#timeouts}
    */
    readonly timeouts?: AwsLexv2ModelsBotVersion.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_bot_version aws_lexv2models_bot_version}
*/
export declare class AwsLexv2ModelsBotVersion extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_lexv2models_bot_version";
    /**
    * Generates CDKTN code for importing a AwsLexv2ModelsBotVersion resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsLexv2ModelsBotVersion to import
    * @param importFromId The id of the existing AwsLexv2ModelsBotVersion that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_bot_version#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsLexv2ModelsBotVersion to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_bot_version aws_lexv2models_bot_version} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsLexv2ModelsBotVersionConfig
    */
    constructor(scope: Construct, id: string, config: AwsLexv2ModelsBotVersionConfig);
    private _botId?;
    get botId(): string;
    set botId(value: string);
    get botIdInput(): string | undefined;
    private _botVersion?;
    get botVersion(): string;
    set botVersion(value: string);
    resetBotVersion(): void;
    get botVersionInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _localeSpecification;
    get localeSpecification(): AwsLexv2ModelsBotVersion.LocaleSpecificationPropertyMap;
    putLocaleSpecification(value: {
        [key: string]: AwsLexv2ModelsBotVersion.LocaleSpecificationProperty;
    } | cdktn.IResolvable): void;
    get localeSpecificationInput(): cdktn.IResolvable | {
        [key: string]: AwsLexv2ModelsBotVersion.LocaleSpecificationProperty;
    } | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _timeouts;
    get timeouts(): AwsLexv2ModelsBotVersion.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsLexv2ModelsBotVersion.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsLexv2ModelsBotVersion.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsLexv2ModelsBotVersionLocaleSpecificationPropertyToTerraform(struct?: AwsLexv2ModelsBotVersion.LocaleSpecificationProperty | cdktn.IResolvable): any;
export declare function awsLexv2ModelsBotVersionLocaleSpecificationPropertyToHclTerraform(struct?: AwsLexv2ModelsBotVersion.LocaleSpecificationProperty | cdktn.IResolvable): any;
export declare function awsLexv2ModelsBotVersionTimeoutsPropertyToTerraform(struct?: AwsLexv2ModelsBotVersion.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsLexv2ModelsBotVersionTimeoutsPropertyToHclTerraform(struct?: AwsLexv2ModelsBotVersion.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsLexv2ModelsBotVersion {
    interface LocaleSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_bot_version#source_bot_version AwsLexv2ModelsBotVersion#source_bot_version}
        */
        readonly sourceBotVersion: string;
    }
    class LocaleSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectKey the key of this item in the map
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
        get internalValue(): LocaleSpecificationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LocaleSpecificationProperty | cdktn.IResolvable | undefined);
        private _sourceBotVersion?;
        get sourceBotVersion(): string;
        set sourceBotVersion(value: string);
        get sourceBotVersionInput(): string | undefined;
    }
    class LocaleSpecificationPropertyMap extends cdktn.ComplexMap {
        internalValue?: {
            [key: string]: LocaleSpecificationProperty;
        } | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        /**
        * @param key the key of the item to return
        */
        get(key: string): LocaleSpecificationPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_bot_version#create AwsLexv2ModelsBotVersion#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lexv2models_bot_version#delete AwsLexv2ModelsBotVersion#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
