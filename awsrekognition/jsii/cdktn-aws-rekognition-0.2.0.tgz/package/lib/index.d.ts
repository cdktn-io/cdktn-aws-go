export * from './aws-rekognition-collection';
export * from './aws-rekognition-project';
export * from './aws-rekognition-stream-processor';
