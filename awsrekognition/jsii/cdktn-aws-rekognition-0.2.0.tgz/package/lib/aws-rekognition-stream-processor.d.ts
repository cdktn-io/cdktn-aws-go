import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfStreamProcessorConfig extends cdktn.TerraformMetaArguments {
    /**
    * The identifier for your AWS Key Management Service key (AWS KMS key). You can supply the Amazon Resource Name (ARN) of your KMS key, the ID of your KMS key, an alias for your KMS key, or an alias ARN.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rekognition_stream_processor#kms_key_id TfStreamProcessor#kms_key_id}
    */
    readonly kmsKeyId?: string;
    /**
    * An identifier you assign to the stream processor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rekognition_stream_processor#name TfStreamProcessor#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rekognition_stream_processor#region TfStreamProcessor#region}
    */
    readonly region?: string;
    /**
    * The Amazon Resource Number (ARN) of the IAM role that allows access to the stream processor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rekognition_stream_processor#role_arn TfStreamProcessor#role_arn}
    */
    readonly roleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rekognition_stream_processor#tags TfStreamProcessor#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * data_sharing_preference block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rekognition_stream_processor#data_sharing_preference TfStreamProcessor#data_sharing_preference}
    */
    readonly dataSharingPreference?: TfStreamProcessor.DataSharingPreferenceProperty[] | cdktn.IResolvable;
    /**
    * input block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rekognition_stream_processor#input TfStreamProcessor#input}
    */
    readonly input?: TfStreamProcessor.InputProperty[] | cdktn.IResolvable;
    /**
    * notification_channel block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rekognition_stream_processor#notification_channel TfStreamProcessor#notification_channel}
    */
    readonly notificationChannel?: TfStreamProcessor.NotificationChannelProperty[] | cdktn.IResolvable;
    /**
    * output block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rekognition_stream_processor#output TfStreamProcessor#output}
    */
    readonly output?: TfStreamProcessor.OutputProperty[] | cdktn.IResolvable;
    /**
    * regions_of_interest block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rekognition_stream_processor#regions_of_interest TfStreamProcessor#regions_of_interest}
    */
    readonly regionsOfInterest?: TfStreamProcessor.RegionsOfInterestProperty[] | cdktn.IResolvable;
    /**
    * settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rekognition_stream_processor#settings TfStreamProcessor#settings}
    */
    readonly settings?: TfStreamProcessor.SettingsProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rekognition_stream_processor#timeouts TfStreamProcessor#timeouts}
    */
    readonly timeouts?: TfStreamProcessor.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rekognition_stream_processor aws_rekognition_stream_processor}
*/
export declare class TfStreamProcessor extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_rekognition_stream_processor";
    /**
    * Generates CDKTN code for importing a TfStreamProcessor resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfStreamProcessor to import
    * @param importFromId The id of the existing TfStreamProcessor that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rekognition_stream_processor#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfStreamProcessor to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rekognition_stream_processor aws_rekognition_stream_processor} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfStreamProcessorConfig
    */
    constructor(scope: Construct, id: string, config: TfStreamProcessorConfig);
    get arn(): string;
    private _kmsKeyId?;
    get kmsKeyId(): string;
    set kmsKeyId(value: string);
    resetKmsKeyId(): void;
    get kmsKeyIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    get streamProcessorArn(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _dataSharingPreference;
    get dataSharingPreference(): TfStreamProcessor.DataSharingPreferencePropertyList;
    putDataSharingPreference(value: TfStreamProcessor.DataSharingPreferenceProperty[] | cdktn.IResolvable): void;
    resetDataSharingPreference(): void;
    get dataSharingPreferenceInput(): cdktn.IResolvable | TfStreamProcessor.DataSharingPreferenceProperty[] | undefined;
    private _input;
    get input(): TfStreamProcessor.InputPropertyList;
    putInput(value: TfStreamProcessor.InputProperty[] | cdktn.IResolvable): void;
    resetInput(): void;
    get inputInput(): cdktn.IResolvable | TfStreamProcessor.InputProperty[] | undefined;
    private _notificationChannel;
    get notificationChannel(): TfStreamProcessor.NotificationChannelPropertyList;
    putNotificationChannel(value: TfStreamProcessor.NotificationChannelProperty[] | cdktn.IResolvable): void;
    resetNotificationChannel(): void;
    get notificationChannelInput(): cdktn.IResolvable | TfStreamProcessor.NotificationChannelProperty[] | undefined;
    private _output;
    get output(): TfStreamProcessor.OutputPropertyList;
    putOutput(value: TfStreamProcessor.OutputProperty[] | cdktn.IResolvable): void;
    resetOutput(): void;
    get outputInput(): cdktn.IResolvable | TfStreamProcessor.OutputProperty[] | undefined;
    private _regionsOfInterest;
    get regionsOfInterest(): TfStreamProcessor.RegionsOfInterestPropertyList;
    putRegionsOfInterest(value: TfStreamProcessor.RegionsOfInterestProperty[] | cdktn.IResolvable): void;
    resetRegionsOfInterest(): void;
    get regionsOfInterestInput(): cdktn.IResolvable | TfStreamProcessor.RegionsOfInterestProperty[] | undefined;
    private _settings;
    get settings(): TfStreamProcessor.SettingsPropertyList;
    putSettings(value: TfStreamProcessor.SettingsProperty[] | cdktn.IResolvable): void;
    resetSettings(): void;
    get settingsInput(): cdktn.IResolvable | TfStreamProcessor.SettingsProperty[] | undefined;
    private _timeouts;
    get timeouts(): TfStreamProcessor.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfStreamProcessor.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfStreamProcessor.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfStreamProcessorDataSharingPreferencePropertyToTerraform(struct?: TfStreamProcessor.DataSharingPreferenceProperty | cdktn.IResolvable): any;
export declare function tfStreamProcessorDataSharingPreferencePropertyToHclTerraform(struct?: TfStreamProcessor.DataSharingPreferenceProperty | cdktn.IResolvable): any;
export declare function tfStreamProcessorKinesisVideoStreamPropertyToTerraform(struct?: TfStreamProcessor.KinesisVideoStreamProperty | cdktn.IResolvable): any;
export declare function tfStreamProcessorKinesisVideoStreamPropertyToHclTerraform(struct?: TfStreamProcessor.KinesisVideoStreamProperty | cdktn.IResolvable): any;
export declare function tfStreamProcessorInputPropertyToTerraform(struct?: TfStreamProcessor.InputProperty | cdktn.IResolvable): any;
export declare function tfStreamProcessorInputPropertyToHclTerraform(struct?: TfStreamProcessor.InputProperty | cdktn.IResolvable): any;
export declare function tfStreamProcessorNotificationChannelPropertyToTerraform(struct?: TfStreamProcessor.NotificationChannelProperty | cdktn.IResolvable): any;
export declare function tfStreamProcessorNotificationChannelPropertyToHclTerraform(struct?: TfStreamProcessor.NotificationChannelProperty | cdktn.IResolvable): any;
export declare function tfStreamProcessorKinesisDataStreamPropertyToTerraform(struct?: TfStreamProcessor.KinesisDataStreamProperty | cdktn.IResolvable): any;
export declare function tfStreamProcessorKinesisDataStreamPropertyToHclTerraform(struct?: TfStreamProcessor.KinesisDataStreamProperty | cdktn.IResolvable): any;
export declare function tfStreamProcessorS3DestinationPropertyToTerraform(struct?: TfStreamProcessor.S3DestinationProperty | cdktn.IResolvable): any;
export declare function tfStreamProcessorS3DestinationPropertyToHclTerraform(struct?: TfStreamProcessor.S3DestinationProperty | cdktn.IResolvable): any;
export declare function tfStreamProcessorOutputPropertyToTerraform(struct?: TfStreamProcessor.OutputProperty | cdktn.IResolvable): any;
export declare function tfStreamProcessorOutputPropertyToHclTerraform(struct?: TfStreamProcessor.OutputProperty | cdktn.IResolvable): any;
export declare function tfStreamProcessorBoundingBoxPropertyToTerraform(struct?: TfStreamProcessor.BoundingBoxProperty | cdktn.IResolvable): any;
export declare function tfStreamProcessorBoundingBoxPropertyToHclTerraform(struct?: TfStreamProcessor.BoundingBoxProperty | cdktn.IResolvable): any;
export declare function tfStreamProcessorPolygonPropertyToTerraform(struct?: TfStreamProcessor.PolygonProperty | cdktn.IResolvable): any;
export declare function tfStreamProcessorPolygonPropertyToHclTerraform(struct?: TfStreamProcessor.PolygonProperty | cdktn.IResolvable): any;
export declare function tfStreamProcessorRegionsOfInterestPropertyToTerraform(struct?: TfStreamProcessor.RegionsOfInterestProperty | cdktn.IResolvable): any;
export declare function tfStreamProcessorRegionsOfInterestPropertyToHclTerraform(struct?: TfStreamProcessor.RegionsOfInterestProperty | cdktn.IResolvable): any;
export declare function tfStreamProcessorConnectedHomePropertyToTerraform(struct?: TfStreamProcessor.ConnectedHomeProperty | cdktn.IResolvable): any;
export declare function tfStreamProcessorConnectedHomePropertyToHclTerraform(struct?: TfStreamProcessor.ConnectedHomeProperty | cdktn.IResolvable): any;
export declare function tfStreamProcessorFaceSearchPropertyToTerraform(struct?: TfStreamProcessor.FaceSearchProperty | cdktn.IResolvable): any;
export declare function tfStreamProcessorFaceSearchPropertyToHclTerraform(struct?: TfStreamProcessor.FaceSearchProperty | cdktn.IResolvable): any;
export declare function tfStreamProcessorSettingsPropertyToTerraform(struct?: TfStreamProcessor.SettingsProperty | cdktn.IResolvable): any;
export declare function tfStreamProcessorSettingsPropertyToHclTerraform(struct?: TfStreamProcessor.SettingsProperty | cdktn.IResolvable): any;
export declare function tfStreamProcessorTimeoutsPropertyToTerraform(struct?: TfStreamProcessor.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfStreamProcessorTimeoutsPropertyToHclTerraform(struct?: TfStreamProcessor.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfStreamProcessor {
    interface DataSharingPreferenceProperty {
        /**
        * Do you want to share data with Rekognition to improve model performance.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rekognition_stream_processor#opt_in TfStreamProcessor#opt_in}
        */
        readonly optIn: boolean | cdktn.IResolvable;
    }
    class DataSharingPreferencePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataSharingPreferenceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DataSharingPreferenceProperty | cdktn.IResolvable | undefined);
        private _optIn?;
        get optIn(): boolean | cdktn.IResolvable;
        set optIn(value: boolean | cdktn.IResolvable);
        get optInInput(): boolean | cdktn.IResolvable | undefined;
    }
    class DataSharingPreferencePropertyList extends cdktn.ComplexList {
        internalValue?: DataSharingPreferenceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataSharingPreferencePropertyOutputReference;
    }
    interface KinesisVideoStreamProperty {
        /**
        * ARN of the Kinesis video stream stream that streams the source video.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rekognition_stream_processor#arn TfStreamProcessor#arn}
        */
        readonly arn: string;
    }
    class KinesisVideoStreamPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KinesisVideoStreamProperty | cdktn.IResolvable | undefined;
        set internalValue(value: KinesisVideoStreamProperty | cdktn.IResolvable | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
    }
    class KinesisVideoStreamPropertyList extends cdktn.ComplexList {
        internalValue?: KinesisVideoStreamProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KinesisVideoStreamPropertyOutputReference;
    }
    interface InputProperty {
        /**
        * kinesis_video_stream block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rekognition_stream_processor#kinesis_video_stream TfStreamProcessor#kinesis_video_stream}
        */
        readonly kinesisVideoStream?: KinesisVideoStreamProperty[] | cdktn.IResolvable;
    }
    class InputPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InputProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InputProperty | cdktn.IResolvable | undefined);
        private _kinesisVideoStream;
        get kinesisVideoStream(): KinesisVideoStreamPropertyList;
        putKinesisVideoStream(value: KinesisVideoStreamProperty[] | cdktn.IResolvable): void;
        resetKinesisVideoStream(): void;
        get kinesisVideoStreamInput(): cdktn.IResolvable | KinesisVideoStreamProperty[] | undefined;
    }
    class InputPropertyList extends cdktn.ComplexList {
        internalValue?: InputProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InputPropertyOutputReference;
    }
    interface NotificationChannelProperty {
        /**
        * The Amazon Resource Number (ARN) of the Amazon Amazon Simple Notification Service topic to which Amazon Rekognition posts the completion status.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rekognition_stream_processor#sns_topic_arn TfStreamProcessor#sns_topic_arn}
        */
        readonly snsTopicArn?: string;
    }
    class NotificationChannelPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NotificationChannelProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NotificationChannelProperty | cdktn.IResolvable | undefined);
        private _snsTopicArn?;
        get snsTopicArn(): string;
        set snsTopicArn(value: string);
        resetSnsTopicArn(): void;
        get snsTopicArnInput(): string | undefined;
    }
    class NotificationChannelPropertyList extends cdktn.ComplexList {
        internalValue?: NotificationChannelProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NotificationChannelPropertyOutputReference;
    }
    interface KinesisDataStreamProperty {
        /**
        * ARN of the output Amazon Kinesis Data Streams stream.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rekognition_stream_processor#arn TfStreamProcessor#arn}
        */
        readonly arn?: string;
    }
    class KinesisDataStreamPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KinesisDataStreamProperty | cdktn.IResolvable | undefined;
        set internalValue(value: KinesisDataStreamProperty | cdktn.IResolvable | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        resetArn(): void;
        get arnInput(): string | undefined;
    }
    class KinesisDataStreamPropertyList extends cdktn.ComplexList {
        internalValue?: KinesisDataStreamProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KinesisDataStreamPropertyOutputReference;
    }
    interface S3DestinationProperty {
        /**
        * The name of the Amazon S3 bucket you want to associate with the streaming video project.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rekognition_stream_processor#bucket TfStreamProcessor#bucket}
        */
        readonly bucket?: string;
        /**
        * The prefix value of the location within the bucket that you want the information to be published to.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rekognition_stream_processor#key_prefix TfStreamProcessor#key_prefix}
        */
        readonly keyPrefix?: string;
    }
    class S3DestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3DestinationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: S3DestinationProperty | cdktn.IResolvable | undefined);
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        resetBucket(): void;
        get bucketInput(): string | undefined;
        private _keyPrefix?;
        get keyPrefix(): string;
        set keyPrefix(value: string);
        resetKeyPrefix(): void;
        get keyPrefixInput(): string | undefined;
    }
    class S3DestinationPropertyList extends cdktn.ComplexList {
        internalValue?: S3DestinationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3DestinationPropertyOutputReference;
    }
    interface OutputProperty {
        /**
        * kinesis_data_stream block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rekognition_stream_processor#kinesis_data_stream TfStreamProcessor#kinesis_data_stream}
        */
        readonly kinesisDataStream?: KinesisDataStreamProperty[] | cdktn.IResolvable;
        /**
        * s3_destination block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rekognition_stream_processor#s3_destination TfStreamProcessor#s3_destination}
        */
        readonly s3Destination?: S3DestinationProperty[] | cdktn.IResolvable;
    }
    class OutputPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OutputProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OutputProperty | cdktn.IResolvable | undefined);
        private _kinesisDataStream;
        get kinesisDataStream(): KinesisDataStreamPropertyList;
        putKinesisDataStream(value: KinesisDataStreamProperty[] | cdktn.IResolvable): void;
        resetKinesisDataStream(): void;
        get kinesisDataStreamInput(): cdktn.IResolvable | KinesisDataStreamProperty[] | undefined;
        private _s3Destination;
        get s3Destination(): S3DestinationPropertyList;
        putS3Destination(value: S3DestinationProperty[] | cdktn.IResolvable): void;
        resetS3Destination(): void;
        get s3DestinationInput(): cdktn.IResolvable | S3DestinationProperty[] | undefined;
    }
    class OutputPropertyList extends cdktn.ComplexList {
        internalValue?: OutputProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OutputPropertyOutputReference;
    }
    interface BoundingBoxProperty {
        /**
        * Height of the bounding box as a ratio of the overall image height.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rekognition_stream_processor#height TfStreamProcessor#height}
        */
        readonly height?: number;
        /**
        * Left coordinate of the bounding box as a ratio of overall image width.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rekognition_stream_processor#left TfStreamProcessor#left}
        */
        readonly left?: number;
        /**
        * Top coordinate of the bounding box as a ratio of overall image height.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rekognition_stream_processor#top TfStreamProcessor#top}
        */
        readonly top?: number;
        /**
        * Width of the bounding box as a ratio of the overall image width.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rekognition_stream_processor#width TfStreamProcessor#width}
        */
        readonly width?: number;
    }
    class BoundingBoxPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BoundingBoxProperty | cdktn.IResolvable | undefined;
        set internalValue(value: BoundingBoxProperty | cdktn.IResolvable | undefined);
        private _height?;
        get height(): number;
        set height(value: number);
        resetHeight(): void;
        get heightInput(): number | undefined;
        private _left?;
        get left(): number;
        set left(value: number);
        resetLeft(): void;
        get leftInput(): number | undefined;
        private _top?;
        get top(): number;
        set top(value: number);
        resetTop(): void;
        get topInput(): number | undefined;
        private _width?;
        get width(): number;
        set width(value: number);
        resetWidth(): void;
        get widthInput(): number | undefined;
    }
    class BoundingBoxPropertyList extends cdktn.ComplexList {
        internalValue?: BoundingBoxProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BoundingBoxPropertyOutputReference;
    }
    interface PolygonProperty {
        /**
        * The value of the X coordinate for a point on a Polygon.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rekognition_stream_processor#x TfStreamProcessor#x}
        */
        readonly x?: number;
        /**
        * The value of the Y coordinate for a point on a Polygon.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rekognition_stream_processor#y TfStreamProcessor#y}
        */
        readonly y?: number;
    }
    class PolygonPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PolygonProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PolygonProperty | cdktn.IResolvable | undefined);
        private _x?;
        get x(): number;
        set x(value: number);
        resetX(): void;
        get xInput(): number | undefined;
        private _y?;
        get y(): number;
        set y(value: number);
        resetY(): void;
        get yInput(): number | undefined;
    }
    class PolygonPropertyList extends cdktn.ComplexList {
        internalValue?: PolygonProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PolygonPropertyOutputReference;
    }
    interface RegionsOfInterestProperty {
        /**
        * bounding_box block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rekognition_stream_processor#bounding_box TfStreamProcessor#bounding_box}
        */
        readonly boundingBox?: BoundingBoxProperty[] | cdktn.IResolvable;
        /**
        * polygon block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rekognition_stream_processor#polygon TfStreamProcessor#polygon}
        */
        readonly polygon?: PolygonProperty[] | cdktn.IResolvable;
    }
    class RegionsOfInterestPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RegionsOfInterestProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RegionsOfInterestProperty | cdktn.IResolvable | undefined);
        private _boundingBox;
        get boundingBox(): BoundingBoxPropertyList;
        putBoundingBox(value: BoundingBoxProperty[] | cdktn.IResolvable): void;
        resetBoundingBox(): void;
        get boundingBoxInput(): cdktn.IResolvable | BoundingBoxProperty[] | undefined;
        private _polygon;
        get polygon(): PolygonPropertyList;
        putPolygon(value: PolygonProperty[] | cdktn.IResolvable): void;
        resetPolygon(): void;
        get polygonInput(): cdktn.IResolvable | PolygonProperty[] | undefined;
    }
    class RegionsOfInterestPropertyList extends cdktn.ComplexList {
        internalValue?: RegionsOfInterestProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RegionsOfInterestPropertyOutputReference;
    }
    interface ConnectedHomeProperty {
        /**
        * Specifies what you want to detect in the video, such as people, packages, or pets.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rekognition_stream_processor#labels TfStreamProcessor#labels}
        */
        readonly labels?: string[];
        /**
        * The minimum confidence required to label an object in the video.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rekognition_stream_processor#min_confidence TfStreamProcessor#min_confidence}
        */
        readonly minConfidence?: number;
    }
    class ConnectedHomePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConnectedHomeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConnectedHomeProperty | cdktn.IResolvable | undefined);
        private _labels?;
        get labels(): string[];
        set labels(value: string[]);
        resetLabels(): void;
        get labelsInput(): string[] | undefined;
        private _minConfidence?;
        get minConfidence(): number;
        set minConfidence(value: number);
        resetMinConfidence(): void;
        get minConfidenceInput(): number | undefined;
    }
    class ConnectedHomePropertyList extends cdktn.ComplexList {
        internalValue?: ConnectedHomeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConnectedHomePropertyOutputReference;
    }
    interface FaceSearchProperty {
        /**
        * The ID of a collection that contains faces that you want to search for.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rekognition_stream_processor#collection_id TfStreamProcessor#collection_id}
        */
        readonly collectionId: string;
        /**
        * Minimum face match confidence score that must be met to return a result for a recognized face.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rekognition_stream_processor#face_match_threshold TfStreamProcessor#face_match_threshold}
        */
        readonly faceMatchThreshold?: number;
    }
    class FaceSearchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FaceSearchProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FaceSearchProperty | cdktn.IResolvable | undefined);
        private _collectionId?;
        get collectionId(): string;
        set collectionId(value: string);
        get collectionIdInput(): string | undefined;
        private _faceMatchThreshold?;
        get faceMatchThreshold(): number;
        set faceMatchThreshold(value: number);
        resetFaceMatchThreshold(): void;
        get faceMatchThresholdInput(): number | undefined;
    }
    class FaceSearchPropertyList extends cdktn.ComplexList {
        internalValue?: FaceSearchProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FaceSearchPropertyOutputReference;
    }
    interface SettingsProperty {
        /**
        * connected_home block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rekognition_stream_processor#connected_home TfStreamProcessor#connected_home}
        */
        readonly connectedHome?: ConnectedHomeProperty[] | cdktn.IResolvable;
        /**
        * face_search block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rekognition_stream_processor#face_search TfStreamProcessor#face_search}
        */
        readonly faceSearch?: FaceSearchProperty[] | cdktn.IResolvable;
    }
    class SettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SettingsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SettingsProperty | cdktn.IResolvable | undefined);
        private _connectedHome;
        get connectedHome(): ConnectedHomePropertyList;
        putConnectedHome(value: ConnectedHomeProperty[] | cdktn.IResolvable): void;
        resetConnectedHome(): void;
        get connectedHomeInput(): cdktn.IResolvable | ConnectedHomeProperty[] | undefined;
        private _faceSearch;
        get faceSearch(): FaceSearchPropertyList;
        putFaceSearch(value: FaceSearchProperty[] | cdktn.IResolvable): void;
        resetFaceSearch(): void;
        get faceSearchInput(): cdktn.IResolvable | FaceSearchProperty[] | undefined;
    }
    class SettingsPropertyList extends cdktn.ComplexList {
        internalValue?: SettingsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SettingsPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rekognition_stream_processor#create TfStreamProcessor#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rekognition_stream_processor#delete TfStreamProcessor#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rekognition_stream_processor#update TfStreamProcessor#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
