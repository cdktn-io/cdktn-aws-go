import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsRekognitionCollectionConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the Rekognition collection
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rekognition_collection#collection_id AwsRekognitionCollection#collection_id}
    */
    readonly collectionId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rekognition_collection#region AwsRekognitionCollection#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rekognition_collection#tags AwsRekognitionCollection#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rekognition_collection#timeouts AwsRekognitionCollection#timeouts}
    */
    readonly timeouts?: AwsRekognitionCollection.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rekognition_collection aws_rekognition_collection}
*/
export declare class AwsRekognitionCollection extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_rekognition_collection";
    /**
    * Generates CDKTN code for importing a AwsRekognitionCollection resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsRekognitionCollection to import
    * @param importFromId The id of the existing AwsRekognitionCollection that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rekognition_collection#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsRekognitionCollection to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rekognition_collection aws_rekognition_collection} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsRekognitionCollectionConfig
    */
    constructor(scope: Construct, id: string, config: AwsRekognitionCollectionConfig);
    get arn(): string;
    private _collectionId?;
    get collectionId(): string;
    set collectionId(value: string);
    get collectionIdInput(): string | undefined;
    get faceModelVersion(): string;
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _timeouts;
    get timeouts(): AwsRekognitionCollection.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsRekognitionCollection.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): AwsRekognitionCollection.TimeoutsProperty | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsRekognitionCollectionTimeoutsPropertyToTerraform(struct?: AwsRekognitionCollection.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsRekognitionCollectionTimeoutsPropertyToHclTerraform(struct?: AwsRekognitionCollection.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsRekognitionCollection {
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rekognition_collection#create AwsRekognitionCollection#create}
        */
        readonly create?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
    }
}
