import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsPlanConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#description AwsPlan#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#execution_role AwsPlan#execution_role}
    */
    readonly executionRole: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#name AwsPlan#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#primary_region AwsPlan#primary_region}
    */
    readonly primaryRegion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#recovery_approach AwsPlan#recovery_approach}
    */
    readonly recoveryApproach: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#recovery_time_objective_minutes AwsPlan#recovery_time_objective_minutes}
    */
    readonly recoveryTimeObjectiveMinutes?: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region AwsPlan#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#regions AwsPlan#regions}
    */
    readonly regions: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#tags AwsPlan#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * associated_alarms block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#associated_alarms AwsPlan#associated_alarms}
    */
    readonly associatedAlarms?: AwsPlan.AssociatedAlarmsProperty[] | cdktn.IResolvable;
    /**
    * report_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#report_configuration AwsPlan#report_configuration}
    */
    readonly reportConfiguration?: AwsPlan.ReportConfigurationProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeouts AwsPlan#timeouts}
    */
    readonly timeouts?: AwsPlan.TimeoutsProperty;
    /**
    * triggers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#triggers AwsPlan#triggers}
    */
    readonly triggers?: AwsPlan.TriggersProperty[] | cdktn.IResolvable;
    /**
    * workflow block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#workflow AwsPlan#workflow}
    */
    readonly workflow?: AwsPlan.WorkflowProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan aws_arcregionswitch_plan}
*/
export declare class AwsPlan extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_arcregionswitch_plan";
    /**
    * Generates CDKTN code for importing a AwsPlan resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsPlan to import
    * @param importFromId The id of the existing AwsPlan that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsPlan to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan aws_arcregionswitch_plan} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsPlanConfig
    */
    constructor(scope: Construct, id: string, config: AwsPlanConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _executionRole?;
    get executionRole(): string;
    set executionRole(value: string);
    get executionRoleInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _primaryRegion?;
    get primaryRegion(): string;
    set primaryRegion(value: string);
    resetPrimaryRegion(): void;
    get primaryRegionInput(): string | undefined;
    private _recoveryApproach?;
    get recoveryApproach(): string;
    set recoveryApproach(value: string);
    get recoveryApproachInput(): string | undefined;
    private _recoveryTimeObjectiveMinutes?;
    get recoveryTimeObjectiveMinutes(): number;
    set recoveryTimeObjectiveMinutes(value: number);
    resetRecoveryTimeObjectiveMinutes(): void;
    get recoveryTimeObjectiveMinutesInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _regions?;
    get regions(): string[];
    set regions(value: string[]);
    get regionsInput(): string[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _associatedAlarms;
    get associatedAlarms(): AwsPlan.AssociatedAlarmsPropertyList;
    putAssociatedAlarms(value: AwsPlan.AssociatedAlarmsProperty[] | cdktn.IResolvable): void;
    resetAssociatedAlarms(): void;
    get associatedAlarmsInput(): cdktn.IResolvable | AwsPlan.AssociatedAlarmsProperty[] | undefined;
    private _reportConfiguration;
    get reportConfiguration(): AwsPlan.ReportConfigurationPropertyList;
    putReportConfiguration(value: AwsPlan.ReportConfigurationProperty[] | cdktn.IResolvable): void;
    resetReportConfiguration(): void;
    get reportConfigurationInput(): cdktn.IResolvable | AwsPlan.ReportConfigurationProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsPlan.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsPlan.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsPlan.TimeoutsProperty | undefined;
    private _triggers;
    get triggers(): AwsPlan.TriggersPropertyList;
    putTriggers(value: AwsPlan.TriggersProperty[] | cdktn.IResolvable): void;
    resetTriggers(): void;
    get triggersInput(): cdktn.IResolvable | AwsPlan.TriggersProperty[] | undefined;
    private _workflow;
    get workflow(): AwsPlan.WorkflowPropertyList;
    putWorkflow(value: AwsPlan.WorkflowProperty[] | cdktn.IResolvable): void;
    resetWorkflow(): void;
    get workflowInput(): cdktn.IResolvable | AwsPlan.WorkflowProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsPlanAssociatedAlarmsPropertyToTerraform(struct?: AwsPlan.AssociatedAlarmsProperty | cdktn.IResolvable): any;
export declare function awsPlanAssociatedAlarmsPropertyToHclTerraform(struct?: AwsPlan.AssociatedAlarmsProperty | cdktn.IResolvable): any;
export declare function awsPlanS3ConfigurationPropertyToTerraform(struct?: AwsPlan.S3ConfigurationProperty | cdktn.IResolvable): any;
export declare function awsPlanS3ConfigurationPropertyToHclTerraform(struct?: AwsPlan.S3ConfigurationProperty | cdktn.IResolvable): any;
export declare function awsPlanReportOutputPropertyToTerraform(struct?: AwsPlan.ReportOutputProperty | cdktn.IResolvable): any;
export declare function awsPlanReportOutputPropertyToHclTerraform(struct?: AwsPlan.ReportOutputProperty | cdktn.IResolvable): any;
export declare function awsPlanReportConfigurationPropertyToTerraform(struct?: AwsPlan.ReportConfigurationProperty | cdktn.IResolvable): any;
export declare function awsPlanReportConfigurationPropertyToHclTerraform(struct?: AwsPlan.ReportConfigurationProperty | cdktn.IResolvable): any;
export declare function awsPlanTimeoutsPropertyToTerraform(struct?: AwsPlan.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsPlanTimeoutsPropertyToHclTerraform(struct?: AwsPlan.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsPlanConditionsPropertyToTerraform(struct?: AwsPlan.ConditionsProperty | cdktn.IResolvable): any;
export declare function awsPlanConditionsPropertyToHclTerraform(struct?: AwsPlan.ConditionsProperty | cdktn.IResolvable): any;
export declare function awsPlanTriggersPropertyToTerraform(struct?: AwsPlan.TriggersProperty | cdktn.IResolvable): any;
export declare function awsPlanTriggersPropertyToHclTerraform(struct?: AwsPlan.TriggersProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlPropertyToTerraform(struct?: AwsPlan.WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepArcRoutingControlConfigRegionAndRoutingControlsPropertyToTerraform(struct?: AwsPlan.WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepArcRoutingControlConfigRegionAndRoutingControlsPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepArcRoutingControlConfigPropertyToTerraform(struct?: AwsPlan.WorkflowStepArcRoutingControlConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepArcRoutingControlConfigPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepArcRoutingControlConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepAuroraProvisionedScalingConfigPropertyToTerraform(struct?: AwsPlan.WorkflowStepAuroraProvisionedScalingConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepAuroraProvisionedScalingConfigPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepAuroraProvisionedScalingConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepAuroraServerlessScalingConfigPropertyToTerraform(struct?: AwsPlan.WorkflowStepAuroraServerlessScalingConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepAuroraServerlessScalingConfigPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepAuroraServerlessScalingConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepCustomActionLambdaConfigLambdaPropertyToTerraform(struct?: AwsPlan.WorkflowStepCustomActionLambdaConfigLambdaProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepCustomActionLambdaConfigLambdaPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepCustomActionLambdaConfigLambdaProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepCustomActionLambdaConfigUngracefulPropertyToTerraform(struct?: AwsPlan.WorkflowStepCustomActionLambdaConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepCustomActionLambdaConfigUngracefulPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepCustomActionLambdaConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepCustomActionLambdaConfigPropertyToTerraform(struct?: AwsPlan.WorkflowStepCustomActionLambdaConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepCustomActionLambdaConfigPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepCustomActionLambdaConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepDocumentDbConfigUngracefulPropertyToTerraform(struct?: AwsPlan.WorkflowStepDocumentDbConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepDocumentDbConfigUngracefulPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepDocumentDbConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepDocumentDbConfigPropertyToTerraform(struct?: AwsPlan.WorkflowStepDocumentDbConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepDocumentDbConfigPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepDocumentDbConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepEc2AsgCapacityIncreaseConfigAsgPropertyToTerraform(struct?: AwsPlan.WorkflowStepEc2AsgCapacityIncreaseConfigAsgProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepEc2AsgCapacityIncreaseConfigAsgPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepEc2AsgCapacityIncreaseConfigAsgProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepEc2AsgCapacityIncreaseConfigUngracefulPropertyToTerraform(struct?: AwsPlan.WorkflowStepEc2AsgCapacityIncreaseConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepEc2AsgCapacityIncreaseConfigUngracefulPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepEc2AsgCapacityIncreaseConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepEc2AsgCapacityIncreaseConfigPropertyToTerraform(struct?: AwsPlan.WorkflowStepEc2AsgCapacityIncreaseConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepEc2AsgCapacityIncreaseConfigPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepEc2AsgCapacityIncreaseConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepEcsCapacityIncreaseConfigServicePropertyToTerraform(struct?: AwsPlan.WorkflowStepEcsCapacityIncreaseConfigServiceProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepEcsCapacityIncreaseConfigServicePropertyToHclTerraform(struct?: AwsPlan.WorkflowStepEcsCapacityIncreaseConfigServiceProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepEcsCapacityIncreaseConfigUngracefulPropertyToTerraform(struct?: AwsPlan.WorkflowStepEcsCapacityIncreaseConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepEcsCapacityIncreaseConfigUngracefulPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepEcsCapacityIncreaseConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepEcsCapacityIncreaseConfigPropertyToTerraform(struct?: AwsPlan.WorkflowStepEcsCapacityIncreaseConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepEcsCapacityIncreaseConfigPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepEcsCapacityIncreaseConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepEksResourceScalingConfigEksClustersPropertyToTerraform(struct?: AwsPlan.WorkflowStepEksResourceScalingConfigEksClustersProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepEksResourceScalingConfigEksClustersPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepEksResourceScalingConfigEksClustersProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepEksResourceScalingConfigKubernetesResourceTypePropertyToTerraform(struct?: AwsPlan.WorkflowStepEksResourceScalingConfigKubernetesResourceTypeProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepEksResourceScalingConfigKubernetesResourceTypePropertyToHclTerraform(struct?: AwsPlan.WorkflowStepEksResourceScalingConfigKubernetesResourceTypeProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepEksResourceScalingConfigScalingResourcesResourcesPropertyToTerraform(struct?: AwsPlan.WorkflowStepEksResourceScalingConfigScalingResourcesResourcesProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepEksResourceScalingConfigScalingResourcesResourcesPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepEksResourceScalingConfigScalingResourcesResourcesProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepEksResourceScalingConfigScalingResourcesPropertyToTerraform(struct?: AwsPlan.WorkflowStepEksResourceScalingConfigScalingResourcesProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepEksResourceScalingConfigScalingResourcesPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepEksResourceScalingConfigScalingResourcesProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepEksResourceScalingConfigUngracefulPropertyToTerraform(struct?: AwsPlan.WorkflowStepEksResourceScalingConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepEksResourceScalingConfigUngracefulPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepEksResourceScalingConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepEksResourceScalingConfigPropertyToTerraform(struct?: AwsPlan.WorkflowStepEksResourceScalingConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepEksResourceScalingConfigPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepEksResourceScalingConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepExecutionApprovalConfigPropertyToTerraform(struct?: AwsPlan.WorkflowStepExecutionApprovalConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepExecutionApprovalConfigPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepExecutionApprovalConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepGlobalAuroraConfigUngracefulPropertyToTerraform(struct?: AwsPlan.WorkflowStepGlobalAuroraConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepGlobalAuroraConfigUngracefulPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepGlobalAuroraConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepGlobalAuroraConfigPropertyToTerraform(struct?: AwsPlan.WorkflowStepGlobalAuroraConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepGlobalAuroraConfigPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepGlobalAuroraConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMappingPropertyToTerraform(struct?: AwsPlan.WorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMappingPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepLambdaEventSourceMappingConfigUngracefulPropertyToTerraform(struct?: AwsPlan.WorkflowStepLambdaEventSourceMappingConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepLambdaEventSourceMappingConfigUngracefulPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepLambdaEventSourceMappingConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepLambdaEventSourceMappingConfigPropertyToTerraform(struct?: AwsPlan.WorkflowStepLambdaEventSourceMappingConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepLambdaEventSourceMappingConfigPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepLambdaEventSourceMappingConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepNeptuneGlobalDatabaseConfigUngracefulPropertyToTerraform(struct?: AwsPlan.WorkflowStepNeptuneGlobalDatabaseConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepNeptuneGlobalDatabaseConfigUngracefulPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepNeptuneGlobalDatabaseConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepNeptuneGlobalDatabaseConfigPropertyToTerraform(struct?: AwsPlan.WorkflowStepNeptuneGlobalDatabaseConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepNeptuneGlobalDatabaseConfigPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepNeptuneGlobalDatabaseConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlPropertyToTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsPropertyToTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepArcRoutingControlConfigPropertyToTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepArcRoutingControlConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepArcRoutingControlConfigPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepArcRoutingControlConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepAuroraProvisionedScalingConfigPropertyToTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepAuroraProvisionedScalingConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepAuroraProvisionedScalingConfigPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepAuroraProvisionedScalingConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepAuroraServerlessScalingConfigPropertyToTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepAuroraServerlessScalingConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepAuroraServerlessScalingConfigPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepAuroraServerlessScalingConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigLambdaPropertyToTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepCustomActionLambdaConfigLambdaProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigLambdaPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepCustomActionLambdaConfigLambdaProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigUngracefulPropertyToTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepCustomActionLambdaConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigUngracefulPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepCustomActionLambdaConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigPropertyToTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepCustomActionLambdaConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepCustomActionLambdaConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepDocumentDbConfigUngracefulPropertyToTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepDocumentDbConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepDocumentDbConfigUngracefulPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepDocumentDbConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepDocumentDbConfigPropertyToTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepDocumentDbConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepDocumentDbConfigPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepDocumentDbConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsgPropertyToTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsgProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsgPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsgProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngracefulPropertyToTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngracefulPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigPropertyToTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigServicePropertyToTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigServiceProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigServicePropertyToHclTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigServiceProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngracefulPropertyToTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngracefulPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigPropertyToTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepEksResourceScalingConfigEksClustersPropertyToTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepEksResourceScalingConfigEksClustersProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepEksResourceScalingConfigEksClustersPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepEksResourceScalingConfigEksClustersProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceTypePropertyToTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceTypeProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceTypePropertyToHclTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceTypeProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResourcesPropertyToTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResourcesProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResourcesPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResourcesProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesPropertyToTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepEksResourceScalingConfigUngracefulPropertyToTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepEksResourceScalingConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepEksResourceScalingConfigUngracefulPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepEksResourceScalingConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepEksResourceScalingConfigPropertyToTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepEksResourceScalingConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepEksResourceScalingConfigPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepEksResourceScalingConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepExecutionApprovalConfigPropertyToTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepExecutionApprovalConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepExecutionApprovalConfigPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepExecutionApprovalConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepGlobalAuroraConfigUngracefulPropertyToTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepGlobalAuroraConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepGlobalAuroraConfigUngracefulPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepGlobalAuroraConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepGlobalAuroraConfigPropertyToTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepGlobalAuroraConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepGlobalAuroraConfigPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepGlobalAuroraConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMappingPropertyToTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMappingPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngracefulPropertyToTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngracefulPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigPropertyToTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngracefulPropertyToTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngracefulPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigPropertyToTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfigPropertyToTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfigPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepRdsPromoteReadReplicaConfigPropertyToTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepRdsPromoteReadReplicaConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepRdsPromoteReadReplicaConfigPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepRdsPromoteReadReplicaConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepRegionSwitchPlanConfigPropertyToTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepRegionSwitchPlanConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepRegionSwitchPlanConfigPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepRegionSwitchPlanConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSetPropertyToTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSetProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSetPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSetProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepRoute53HealthCheckConfigPropertyToTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepRoute53HealthCheckConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepRoute53HealthCheckConfigPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepRoute53HealthCheckConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepPropertyToTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepParallelConfigStepPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepParallelConfigStepProperty | cdktn.IResolvable): any;
export declare function awsPlanParallelConfigPropertyToTerraform(struct?: AwsPlan.ParallelConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanParallelConfigPropertyToHclTerraform(struct?: AwsPlan.ParallelConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepRdsCreateCrossRegionReadReplicaConfigPropertyToTerraform(struct?: AwsPlan.WorkflowStepRdsCreateCrossRegionReadReplicaConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepRdsCreateCrossRegionReadReplicaConfigPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepRdsCreateCrossRegionReadReplicaConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepRdsPromoteReadReplicaConfigPropertyToTerraform(struct?: AwsPlan.WorkflowStepRdsPromoteReadReplicaConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepRdsPromoteReadReplicaConfigPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepRdsPromoteReadReplicaConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepRegionSwitchPlanConfigPropertyToTerraform(struct?: AwsPlan.WorkflowStepRegionSwitchPlanConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepRegionSwitchPlanConfigPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepRegionSwitchPlanConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepRoute53HealthCheckConfigRecordSetPropertyToTerraform(struct?: AwsPlan.WorkflowStepRoute53HealthCheckConfigRecordSetProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepRoute53HealthCheckConfigRecordSetPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepRoute53HealthCheckConfigRecordSetProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepRoute53HealthCheckConfigPropertyToTerraform(struct?: AwsPlan.WorkflowStepRoute53HealthCheckConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepRoute53HealthCheckConfigPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepRoute53HealthCheckConfigProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepPropertyToTerraform(struct?: AwsPlan.WorkflowStepProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowStepPropertyToHclTerraform(struct?: AwsPlan.WorkflowStepProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowPropertyToTerraform(struct?: AwsPlan.WorkflowProperty | cdktn.IResolvable): any;
export declare function awsPlanWorkflowPropertyToHclTerraform(struct?: AwsPlan.WorkflowProperty | cdktn.IResolvable): any;
export declare namespace AwsPlan {
    interface AssociatedAlarmsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#alarm_type AwsPlan#alarm_type}
        */
        readonly alarmType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#map_block_key AwsPlan#map_block_key}
        */
        readonly mapBlockKey: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#resource_identifier AwsPlan#resource_identifier}
        */
        readonly resourceIdentifier: string;
    }
    class AssociatedAlarmsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AssociatedAlarmsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AssociatedAlarmsProperty | cdktn.IResolvable | undefined);
        private _alarmType?;
        get alarmType(): string;
        set alarmType(value: string);
        get alarmTypeInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _mapBlockKey?;
        get mapBlockKey(): string;
        set mapBlockKey(value: string);
        get mapBlockKeyInput(): string | undefined;
        private _resourceIdentifier?;
        get resourceIdentifier(): string;
        set resourceIdentifier(value: string);
        get resourceIdentifierInput(): string | undefined;
    }
    class AssociatedAlarmsPropertyList extends cdktn.ComplexList {
        internalValue?: AssociatedAlarmsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AssociatedAlarmsPropertyOutputReference;
    }
    interface S3ConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#bucket_owner AwsPlan#bucket_owner}
        */
        readonly bucketOwner: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#bucket_path AwsPlan#bucket_path}
        */
        readonly bucketPath: string;
    }
    class S3ConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3ConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: S3ConfigurationProperty | cdktn.IResolvable | undefined);
        private _bucketOwner?;
        get bucketOwner(): string;
        set bucketOwner(value: string);
        get bucketOwnerInput(): string | undefined;
        private _bucketPath?;
        get bucketPath(): string;
        set bucketPath(value: string);
        get bucketPathInput(): string | undefined;
    }
    class S3ConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: S3ConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3ConfigurationPropertyOutputReference;
    }
    interface ReportOutputProperty {
        /**
        * s3_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#s3_configuration AwsPlan#s3_configuration}
        */
        readonly s3Configuration?: S3ConfigurationProperty[] | cdktn.IResolvable;
    }
    class ReportOutputPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReportOutputProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ReportOutputProperty | cdktn.IResolvable | undefined);
        private _s3Configuration;
        get s3Configuration(): S3ConfigurationPropertyList;
        putS3Configuration(value: S3ConfigurationProperty[] | cdktn.IResolvable): void;
        resetS3Configuration(): void;
        get s3ConfigurationInput(): cdktn.IResolvable | S3ConfigurationProperty[] | undefined;
    }
    class ReportOutputPropertyList extends cdktn.ComplexList {
        internalValue?: ReportOutputProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReportOutputPropertyOutputReference;
    }
    interface ReportConfigurationProperty {
        /**
        * report_output block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#report_output AwsPlan#report_output}
        */
        readonly reportOutput?: ReportOutputProperty[] | cdktn.IResolvable;
    }
    class ReportConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReportConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ReportConfigurationProperty | cdktn.IResolvable | undefined);
        private _reportOutput;
        get reportOutput(): ReportOutputPropertyList;
        putReportOutput(value: ReportOutputProperty[] | cdktn.IResolvable): void;
        resetReportOutput(): void;
        get reportOutputInput(): cdktn.IResolvable | ReportOutputProperty[] | undefined;
    }
    class ReportConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: ReportConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReportConfigurationPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#create AwsPlan#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#delete AwsPlan#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#update AwsPlan#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface ConditionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#associated_alarm_name AwsPlan#associated_alarm_name}
        */
        readonly associatedAlarmName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#condition AwsPlan#condition}
        */
        readonly condition: string;
    }
    class ConditionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConditionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConditionsProperty | cdktn.IResolvable | undefined);
        private _associatedAlarmName?;
        get associatedAlarmName(): string;
        set associatedAlarmName(value: string);
        get associatedAlarmNameInput(): string | undefined;
        private _condition?;
        get condition(): string;
        set condition(value: string);
        get conditionInput(): string | undefined;
    }
    class ConditionsPropertyList extends cdktn.ComplexList {
        internalValue?: ConditionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConditionsPropertyOutputReference;
    }
    interface TriggersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#action AwsPlan#action}
        */
        readonly action: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#description AwsPlan#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#min_delay_minutes_between_executions AwsPlan#min_delay_minutes_between_executions}
        */
        readonly minDelayMinutesBetweenExecutions: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#target_region AwsPlan#target_region}
        */
        readonly targetRegion: string;
        /**
        * conditions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#conditions AwsPlan#conditions}
        */
        readonly conditions?: ConditionsProperty[] | cdktn.IResolvable;
    }
    class TriggersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TriggersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TriggersProperty | cdktn.IResolvable | undefined);
        private _action?;
        get action(): string;
        set action(value: string);
        get actionInput(): string | undefined;
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _minDelayMinutesBetweenExecutions?;
        get minDelayMinutesBetweenExecutions(): number;
        set minDelayMinutesBetweenExecutions(value: number);
        get minDelayMinutesBetweenExecutionsInput(): number | undefined;
        private _targetRegion?;
        get targetRegion(): string;
        set targetRegion(value: string);
        get targetRegionInput(): string | undefined;
        private _conditions;
        get conditions(): ConditionsPropertyList;
        putConditions(value: ConditionsProperty[] | cdktn.IResolvable): void;
        resetConditions(): void;
        get conditionsInput(): cdktn.IResolvable | ConditionsProperty[] | undefined;
    }
    class TriggersPropertyList extends cdktn.ComplexList {
        internalValue?: TriggersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TriggersPropertyOutputReference;
    }
    interface WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#routing_control_arn AwsPlan#routing_control_arn}
        */
        readonly routingControlArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#state AwsPlan#state}
        */
        readonly state: string;
    }
    class WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty | cdktn.IResolvable | undefined);
        private _routingControlArn?;
        get routingControlArn(): string;
        set routingControlArn(value: string);
        get routingControlArnInput(): string | undefined;
        private _state?;
        get state(): string;
        set state(value: string);
        get stateInput(): string | undefined;
    }
    class WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlPropertyOutputReference;
    }
    interface WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region AwsPlan#region}
        */
        readonly region: string;
        /**
        * routing_control block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#routing_control AwsPlan#routing_control}
        */
        readonly routingControl?: WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsProperty | cdktn.IResolvable | undefined);
        private _region?;
        get region(): string;
        set region(value: string);
        get regionInput(): string | undefined;
        private _routingControl;
        get routingControl(): WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlPropertyList;
        putRoutingControl(value: WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty[] | cdktn.IResolvable): void;
        resetRoutingControl(): void;
        get routingControlInput(): cdktn.IResolvable | WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty[] | undefined;
    }
    class WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsPropertyOutputReference;
    }
    interface WorkflowStepArcRoutingControlConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * region_and_routing_controls block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region_and_routing_controls AwsPlan#region_and_routing_controls}
        */
        readonly regionAndRoutingControls?: WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepArcRoutingControlConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepArcRoutingControlConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepArcRoutingControlConfigProperty | cdktn.IResolvable | undefined);
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _regionAndRoutingControls;
        get regionAndRoutingControls(): WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsPropertyList;
        putRegionAndRoutingControls(value: WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsProperty[] | cdktn.IResolvable): void;
        resetRegionAndRoutingControls(): void;
        get regionAndRoutingControlsInput(): cdktn.IResolvable | WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsProperty[] | undefined;
    }
    class WorkflowStepArcRoutingControlConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepArcRoutingControlConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepArcRoutingControlConfigPropertyOutputReference;
    }
    interface WorkflowStepAuroraProvisionedScalingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#global_cluster_identifier AwsPlan#global_cluster_identifier}
        */
        readonly globalClusterIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#instance_arns AwsPlan#instance_arns}
        */
        readonly instanceArns: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region_database_cluster_arns AwsPlan#region_database_cluster_arns}
        */
        readonly regionDatabaseClusterArns: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
    }
    class WorkflowStepAuroraProvisionedScalingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepAuroraProvisionedScalingConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepAuroraProvisionedScalingConfigProperty | cdktn.IResolvable | undefined);
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _globalClusterIdentifier?;
        get globalClusterIdentifier(): string;
        set globalClusterIdentifier(value: string);
        get globalClusterIdentifierInput(): string | undefined;
        private _instanceArns?;
        get instanceArns(): {
            [key: string]: string;
        };
        set instanceArns(value: {
            [key: string]: string;
        });
        get instanceArnsInput(): {
            [key: string]: string;
        } | undefined;
        private _regionDatabaseClusterArns?;
        get regionDatabaseClusterArns(): {
            [key: string]: string;
        };
        set regionDatabaseClusterArns(value: {
            [key: string]: string;
        });
        get regionDatabaseClusterArnsInput(): {
            [key: string]: string;
        } | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
    }
    class WorkflowStepAuroraProvisionedScalingConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepAuroraProvisionedScalingConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepAuroraProvisionedScalingConfigPropertyOutputReference;
    }
    interface WorkflowStepAuroraServerlessScalingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#global_cluster_identifier AwsPlan#global_cluster_identifier}
        */
        readonly globalClusterIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region_database_cluster_arns AwsPlan#region_database_cluster_arns}
        */
        readonly regionDatabaseClusterArns: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#target_percent AwsPlan#target_percent}
        */
        readonly targetPercent?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
    }
    class WorkflowStepAuroraServerlessScalingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepAuroraServerlessScalingConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepAuroraServerlessScalingConfigProperty | cdktn.IResolvable | undefined);
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _globalClusterIdentifier?;
        get globalClusterIdentifier(): string;
        set globalClusterIdentifier(value: string);
        get globalClusterIdentifierInput(): string | undefined;
        private _regionDatabaseClusterArns?;
        get regionDatabaseClusterArns(): {
            [key: string]: string;
        };
        set regionDatabaseClusterArns(value: {
            [key: string]: string;
        });
        get regionDatabaseClusterArnsInput(): {
            [key: string]: string;
        } | undefined;
        private _targetPercent?;
        get targetPercent(): number;
        set targetPercent(value: number);
        resetTargetPercent(): void;
        get targetPercentInput(): number | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
    }
    class WorkflowStepAuroraServerlessScalingConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepAuroraServerlessScalingConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepAuroraServerlessScalingConfigPropertyOutputReference;
    }
    interface WorkflowStepCustomActionLambdaConfigLambdaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#arn AwsPlan#arn}
        */
        readonly arn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsPlan#external_id}
        */
        readonly externalId?: string;
    }
    class WorkflowStepCustomActionLambdaConfigLambdaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepCustomActionLambdaConfigLambdaProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepCustomActionLambdaConfigLambdaProperty | cdktn.IResolvable | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
    }
    class WorkflowStepCustomActionLambdaConfigLambdaPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepCustomActionLambdaConfigLambdaProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepCustomActionLambdaConfigLambdaPropertyOutputReference;
    }
    interface WorkflowStepCustomActionLambdaConfigUngracefulProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#behavior AwsPlan#behavior}
        */
        readonly behavior: string;
    }
    class WorkflowStepCustomActionLambdaConfigUngracefulPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepCustomActionLambdaConfigUngracefulProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepCustomActionLambdaConfigUngracefulProperty | cdktn.IResolvable | undefined);
        private _behavior?;
        get behavior(): string;
        set behavior(value: string);
        get behaviorInput(): string | undefined;
    }
    class WorkflowStepCustomActionLambdaConfigUngracefulPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepCustomActionLambdaConfigUngracefulProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepCustomActionLambdaConfigUngracefulPropertyOutputReference;
    }
    interface WorkflowStepCustomActionLambdaConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region_to_run AwsPlan#region_to_run}
        */
        readonly regionToRun: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#retry_interval_minutes AwsPlan#retry_interval_minutes}
        */
        readonly retryIntervalMinutes: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * lambda block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#lambda AwsPlan#lambda}
        */
        readonly lambda?: WorkflowStepCustomActionLambdaConfigLambdaProperty[] | cdktn.IResolvable;
        /**
        * ungraceful block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful AwsPlan#ungraceful}
        */
        readonly ungraceful?: WorkflowStepCustomActionLambdaConfigUngracefulProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepCustomActionLambdaConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepCustomActionLambdaConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepCustomActionLambdaConfigProperty | cdktn.IResolvable | undefined);
        private _regionToRun?;
        get regionToRun(): string;
        set regionToRun(value: string);
        get regionToRunInput(): string | undefined;
        private _retryIntervalMinutes?;
        get retryIntervalMinutes(): number;
        set retryIntervalMinutes(value: number);
        get retryIntervalMinutesInput(): number | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _lambda;
        get lambda(): WorkflowStepCustomActionLambdaConfigLambdaPropertyList;
        putLambda(value: WorkflowStepCustomActionLambdaConfigLambdaProperty[] | cdktn.IResolvable): void;
        resetLambda(): void;
        get lambdaInput(): cdktn.IResolvable | WorkflowStepCustomActionLambdaConfigLambdaProperty[] | undefined;
        private _ungraceful;
        get ungraceful(): WorkflowStepCustomActionLambdaConfigUngracefulPropertyList;
        putUngraceful(value: WorkflowStepCustomActionLambdaConfigUngracefulProperty[] | cdktn.IResolvable): void;
        resetUngraceful(): void;
        get ungracefulInput(): cdktn.IResolvable | WorkflowStepCustomActionLambdaConfigUngracefulProperty[] | undefined;
    }
    class WorkflowStepCustomActionLambdaConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepCustomActionLambdaConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepCustomActionLambdaConfigPropertyOutputReference;
    }
    interface WorkflowStepDocumentDbConfigUngracefulProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful AwsPlan#ungraceful}
        */
        readonly ungraceful: string;
    }
    class WorkflowStepDocumentDbConfigUngracefulPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepDocumentDbConfigUngracefulProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepDocumentDbConfigUngracefulProperty | cdktn.IResolvable | undefined);
        private _ungraceful?;
        get ungraceful(): string;
        set ungraceful(value: string);
        get ungracefulInput(): string | undefined;
    }
    class WorkflowStepDocumentDbConfigUngracefulPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepDocumentDbConfigUngracefulProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepDocumentDbConfigUngracefulPropertyOutputReference;
    }
    interface WorkflowStepDocumentDbConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#behavior AwsPlan#behavior}
        */
        readonly behavior: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#database_cluster_arns AwsPlan#database_cluster_arns}
        */
        readonly databaseClusterArns: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#global_cluster_identifier AwsPlan#global_cluster_identifier}
        */
        readonly globalClusterIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * ungraceful block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful AwsPlan#ungraceful}
        */
        readonly ungraceful?: WorkflowStepDocumentDbConfigUngracefulProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepDocumentDbConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepDocumentDbConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepDocumentDbConfigProperty | cdktn.IResolvable | undefined);
        private _behavior?;
        get behavior(): string;
        set behavior(value: string);
        get behaviorInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _databaseClusterArns?;
        get databaseClusterArns(): string[];
        set databaseClusterArns(value: string[]);
        get databaseClusterArnsInput(): string[] | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _globalClusterIdentifier?;
        get globalClusterIdentifier(): string;
        set globalClusterIdentifier(value: string);
        get globalClusterIdentifierInput(): string | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _ungraceful;
        get ungraceful(): WorkflowStepDocumentDbConfigUngracefulPropertyList;
        putUngraceful(value: WorkflowStepDocumentDbConfigUngracefulProperty[] | cdktn.IResolvable): void;
        resetUngraceful(): void;
        get ungracefulInput(): cdktn.IResolvable | WorkflowStepDocumentDbConfigUngracefulProperty[] | undefined;
    }
    class WorkflowStepDocumentDbConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepDocumentDbConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepDocumentDbConfigPropertyOutputReference;
    }
    interface WorkflowStepEc2AsgCapacityIncreaseConfigAsgProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#arn AwsPlan#arn}
        */
        readonly arn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsPlan#external_id}
        */
        readonly externalId?: string;
    }
    class WorkflowStepEc2AsgCapacityIncreaseConfigAsgPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepEc2AsgCapacityIncreaseConfigAsgProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepEc2AsgCapacityIncreaseConfigAsgProperty | cdktn.IResolvable | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
    }
    class WorkflowStepEc2AsgCapacityIncreaseConfigAsgPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepEc2AsgCapacityIncreaseConfigAsgProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepEc2AsgCapacityIncreaseConfigAsgPropertyOutputReference;
    }
    interface WorkflowStepEc2AsgCapacityIncreaseConfigUngracefulProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#minimum_success_percentage AwsPlan#minimum_success_percentage}
        */
        readonly minimumSuccessPercentage: number;
    }
    class WorkflowStepEc2AsgCapacityIncreaseConfigUngracefulPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepEc2AsgCapacityIncreaseConfigUngracefulProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepEc2AsgCapacityIncreaseConfigUngracefulProperty | cdktn.IResolvable | undefined);
        private _minimumSuccessPercentage?;
        get minimumSuccessPercentage(): number;
        set minimumSuccessPercentage(value: number);
        get minimumSuccessPercentageInput(): number | undefined;
    }
    class WorkflowStepEc2AsgCapacityIncreaseConfigUngracefulPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepEc2AsgCapacityIncreaseConfigUngracefulProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepEc2AsgCapacityIncreaseConfigUngracefulPropertyOutputReference;
    }
    interface WorkflowStepEc2AsgCapacityIncreaseConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#capacity_monitoring_approach AwsPlan#capacity_monitoring_approach}
        */
        readonly capacityMonitoringApproach: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#target_percent AwsPlan#target_percent}
        */
        readonly targetPercent?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * asg block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#asg AwsPlan#asg}
        */
        readonly asg?: WorkflowStepEc2AsgCapacityIncreaseConfigAsgProperty[] | cdktn.IResolvable;
        /**
        * ungraceful block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful AwsPlan#ungraceful}
        */
        readonly ungraceful?: WorkflowStepEc2AsgCapacityIncreaseConfigUngracefulProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepEc2AsgCapacityIncreaseConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepEc2AsgCapacityIncreaseConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepEc2AsgCapacityIncreaseConfigProperty | cdktn.IResolvable | undefined);
        private _capacityMonitoringApproach?;
        get capacityMonitoringApproach(): string;
        set capacityMonitoringApproach(value: string);
        get capacityMonitoringApproachInput(): string | undefined;
        private _targetPercent?;
        get targetPercent(): number;
        set targetPercent(value: number);
        resetTargetPercent(): void;
        get targetPercentInput(): number | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _asg;
        get asg(): WorkflowStepEc2AsgCapacityIncreaseConfigAsgPropertyList;
        putAsg(value: WorkflowStepEc2AsgCapacityIncreaseConfigAsgProperty[] | cdktn.IResolvable): void;
        resetAsg(): void;
        get asgInput(): cdktn.IResolvable | WorkflowStepEc2AsgCapacityIncreaseConfigAsgProperty[] | undefined;
        private _ungraceful;
        get ungraceful(): WorkflowStepEc2AsgCapacityIncreaseConfigUngracefulPropertyList;
        putUngraceful(value: WorkflowStepEc2AsgCapacityIncreaseConfigUngracefulProperty[] | cdktn.IResolvable): void;
        resetUngraceful(): void;
        get ungracefulInput(): cdktn.IResolvable | WorkflowStepEc2AsgCapacityIncreaseConfigUngracefulProperty[] | undefined;
    }
    class WorkflowStepEc2AsgCapacityIncreaseConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepEc2AsgCapacityIncreaseConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepEc2AsgCapacityIncreaseConfigPropertyOutputReference;
    }
    interface WorkflowStepEcsCapacityIncreaseConfigServiceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cluster_arn AwsPlan#cluster_arn}
        */
        readonly clusterArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#service_arn AwsPlan#service_arn}
        */
        readonly serviceArn: string;
    }
    class WorkflowStepEcsCapacityIncreaseConfigServicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepEcsCapacityIncreaseConfigServiceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepEcsCapacityIncreaseConfigServiceProperty | cdktn.IResolvable | undefined);
        private _clusterArn?;
        get clusterArn(): string;
        set clusterArn(value: string);
        get clusterArnInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _serviceArn?;
        get serviceArn(): string;
        set serviceArn(value: string);
        get serviceArnInput(): string | undefined;
    }
    class WorkflowStepEcsCapacityIncreaseConfigServicePropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepEcsCapacityIncreaseConfigServiceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepEcsCapacityIncreaseConfigServicePropertyOutputReference;
    }
    interface WorkflowStepEcsCapacityIncreaseConfigUngracefulProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#minimum_success_percentage AwsPlan#minimum_success_percentage}
        */
        readonly minimumSuccessPercentage: number;
    }
    class WorkflowStepEcsCapacityIncreaseConfigUngracefulPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepEcsCapacityIncreaseConfigUngracefulProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepEcsCapacityIncreaseConfigUngracefulProperty | cdktn.IResolvable | undefined);
        private _minimumSuccessPercentage?;
        get minimumSuccessPercentage(): number;
        set minimumSuccessPercentage(value: number);
        get minimumSuccessPercentageInput(): number | undefined;
    }
    class WorkflowStepEcsCapacityIncreaseConfigUngracefulPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepEcsCapacityIncreaseConfigUngracefulProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepEcsCapacityIncreaseConfigUngracefulPropertyOutputReference;
    }
    interface WorkflowStepEcsCapacityIncreaseConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#capacity_monitoring_approach AwsPlan#capacity_monitoring_approach}
        */
        readonly capacityMonitoringApproach: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#target_percent AwsPlan#target_percent}
        */
        readonly targetPercent?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * service block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#service AwsPlan#service}
        */
        readonly service?: WorkflowStepEcsCapacityIncreaseConfigServiceProperty[] | cdktn.IResolvable;
        /**
        * ungraceful block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful AwsPlan#ungraceful}
        */
        readonly ungraceful?: WorkflowStepEcsCapacityIncreaseConfigUngracefulProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepEcsCapacityIncreaseConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepEcsCapacityIncreaseConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepEcsCapacityIncreaseConfigProperty | cdktn.IResolvable | undefined);
        private _capacityMonitoringApproach?;
        get capacityMonitoringApproach(): string;
        set capacityMonitoringApproach(value: string);
        get capacityMonitoringApproachInput(): string | undefined;
        private _targetPercent?;
        get targetPercent(): number;
        set targetPercent(value: number);
        resetTargetPercent(): void;
        get targetPercentInput(): number | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _service;
        get service(): WorkflowStepEcsCapacityIncreaseConfigServicePropertyList;
        putService(value: WorkflowStepEcsCapacityIncreaseConfigServiceProperty[] | cdktn.IResolvable): void;
        resetService(): void;
        get serviceInput(): cdktn.IResolvable | WorkflowStepEcsCapacityIncreaseConfigServiceProperty[] | undefined;
        private _ungraceful;
        get ungraceful(): WorkflowStepEcsCapacityIncreaseConfigUngracefulPropertyList;
        putUngraceful(value: WorkflowStepEcsCapacityIncreaseConfigUngracefulProperty[] | cdktn.IResolvable): void;
        resetUngraceful(): void;
        get ungracefulInput(): cdktn.IResolvable | WorkflowStepEcsCapacityIncreaseConfigUngracefulProperty[] | undefined;
    }
    class WorkflowStepEcsCapacityIncreaseConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepEcsCapacityIncreaseConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepEcsCapacityIncreaseConfigPropertyOutputReference;
    }
    interface WorkflowStepEksResourceScalingConfigEksClustersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cluster_arn AwsPlan#cluster_arn}
        */
        readonly clusterArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsPlan#external_id}
        */
        readonly externalId?: string;
    }
    class WorkflowStepEksResourceScalingConfigEksClustersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepEksResourceScalingConfigEksClustersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepEksResourceScalingConfigEksClustersProperty | cdktn.IResolvable | undefined);
        private _clusterArn?;
        get clusterArn(): string;
        set clusterArn(value: string);
        get clusterArnInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
    }
    class WorkflowStepEksResourceScalingConfigEksClustersPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepEksResourceScalingConfigEksClustersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepEksResourceScalingConfigEksClustersPropertyOutputReference;
    }
    interface WorkflowStepEksResourceScalingConfigKubernetesResourceTypeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#api_version AwsPlan#api_version}
        */
        readonly apiVersion: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#kind AwsPlan#kind}
        */
        readonly kind: string;
    }
    class WorkflowStepEksResourceScalingConfigKubernetesResourceTypePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepEksResourceScalingConfigKubernetesResourceTypeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepEksResourceScalingConfigKubernetesResourceTypeProperty | cdktn.IResolvable | undefined);
        private _apiVersion?;
        get apiVersion(): string;
        set apiVersion(value: string);
        get apiVersionInput(): string | undefined;
        private _kind?;
        get kind(): string;
        set kind(value: string);
        get kindInput(): string | undefined;
    }
    class WorkflowStepEksResourceScalingConfigKubernetesResourceTypePropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepEksResourceScalingConfigKubernetesResourceTypeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepEksResourceScalingConfigKubernetesResourceTypePropertyOutputReference;
    }
    interface WorkflowStepEksResourceScalingConfigScalingResourcesResourcesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#hpa_name AwsPlan#hpa_name}
        */
        readonly hpaName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#name AwsPlan#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#namespace AwsPlan#namespace}
        */
        readonly namespace: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#resource_name AwsPlan#resource_name}
        */
        readonly resourceName: string;
    }
    class WorkflowStepEksResourceScalingConfigScalingResourcesResourcesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepEksResourceScalingConfigScalingResourcesResourcesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepEksResourceScalingConfigScalingResourcesResourcesProperty | cdktn.IResolvable | undefined);
        private _hpaName?;
        get hpaName(): string;
        set hpaName(value: string);
        resetHpaName(): void;
        get hpaNameInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _namespace?;
        get namespace(): string;
        set namespace(value: string);
        get namespaceInput(): string | undefined;
        private _resourceName?;
        get resourceName(): string;
        set resourceName(value: string);
        get resourceNameInput(): string | undefined;
    }
    class WorkflowStepEksResourceScalingConfigScalingResourcesResourcesPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepEksResourceScalingConfigScalingResourcesResourcesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepEksResourceScalingConfigScalingResourcesResourcesPropertyOutputReference;
    }
    interface WorkflowStepEksResourceScalingConfigScalingResourcesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#namespace AwsPlan#namespace}
        */
        readonly namespace: string;
        /**
        * resources block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#resources AwsPlan#resources}
        */
        readonly resources?: WorkflowStepEksResourceScalingConfigScalingResourcesResourcesProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepEksResourceScalingConfigScalingResourcesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepEksResourceScalingConfigScalingResourcesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepEksResourceScalingConfigScalingResourcesProperty | cdktn.IResolvable | undefined);
        private _namespace?;
        get namespace(): string;
        set namespace(value: string);
        get namespaceInput(): string | undefined;
        private _resources;
        get resources(): WorkflowStepEksResourceScalingConfigScalingResourcesResourcesPropertyList;
        putResources(value: WorkflowStepEksResourceScalingConfigScalingResourcesResourcesProperty[] | cdktn.IResolvable): void;
        resetResources(): void;
        get resourcesInput(): cdktn.IResolvable | WorkflowStepEksResourceScalingConfigScalingResourcesResourcesProperty[] | undefined;
    }
    class WorkflowStepEksResourceScalingConfigScalingResourcesPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepEksResourceScalingConfigScalingResourcesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepEksResourceScalingConfigScalingResourcesPropertyOutputReference;
    }
    interface WorkflowStepEksResourceScalingConfigUngracefulProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#minimum_success_percentage AwsPlan#minimum_success_percentage}
        */
        readonly minimumSuccessPercentage: number;
    }
    class WorkflowStepEksResourceScalingConfigUngracefulPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepEksResourceScalingConfigUngracefulProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepEksResourceScalingConfigUngracefulProperty | cdktn.IResolvable | undefined);
        private _minimumSuccessPercentage?;
        get minimumSuccessPercentage(): number;
        set minimumSuccessPercentage(value: number);
        get minimumSuccessPercentageInput(): number | undefined;
    }
    class WorkflowStepEksResourceScalingConfigUngracefulPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepEksResourceScalingConfigUngracefulProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepEksResourceScalingConfigUngracefulPropertyOutputReference;
    }
    interface WorkflowStepEksResourceScalingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#capacity_monitoring_approach AwsPlan#capacity_monitoring_approach}
        */
        readonly capacityMonitoringApproach: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#target_percent AwsPlan#target_percent}
        */
        readonly targetPercent: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * eks_clusters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#eks_clusters AwsPlan#eks_clusters}
        */
        readonly eksClusters?: WorkflowStepEksResourceScalingConfigEksClustersProperty[] | cdktn.IResolvable;
        /**
        * kubernetes_resource_type block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#kubernetes_resource_type AwsPlan#kubernetes_resource_type}
        */
        readonly kubernetesResourceType?: WorkflowStepEksResourceScalingConfigKubernetesResourceTypeProperty[] | cdktn.IResolvable;
        /**
        * scaling_resources block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#scaling_resources AwsPlan#scaling_resources}
        */
        readonly scalingResources?: WorkflowStepEksResourceScalingConfigScalingResourcesProperty[] | cdktn.IResolvable;
        /**
        * ungraceful block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful AwsPlan#ungraceful}
        */
        readonly ungraceful?: WorkflowStepEksResourceScalingConfigUngracefulProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepEksResourceScalingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepEksResourceScalingConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepEksResourceScalingConfigProperty | cdktn.IResolvable | undefined);
        private _capacityMonitoringApproach?;
        get capacityMonitoringApproach(): string;
        set capacityMonitoringApproach(value: string);
        get capacityMonitoringApproachInput(): string | undefined;
        private _targetPercent?;
        get targetPercent(): number;
        set targetPercent(value: number);
        get targetPercentInput(): number | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _eksClusters;
        get eksClusters(): WorkflowStepEksResourceScalingConfigEksClustersPropertyList;
        putEksClusters(value: WorkflowStepEksResourceScalingConfigEksClustersProperty[] | cdktn.IResolvable): void;
        resetEksClusters(): void;
        get eksClustersInput(): cdktn.IResolvable | WorkflowStepEksResourceScalingConfigEksClustersProperty[] | undefined;
        private _kubernetesResourceType;
        get kubernetesResourceType(): WorkflowStepEksResourceScalingConfigKubernetesResourceTypePropertyList;
        putKubernetesResourceType(value: WorkflowStepEksResourceScalingConfigKubernetesResourceTypeProperty[] | cdktn.IResolvable): void;
        resetKubernetesResourceType(): void;
        get kubernetesResourceTypeInput(): cdktn.IResolvable | WorkflowStepEksResourceScalingConfigKubernetesResourceTypeProperty[] | undefined;
        private _scalingResources;
        get scalingResources(): WorkflowStepEksResourceScalingConfigScalingResourcesPropertyList;
        putScalingResources(value: WorkflowStepEksResourceScalingConfigScalingResourcesProperty[] | cdktn.IResolvable): void;
        resetScalingResources(): void;
        get scalingResourcesInput(): cdktn.IResolvable | WorkflowStepEksResourceScalingConfigScalingResourcesProperty[] | undefined;
        private _ungraceful;
        get ungraceful(): WorkflowStepEksResourceScalingConfigUngracefulPropertyList;
        putUngraceful(value: WorkflowStepEksResourceScalingConfigUngracefulProperty[] | cdktn.IResolvable): void;
        resetUngraceful(): void;
        get ungracefulInput(): cdktn.IResolvable | WorkflowStepEksResourceScalingConfigUngracefulProperty[] | undefined;
    }
    class WorkflowStepEksResourceScalingConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepEksResourceScalingConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepEksResourceScalingConfigPropertyOutputReference;
    }
    interface WorkflowStepExecutionApprovalConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#approval_role AwsPlan#approval_role}
        */
        readonly approvalRole: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
    }
    class WorkflowStepExecutionApprovalConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepExecutionApprovalConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepExecutionApprovalConfigProperty | cdktn.IResolvable | undefined);
        private _approvalRole?;
        get approvalRole(): string;
        set approvalRole(value: string);
        get approvalRoleInput(): string | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
    }
    class WorkflowStepExecutionApprovalConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepExecutionApprovalConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepExecutionApprovalConfigPropertyOutputReference;
    }
    interface WorkflowStepGlobalAuroraConfigUngracefulProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful AwsPlan#ungraceful}
        */
        readonly ungraceful: string;
    }
    class WorkflowStepGlobalAuroraConfigUngracefulPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepGlobalAuroraConfigUngracefulProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepGlobalAuroraConfigUngracefulProperty | cdktn.IResolvable | undefined);
        private _ungraceful?;
        get ungraceful(): string;
        set ungraceful(value: string);
        get ungracefulInput(): string | undefined;
    }
    class WorkflowStepGlobalAuroraConfigUngracefulPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepGlobalAuroraConfigUngracefulProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepGlobalAuroraConfigUngracefulPropertyOutputReference;
    }
    interface WorkflowStepGlobalAuroraConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#behavior AwsPlan#behavior}
        */
        readonly behavior: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#database_cluster_arns AwsPlan#database_cluster_arns}
        */
        readonly databaseClusterArns: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#global_cluster_identifier AwsPlan#global_cluster_identifier}
        */
        readonly globalClusterIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * ungraceful block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful AwsPlan#ungraceful}
        */
        readonly ungraceful?: WorkflowStepGlobalAuroraConfigUngracefulProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepGlobalAuroraConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepGlobalAuroraConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepGlobalAuroraConfigProperty | cdktn.IResolvable | undefined);
        private _behavior?;
        get behavior(): string;
        set behavior(value: string);
        get behaviorInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _databaseClusterArns?;
        get databaseClusterArns(): string[];
        set databaseClusterArns(value: string[]);
        get databaseClusterArnsInput(): string[] | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _globalClusterIdentifier?;
        get globalClusterIdentifier(): string;
        set globalClusterIdentifier(value: string);
        get globalClusterIdentifierInput(): string | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _ungraceful;
        get ungraceful(): WorkflowStepGlobalAuroraConfigUngracefulPropertyList;
        putUngraceful(value: WorkflowStepGlobalAuroraConfigUngracefulProperty[] | cdktn.IResolvable): void;
        resetUngraceful(): void;
        get ungracefulInput(): cdktn.IResolvable | WorkflowStepGlobalAuroraConfigUngracefulProperty[] | undefined;
    }
    class WorkflowStepGlobalAuroraConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepGlobalAuroraConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepGlobalAuroraConfigPropertyOutputReference;
    }
    interface WorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#arn AwsPlan#arn}
        */
        readonly arn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region AwsPlan#region}
        */
        readonly region: string;
    }
    class WorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMappingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty | cdktn.IResolvable | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _region?;
        get region(): string;
        set region(value: string);
        get regionInput(): string | undefined;
    }
    class WorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMappingPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMappingPropertyOutputReference;
    }
    interface WorkflowStepLambdaEventSourceMappingConfigUngracefulProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#behavior AwsPlan#behavior}
        */
        readonly behavior: string;
    }
    class WorkflowStepLambdaEventSourceMappingConfigUngracefulPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepLambdaEventSourceMappingConfigUngracefulProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepLambdaEventSourceMappingConfigUngracefulProperty | cdktn.IResolvable | undefined);
        private _behavior?;
        get behavior(): string;
        set behavior(value: string);
        get behaviorInput(): string | undefined;
    }
    class WorkflowStepLambdaEventSourceMappingConfigUngracefulPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepLambdaEventSourceMappingConfigUngracefulProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepLambdaEventSourceMappingConfigUngracefulPropertyOutputReference;
    }
    interface WorkflowStepLambdaEventSourceMappingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#action AwsPlan#action}
        */
        readonly action: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * region_event_source_mapping block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region_event_source_mapping AwsPlan#region_event_source_mapping}
        */
        readonly regionEventSourceMapping?: WorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty[] | cdktn.IResolvable;
        /**
        * ungraceful block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful AwsPlan#ungraceful}
        */
        readonly ungraceful?: WorkflowStepLambdaEventSourceMappingConfigUngracefulProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepLambdaEventSourceMappingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepLambdaEventSourceMappingConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepLambdaEventSourceMappingConfigProperty | cdktn.IResolvable | undefined);
        private _action?;
        get action(): string;
        set action(value: string);
        get actionInput(): string | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _regionEventSourceMapping;
        get regionEventSourceMapping(): WorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMappingPropertyList;
        putRegionEventSourceMapping(value: WorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty[] | cdktn.IResolvable): void;
        resetRegionEventSourceMapping(): void;
        get regionEventSourceMappingInput(): cdktn.IResolvable | WorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty[] | undefined;
        private _ungraceful;
        get ungraceful(): WorkflowStepLambdaEventSourceMappingConfigUngracefulPropertyList;
        putUngraceful(value: WorkflowStepLambdaEventSourceMappingConfigUngracefulProperty[] | cdktn.IResolvable): void;
        resetUngraceful(): void;
        get ungracefulInput(): cdktn.IResolvable | WorkflowStepLambdaEventSourceMappingConfigUngracefulProperty[] | undefined;
    }
    class WorkflowStepLambdaEventSourceMappingConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepLambdaEventSourceMappingConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepLambdaEventSourceMappingConfigPropertyOutputReference;
    }
    interface WorkflowStepNeptuneGlobalDatabaseConfigUngracefulProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful AwsPlan#ungraceful}
        */
        readonly ungraceful: string;
    }
    class WorkflowStepNeptuneGlobalDatabaseConfigUngracefulPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepNeptuneGlobalDatabaseConfigUngracefulProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepNeptuneGlobalDatabaseConfigUngracefulProperty | cdktn.IResolvable | undefined);
        private _ungraceful?;
        get ungraceful(): string;
        set ungraceful(value: string);
        get ungracefulInput(): string | undefined;
    }
    class WorkflowStepNeptuneGlobalDatabaseConfigUngracefulPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepNeptuneGlobalDatabaseConfigUngracefulProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepNeptuneGlobalDatabaseConfigUngracefulPropertyOutputReference;
    }
    interface WorkflowStepNeptuneGlobalDatabaseConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#behavior AwsPlan#behavior}
        */
        readonly behavior: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#global_cluster_identifier AwsPlan#global_cluster_identifier}
        */
        readonly globalClusterIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region_database_cluster_arns AwsPlan#region_database_cluster_arns}
        */
        readonly regionDatabaseClusterArns: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * ungraceful block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful AwsPlan#ungraceful}
        */
        readonly ungraceful?: WorkflowStepNeptuneGlobalDatabaseConfigUngracefulProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepNeptuneGlobalDatabaseConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepNeptuneGlobalDatabaseConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepNeptuneGlobalDatabaseConfigProperty | cdktn.IResolvable | undefined);
        private _behavior?;
        get behavior(): string;
        set behavior(value: string);
        get behaviorInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _globalClusterIdentifier?;
        get globalClusterIdentifier(): string;
        set globalClusterIdentifier(value: string);
        get globalClusterIdentifierInput(): string | undefined;
        private _regionDatabaseClusterArns?;
        get regionDatabaseClusterArns(): {
            [key: string]: string;
        };
        set regionDatabaseClusterArns(value: {
            [key: string]: string;
        });
        get regionDatabaseClusterArnsInput(): {
            [key: string]: string;
        } | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _ungraceful;
        get ungraceful(): WorkflowStepNeptuneGlobalDatabaseConfigUngracefulPropertyList;
        putUngraceful(value: WorkflowStepNeptuneGlobalDatabaseConfigUngracefulProperty[] | cdktn.IResolvable): void;
        resetUngraceful(): void;
        get ungracefulInput(): cdktn.IResolvable | WorkflowStepNeptuneGlobalDatabaseConfigUngracefulProperty[] | undefined;
    }
    class WorkflowStepNeptuneGlobalDatabaseConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepNeptuneGlobalDatabaseConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepNeptuneGlobalDatabaseConfigPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#routing_control_arn AwsPlan#routing_control_arn}
        */
        readonly routingControlArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#state AwsPlan#state}
        */
        readonly state: string;
    }
    class WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty | cdktn.IResolvable | undefined);
        private _routingControlArn?;
        get routingControlArn(): string;
        set routingControlArn(value: string);
        get routingControlArnInput(): string | undefined;
        private _state?;
        get state(): string;
        set state(value: string);
        get stateInput(): string | undefined;
    }
    class WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region AwsPlan#region}
        */
        readonly region: string;
        /**
        * routing_control block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#routing_control AwsPlan#routing_control}
        */
        readonly routingControl?: WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsProperty | cdktn.IResolvable | undefined);
        private _region?;
        get region(): string;
        set region(value: string);
        get regionInput(): string | undefined;
        private _routingControl;
        get routingControl(): WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlPropertyList;
        putRoutingControl(value: WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty[] | cdktn.IResolvable): void;
        resetRoutingControl(): void;
        get routingControlInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty[] | undefined;
    }
    class WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepArcRoutingControlConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * region_and_routing_controls block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region_and_routing_controls AwsPlan#region_and_routing_controls}
        */
        readonly regionAndRoutingControls?: WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepParallelConfigStepArcRoutingControlConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepArcRoutingControlConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepArcRoutingControlConfigProperty | cdktn.IResolvable | undefined);
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _regionAndRoutingControls;
        get regionAndRoutingControls(): WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsPropertyList;
        putRegionAndRoutingControls(value: WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsProperty[] | cdktn.IResolvable): void;
        resetRegionAndRoutingControls(): void;
        get regionAndRoutingControlsInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsProperty[] | undefined;
    }
    class WorkflowStepParallelConfigStepArcRoutingControlConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepArcRoutingControlConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepArcRoutingControlConfigPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepAuroraProvisionedScalingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#global_cluster_identifier AwsPlan#global_cluster_identifier}
        */
        readonly globalClusterIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#instance_arns AwsPlan#instance_arns}
        */
        readonly instanceArns: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region_database_cluster_arns AwsPlan#region_database_cluster_arns}
        */
        readonly regionDatabaseClusterArns: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
    }
    class WorkflowStepParallelConfigStepAuroraProvisionedScalingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepAuroraProvisionedScalingConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepAuroraProvisionedScalingConfigProperty | cdktn.IResolvable | undefined);
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _globalClusterIdentifier?;
        get globalClusterIdentifier(): string;
        set globalClusterIdentifier(value: string);
        get globalClusterIdentifierInput(): string | undefined;
        private _instanceArns?;
        get instanceArns(): {
            [key: string]: string;
        };
        set instanceArns(value: {
            [key: string]: string;
        });
        get instanceArnsInput(): {
            [key: string]: string;
        } | undefined;
        private _regionDatabaseClusterArns?;
        get regionDatabaseClusterArns(): {
            [key: string]: string;
        };
        set regionDatabaseClusterArns(value: {
            [key: string]: string;
        });
        get regionDatabaseClusterArnsInput(): {
            [key: string]: string;
        } | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
    }
    class WorkflowStepParallelConfigStepAuroraProvisionedScalingConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepAuroraProvisionedScalingConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepAuroraProvisionedScalingConfigPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepAuroraServerlessScalingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#global_cluster_identifier AwsPlan#global_cluster_identifier}
        */
        readonly globalClusterIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region_database_cluster_arns AwsPlan#region_database_cluster_arns}
        */
        readonly regionDatabaseClusterArns: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#target_percent AwsPlan#target_percent}
        */
        readonly targetPercent?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
    }
    class WorkflowStepParallelConfigStepAuroraServerlessScalingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepAuroraServerlessScalingConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepAuroraServerlessScalingConfigProperty | cdktn.IResolvable | undefined);
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _globalClusterIdentifier?;
        get globalClusterIdentifier(): string;
        set globalClusterIdentifier(value: string);
        get globalClusterIdentifierInput(): string | undefined;
        private _regionDatabaseClusterArns?;
        get regionDatabaseClusterArns(): {
            [key: string]: string;
        };
        set regionDatabaseClusterArns(value: {
            [key: string]: string;
        });
        get regionDatabaseClusterArnsInput(): {
            [key: string]: string;
        } | undefined;
        private _targetPercent?;
        get targetPercent(): number;
        set targetPercent(value: number);
        resetTargetPercent(): void;
        get targetPercentInput(): number | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
    }
    class WorkflowStepParallelConfigStepAuroraServerlessScalingConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepAuroraServerlessScalingConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepAuroraServerlessScalingConfigPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepCustomActionLambdaConfigLambdaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#arn AwsPlan#arn}
        */
        readonly arn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsPlan#external_id}
        */
        readonly externalId?: string;
    }
    class WorkflowStepParallelConfigStepCustomActionLambdaConfigLambdaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepCustomActionLambdaConfigLambdaProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepCustomActionLambdaConfigLambdaProperty | cdktn.IResolvable | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
    }
    class WorkflowStepParallelConfigStepCustomActionLambdaConfigLambdaPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepCustomActionLambdaConfigLambdaProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepCustomActionLambdaConfigLambdaPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepCustomActionLambdaConfigUngracefulProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#behavior AwsPlan#behavior}
        */
        readonly behavior: string;
    }
    class WorkflowStepParallelConfigStepCustomActionLambdaConfigUngracefulPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepCustomActionLambdaConfigUngracefulProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepCustomActionLambdaConfigUngracefulProperty | cdktn.IResolvable | undefined);
        private _behavior?;
        get behavior(): string;
        set behavior(value: string);
        get behaviorInput(): string | undefined;
    }
    class WorkflowStepParallelConfigStepCustomActionLambdaConfigUngracefulPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepCustomActionLambdaConfigUngracefulProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepCustomActionLambdaConfigUngracefulPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepCustomActionLambdaConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region_to_run AwsPlan#region_to_run}
        */
        readonly regionToRun: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#retry_interval_minutes AwsPlan#retry_interval_minutes}
        */
        readonly retryIntervalMinutes: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * lambda block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#lambda AwsPlan#lambda}
        */
        readonly lambda?: WorkflowStepParallelConfigStepCustomActionLambdaConfigLambdaProperty[] | cdktn.IResolvable;
        /**
        * ungraceful block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful AwsPlan#ungraceful}
        */
        readonly ungraceful?: WorkflowStepParallelConfigStepCustomActionLambdaConfigUngracefulProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepParallelConfigStepCustomActionLambdaConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepCustomActionLambdaConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepCustomActionLambdaConfigProperty | cdktn.IResolvable | undefined);
        private _regionToRun?;
        get regionToRun(): string;
        set regionToRun(value: string);
        get regionToRunInput(): string | undefined;
        private _retryIntervalMinutes?;
        get retryIntervalMinutes(): number;
        set retryIntervalMinutes(value: number);
        get retryIntervalMinutesInput(): number | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _lambda;
        get lambda(): WorkflowStepParallelConfigStepCustomActionLambdaConfigLambdaPropertyList;
        putLambda(value: WorkflowStepParallelConfigStepCustomActionLambdaConfigLambdaProperty[] | cdktn.IResolvable): void;
        resetLambda(): void;
        get lambdaInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepCustomActionLambdaConfigLambdaProperty[] | undefined;
        private _ungraceful;
        get ungraceful(): WorkflowStepParallelConfigStepCustomActionLambdaConfigUngracefulPropertyList;
        putUngraceful(value: WorkflowStepParallelConfigStepCustomActionLambdaConfigUngracefulProperty[] | cdktn.IResolvable): void;
        resetUngraceful(): void;
        get ungracefulInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepCustomActionLambdaConfigUngracefulProperty[] | undefined;
    }
    class WorkflowStepParallelConfigStepCustomActionLambdaConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepCustomActionLambdaConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepCustomActionLambdaConfigPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepDocumentDbConfigUngracefulProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful AwsPlan#ungraceful}
        */
        readonly ungraceful: string;
    }
    class WorkflowStepParallelConfigStepDocumentDbConfigUngracefulPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepDocumentDbConfigUngracefulProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepDocumentDbConfigUngracefulProperty | cdktn.IResolvable | undefined);
        private _ungraceful?;
        get ungraceful(): string;
        set ungraceful(value: string);
        get ungracefulInput(): string | undefined;
    }
    class WorkflowStepParallelConfigStepDocumentDbConfigUngracefulPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepDocumentDbConfigUngracefulProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepDocumentDbConfigUngracefulPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepDocumentDbConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#behavior AwsPlan#behavior}
        */
        readonly behavior: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#database_cluster_arns AwsPlan#database_cluster_arns}
        */
        readonly databaseClusterArns: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#global_cluster_identifier AwsPlan#global_cluster_identifier}
        */
        readonly globalClusterIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * ungraceful block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful AwsPlan#ungraceful}
        */
        readonly ungraceful?: WorkflowStepParallelConfigStepDocumentDbConfigUngracefulProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepParallelConfigStepDocumentDbConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepDocumentDbConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepDocumentDbConfigProperty | cdktn.IResolvable | undefined);
        private _behavior?;
        get behavior(): string;
        set behavior(value: string);
        get behaviorInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _databaseClusterArns?;
        get databaseClusterArns(): string[];
        set databaseClusterArns(value: string[]);
        get databaseClusterArnsInput(): string[] | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _globalClusterIdentifier?;
        get globalClusterIdentifier(): string;
        set globalClusterIdentifier(value: string);
        get globalClusterIdentifierInput(): string | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _ungraceful;
        get ungraceful(): WorkflowStepParallelConfigStepDocumentDbConfigUngracefulPropertyList;
        putUngraceful(value: WorkflowStepParallelConfigStepDocumentDbConfigUngracefulProperty[] | cdktn.IResolvable): void;
        resetUngraceful(): void;
        get ungracefulInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepDocumentDbConfigUngracefulProperty[] | undefined;
    }
    class WorkflowStepParallelConfigStepDocumentDbConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepDocumentDbConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepDocumentDbConfigPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsgProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#arn AwsPlan#arn}
        */
        readonly arn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsPlan#external_id}
        */
        readonly externalId?: string;
    }
    class WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsgPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsgProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsgProperty | cdktn.IResolvable | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
    }
    class WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsgPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsgProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsgPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngracefulProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#minimum_success_percentage AwsPlan#minimum_success_percentage}
        */
        readonly minimumSuccessPercentage: number;
    }
    class WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngracefulPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngracefulProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngracefulProperty | cdktn.IResolvable | undefined);
        private _minimumSuccessPercentage?;
        get minimumSuccessPercentage(): number;
        set minimumSuccessPercentage(value: number);
        get minimumSuccessPercentageInput(): number | undefined;
    }
    class WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngracefulPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngracefulProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngracefulPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#capacity_monitoring_approach AwsPlan#capacity_monitoring_approach}
        */
        readonly capacityMonitoringApproach: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#target_percent AwsPlan#target_percent}
        */
        readonly targetPercent?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * asg block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#asg AwsPlan#asg}
        */
        readonly asg?: WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsgProperty[] | cdktn.IResolvable;
        /**
        * ungraceful block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful AwsPlan#ungraceful}
        */
        readonly ungraceful?: WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngracefulProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigProperty | cdktn.IResolvable | undefined);
        private _capacityMonitoringApproach?;
        get capacityMonitoringApproach(): string;
        set capacityMonitoringApproach(value: string);
        get capacityMonitoringApproachInput(): string | undefined;
        private _targetPercent?;
        get targetPercent(): number;
        set targetPercent(value: number);
        resetTargetPercent(): void;
        get targetPercentInput(): number | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _asg;
        get asg(): WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsgPropertyList;
        putAsg(value: WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsgProperty[] | cdktn.IResolvable): void;
        resetAsg(): void;
        get asgInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsgProperty[] | undefined;
        private _ungraceful;
        get ungraceful(): WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngracefulPropertyList;
        putUngraceful(value: WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngracefulProperty[] | cdktn.IResolvable): void;
        resetUngraceful(): void;
        get ungracefulInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngracefulProperty[] | undefined;
    }
    class WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigServiceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cluster_arn AwsPlan#cluster_arn}
        */
        readonly clusterArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#service_arn AwsPlan#service_arn}
        */
        readonly serviceArn: string;
    }
    class WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigServicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigServiceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigServiceProperty | cdktn.IResolvable | undefined);
        private _clusterArn?;
        get clusterArn(): string;
        set clusterArn(value: string);
        get clusterArnInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _serviceArn?;
        get serviceArn(): string;
        set serviceArn(value: string);
        get serviceArnInput(): string | undefined;
    }
    class WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigServicePropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigServiceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigServicePropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngracefulProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#minimum_success_percentage AwsPlan#minimum_success_percentage}
        */
        readonly minimumSuccessPercentage: number;
    }
    class WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngracefulPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngracefulProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngracefulProperty | cdktn.IResolvable | undefined);
        private _minimumSuccessPercentage?;
        get minimumSuccessPercentage(): number;
        set minimumSuccessPercentage(value: number);
        get minimumSuccessPercentageInput(): number | undefined;
    }
    class WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngracefulPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngracefulProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngracefulPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#capacity_monitoring_approach AwsPlan#capacity_monitoring_approach}
        */
        readonly capacityMonitoringApproach: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#target_percent AwsPlan#target_percent}
        */
        readonly targetPercent?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * service block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#service AwsPlan#service}
        */
        readonly service?: WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigServiceProperty[] | cdktn.IResolvable;
        /**
        * ungraceful block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful AwsPlan#ungraceful}
        */
        readonly ungraceful?: WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngracefulProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigProperty | cdktn.IResolvable | undefined);
        private _capacityMonitoringApproach?;
        get capacityMonitoringApproach(): string;
        set capacityMonitoringApproach(value: string);
        get capacityMonitoringApproachInput(): string | undefined;
        private _targetPercent?;
        get targetPercent(): number;
        set targetPercent(value: number);
        resetTargetPercent(): void;
        get targetPercentInput(): number | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _service;
        get service(): WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigServicePropertyList;
        putService(value: WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigServiceProperty[] | cdktn.IResolvable): void;
        resetService(): void;
        get serviceInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigServiceProperty[] | undefined;
        private _ungraceful;
        get ungraceful(): WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngracefulPropertyList;
        putUngraceful(value: WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngracefulProperty[] | cdktn.IResolvable): void;
        resetUngraceful(): void;
        get ungracefulInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngracefulProperty[] | undefined;
    }
    class WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepEksResourceScalingConfigEksClustersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cluster_arn AwsPlan#cluster_arn}
        */
        readonly clusterArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsPlan#external_id}
        */
        readonly externalId?: string;
    }
    class WorkflowStepParallelConfigStepEksResourceScalingConfigEksClustersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepEksResourceScalingConfigEksClustersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepEksResourceScalingConfigEksClustersProperty | cdktn.IResolvable | undefined);
        private _clusterArn?;
        get clusterArn(): string;
        set clusterArn(value: string);
        get clusterArnInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
    }
    class WorkflowStepParallelConfigStepEksResourceScalingConfigEksClustersPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepEksResourceScalingConfigEksClustersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepEksResourceScalingConfigEksClustersPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceTypeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#api_version AwsPlan#api_version}
        */
        readonly apiVersion: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#kind AwsPlan#kind}
        */
        readonly kind: string;
    }
    class WorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceTypePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceTypeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceTypeProperty | cdktn.IResolvable | undefined);
        private _apiVersion?;
        get apiVersion(): string;
        set apiVersion(value: string);
        get apiVersionInput(): string | undefined;
        private _kind?;
        get kind(): string;
        set kind(value: string);
        get kindInput(): string | undefined;
    }
    class WorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceTypePropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceTypeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceTypePropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResourcesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#hpa_name AwsPlan#hpa_name}
        */
        readonly hpaName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#name AwsPlan#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#namespace AwsPlan#namespace}
        */
        readonly namespace: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#resource_name AwsPlan#resource_name}
        */
        readonly resourceName: string;
    }
    class WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResourcesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResourcesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResourcesProperty | cdktn.IResolvable | undefined);
        private _hpaName?;
        get hpaName(): string;
        set hpaName(value: string);
        resetHpaName(): void;
        get hpaNameInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _namespace?;
        get namespace(): string;
        set namespace(value: string);
        get namespaceInput(): string | undefined;
        private _resourceName?;
        get resourceName(): string;
        set resourceName(value: string);
        get resourceNameInput(): string | undefined;
    }
    class WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResourcesPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResourcesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResourcesPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#namespace AwsPlan#namespace}
        */
        readonly namespace: string;
        /**
        * resources block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#resources AwsPlan#resources}
        */
        readonly resources?: WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResourcesProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesProperty | cdktn.IResolvable | undefined);
        private _namespace?;
        get namespace(): string;
        set namespace(value: string);
        get namespaceInput(): string | undefined;
        private _resources;
        get resources(): WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResourcesPropertyList;
        putResources(value: WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResourcesProperty[] | cdktn.IResolvable): void;
        resetResources(): void;
        get resourcesInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResourcesProperty[] | undefined;
    }
    class WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepEksResourceScalingConfigUngracefulProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#minimum_success_percentage AwsPlan#minimum_success_percentage}
        */
        readonly minimumSuccessPercentage: number;
    }
    class WorkflowStepParallelConfigStepEksResourceScalingConfigUngracefulPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepEksResourceScalingConfigUngracefulProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepEksResourceScalingConfigUngracefulProperty | cdktn.IResolvable | undefined);
        private _minimumSuccessPercentage?;
        get minimumSuccessPercentage(): number;
        set minimumSuccessPercentage(value: number);
        get minimumSuccessPercentageInput(): number | undefined;
    }
    class WorkflowStepParallelConfigStepEksResourceScalingConfigUngracefulPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepEksResourceScalingConfigUngracefulProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepEksResourceScalingConfigUngracefulPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepEksResourceScalingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#capacity_monitoring_approach AwsPlan#capacity_monitoring_approach}
        */
        readonly capacityMonitoringApproach: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#target_percent AwsPlan#target_percent}
        */
        readonly targetPercent: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * eks_clusters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#eks_clusters AwsPlan#eks_clusters}
        */
        readonly eksClusters?: WorkflowStepParallelConfigStepEksResourceScalingConfigEksClustersProperty[] | cdktn.IResolvable;
        /**
        * kubernetes_resource_type block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#kubernetes_resource_type AwsPlan#kubernetes_resource_type}
        */
        readonly kubernetesResourceType?: WorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceTypeProperty[] | cdktn.IResolvable;
        /**
        * scaling_resources block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#scaling_resources AwsPlan#scaling_resources}
        */
        readonly scalingResources?: WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesProperty[] | cdktn.IResolvable;
        /**
        * ungraceful block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful AwsPlan#ungraceful}
        */
        readonly ungraceful?: WorkflowStepParallelConfigStepEksResourceScalingConfigUngracefulProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepParallelConfigStepEksResourceScalingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepEksResourceScalingConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepEksResourceScalingConfigProperty | cdktn.IResolvable | undefined);
        private _capacityMonitoringApproach?;
        get capacityMonitoringApproach(): string;
        set capacityMonitoringApproach(value: string);
        get capacityMonitoringApproachInput(): string | undefined;
        private _targetPercent?;
        get targetPercent(): number;
        set targetPercent(value: number);
        get targetPercentInput(): number | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _eksClusters;
        get eksClusters(): WorkflowStepParallelConfigStepEksResourceScalingConfigEksClustersPropertyList;
        putEksClusters(value: WorkflowStepParallelConfigStepEksResourceScalingConfigEksClustersProperty[] | cdktn.IResolvable): void;
        resetEksClusters(): void;
        get eksClustersInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepEksResourceScalingConfigEksClustersProperty[] | undefined;
        private _kubernetesResourceType;
        get kubernetesResourceType(): WorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceTypePropertyList;
        putKubernetesResourceType(value: WorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceTypeProperty[] | cdktn.IResolvable): void;
        resetKubernetesResourceType(): void;
        get kubernetesResourceTypeInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceTypeProperty[] | undefined;
        private _scalingResources;
        get scalingResources(): WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesPropertyList;
        putScalingResources(value: WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesProperty[] | cdktn.IResolvable): void;
        resetScalingResources(): void;
        get scalingResourcesInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesProperty[] | undefined;
        private _ungraceful;
        get ungraceful(): WorkflowStepParallelConfigStepEksResourceScalingConfigUngracefulPropertyList;
        putUngraceful(value: WorkflowStepParallelConfigStepEksResourceScalingConfigUngracefulProperty[] | cdktn.IResolvable): void;
        resetUngraceful(): void;
        get ungracefulInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepEksResourceScalingConfigUngracefulProperty[] | undefined;
    }
    class WorkflowStepParallelConfigStepEksResourceScalingConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepEksResourceScalingConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepEksResourceScalingConfigPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepExecutionApprovalConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#approval_role AwsPlan#approval_role}
        */
        readonly approvalRole: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
    }
    class WorkflowStepParallelConfigStepExecutionApprovalConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepExecutionApprovalConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepExecutionApprovalConfigProperty | cdktn.IResolvable | undefined);
        private _approvalRole?;
        get approvalRole(): string;
        set approvalRole(value: string);
        get approvalRoleInput(): string | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
    }
    class WorkflowStepParallelConfigStepExecutionApprovalConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepExecutionApprovalConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepExecutionApprovalConfigPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepGlobalAuroraConfigUngracefulProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful AwsPlan#ungraceful}
        */
        readonly ungraceful: string;
    }
    class WorkflowStepParallelConfigStepGlobalAuroraConfigUngracefulPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepGlobalAuroraConfigUngracefulProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepGlobalAuroraConfigUngracefulProperty | cdktn.IResolvable | undefined);
        private _ungraceful?;
        get ungraceful(): string;
        set ungraceful(value: string);
        get ungracefulInput(): string | undefined;
    }
    class WorkflowStepParallelConfigStepGlobalAuroraConfigUngracefulPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepGlobalAuroraConfigUngracefulProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepGlobalAuroraConfigUngracefulPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepGlobalAuroraConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#behavior AwsPlan#behavior}
        */
        readonly behavior: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#database_cluster_arns AwsPlan#database_cluster_arns}
        */
        readonly databaseClusterArns: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#global_cluster_identifier AwsPlan#global_cluster_identifier}
        */
        readonly globalClusterIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * ungraceful block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful AwsPlan#ungraceful}
        */
        readonly ungraceful?: WorkflowStepParallelConfigStepGlobalAuroraConfigUngracefulProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepParallelConfigStepGlobalAuroraConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepGlobalAuroraConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepGlobalAuroraConfigProperty | cdktn.IResolvable | undefined);
        private _behavior?;
        get behavior(): string;
        set behavior(value: string);
        get behaviorInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _databaseClusterArns?;
        get databaseClusterArns(): string[];
        set databaseClusterArns(value: string[]);
        get databaseClusterArnsInput(): string[] | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _globalClusterIdentifier?;
        get globalClusterIdentifier(): string;
        set globalClusterIdentifier(value: string);
        get globalClusterIdentifierInput(): string | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _ungraceful;
        get ungraceful(): WorkflowStepParallelConfigStepGlobalAuroraConfigUngracefulPropertyList;
        putUngraceful(value: WorkflowStepParallelConfigStepGlobalAuroraConfigUngracefulProperty[] | cdktn.IResolvable): void;
        resetUngraceful(): void;
        get ungracefulInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepGlobalAuroraConfigUngracefulProperty[] | undefined;
    }
    class WorkflowStepParallelConfigStepGlobalAuroraConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepGlobalAuroraConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepGlobalAuroraConfigPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#arn AwsPlan#arn}
        */
        readonly arn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region AwsPlan#region}
        */
        readonly region: string;
    }
    class WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMappingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty | cdktn.IResolvable | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _region?;
        get region(): string;
        set region(value: string);
        get regionInput(): string | undefined;
    }
    class WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMappingPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMappingPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngracefulProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#behavior AwsPlan#behavior}
        */
        readonly behavior: string;
    }
    class WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngracefulPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngracefulProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngracefulProperty | cdktn.IResolvable | undefined);
        private _behavior?;
        get behavior(): string;
        set behavior(value: string);
        get behaviorInput(): string | undefined;
    }
    class WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngracefulPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngracefulProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngracefulPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#action AwsPlan#action}
        */
        readonly action: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * region_event_source_mapping block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region_event_source_mapping AwsPlan#region_event_source_mapping}
        */
        readonly regionEventSourceMapping?: WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty[] | cdktn.IResolvable;
        /**
        * ungraceful block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful AwsPlan#ungraceful}
        */
        readonly ungraceful?: WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngracefulProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigProperty | cdktn.IResolvable | undefined);
        private _action?;
        get action(): string;
        set action(value: string);
        get actionInput(): string | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _regionEventSourceMapping;
        get regionEventSourceMapping(): WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMappingPropertyList;
        putRegionEventSourceMapping(value: WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty[] | cdktn.IResolvable): void;
        resetRegionEventSourceMapping(): void;
        get regionEventSourceMappingInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty[] | undefined;
        private _ungraceful;
        get ungraceful(): WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngracefulPropertyList;
        putUngraceful(value: WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngracefulProperty[] | cdktn.IResolvable): void;
        resetUngraceful(): void;
        get ungracefulInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngracefulProperty[] | undefined;
    }
    class WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngracefulProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful AwsPlan#ungraceful}
        */
        readonly ungraceful: string;
    }
    class WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngracefulPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngracefulProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngracefulProperty | cdktn.IResolvable | undefined);
        private _ungraceful?;
        get ungraceful(): string;
        set ungraceful(value: string);
        get ungracefulInput(): string | undefined;
    }
    class WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngracefulPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngracefulProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngracefulPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#behavior AwsPlan#behavior}
        */
        readonly behavior: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#global_cluster_identifier AwsPlan#global_cluster_identifier}
        */
        readonly globalClusterIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region_database_cluster_arns AwsPlan#region_database_cluster_arns}
        */
        readonly regionDatabaseClusterArns: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * ungraceful block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful AwsPlan#ungraceful}
        */
        readonly ungraceful?: WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngracefulProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigProperty | cdktn.IResolvable | undefined);
        private _behavior?;
        get behavior(): string;
        set behavior(value: string);
        get behaviorInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _globalClusterIdentifier?;
        get globalClusterIdentifier(): string;
        set globalClusterIdentifier(value: string);
        get globalClusterIdentifierInput(): string | undefined;
        private _regionDatabaseClusterArns?;
        get regionDatabaseClusterArns(): {
            [key: string]: string;
        };
        set regionDatabaseClusterArns(value: {
            [key: string]: string;
        });
        get regionDatabaseClusterArnsInput(): {
            [key: string]: string;
        } | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _ungraceful;
        get ungraceful(): WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngracefulPropertyList;
        putUngraceful(value: WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngracefulProperty[] | cdktn.IResolvable): void;
        resetUngraceful(): void;
        get ungracefulInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngracefulProperty[] | undefined;
    }
    class WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#db_instance_arn_map AwsPlan#db_instance_arn_map}
        */
        readonly dbInstanceArnMap: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
    }
    class WorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfigProperty | cdktn.IResolvable | undefined);
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _dbInstanceArnMap?;
        get dbInstanceArnMap(): {
            [key: string]: string;
        };
        set dbInstanceArnMap(value: {
            [key: string]: string;
        });
        get dbInstanceArnMapInput(): {
            [key: string]: string;
        } | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
    }
    class WorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfigPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepRdsPromoteReadReplicaConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#db_instance_arn_map AwsPlan#db_instance_arn_map}
        */
        readonly dbInstanceArnMap: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
    }
    class WorkflowStepParallelConfigStepRdsPromoteReadReplicaConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepRdsPromoteReadReplicaConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepRdsPromoteReadReplicaConfigProperty | cdktn.IResolvable | undefined);
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _dbInstanceArnMap?;
        get dbInstanceArnMap(): {
            [key: string]: string;
        };
        set dbInstanceArnMap(value: {
            [key: string]: string;
        });
        get dbInstanceArnMapInput(): {
            [key: string]: string;
        } | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
    }
    class WorkflowStepParallelConfigStepRdsPromoteReadReplicaConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepRdsPromoteReadReplicaConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepRdsPromoteReadReplicaConfigPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepRegionSwitchPlanConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#arn AwsPlan#arn}
        */
        readonly arn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsPlan#external_id}
        */
        readonly externalId?: string;
    }
    class WorkflowStepParallelConfigStepRegionSwitchPlanConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepRegionSwitchPlanConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepRegionSwitchPlanConfigProperty | cdktn.IResolvable | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
    }
    class WorkflowStepParallelConfigStepRegionSwitchPlanConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepRegionSwitchPlanConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepRegionSwitchPlanConfigPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#record_set_identifier AwsPlan#record_set_identifier}
        */
        readonly recordSetIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region AwsPlan#region}
        */
        readonly region: string;
    }
    class WorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSetProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSetProperty | cdktn.IResolvable | undefined);
        private _recordSetIdentifier?;
        get recordSetIdentifier(): string;
        set recordSetIdentifier(value: string);
        get recordSetIdentifierInput(): string | undefined;
        private _region?;
        get region(): string;
        set region(value: string);
        get regionInput(): string | undefined;
    }
    class WorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSetPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSetProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSetPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepRoute53HealthCheckConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#hosted_zone_id AwsPlan#hosted_zone_id}
        */
        readonly hostedZoneId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#record_name AwsPlan#record_name}
        */
        readonly recordName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * record_set block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#record_set AwsPlan#record_set}
        */
        readonly recordSet?: WorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSetProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepParallelConfigStepRoute53HealthCheckConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepRoute53HealthCheckConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepRoute53HealthCheckConfigProperty | cdktn.IResolvable | undefined);
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _hostedZoneId?;
        get hostedZoneId(): string;
        set hostedZoneId(value: string);
        get hostedZoneIdInput(): string | undefined;
        private _recordName?;
        get recordName(): string;
        set recordName(value: string);
        get recordNameInput(): string | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _recordSet;
        get recordSet(): WorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSetPropertyList;
        putRecordSet(value: WorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSetProperty[] | cdktn.IResolvable): void;
        resetRecordSet(): void;
        get recordSetInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSetProperty[] | undefined;
    }
    class WorkflowStepParallelConfigStepRoute53HealthCheckConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepRoute53HealthCheckConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepRoute53HealthCheckConfigPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#description AwsPlan#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#execution_block_type AwsPlan#execution_block_type}
        */
        readonly executionBlockType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#name AwsPlan#name}
        */
        readonly name: string;
        /**
        * arc_routing_control_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#arc_routing_control_config AwsPlan#arc_routing_control_config}
        */
        readonly arcRoutingControlConfig?: WorkflowStepParallelConfigStepArcRoutingControlConfigProperty[] | cdktn.IResolvable;
        /**
        * aurora_provisioned_scaling_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#aurora_provisioned_scaling_config AwsPlan#aurora_provisioned_scaling_config}
        */
        readonly auroraProvisionedScalingConfig?: WorkflowStepParallelConfigStepAuroraProvisionedScalingConfigProperty[] | cdktn.IResolvable;
        /**
        * aurora_serverless_scaling_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#aurora_serverless_scaling_config AwsPlan#aurora_serverless_scaling_config}
        */
        readonly auroraServerlessScalingConfig?: WorkflowStepParallelConfigStepAuroraServerlessScalingConfigProperty[] | cdktn.IResolvable;
        /**
        * custom_action_lambda_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#custom_action_lambda_config AwsPlan#custom_action_lambda_config}
        */
        readonly customActionLambdaConfig?: WorkflowStepParallelConfigStepCustomActionLambdaConfigProperty[] | cdktn.IResolvable;
        /**
        * document_db_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#document_db_config AwsPlan#document_db_config}
        */
        readonly documentDbConfig?: WorkflowStepParallelConfigStepDocumentDbConfigProperty[] | cdktn.IResolvable;
        /**
        * ec2_asg_capacity_increase_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ec2_asg_capacity_increase_config AwsPlan#ec2_asg_capacity_increase_config}
        */
        readonly ec2AsgCapacityIncreaseConfig?: WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigProperty[] | cdktn.IResolvable;
        /**
        * ecs_capacity_increase_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ecs_capacity_increase_config AwsPlan#ecs_capacity_increase_config}
        */
        readonly ecsCapacityIncreaseConfig?: WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigProperty[] | cdktn.IResolvable;
        /**
        * eks_resource_scaling_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#eks_resource_scaling_config AwsPlan#eks_resource_scaling_config}
        */
        readonly eksResourceScalingConfig?: WorkflowStepParallelConfigStepEksResourceScalingConfigProperty[] | cdktn.IResolvable;
        /**
        * execution_approval_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#execution_approval_config AwsPlan#execution_approval_config}
        */
        readonly executionApprovalConfig?: WorkflowStepParallelConfigStepExecutionApprovalConfigProperty[] | cdktn.IResolvable;
        /**
        * global_aurora_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#global_aurora_config AwsPlan#global_aurora_config}
        */
        readonly globalAuroraConfig?: WorkflowStepParallelConfigStepGlobalAuroraConfigProperty[] | cdktn.IResolvable;
        /**
        * lambda_event_source_mapping_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#lambda_event_source_mapping_config AwsPlan#lambda_event_source_mapping_config}
        */
        readonly lambdaEventSourceMappingConfig?: WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigProperty[] | cdktn.IResolvable;
        /**
        * neptune_global_database_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#neptune_global_database_config AwsPlan#neptune_global_database_config}
        */
        readonly neptuneGlobalDatabaseConfig?: WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigProperty[] | cdktn.IResolvable;
        /**
        * rds_create_cross_region_read_replica_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#rds_create_cross_region_read_replica_config AwsPlan#rds_create_cross_region_read_replica_config}
        */
        readonly rdsCreateCrossRegionReadReplicaConfig?: WorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfigProperty[] | cdktn.IResolvable;
        /**
        * rds_promote_read_replica_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#rds_promote_read_replica_config AwsPlan#rds_promote_read_replica_config}
        */
        readonly rdsPromoteReadReplicaConfig?: WorkflowStepParallelConfigStepRdsPromoteReadReplicaConfigProperty[] | cdktn.IResolvable;
        /**
        * region_switch_plan_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region_switch_plan_config AwsPlan#region_switch_plan_config}
        */
        readonly regionSwitchPlanConfig?: WorkflowStepParallelConfigStepRegionSwitchPlanConfigProperty[] | cdktn.IResolvable;
        /**
        * route53_health_check_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#route53_health_check_config AwsPlan#route53_health_check_config}
        */
        readonly route53HealthCheckConfig?: WorkflowStepParallelConfigStepRoute53HealthCheckConfigProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepParallelConfigStepPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _executionBlockType?;
        get executionBlockType(): string;
        set executionBlockType(value: string);
        get executionBlockTypeInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _arcRoutingControlConfig;
        get arcRoutingControlConfig(): WorkflowStepParallelConfigStepArcRoutingControlConfigPropertyList;
        putArcRoutingControlConfig(value: WorkflowStepParallelConfigStepArcRoutingControlConfigProperty[] | cdktn.IResolvable): void;
        resetArcRoutingControlConfig(): void;
        get arcRoutingControlConfigInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepArcRoutingControlConfigProperty[] | undefined;
        private _auroraProvisionedScalingConfig;
        get auroraProvisionedScalingConfig(): WorkflowStepParallelConfigStepAuroraProvisionedScalingConfigPropertyList;
        putAuroraProvisionedScalingConfig(value: WorkflowStepParallelConfigStepAuroraProvisionedScalingConfigProperty[] | cdktn.IResolvable): void;
        resetAuroraProvisionedScalingConfig(): void;
        get auroraProvisionedScalingConfigInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepAuroraProvisionedScalingConfigProperty[] | undefined;
        private _auroraServerlessScalingConfig;
        get auroraServerlessScalingConfig(): WorkflowStepParallelConfigStepAuroraServerlessScalingConfigPropertyList;
        putAuroraServerlessScalingConfig(value: WorkflowStepParallelConfigStepAuroraServerlessScalingConfigProperty[] | cdktn.IResolvable): void;
        resetAuroraServerlessScalingConfig(): void;
        get auroraServerlessScalingConfigInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepAuroraServerlessScalingConfigProperty[] | undefined;
        private _customActionLambdaConfig;
        get customActionLambdaConfig(): WorkflowStepParallelConfigStepCustomActionLambdaConfigPropertyList;
        putCustomActionLambdaConfig(value: WorkflowStepParallelConfigStepCustomActionLambdaConfigProperty[] | cdktn.IResolvable): void;
        resetCustomActionLambdaConfig(): void;
        get customActionLambdaConfigInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepCustomActionLambdaConfigProperty[] | undefined;
        private _documentDbConfig;
        get documentDbConfig(): WorkflowStepParallelConfigStepDocumentDbConfigPropertyList;
        putDocumentDbConfig(value: WorkflowStepParallelConfigStepDocumentDbConfigProperty[] | cdktn.IResolvable): void;
        resetDocumentDbConfig(): void;
        get documentDbConfigInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepDocumentDbConfigProperty[] | undefined;
        private _ec2AsgCapacityIncreaseConfig;
        get ec2AsgCapacityIncreaseConfig(): WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigPropertyList;
        putEc2AsgCapacityIncreaseConfig(value: WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigProperty[] | cdktn.IResolvable): void;
        resetEc2AsgCapacityIncreaseConfig(): void;
        get ec2AsgCapacityIncreaseConfigInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigProperty[] | undefined;
        private _ecsCapacityIncreaseConfig;
        get ecsCapacityIncreaseConfig(): WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigPropertyList;
        putEcsCapacityIncreaseConfig(value: WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigProperty[] | cdktn.IResolvable): void;
        resetEcsCapacityIncreaseConfig(): void;
        get ecsCapacityIncreaseConfigInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigProperty[] | undefined;
        private _eksResourceScalingConfig;
        get eksResourceScalingConfig(): WorkflowStepParallelConfigStepEksResourceScalingConfigPropertyList;
        putEksResourceScalingConfig(value: WorkflowStepParallelConfigStepEksResourceScalingConfigProperty[] | cdktn.IResolvable): void;
        resetEksResourceScalingConfig(): void;
        get eksResourceScalingConfigInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepEksResourceScalingConfigProperty[] | undefined;
        private _executionApprovalConfig;
        get executionApprovalConfig(): WorkflowStepParallelConfigStepExecutionApprovalConfigPropertyList;
        putExecutionApprovalConfig(value: WorkflowStepParallelConfigStepExecutionApprovalConfigProperty[] | cdktn.IResolvable): void;
        resetExecutionApprovalConfig(): void;
        get executionApprovalConfigInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepExecutionApprovalConfigProperty[] | undefined;
        private _globalAuroraConfig;
        get globalAuroraConfig(): WorkflowStepParallelConfigStepGlobalAuroraConfigPropertyList;
        putGlobalAuroraConfig(value: WorkflowStepParallelConfigStepGlobalAuroraConfigProperty[] | cdktn.IResolvable): void;
        resetGlobalAuroraConfig(): void;
        get globalAuroraConfigInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepGlobalAuroraConfigProperty[] | undefined;
        private _lambdaEventSourceMappingConfig;
        get lambdaEventSourceMappingConfig(): WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigPropertyList;
        putLambdaEventSourceMappingConfig(value: WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigProperty[] | cdktn.IResolvable): void;
        resetLambdaEventSourceMappingConfig(): void;
        get lambdaEventSourceMappingConfigInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigProperty[] | undefined;
        private _neptuneGlobalDatabaseConfig;
        get neptuneGlobalDatabaseConfig(): WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigPropertyList;
        putNeptuneGlobalDatabaseConfig(value: WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigProperty[] | cdktn.IResolvable): void;
        resetNeptuneGlobalDatabaseConfig(): void;
        get neptuneGlobalDatabaseConfigInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigProperty[] | undefined;
        private _rdsCreateCrossRegionReadReplicaConfig;
        get rdsCreateCrossRegionReadReplicaConfig(): WorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfigPropertyList;
        putRdsCreateCrossRegionReadReplicaConfig(value: WorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfigProperty[] | cdktn.IResolvable): void;
        resetRdsCreateCrossRegionReadReplicaConfig(): void;
        get rdsCreateCrossRegionReadReplicaConfigInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfigProperty[] | undefined;
        private _rdsPromoteReadReplicaConfig;
        get rdsPromoteReadReplicaConfig(): WorkflowStepParallelConfigStepRdsPromoteReadReplicaConfigPropertyList;
        putRdsPromoteReadReplicaConfig(value: WorkflowStepParallelConfigStepRdsPromoteReadReplicaConfigProperty[] | cdktn.IResolvable): void;
        resetRdsPromoteReadReplicaConfig(): void;
        get rdsPromoteReadReplicaConfigInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepRdsPromoteReadReplicaConfigProperty[] | undefined;
        private _regionSwitchPlanConfig;
        get regionSwitchPlanConfig(): WorkflowStepParallelConfigStepRegionSwitchPlanConfigPropertyList;
        putRegionSwitchPlanConfig(value: WorkflowStepParallelConfigStepRegionSwitchPlanConfigProperty[] | cdktn.IResolvable): void;
        resetRegionSwitchPlanConfig(): void;
        get regionSwitchPlanConfigInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepRegionSwitchPlanConfigProperty[] | undefined;
        private _route53HealthCheckConfig;
        get route53HealthCheckConfig(): WorkflowStepParallelConfigStepRoute53HealthCheckConfigPropertyList;
        putRoute53HealthCheckConfig(value: WorkflowStepParallelConfigStepRoute53HealthCheckConfigProperty[] | cdktn.IResolvable): void;
        resetRoute53HealthCheckConfig(): void;
        get route53HealthCheckConfigInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepRoute53HealthCheckConfigProperty[] | undefined;
    }
    class WorkflowStepParallelConfigStepPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepPropertyOutputReference;
    }
    interface ParallelConfigProperty {
        /**
        * step block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#step AwsPlan#step}
        */
        readonly step?: WorkflowStepParallelConfigStepProperty[] | cdktn.IResolvable;
    }
    class ParallelConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ParallelConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ParallelConfigProperty | cdktn.IResolvable | undefined);
        private _step;
        get step(): WorkflowStepParallelConfigStepPropertyList;
        putStep(value: WorkflowStepParallelConfigStepProperty[] | cdktn.IResolvable): void;
        resetStep(): void;
        get stepInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepProperty[] | undefined;
    }
    class ParallelConfigPropertyList extends cdktn.ComplexList {
        internalValue?: ParallelConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ParallelConfigPropertyOutputReference;
    }
    interface WorkflowStepRdsCreateCrossRegionReadReplicaConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#db_instance_arn_map AwsPlan#db_instance_arn_map}
        */
        readonly dbInstanceArnMap: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
    }
    class WorkflowStepRdsCreateCrossRegionReadReplicaConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepRdsCreateCrossRegionReadReplicaConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepRdsCreateCrossRegionReadReplicaConfigProperty | cdktn.IResolvable | undefined);
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _dbInstanceArnMap?;
        get dbInstanceArnMap(): {
            [key: string]: string;
        };
        set dbInstanceArnMap(value: {
            [key: string]: string;
        });
        get dbInstanceArnMapInput(): {
            [key: string]: string;
        } | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
    }
    class WorkflowStepRdsCreateCrossRegionReadReplicaConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepRdsCreateCrossRegionReadReplicaConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepRdsCreateCrossRegionReadReplicaConfigPropertyOutputReference;
    }
    interface WorkflowStepRdsPromoteReadReplicaConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#db_instance_arn_map AwsPlan#db_instance_arn_map}
        */
        readonly dbInstanceArnMap: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
    }
    class WorkflowStepRdsPromoteReadReplicaConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepRdsPromoteReadReplicaConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepRdsPromoteReadReplicaConfigProperty | cdktn.IResolvable | undefined);
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _dbInstanceArnMap?;
        get dbInstanceArnMap(): {
            [key: string]: string;
        };
        set dbInstanceArnMap(value: {
            [key: string]: string;
        });
        get dbInstanceArnMapInput(): {
            [key: string]: string;
        } | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
    }
    class WorkflowStepRdsPromoteReadReplicaConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepRdsPromoteReadReplicaConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepRdsPromoteReadReplicaConfigPropertyOutputReference;
    }
    interface WorkflowStepRegionSwitchPlanConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#arn AwsPlan#arn}
        */
        readonly arn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsPlan#external_id}
        */
        readonly externalId?: string;
    }
    class WorkflowStepRegionSwitchPlanConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepRegionSwitchPlanConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepRegionSwitchPlanConfigProperty | cdktn.IResolvable | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
    }
    class WorkflowStepRegionSwitchPlanConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepRegionSwitchPlanConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepRegionSwitchPlanConfigPropertyOutputReference;
    }
    interface WorkflowStepRoute53HealthCheckConfigRecordSetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#record_set_identifier AwsPlan#record_set_identifier}
        */
        readonly recordSetIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region AwsPlan#region}
        */
        readonly region: string;
    }
    class WorkflowStepRoute53HealthCheckConfigRecordSetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepRoute53HealthCheckConfigRecordSetProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepRoute53HealthCheckConfigRecordSetProperty | cdktn.IResolvable | undefined);
        private _recordSetIdentifier?;
        get recordSetIdentifier(): string;
        set recordSetIdentifier(value: string);
        get recordSetIdentifierInput(): string | undefined;
        private _region?;
        get region(): string;
        set region(value: string);
        get regionInput(): string | undefined;
    }
    class WorkflowStepRoute53HealthCheckConfigRecordSetPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepRoute53HealthCheckConfigRecordSetProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepRoute53HealthCheckConfigRecordSetPropertyOutputReference;
    }
    interface WorkflowStepRoute53HealthCheckConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#hosted_zone_id AwsPlan#hosted_zone_id}
        */
        readonly hostedZoneId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#record_name AwsPlan#record_name}
        */
        readonly recordName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * record_set block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#record_set AwsPlan#record_set}
        */
        readonly recordSet?: WorkflowStepRoute53HealthCheckConfigRecordSetProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepRoute53HealthCheckConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepRoute53HealthCheckConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepRoute53HealthCheckConfigProperty | cdktn.IResolvable | undefined);
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _hostedZoneId?;
        get hostedZoneId(): string;
        set hostedZoneId(value: string);
        get hostedZoneIdInput(): string | undefined;
        private _recordName?;
        get recordName(): string;
        set recordName(value: string);
        get recordNameInput(): string | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _recordSet;
        get recordSet(): WorkflowStepRoute53HealthCheckConfigRecordSetPropertyList;
        putRecordSet(value: WorkflowStepRoute53HealthCheckConfigRecordSetProperty[] | cdktn.IResolvable): void;
        resetRecordSet(): void;
        get recordSetInput(): cdktn.IResolvable | WorkflowStepRoute53HealthCheckConfigRecordSetProperty[] | undefined;
    }
    class WorkflowStepRoute53HealthCheckConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepRoute53HealthCheckConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepRoute53HealthCheckConfigPropertyOutputReference;
    }
    interface WorkflowStepProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#description AwsPlan#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#execution_block_type AwsPlan#execution_block_type}
        */
        readonly executionBlockType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#name AwsPlan#name}
        */
        readonly name: string;
        /**
        * arc_routing_control_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#arc_routing_control_config AwsPlan#arc_routing_control_config}
        */
        readonly arcRoutingControlConfig?: WorkflowStepArcRoutingControlConfigProperty[] | cdktn.IResolvable;
        /**
        * aurora_provisioned_scaling_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#aurora_provisioned_scaling_config AwsPlan#aurora_provisioned_scaling_config}
        */
        readonly auroraProvisionedScalingConfig?: WorkflowStepAuroraProvisionedScalingConfigProperty[] | cdktn.IResolvable;
        /**
        * aurora_serverless_scaling_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#aurora_serverless_scaling_config AwsPlan#aurora_serverless_scaling_config}
        */
        readonly auroraServerlessScalingConfig?: WorkflowStepAuroraServerlessScalingConfigProperty[] | cdktn.IResolvable;
        /**
        * custom_action_lambda_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#custom_action_lambda_config AwsPlan#custom_action_lambda_config}
        */
        readonly customActionLambdaConfig?: WorkflowStepCustomActionLambdaConfigProperty[] | cdktn.IResolvable;
        /**
        * document_db_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#document_db_config AwsPlan#document_db_config}
        */
        readonly documentDbConfig?: WorkflowStepDocumentDbConfigProperty[] | cdktn.IResolvable;
        /**
        * ec2_asg_capacity_increase_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ec2_asg_capacity_increase_config AwsPlan#ec2_asg_capacity_increase_config}
        */
        readonly ec2AsgCapacityIncreaseConfig?: WorkflowStepEc2AsgCapacityIncreaseConfigProperty[] | cdktn.IResolvable;
        /**
        * ecs_capacity_increase_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ecs_capacity_increase_config AwsPlan#ecs_capacity_increase_config}
        */
        readonly ecsCapacityIncreaseConfig?: WorkflowStepEcsCapacityIncreaseConfigProperty[] | cdktn.IResolvable;
        /**
        * eks_resource_scaling_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#eks_resource_scaling_config AwsPlan#eks_resource_scaling_config}
        */
        readonly eksResourceScalingConfig?: WorkflowStepEksResourceScalingConfigProperty[] | cdktn.IResolvable;
        /**
        * execution_approval_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#execution_approval_config AwsPlan#execution_approval_config}
        */
        readonly executionApprovalConfig?: WorkflowStepExecutionApprovalConfigProperty[] | cdktn.IResolvable;
        /**
        * global_aurora_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#global_aurora_config AwsPlan#global_aurora_config}
        */
        readonly globalAuroraConfig?: WorkflowStepGlobalAuroraConfigProperty[] | cdktn.IResolvable;
        /**
        * lambda_event_source_mapping_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#lambda_event_source_mapping_config AwsPlan#lambda_event_source_mapping_config}
        */
        readonly lambdaEventSourceMappingConfig?: WorkflowStepLambdaEventSourceMappingConfigProperty[] | cdktn.IResolvable;
        /**
        * neptune_global_database_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#neptune_global_database_config AwsPlan#neptune_global_database_config}
        */
        readonly neptuneGlobalDatabaseConfig?: WorkflowStepNeptuneGlobalDatabaseConfigProperty[] | cdktn.IResolvable;
        /**
        * parallel_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#parallel_config AwsPlan#parallel_config}
        */
        readonly parallelConfig?: ParallelConfigProperty[] | cdktn.IResolvable;
        /**
        * rds_create_cross_region_read_replica_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#rds_create_cross_region_read_replica_config AwsPlan#rds_create_cross_region_read_replica_config}
        */
        readonly rdsCreateCrossRegionReadReplicaConfig?: WorkflowStepRdsCreateCrossRegionReadReplicaConfigProperty[] | cdktn.IResolvable;
        /**
        * rds_promote_read_replica_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#rds_promote_read_replica_config AwsPlan#rds_promote_read_replica_config}
        */
        readonly rdsPromoteReadReplicaConfig?: WorkflowStepRdsPromoteReadReplicaConfigProperty[] | cdktn.IResolvable;
        /**
        * region_switch_plan_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region_switch_plan_config AwsPlan#region_switch_plan_config}
        */
        readonly regionSwitchPlanConfig?: WorkflowStepRegionSwitchPlanConfigProperty[] | cdktn.IResolvable;
        /**
        * route53_health_check_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#route53_health_check_config AwsPlan#route53_health_check_config}
        */
        readonly route53HealthCheckConfig?: WorkflowStepRoute53HealthCheckConfigProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _executionBlockType?;
        get executionBlockType(): string;
        set executionBlockType(value: string);
        get executionBlockTypeInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _arcRoutingControlConfig;
        get arcRoutingControlConfig(): WorkflowStepArcRoutingControlConfigPropertyList;
        putArcRoutingControlConfig(value: WorkflowStepArcRoutingControlConfigProperty[] | cdktn.IResolvable): void;
        resetArcRoutingControlConfig(): void;
        get arcRoutingControlConfigInput(): cdktn.IResolvable | WorkflowStepArcRoutingControlConfigProperty[] | undefined;
        private _auroraProvisionedScalingConfig;
        get auroraProvisionedScalingConfig(): WorkflowStepAuroraProvisionedScalingConfigPropertyList;
        putAuroraProvisionedScalingConfig(value: WorkflowStepAuroraProvisionedScalingConfigProperty[] | cdktn.IResolvable): void;
        resetAuroraProvisionedScalingConfig(): void;
        get auroraProvisionedScalingConfigInput(): cdktn.IResolvable | WorkflowStepAuroraProvisionedScalingConfigProperty[] | undefined;
        private _auroraServerlessScalingConfig;
        get auroraServerlessScalingConfig(): WorkflowStepAuroraServerlessScalingConfigPropertyList;
        putAuroraServerlessScalingConfig(value: WorkflowStepAuroraServerlessScalingConfigProperty[] | cdktn.IResolvable): void;
        resetAuroraServerlessScalingConfig(): void;
        get auroraServerlessScalingConfigInput(): cdktn.IResolvable | WorkflowStepAuroraServerlessScalingConfigProperty[] | undefined;
        private _customActionLambdaConfig;
        get customActionLambdaConfig(): WorkflowStepCustomActionLambdaConfigPropertyList;
        putCustomActionLambdaConfig(value: WorkflowStepCustomActionLambdaConfigProperty[] | cdktn.IResolvable): void;
        resetCustomActionLambdaConfig(): void;
        get customActionLambdaConfigInput(): cdktn.IResolvable | WorkflowStepCustomActionLambdaConfigProperty[] | undefined;
        private _documentDbConfig;
        get documentDbConfig(): WorkflowStepDocumentDbConfigPropertyList;
        putDocumentDbConfig(value: WorkflowStepDocumentDbConfigProperty[] | cdktn.IResolvable): void;
        resetDocumentDbConfig(): void;
        get documentDbConfigInput(): cdktn.IResolvable | WorkflowStepDocumentDbConfigProperty[] | undefined;
        private _ec2AsgCapacityIncreaseConfig;
        get ec2AsgCapacityIncreaseConfig(): WorkflowStepEc2AsgCapacityIncreaseConfigPropertyList;
        putEc2AsgCapacityIncreaseConfig(value: WorkflowStepEc2AsgCapacityIncreaseConfigProperty[] | cdktn.IResolvable): void;
        resetEc2AsgCapacityIncreaseConfig(): void;
        get ec2AsgCapacityIncreaseConfigInput(): cdktn.IResolvable | WorkflowStepEc2AsgCapacityIncreaseConfigProperty[] | undefined;
        private _ecsCapacityIncreaseConfig;
        get ecsCapacityIncreaseConfig(): WorkflowStepEcsCapacityIncreaseConfigPropertyList;
        putEcsCapacityIncreaseConfig(value: WorkflowStepEcsCapacityIncreaseConfigProperty[] | cdktn.IResolvable): void;
        resetEcsCapacityIncreaseConfig(): void;
        get ecsCapacityIncreaseConfigInput(): cdktn.IResolvable | WorkflowStepEcsCapacityIncreaseConfigProperty[] | undefined;
        private _eksResourceScalingConfig;
        get eksResourceScalingConfig(): WorkflowStepEksResourceScalingConfigPropertyList;
        putEksResourceScalingConfig(value: WorkflowStepEksResourceScalingConfigProperty[] | cdktn.IResolvable): void;
        resetEksResourceScalingConfig(): void;
        get eksResourceScalingConfigInput(): cdktn.IResolvable | WorkflowStepEksResourceScalingConfigProperty[] | undefined;
        private _executionApprovalConfig;
        get executionApprovalConfig(): WorkflowStepExecutionApprovalConfigPropertyList;
        putExecutionApprovalConfig(value: WorkflowStepExecutionApprovalConfigProperty[] | cdktn.IResolvable): void;
        resetExecutionApprovalConfig(): void;
        get executionApprovalConfigInput(): cdktn.IResolvable | WorkflowStepExecutionApprovalConfigProperty[] | undefined;
        private _globalAuroraConfig;
        get globalAuroraConfig(): WorkflowStepGlobalAuroraConfigPropertyList;
        putGlobalAuroraConfig(value: WorkflowStepGlobalAuroraConfigProperty[] | cdktn.IResolvable): void;
        resetGlobalAuroraConfig(): void;
        get globalAuroraConfigInput(): cdktn.IResolvable | WorkflowStepGlobalAuroraConfigProperty[] | undefined;
        private _lambdaEventSourceMappingConfig;
        get lambdaEventSourceMappingConfig(): WorkflowStepLambdaEventSourceMappingConfigPropertyList;
        putLambdaEventSourceMappingConfig(value: WorkflowStepLambdaEventSourceMappingConfigProperty[] | cdktn.IResolvable): void;
        resetLambdaEventSourceMappingConfig(): void;
        get lambdaEventSourceMappingConfigInput(): cdktn.IResolvable | WorkflowStepLambdaEventSourceMappingConfigProperty[] | undefined;
        private _neptuneGlobalDatabaseConfig;
        get neptuneGlobalDatabaseConfig(): WorkflowStepNeptuneGlobalDatabaseConfigPropertyList;
        putNeptuneGlobalDatabaseConfig(value: WorkflowStepNeptuneGlobalDatabaseConfigProperty[] | cdktn.IResolvable): void;
        resetNeptuneGlobalDatabaseConfig(): void;
        get neptuneGlobalDatabaseConfigInput(): cdktn.IResolvable | WorkflowStepNeptuneGlobalDatabaseConfigProperty[] | undefined;
        private _parallelConfig;
        get parallelConfig(): ParallelConfigPropertyList;
        putParallelConfig(value: ParallelConfigProperty[] | cdktn.IResolvable): void;
        resetParallelConfig(): void;
        get parallelConfigInput(): cdktn.IResolvable | ParallelConfigProperty[] | undefined;
        private _rdsCreateCrossRegionReadReplicaConfig;
        get rdsCreateCrossRegionReadReplicaConfig(): WorkflowStepRdsCreateCrossRegionReadReplicaConfigPropertyList;
        putRdsCreateCrossRegionReadReplicaConfig(value: WorkflowStepRdsCreateCrossRegionReadReplicaConfigProperty[] | cdktn.IResolvable): void;
        resetRdsCreateCrossRegionReadReplicaConfig(): void;
        get rdsCreateCrossRegionReadReplicaConfigInput(): cdktn.IResolvable | WorkflowStepRdsCreateCrossRegionReadReplicaConfigProperty[] | undefined;
        private _rdsPromoteReadReplicaConfig;
        get rdsPromoteReadReplicaConfig(): WorkflowStepRdsPromoteReadReplicaConfigPropertyList;
        putRdsPromoteReadReplicaConfig(value: WorkflowStepRdsPromoteReadReplicaConfigProperty[] | cdktn.IResolvable): void;
        resetRdsPromoteReadReplicaConfig(): void;
        get rdsPromoteReadReplicaConfigInput(): cdktn.IResolvable | WorkflowStepRdsPromoteReadReplicaConfigProperty[] | undefined;
        private _regionSwitchPlanConfig;
        get regionSwitchPlanConfig(): WorkflowStepRegionSwitchPlanConfigPropertyList;
        putRegionSwitchPlanConfig(value: WorkflowStepRegionSwitchPlanConfigProperty[] | cdktn.IResolvable): void;
        resetRegionSwitchPlanConfig(): void;
        get regionSwitchPlanConfigInput(): cdktn.IResolvable | WorkflowStepRegionSwitchPlanConfigProperty[] | undefined;
        private _route53HealthCheckConfig;
        get route53HealthCheckConfig(): WorkflowStepRoute53HealthCheckConfigPropertyList;
        putRoute53HealthCheckConfig(value: WorkflowStepRoute53HealthCheckConfigProperty[] | cdktn.IResolvable): void;
        resetRoute53HealthCheckConfig(): void;
        get route53HealthCheckConfigInput(): cdktn.IResolvable | WorkflowStepRoute53HealthCheckConfigProperty[] | undefined;
    }
    class WorkflowStepPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepPropertyOutputReference;
    }
    interface WorkflowProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#workflow_description AwsPlan#workflow_description}
        */
        readonly workflowDescription?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#workflow_target_action AwsPlan#workflow_target_action}
        */
        readonly workflowTargetAction: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#workflow_target_region AwsPlan#workflow_target_region}
        */
        readonly workflowTargetRegion?: string;
        /**
        * step block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#step AwsPlan#step}
        */
        readonly step?: WorkflowStepProperty[] | cdktn.IResolvable;
    }
    class WorkflowPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowProperty | cdktn.IResolvable | undefined);
        private _workflowDescription?;
        get workflowDescription(): string;
        set workflowDescription(value: string);
        resetWorkflowDescription(): void;
        get workflowDescriptionInput(): string | undefined;
        private _workflowTargetAction?;
        get workflowTargetAction(): string;
        set workflowTargetAction(value: string);
        get workflowTargetActionInput(): string | undefined;
        private _workflowTargetRegion?;
        get workflowTargetRegion(): string;
        set workflowTargetRegion(value: string);
        resetWorkflowTargetRegion(): void;
        get workflowTargetRegionInput(): string | undefined;
        private _step;
        get step(): WorkflowStepPropertyList;
        putStep(value: WorkflowStepProperty[] | cdktn.IResolvable): void;
        resetStep(): void;
        get stepInput(): cdktn.IResolvable | WorkflowStepProperty[] | undefined;
    }
    class WorkflowPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowPropertyOutputReference;
    }
}
