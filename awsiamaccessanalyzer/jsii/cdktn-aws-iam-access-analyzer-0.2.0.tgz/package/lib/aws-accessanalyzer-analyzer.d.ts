import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfAnalyzerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_analyzer#analyzer_name TfAnalyzer#analyzer_name}
    */
    readonly analyzerName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_analyzer#id TfAnalyzer#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_analyzer#region TfAnalyzer#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_analyzer#tags TfAnalyzer#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_analyzer#tags_all TfAnalyzer#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_analyzer#type TfAnalyzer#type}
    */
    readonly type?: string;
    /**
    * configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_analyzer#configuration TfAnalyzer#configuration}
    */
    readonly configuration?: TfAnalyzer.ConfigurationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_analyzer aws_accessanalyzer_analyzer}
*/
export declare class TfAnalyzer extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_accessanalyzer_analyzer";
    /**
    * Generates CDKTN code for importing a TfAnalyzer resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfAnalyzer to import
    * @param importFromId The id of the existing TfAnalyzer that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_analyzer#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfAnalyzer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_analyzer aws_accessanalyzer_analyzer} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfAnalyzerConfig
    */
    constructor(scope: Construct, id: string, config: TfAnalyzerConfig);
    private _analyzerName?;
    get analyzerName(): string;
    set analyzerName(value: string);
    get analyzerNameInput(): string | undefined;
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _configuration;
    get configuration(): TfAnalyzer.ConfigurationPropertyOutputReference;
    putConfiguration(value: TfAnalyzer.ConfigurationProperty): void;
    resetConfiguration(): void;
    get configurationInput(): TfAnalyzer.ConfigurationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfAnalyzerInclusionPropertyToTerraform(struct?: TfAnalyzer.InclusionProperty | cdktn.IResolvable): any;
export declare function tfAnalyzerInclusionPropertyToHclTerraform(struct?: TfAnalyzer.InclusionProperty | cdktn.IResolvable): any;
export declare function tfAnalyzerConfigurationInternalAccessAnalysisRulePropertyToTerraform(struct?: TfAnalyzer.ConfigurationInternalAccessAnalysisRulePropertyOutputReference | TfAnalyzer.ConfigurationInternalAccessAnalysisRuleProperty): any;
export declare function tfAnalyzerConfigurationInternalAccessAnalysisRulePropertyToHclTerraform(struct?: TfAnalyzer.ConfigurationInternalAccessAnalysisRulePropertyOutputReference | TfAnalyzer.ConfigurationInternalAccessAnalysisRuleProperty): any;
export declare function tfAnalyzerInternalAccessPropertyToTerraform(struct?: TfAnalyzer.InternalAccessPropertyOutputReference | TfAnalyzer.InternalAccessProperty): any;
export declare function tfAnalyzerInternalAccessPropertyToHclTerraform(struct?: TfAnalyzer.InternalAccessPropertyOutputReference | TfAnalyzer.InternalAccessProperty): any;
export declare function tfAnalyzerExclusionPropertyToTerraform(struct?: TfAnalyzer.ExclusionProperty | cdktn.IResolvable): any;
export declare function tfAnalyzerExclusionPropertyToHclTerraform(struct?: TfAnalyzer.ExclusionProperty | cdktn.IResolvable): any;
export declare function tfAnalyzerConfigurationUnusedAccessAnalysisRulePropertyToTerraform(struct?: TfAnalyzer.ConfigurationUnusedAccessAnalysisRulePropertyOutputReference | TfAnalyzer.ConfigurationUnusedAccessAnalysisRuleProperty): any;
export declare function tfAnalyzerConfigurationUnusedAccessAnalysisRulePropertyToHclTerraform(struct?: TfAnalyzer.ConfigurationUnusedAccessAnalysisRulePropertyOutputReference | TfAnalyzer.ConfigurationUnusedAccessAnalysisRuleProperty): any;
export declare function tfAnalyzerUnusedAccessPropertyToTerraform(struct?: TfAnalyzer.UnusedAccessPropertyOutputReference | TfAnalyzer.UnusedAccessProperty): any;
export declare function tfAnalyzerUnusedAccessPropertyToHclTerraform(struct?: TfAnalyzer.UnusedAccessPropertyOutputReference | TfAnalyzer.UnusedAccessProperty): any;
export declare function tfAnalyzerConfigurationPropertyToTerraform(struct?: TfAnalyzer.ConfigurationPropertyOutputReference | TfAnalyzer.ConfigurationProperty): any;
export declare function tfAnalyzerConfigurationPropertyToHclTerraform(struct?: TfAnalyzer.ConfigurationPropertyOutputReference | TfAnalyzer.ConfigurationProperty): any;
export declare namespace TfAnalyzer {
    interface InclusionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_analyzer#account_ids TfAnalyzer#account_ids}
        */
        readonly accountIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_analyzer#resource_arns TfAnalyzer#resource_arns}
        */
        readonly resourceArns?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_analyzer#resource_types TfAnalyzer#resource_types}
        */
        readonly resourceTypes?: string[];
    }
    class InclusionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InclusionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InclusionProperty | cdktn.IResolvable | undefined);
        private _accountIds?;
        get accountIds(): string[];
        set accountIds(value: string[]);
        resetAccountIds(): void;
        get accountIdsInput(): string[] | undefined;
        private _resourceArns?;
        get resourceArns(): string[];
        set resourceArns(value: string[]);
        resetResourceArns(): void;
        get resourceArnsInput(): string[] | undefined;
        private _resourceTypes?;
        get resourceTypes(): string[];
        set resourceTypes(value: string[]);
        resetResourceTypes(): void;
        get resourceTypesInput(): string[] | undefined;
    }
    class InclusionPropertyList extends cdktn.ComplexList {
        internalValue?: InclusionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InclusionPropertyOutputReference;
    }
    interface ConfigurationInternalAccessAnalysisRuleProperty {
        /**
        * inclusion block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_analyzer#inclusion TfAnalyzer#inclusion}
        */
        readonly inclusion?: InclusionProperty[] | cdktn.IResolvable;
    }
    class ConfigurationInternalAccessAnalysisRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConfigurationInternalAccessAnalysisRuleProperty | undefined;
        set internalValue(value: ConfigurationInternalAccessAnalysisRuleProperty | undefined);
        private _inclusion;
        get inclusion(): InclusionPropertyList;
        putInclusion(value: InclusionProperty[] | cdktn.IResolvable): void;
        resetInclusion(): void;
        get inclusionInput(): cdktn.IResolvable | InclusionProperty[] | undefined;
    }
    interface InternalAccessProperty {
        /**
        * analysis_rule block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_analyzer#analysis_rule TfAnalyzer#analysis_rule}
        */
        readonly analysisRule?: ConfigurationInternalAccessAnalysisRuleProperty;
    }
    class InternalAccessPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InternalAccessProperty | undefined;
        set internalValue(value: InternalAccessProperty | undefined);
        private _analysisRule;
        get analysisRule(): ConfigurationInternalAccessAnalysisRulePropertyOutputReference;
        putAnalysisRule(value: ConfigurationInternalAccessAnalysisRuleProperty): void;
        resetAnalysisRule(): void;
        get analysisRuleInput(): ConfigurationInternalAccessAnalysisRuleProperty | undefined;
    }
    interface ExclusionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_analyzer#account_ids TfAnalyzer#account_ids}
        */
        readonly accountIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_analyzer#resource_tags TfAnalyzer#resource_tags}
        */
        readonly resourceTags?: {
            [key: string]: string;
        }[] | cdktn.IResolvable;
    }
    class ExclusionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExclusionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ExclusionProperty | cdktn.IResolvable | undefined);
        private _accountIds?;
        get accountIds(): string[];
        set accountIds(value: string[]);
        resetAccountIds(): void;
        get accountIdsInput(): string[] | undefined;
        private _resourceTags?;
        get resourceTags(): {
            [key: string]: string;
        }[] | cdktn.IResolvable;
        set resourceTags(value: {
            [key: string]: string;
        }[] | cdktn.IResolvable);
        resetResourceTags(): void;
        get resourceTagsInput(): cdktn.IResolvable | {
            [key: string]: string;
        }[] | undefined;
    }
    class ExclusionPropertyList extends cdktn.ComplexList {
        internalValue?: ExclusionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExclusionPropertyOutputReference;
    }
    interface ConfigurationUnusedAccessAnalysisRuleProperty {
        /**
        * exclusion block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_analyzer#exclusion TfAnalyzer#exclusion}
        */
        readonly exclusion?: ExclusionProperty[] | cdktn.IResolvable;
    }
    class ConfigurationUnusedAccessAnalysisRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConfigurationUnusedAccessAnalysisRuleProperty | undefined;
        set internalValue(value: ConfigurationUnusedAccessAnalysisRuleProperty | undefined);
        private _exclusion;
        get exclusion(): ExclusionPropertyList;
        putExclusion(value: ExclusionProperty[] | cdktn.IResolvable): void;
        resetExclusion(): void;
        get exclusionInput(): cdktn.IResolvable | ExclusionProperty[] | undefined;
    }
    interface UnusedAccessProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_analyzer#unused_access_age TfAnalyzer#unused_access_age}
        */
        readonly unusedAccessAge?: number;
        /**
        * analysis_rule block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_analyzer#analysis_rule TfAnalyzer#analysis_rule}
        */
        readonly analysisRule?: ConfigurationUnusedAccessAnalysisRuleProperty;
    }
    class UnusedAccessPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UnusedAccessProperty | undefined;
        set internalValue(value: UnusedAccessProperty | undefined);
        private _unusedAccessAge?;
        get unusedAccessAge(): number;
        set unusedAccessAge(value: number);
        resetUnusedAccessAge(): void;
        get unusedAccessAgeInput(): number | undefined;
        private _analysisRule;
        get analysisRule(): ConfigurationUnusedAccessAnalysisRulePropertyOutputReference;
        putAnalysisRule(value: ConfigurationUnusedAccessAnalysisRuleProperty): void;
        resetAnalysisRule(): void;
        get analysisRuleInput(): ConfigurationUnusedAccessAnalysisRuleProperty | undefined;
    }
    interface ConfigurationProperty {
        /**
        * internal_access block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_analyzer#internal_access TfAnalyzer#internal_access}
        */
        readonly internalAccess?: InternalAccessProperty;
        /**
        * unused_access block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_analyzer#unused_access TfAnalyzer#unused_access}
        */
        readonly unusedAccess?: UnusedAccessProperty;
    }
    class ConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConfigurationProperty | undefined;
        set internalValue(value: ConfigurationProperty | undefined);
        private _internalAccess;
        get internalAccess(): InternalAccessPropertyOutputReference;
        putInternalAccess(value: InternalAccessProperty): void;
        resetInternalAccess(): void;
        get internalAccessInput(): InternalAccessProperty | undefined;
        private _unusedAccess;
        get unusedAccess(): UnusedAccessPropertyOutputReference;
        putUnusedAccess(value: UnusedAccessProperty): void;
        resetUnusedAccess(): void;
        get unusedAccessInput(): UnusedAccessProperty | undefined;
    }
}
