import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAccessanalyzerArchiveRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_archive_rule#analyzer_name AwsAccessanalyzerArchiveRule#analyzer_name}
    */
    readonly analyzerName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_archive_rule#id AwsAccessanalyzerArchiveRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_archive_rule#region AwsAccessanalyzerArchiveRule#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_archive_rule#rule_name AwsAccessanalyzerArchiveRule#rule_name}
    */
    readonly ruleName: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_archive_rule#filter AwsAccessanalyzerArchiveRule#filter}
    */
    readonly filter: AwsAccessanalyzerArchiveRule.FilterProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_archive_rule aws_accessanalyzer_archive_rule}
*/
export declare class AwsAccessanalyzerArchiveRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_accessanalyzer_archive_rule";
    /**
    * Generates CDKTN code for importing a AwsAccessanalyzerArchiveRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsAccessanalyzerArchiveRule to import
    * @param importFromId The id of the existing AwsAccessanalyzerArchiveRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_archive_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsAccessanalyzerArchiveRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_archive_rule aws_accessanalyzer_archive_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAccessanalyzerArchiveRuleConfig
    */
    constructor(scope: Construct, id: string, config: AwsAccessanalyzerArchiveRuleConfig);
    private _analyzerName?;
    get analyzerName(): string;
    set analyzerName(value: string);
    get analyzerNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _ruleName?;
    get ruleName(): string;
    set ruleName(value: string);
    get ruleNameInput(): string | undefined;
    private _filter;
    get filter(): AwsAccessanalyzerArchiveRule.FilterPropertyList;
    putFilter(value: AwsAccessanalyzerArchiveRule.FilterProperty[] | cdktn.IResolvable): void;
    get filterInput(): cdktn.IResolvable | AwsAccessanalyzerArchiveRule.FilterProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsAccessanalyzerArchiveRuleFilterPropertyToTerraform(struct?: AwsAccessanalyzerArchiveRule.FilterProperty | cdktn.IResolvable): any;
export declare function awsAccessanalyzerArchiveRuleFilterPropertyToHclTerraform(struct?: AwsAccessanalyzerArchiveRule.FilterProperty | cdktn.IResolvable): any;
export declare namespace AwsAccessanalyzerArchiveRule {
    interface FilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_archive_rule#contains AwsAccessanalyzerArchiveRule#contains}
        */
        readonly contains?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_archive_rule#criteria AwsAccessanalyzerArchiveRule#criteria}
        */
        readonly criteria: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_archive_rule#eq AwsAccessanalyzerArchiveRule#eq}
        */
        readonly eq?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_archive_rule#exists AwsAccessanalyzerArchiveRule#exists}
        */
        readonly exists?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_archive_rule#neq AwsAccessanalyzerArchiveRule#neq}
        */
        readonly neq?: string[];
    }
    class FilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FilterProperty | cdktn.IResolvable | undefined);
        private _contains?;
        get contains(): string[];
        set contains(value: string[]);
        resetContains(): void;
        get containsInput(): string[] | undefined;
        private _criteria?;
        get criteria(): string;
        set criteria(value: string);
        get criteriaInput(): string | undefined;
        private _eq?;
        get eq(): string[];
        set eq(value: string[]);
        resetEq(): void;
        get eqInput(): string[] | undefined;
        private _exists?;
        get exists(): string;
        set exists(value: string);
        resetExists(): void;
        get existsInput(): string | undefined;
        private _neq?;
        get neq(): string[];
        set neq(value: string[]);
        resetNeq(): void;
        get neqInput(): string[] | undefined;
    }
    class FilterPropertyList extends cdktn.ComplexList {
        internalValue?: FilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterPropertyOutputReference;
    }
}
