import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsMediaConvertQueueConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/media_convert_queue#concurrent_jobs AwsMediaConvertQueue#concurrent_jobs}
    */
    readonly concurrentJobs?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/media_convert_queue#description AwsMediaConvertQueue#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/media_convert_queue#id AwsMediaConvertQueue#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/media_convert_queue#name AwsMediaConvertQueue#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/media_convert_queue#pricing_plan AwsMediaConvertQueue#pricing_plan}
    */
    readonly pricingPlan?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/media_convert_queue#region AwsMediaConvertQueue#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/media_convert_queue#status AwsMediaConvertQueue#status}
    */
    readonly status?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/media_convert_queue#tags AwsMediaConvertQueue#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/media_convert_queue#tags_all AwsMediaConvertQueue#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * reservation_plan_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/media_convert_queue#reservation_plan_settings AwsMediaConvertQueue#reservation_plan_settings}
    */
    readonly reservationPlanSettings?: AwsMediaConvertQueue.ReservationPlanSettingsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/media_convert_queue aws_media_convert_queue}
*/
export declare class AwsMediaConvertQueue extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_media_convert_queue";
    /**
    * Generates CDKTN code for importing a AwsMediaConvertQueue resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsMediaConvertQueue to import
    * @param importFromId The id of the existing AwsMediaConvertQueue that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/media_convert_queue#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsMediaConvertQueue to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/media_convert_queue aws_media_convert_queue} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsMediaConvertQueueConfig
    */
    constructor(scope: Construct, id: string, config: AwsMediaConvertQueueConfig);
    get arn(): string;
    private _concurrentJobs?;
    get concurrentJobs(): number;
    set concurrentJobs(value: number);
    resetConcurrentJobs(): void;
    get concurrentJobsInput(): number | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _pricingPlan?;
    get pricingPlan(): string;
    set pricingPlan(value: string);
    resetPricingPlan(): void;
    get pricingPlanInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _reservationPlanSettings;
    get reservationPlanSettings(): AwsMediaConvertQueue.ReservationPlanSettingsPropertyOutputReference;
    putReservationPlanSettings(value: AwsMediaConvertQueue.ReservationPlanSettingsProperty): void;
    resetReservationPlanSettings(): void;
    get reservationPlanSettingsInput(): AwsMediaConvertQueue.ReservationPlanSettingsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsMediaConvertQueueReservationPlanSettingsPropertyToTerraform(struct?: AwsMediaConvertQueue.ReservationPlanSettingsPropertyOutputReference | AwsMediaConvertQueue.ReservationPlanSettingsProperty): any;
export declare function awsMediaConvertQueueReservationPlanSettingsPropertyToHclTerraform(struct?: AwsMediaConvertQueue.ReservationPlanSettingsPropertyOutputReference | AwsMediaConvertQueue.ReservationPlanSettingsProperty): any;
export declare namespace AwsMediaConvertQueue {
    interface ReservationPlanSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/media_convert_queue#commitment AwsMediaConvertQueue#commitment}
        */
        readonly commitment: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/media_convert_queue#renewal_type AwsMediaConvertQueue#renewal_type}
        */
        readonly renewalType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/media_convert_queue#reserved_slots AwsMediaConvertQueue#reserved_slots}
        */
        readonly reservedSlots: number;
    }
    class ReservationPlanSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ReservationPlanSettingsProperty | undefined;
        set internalValue(value: ReservationPlanSettingsProperty | undefined);
        private _commitment?;
        get commitment(): string;
        set commitment(value: string);
        get commitmentInput(): string | undefined;
        private _renewalType?;
        get renewalType(): string;
        set renewalType(value: string);
        get renewalTypeInput(): string | undefined;
        private _reservedSlots?;
        get reservedSlots(): number;
        set reservedSlots(value: number);
        get reservedSlotsInput(): number | undefined;
    }
}
