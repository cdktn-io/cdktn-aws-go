import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsFleetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_fleet#build_id AwsFleet#build_id}
    */
    readonly buildId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_fleet#description AwsFleet#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_fleet#ec2_instance_type AwsFleet#ec2_instance_type}
    */
    readonly ec2InstanceType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_fleet#fleet_type AwsFleet#fleet_type}
    */
    readonly fleetType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_fleet#id AwsFleet#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_fleet#instance_role_arn AwsFleet#instance_role_arn}
    */
    readonly instanceRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_fleet#metric_groups AwsFleet#metric_groups}
    */
    readonly metricGroups?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_fleet#name AwsFleet#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_fleet#new_game_session_protection_policy AwsFleet#new_game_session_protection_policy}
    */
    readonly newGameSessionProtectionPolicy?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_fleet#region AwsFleet#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_fleet#script_id AwsFleet#script_id}
    */
    readonly scriptId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_fleet#tags AwsFleet#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_fleet#tags_all AwsFleet#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * certificate_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_fleet#certificate_configuration AwsFleet#certificate_configuration}
    */
    readonly certificateConfiguration?: AwsFleet.CertificateConfigurationProperty;
    /**
    * ec2_inbound_permission block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_fleet#ec2_inbound_permission AwsFleet#ec2_inbound_permission}
    */
    readonly ec2InboundPermission?: AwsFleet.Ec2InboundPermissionProperty[] | cdktn.IResolvable;
    /**
    * resource_creation_limit_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_fleet#resource_creation_limit_policy AwsFleet#resource_creation_limit_policy}
    */
    readonly resourceCreationLimitPolicy?: AwsFleet.ResourceCreationLimitPolicyProperty;
    /**
    * runtime_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_fleet#runtime_configuration AwsFleet#runtime_configuration}
    */
    readonly runtimeConfiguration?: AwsFleet.RuntimeConfigurationProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_fleet#timeouts AwsFleet#timeouts}
    */
    readonly timeouts?: AwsFleet.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_fleet aws_gamelift_fleet}
*/
export declare class AwsFleet extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_gamelift_fleet";
    /**
    * Generates CDKTN code for importing a AwsFleet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsFleet to import
    * @param importFromId The id of the existing AwsFleet that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_fleet#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsFleet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_fleet aws_gamelift_fleet} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsFleetConfig
    */
    constructor(scope: Construct, id: string, config: AwsFleetConfig);
    get arn(): string;
    get buildArn(): string;
    private _buildId?;
    get buildId(): string;
    set buildId(value: string);
    resetBuildId(): void;
    get buildIdInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _ec2InstanceType?;
    get ec2InstanceType(): string;
    set ec2InstanceType(value: string);
    get ec2InstanceTypeInput(): string | undefined;
    private _fleetType?;
    get fleetType(): string;
    set fleetType(value: string);
    resetFleetType(): void;
    get fleetTypeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceRoleArn?;
    get instanceRoleArn(): string;
    set instanceRoleArn(value: string);
    resetInstanceRoleArn(): void;
    get instanceRoleArnInput(): string | undefined;
    get logPaths(): string[];
    private _metricGroups?;
    get metricGroups(): string[];
    set metricGroups(value: string[]);
    resetMetricGroups(): void;
    get metricGroupsInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _newGameSessionProtectionPolicy?;
    get newGameSessionProtectionPolicy(): string;
    set newGameSessionProtectionPolicy(value: string);
    resetNewGameSessionProtectionPolicy(): void;
    get newGameSessionProtectionPolicyInput(): string | undefined;
    get operatingSystem(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get scriptArn(): string;
    private _scriptId?;
    get scriptId(): string;
    set scriptId(value: string);
    resetScriptId(): void;
    get scriptIdInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _certificateConfiguration;
    get certificateConfiguration(): AwsFleet.CertificateConfigurationPropertyOutputReference;
    putCertificateConfiguration(value: AwsFleet.CertificateConfigurationProperty): void;
    resetCertificateConfiguration(): void;
    get certificateConfigurationInput(): AwsFleet.CertificateConfigurationProperty | undefined;
    private _ec2InboundPermission;
    get ec2InboundPermission(): AwsFleet.Ec2InboundPermissionPropertyList;
    putEc2InboundPermission(value: AwsFleet.Ec2InboundPermissionProperty[] | cdktn.IResolvable): void;
    resetEc2InboundPermission(): void;
    get ec2InboundPermissionInput(): cdktn.IResolvable | AwsFleet.Ec2InboundPermissionProperty[] | undefined;
    private _resourceCreationLimitPolicy;
    get resourceCreationLimitPolicy(): AwsFleet.ResourceCreationLimitPolicyPropertyOutputReference;
    putResourceCreationLimitPolicy(value: AwsFleet.ResourceCreationLimitPolicyProperty): void;
    resetResourceCreationLimitPolicy(): void;
    get resourceCreationLimitPolicyInput(): AwsFleet.ResourceCreationLimitPolicyProperty | undefined;
    private _runtimeConfiguration;
    get runtimeConfiguration(): AwsFleet.RuntimeConfigurationPropertyOutputReference;
    putRuntimeConfiguration(value: AwsFleet.RuntimeConfigurationProperty): void;
    resetRuntimeConfiguration(): void;
    get runtimeConfigurationInput(): AwsFleet.RuntimeConfigurationProperty | undefined;
    private _timeouts;
    get timeouts(): AwsFleet.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsFleet.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsFleet.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsFleetCertificateConfigurationPropertyToTerraform(struct?: AwsFleet.CertificateConfigurationPropertyOutputReference | AwsFleet.CertificateConfigurationProperty): any;
export declare function awsFleetCertificateConfigurationPropertyToHclTerraform(struct?: AwsFleet.CertificateConfigurationPropertyOutputReference | AwsFleet.CertificateConfigurationProperty): any;
export declare function awsFleetEc2InboundPermissionPropertyToTerraform(struct?: AwsFleet.Ec2InboundPermissionProperty | cdktn.IResolvable): any;
export declare function awsFleetEc2InboundPermissionPropertyToHclTerraform(struct?: AwsFleet.Ec2InboundPermissionProperty | cdktn.IResolvable): any;
export declare function awsFleetResourceCreationLimitPolicyPropertyToTerraform(struct?: AwsFleet.ResourceCreationLimitPolicyPropertyOutputReference | AwsFleet.ResourceCreationLimitPolicyProperty): any;
export declare function awsFleetResourceCreationLimitPolicyPropertyToHclTerraform(struct?: AwsFleet.ResourceCreationLimitPolicyPropertyOutputReference | AwsFleet.ResourceCreationLimitPolicyProperty): any;
export declare function awsFleetServerProcessPropertyToTerraform(struct?: AwsFleet.ServerProcessProperty | cdktn.IResolvable): any;
export declare function awsFleetServerProcessPropertyToHclTerraform(struct?: AwsFleet.ServerProcessProperty | cdktn.IResolvable): any;
export declare function awsFleetRuntimeConfigurationPropertyToTerraform(struct?: AwsFleet.RuntimeConfigurationPropertyOutputReference | AwsFleet.RuntimeConfigurationProperty): any;
export declare function awsFleetRuntimeConfigurationPropertyToHclTerraform(struct?: AwsFleet.RuntimeConfigurationPropertyOutputReference | AwsFleet.RuntimeConfigurationProperty): any;
export declare function awsFleetTimeoutsPropertyToTerraform(struct?: AwsFleet.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsFleetTimeoutsPropertyToHclTerraform(struct?: AwsFleet.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsFleet {
    interface CertificateConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_fleet#certificate_type AwsFleet#certificate_type}
        */
        readonly certificateType?: string;
    }
    class CertificateConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CertificateConfigurationProperty | undefined;
        set internalValue(value: CertificateConfigurationProperty | undefined);
        private _certificateType?;
        get certificateType(): string;
        set certificateType(value: string);
        resetCertificateType(): void;
        get certificateTypeInput(): string | undefined;
    }
    interface Ec2InboundPermissionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_fleet#from_port AwsFleet#from_port}
        */
        readonly fromPort: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_fleet#ip_range AwsFleet#ip_range}
        */
        readonly ipRange: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_fleet#protocol AwsFleet#protocol}
        */
        readonly protocol: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_fleet#to_port AwsFleet#to_port}
        */
        readonly toPort: number;
    }
    class Ec2InboundPermissionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): Ec2InboundPermissionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: Ec2InboundPermissionProperty | cdktn.IResolvable | undefined);
        private _fromPort?;
        get fromPort(): number;
        set fromPort(value: number);
        get fromPortInput(): number | undefined;
        private _ipRange?;
        get ipRange(): string;
        set ipRange(value: string);
        get ipRangeInput(): string | undefined;
        private _protocol?;
        get protocol(): string;
        set protocol(value: string);
        get protocolInput(): string | undefined;
        private _toPort?;
        get toPort(): number;
        set toPort(value: number);
        get toPortInput(): number | undefined;
    }
    class Ec2InboundPermissionPropertyList extends cdktn.ComplexList {
        internalValue?: Ec2InboundPermissionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): Ec2InboundPermissionPropertyOutputReference;
    }
    interface ResourceCreationLimitPolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_fleet#new_game_sessions_per_creator AwsFleet#new_game_sessions_per_creator}
        */
        readonly newGameSessionsPerCreator?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_fleet#policy_period_in_minutes AwsFleet#policy_period_in_minutes}
        */
        readonly policyPeriodInMinutes?: number;
    }
    class ResourceCreationLimitPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ResourceCreationLimitPolicyProperty | undefined;
        set internalValue(value: ResourceCreationLimitPolicyProperty | undefined);
        private _newGameSessionsPerCreator?;
        get newGameSessionsPerCreator(): number;
        set newGameSessionsPerCreator(value: number);
        resetNewGameSessionsPerCreator(): void;
        get newGameSessionsPerCreatorInput(): number | undefined;
        private _policyPeriodInMinutes?;
        get policyPeriodInMinutes(): number;
        set policyPeriodInMinutes(value: number);
        resetPolicyPeriodInMinutes(): void;
        get policyPeriodInMinutesInput(): number | undefined;
    }
    interface ServerProcessProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_fleet#concurrent_executions AwsFleet#concurrent_executions}
        */
        readonly concurrentExecutions: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_fleet#launch_path AwsFleet#launch_path}
        */
        readonly launchPath: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_fleet#parameters AwsFleet#parameters}
        */
        readonly parameters?: string;
    }
    class ServerProcessPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ServerProcessProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ServerProcessProperty | cdktn.IResolvable | undefined);
        private _concurrentExecutions?;
        get concurrentExecutions(): number;
        set concurrentExecutions(value: number);
        get concurrentExecutionsInput(): number | undefined;
        private _launchPath?;
        get launchPath(): string;
        set launchPath(value: string);
        get launchPathInput(): string | undefined;
        private _parameters?;
        get parameters(): string;
        set parameters(value: string);
        resetParameters(): void;
        get parametersInput(): string | undefined;
    }
    class ServerProcessPropertyList extends cdktn.ComplexList {
        internalValue?: ServerProcessProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ServerProcessPropertyOutputReference;
    }
    interface RuntimeConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_fleet#game_session_activation_timeout_seconds AwsFleet#game_session_activation_timeout_seconds}
        */
        readonly gameSessionActivationTimeoutSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_fleet#max_concurrent_game_session_activations AwsFleet#max_concurrent_game_session_activations}
        */
        readonly maxConcurrentGameSessionActivations?: number;
        /**
        * server_process block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_fleet#server_process AwsFleet#server_process}
        */
        readonly serverProcess?: ServerProcessProperty[] | cdktn.IResolvable;
    }
    class RuntimeConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuntimeConfigurationProperty | undefined;
        set internalValue(value: RuntimeConfigurationProperty | undefined);
        private _gameSessionActivationTimeoutSeconds?;
        get gameSessionActivationTimeoutSeconds(): number;
        set gameSessionActivationTimeoutSeconds(value: number);
        resetGameSessionActivationTimeoutSeconds(): void;
        get gameSessionActivationTimeoutSecondsInput(): number | undefined;
        private _maxConcurrentGameSessionActivations?;
        get maxConcurrentGameSessionActivations(): number;
        set maxConcurrentGameSessionActivations(value: number);
        resetMaxConcurrentGameSessionActivations(): void;
        get maxConcurrentGameSessionActivationsInput(): number | undefined;
        private _serverProcess;
        get serverProcess(): ServerProcessPropertyList;
        putServerProcess(value: ServerProcessProperty[] | cdktn.IResolvable): void;
        resetServerProcess(): void;
        get serverProcessInput(): cdktn.IResolvable | ServerProcessProperty[] | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_fleet#create AwsFleet#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_fleet#delete AwsFleet#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
