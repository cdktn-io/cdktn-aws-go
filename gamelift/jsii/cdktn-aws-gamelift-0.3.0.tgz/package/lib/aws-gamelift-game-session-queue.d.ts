import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsGameSessionQueueConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_game_session_queue#custom_event_data AwsGameSessionQueue#custom_event_data}
    */
    readonly customEventData?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_game_session_queue#destinations AwsGameSessionQueue#destinations}
    */
    readonly destinations?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_game_session_queue#id AwsGameSessionQueue#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_game_session_queue#name AwsGameSessionQueue#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_game_session_queue#notification_target AwsGameSessionQueue#notification_target}
    */
    readonly notificationTarget?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_game_session_queue#region AwsGameSessionQueue#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_game_session_queue#tags AwsGameSessionQueue#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_game_session_queue#tags_all AwsGameSessionQueue#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_game_session_queue#timeout_in_seconds AwsGameSessionQueue#timeout_in_seconds}
    */
    readonly timeoutInSeconds?: number;
    /**
    * player_latency_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_game_session_queue#player_latency_policy AwsGameSessionQueue#player_latency_policy}
    */
    readonly playerLatencyPolicy?: AwsGameSessionQueue.PlayerLatencyPolicyProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_game_session_queue aws_gamelift_game_session_queue}
*/
export declare class AwsGameSessionQueue extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_gamelift_game_session_queue";
    /**
    * Generates CDKTN code for importing a AwsGameSessionQueue resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsGameSessionQueue to import
    * @param importFromId The id of the existing AwsGameSessionQueue that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_game_session_queue#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsGameSessionQueue to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_game_session_queue aws_gamelift_game_session_queue} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsGameSessionQueueConfig
    */
    constructor(scope: Construct, id: string, config: AwsGameSessionQueueConfig);
    get arn(): string;
    private _customEventData?;
    get customEventData(): string;
    set customEventData(value: string);
    resetCustomEventData(): void;
    get customEventDataInput(): string | undefined;
    private _destinations?;
    get destinations(): string[];
    set destinations(value: string[]);
    resetDestinations(): void;
    get destinationsInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _notificationTarget?;
    get notificationTarget(): string;
    set notificationTarget(value: string);
    resetNotificationTarget(): void;
    get notificationTargetInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _timeoutInSeconds?;
    get timeoutInSeconds(): number;
    set timeoutInSeconds(value: number);
    resetTimeoutInSeconds(): void;
    get timeoutInSecondsInput(): number | undefined;
    private _playerLatencyPolicy;
    get playerLatencyPolicy(): AwsGameSessionQueue.PlayerLatencyPolicyPropertyList;
    putPlayerLatencyPolicy(value: AwsGameSessionQueue.PlayerLatencyPolicyProperty[] | cdktn.IResolvable): void;
    resetPlayerLatencyPolicy(): void;
    get playerLatencyPolicyInput(): cdktn.IResolvable | AwsGameSessionQueue.PlayerLatencyPolicyProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsGameSessionQueuePlayerLatencyPolicyPropertyToTerraform(struct?: AwsGameSessionQueue.PlayerLatencyPolicyProperty | cdktn.IResolvable): any;
export declare function awsGameSessionQueuePlayerLatencyPolicyPropertyToHclTerraform(struct?: AwsGameSessionQueue.PlayerLatencyPolicyProperty | cdktn.IResolvable): any;
export declare namespace AwsGameSessionQueue {
    interface PlayerLatencyPolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_game_session_queue#maximum_individual_player_latency_milliseconds AwsGameSessionQueue#maximum_individual_player_latency_milliseconds}
        */
        readonly maximumIndividualPlayerLatencyMilliseconds: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_game_session_queue#policy_duration_seconds AwsGameSessionQueue#policy_duration_seconds}
        */
        readonly policyDurationSeconds?: number;
    }
    class PlayerLatencyPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PlayerLatencyPolicyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PlayerLatencyPolicyProperty | cdktn.IResolvable | undefined);
        private _maximumIndividualPlayerLatencyMilliseconds?;
        get maximumIndividualPlayerLatencyMilliseconds(): number;
        set maximumIndividualPlayerLatencyMilliseconds(value: number);
        get maximumIndividualPlayerLatencyMillisecondsInput(): number | undefined;
        private _policyDurationSeconds?;
        get policyDurationSeconds(): number;
        set policyDurationSeconds(value: number);
        resetPolicyDurationSeconds(): void;
        get policyDurationSecondsInput(): number | undefined;
    }
    class PlayerLatencyPolicyPropertyList extends cdktn.ComplexList {
        internalValue?: PlayerLatencyPolicyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PlayerLatencyPolicyPropertyOutputReference;
    }
}
