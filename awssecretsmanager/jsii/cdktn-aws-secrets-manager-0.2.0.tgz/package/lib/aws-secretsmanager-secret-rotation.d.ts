import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfSecretRotationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/secretsmanager_secret_rotation#external_secret_rotation_role_arn TfSecretRotation#external_secret_rotation_role_arn}
    */
    readonly externalSecretRotationRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/secretsmanager_secret_rotation#id TfSecretRotation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/secretsmanager_secret_rotation#region TfSecretRotation#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/secretsmanager_secret_rotation#rotate_immediately TfSecretRotation#rotate_immediately}
    */
    readonly rotateImmediately?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/secretsmanager_secret_rotation#rotation_enabled TfSecretRotation#rotation_enabled}
    */
    readonly rotationEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/secretsmanager_secret_rotation#rotation_lambda_arn TfSecretRotation#rotation_lambda_arn}
    */
    readonly rotationLambdaArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/secretsmanager_secret_rotation#secret_id TfSecretRotation#secret_id}
    */
    readonly secretId: string;
    /**
    * external_secret_rotation_metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/secretsmanager_secret_rotation#external_secret_rotation_metadata TfSecretRotation#external_secret_rotation_metadata}
    */
    readonly externalSecretRotationMetadata?: TfSecretRotation.ExternalSecretRotationMetadataProperty[] | cdktn.IResolvable;
    /**
    * rotation_rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/secretsmanager_secret_rotation#rotation_rules TfSecretRotation#rotation_rules}
    */
    readonly rotationRules?: TfSecretRotation.RotationRulesProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/secretsmanager_secret_rotation aws_secretsmanager_secret_rotation}
*/
export declare class TfSecretRotation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_secretsmanager_secret_rotation";
    /**
    * Generates CDKTN code for importing a TfSecretRotation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfSecretRotation to import
    * @param importFromId The id of the existing TfSecretRotation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/secretsmanager_secret_rotation#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfSecretRotation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/secretsmanager_secret_rotation aws_secretsmanager_secret_rotation} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfSecretRotationConfig
    */
    constructor(scope: Construct, id: string, config: TfSecretRotationConfig);
    private _externalSecretRotationRoleArn?;
    get externalSecretRotationRoleArn(): string;
    set externalSecretRotationRoleArn(value: string);
    resetExternalSecretRotationRoleArn(): void;
    get externalSecretRotationRoleArnInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _rotateImmediately?;
    get rotateImmediately(): boolean | cdktn.IResolvable;
    set rotateImmediately(value: boolean | cdktn.IResolvable);
    resetRotateImmediately(): void;
    get rotateImmediatelyInput(): boolean | cdktn.IResolvable | undefined;
    private _rotationEnabled?;
    get rotationEnabled(): boolean | cdktn.IResolvable;
    set rotationEnabled(value: boolean | cdktn.IResolvable);
    resetRotationEnabled(): void;
    get rotationEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _rotationLambdaArn?;
    get rotationLambdaArn(): string;
    set rotationLambdaArn(value: string);
    resetRotationLambdaArn(): void;
    get rotationLambdaArnInput(): string | undefined;
    private _secretId?;
    get secretId(): string;
    set secretId(value: string);
    get secretIdInput(): string | undefined;
    private _externalSecretRotationMetadata;
    get externalSecretRotationMetadata(): TfSecretRotation.ExternalSecretRotationMetadataPropertyList;
    putExternalSecretRotationMetadata(value: TfSecretRotation.ExternalSecretRotationMetadataProperty[] | cdktn.IResolvable): void;
    resetExternalSecretRotationMetadata(): void;
    get externalSecretRotationMetadataInput(): cdktn.IResolvable | TfSecretRotation.ExternalSecretRotationMetadataProperty[] | undefined;
    private _rotationRules;
    get rotationRules(): TfSecretRotation.RotationRulesPropertyOutputReference;
    putRotationRules(value: TfSecretRotation.RotationRulesProperty): void;
    resetRotationRules(): void;
    get rotationRulesInput(): TfSecretRotation.RotationRulesProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfSecretRotationExternalSecretRotationMetadataPropertyToTerraform(struct?: TfSecretRotation.ExternalSecretRotationMetadataProperty | cdktn.IResolvable): any;
export declare function tfSecretRotationExternalSecretRotationMetadataPropertyToHclTerraform(struct?: TfSecretRotation.ExternalSecretRotationMetadataProperty | cdktn.IResolvable): any;
export declare function tfSecretRotationRotationRulesPropertyToTerraform(struct?: TfSecretRotation.RotationRulesPropertyOutputReference | TfSecretRotation.RotationRulesProperty): any;
export declare function tfSecretRotationRotationRulesPropertyToHclTerraform(struct?: TfSecretRotation.RotationRulesPropertyOutputReference | TfSecretRotation.RotationRulesProperty): any;
export declare namespace TfSecretRotation {
    interface ExternalSecretRotationMetadataProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/secretsmanager_secret_rotation#key TfSecretRotation#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/secretsmanager_secret_rotation#value TfSecretRotation#value}
        */
        readonly value: string;
    }
    class ExternalSecretRotationMetadataPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExternalSecretRotationMetadataProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ExternalSecretRotationMetadataProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ExternalSecretRotationMetadataPropertyList extends cdktn.ComplexList {
        internalValue?: ExternalSecretRotationMetadataProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExternalSecretRotationMetadataPropertyOutputReference;
    }
    interface RotationRulesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/secretsmanager_secret_rotation#automatically_after_days TfSecretRotation#automatically_after_days}
        */
        readonly automaticallyAfterDays?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/secretsmanager_secret_rotation#duration TfSecretRotation#duration}
        */
        readonly duration?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/secretsmanager_secret_rotation#schedule_expression TfSecretRotation#schedule_expression}
        */
        readonly scheduleExpression?: string;
    }
    class RotationRulesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RotationRulesProperty | undefined;
        set internalValue(value: RotationRulesProperty | undefined);
        private _automaticallyAfterDays?;
        get automaticallyAfterDays(): number;
        set automaticallyAfterDays(value: number);
        resetAutomaticallyAfterDays(): void;
        get automaticallyAfterDaysInput(): number | undefined;
        private _duration?;
        get duration(): string;
        set duration(value: string);
        resetDuration(): void;
        get durationInput(): string | undefined;
        private _scheduleExpression?;
        get scheduleExpression(): string;
        set scheduleExpression(value: string);
        resetScheduleExpression(): void;
        get scheduleExpressionInput(): string | undefined;
    }
}
