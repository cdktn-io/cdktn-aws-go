import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface EphemeralTfRandomPasswordConfig extends cdktn.TerraformEphemeralMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/ephemeral-resources/secretsmanager_random_password#exclude_characters EphemeralTfRandomPassword#exclude_characters}
    */
    readonly excludeCharacters?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/ephemeral-resources/secretsmanager_random_password#exclude_lowercase EphemeralTfRandomPassword#exclude_lowercase}
    */
    readonly excludeLowercase?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/ephemeral-resources/secretsmanager_random_password#exclude_numbers EphemeralTfRandomPassword#exclude_numbers}
    */
    readonly excludeNumbers?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/ephemeral-resources/secretsmanager_random_password#exclude_punctuation EphemeralTfRandomPassword#exclude_punctuation}
    */
    readonly excludePunctuation?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/ephemeral-resources/secretsmanager_random_password#exclude_uppercase EphemeralTfRandomPassword#exclude_uppercase}
    */
    readonly excludeUppercase?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/ephemeral-resources/secretsmanager_random_password#include_space EphemeralTfRandomPassword#include_space}
    */
    readonly includeSpace?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/ephemeral-resources/secretsmanager_random_password#password_length EphemeralTfRandomPassword#password_length}
    */
    readonly passwordLength?: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/ephemeral-resources/secretsmanager_random_password#region EphemeralTfRandomPassword#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/ephemeral-resources/secretsmanager_random_password#require_each_included_type EphemeralTfRandomPassword#require_each_included_type}
    */
    readonly requireEachIncludedType?: boolean | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/ephemeral-resources/secretsmanager_random_password aws_secretsmanager_random_password}
*/
export declare class EphemeralTfRandomPassword extends cdktn.TerraformEphemeralResource {
    static readonly tfResourceType = "aws_secretsmanager_random_password";
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/ephemeral-resources/secretsmanager_random_password aws_secretsmanager_random_password} Ephemeral Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EphemeralTfRandomPasswordConfig = {}
    */
    constructor(scope: Construct, id: string, config?: EphemeralTfRandomPasswordConfig);
    private _excludeCharacters?;
    get excludeCharacters(): string;
    set excludeCharacters(value: string);
    resetExcludeCharacters(): void;
    get excludeCharactersInput(): string | undefined;
    private _excludeLowercase?;
    get excludeLowercase(): boolean | cdktn.IResolvable;
    set excludeLowercase(value: boolean | cdktn.IResolvable);
    resetExcludeLowercase(): void;
    get excludeLowercaseInput(): boolean | cdktn.IResolvable | undefined;
    private _excludeNumbers?;
    get excludeNumbers(): boolean | cdktn.IResolvable;
    set excludeNumbers(value: boolean | cdktn.IResolvable);
    resetExcludeNumbers(): void;
    get excludeNumbersInput(): boolean | cdktn.IResolvable | undefined;
    private _excludePunctuation?;
    get excludePunctuation(): boolean | cdktn.IResolvable;
    set excludePunctuation(value: boolean | cdktn.IResolvable);
    resetExcludePunctuation(): void;
    get excludePunctuationInput(): boolean | cdktn.IResolvable | undefined;
    private _excludeUppercase?;
    get excludeUppercase(): boolean | cdktn.IResolvable;
    set excludeUppercase(value: boolean | cdktn.IResolvable);
    resetExcludeUppercase(): void;
    get excludeUppercaseInput(): boolean | cdktn.IResolvable | undefined;
    private _includeSpace?;
    get includeSpace(): boolean | cdktn.IResolvable;
    set includeSpace(value: boolean | cdktn.IResolvable);
    resetIncludeSpace(): void;
    get includeSpaceInput(): boolean | cdktn.IResolvable | undefined;
    private _passwordLength?;
    get passwordLength(): number;
    set passwordLength(value: number);
    resetPasswordLength(): void;
    get passwordLengthInput(): number | undefined;
    get randomPassword(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _requireEachIncludedType?;
    get requireEachIncludedType(): boolean | cdktn.IResolvable;
    set requireEachIncludedType(value: boolean | cdktn.IResolvable);
    resetRequireEachIncludedType(): void;
    get requireEachIncludedTypeInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
