import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfSecretVersionsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/secretsmanager_secret_versions#include_deprecated DataTfSecretVersions#include_deprecated}
    */
    readonly includeDeprecated?: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/secretsmanager_secret_versions#region DataTfSecretVersions#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/secretsmanager_secret_versions#secret_id DataTfSecretVersions#secret_id}
    */
    readonly secretId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/secretsmanager_secret_versions aws_secretsmanager_secret_versions}
*/
export declare class DataTfSecretVersions extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_secretsmanager_secret_versions";
    /**
    * Generates CDKTN code for importing a DataTfSecretVersions resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfSecretVersions to import
    * @param importFromId The id of the existing DataTfSecretVersions that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/secretsmanager_secret_versions#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfSecretVersions to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/secretsmanager_secret_versions aws_secretsmanager_secret_versions} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfSecretVersionsConfig
    */
    constructor(scope: Construct, id: string, config: DataTfSecretVersionsConfig);
    get arn(): string;
    private _includeDeprecated?;
    get includeDeprecated(): boolean | cdktn.IResolvable;
    set includeDeprecated(value: boolean | cdktn.IResolvable);
    resetIncludeDeprecated(): void;
    get includeDeprecatedInput(): boolean | cdktn.IResolvable | undefined;
    get name(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get secretArn(): string;
    private _secretId?;
    get secretId(): string;
    set secretId(value: string);
    get secretIdInput(): string | undefined;
    get secretName(): string;
    private _versions;
    get versions(): DataTfSecretVersions.VersionsPropertyList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfSecretVersionsVersionsPropertyToTerraform(struct?: DataTfSecretVersions.VersionsProperty): any;
export declare function dataTfSecretVersionsVersionsPropertyToHclTerraform(struct?: DataTfSecretVersions.VersionsProperty): any;
export declare namespace DataTfSecretVersions {
    interface VersionsProperty {
    }
    class VersionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VersionsProperty | undefined;
        set internalValue(value: VersionsProperty | undefined);
        get createdTime(): string;
        get lastAccessedDate(): string;
        get versionId(): string;
        get versionStages(): string[];
    }
    class VersionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VersionsPropertyOutputReference;
    }
}
