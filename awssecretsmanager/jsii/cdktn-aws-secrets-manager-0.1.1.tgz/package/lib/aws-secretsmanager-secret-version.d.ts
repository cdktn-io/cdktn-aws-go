import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSecretsmanagerSecretVersionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/secretsmanager_secret_version#id AwsSecretsmanagerSecretVersion#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/secretsmanager_secret_version#region AwsSecretsmanagerSecretVersion#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/secretsmanager_secret_version#secret_binary AwsSecretsmanagerSecretVersion#secret_binary}
    */
    readonly secretBinary?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/secretsmanager_secret_version#secret_id AwsSecretsmanagerSecretVersion#secret_id}
    */
    readonly secretId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/secretsmanager_secret_version#secret_string AwsSecretsmanagerSecretVersion#secret_string}
    */
    readonly secretString?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/secretsmanager_secret_version#secret_string_wo AwsSecretsmanagerSecretVersion#secret_string_wo}
    */
    readonly secretStringWo?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/secretsmanager_secret_version#secret_string_wo_version AwsSecretsmanagerSecretVersion#secret_string_wo_version}
    */
    readonly secretStringWoVersion?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/secretsmanager_secret_version#version_stages AwsSecretsmanagerSecretVersion#version_stages}
    */
    readonly versionStages?: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/secretsmanager_secret_version aws_secretsmanager_secret_version}
*/
export declare class AwsSecretsmanagerSecretVersion extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_secretsmanager_secret_version";
    /**
    * Generates CDKTN code for importing a AwsSecretsmanagerSecretVersion resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSecretsmanagerSecretVersion to import
    * @param importFromId The id of the existing AwsSecretsmanagerSecretVersion that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/secretsmanager_secret_version#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSecretsmanagerSecretVersion to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/secretsmanager_secret_version aws_secretsmanager_secret_version} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSecretsmanagerSecretVersionConfig
    */
    constructor(scope: Construct, id: string, config: AwsSecretsmanagerSecretVersionConfig);
    get arn(): string;
    get hasSecretStringWo(): cdktn.IResolvable;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get secretArn(): string;
    private _secretBinary?;
    get secretBinary(): string;
    set secretBinary(value: string);
    resetSecretBinary(): void;
    get secretBinaryInput(): string | undefined;
    private _secretId?;
    get secretId(): string;
    set secretId(value: string);
    get secretIdInput(): string | undefined;
    private _secretString?;
    get secretString(): string;
    set secretString(value: string);
    resetSecretString(): void;
    get secretStringInput(): string | undefined;
    private _secretStringWo?;
    /**
    * @deprecated Write-only: the provider never returns this value; reading it always yields null by protocol contract. The getter remains for compatibility and will be removed in a future prebuilt-provider major.
    */
    get secretStringWo(): string;
    set secretStringWo(value: string);
    resetSecretStringWo(): void;
    get secretStringWoInput(): string | undefined;
    private _secretStringWoVersion?;
    get secretStringWoVersion(): number;
    set secretStringWoVersion(value: number);
    resetSecretStringWoVersion(): void;
    get secretStringWoVersionInput(): number | undefined;
    get versionId(): string;
    private _versionStages?;
    get versionStages(): string[];
    set versionStages(value: string[]);
    resetVersionStages(): void;
    get versionStagesInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
