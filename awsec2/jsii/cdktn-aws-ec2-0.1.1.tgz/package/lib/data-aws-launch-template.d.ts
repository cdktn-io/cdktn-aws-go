import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsLaunchTemplateConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/launch_template#id DataAwsLaunchTemplate#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/launch_template#name DataAwsLaunchTemplate#name}
    */
    readonly name?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/launch_template#region DataAwsLaunchTemplate#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/launch_template#tags DataAwsLaunchTemplate#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/launch_template#filter DataAwsLaunchTemplate#filter}
    */
    readonly filter?: DataAwsLaunchTemplate.FilterProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/launch_template#timeouts DataAwsLaunchTemplate#timeouts}
    */
    readonly timeouts?: DataAwsLaunchTemplate.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/launch_template aws_launch_template}
*/
export declare class DataAwsLaunchTemplate extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_launch_template";
    /**
    * Generates CDKTN code for importing a DataAwsLaunchTemplate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsLaunchTemplate to import
    * @param importFromId The id of the existing DataAwsLaunchTemplate that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/launch_template#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsLaunchTemplate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/launch_template aws_launch_template} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsLaunchTemplateConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsLaunchTemplateConfig);
    get arn(): string;
    private _blockDeviceMappings;
    get blockDeviceMappings(): DataAwsLaunchTemplate.BlockDeviceMappingsPropertyList;
    private _capacityReservationSpecification;
    get capacityReservationSpecification(): DataAwsLaunchTemplate.CapacityReservationSpecificationPropertyList;
    private _cpuOptions;
    get cpuOptions(): DataAwsLaunchTemplate.CpuOptionsPropertyList;
    private _creditSpecification;
    get creditSpecification(): DataAwsLaunchTemplate.CreditSpecificationPropertyList;
    get defaultVersion(): number;
    get description(): string;
    get disableApiStop(): cdktn.IResolvable;
    get disableApiTermination(): cdktn.IResolvable;
    get ebsOptimized(): string;
    private _enclaveOptions;
    get enclaveOptions(): DataAwsLaunchTemplate.EnclaveOptionsPropertyList;
    private _hibernationOptions;
    get hibernationOptions(): DataAwsLaunchTemplate.HibernationOptionsPropertyList;
    private _iamInstanceProfile;
    get iamInstanceProfile(): DataAwsLaunchTemplate.IamInstanceProfilePropertyList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get imageId(): string;
    get instanceInitiatedShutdownBehavior(): string;
    private _instanceMarketOptions;
    get instanceMarketOptions(): DataAwsLaunchTemplate.InstanceMarketOptionsPropertyList;
    private _instanceRequirements;
    get instanceRequirements(): DataAwsLaunchTemplate.InstanceRequirementsPropertyList;
    get instanceType(): string;
    get kernelId(): string;
    get keyName(): string;
    get latestVersion(): number;
    private _licenseSpecification;
    get licenseSpecification(): DataAwsLaunchTemplate.LicenseSpecificationPropertyList;
    private _maintenanceOptions;
    get maintenanceOptions(): DataAwsLaunchTemplate.MaintenanceOptionsPropertyList;
    private _metadataOptions;
    get metadataOptions(): DataAwsLaunchTemplate.MetadataOptionsPropertyList;
    private _monitoring;
    get monitoring(): DataAwsLaunchTemplate.MonitoringPropertyList;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _networkInterfaces;
    get networkInterfaces(): DataAwsLaunchTemplate.NetworkInterfacesPropertyList;
    private _networkPerformanceOptions;
    get networkPerformanceOptions(): DataAwsLaunchTemplate.NetworkPerformanceOptionsPropertyList;
    private _placement;
    get placement(): DataAwsLaunchTemplate.PlacementPropertyList;
    private _privateDnsNameOptions;
    get privateDnsNameOptions(): DataAwsLaunchTemplate.PrivateDnsNameOptionsPropertyList;
    get ramDiskId(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _secondaryInterfaces;
    get secondaryInterfaces(): DataAwsLaunchTemplate.SecondaryInterfacesPropertyList;
    get securityGroupNames(): string[];
    private _tagSpecifications;
    get tagSpecifications(): DataAwsLaunchTemplate.TagSpecificationsPropertyList;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    get userData(): string;
    get vpcSecurityGroupIds(): string[];
    private _filter;
    get filter(): DataAwsLaunchTemplate.FilterPropertyList;
    putFilter(value: DataAwsLaunchTemplate.FilterProperty[] | cdktn.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataAwsLaunchTemplate.FilterProperty[] | undefined;
    private _timeouts;
    get timeouts(): DataAwsLaunchTemplate.TimeoutsPropertyOutputReference;
    putTimeouts(value: DataAwsLaunchTemplate.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAwsLaunchTemplate.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsLaunchTemplateEbsPropertyToTerraform(struct?: DataAwsLaunchTemplate.EbsProperty): any;
export declare function dataAwsLaunchTemplateEbsPropertyToHclTerraform(struct?: DataAwsLaunchTemplate.EbsProperty): any;
export declare function dataAwsLaunchTemplateBlockDeviceMappingsPropertyToTerraform(struct?: DataAwsLaunchTemplate.BlockDeviceMappingsProperty): any;
export declare function dataAwsLaunchTemplateBlockDeviceMappingsPropertyToHclTerraform(struct?: DataAwsLaunchTemplate.BlockDeviceMappingsProperty): any;
export declare function dataAwsLaunchTemplateCapacityReservationTargetPropertyToTerraform(struct?: DataAwsLaunchTemplate.CapacityReservationTargetProperty): any;
export declare function dataAwsLaunchTemplateCapacityReservationTargetPropertyToHclTerraform(struct?: DataAwsLaunchTemplate.CapacityReservationTargetProperty): any;
export declare function dataAwsLaunchTemplateCapacityReservationSpecificationPropertyToTerraform(struct?: DataAwsLaunchTemplate.CapacityReservationSpecificationProperty): any;
export declare function dataAwsLaunchTemplateCapacityReservationSpecificationPropertyToHclTerraform(struct?: DataAwsLaunchTemplate.CapacityReservationSpecificationProperty): any;
export declare function dataAwsLaunchTemplateCpuOptionsPropertyToTerraform(struct?: DataAwsLaunchTemplate.CpuOptionsProperty): any;
export declare function dataAwsLaunchTemplateCpuOptionsPropertyToHclTerraform(struct?: DataAwsLaunchTemplate.CpuOptionsProperty): any;
export declare function dataAwsLaunchTemplateCreditSpecificationPropertyToTerraform(struct?: DataAwsLaunchTemplate.CreditSpecificationProperty): any;
export declare function dataAwsLaunchTemplateCreditSpecificationPropertyToHclTerraform(struct?: DataAwsLaunchTemplate.CreditSpecificationProperty): any;
export declare function dataAwsLaunchTemplateEnclaveOptionsPropertyToTerraform(struct?: DataAwsLaunchTemplate.EnclaveOptionsProperty): any;
export declare function dataAwsLaunchTemplateEnclaveOptionsPropertyToHclTerraform(struct?: DataAwsLaunchTemplate.EnclaveOptionsProperty): any;
export declare function dataAwsLaunchTemplateHibernationOptionsPropertyToTerraform(struct?: DataAwsLaunchTemplate.HibernationOptionsProperty): any;
export declare function dataAwsLaunchTemplateHibernationOptionsPropertyToHclTerraform(struct?: DataAwsLaunchTemplate.HibernationOptionsProperty): any;
export declare function dataAwsLaunchTemplateIamInstanceProfilePropertyToTerraform(struct?: DataAwsLaunchTemplate.IamInstanceProfileProperty): any;
export declare function dataAwsLaunchTemplateIamInstanceProfilePropertyToHclTerraform(struct?: DataAwsLaunchTemplate.IamInstanceProfileProperty): any;
export declare function dataAwsLaunchTemplateSpotOptionsPropertyToTerraform(struct?: DataAwsLaunchTemplate.SpotOptionsProperty): any;
export declare function dataAwsLaunchTemplateSpotOptionsPropertyToHclTerraform(struct?: DataAwsLaunchTemplate.SpotOptionsProperty): any;
export declare function dataAwsLaunchTemplateInstanceMarketOptionsPropertyToTerraform(struct?: DataAwsLaunchTemplate.InstanceMarketOptionsProperty): any;
export declare function dataAwsLaunchTemplateInstanceMarketOptionsPropertyToHclTerraform(struct?: DataAwsLaunchTemplate.InstanceMarketOptionsProperty): any;
export declare function dataAwsLaunchTemplateAcceleratorCountPropertyToTerraform(struct?: DataAwsLaunchTemplate.AcceleratorCountProperty): any;
export declare function dataAwsLaunchTemplateAcceleratorCountPropertyToHclTerraform(struct?: DataAwsLaunchTemplate.AcceleratorCountProperty): any;
export declare function dataAwsLaunchTemplateAcceleratorTotalMemoryMibPropertyToTerraform(struct?: DataAwsLaunchTemplate.AcceleratorTotalMemoryMibProperty): any;
export declare function dataAwsLaunchTemplateAcceleratorTotalMemoryMibPropertyToHclTerraform(struct?: DataAwsLaunchTemplate.AcceleratorTotalMemoryMibProperty): any;
export declare function dataAwsLaunchTemplateBaselineEbsBandwidthMbpsPropertyToTerraform(struct?: DataAwsLaunchTemplate.BaselineEbsBandwidthMbpsProperty): any;
export declare function dataAwsLaunchTemplateBaselineEbsBandwidthMbpsPropertyToHclTerraform(struct?: DataAwsLaunchTemplate.BaselineEbsBandwidthMbpsProperty): any;
export declare function dataAwsLaunchTemplateMemoryGibPerVcpuPropertyToTerraform(struct?: DataAwsLaunchTemplate.MemoryGibPerVcpuProperty): any;
export declare function dataAwsLaunchTemplateMemoryGibPerVcpuPropertyToHclTerraform(struct?: DataAwsLaunchTemplate.MemoryGibPerVcpuProperty): any;
export declare function dataAwsLaunchTemplateMemoryMibPropertyToTerraform(struct?: DataAwsLaunchTemplate.MemoryMibProperty): any;
export declare function dataAwsLaunchTemplateMemoryMibPropertyToHclTerraform(struct?: DataAwsLaunchTemplate.MemoryMibProperty): any;
export declare function dataAwsLaunchTemplateNetworkBandwidthGbpsPropertyToTerraform(struct?: DataAwsLaunchTemplate.NetworkBandwidthGbpsProperty): any;
export declare function dataAwsLaunchTemplateNetworkBandwidthGbpsPropertyToHclTerraform(struct?: DataAwsLaunchTemplate.NetworkBandwidthGbpsProperty): any;
export declare function dataAwsLaunchTemplateNetworkInterfaceCountPropertyToTerraform(struct?: DataAwsLaunchTemplate.NetworkInterfaceCountProperty): any;
export declare function dataAwsLaunchTemplateNetworkInterfaceCountPropertyToHclTerraform(struct?: DataAwsLaunchTemplate.NetworkInterfaceCountProperty): any;
export declare function dataAwsLaunchTemplateTotalLocalStorageGbPropertyToTerraform(struct?: DataAwsLaunchTemplate.TotalLocalStorageGbProperty): any;
export declare function dataAwsLaunchTemplateTotalLocalStorageGbPropertyToHclTerraform(struct?: DataAwsLaunchTemplate.TotalLocalStorageGbProperty): any;
export declare function dataAwsLaunchTemplateVcpuCountPropertyToTerraform(struct?: DataAwsLaunchTemplate.VcpuCountProperty): any;
export declare function dataAwsLaunchTemplateVcpuCountPropertyToHclTerraform(struct?: DataAwsLaunchTemplate.VcpuCountProperty): any;
export declare function dataAwsLaunchTemplateInstanceRequirementsPropertyToTerraform(struct?: DataAwsLaunchTemplate.InstanceRequirementsProperty): any;
export declare function dataAwsLaunchTemplateInstanceRequirementsPropertyToHclTerraform(struct?: DataAwsLaunchTemplate.InstanceRequirementsProperty): any;
export declare function dataAwsLaunchTemplateLicenseSpecificationPropertyToTerraform(struct?: DataAwsLaunchTemplate.LicenseSpecificationProperty): any;
export declare function dataAwsLaunchTemplateLicenseSpecificationPropertyToHclTerraform(struct?: DataAwsLaunchTemplate.LicenseSpecificationProperty): any;
export declare function dataAwsLaunchTemplateMaintenanceOptionsPropertyToTerraform(struct?: DataAwsLaunchTemplate.MaintenanceOptionsProperty): any;
export declare function dataAwsLaunchTemplateMaintenanceOptionsPropertyToHclTerraform(struct?: DataAwsLaunchTemplate.MaintenanceOptionsProperty): any;
export declare function dataAwsLaunchTemplateMetadataOptionsPropertyToTerraform(struct?: DataAwsLaunchTemplate.MetadataOptionsProperty): any;
export declare function dataAwsLaunchTemplateMetadataOptionsPropertyToHclTerraform(struct?: DataAwsLaunchTemplate.MetadataOptionsProperty): any;
export declare function dataAwsLaunchTemplateMonitoringPropertyToTerraform(struct?: DataAwsLaunchTemplate.MonitoringProperty): any;
export declare function dataAwsLaunchTemplateMonitoringPropertyToHclTerraform(struct?: DataAwsLaunchTemplate.MonitoringProperty): any;
export declare function dataAwsLaunchTemplateConnectionTrackingSpecificationPropertyToTerraform(struct?: DataAwsLaunchTemplate.ConnectionTrackingSpecificationProperty): any;
export declare function dataAwsLaunchTemplateConnectionTrackingSpecificationPropertyToHclTerraform(struct?: DataAwsLaunchTemplate.ConnectionTrackingSpecificationProperty): any;
export declare function dataAwsLaunchTemplateNetworkInterfacesPropertyToTerraform(struct?: DataAwsLaunchTemplate.NetworkInterfacesProperty): any;
export declare function dataAwsLaunchTemplateNetworkInterfacesPropertyToHclTerraform(struct?: DataAwsLaunchTemplate.NetworkInterfacesProperty): any;
export declare function dataAwsLaunchTemplateNetworkPerformanceOptionsPropertyToTerraform(struct?: DataAwsLaunchTemplate.NetworkPerformanceOptionsProperty): any;
export declare function dataAwsLaunchTemplateNetworkPerformanceOptionsPropertyToHclTerraform(struct?: DataAwsLaunchTemplate.NetworkPerformanceOptionsProperty): any;
export declare function dataAwsLaunchTemplatePlacementPropertyToTerraform(struct?: DataAwsLaunchTemplate.PlacementProperty): any;
export declare function dataAwsLaunchTemplatePlacementPropertyToHclTerraform(struct?: DataAwsLaunchTemplate.PlacementProperty): any;
export declare function dataAwsLaunchTemplatePrivateDnsNameOptionsPropertyToTerraform(struct?: DataAwsLaunchTemplate.PrivateDnsNameOptionsProperty): any;
export declare function dataAwsLaunchTemplatePrivateDnsNameOptionsPropertyToHclTerraform(struct?: DataAwsLaunchTemplate.PrivateDnsNameOptionsProperty): any;
export declare function dataAwsLaunchTemplateSecondaryInterfacesPropertyToTerraform(struct?: DataAwsLaunchTemplate.SecondaryInterfacesProperty): any;
export declare function dataAwsLaunchTemplateSecondaryInterfacesPropertyToHclTerraform(struct?: DataAwsLaunchTemplate.SecondaryInterfacesProperty): any;
export declare function dataAwsLaunchTemplateTagSpecificationsPropertyToTerraform(struct?: DataAwsLaunchTemplate.TagSpecificationsProperty): any;
export declare function dataAwsLaunchTemplateTagSpecificationsPropertyToHclTerraform(struct?: DataAwsLaunchTemplate.TagSpecificationsProperty): any;
export declare function dataAwsLaunchTemplateFilterPropertyToTerraform(struct?: DataAwsLaunchTemplate.FilterProperty | cdktn.IResolvable): any;
export declare function dataAwsLaunchTemplateFilterPropertyToHclTerraform(struct?: DataAwsLaunchTemplate.FilterProperty | cdktn.IResolvable): any;
export declare function dataAwsLaunchTemplateTimeoutsPropertyToTerraform(struct?: DataAwsLaunchTemplate.TimeoutsProperty | cdktn.IResolvable): any;
export declare function dataAwsLaunchTemplateTimeoutsPropertyToHclTerraform(struct?: DataAwsLaunchTemplate.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace DataAwsLaunchTemplate {
    interface EbsProperty {
    }
    class EbsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EbsProperty | undefined;
        set internalValue(value: EbsProperty | undefined);
        get deleteOnTermination(): string;
        get encrypted(): string;
        get iops(): number;
        get kmsKeyId(): string;
        get snapshotId(): string;
        get throughput(): number;
        get volumeInitializationRate(): number;
        get volumeSize(): number;
        get volumeType(): string;
    }
    class EbsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EbsPropertyOutputReference;
    }
    interface BlockDeviceMappingsProperty {
    }
    class BlockDeviceMappingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BlockDeviceMappingsProperty | undefined;
        set internalValue(value: BlockDeviceMappingsProperty | undefined);
        get deviceName(): string;
        private _ebs;
        get ebs(): EbsPropertyList;
        get noDevice(): string;
        get virtualName(): string;
    }
    class BlockDeviceMappingsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BlockDeviceMappingsPropertyOutputReference;
    }
    interface CapacityReservationTargetProperty {
    }
    class CapacityReservationTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CapacityReservationTargetProperty | undefined;
        set internalValue(value: CapacityReservationTargetProperty | undefined);
        get capacityReservationId(): string;
        get capacityReservationResourceGroupArn(): string;
    }
    class CapacityReservationTargetPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CapacityReservationTargetPropertyOutputReference;
    }
    interface CapacityReservationSpecificationProperty {
    }
    class CapacityReservationSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CapacityReservationSpecificationProperty | undefined;
        set internalValue(value: CapacityReservationSpecificationProperty | undefined);
        get capacityReservationPreference(): string;
        private _capacityReservationTarget;
        get capacityReservationTarget(): CapacityReservationTargetPropertyList;
    }
    class CapacityReservationSpecificationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CapacityReservationSpecificationPropertyOutputReference;
    }
    interface CpuOptionsProperty {
    }
    class CpuOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CpuOptionsProperty | undefined;
        set internalValue(value: CpuOptionsProperty | undefined);
        get amdSevSnp(): string;
        get coreCount(): number;
        get nestedVirtualization(): string;
        get threadsPerCore(): number;
    }
    class CpuOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CpuOptionsPropertyOutputReference;
    }
    interface CreditSpecificationProperty {
    }
    class CreditSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CreditSpecificationProperty | undefined;
        set internalValue(value: CreditSpecificationProperty | undefined);
        get cpuCredits(): string;
    }
    class CreditSpecificationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CreditSpecificationPropertyOutputReference;
    }
    interface EnclaveOptionsProperty {
    }
    class EnclaveOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EnclaveOptionsProperty | undefined;
        set internalValue(value: EnclaveOptionsProperty | undefined);
        get enabled(): cdktn.IResolvable;
    }
    class EnclaveOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EnclaveOptionsPropertyOutputReference;
    }
    interface HibernationOptionsProperty {
    }
    class HibernationOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HibernationOptionsProperty | undefined;
        set internalValue(value: HibernationOptionsProperty | undefined);
        get configured(): cdktn.IResolvable;
    }
    class HibernationOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HibernationOptionsPropertyOutputReference;
    }
    interface IamInstanceProfileProperty {
    }
    class IamInstanceProfilePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IamInstanceProfileProperty | undefined;
        set internalValue(value: IamInstanceProfileProperty | undefined);
        get arn(): string;
        get name(): string;
    }
    class IamInstanceProfilePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IamInstanceProfilePropertyOutputReference;
    }
    interface SpotOptionsProperty {
    }
    class SpotOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpotOptionsProperty | undefined;
        set internalValue(value: SpotOptionsProperty | undefined);
        get blockDurationMinutes(): number;
        get instanceInterruptionBehavior(): string;
        get maxPrice(): string;
        get spotInstanceType(): string;
        get validUntil(): string;
    }
    class SpotOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpotOptionsPropertyOutputReference;
    }
    interface InstanceMarketOptionsProperty {
    }
    class InstanceMarketOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InstanceMarketOptionsProperty | undefined;
        set internalValue(value: InstanceMarketOptionsProperty | undefined);
        get marketType(): string;
        private _spotOptions;
        get spotOptions(): SpotOptionsPropertyList;
    }
    class InstanceMarketOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InstanceMarketOptionsPropertyOutputReference;
    }
    interface AcceleratorCountProperty {
    }
    class AcceleratorCountPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AcceleratorCountProperty | undefined;
        set internalValue(value: AcceleratorCountProperty | undefined);
        get max(): number;
        get min(): number;
    }
    class AcceleratorCountPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AcceleratorCountPropertyOutputReference;
    }
    interface AcceleratorTotalMemoryMibProperty {
    }
    class AcceleratorTotalMemoryMibPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AcceleratorTotalMemoryMibProperty | undefined;
        set internalValue(value: AcceleratorTotalMemoryMibProperty | undefined);
        get max(): number;
        get min(): number;
    }
    class AcceleratorTotalMemoryMibPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AcceleratorTotalMemoryMibPropertyOutputReference;
    }
    interface BaselineEbsBandwidthMbpsProperty {
    }
    class BaselineEbsBandwidthMbpsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BaselineEbsBandwidthMbpsProperty | undefined;
        set internalValue(value: BaselineEbsBandwidthMbpsProperty | undefined);
        get max(): number;
        get min(): number;
    }
    class BaselineEbsBandwidthMbpsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BaselineEbsBandwidthMbpsPropertyOutputReference;
    }
    interface MemoryGibPerVcpuProperty {
    }
    class MemoryGibPerVcpuPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MemoryGibPerVcpuProperty | undefined;
        set internalValue(value: MemoryGibPerVcpuProperty | undefined);
        get max(): number;
        get min(): number;
    }
    class MemoryGibPerVcpuPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MemoryGibPerVcpuPropertyOutputReference;
    }
    interface MemoryMibProperty {
    }
    class MemoryMibPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MemoryMibProperty | undefined;
        set internalValue(value: MemoryMibProperty | undefined);
        get max(): number;
        get min(): number;
    }
    class MemoryMibPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MemoryMibPropertyOutputReference;
    }
    interface NetworkBandwidthGbpsProperty {
    }
    class NetworkBandwidthGbpsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NetworkBandwidthGbpsProperty | undefined;
        set internalValue(value: NetworkBandwidthGbpsProperty | undefined);
        get max(): number;
        get min(): number;
    }
    class NetworkBandwidthGbpsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NetworkBandwidthGbpsPropertyOutputReference;
    }
    interface NetworkInterfaceCountProperty {
    }
    class NetworkInterfaceCountPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NetworkInterfaceCountProperty | undefined;
        set internalValue(value: NetworkInterfaceCountProperty | undefined);
        get max(): number;
        get min(): number;
    }
    class NetworkInterfaceCountPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NetworkInterfaceCountPropertyOutputReference;
    }
    interface TotalLocalStorageGbProperty {
    }
    class TotalLocalStorageGbPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TotalLocalStorageGbProperty | undefined;
        set internalValue(value: TotalLocalStorageGbProperty | undefined);
        get max(): number;
        get min(): number;
    }
    class TotalLocalStorageGbPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TotalLocalStorageGbPropertyOutputReference;
    }
    interface VcpuCountProperty {
    }
    class VcpuCountPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VcpuCountProperty | undefined;
        set internalValue(value: VcpuCountProperty | undefined);
        get max(): number;
        get min(): number;
    }
    class VcpuCountPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VcpuCountPropertyOutputReference;
    }
    interface InstanceRequirementsProperty {
    }
    class InstanceRequirementsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InstanceRequirementsProperty | undefined;
        set internalValue(value: InstanceRequirementsProperty | undefined);
        private _acceleratorCount;
        get acceleratorCount(): AcceleratorCountPropertyList;
        get acceleratorManufacturers(): string[];
        get acceleratorNames(): string[];
        private _acceleratorTotalMemoryMib;
        get acceleratorTotalMemoryMib(): AcceleratorTotalMemoryMibPropertyList;
        get acceleratorTypes(): string[];
        get allowedInstanceTypes(): string[];
        get bareMetal(): string;
        private _baselineEbsBandwidthMbps;
        get baselineEbsBandwidthMbps(): BaselineEbsBandwidthMbpsPropertyList;
        get burstablePerformance(): string;
        get cpuManufacturers(): string[];
        get excludedInstanceTypes(): string[];
        get instanceGenerations(): string[];
        get localStorage(): string;
        get localStorageTypes(): string[];
        get maxSpotPriceAsPercentageOfOptimalOnDemandPrice(): number;
        private _memoryGibPerVcpu;
        get memoryGibPerVcpu(): MemoryGibPerVcpuPropertyList;
        private _memoryMib;
        get memoryMib(): MemoryMibPropertyList;
        private _networkBandwidthGbps;
        get networkBandwidthGbps(): NetworkBandwidthGbpsPropertyList;
        private _networkInterfaceCount;
        get networkInterfaceCount(): NetworkInterfaceCountPropertyList;
        get onDemandMaxPricePercentageOverLowestPrice(): number;
        get requireHibernateSupport(): cdktn.IResolvable;
        get spotMaxPricePercentageOverLowestPrice(): number;
        private _totalLocalStorageGb;
        get totalLocalStorageGb(): TotalLocalStorageGbPropertyList;
        private _vcpuCount;
        get vcpuCount(): VcpuCountPropertyList;
    }
    class InstanceRequirementsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InstanceRequirementsPropertyOutputReference;
    }
    interface LicenseSpecificationProperty {
    }
    class LicenseSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LicenseSpecificationProperty | undefined;
        set internalValue(value: LicenseSpecificationProperty | undefined);
        get licenseConfigurationArn(): string;
    }
    class LicenseSpecificationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LicenseSpecificationPropertyOutputReference;
    }
    interface MaintenanceOptionsProperty {
    }
    class MaintenanceOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MaintenanceOptionsProperty | undefined;
        set internalValue(value: MaintenanceOptionsProperty | undefined);
        get autoRecovery(): string;
    }
    class MaintenanceOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MaintenanceOptionsPropertyOutputReference;
    }
    interface MetadataOptionsProperty {
    }
    class MetadataOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MetadataOptionsProperty | undefined;
        set internalValue(value: MetadataOptionsProperty | undefined);
        get httpEndpoint(): string;
        get httpProtocolIpv6(): string;
        get httpPutResponseHopLimit(): number;
        get httpTokens(): string;
        get instanceMetadataTags(): string;
    }
    class MetadataOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MetadataOptionsPropertyOutputReference;
    }
    interface MonitoringProperty {
    }
    class MonitoringPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MonitoringProperty | undefined;
        set internalValue(value: MonitoringProperty | undefined);
        get enabled(): cdktn.IResolvable;
    }
    class MonitoringPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MonitoringPropertyOutputReference;
    }
    interface ConnectionTrackingSpecificationProperty {
    }
    class ConnectionTrackingSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConnectionTrackingSpecificationProperty | undefined;
        set internalValue(value: ConnectionTrackingSpecificationProperty | undefined);
        get tcpEstablishedTimeout(): number;
        get udpStreamTimeout(): number;
        get udpTimeout(): number;
    }
    class ConnectionTrackingSpecificationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConnectionTrackingSpecificationPropertyOutputReference;
    }
    interface NetworkInterfacesProperty {
    }
    class NetworkInterfacesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NetworkInterfacesProperty | undefined;
        set internalValue(value: NetworkInterfacesProperty | undefined);
        get associateCarrierIpAddress(): string;
        get associatePublicIpAddress(): string;
        private _connectionTrackingSpecification;
        get connectionTrackingSpecification(): ConnectionTrackingSpecificationPropertyList;
        get deleteOnTermination(): string;
        get description(): string;
        get deviceIndex(): number;
        get enaQueueCount(): number;
        get interfaceType(): string;
        get ipv4AddressCount(): number;
        get ipv4Addresses(): string[];
        get ipv4PrefixCount(): number;
        get ipv4Prefixes(): string[];
        get ipv6AddressCount(): number;
        get ipv6Addresses(): string[];
        get ipv6PrefixCount(): number;
        get ipv6Prefixes(): string[];
        get networkCardIndex(): number;
        get networkInterfaceId(): string;
        get primaryIpv6(): string;
        get privateIpAddress(): string;
        get securityGroups(): string[];
        get subnetId(): string;
    }
    class NetworkInterfacesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NetworkInterfacesPropertyOutputReference;
    }
    interface NetworkPerformanceOptionsProperty {
    }
    class NetworkPerformanceOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NetworkPerformanceOptionsProperty | undefined;
        set internalValue(value: NetworkPerformanceOptionsProperty | undefined);
        get bandwidthWeighting(): string;
    }
    class NetworkPerformanceOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NetworkPerformanceOptionsPropertyOutputReference;
    }
    interface PlacementProperty {
    }
    class PlacementPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PlacementProperty | undefined;
        set internalValue(value: PlacementProperty | undefined);
        get affinity(): string;
        get availabilityZone(): string;
        get groupId(): string;
        get groupName(): string;
        get hostId(): string;
        get hostResourceGroupArn(): string;
        get partitionNumber(): number;
        get spreadDomain(): string;
        get tenancy(): string;
    }
    class PlacementPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PlacementPropertyOutputReference;
    }
    interface PrivateDnsNameOptionsProperty {
    }
    class PrivateDnsNameOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PrivateDnsNameOptionsProperty | undefined;
        set internalValue(value: PrivateDnsNameOptionsProperty | undefined);
        get enableResourceNameDnsARecord(): cdktn.IResolvable;
        get enableResourceNameDnsAaaaRecord(): cdktn.IResolvable;
        get hostnameType(): string;
    }
    class PrivateDnsNameOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PrivateDnsNameOptionsPropertyOutputReference;
    }
    interface SecondaryInterfacesProperty {
    }
    class SecondaryInterfacesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SecondaryInterfacesProperty | undefined;
        set internalValue(value: SecondaryInterfacesProperty | undefined);
        get deleteOnTermination(): cdktn.IResolvable;
        get deviceIndex(): number;
        get interfaceType(): string;
        get networkCardIndex(): number;
        get privateIpAddressCount(): number;
        get privateIpAddresses(): string[];
        get secondarySubnetId(): string;
    }
    class SecondaryInterfacesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SecondaryInterfacesPropertyOutputReference;
    }
    interface TagSpecificationsProperty {
    }
    class TagSpecificationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TagSpecificationsProperty | undefined;
        set internalValue(value: TagSpecificationsProperty | undefined);
        get resourceType(): string;
        private _tags;
        get tags(): cdktn.StringMap;
    }
    class TagSpecificationsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TagSpecificationsPropertyOutputReference;
    }
    interface FilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/launch_template#name DataAwsLaunchTemplate#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/launch_template#values DataAwsLaunchTemplate#values}
        */
        readonly values: string[];
    }
    class FilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FilterProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class FilterPropertyList extends cdktn.ComplexList {
        internalValue?: FilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/launch_template#read DataAwsLaunchTemplate#read}
        */
        readonly read?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _read?;
        get read(): string;
        set read(value: string);
        resetRead(): void;
        get readInput(): string | undefined;
    }
}
