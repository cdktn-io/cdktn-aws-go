import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsInstanceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#ami AwsInstance#ami}
    */
    readonly ami?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#associate_public_ip_address AwsInstance#associate_public_ip_address}
    */
    readonly associatePublicIpAddress?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#availability_zone AwsInstance#availability_zone}
    */
    readonly availabilityZone?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#disable_api_stop AwsInstance#disable_api_stop}
    */
    readonly disableApiStop?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#disable_api_termination AwsInstance#disable_api_termination}
    */
    readonly disableApiTermination?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#ebs_optimized AwsInstance#ebs_optimized}
    */
    readonly ebsOptimized?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#enable_primary_ipv6 AwsInstance#enable_primary_ipv6}
    */
    readonly enablePrimaryIpv6?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#force_destroy AwsInstance#force_destroy}
    */
    readonly forceDestroy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#get_password_data AwsInstance#get_password_data}
    */
    readonly fetchPasswordData?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#hibernation AwsInstance#hibernation}
    */
    readonly hibernation?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#host_id AwsInstance#host_id}
    */
    readonly hostId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#host_resource_group_arn AwsInstance#host_resource_group_arn}
    */
    readonly hostResourceGroupArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#iam_instance_profile AwsInstance#iam_instance_profile}
    */
    readonly iamInstanceProfile?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#id AwsInstance#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#instance_initiated_shutdown_behavior AwsInstance#instance_initiated_shutdown_behavior}
    */
    readonly instanceInitiatedShutdownBehavior?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#instance_type AwsInstance#instance_type}
    */
    readonly instanceType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#ipv6_address_count AwsInstance#ipv6_address_count}
    */
    readonly ipv6AddressCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#ipv6_addresses AwsInstance#ipv6_addresses}
    */
    readonly ipv6Addresses?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#key_name AwsInstance#key_name}
    */
    readonly keyName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#monitoring AwsInstance#monitoring}
    */
    readonly monitoring?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#placement_group AwsInstance#placement_group}
    */
    readonly placementGroup?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#placement_group_id AwsInstance#placement_group_id}
    */
    readonly placementGroupId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#placement_partition_number AwsInstance#placement_partition_number}
    */
    readonly placementPartitionNumber?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#private_ip AwsInstance#private_ip}
    */
    readonly privateIp?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#region AwsInstance#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#secondary_private_ips AwsInstance#secondary_private_ips}
    */
    readonly secondaryPrivateIps?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#security_groups AwsInstance#security_groups}
    */
    readonly securityGroups?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#source_dest_check AwsInstance#source_dest_check}
    */
    readonly sourceDestCheck?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#subnet_id AwsInstance#subnet_id}
    */
    readonly subnetId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#tags AwsInstance#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#tags_all AwsInstance#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#tenancy AwsInstance#tenancy}
    */
    readonly tenancy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#user_data AwsInstance#user_data}
    */
    readonly userData?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#user_data_base64 AwsInstance#user_data_base64}
    */
    readonly userDataBase64?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#user_data_replace_on_change AwsInstance#user_data_replace_on_change}
    */
    readonly userDataReplaceOnChange?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#volume_tags AwsInstance#volume_tags}
    */
    readonly volumeTags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#vpc_security_group_ids AwsInstance#vpc_security_group_ids}
    */
    readonly vpcSecurityGroupIds?: string[];
    /**
    * capacity_reservation_specification block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#capacity_reservation_specification AwsInstance#capacity_reservation_specification}
    */
    readonly capacityReservationSpecification?: AwsInstance.CapacityReservationSpecificationProperty;
    /**
    * cpu_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#cpu_options AwsInstance#cpu_options}
    */
    readonly cpuOptions?: AwsInstance.CpuOptionsProperty;
    /**
    * credit_specification block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#credit_specification AwsInstance#credit_specification}
    */
    readonly creditSpecification?: AwsInstance.CreditSpecificationProperty;
    /**
    * ebs_block_device block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#ebs_block_device AwsInstance#ebs_block_device}
    */
    readonly ebsBlockDevice?: AwsInstance.EbsBlockDeviceProperty[] | cdktn.IResolvable;
    /**
    * enclave_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#enclave_options AwsInstance#enclave_options}
    */
    readonly enclaveOptions?: AwsInstance.EnclaveOptionsProperty;
    /**
    * ephemeral_block_device block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#ephemeral_block_device AwsInstance#ephemeral_block_device}
    */
    readonly ephemeralBlockDevice?: AwsInstance.EphemeralBlockDeviceProperty[] | cdktn.IResolvable;
    /**
    * instance_market_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#instance_market_options AwsInstance#instance_market_options}
    */
    readonly instanceMarketOptions?: AwsInstance.InstanceMarketOptionsProperty;
    /**
    * launch_template block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#launch_template AwsInstance#launch_template}
    */
    readonly launchTemplate?: AwsInstance.LaunchTemplateProperty;
    /**
    * maintenance_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#maintenance_options AwsInstance#maintenance_options}
    */
    readonly maintenanceOptions?: AwsInstance.MaintenanceOptionsProperty;
    /**
    * metadata_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#metadata_options AwsInstance#metadata_options}
    */
    readonly metadataOptions?: AwsInstance.MetadataOptionsProperty;
    /**
    * network_interface block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#network_interface AwsInstance#network_interface}
    */
    readonly networkInterface?: AwsInstance.NetworkInterfaceProperty[] | cdktn.IResolvable;
    /**
    * primary_network_interface block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#primary_network_interface AwsInstance#primary_network_interface}
    */
    readonly primaryNetworkInterface?: AwsInstance.PrimaryNetworkInterfaceProperty;
    /**
    * private_dns_name_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#private_dns_name_options AwsInstance#private_dns_name_options}
    */
    readonly privateDnsNameOptions?: AwsInstance.PrivateDnsNameOptionsProperty;
    /**
    * root_block_device block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#root_block_device AwsInstance#root_block_device}
    */
    readonly rootBlockDevice?: AwsInstance.RootBlockDeviceProperty;
    /**
    * secondary_network_interface block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#secondary_network_interface AwsInstance#secondary_network_interface}
    */
    readonly secondaryNetworkInterface?: AwsInstance.SecondaryNetworkInterfaceProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#timeouts AwsInstance#timeouts}
    */
    readonly timeouts?: AwsInstance.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance aws_instance}
*/
export declare class AwsInstance extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_instance";
    /**
    * Generates CDKTN code for importing a AwsInstance resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsInstance to import
    * @param importFromId The id of the existing AwsInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance aws_instance} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsInstanceConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AwsInstanceConfig);
    private _ami?;
    get ami(): string;
    set ami(value: string);
    resetAmi(): void;
    get amiInput(): string | undefined;
    get arn(): string;
    private _associatePublicIpAddress?;
    get associatePublicIpAddress(): boolean | cdktn.IResolvable;
    set associatePublicIpAddress(value: boolean | cdktn.IResolvable);
    resetAssociatePublicIpAddress(): void;
    get associatePublicIpAddressInput(): boolean | cdktn.IResolvable | undefined;
    private _availabilityZone?;
    get availabilityZone(): string;
    set availabilityZone(value: string);
    resetAvailabilityZone(): void;
    get availabilityZoneInput(): string | undefined;
    private _disableApiStop?;
    get disableApiStop(): boolean | cdktn.IResolvable;
    set disableApiStop(value: boolean | cdktn.IResolvable);
    resetDisableApiStop(): void;
    get disableApiStopInput(): boolean | cdktn.IResolvable | undefined;
    private _disableApiTermination?;
    get disableApiTermination(): boolean | cdktn.IResolvable;
    set disableApiTermination(value: boolean | cdktn.IResolvable);
    resetDisableApiTermination(): void;
    get disableApiTerminationInput(): boolean | cdktn.IResolvable | undefined;
    private _ebsOptimized?;
    get ebsOptimized(): boolean | cdktn.IResolvable;
    set ebsOptimized(value: boolean | cdktn.IResolvable);
    resetEbsOptimized(): void;
    get ebsOptimizedInput(): boolean | cdktn.IResolvable | undefined;
    private _enablePrimaryIpv6?;
    get enablePrimaryIpv6(): boolean | cdktn.IResolvable;
    set enablePrimaryIpv6(value: boolean | cdktn.IResolvable);
    resetEnablePrimaryIpv6(): void;
    get enablePrimaryIpv6Input(): boolean | cdktn.IResolvable | undefined;
    private _forceDestroy?;
    get forceDestroy(): boolean | cdktn.IResolvable;
    set forceDestroy(value: boolean | cdktn.IResolvable);
    resetForceDestroy(): void;
    get forceDestroyInput(): boolean | cdktn.IResolvable | undefined;
    private _getPasswordData?;
    get fetchPasswordData(): boolean | cdktn.IResolvable;
    set fetchPasswordData(value: boolean | cdktn.IResolvable);
    resetFetchPasswordData(): void;
    get fetchPasswordDataInput(): boolean | cdktn.IResolvable | undefined;
    private _hibernation?;
    get hibernation(): boolean | cdktn.IResolvable;
    set hibernation(value: boolean | cdktn.IResolvable);
    resetHibernation(): void;
    get hibernationInput(): boolean | cdktn.IResolvable | undefined;
    private _hostId?;
    get hostId(): string;
    set hostId(value: string);
    resetHostId(): void;
    get hostIdInput(): string | undefined;
    private _hostResourceGroupArn?;
    get hostResourceGroupArn(): string;
    set hostResourceGroupArn(value: string);
    resetHostResourceGroupArn(): void;
    get hostResourceGroupArnInput(): string | undefined;
    private _iamInstanceProfile?;
    get iamInstanceProfile(): string;
    set iamInstanceProfile(value: string);
    resetIamInstanceProfile(): void;
    get iamInstanceProfileInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceInitiatedShutdownBehavior?;
    get instanceInitiatedShutdownBehavior(): string;
    set instanceInitiatedShutdownBehavior(value: string);
    resetInstanceInitiatedShutdownBehavior(): void;
    get instanceInitiatedShutdownBehaviorInput(): string | undefined;
    get instanceLifecycle(): string;
    get instanceState(): string;
    private _instanceType?;
    get instanceType(): string;
    set instanceType(value: string);
    resetInstanceType(): void;
    get instanceTypeInput(): string | undefined;
    private _ipv6AddressCount?;
    get ipv6AddressCount(): number;
    set ipv6AddressCount(value: number);
    resetIpv6AddressCount(): void;
    get ipv6AddressCountInput(): number | undefined;
    private _ipv6Addresses?;
    get ipv6Addresses(): string[];
    set ipv6Addresses(value: string[]);
    resetIpv6Addresses(): void;
    get ipv6AddressesInput(): string[] | undefined;
    private _keyName?;
    get keyName(): string;
    set keyName(value: string);
    resetKeyName(): void;
    get keyNameInput(): string | undefined;
    private _monitoring?;
    get monitoring(): boolean | cdktn.IResolvable;
    set monitoring(value: boolean | cdktn.IResolvable);
    resetMonitoring(): void;
    get monitoringInput(): boolean | cdktn.IResolvable | undefined;
    get outpostArn(): string;
    get passwordData(): string;
    private _placementGroup?;
    get placementGroup(): string;
    set placementGroup(value: string);
    resetPlacementGroup(): void;
    get placementGroupInput(): string | undefined;
    private _placementGroupId?;
    get placementGroupId(): string;
    set placementGroupId(value: string);
    resetPlacementGroupId(): void;
    get placementGroupIdInput(): string | undefined;
    private _placementPartitionNumber?;
    get placementPartitionNumber(): number;
    set placementPartitionNumber(value: number);
    resetPlacementPartitionNumber(): void;
    get placementPartitionNumberInput(): number | undefined;
    get primaryNetworkInterfaceId(): string;
    get privateDns(): string;
    private _privateIp?;
    get privateIp(): string;
    set privateIp(value: string);
    resetPrivateIp(): void;
    get privateIpInput(): string | undefined;
    get publicDns(): string;
    get publicIp(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _secondaryPrivateIps?;
    get secondaryPrivateIps(): string[];
    set secondaryPrivateIps(value: string[]);
    resetSecondaryPrivateIps(): void;
    get secondaryPrivateIpsInput(): string[] | undefined;
    private _securityGroups?;
    get securityGroups(): string[];
    set securityGroups(value: string[]);
    resetSecurityGroups(): void;
    get securityGroupsInput(): string[] | undefined;
    private _sourceDestCheck?;
    get sourceDestCheck(): boolean | cdktn.IResolvable;
    set sourceDestCheck(value: boolean | cdktn.IResolvable);
    resetSourceDestCheck(): void;
    get sourceDestCheckInput(): boolean | cdktn.IResolvable | undefined;
    get spotInstanceRequestId(): string;
    private _subnetId?;
    get subnetId(): string;
    set subnetId(value: string);
    resetSubnetId(): void;
    get subnetIdInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _tenancy?;
    get tenancy(): string;
    set tenancy(value: string);
    resetTenancy(): void;
    get tenancyInput(): string | undefined;
    private _userData?;
    get userData(): string;
    set userData(value: string);
    resetUserData(): void;
    get userDataInput(): string | undefined;
    private _userDataBase64?;
    get userDataBase64(): string;
    set userDataBase64(value: string);
    resetUserDataBase64(): void;
    get userDataBase64Input(): string | undefined;
    private _userDataReplaceOnChange?;
    get userDataReplaceOnChange(): boolean | cdktn.IResolvable;
    set userDataReplaceOnChange(value: boolean | cdktn.IResolvable);
    resetUserDataReplaceOnChange(): void;
    get userDataReplaceOnChangeInput(): boolean | cdktn.IResolvable | undefined;
    private _volumeTags?;
    get volumeTags(): {
        [key: string]: string;
    };
    set volumeTags(value: {
        [key: string]: string;
    });
    resetVolumeTags(): void;
    get volumeTagsInput(): {
        [key: string]: string;
    } | undefined;
    private _vpcSecurityGroupIds?;
    get vpcSecurityGroupIds(): string[];
    set vpcSecurityGroupIds(value: string[]);
    resetVpcSecurityGroupIds(): void;
    get vpcSecurityGroupIdsInput(): string[] | undefined;
    private _capacityReservationSpecification;
    get capacityReservationSpecification(): AwsInstance.CapacityReservationSpecificationPropertyOutputReference;
    putCapacityReservationSpecification(value: AwsInstance.CapacityReservationSpecificationProperty): void;
    resetCapacityReservationSpecification(): void;
    get capacityReservationSpecificationInput(): AwsInstance.CapacityReservationSpecificationProperty | undefined;
    private _cpuOptions;
    get cpuOptions(): AwsInstance.CpuOptionsPropertyOutputReference;
    putCpuOptions(value: AwsInstance.CpuOptionsProperty): void;
    resetCpuOptions(): void;
    get cpuOptionsInput(): AwsInstance.CpuOptionsProperty | undefined;
    private _creditSpecification;
    get creditSpecification(): AwsInstance.CreditSpecificationPropertyOutputReference;
    putCreditSpecification(value: AwsInstance.CreditSpecificationProperty): void;
    resetCreditSpecification(): void;
    get creditSpecificationInput(): AwsInstance.CreditSpecificationProperty | undefined;
    private _ebsBlockDevice;
    get ebsBlockDevice(): AwsInstance.EbsBlockDevicePropertyList;
    putEbsBlockDevice(value: AwsInstance.EbsBlockDeviceProperty[] | cdktn.IResolvable): void;
    resetEbsBlockDevice(): void;
    get ebsBlockDeviceInput(): cdktn.IResolvable | AwsInstance.EbsBlockDeviceProperty[] | undefined;
    private _enclaveOptions;
    get enclaveOptions(): AwsInstance.EnclaveOptionsPropertyOutputReference;
    putEnclaveOptions(value: AwsInstance.EnclaveOptionsProperty): void;
    resetEnclaveOptions(): void;
    get enclaveOptionsInput(): AwsInstance.EnclaveOptionsProperty | undefined;
    private _ephemeralBlockDevice;
    get ephemeralBlockDevice(): AwsInstance.EphemeralBlockDevicePropertyList;
    putEphemeralBlockDevice(value: AwsInstance.EphemeralBlockDeviceProperty[] | cdktn.IResolvable): void;
    resetEphemeralBlockDevice(): void;
    get ephemeralBlockDeviceInput(): cdktn.IResolvable | AwsInstance.EphemeralBlockDeviceProperty[] | undefined;
    private _instanceMarketOptions;
    get instanceMarketOptions(): AwsInstance.InstanceMarketOptionsPropertyOutputReference;
    putInstanceMarketOptions(value: AwsInstance.InstanceMarketOptionsProperty): void;
    resetInstanceMarketOptions(): void;
    get instanceMarketOptionsInput(): AwsInstance.InstanceMarketOptionsProperty | undefined;
    private _launchTemplate;
    get launchTemplate(): AwsInstance.LaunchTemplatePropertyOutputReference;
    putLaunchTemplate(value: AwsInstance.LaunchTemplateProperty): void;
    resetLaunchTemplate(): void;
    get launchTemplateInput(): AwsInstance.LaunchTemplateProperty | undefined;
    private _maintenanceOptions;
    get maintenanceOptions(): AwsInstance.MaintenanceOptionsPropertyOutputReference;
    putMaintenanceOptions(value: AwsInstance.MaintenanceOptionsProperty): void;
    resetMaintenanceOptions(): void;
    get maintenanceOptionsInput(): AwsInstance.MaintenanceOptionsProperty | undefined;
    private _metadataOptions;
    get metadataOptions(): AwsInstance.MetadataOptionsPropertyOutputReference;
    putMetadataOptions(value: AwsInstance.MetadataOptionsProperty): void;
    resetMetadataOptions(): void;
    get metadataOptionsInput(): AwsInstance.MetadataOptionsProperty | undefined;
    private _networkInterface;
    get networkInterface(): AwsInstance.NetworkInterfacePropertyList;
    putNetworkInterface(value: AwsInstance.NetworkInterfaceProperty[] | cdktn.IResolvable): void;
    resetNetworkInterface(): void;
    get networkInterfaceInput(): cdktn.IResolvable | AwsInstance.NetworkInterfaceProperty[] | undefined;
    private _primaryNetworkInterface;
    get primaryNetworkInterface(): AwsInstance.PrimaryNetworkInterfacePropertyOutputReference;
    putPrimaryNetworkInterface(value: AwsInstance.PrimaryNetworkInterfaceProperty): void;
    resetPrimaryNetworkInterface(): void;
    get primaryNetworkInterfaceInput(): AwsInstance.PrimaryNetworkInterfaceProperty | undefined;
    private _privateDnsNameOptions;
    get privateDnsNameOptions(): AwsInstance.PrivateDnsNameOptionsPropertyOutputReference;
    putPrivateDnsNameOptions(value: AwsInstance.PrivateDnsNameOptionsProperty): void;
    resetPrivateDnsNameOptions(): void;
    get privateDnsNameOptionsInput(): AwsInstance.PrivateDnsNameOptionsProperty | undefined;
    private _rootBlockDevice;
    get rootBlockDevice(): AwsInstance.RootBlockDevicePropertyOutputReference;
    putRootBlockDevice(value: AwsInstance.RootBlockDeviceProperty): void;
    resetRootBlockDevice(): void;
    get rootBlockDeviceInput(): AwsInstance.RootBlockDeviceProperty | undefined;
    private _secondaryNetworkInterface;
    get secondaryNetworkInterface(): AwsInstance.SecondaryNetworkInterfacePropertyList;
    putSecondaryNetworkInterface(value: AwsInstance.SecondaryNetworkInterfaceProperty[] | cdktn.IResolvable): void;
    resetSecondaryNetworkInterface(): void;
    get secondaryNetworkInterfaceInput(): cdktn.IResolvable | AwsInstance.SecondaryNetworkInterfaceProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsInstance.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsInstance.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsInstance.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsInstanceCapacityReservationTargetPropertyToTerraform(struct?: AwsInstance.CapacityReservationTargetPropertyOutputReference | AwsInstance.CapacityReservationTargetProperty): any;
export declare function awsInstanceCapacityReservationTargetPropertyToHclTerraform(struct?: AwsInstance.CapacityReservationTargetPropertyOutputReference | AwsInstance.CapacityReservationTargetProperty): any;
export declare function awsInstanceCapacityReservationSpecificationPropertyToTerraform(struct?: AwsInstance.CapacityReservationSpecificationPropertyOutputReference | AwsInstance.CapacityReservationSpecificationProperty): any;
export declare function awsInstanceCapacityReservationSpecificationPropertyToHclTerraform(struct?: AwsInstance.CapacityReservationSpecificationPropertyOutputReference | AwsInstance.CapacityReservationSpecificationProperty): any;
export declare function awsInstanceCpuOptionsPropertyToTerraform(struct?: AwsInstance.CpuOptionsPropertyOutputReference | AwsInstance.CpuOptionsProperty): any;
export declare function awsInstanceCpuOptionsPropertyToHclTerraform(struct?: AwsInstance.CpuOptionsPropertyOutputReference | AwsInstance.CpuOptionsProperty): any;
export declare function awsInstanceCreditSpecificationPropertyToTerraform(struct?: AwsInstance.CreditSpecificationPropertyOutputReference | AwsInstance.CreditSpecificationProperty): any;
export declare function awsInstanceCreditSpecificationPropertyToHclTerraform(struct?: AwsInstance.CreditSpecificationPropertyOutputReference | AwsInstance.CreditSpecificationProperty): any;
export declare function awsInstanceEbsBlockDevicePropertyToTerraform(struct?: AwsInstance.EbsBlockDeviceProperty | cdktn.IResolvable): any;
export declare function awsInstanceEbsBlockDevicePropertyToHclTerraform(struct?: AwsInstance.EbsBlockDeviceProperty | cdktn.IResolvable): any;
export declare function awsInstanceEnclaveOptionsPropertyToTerraform(struct?: AwsInstance.EnclaveOptionsPropertyOutputReference | AwsInstance.EnclaveOptionsProperty): any;
export declare function awsInstanceEnclaveOptionsPropertyToHclTerraform(struct?: AwsInstance.EnclaveOptionsPropertyOutputReference | AwsInstance.EnclaveOptionsProperty): any;
export declare function awsInstanceEphemeralBlockDevicePropertyToTerraform(struct?: AwsInstance.EphemeralBlockDeviceProperty | cdktn.IResolvable): any;
export declare function awsInstanceEphemeralBlockDevicePropertyToHclTerraform(struct?: AwsInstance.EphemeralBlockDeviceProperty | cdktn.IResolvable): any;
export declare function awsInstanceSpotOptionsPropertyToTerraform(struct?: AwsInstance.SpotOptionsPropertyOutputReference | AwsInstance.SpotOptionsProperty): any;
export declare function awsInstanceSpotOptionsPropertyToHclTerraform(struct?: AwsInstance.SpotOptionsPropertyOutputReference | AwsInstance.SpotOptionsProperty): any;
export declare function awsInstanceInstanceMarketOptionsPropertyToTerraform(struct?: AwsInstance.InstanceMarketOptionsPropertyOutputReference | AwsInstance.InstanceMarketOptionsProperty): any;
export declare function awsInstanceInstanceMarketOptionsPropertyToHclTerraform(struct?: AwsInstance.InstanceMarketOptionsPropertyOutputReference | AwsInstance.InstanceMarketOptionsProperty): any;
export declare function awsInstanceLaunchTemplatePropertyToTerraform(struct?: AwsInstance.LaunchTemplatePropertyOutputReference | AwsInstance.LaunchTemplateProperty): any;
export declare function awsInstanceLaunchTemplatePropertyToHclTerraform(struct?: AwsInstance.LaunchTemplatePropertyOutputReference | AwsInstance.LaunchTemplateProperty): any;
export declare function awsInstanceMaintenanceOptionsPropertyToTerraform(struct?: AwsInstance.MaintenanceOptionsPropertyOutputReference | AwsInstance.MaintenanceOptionsProperty): any;
export declare function awsInstanceMaintenanceOptionsPropertyToHclTerraform(struct?: AwsInstance.MaintenanceOptionsPropertyOutputReference | AwsInstance.MaintenanceOptionsProperty): any;
export declare function awsInstanceMetadataOptionsPropertyToTerraform(struct?: AwsInstance.MetadataOptionsPropertyOutputReference | AwsInstance.MetadataOptionsProperty): any;
export declare function awsInstanceMetadataOptionsPropertyToHclTerraform(struct?: AwsInstance.MetadataOptionsPropertyOutputReference | AwsInstance.MetadataOptionsProperty): any;
export declare function awsInstanceNetworkInterfacePropertyToTerraform(struct?: AwsInstance.NetworkInterfaceProperty | cdktn.IResolvable): any;
export declare function awsInstanceNetworkInterfacePropertyToHclTerraform(struct?: AwsInstance.NetworkInterfaceProperty | cdktn.IResolvable): any;
export declare function awsInstancePrimaryNetworkInterfacePropertyToTerraform(struct?: AwsInstance.PrimaryNetworkInterfacePropertyOutputReference | AwsInstance.PrimaryNetworkInterfaceProperty): any;
export declare function awsInstancePrimaryNetworkInterfacePropertyToHclTerraform(struct?: AwsInstance.PrimaryNetworkInterfacePropertyOutputReference | AwsInstance.PrimaryNetworkInterfaceProperty): any;
export declare function awsInstancePrivateDnsNameOptionsPropertyToTerraform(struct?: AwsInstance.PrivateDnsNameOptionsPropertyOutputReference | AwsInstance.PrivateDnsNameOptionsProperty): any;
export declare function awsInstancePrivateDnsNameOptionsPropertyToHclTerraform(struct?: AwsInstance.PrivateDnsNameOptionsPropertyOutputReference | AwsInstance.PrivateDnsNameOptionsProperty): any;
export declare function awsInstanceRootBlockDevicePropertyToTerraform(struct?: AwsInstance.RootBlockDevicePropertyOutputReference | AwsInstance.RootBlockDeviceProperty): any;
export declare function awsInstanceRootBlockDevicePropertyToHclTerraform(struct?: AwsInstance.RootBlockDevicePropertyOutputReference | AwsInstance.RootBlockDeviceProperty): any;
export declare function awsInstanceSecondaryNetworkInterfacePropertyToTerraform(struct?: AwsInstance.SecondaryNetworkInterfaceProperty | cdktn.IResolvable): any;
export declare function awsInstanceSecondaryNetworkInterfacePropertyToHclTerraform(struct?: AwsInstance.SecondaryNetworkInterfaceProperty | cdktn.IResolvable): any;
export declare function awsInstanceTimeoutsPropertyToTerraform(struct?: AwsInstance.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsInstanceTimeoutsPropertyToHclTerraform(struct?: AwsInstance.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsInstance {
    interface CapacityReservationTargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#capacity_reservation_id AwsInstance#capacity_reservation_id}
        */
        readonly capacityReservationId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#capacity_reservation_resource_group_arn AwsInstance#capacity_reservation_resource_group_arn}
        */
        readonly capacityReservationResourceGroupArn?: string;
    }
    class CapacityReservationTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CapacityReservationTargetProperty | undefined;
        set internalValue(value: CapacityReservationTargetProperty | undefined);
        private _capacityReservationId?;
        get capacityReservationId(): string;
        set capacityReservationId(value: string);
        resetCapacityReservationId(): void;
        get capacityReservationIdInput(): string | undefined;
        private _capacityReservationResourceGroupArn?;
        get capacityReservationResourceGroupArn(): string;
        set capacityReservationResourceGroupArn(value: string);
        resetCapacityReservationResourceGroupArn(): void;
        get capacityReservationResourceGroupArnInput(): string | undefined;
    }
    interface CapacityReservationSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#capacity_reservation_preference AwsInstance#capacity_reservation_preference}
        */
        readonly capacityReservationPreference?: string;
        /**
        * capacity_reservation_target block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#capacity_reservation_target AwsInstance#capacity_reservation_target}
        */
        readonly capacityReservationTarget?: CapacityReservationTargetProperty;
    }
    class CapacityReservationSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CapacityReservationSpecificationProperty | undefined;
        set internalValue(value: CapacityReservationSpecificationProperty | undefined);
        private _capacityReservationPreference?;
        get capacityReservationPreference(): string;
        set capacityReservationPreference(value: string);
        resetCapacityReservationPreference(): void;
        get capacityReservationPreferenceInput(): string | undefined;
        private _capacityReservationTarget;
        get capacityReservationTarget(): CapacityReservationTargetPropertyOutputReference;
        putCapacityReservationTarget(value: CapacityReservationTargetProperty): void;
        resetCapacityReservationTarget(): void;
        get capacityReservationTargetInput(): CapacityReservationTargetProperty | undefined;
    }
    interface CpuOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#amd_sev_snp AwsInstance#amd_sev_snp}
        */
        readonly amdSevSnp?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#core_count AwsInstance#core_count}
        */
        readonly coreCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#nested_virtualization AwsInstance#nested_virtualization}
        */
        readonly nestedVirtualization?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#threads_per_core AwsInstance#threads_per_core}
        */
        readonly threadsPerCore?: number;
    }
    class CpuOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CpuOptionsProperty | undefined;
        set internalValue(value: CpuOptionsProperty | undefined);
        private _amdSevSnp?;
        get amdSevSnp(): string;
        set amdSevSnp(value: string);
        resetAmdSevSnp(): void;
        get amdSevSnpInput(): string | undefined;
        private _coreCount?;
        get coreCount(): number;
        set coreCount(value: number);
        resetCoreCount(): void;
        get coreCountInput(): number | undefined;
        private _nestedVirtualization?;
        get nestedVirtualization(): string;
        set nestedVirtualization(value: string);
        resetNestedVirtualization(): void;
        get nestedVirtualizationInput(): string | undefined;
        private _threadsPerCore?;
        get threadsPerCore(): number;
        set threadsPerCore(value: number);
        resetThreadsPerCore(): void;
        get threadsPerCoreInput(): number | undefined;
    }
    interface CreditSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#cpu_credits AwsInstance#cpu_credits}
        */
        readonly cpuCredits?: string;
    }
    class CreditSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CreditSpecificationProperty | undefined;
        set internalValue(value: CreditSpecificationProperty | undefined);
        private _cpuCredits?;
        get cpuCredits(): string;
        set cpuCredits(value: string);
        resetCpuCredits(): void;
        get cpuCreditsInput(): string | undefined;
    }
    interface EbsBlockDeviceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#delete_on_termination AwsInstance#delete_on_termination}
        */
        readonly deleteOnTermination?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#device_name AwsInstance#device_name}
        */
        readonly deviceName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#encrypted AwsInstance#encrypted}
        */
        readonly encrypted?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#iops AwsInstance#iops}
        */
        readonly iops?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#kms_key_id AwsInstance#kms_key_id}
        */
        readonly kmsKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#snapshot_id AwsInstance#snapshot_id}
        */
        readonly snapshotId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#tags AwsInstance#tags}
        */
        readonly tags?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#tags_all AwsInstance#tags_all}
        */
        readonly tagsAll?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#throughput AwsInstance#throughput}
        */
        readonly throughput?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#volume_size AwsInstance#volume_size}
        */
        readonly volumeSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#volume_type AwsInstance#volume_type}
        */
        readonly volumeType?: string;
    }
    class EbsBlockDevicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EbsBlockDeviceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EbsBlockDeviceProperty | cdktn.IResolvable | undefined);
        private _deleteOnTermination?;
        get deleteOnTermination(): boolean | cdktn.IResolvable;
        set deleteOnTermination(value: boolean | cdktn.IResolvable);
        resetDeleteOnTermination(): void;
        get deleteOnTerminationInput(): boolean | cdktn.IResolvable | undefined;
        private _deviceName?;
        get deviceName(): string;
        set deviceName(value: string);
        get deviceNameInput(): string | undefined;
        private _encrypted?;
        get encrypted(): boolean | cdktn.IResolvable;
        set encrypted(value: boolean | cdktn.IResolvable);
        resetEncrypted(): void;
        get encryptedInput(): boolean | cdktn.IResolvable | undefined;
        private _iops?;
        get iops(): number;
        set iops(value: number);
        resetIops(): void;
        get iopsInput(): number | undefined;
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        resetKmsKeyId(): void;
        get kmsKeyIdInput(): string | undefined;
        private _snapshotId?;
        get snapshotId(): string;
        set snapshotId(value: string);
        resetSnapshotId(): void;
        get snapshotIdInput(): string | undefined;
        private _tags?;
        get tags(): {
            [key: string]: string;
        };
        set tags(value: {
            [key: string]: string;
        });
        resetTags(): void;
        get tagsInput(): {
            [key: string]: string;
        } | undefined;
        private _tagsAll?;
        get tagsAll(): {
            [key: string]: string;
        };
        set tagsAll(value: {
            [key: string]: string;
        });
        resetTagsAll(): void;
        get tagsAllInput(): {
            [key: string]: string;
        } | undefined;
        private _throughput?;
        get throughput(): number;
        set throughput(value: number);
        resetThroughput(): void;
        get throughputInput(): number | undefined;
        get volumeId(): string;
        private _volumeSize?;
        get volumeSize(): number;
        set volumeSize(value: number);
        resetVolumeSize(): void;
        get volumeSizeInput(): number | undefined;
        private _volumeType?;
        get volumeType(): string;
        set volumeType(value: string);
        resetVolumeType(): void;
        get volumeTypeInput(): string | undefined;
    }
    class EbsBlockDevicePropertyList extends cdktn.ComplexList {
        internalValue?: EbsBlockDeviceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EbsBlockDevicePropertyOutputReference;
    }
    interface EnclaveOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#enabled AwsInstance#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
    }
    class EnclaveOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EnclaveOptionsProperty | undefined;
        set internalValue(value: EnclaveOptionsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface EphemeralBlockDeviceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#device_name AwsInstance#device_name}
        */
        readonly deviceName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#no_device AwsInstance#no_device}
        */
        readonly noDevice?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#virtual_name AwsInstance#virtual_name}
        */
        readonly virtualName?: string;
    }
    class EphemeralBlockDevicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EphemeralBlockDeviceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EphemeralBlockDeviceProperty | cdktn.IResolvable | undefined);
        private _deviceName?;
        get deviceName(): string;
        set deviceName(value: string);
        get deviceNameInput(): string | undefined;
        private _noDevice?;
        get noDevice(): boolean | cdktn.IResolvable;
        set noDevice(value: boolean | cdktn.IResolvable);
        resetNoDevice(): void;
        get noDeviceInput(): boolean | cdktn.IResolvable | undefined;
        private _virtualName?;
        get virtualName(): string;
        set virtualName(value: string);
        resetVirtualName(): void;
        get virtualNameInput(): string | undefined;
    }
    class EphemeralBlockDevicePropertyList extends cdktn.ComplexList {
        internalValue?: EphemeralBlockDeviceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EphemeralBlockDevicePropertyOutputReference;
    }
    interface SpotOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#instance_interruption_behavior AwsInstance#instance_interruption_behavior}
        */
        readonly instanceInterruptionBehavior?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#max_price AwsInstance#max_price}
        */
        readonly maxPrice?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#spot_instance_type AwsInstance#spot_instance_type}
        */
        readonly spotInstanceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#valid_until AwsInstance#valid_until}
        */
        readonly validUntil?: string;
    }
    class SpotOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpotOptionsProperty | undefined;
        set internalValue(value: SpotOptionsProperty | undefined);
        private _instanceInterruptionBehavior?;
        get instanceInterruptionBehavior(): string;
        set instanceInterruptionBehavior(value: string);
        resetInstanceInterruptionBehavior(): void;
        get instanceInterruptionBehaviorInput(): string | undefined;
        private _maxPrice?;
        get maxPrice(): string;
        set maxPrice(value: string);
        resetMaxPrice(): void;
        get maxPriceInput(): string | undefined;
        private _spotInstanceType?;
        get spotInstanceType(): string;
        set spotInstanceType(value: string);
        resetSpotInstanceType(): void;
        get spotInstanceTypeInput(): string | undefined;
        private _validUntil?;
        get validUntil(): string;
        set validUntil(value: string);
        resetValidUntil(): void;
        get validUntilInput(): string | undefined;
    }
    interface InstanceMarketOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#market_type AwsInstance#market_type}
        */
        readonly marketType?: string;
        /**
        * spot_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#spot_options AwsInstance#spot_options}
        */
        readonly spotOptions?: SpotOptionsProperty;
    }
    class InstanceMarketOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InstanceMarketOptionsProperty | undefined;
        set internalValue(value: InstanceMarketOptionsProperty | undefined);
        private _marketType?;
        get marketType(): string;
        set marketType(value: string);
        resetMarketType(): void;
        get marketTypeInput(): string | undefined;
        private _spotOptions;
        get spotOptions(): SpotOptionsPropertyOutputReference;
        putSpotOptions(value: SpotOptionsProperty): void;
        resetSpotOptions(): void;
        get spotOptionsInput(): SpotOptionsProperty | undefined;
    }
    interface LaunchTemplateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#id AwsInstance#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#name AwsInstance#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#version AwsInstance#version}
        */
        readonly version?: string;
    }
    class LaunchTemplatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LaunchTemplateProperty | undefined;
        set internalValue(value: LaunchTemplateProperty | undefined);
        private _id?;
        get id(): string;
        set id(value: string);
        resetId(): void;
        get idInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _version?;
        get version(): string;
        set version(value: string);
        resetVersion(): void;
        get versionInput(): string | undefined;
    }
    interface MaintenanceOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#auto_recovery AwsInstance#auto_recovery}
        */
        readonly autoRecovery?: string;
    }
    class MaintenanceOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MaintenanceOptionsProperty | undefined;
        set internalValue(value: MaintenanceOptionsProperty | undefined);
        private _autoRecovery?;
        get autoRecovery(): string;
        set autoRecovery(value: string);
        resetAutoRecovery(): void;
        get autoRecoveryInput(): string | undefined;
    }
    interface MetadataOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#http_endpoint AwsInstance#http_endpoint}
        */
        readonly httpEndpoint?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#http_protocol_ipv6 AwsInstance#http_protocol_ipv6}
        */
        readonly httpProtocolIpv6?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#http_put_response_hop_limit AwsInstance#http_put_response_hop_limit}
        */
        readonly httpPutResponseHopLimit?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#http_tokens AwsInstance#http_tokens}
        */
        readonly httpTokens?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#instance_metadata_tags AwsInstance#instance_metadata_tags}
        */
        readonly instanceMetadataTags?: string;
    }
    class MetadataOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MetadataOptionsProperty | undefined;
        set internalValue(value: MetadataOptionsProperty | undefined);
        private _httpEndpoint?;
        get httpEndpoint(): string;
        set httpEndpoint(value: string);
        resetHttpEndpoint(): void;
        get httpEndpointInput(): string | undefined;
        private _httpProtocolIpv6?;
        get httpProtocolIpv6(): string;
        set httpProtocolIpv6(value: string);
        resetHttpProtocolIpv6(): void;
        get httpProtocolIpv6Input(): string | undefined;
        private _httpPutResponseHopLimit?;
        get httpPutResponseHopLimit(): number;
        set httpPutResponseHopLimit(value: number);
        resetHttpPutResponseHopLimit(): void;
        get httpPutResponseHopLimitInput(): number | undefined;
        private _httpTokens?;
        get httpTokens(): string;
        set httpTokens(value: string);
        resetHttpTokens(): void;
        get httpTokensInput(): string | undefined;
        private _instanceMetadataTags?;
        get instanceMetadataTags(): string;
        set instanceMetadataTags(value: string);
        resetInstanceMetadataTags(): void;
        get instanceMetadataTagsInput(): string | undefined;
    }
    interface NetworkInterfaceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#delete_on_termination AwsInstance#delete_on_termination}
        */
        readonly deleteOnTermination?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#device_index AwsInstance#device_index}
        */
        readonly deviceIndex: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#network_card_index AwsInstance#network_card_index}
        */
        readonly networkCardIndex?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#network_interface_id AwsInstance#network_interface_id}
        */
        readonly networkInterfaceId: string;
    }
    class NetworkInterfacePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NetworkInterfaceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NetworkInterfaceProperty | cdktn.IResolvable | undefined);
        private _deleteOnTermination?;
        get deleteOnTermination(): boolean | cdktn.IResolvable;
        set deleteOnTermination(value: boolean | cdktn.IResolvable);
        resetDeleteOnTermination(): void;
        get deleteOnTerminationInput(): boolean | cdktn.IResolvable | undefined;
        private _deviceIndex?;
        get deviceIndex(): number;
        set deviceIndex(value: number);
        get deviceIndexInput(): number | undefined;
        private _networkCardIndex?;
        get networkCardIndex(): number;
        set networkCardIndex(value: number);
        resetNetworkCardIndex(): void;
        get networkCardIndexInput(): number | undefined;
        private _networkInterfaceId?;
        get networkInterfaceId(): string;
        set networkInterfaceId(value: string);
        get networkInterfaceIdInput(): string | undefined;
    }
    class NetworkInterfacePropertyList extends cdktn.ComplexList {
        internalValue?: NetworkInterfaceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NetworkInterfacePropertyOutputReference;
    }
    interface PrimaryNetworkInterfaceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#network_interface_id AwsInstance#network_interface_id}
        */
        readonly networkInterfaceId: string;
    }
    class PrimaryNetworkInterfacePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PrimaryNetworkInterfaceProperty | undefined;
        set internalValue(value: PrimaryNetworkInterfaceProperty | undefined);
        get deleteOnTermination(): cdktn.IResolvable;
        private _networkInterfaceId?;
        get networkInterfaceId(): string;
        set networkInterfaceId(value: string);
        get networkInterfaceIdInput(): string | undefined;
    }
    interface PrivateDnsNameOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#enable_resource_name_dns_a_record AwsInstance#enable_resource_name_dns_a_record}
        */
        readonly enableResourceNameDnsARecord?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#enable_resource_name_dns_aaaa_record AwsInstance#enable_resource_name_dns_aaaa_record}
        */
        readonly enableResourceNameDnsAaaaRecord?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#hostname_type AwsInstance#hostname_type}
        */
        readonly hostnameType?: string;
    }
    class PrivateDnsNameOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PrivateDnsNameOptionsProperty | undefined;
        set internalValue(value: PrivateDnsNameOptionsProperty | undefined);
        private _enableResourceNameDnsARecord?;
        get enableResourceNameDnsARecord(): boolean | cdktn.IResolvable;
        set enableResourceNameDnsARecord(value: boolean | cdktn.IResolvable);
        resetEnableResourceNameDnsARecord(): void;
        get enableResourceNameDnsARecordInput(): boolean | cdktn.IResolvable | undefined;
        private _enableResourceNameDnsAaaaRecord?;
        get enableResourceNameDnsAaaaRecord(): boolean | cdktn.IResolvable;
        set enableResourceNameDnsAaaaRecord(value: boolean | cdktn.IResolvable);
        resetEnableResourceNameDnsAaaaRecord(): void;
        get enableResourceNameDnsAaaaRecordInput(): boolean | cdktn.IResolvable | undefined;
        private _hostnameType?;
        get hostnameType(): string;
        set hostnameType(value: string);
        resetHostnameType(): void;
        get hostnameTypeInput(): string | undefined;
    }
    interface RootBlockDeviceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#delete_on_termination AwsInstance#delete_on_termination}
        */
        readonly deleteOnTermination?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#encrypted AwsInstance#encrypted}
        */
        readonly encrypted?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#iops AwsInstance#iops}
        */
        readonly iops?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#kms_key_id AwsInstance#kms_key_id}
        */
        readonly kmsKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#tags AwsInstance#tags}
        */
        readonly tags?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#tags_all AwsInstance#tags_all}
        */
        readonly tagsAll?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#throughput AwsInstance#throughput}
        */
        readonly throughput?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#volume_size AwsInstance#volume_size}
        */
        readonly volumeSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#volume_type AwsInstance#volume_type}
        */
        readonly volumeType?: string;
    }
    class RootBlockDevicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RootBlockDeviceProperty | undefined;
        set internalValue(value: RootBlockDeviceProperty | undefined);
        private _deleteOnTermination?;
        get deleteOnTermination(): boolean | cdktn.IResolvable;
        set deleteOnTermination(value: boolean | cdktn.IResolvable);
        resetDeleteOnTermination(): void;
        get deleteOnTerminationInput(): boolean | cdktn.IResolvable | undefined;
        get deviceName(): string;
        private _encrypted?;
        get encrypted(): boolean | cdktn.IResolvable;
        set encrypted(value: boolean | cdktn.IResolvable);
        resetEncrypted(): void;
        get encryptedInput(): boolean | cdktn.IResolvable | undefined;
        private _iops?;
        get iops(): number;
        set iops(value: number);
        resetIops(): void;
        get iopsInput(): number | undefined;
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        resetKmsKeyId(): void;
        get kmsKeyIdInput(): string | undefined;
        private _tags?;
        get tags(): {
            [key: string]: string;
        };
        set tags(value: {
            [key: string]: string;
        });
        resetTags(): void;
        get tagsInput(): {
            [key: string]: string;
        } | undefined;
        private _tagsAll?;
        get tagsAll(): {
            [key: string]: string;
        };
        set tagsAll(value: {
            [key: string]: string;
        });
        resetTagsAll(): void;
        get tagsAllInput(): {
            [key: string]: string;
        } | undefined;
        private _throughput?;
        get throughput(): number;
        set throughput(value: number);
        resetThroughput(): void;
        get throughputInput(): number | undefined;
        get volumeId(): string;
        private _volumeSize?;
        get volumeSize(): number;
        set volumeSize(value: number);
        resetVolumeSize(): void;
        get volumeSizeInput(): number | undefined;
        private _volumeType?;
        get volumeType(): string;
        set volumeType(value: string);
        resetVolumeType(): void;
        get volumeTypeInput(): string | undefined;
    }
    interface SecondaryNetworkInterfaceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#delete_on_termination AwsInstance#delete_on_termination}
        */
        readonly deleteOnTermination?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#device_index AwsInstance#device_index}
        */
        readonly deviceIndex?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#interface_type AwsInstance#interface_type}
        */
        readonly interfaceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#network_card_index AwsInstance#network_card_index}
        */
        readonly networkCardIndex: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#private_ip_address_count AwsInstance#private_ip_address_count}
        */
        readonly privateIpAddressCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#secondary_subnet_id AwsInstance#secondary_subnet_id}
        */
        readonly secondarySubnetId: string;
    }
    class SecondaryNetworkInterfacePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SecondaryNetworkInterfaceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SecondaryNetworkInterfaceProperty | cdktn.IResolvable | undefined);
        private _deleteOnTermination?;
        get deleteOnTermination(): boolean | cdktn.IResolvable;
        set deleteOnTermination(value: boolean | cdktn.IResolvable);
        resetDeleteOnTermination(): void;
        get deleteOnTerminationInput(): boolean | cdktn.IResolvable | undefined;
        private _deviceIndex?;
        get deviceIndex(): number;
        set deviceIndex(value: number);
        resetDeviceIndex(): void;
        get deviceIndexInput(): number | undefined;
        private _interfaceType?;
        get interfaceType(): string;
        set interfaceType(value: string);
        resetInterfaceType(): void;
        get interfaceTypeInput(): string | undefined;
        get macAddress(): string;
        private _networkCardIndex?;
        get networkCardIndex(): number;
        set networkCardIndex(value: number);
        get networkCardIndexInput(): number | undefined;
        private _privateIpAddressCount?;
        get privateIpAddressCount(): number;
        set privateIpAddressCount(value: number);
        resetPrivateIpAddressCount(): void;
        get privateIpAddressCountInput(): number | undefined;
        get privateIpAddresses(): string[];
        get secondaryInterfaceId(): string;
        get secondaryNetworkId(): string;
        private _secondarySubnetId?;
        get secondarySubnetId(): string;
        set secondarySubnetId(value: string);
        get secondarySubnetIdInput(): string | undefined;
        get sourceDestCheck(): cdktn.IResolvable;
        get status(): string;
    }
    class SecondaryNetworkInterfacePropertyList extends cdktn.ComplexList {
        internalValue?: SecondaryNetworkInterfaceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SecondaryNetworkInterfacePropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#create AwsInstance#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#delete AwsInstance#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#read AwsInstance#read}
        */
        readonly read?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/instance#update AwsInstance#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _read?;
        get read(): string;
        set read(value: string);
        resetRead(): void;
        get readInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
