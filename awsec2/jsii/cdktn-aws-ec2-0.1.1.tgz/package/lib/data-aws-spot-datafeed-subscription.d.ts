import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsSpotDatafeedSubscriptionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/spot_datafeed_subscription#region DataAwsSpotDatafeedSubscription#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/spot_datafeed_subscription aws_spot_datafeed_subscription}
*/
export declare class DataAwsSpotDatafeedSubscription extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_spot_datafeed_subscription";
    /**
    * Generates CDKTN code for importing a DataAwsSpotDatafeedSubscription resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsSpotDatafeedSubscription to import
    * @param importFromId The id of the existing DataAwsSpotDatafeedSubscription that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/spot_datafeed_subscription#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsSpotDatafeedSubscription to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/spot_datafeed_subscription aws_spot_datafeed_subscription} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsSpotDatafeedSubscriptionConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsSpotDatafeedSubscriptionConfig);
    get bucket(): string;
    get prefix(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
