import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsAmiConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ami#allow_unsafe_filter DataAwsAmi#allow_unsafe_filter}
    */
    readonly allowUnsafeFilter?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ami#executable_users DataAwsAmi#executable_users}
    */
    readonly executableUsers?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ami#id DataAwsAmi#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ami#include_deprecated DataAwsAmi#include_deprecated}
    */
    readonly includeDeprecated?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ami#most_recent DataAwsAmi#most_recent}
    */
    readonly mostRecent?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ami#name_regex DataAwsAmi#name_regex}
    */
    readonly nameRegex?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ami#owners DataAwsAmi#owners}
    */
    readonly owners?: string[];
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ami#region DataAwsAmi#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ami#tags DataAwsAmi#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ami#uefi_data DataAwsAmi#uefi_data}
    */
    readonly uefiData?: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ami#filter DataAwsAmi#filter}
    */
    readonly filter?: DataAwsAmi.FilterProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ami#timeouts DataAwsAmi#timeouts}
    */
    readonly timeouts?: DataAwsAmi.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ami aws_ami}
*/
export declare class DataAwsAmi extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_ami";
    /**
    * Generates CDKTN code for importing a DataAwsAmi resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsAmi to import
    * @param importFromId The id of the existing DataAwsAmi that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ami#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsAmi to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ami aws_ami} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsAmiConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsAmiConfig);
    private _allowUnsafeFilter?;
    get allowUnsafeFilter(): boolean | cdktn.IResolvable;
    set allowUnsafeFilter(value: boolean | cdktn.IResolvable);
    resetAllowUnsafeFilter(): void;
    get allowUnsafeFilterInput(): boolean | cdktn.IResolvable | undefined;
    get architecture(): string;
    get arn(): string;
    private _blockDeviceMappings;
    get blockDeviceMappings(): DataAwsAmi.BlockDeviceMappingsPropertyList;
    get bootMode(): string;
    get creationDate(): string;
    get deprecationTime(): string;
    get description(): string;
    get enaSupport(): cdktn.IResolvable;
    private _executableUsers?;
    get executableUsers(): string[];
    set executableUsers(value: string[]);
    resetExecutableUsers(): void;
    get executableUsersInput(): string[] | undefined;
    get hypervisor(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get imageId(): string;
    get imageLocation(): string;
    get imageOwnerAlias(): string;
    get imageType(): string;
    get imdsSupport(): string;
    private _includeDeprecated?;
    get includeDeprecated(): boolean | cdktn.IResolvable;
    set includeDeprecated(value: boolean | cdktn.IResolvable);
    resetIncludeDeprecated(): void;
    get includeDeprecatedInput(): boolean | cdktn.IResolvable | undefined;
    get kernelId(): string;
    get lastLaunchedTime(): string;
    private _mostRecent?;
    get mostRecent(): boolean | cdktn.IResolvable;
    set mostRecent(value: boolean | cdktn.IResolvable);
    resetMostRecent(): void;
    get mostRecentInput(): boolean | cdktn.IResolvable | undefined;
    get name(): string;
    private _nameRegex?;
    get nameRegex(): string;
    set nameRegex(value: string);
    resetNameRegex(): void;
    get nameRegexInput(): string | undefined;
    get ownerId(): string;
    private _owners?;
    get owners(): string[];
    set owners(value: string[]);
    resetOwners(): void;
    get ownersInput(): string[] | undefined;
    get platform(): string;
    get platformDetails(): string;
    private _productCodes;
    get productCodes(): DataAwsAmi.ProductCodesPropertyList;
    get public(): cdktn.IResolvable;
    get ramdiskId(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get rootDeviceName(): string;
    get rootDeviceType(): string;
    get rootSnapshotId(): string;
    get sriovNetSupport(): string;
    get state(): string;
    private _stateReason;
    get stateReason(): cdktn.StringMap;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    get tpmSupport(): string;
    private _uefiData?;
    get uefiData(): string;
    set uefiData(value: string);
    resetUefiData(): void;
    get uefiDataInput(): string | undefined;
    get usageOperation(): string;
    get virtualizationType(): string;
    private _filter;
    get filter(): DataAwsAmi.FilterPropertyList;
    putFilter(value: DataAwsAmi.FilterProperty[] | cdktn.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataAwsAmi.FilterProperty[] | undefined;
    private _timeouts;
    get timeouts(): DataAwsAmi.TimeoutsPropertyOutputReference;
    putTimeouts(value: DataAwsAmi.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAwsAmi.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsAmiBlockDeviceMappingsPropertyToTerraform(struct?: DataAwsAmi.BlockDeviceMappingsProperty): any;
export declare function dataAwsAmiBlockDeviceMappingsPropertyToHclTerraform(struct?: DataAwsAmi.BlockDeviceMappingsProperty): any;
export declare function dataAwsAmiProductCodesPropertyToTerraform(struct?: DataAwsAmi.ProductCodesProperty): any;
export declare function dataAwsAmiProductCodesPropertyToHclTerraform(struct?: DataAwsAmi.ProductCodesProperty): any;
export declare function dataAwsAmiFilterPropertyToTerraform(struct?: DataAwsAmi.FilterProperty | cdktn.IResolvable): any;
export declare function dataAwsAmiFilterPropertyToHclTerraform(struct?: DataAwsAmi.FilterProperty | cdktn.IResolvable): any;
export declare function dataAwsAmiTimeoutsPropertyToTerraform(struct?: DataAwsAmi.TimeoutsProperty | cdktn.IResolvable): any;
export declare function dataAwsAmiTimeoutsPropertyToHclTerraform(struct?: DataAwsAmi.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace DataAwsAmi {
    interface BlockDeviceMappingsProperty {
    }
    class BlockDeviceMappingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BlockDeviceMappingsProperty | undefined;
        set internalValue(value: BlockDeviceMappingsProperty | undefined);
        get deviceName(): string;
        private _ebs;
        get ebs(): cdktn.StringMap;
        get noDevice(): string;
        get virtualName(): string;
    }
    class BlockDeviceMappingsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BlockDeviceMappingsPropertyOutputReference;
    }
    interface ProductCodesProperty {
    }
    class ProductCodesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ProductCodesProperty | undefined;
        set internalValue(value: ProductCodesProperty | undefined);
        get productCodeId(): string;
        get productCodeType(): string;
    }
    class ProductCodesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ProductCodesPropertyOutputReference;
    }
    interface FilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ami#name DataAwsAmi#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ami#values DataAwsAmi#values}
        */
        readonly values: string[];
    }
    class FilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FilterProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class FilterPropertyList extends cdktn.ComplexList {
        internalValue?: FilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ami#read DataAwsAmi#read}
        */
        readonly read?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _read?;
        get read(): string;
        set read(value: string);
        resetRead(): void;
        get readInput(): string | undefined;
    }
}
