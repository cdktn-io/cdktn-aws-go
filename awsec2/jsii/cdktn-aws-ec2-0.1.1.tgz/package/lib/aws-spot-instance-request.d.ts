import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSpotInstanceRequestConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#ami AwsSpotInstanceRequest#ami}
    */
    readonly ami?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#associate_public_ip_address AwsSpotInstanceRequest#associate_public_ip_address}
    */
    readonly associatePublicIpAddress?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#availability_zone AwsSpotInstanceRequest#availability_zone}
    */
    readonly availabilityZone?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#disable_api_stop AwsSpotInstanceRequest#disable_api_stop}
    */
    readonly disableApiStop?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#disable_api_termination AwsSpotInstanceRequest#disable_api_termination}
    */
    readonly disableApiTermination?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#ebs_optimized AwsSpotInstanceRequest#ebs_optimized}
    */
    readonly ebsOptimized?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#enable_primary_ipv6 AwsSpotInstanceRequest#enable_primary_ipv6}
    */
    readonly enablePrimaryIpv6?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#force_destroy AwsSpotInstanceRequest#force_destroy}
    */
    readonly forceDestroy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#get_password_data AwsSpotInstanceRequest#get_password_data}
    */
    readonly fetchPasswordData?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#hibernation AwsSpotInstanceRequest#hibernation}
    */
    readonly hibernation?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#host_id AwsSpotInstanceRequest#host_id}
    */
    readonly hostId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#host_resource_group_arn AwsSpotInstanceRequest#host_resource_group_arn}
    */
    readonly hostResourceGroupArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#iam_instance_profile AwsSpotInstanceRequest#iam_instance_profile}
    */
    readonly iamInstanceProfile?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#id AwsSpotInstanceRequest#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#instance_initiated_shutdown_behavior AwsSpotInstanceRequest#instance_initiated_shutdown_behavior}
    */
    readonly instanceInitiatedShutdownBehavior?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#instance_interruption_behavior AwsSpotInstanceRequest#instance_interruption_behavior}
    */
    readonly instanceInterruptionBehavior?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#instance_type AwsSpotInstanceRequest#instance_type}
    */
    readonly instanceType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#ipv6_address_count AwsSpotInstanceRequest#ipv6_address_count}
    */
    readonly ipv6AddressCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#ipv6_addresses AwsSpotInstanceRequest#ipv6_addresses}
    */
    readonly ipv6Addresses?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#key_name AwsSpotInstanceRequest#key_name}
    */
    readonly keyName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#launch_group AwsSpotInstanceRequest#launch_group}
    */
    readonly launchGroup?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#monitoring AwsSpotInstanceRequest#monitoring}
    */
    readonly monitoring?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#placement_group AwsSpotInstanceRequest#placement_group}
    */
    readonly placementGroup?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#placement_group_id AwsSpotInstanceRequest#placement_group_id}
    */
    readonly placementGroupId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#placement_partition_number AwsSpotInstanceRequest#placement_partition_number}
    */
    readonly placementPartitionNumber?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#private_ip AwsSpotInstanceRequest#private_ip}
    */
    readonly privateIp?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#region AwsSpotInstanceRequest#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#secondary_private_ips AwsSpotInstanceRequest#secondary_private_ips}
    */
    readonly secondaryPrivateIps?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#security_groups AwsSpotInstanceRequest#security_groups}
    */
    readonly securityGroups?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#source_dest_check AwsSpotInstanceRequest#source_dest_check}
    */
    readonly sourceDestCheck?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#spot_price AwsSpotInstanceRequest#spot_price}
    */
    readonly spotPrice?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#spot_type AwsSpotInstanceRequest#spot_type}
    */
    readonly spotType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#subnet_id AwsSpotInstanceRequest#subnet_id}
    */
    readonly subnetId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#tags AwsSpotInstanceRequest#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#tags_all AwsSpotInstanceRequest#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#tenancy AwsSpotInstanceRequest#tenancy}
    */
    readonly tenancy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#user_data AwsSpotInstanceRequest#user_data}
    */
    readonly userData?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#user_data_base64 AwsSpotInstanceRequest#user_data_base64}
    */
    readonly userDataBase64?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#user_data_replace_on_change AwsSpotInstanceRequest#user_data_replace_on_change}
    */
    readonly userDataReplaceOnChange?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#valid_from AwsSpotInstanceRequest#valid_from}
    */
    readonly validFrom?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#valid_until AwsSpotInstanceRequest#valid_until}
    */
    readonly validUntil?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#volume_tags AwsSpotInstanceRequest#volume_tags}
    */
    readonly volumeTags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#vpc_security_group_ids AwsSpotInstanceRequest#vpc_security_group_ids}
    */
    readonly vpcSecurityGroupIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#wait_for_fulfillment AwsSpotInstanceRequest#wait_for_fulfillment}
    */
    readonly waitForFulfillment?: boolean | cdktn.IResolvable;
    /**
    * capacity_reservation_specification block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#capacity_reservation_specification AwsSpotInstanceRequest#capacity_reservation_specification}
    */
    readonly capacityReservationSpecification?: AwsSpotInstanceRequest.CapacityReservationSpecificationProperty;
    /**
    * cpu_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#cpu_options AwsSpotInstanceRequest#cpu_options}
    */
    readonly cpuOptions?: AwsSpotInstanceRequest.CpuOptionsProperty;
    /**
    * credit_specification block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#credit_specification AwsSpotInstanceRequest#credit_specification}
    */
    readonly creditSpecification?: AwsSpotInstanceRequest.CreditSpecificationProperty;
    /**
    * ebs_block_device block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#ebs_block_device AwsSpotInstanceRequest#ebs_block_device}
    */
    readonly ebsBlockDevice?: AwsSpotInstanceRequest.EbsBlockDeviceProperty[] | cdktn.IResolvable;
    /**
    * enclave_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#enclave_options AwsSpotInstanceRequest#enclave_options}
    */
    readonly enclaveOptions?: AwsSpotInstanceRequest.EnclaveOptionsProperty;
    /**
    * ephemeral_block_device block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#ephemeral_block_device AwsSpotInstanceRequest#ephemeral_block_device}
    */
    readonly ephemeralBlockDevice?: AwsSpotInstanceRequest.EphemeralBlockDeviceProperty[] | cdktn.IResolvable;
    /**
    * launch_template block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#launch_template AwsSpotInstanceRequest#launch_template}
    */
    readonly launchTemplate?: AwsSpotInstanceRequest.LaunchTemplateProperty;
    /**
    * maintenance_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#maintenance_options AwsSpotInstanceRequest#maintenance_options}
    */
    readonly maintenanceOptions?: AwsSpotInstanceRequest.MaintenanceOptionsProperty;
    /**
    * metadata_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#metadata_options AwsSpotInstanceRequest#metadata_options}
    */
    readonly metadataOptions?: AwsSpotInstanceRequest.MetadataOptionsProperty;
    /**
    * network_interface block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#network_interface AwsSpotInstanceRequest#network_interface}
    */
    readonly networkInterface?: AwsSpotInstanceRequest.NetworkInterfaceProperty[] | cdktn.IResolvable;
    /**
    * private_dns_name_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#private_dns_name_options AwsSpotInstanceRequest#private_dns_name_options}
    */
    readonly privateDnsNameOptions?: AwsSpotInstanceRequest.PrivateDnsNameOptionsProperty;
    /**
    * root_block_device block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#root_block_device AwsSpotInstanceRequest#root_block_device}
    */
    readonly rootBlockDevice?: AwsSpotInstanceRequest.RootBlockDeviceProperty;
    /**
    * secondary_network_interface block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#secondary_network_interface AwsSpotInstanceRequest#secondary_network_interface}
    */
    readonly secondaryNetworkInterface?: AwsSpotInstanceRequest.SecondaryNetworkInterfaceProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#timeouts AwsSpotInstanceRequest#timeouts}
    */
    readonly timeouts?: AwsSpotInstanceRequest.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request aws_spot_instance_request}
*/
export declare class AwsSpotInstanceRequest extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_spot_instance_request";
    /**
    * Generates CDKTN code for importing a AwsSpotInstanceRequest resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSpotInstanceRequest to import
    * @param importFromId The id of the existing AwsSpotInstanceRequest that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSpotInstanceRequest to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request aws_spot_instance_request} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSpotInstanceRequestConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AwsSpotInstanceRequestConfig);
    private _ami?;
    get ami(): string;
    set ami(value: string);
    resetAmi(): void;
    get amiInput(): string | undefined;
    get arn(): string;
    private _associatePublicIpAddress?;
    get associatePublicIpAddress(): boolean | cdktn.IResolvable;
    set associatePublicIpAddress(value: boolean | cdktn.IResolvable);
    resetAssociatePublicIpAddress(): void;
    get associatePublicIpAddressInput(): boolean | cdktn.IResolvable | undefined;
    private _availabilityZone?;
    get availabilityZone(): string;
    set availabilityZone(value: string);
    resetAvailabilityZone(): void;
    get availabilityZoneInput(): string | undefined;
    private _disableApiStop?;
    get disableApiStop(): boolean | cdktn.IResolvable;
    set disableApiStop(value: boolean | cdktn.IResolvable);
    resetDisableApiStop(): void;
    get disableApiStopInput(): boolean | cdktn.IResolvable | undefined;
    private _disableApiTermination?;
    get disableApiTermination(): boolean | cdktn.IResolvable;
    set disableApiTermination(value: boolean | cdktn.IResolvable);
    resetDisableApiTermination(): void;
    get disableApiTerminationInput(): boolean | cdktn.IResolvable | undefined;
    private _ebsOptimized?;
    get ebsOptimized(): boolean | cdktn.IResolvable;
    set ebsOptimized(value: boolean | cdktn.IResolvable);
    resetEbsOptimized(): void;
    get ebsOptimizedInput(): boolean | cdktn.IResolvable | undefined;
    private _enablePrimaryIpv6?;
    get enablePrimaryIpv6(): boolean | cdktn.IResolvable;
    set enablePrimaryIpv6(value: boolean | cdktn.IResolvable);
    resetEnablePrimaryIpv6(): void;
    get enablePrimaryIpv6Input(): boolean | cdktn.IResolvable | undefined;
    private _forceDestroy?;
    get forceDestroy(): boolean | cdktn.IResolvable;
    set forceDestroy(value: boolean | cdktn.IResolvable);
    resetForceDestroy(): void;
    get forceDestroyInput(): boolean | cdktn.IResolvable | undefined;
    private _getPasswordData?;
    get fetchPasswordData(): boolean | cdktn.IResolvable;
    set fetchPasswordData(value: boolean | cdktn.IResolvable);
    resetFetchPasswordData(): void;
    get fetchPasswordDataInput(): boolean | cdktn.IResolvable | undefined;
    private _hibernation?;
    get hibernation(): boolean | cdktn.IResolvable;
    set hibernation(value: boolean | cdktn.IResolvable);
    resetHibernation(): void;
    get hibernationInput(): boolean | cdktn.IResolvable | undefined;
    private _hostId?;
    get hostId(): string;
    set hostId(value: string);
    resetHostId(): void;
    get hostIdInput(): string | undefined;
    private _hostResourceGroupArn?;
    get hostResourceGroupArn(): string;
    set hostResourceGroupArn(value: string);
    resetHostResourceGroupArn(): void;
    get hostResourceGroupArnInput(): string | undefined;
    private _iamInstanceProfile?;
    get iamInstanceProfile(): string;
    set iamInstanceProfile(value: string);
    resetIamInstanceProfile(): void;
    get iamInstanceProfileInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceInitiatedShutdownBehavior?;
    get instanceInitiatedShutdownBehavior(): string;
    set instanceInitiatedShutdownBehavior(value: string);
    resetInstanceInitiatedShutdownBehavior(): void;
    get instanceInitiatedShutdownBehaviorInput(): string | undefined;
    private _instanceInterruptionBehavior?;
    get instanceInterruptionBehavior(): string;
    set instanceInterruptionBehavior(value: string);
    resetInstanceInterruptionBehavior(): void;
    get instanceInterruptionBehaviorInput(): string | undefined;
    get instanceState(): string;
    private _instanceType?;
    get instanceType(): string;
    set instanceType(value: string);
    resetInstanceType(): void;
    get instanceTypeInput(): string | undefined;
    private _ipv6AddressCount?;
    get ipv6AddressCount(): number;
    set ipv6AddressCount(value: number);
    resetIpv6AddressCount(): void;
    get ipv6AddressCountInput(): number | undefined;
    private _ipv6Addresses?;
    get ipv6Addresses(): string[];
    set ipv6Addresses(value: string[]);
    resetIpv6Addresses(): void;
    get ipv6AddressesInput(): string[] | undefined;
    private _keyName?;
    get keyName(): string;
    set keyName(value: string);
    resetKeyName(): void;
    get keyNameInput(): string | undefined;
    private _launchGroup?;
    get launchGroup(): string;
    set launchGroup(value: string);
    resetLaunchGroup(): void;
    get launchGroupInput(): string | undefined;
    private _monitoring?;
    get monitoring(): boolean | cdktn.IResolvable;
    set monitoring(value: boolean | cdktn.IResolvable);
    resetMonitoring(): void;
    get monitoringInput(): boolean | cdktn.IResolvable | undefined;
    get outpostArn(): string;
    get passwordData(): string;
    private _placementGroup?;
    get placementGroup(): string;
    set placementGroup(value: string);
    resetPlacementGroup(): void;
    get placementGroupInput(): string | undefined;
    private _placementGroupId?;
    get placementGroupId(): string;
    set placementGroupId(value: string);
    resetPlacementGroupId(): void;
    get placementGroupIdInput(): string | undefined;
    private _placementPartitionNumber?;
    get placementPartitionNumber(): number;
    set placementPartitionNumber(value: number);
    resetPlacementPartitionNumber(): void;
    get placementPartitionNumberInput(): number | undefined;
    private _primaryNetworkInterface;
    get primaryNetworkInterface(): AwsSpotInstanceRequest.PrimaryNetworkInterfacePropertyList;
    get primaryNetworkInterfaceId(): string;
    get privateDns(): string;
    private _privateIp?;
    get privateIp(): string;
    set privateIp(value: string);
    resetPrivateIp(): void;
    get privateIpInput(): string | undefined;
    get publicDns(): string;
    get publicIp(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _secondaryPrivateIps?;
    get secondaryPrivateIps(): string[];
    set secondaryPrivateIps(value: string[]);
    resetSecondaryPrivateIps(): void;
    get secondaryPrivateIpsInput(): string[] | undefined;
    private _securityGroups?;
    get securityGroups(): string[];
    set securityGroups(value: string[]);
    resetSecurityGroups(): void;
    get securityGroupsInput(): string[] | undefined;
    private _sourceDestCheck?;
    get sourceDestCheck(): boolean | cdktn.IResolvable;
    set sourceDestCheck(value: boolean | cdktn.IResolvable);
    resetSourceDestCheck(): void;
    get sourceDestCheckInput(): boolean | cdktn.IResolvable | undefined;
    get spotBidStatus(): string;
    get spotInstanceId(): string;
    private _spotPrice?;
    get spotPrice(): string;
    set spotPrice(value: string);
    resetSpotPrice(): void;
    get spotPriceInput(): string | undefined;
    get spotRequestState(): string;
    private _spotType?;
    get spotType(): string;
    set spotType(value: string);
    resetSpotType(): void;
    get spotTypeInput(): string | undefined;
    private _subnetId?;
    get subnetId(): string;
    set subnetId(value: string);
    resetSubnetId(): void;
    get subnetIdInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _tenancy?;
    get tenancy(): string;
    set tenancy(value: string);
    resetTenancy(): void;
    get tenancyInput(): string | undefined;
    private _userData?;
    get userData(): string;
    set userData(value: string);
    resetUserData(): void;
    get userDataInput(): string | undefined;
    private _userDataBase64?;
    get userDataBase64(): string;
    set userDataBase64(value: string);
    resetUserDataBase64(): void;
    get userDataBase64Input(): string | undefined;
    private _userDataReplaceOnChange?;
    get userDataReplaceOnChange(): boolean | cdktn.IResolvable;
    set userDataReplaceOnChange(value: boolean | cdktn.IResolvable);
    resetUserDataReplaceOnChange(): void;
    get userDataReplaceOnChangeInput(): boolean | cdktn.IResolvable | undefined;
    private _validFrom?;
    get validFrom(): string;
    set validFrom(value: string);
    resetValidFrom(): void;
    get validFromInput(): string | undefined;
    private _validUntil?;
    get validUntil(): string;
    set validUntil(value: string);
    resetValidUntil(): void;
    get validUntilInput(): string | undefined;
    private _volumeTags?;
    get volumeTags(): {
        [key: string]: string;
    };
    set volumeTags(value: {
        [key: string]: string;
    });
    resetVolumeTags(): void;
    get volumeTagsInput(): {
        [key: string]: string;
    } | undefined;
    private _vpcSecurityGroupIds?;
    get vpcSecurityGroupIds(): string[];
    set vpcSecurityGroupIds(value: string[]);
    resetVpcSecurityGroupIds(): void;
    get vpcSecurityGroupIdsInput(): string[] | undefined;
    private _waitForFulfillment?;
    get waitForFulfillment(): boolean | cdktn.IResolvable;
    set waitForFulfillment(value: boolean | cdktn.IResolvable);
    resetWaitForFulfillment(): void;
    get waitForFulfillmentInput(): boolean | cdktn.IResolvable | undefined;
    private _capacityReservationSpecification;
    get capacityReservationSpecification(): AwsSpotInstanceRequest.CapacityReservationSpecificationPropertyOutputReference;
    putCapacityReservationSpecification(value: AwsSpotInstanceRequest.CapacityReservationSpecificationProperty): void;
    resetCapacityReservationSpecification(): void;
    get capacityReservationSpecificationInput(): AwsSpotInstanceRequest.CapacityReservationSpecificationProperty | undefined;
    private _cpuOptions;
    get cpuOptions(): AwsSpotInstanceRequest.CpuOptionsPropertyOutputReference;
    putCpuOptions(value: AwsSpotInstanceRequest.CpuOptionsProperty): void;
    resetCpuOptions(): void;
    get cpuOptionsInput(): AwsSpotInstanceRequest.CpuOptionsProperty | undefined;
    private _creditSpecification;
    get creditSpecification(): AwsSpotInstanceRequest.CreditSpecificationPropertyOutputReference;
    putCreditSpecification(value: AwsSpotInstanceRequest.CreditSpecificationProperty): void;
    resetCreditSpecification(): void;
    get creditSpecificationInput(): AwsSpotInstanceRequest.CreditSpecificationProperty | undefined;
    private _ebsBlockDevice;
    get ebsBlockDevice(): AwsSpotInstanceRequest.EbsBlockDevicePropertyList;
    putEbsBlockDevice(value: AwsSpotInstanceRequest.EbsBlockDeviceProperty[] | cdktn.IResolvable): void;
    resetEbsBlockDevice(): void;
    get ebsBlockDeviceInput(): cdktn.IResolvable | AwsSpotInstanceRequest.EbsBlockDeviceProperty[] | undefined;
    private _enclaveOptions;
    get enclaveOptions(): AwsSpotInstanceRequest.EnclaveOptionsPropertyOutputReference;
    putEnclaveOptions(value: AwsSpotInstanceRequest.EnclaveOptionsProperty): void;
    resetEnclaveOptions(): void;
    get enclaveOptionsInput(): AwsSpotInstanceRequest.EnclaveOptionsProperty | undefined;
    private _ephemeralBlockDevice;
    get ephemeralBlockDevice(): AwsSpotInstanceRequest.EphemeralBlockDevicePropertyList;
    putEphemeralBlockDevice(value: AwsSpotInstanceRequest.EphemeralBlockDeviceProperty[] | cdktn.IResolvable): void;
    resetEphemeralBlockDevice(): void;
    get ephemeralBlockDeviceInput(): cdktn.IResolvable | AwsSpotInstanceRequest.EphemeralBlockDeviceProperty[] | undefined;
    private _launchTemplate;
    get launchTemplate(): AwsSpotInstanceRequest.LaunchTemplatePropertyOutputReference;
    putLaunchTemplate(value: AwsSpotInstanceRequest.LaunchTemplateProperty): void;
    resetLaunchTemplate(): void;
    get launchTemplateInput(): AwsSpotInstanceRequest.LaunchTemplateProperty | undefined;
    private _maintenanceOptions;
    get maintenanceOptions(): AwsSpotInstanceRequest.MaintenanceOptionsPropertyOutputReference;
    putMaintenanceOptions(value: AwsSpotInstanceRequest.MaintenanceOptionsProperty): void;
    resetMaintenanceOptions(): void;
    get maintenanceOptionsInput(): AwsSpotInstanceRequest.MaintenanceOptionsProperty | undefined;
    private _metadataOptions;
    get metadataOptions(): AwsSpotInstanceRequest.MetadataOptionsPropertyOutputReference;
    putMetadataOptions(value: AwsSpotInstanceRequest.MetadataOptionsProperty): void;
    resetMetadataOptions(): void;
    get metadataOptionsInput(): AwsSpotInstanceRequest.MetadataOptionsProperty | undefined;
    private _networkInterface;
    get networkInterface(): AwsSpotInstanceRequest.NetworkInterfacePropertyList;
    putNetworkInterface(value: AwsSpotInstanceRequest.NetworkInterfaceProperty[] | cdktn.IResolvable): void;
    resetNetworkInterface(): void;
    get networkInterfaceInput(): cdktn.IResolvable | AwsSpotInstanceRequest.NetworkInterfaceProperty[] | undefined;
    private _privateDnsNameOptions;
    get privateDnsNameOptions(): AwsSpotInstanceRequest.PrivateDnsNameOptionsPropertyOutputReference;
    putPrivateDnsNameOptions(value: AwsSpotInstanceRequest.PrivateDnsNameOptionsProperty): void;
    resetPrivateDnsNameOptions(): void;
    get privateDnsNameOptionsInput(): AwsSpotInstanceRequest.PrivateDnsNameOptionsProperty | undefined;
    private _rootBlockDevice;
    get rootBlockDevice(): AwsSpotInstanceRequest.RootBlockDevicePropertyOutputReference;
    putRootBlockDevice(value: AwsSpotInstanceRequest.RootBlockDeviceProperty): void;
    resetRootBlockDevice(): void;
    get rootBlockDeviceInput(): AwsSpotInstanceRequest.RootBlockDeviceProperty | undefined;
    private _secondaryNetworkInterface;
    get secondaryNetworkInterface(): AwsSpotInstanceRequest.SecondaryNetworkInterfacePropertyList;
    putSecondaryNetworkInterface(value: AwsSpotInstanceRequest.SecondaryNetworkInterfaceProperty[] | cdktn.IResolvable): void;
    resetSecondaryNetworkInterface(): void;
    get secondaryNetworkInterfaceInput(): cdktn.IResolvable | AwsSpotInstanceRequest.SecondaryNetworkInterfaceProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsSpotInstanceRequest.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsSpotInstanceRequest.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsSpotInstanceRequest.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsSpotInstanceRequestPrimaryNetworkInterfacePropertyToTerraform(struct?: AwsSpotInstanceRequest.PrimaryNetworkInterfaceProperty): any;
export declare function awsSpotInstanceRequestPrimaryNetworkInterfacePropertyToHclTerraform(struct?: AwsSpotInstanceRequest.PrimaryNetworkInterfaceProperty): any;
export declare function awsSpotInstanceRequestCapacityReservationTargetPropertyToTerraform(struct?: AwsSpotInstanceRequest.CapacityReservationTargetPropertyOutputReference | AwsSpotInstanceRequest.CapacityReservationTargetProperty): any;
export declare function awsSpotInstanceRequestCapacityReservationTargetPropertyToHclTerraform(struct?: AwsSpotInstanceRequest.CapacityReservationTargetPropertyOutputReference | AwsSpotInstanceRequest.CapacityReservationTargetProperty): any;
export declare function awsSpotInstanceRequestCapacityReservationSpecificationPropertyToTerraform(struct?: AwsSpotInstanceRequest.CapacityReservationSpecificationPropertyOutputReference | AwsSpotInstanceRequest.CapacityReservationSpecificationProperty): any;
export declare function awsSpotInstanceRequestCapacityReservationSpecificationPropertyToHclTerraform(struct?: AwsSpotInstanceRequest.CapacityReservationSpecificationPropertyOutputReference | AwsSpotInstanceRequest.CapacityReservationSpecificationProperty): any;
export declare function awsSpotInstanceRequestCpuOptionsPropertyToTerraform(struct?: AwsSpotInstanceRequest.CpuOptionsPropertyOutputReference | AwsSpotInstanceRequest.CpuOptionsProperty): any;
export declare function awsSpotInstanceRequestCpuOptionsPropertyToHclTerraform(struct?: AwsSpotInstanceRequest.CpuOptionsPropertyOutputReference | AwsSpotInstanceRequest.CpuOptionsProperty): any;
export declare function awsSpotInstanceRequestCreditSpecificationPropertyToTerraform(struct?: AwsSpotInstanceRequest.CreditSpecificationPropertyOutputReference | AwsSpotInstanceRequest.CreditSpecificationProperty): any;
export declare function awsSpotInstanceRequestCreditSpecificationPropertyToHclTerraform(struct?: AwsSpotInstanceRequest.CreditSpecificationPropertyOutputReference | AwsSpotInstanceRequest.CreditSpecificationProperty): any;
export declare function awsSpotInstanceRequestEbsBlockDevicePropertyToTerraform(struct?: AwsSpotInstanceRequest.EbsBlockDeviceProperty | cdktn.IResolvable): any;
export declare function awsSpotInstanceRequestEbsBlockDevicePropertyToHclTerraform(struct?: AwsSpotInstanceRequest.EbsBlockDeviceProperty | cdktn.IResolvable): any;
export declare function awsSpotInstanceRequestEnclaveOptionsPropertyToTerraform(struct?: AwsSpotInstanceRequest.EnclaveOptionsPropertyOutputReference | AwsSpotInstanceRequest.EnclaveOptionsProperty): any;
export declare function awsSpotInstanceRequestEnclaveOptionsPropertyToHclTerraform(struct?: AwsSpotInstanceRequest.EnclaveOptionsPropertyOutputReference | AwsSpotInstanceRequest.EnclaveOptionsProperty): any;
export declare function awsSpotInstanceRequestEphemeralBlockDevicePropertyToTerraform(struct?: AwsSpotInstanceRequest.EphemeralBlockDeviceProperty | cdktn.IResolvable): any;
export declare function awsSpotInstanceRequestEphemeralBlockDevicePropertyToHclTerraform(struct?: AwsSpotInstanceRequest.EphemeralBlockDeviceProperty | cdktn.IResolvable): any;
export declare function awsSpotInstanceRequestLaunchTemplatePropertyToTerraform(struct?: AwsSpotInstanceRequest.LaunchTemplatePropertyOutputReference | AwsSpotInstanceRequest.LaunchTemplateProperty): any;
export declare function awsSpotInstanceRequestLaunchTemplatePropertyToHclTerraform(struct?: AwsSpotInstanceRequest.LaunchTemplatePropertyOutputReference | AwsSpotInstanceRequest.LaunchTemplateProperty): any;
export declare function awsSpotInstanceRequestMaintenanceOptionsPropertyToTerraform(struct?: AwsSpotInstanceRequest.MaintenanceOptionsPropertyOutputReference | AwsSpotInstanceRequest.MaintenanceOptionsProperty): any;
export declare function awsSpotInstanceRequestMaintenanceOptionsPropertyToHclTerraform(struct?: AwsSpotInstanceRequest.MaintenanceOptionsPropertyOutputReference | AwsSpotInstanceRequest.MaintenanceOptionsProperty): any;
export declare function awsSpotInstanceRequestMetadataOptionsPropertyToTerraform(struct?: AwsSpotInstanceRequest.MetadataOptionsPropertyOutputReference | AwsSpotInstanceRequest.MetadataOptionsProperty): any;
export declare function awsSpotInstanceRequestMetadataOptionsPropertyToHclTerraform(struct?: AwsSpotInstanceRequest.MetadataOptionsPropertyOutputReference | AwsSpotInstanceRequest.MetadataOptionsProperty): any;
export declare function awsSpotInstanceRequestNetworkInterfacePropertyToTerraform(struct?: AwsSpotInstanceRequest.NetworkInterfaceProperty | cdktn.IResolvable): any;
export declare function awsSpotInstanceRequestNetworkInterfacePropertyToHclTerraform(struct?: AwsSpotInstanceRequest.NetworkInterfaceProperty | cdktn.IResolvable): any;
export declare function awsSpotInstanceRequestPrivateDnsNameOptionsPropertyToTerraform(struct?: AwsSpotInstanceRequest.PrivateDnsNameOptionsPropertyOutputReference | AwsSpotInstanceRequest.PrivateDnsNameOptionsProperty): any;
export declare function awsSpotInstanceRequestPrivateDnsNameOptionsPropertyToHclTerraform(struct?: AwsSpotInstanceRequest.PrivateDnsNameOptionsPropertyOutputReference | AwsSpotInstanceRequest.PrivateDnsNameOptionsProperty): any;
export declare function awsSpotInstanceRequestRootBlockDevicePropertyToTerraform(struct?: AwsSpotInstanceRequest.RootBlockDevicePropertyOutputReference | AwsSpotInstanceRequest.RootBlockDeviceProperty): any;
export declare function awsSpotInstanceRequestRootBlockDevicePropertyToHclTerraform(struct?: AwsSpotInstanceRequest.RootBlockDevicePropertyOutputReference | AwsSpotInstanceRequest.RootBlockDeviceProperty): any;
export declare function awsSpotInstanceRequestSecondaryNetworkInterfacePropertyToTerraform(struct?: AwsSpotInstanceRequest.SecondaryNetworkInterfaceProperty | cdktn.IResolvable): any;
export declare function awsSpotInstanceRequestSecondaryNetworkInterfacePropertyToHclTerraform(struct?: AwsSpotInstanceRequest.SecondaryNetworkInterfaceProperty | cdktn.IResolvable): any;
export declare function awsSpotInstanceRequestTimeoutsPropertyToTerraform(struct?: AwsSpotInstanceRequest.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsSpotInstanceRequestTimeoutsPropertyToHclTerraform(struct?: AwsSpotInstanceRequest.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsSpotInstanceRequest {
    interface PrimaryNetworkInterfaceProperty {
    }
    class PrimaryNetworkInterfacePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PrimaryNetworkInterfaceProperty | undefined;
        set internalValue(value: PrimaryNetworkInterfaceProperty | undefined);
        get deleteOnTermination(): cdktn.IResolvable;
        get networkInterfaceId(): string;
    }
    class PrimaryNetworkInterfacePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PrimaryNetworkInterfacePropertyOutputReference;
    }
    interface CapacityReservationTargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#capacity_reservation_id AwsSpotInstanceRequest#capacity_reservation_id}
        */
        readonly capacityReservationId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#capacity_reservation_resource_group_arn AwsSpotInstanceRequest#capacity_reservation_resource_group_arn}
        */
        readonly capacityReservationResourceGroupArn?: string;
    }
    class CapacityReservationTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CapacityReservationTargetProperty | undefined;
        set internalValue(value: CapacityReservationTargetProperty | undefined);
        private _capacityReservationId?;
        get capacityReservationId(): string;
        set capacityReservationId(value: string);
        resetCapacityReservationId(): void;
        get capacityReservationIdInput(): string | undefined;
        private _capacityReservationResourceGroupArn?;
        get capacityReservationResourceGroupArn(): string;
        set capacityReservationResourceGroupArn(value: string);
        resetCapacityReservationResourceGroupArn(): void;
        get capacityReservationResourceGroupArnInput(): string | undefined;
    }
    interface CapacityReservationSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#capacity_reservation_preference AwsSpotInstanceRequest#capacity_reservation_preference}
        */
        readonly capacityReservationPreference?: string;
        /**
        * capacity_reservation_target block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#capacity_reservation_target AwsSpotInstanceRequest#capacity_reservation_target}
        */
        readonly capacityReservationTarget?: CapacityReservationTargetProperty;
    }
    class CapacityReservationSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CapacityReservationSpecificationProperty | undefined;
        set internalValue(value: CapacityReservationSpecificationProperty | undefined);
        private _capacityReservationPreference?;
        get capacityReservationPreference(): string;
        set capacityReservationPreference(value: string);
        resetCapacityReservationPreference(): void;
        get capacityReservationPreferenceInput(): string | undefined;
        private _capacityReservationTarget;
        get capacityReservationTarget(): CapacityReservationTargetPropertyOutputReference;
        putCapacityReservationTarget(value: CapacityReservationTargetProperty): void;
        resetCapacityReservationTarget(): void;
        get capacityReservationTargetInput(): CapacityReservationTargetProperty | undefined;
    }
    interface CpuOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#amd_sev_snp AwsSpotInstanceRequest#amd_sev_snp}
        */
        readonly amdSevSnp?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#core_count AwsSpotInstanceRequest#core_count}
        */
        readonly coreCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#nested_virtualization AwsSpotInstanceRequest#nested_virtualization}
        */
        readonly nestedVirtualization?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#threads_per_core AwsSpotInstanceRequest#threads_per_core}
        */
        readonly threadsPerCore?: number;
    }
    class CpuOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CpuOptionsProperty | undefined;
        set internalValue(value: CpuOptionsProperty | undefined);
        private _amdSevSnp?;
        get amdSevSnp(): string;
        set amdSevSnp(value: string);
        resetAmdSevSnp(): void;
        get amdSevSnpInput(): string | undefined;
        private _coreCount?;
        get coreCount(): number;
        set coreCount(value: number);
        resetCoreCount(): void;
        get coreCountInput(): number | undefined;
        private _nestedVirtualization?;
        get nestedVirtualization(): string;
        set nestedVirtualization(value: string);
        resetNestedVirtualization(): void;
        get nestedVirtualizationInput(): string | undefined;
        private _threadsPerCore?;
        get threadsPerCore(): number;
        set threadsPerCore(value: number);
        resetThreadsPerCore(): void;
        get threadsPerCoreInput(): number | undefined;
    }
    interface CreditSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#cpu_credits AwsSpotInstanceRequest#cpu_credits}
        */
        readonly cpuCredits?: string;
    }
    class CreditSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CreditSpecificationProperty | undefined;
        set internalValue(value: CreditSpecificationProperty | undefined);
        private _cpuCredits?;
        get cpuCredits(): string;
        set cpuCredits(value: string);
        resetCpuCredits(): void;
        get cpuCreditsInput(): string | undefined;
    }
    interface EbsBlockDeviceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#delete_on_termination AwsSpotInstanceRequest#delete_on_termination}
        */
        readonly deleteOnTermination?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#device_name AwsSpotInstanceRequest#device_name}
        */
        readonly deviceName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#encrypted AwsSpotInstanceRequest#encrypted}
        */
        readonly encrypted?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#iops AwsSpotInstanceRequest#iops}
        */
        readonly iops?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#kms_key_id AwsSpotInstanceRequest#kms_key_id}
        */
        readonly kmsKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#snapshot_id AwsSpotInstanceRequest#snapshot_id}
        */
        readonly snapshotId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#tags AwsSpotInstanceRequest#tags}
        */
        readonly tags?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#tags_all AwsSpotInstanceRequest#tags_all}
        */
        readonly tagsAll?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#throughput AwsSpotInstanceRequest#throughput}
        */
        readonly throughput?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#volume_size AwsSpotInstanceRequest#volume_size}
        */
        readonly volumeSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#volume_type AwsSpotInstanceRequest#volume_type}
        */
        readonly volumeType?: string;
    }
    class EbsBlockDevicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EbsBlockDeviceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EbsBlockDeviceProperty | cdktn.IResolvable | undefined);
        private _deleteOnTermination?;
        get deleteOnTermination(): boolean | cdktn.IResolvable;
        set deleteOnTermination(value: boolean | cdktn.IResolvable);
        resetDeleteOnTermination(): void;
        get deleteOnTerminationInput(): boolean | cdktn.IResolvable | undefined;
        private _deviceName?;
        get deviceName(): string;
        set deviceName(value: string);
        get deviceNameInput(): string | undefined;
        private _encrypted?;
        get encrypted(): boolean | cdktn.IResolvable;
        set encrypted(value: boolean | cdktn.IResolvable);
        resetEncrypted(): void;
        get encryptedInput(): boolean | cdktn.IResolvable | undefined;
        private _iops?;
        get iops(): number;
        set iops(value: number);
        resetIops(): void;
        get iopsInput(): number | undefined;
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        resetKmsKeyId(): void;
        get kmsKeyIdInput(): string | undefined;
        private _snapshotId?;
        get snapshotId(): string;
        set snapshotId(value: string);
        resetSnapshotId(): void;
        get snapshotIdInput(): string | undefined;
        private _tags?;
        get tags(): {
            [key: string]: string;
        };
        set tags(value: {
            [key: string]: string;
        });
        resetTags(): void;
        get tagsInput(): {
            [key: string]: string;
        } | undefined;
        private _tagsAll?;
        get tagsAll(): {
            [key: string]: string;
        };
        set tagsAll(value: {
            [key: string]: string;
        });
        resetTagsAll(): void;
        get tagsAllInput(): {
            [key: string]: string;
        } | undefined;
        private _throughput?;
        get throughput(): number;
        set throughput(value: number);
        resetThroughput(): void;
        get throughputInput(): number | undefined;
        get volumeId(): string;
        private _volumeSize?;
        get volumeSize(): number;
        set volumeSize(value: number);
        resetVolumeSize(): void;
        get volumeSizeInput(): number | undefined;
        private _volumeType?;
        get volumeType(): string;
        set volumeType(value: string);
        resetVolumeType(): void;
        get volumeTypeInput(): string | undefined;
    }
    class EbsBlockDevicePropertyList extends cdktn.ComplexList {
        internalValue?: EbsBlockDeviceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EbsBlockDevicePropertyOutputReference;
    }
    interface EnclaveOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#enabled AwsSpotInstanceRequest#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
    }
    class EnclaveOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EnclaveOptionsProperty | undefined;
        set internalValue(value: EnclaveOptionsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface EphemeralBlockDeviceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#device_name AwsSpotInstanceRequest#device_name}
        */
        readonly deviceName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#no_device AwsSpotInstanceRequest#no_device}
        */
        readonly noDevice?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#virtual_name AwsSpotInstanceRequest#virtual_name}
        */
        readonly virtualName?: string;
    }
    class EphemeralBlockDevicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EphemeralBlockDeviceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EphemeralBlockDeviceProperty | cdktn.IResolvable | undefined);
        private _deviceName?;
        get deviceName(): string;
        set deviceName(value: string);
        get deviceNameInput(): string | undefined;
        private _noDevice?;
        get noDevice(): boolean | cdktn.IResolvable;
        set noDevice(value: boolean | cdktn.IResolvable);
        resetNoDevice(): void;
        get noDeviceInput(): boolean | cdktn.IResolvable | undefined;
        private _virtualName?;
        get virtualName(): string;
        set virtualName(value: string);
        resetVirtualName(): void;
        get virtualNameInput(): string | undefined;
    }
    class EphemeralBlockDevicePropertyList extends cdktn.ComplexList {
        internalValue?: EphemeralBlockDeviceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EphemeralBlockDevicePropertyOutputReference;
    }
    interface LaunchTemplateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#id AwsSpotInstanceRequest#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#name AwsSpotInstanceRequest#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#version AwsSpotInstanceRequest#version}
        */
        readonly version?: string;
    }
    class LaunchTemplatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LaunchTemplateProperty | undefined;
        set internalValue(value: LaunchTemplateProperty | undefined);
        private _id?;
        get id(): string;
        set id(value: string);
        resetId(): void;
        get idInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _version?;
        get version(): string;
        set version(value: string);
        resetVersion(): void;
        get versionInput(): string | undefined;
    }
    interface MaintenanceOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#auto_recovery AwsSpotInstanceRequest#auto_recovery}
        */
        readonly autoRecovery?: string;
    }
    class MaintenanceOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MaintenanceOptionsProperty | undefined;
        set internalValue(value: MaintenanceOptionsProperty | undefined);
        private _autoRecovery?;
        get autoRecovery(): string;
        set autoRecovery(value: string);
        resetAutoRecovery(): void;
        get autoRecoveryInput(): string | undefined;
    }
    interface MetadataOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#http_endpoint AwsSpotInstanceRequest#http_endpoint}
        */
        readonly httpEndpoint?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#http_protocol_ipv6 AwsSpotInstanceRequest#http_protocol_ipv6}
        */
        readonly httpProtocolIpv6?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#http_put_response_hop_limit AwsSpotInstanceRequest#http_put_response_hop_limit}
        */
        readonly httpPutResponseHopLimit?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#http_tokens AwsSpotInstanceRequest#http_tokens}
        */
        readonly httpTokens?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#instance_metadata_tags AwsSpotInstanceRequest#instance_metadata_tags}
        */
        readonly instanceMetadataTags?: string;
    }
    class MetadataOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MetadataOptionsProperty | undefined;
        set internalValue(value: MetadataOptionsProperty | undefined);
        private _httpEndpoint?;
        get httpEndpoint(): string;
        set httpEndpoint(value: string);
        resetHttpEndpoint(): void;
        get httpEndpointInput(): string | undefined;
        private _httpProtocolIpv6?;
        get httpProtocolIpv6(): string;
        set httpProtocolIpv6(value: string);
        resetHttpProtocolIpv6(): void;
        get httpProtocolIpv6Input(): string | undefined;
        private _httpPutResponseHopLimit?;
        get httpPutResponseHopLimit(): number;
        set httpPutResponseHopLimit(value: number);
        resetHttpPutResponseHopLimit(): void;
        get httpPutResponseHopLimitInput(): number | undefined;
        private _httpTokens?;
        get httpTokens(): string;
        set httpTokens(value: string);
        resetHttpTokens(): void;
        get httpTokensInput(): string | undefined;
        private _instanceMetadataTags?;
        get instanceMetadataTags(): string;
        set instanceMetadataTags(value: string);
        resetInstanceMetadataTags(): void;
        get instanceMetadataTagsInput(): string | undefined;
    }
    interface NetworkInterfaceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#delete_on_termination AwsSpotInstanceRequest#delete_on_termination}
        */
        readonly deleteOnTermination?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#device_index AwsSpotInstanceRequest#device_index}
        */
        readonly deviceIndex: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#network_interface_id AwsSpotInstanceRequest#network_interface_id}
        */
        readonly networkInterfaceId: string;
    }
    class NetworkInterfacePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NetworkInterfaceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NetworkInterfaceProperty | cdktn.IResolvable | undefined);
        private _deleteOnTermination?;
        get deleteOnTermination(): boolean | cdktn.IResolvable;
        set deleteOnTermination(value: boolean | cdktn.IResolvable);
        resetDeleteOnTermination(): void;
        get deleteOnTerminationInput(): boolean | cdktn.IResolvable | undefined;
        private _deviceIndex?;
        get deviceIndex(): number;
        set deviceIndex(value: number);
        get deviceIndexInput(): number | undefined;
        get networkCardIndex(): number;
        private _networkInterfaceId?;
        get networkInterfaceId(): string;
        set networkInterfaceId(value: string);
        get networkInterfaceIdInput(): string | undefined;
    }
    class NetworkInterfacePropertyList extends cdktn.ComplexList {
        internalValue?: NetworkInterfaceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NetworkInterfacePropertyOutputReference;
    }
    interface PrivateDnsNameOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#enable_resource_name_dns_a_record AwsSpotInstanceRequest#enable_resource_name_dns_a_record}
        */
        readonly enableResourceNameDnsARecord?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#enable_resource_name_dns_aaaa_record AwsSpotInstanceRequest#enable_resource_name_dns_aaaa_record}
        */
        readonly enableResourceNameDnsAaaaRecord?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#hostname_type AwsSpotInstanceRequest#hostname_type}
        */
        readonly hostnameType?: string;
    }
    class PrivateDnsNameOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PrivateDnsNameOptionsProperty | undefined;
        set internalValue(value: PrivateDnsNameOptionsProperty | undefined);
        private _enableResourceNameDnsARecord?;
        get enableResourceNameDnsARecord(): boolean | cdktn.IResolvable;
        set enableResourceNameDnsARecord(value: boolean | cdktn.IResolvable);
        resetEnableResourceNameDnsARecord(): void;
        get enableResourceNameDnsARecordInput(): boolean | cdktn.IResolvable | undefined;
        private _enableResourceNameDnsAaaaRecord?;
        get enableResourceNameDnsAaaaRecord(): boolean | cdktn.IResolvable;
        set enableResourceNameDnsAaaaRecord(value: boolean | cdktn.IResolvable);
        resetEnableResourceNameDnsAaaaRecord(): void;
        get enableResourceNameDnsAaaaRecordInput(): boolean | cdktn.IResolvable | undefined;
        private _hostnameType?;
        get hostnameType(): string;
        set hostnameType(value: string);
        resetHostnameType(): void;
        get hostnameTypeInput(): string | undefined;
    }
    interface RootBlockDeviceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#delete_on_termination AwsSpotInstanceRequest#delete_on_termination}
        */
        readonly deleteOnTermination?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#encrypted AwsSpotInstanceRequest#encrypted}
        */
        readonly encrypted?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#iops AwsSpotInstanceRequest#iops}
        */
        readonly iops?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#kms_key_id AwsSpotInstanceRequest#kms_key_id}
        */
        readonly kmsKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#tags AwsSpotInstanceRequest#tags}
        */
        readonly tags?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#tags_all AwsSpotInstanceRequest#tags_all}
        */
        readonly tagsAll?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#throughput AwsSpotInstanceRequest#throughput}
        */
        readonly throughput?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#volume_size AwsSpotInstanceRequest#volume_size}
        */
        readonly volumeSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#volume_type AwsSpotInstanceRequest#volume_type}
        */
        readonly volumeType?: string;
    }
    class RootBlockDevicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RootBlockDeviceProperty | undefined;
        set internalValue(value: RootBlockDeviceProperty | undefined);
        private _deleteOnTermination?;
        get deleteOnTermination(): boolean | cdktn.IResolvable;
        set deleteOnTermination(value: boolean | cdktn.IResolvable);
        resetDeleteOnTermination(): void;
        get deleteOnTerminationInput(): boolean | cdktn.IResolvable | undefined;
        get deviceName(): string;
        private _encrypted?;
        get encrypted(): boolean | cdktn.IResolvable;
        set encrypted(value: boolean | cdktn.IResolvable);
        resetEncrypted(): void;
        get encryptedInput(): boolean | cdktn.IResolvable | undefined;
        private _iops?;
        get iops(): number;
        set iops(value: number);
        resetIops(): void;
        get iopsInput(): number | undefined;
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        resetKmsKeyId(): void;
        get kmsKeyIdInput(): string | undefined;
        private _tags?;
        get tags(): {
            [key: string]: string;
        };
        set tags(value: {
            [key: string]: string;
        });
        resetTags(): void;
        get tagsInput(): {
            [key: string]: string;
        } | undefined;
        private _tagsAll?;
        get tagsAll(): {
            [key: string]: string;
        };
        set tagsAll(value: {
            [key: string]: string;
        });
        resetTagsAll(): void;
        get tagsAllInput(): {
            [key: string]: string;
        } | undefined;
        private _throughput?;
        get throughput(): number;
        set throughput(value: number);
        resetThroughput(): void;
        get throughputInput(): number | undefined;
        get volumeId(): string;
        private _volumeSize?;
        get volumeSize(): number;
        set volumeSize(value: number);
        resetVolumeSize(): void;
        get volumeSizeInput(): number | undefined;
        private _volumeType?;
        get volumeType(): string;
        set volumeType(value: string);
        resetVolumeType(): void;
        get volumeTypeInput(): string | undefined;
    }
    interface SecondaryNetworkInterfaceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#delete_on_termination AwsSpotInstanceRequest#delete_on_termination}
        */
        readonly deleteOnTermination?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#device_index AwsSpotInstanceRequest#device_index}
        */
        readonly deviceIndex?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#interface_type AwsSpotInstanceRequest#interface_type}
        */
        readonly interfaceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#network_card_index AwsSpotInstanceRequest#network_card_index}
        */
        readonly networkCardIndex: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#private_ip_address_count AwsSpotInstanceRequest#private_ip_address_count}
        */
        readonly privateIpAddressCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#secondary_subnet_id AwsSpotInstanceRequest#secondary_subnet_id}
        */
        readonly secondarySubnetId: string;
    }
    class SecondaryNetworkInterfacePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SecondaryNetworkInterfaceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SecondaryNetworkInterfaceProperty | cdktn.IResolvable | undefined);
        private _deleteOnTermination?;
        get deleteOnTermination(): boolean | cdktn.IResolvable;
        set deleteOnTermination(value: boolean | cdktn.IResolvable);
        resetDeleteOnTermination(): void;
        get deleteOnTerminationInput(): boolean | cdktn.IResolvable | undefined;
        private _deviceIndex?;
        get deviceIndex(): number;
        set deviceIndex(value: number);
        resetDeviceIndex(): void;
        get deviceIndexInput(): number | undefined;
        private _interfaceType?;
        get interfaceType(): string;
        set interfaceType(value: string);
        resetInterfaceType(): void;
        get interfaceTypeInput(): string | undefined;
        get macAddress(): string;
        private _networkCardIndex?;
        get networkCardIndex(): number;
        set networkCardIndex(value: number);
        get networkCardIndexInput(): number | undefined;
        private _privateIpAddressCount?;
        get privateIpAddressCount(): number;
        set privateIpAddressCount(value: number);
        resetPrivateIpAddressCount(): void;
        get privateIpAddressCountInput(): number | undefined;
        get privateIpAddresses(): string[];
        get secondaryInterfaceId(): string;
        get secondaryNetworkId(): string;
        private _secondarySubnetId?;
        get secondarySubnetId(): string;
        set secondarySubnetId(value: string);
        get secondarySubnetIdInput(): string | undefined;
        get sourceDestCheck(): cdktn.IResolvable;
        get status(): string;
    }
    class SecondaryNetworkInterfacePropertyList extends cdktn.ComplexList {
        internalValue?: SecondaryNetworkInterfaceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SecondaryNetworkInterfacePropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#create AwsSpotInstanceRequest#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#delete AwsSpotInstanceRequest#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#read AwsSpotInstanceRequest#read}
        */
        readonly read?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _read?;
        get read(): string;
        set read(value: string);
        resetRead(): void;
        get readInput(): string | undefined;
    }
}
