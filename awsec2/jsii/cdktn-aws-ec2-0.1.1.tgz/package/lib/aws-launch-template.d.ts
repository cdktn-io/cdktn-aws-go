import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsLaunchTemplateConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#default_version AwsLaunchTemplate#default_version}
    */
    readonly defaultVersion?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#description AwsLaunchTemplate#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#disable_api_stop AwsLaunchTemplate#disable_api_stop}
    */
    readonly disableApiStop?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#disable_api_termination AwsLaunchTemplate#disable_api_termination}
    */
    readonly disableApiTermination?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#ebs_optimized AwsLaunchTemplate#ebs_optimized}
    */
    readonly ebsOptimized?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#id AwsLaunchTemplate#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#image_id AwsLaunchTemplate#image_id}
    */
    readonly imageId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#instance_initiated_shutdown_behavior AwsLaunchTemplate#instance_initiated_shutdown_behavior}
    */
    readonly instanceInitiatedShutdownBehavior?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#instance_type AwsLaunchTemplate#instance_type}
    */
    readonly instanceType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#kernel_id AwsLaunchTemplate#kernel_id}
    */
    readonly kernelId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#key_name AwsLaunchTemplate#key_name}
    */
    readonly keyName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#name AwsLaunchTemplate#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#name_prefix AwsLaunchTemplate#name_prefix}
    */
    readonly namePrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#ram_disk_id AwsLaunchTemplate#ram_disk_id}
    */
    readonly ramDiskId?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#region AwsLaunchTemplate#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#security_group_names AwsLaunchTemplate#security_group_names}
    */
    readonly securityGroupNames?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#tags AwsLaunchTemplate#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#tags_all AwsLaunchTemplate#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#update_default_version AwsLaunchTemplate#update_default_version}
    */
    readonly updateDefaultVersion?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#user_data AwsLaunchTemplate#user_data}
    */
    readonly userData?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#vpc_security_group_ids AwsLaunchTemplate#vpc_security_group_ids}
    */
    readonly vpcSecurityGroupIds?: string[];
    /**
    * block_device_mappings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#block_device_mappings AwsLaunchTemplate#block_device_mappings}
    */
    readonly blockDeviceMappings?: AwsLaunchTemplate.BlockDeviceMappingsProperty[] | cdktn.IResolvable;
    /**
    * capacity_reservation_specification block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#capacity_reservation_specification AwsLaunchTemplate#capacity_reservation_specification}
    */
    readonly capacityReservationSpecification?: AwsLaunchTemplate.CapacityReservationSpecificationProperty;
    /**
    * cpu_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#cpu_options AwsLaunchTemplate#cpu_options}
    */
    readonly cpuOptions?: AwsLaunchTemplate.CpuOptionsProperty;
    /**
    * credit_specification block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#credit_specification AwsLaunchTemplate#credit_specification}
    */
    readonly creditSpecification?: AwsLaunchTemplate.CreditSpecificationProperty;
    /**
    * enclave_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#enclave_options AwsLaunchTemplate#enclave_options}
    */
    readonly enclaveOptions?: AwsLaunchTemplate.EnclaveOptionsProperty;
    /**
    * hibernation_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#hibernation_options AwsLaunchTemplate#hibernation_options}
    */
    readonly hibernationOptions?: AwsLaunchTemplate.HibernationOptionsProperty;
    /**
    * iam_instance_profile block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#iam_instance_profile AwsLaunchTemplate#iam_instance_profile}
    */
    readonly iamInstanceProfile?: AwsLaunchTemplate.IamInstanceProfileProperty;
    /**
    * instance_market_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#instance_market_options AwsLaunchTemplate#instance_market_options}
    */
    readonly instanceMarketOptions?: AwsLaunchTemplate.InstanceMarketOptionsProperty;
    /**
    * instance_requirements block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#instance_requirements AwsLaunchTemplate#instance_requirements}
    */
    readonly instanceRequirements?: AwsLaunchTemplate.InstanceRequirementsProperty;
    /**
    * license_specification block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#license_specification AwsLaunchTemplate#license_specification}
    */
    readonly licenseSpecification?: AwsLaunchTemplate.LicenseSpecificationProperty[] | cdktn.IResolvable;
    /**
    * maintenance_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#maintenance_options AwsLaunchTemplate#maintenance_options}
    */
    readonly maintenanceOptions?: AwsLaunchTemplate.MaintenanceOptionsProperty;
    /**
    * metadata_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#metadata_options AwsLaunchTemplate#metadata_options}
    */
    readonly metadataOptions?: AwsLaunchTemplate.MetadataOptionsProperty;
    /**
    * monitoring block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#monitoring AwsLaunchTemplate#monitoring}
    */
    readonly monitoring?: AwsLaunchTemplate.MonitoringProperty;
    /**
    * network_interfaces block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#network_interfaces AwsLaunchTemplate#network_interfaces}
    */
    readonly networkInterfaces?: AwsLaunchTemplate.NetworkInterfacesProperty[] | cdktn.IResolvable;
    /**
    * network_performance_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#network_performance_options AwsLaunchTemplate#network_performance_options}
    */
    readonly networkPerformanceOptions?: AwsLaunchTemplate.NetworkPerformanceOptionsProperty;
    /**
    * placement block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#placement AwsLaunchTemplate#placement}
    */
    readonly placement?: AwsLaunchTemplate.PlacementProperty;
    /**
    * private_dns_name_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#private_dns_name_options AwsLaunchTemplate#private_dns_name_options}
    */
    readonly privateDnsNameOptions?: AwsLaunchTemplate.PrivateDnsNameOptionsProperty;
    /**
    * secondary_interfaces block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#secondary_interfaces AwsLaunchTemplate#secondary_interfaces}
    */
    readonly secondaryInterfaces?: AwsLaunchTemplate.SecondaryInterfacesProperty[] | cdktn.IResolvable;
    /**
    * tag_specifications block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#tag_specifications AwsLaunchTemplate#tag_specifications}
    */
    readonly tagSpecifications?: AwsLaunchTemplate.TagSpecificationsProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template aws_launch_template}
*/
export declare class AwsLaunchTemplate extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_launch_template";
    /**
    * Generates CDKTN code for importing a AwsLaunchTemplate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsLaunchTemplate to import
    * @param importFromId The id of the existing AwsLaunchTemplate that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsLaunchTemplate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template aws_launch_template} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsLaunchTemplateConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AwsLaunchTemplateConfig);
    get arn(): string;
    private _defaultVersion?;
    get defaultVersion(): number;
    set defaultVersion(value: number);
    resetDefaultVersion(): void;
    get defaultVersionInput(): number | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _disableApiStop?;
    get disableApiStop(): boolean | cdktn.IResolvable;
    set disableApiStop(value: boolean | cdktn.IResolvable);
    resetDisableApiStop(): void;
    get disableApiStopInput(): boolean | cdktn.IResolvable | undefined;
    private _disableApiTermination?;
    get disableApiTermination(): boolean | cdktn.IResolvable;
    set disableApiTermination(value: boolean | cdktn.IResolvable);
    resetDisableApiTermination(): void;
    get disableApiTerminationInput(): boolean | cdktn.IResolvable | undefined;
    private _ebsOptimized?;
    get ebsOptimized(): string;
    set ebsOptimized(value: string);
    resetEbsOptimized(): void;
    get ebsOptimizedInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _imageId?;
    get imageId(): string;
    set imageId(value: string);
    resetImageId(): void;
    get imageIdInput(): string | undefined;
    private _instanceInitiatedShutdownBehavior?;
    get instanceInitiatedShutdownBehavior(): string;
    set instanceInitiatedShutdownBehavior(value: string);
    resetInstanceInitiatedShutdownBehavior(): void;
    get instanceInitiatedShutdownBehaviorInput(): string | undefined;
    private _instanceType?;
    get instanceType(): string;
    set instanceType(value: string);
    resetInstanceType(): void;
    get instanceTypeInput(): string | undefined;
    private _kernelId?;
    get kernelId(): string;
    set kernelId(value: string);
    resetKernelId(): void;
    get kernelIdInput(): string | undefined;
    private _keyName?;
    get keyName(): string;
    set keyName(value: string);
    resetKeyName(): void;
    get keyNameInput(): string | undefined;
    get latestVersion(): number;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namePrefix?;
    get namePrefix(): string;
    set namePrefix(value: string);
    resetNamePrefix(): void;
    get namePrefixInput(): string | undefined;
    private _ramDiskId?;
    get ramDiskId(): string;
    set ramDiskId(value: string);
    resetRamDiskId(): void;
    get ramDiskIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _securityGroupNames?;
    get securityGroupNames(): string[];
    set securityGroupNames(value: string[]);
    resetSecurityGroupNames(): void;
    get securityGroupNamesInput(): string[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _updateDefaultVersion?;
    get updateDefaultVersion(): boolean | cdktn.IResolvable;
    set updateDefaultVersion(value: boolean | cdktn.IResolvable);
    resetUpdateDefaultVersion(): void;
    get updateDefaultVersionInput(): boolean | cdktn.IResolvable | undefined;
    private _userData?;
    get userData(): string;
    set userData(value: string);
    resetUserData(): void;
    get userDataInput(): string | undefined;
    private _vpcSecurityGroupIds?;
    get vpcSecurityGroupIds(): string[];
    set vpcSecurityGroupIds(value: string[]);
    resetVpcSecurityGroupIds(): void;
    get vpcSecurityGroupIdsInput(): string[] | undefined;
    private _blockDeviceMappings;
    get blockDeviceMappings(): AwsLaunchTemplate.BlockDeviceMappingsPropertyList;
    putBlockDeviceMappings(value: AwsLaunchTemplate.BlockDeviceMappingsProperty[] | cdktn.IResolvable): void;
    resetBlockDeviceMappings(): void;
    get blockDeviceMappingsInput(): cdktn.IResolvable | AwsLaunchTemplate.BlockDeviceMappingsProperty[] | undefined;
    private _capacityReservationSpecification;
    get capacityReservationSpecification(): AwsLaunchTemplate.CapacityReservationSpecificationPropertyOutputReference;
    putCapacityReservationSpecification(value: AwsLaunchTemplate.CapacityReservationSpecificationProperty): void;
    resetCapacityReservationSpecification(): void;
    get capacityReservationSpecificationInput(): AwsLaunchTemplate.CapacityReservationSpecificationProperty | undefined;
    private _cpuOptions;
    get cpuOptions(): AwsLaunchTemplate.CpuOptionsPropertyOutputReference;
    putCpuOptions(value: AwsLaunchTemplate.CpuOptionsProperty): void;
    resetCpuOptions(): void;
    get cpuOptionsInput(): AwsLaunchTemplate.CpuOptionsProperty | undefined;
    private _creditSpecification;
    get creditSpecification(): AwsLaunchTemplate.CreditSpecificationPropertyOutputReference;
    putCreditSpecification(value: AwsLaunchTemplate.CreditSpecificationProperty): void;
    resetCreditSpecification(): void;
    get creditSpecificationInput(): AwsLaunchTemplate.CreditSpecificationProperty | undefined;
    private _enclaveOptions;
    get enclaveOptions(): AwsLaunchTemplate.EnclaveOptionsPropertyOutputReference;
    putEnclaveOptions(value: AwsLaunchTemplate.EnclaveOptionsProperty): void;
    resetEnclaveOptions(): void;
    get enclaveOptionsInput(): AwsLaunchTemplate.EnclaveOptionsProperty | undefined;
    private _hibernationOptions;
    get hibernationOptions(): AwsLaunchTemplate.HibernationOptionsPropertyOutputReference;
    putHibernationOptions(value: AwsLaunchTemplate.HibernationOptionsProperty): void;
    resetHibernationOptions(): void;
    get hibernationOptionsInput(): AwsLaunchTemplate.HibernationOptionsProperty | undefined;
    private _iamInstanceProfile;
    get iamInstanceProfile(): AwsLaunchTemplate.IamInstanceProfilePropertyOutputReference;
    putIamInstanceProfile(value: AwsLaunchTemplate.IamInstanceProfileProperty): void;
    resetIamInstanceProfile(): void;
    get iamInstanceProfileInput(): AwsLaunchTemplate.IamInstanceProfileProperty | undefined;
    private _instanceMarketOptions;
    get instanceMarketOptions(): AwsLaunchTemplate.InstanceMarketOptionsPropertyOutputReference;
    putInstanceMarketOptions(value: AwsLaunchTemplate.InstanceMarketOptionsProperty): void;
    resetInstanceMarketOptions(): void;
    get instanceMarketOptionsInput(): AwsLaunchTemplate.InstanceMarketOptionsProperty | undefined;
    private _instanceRequirements;
    get instanceRequirements(): AwsLaunchTemplate.InstanceRequirementsPropertyOutputReference;
    putInstanceRequirements(value: AwsLaunchTemplate.InstanceRequirementsProperty): void;
    resetInstanceRequirements(): void;
    get instanceRequirementsInput(): AwsLaunchTemplate.InstanceRequirementsProperty | undefined;
    private _licenseSpecification;
    get licenseSpecification(): AwsLaunchTemplate.LicenseSpecificationPropertyList;
    putLicenseSpecification(value: AwsLaunchTemplate.LicenseSpecificationProperty[] | cdktn.IResolvable): void;
    resetLicenseSpecification(): void;
    get licenseSpecificationInput(): cdktn.IResolvable | AwsLaunchTemplate.LicenseSpecificationProperty[] | undefined;
    private _maintenanceOptions;
    get maintenanceOptions(): AwsLaunchTemplate.MaintenanceOptionsPropertyOutputReference;
    putMaintenanceOptions(value: AwsLaunchTemplate.MaintenanceOptionsProperty): void;
    resetMaintenanceOptions(): void;
    get maintenanceOptionsInput(): AwsLaunchTemplate.MaintenanceOptionsProperty | undefined;
    private _metadataOptions;
    get metadataOptions(): AwsLaunchTemplate.MetadataOptionsPropertyOutputReference;
    putMetadataOptions(value: AwsLaunchTemplate.MetadataOptionsProperty): void;
    resetMetadataOptions(): void;
    get metadataOptionsInput(): AwsLaunchTemplate.MetadataOptionsProperty | undefined;
    private _monitoring;
    get monitoring(): AwsLaunchTemplate.MonitoringPropertyOutputReference;
    putMonitoring(value: AwsLaunchTemplate.MonitoringProperty): void;
    resetMonitoring(): void;
    get monitoringInput(): AwsLaunchTemplate.MonitoringProperty | undefined;
    private _networkInterfaces;
    get networkInterfaces(): AwsLaunchTemplate.NetworkInterfacesPropertyList;
    putNetworkInterfaces(value: AwsLaunchTemplate.NetworkInterfacesProperty[] | cdktn.IResolvable): void;
    resetNetworkInterfaces(): void;
    get networkInterfacesInput(): cdktn.IResolvable | AwsLaunchTemplate.NetworkInterfacesProperty[] | undefined;
    private _networkPerformanceOptions;
    get networkPerformanceOptions(): AwsLaunchTemplate.NetworkPerformanceOptionsPropertyOutputReference;
    putNetworkPerformanceOptions(value: AwsLaunchTemplate.NetworkPerformanceOptionsProperty): void;
    resetNetworkPerformanceOptions(): void;
    get networkPerformanceOptionsInput(): AwsLaunchTemplate.NetworkPerformanceOptionsProperty | undefined;
    private _placement;
    get placement(): AwsLaunchTemplate.PlacementPropertyOutputReference;
    putPlacement(value: AwsLaunchTemplate.PlacementProperty): void;
    resetPlacement(): void;
    get placementInput(): AwsLaunchTemplate.PlacementProperty | undefined;
    private _privateDnsNameOptions;
    get privateDnsNameOptions(): AwsLaunchTemplate.PrivateDnsNameOptionsPropertyOutputReference;
    putPrivateDnsNameOptions(value: AwsLaunchTemplate.PrivateDnsNameOptionsProperty): void;
    resetPrivateDnsNameOptions(): void;
    get privateDnsNameOptionsInput(): AwsLaunchTemplate.PrivateDnsNameOptionsProperty | undefined;
    private _secondaryInterfaces;
    get secondaryInterfaces(): AwsLaunchTemplate.SecondaryInterfacesPropertyList;
    putSecondaryInterfaces(value: AwsLaunchTemplate.SecondaryInterfacesProperty[] | cdktn.IResolvable): void;
    resetSecondaryInterfaces(): void;
    get secondaryInterfacesInput(): cdktn.IResolvable | AwsLaunchTemplate.SecondaryInterfacesProperty[] | undefined;
    private _tagSpecifications;
    get tagSpecifications(): AwsLaunchTemplate.TagSpecificationsPropertyList;
    putTagSpecifications(value: AwsLaunchTemplate.TagSpecificationsProperty[] | cdktn.IResolvable): void;
    resetTagSpecifications(): void;
    get tagSpecificationsInput(): cdktn.IResolvable | AwsLaunchTemplate.TagSpecificationsProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsLaunchTemplateEbsPropertyToTerraform(struct?: AwsLaunchTemplate.EbsPropertyOutputReference | AwsLaunchTemplate.EbsProperty): any;
export declare function awsLaunchTemplateEbsPropertyToHclTerraform(struct?: AwsLaunchTemplate.EbsPropertyOutputReference | AwsLaunchTemplate.EbsProperty): any;
export declare function awsLaunchTemplateBlockDeviceMappingsPropertyToTerraform(struct?: AwsLaunchTemplate.BlockDeviceMappingsProperty | cdktn.IResolvable): any;
export declare function awsLaunchTemplateBlockDeviceMappingsPropertyToHclTerraform(struct?: AwsLaunchTemplate.BlockDeviceMappingsProperty | cdktn.IResolvable): any;
export declare function awsLaunchTemplateCapacityReservationTargetPropertyToTerraform(struct?: AwsLaunchTemplate.CapacityReservationTargetPropertyOutputReference | AwsLaunchTemplate.CapacityReservationTargetProperty): any;
export declare function awsLaunchTemplateCapacityReservationTargetPropertyToHclTerraform(struct?: AwsLaunchTemplate.CapacityReservationTargetPropertyOutputReference | AwsLaunchTemplate.CapacityReservationTargetProperty): any;
export declare function awsLaunchTemplateCapacityReservationSpecificationPropertyToTerraform(struct?: AwsLaunchTemplate.CapacityReservationSpecificationPropertyOutputReference | AwsLaunchTemplate.CapacityReservationSpecificationProperty): any;
export declare function awsLaunchTemplateCapacityReservationSpecificationPropertyToHclTerraform(struct?: AwsLaunchTemplate.CapacityReservationSpecificationPropertyOutputReference | AwsLaunchTemplate.CapacityReservationSpecificationProperty): any;
export declare function awsLaunchTemplateCpuOptionsPropertyToTerraform(struct?: AwsLaunchTemplate.CpuOptionsPropertyOutputReference | AwsLaunchTemplate.CpuOptionsProperty): any;
export declare function awsLaunchTemplateCpuOptionsPropertyToHclTerraform(struct?: AwsLaunchTemplate.CpuOptionsPropertyOutputReference | AwsLaunchTemplate.CpuOptionsProperty): any;
export declare function awsLaunchTemplateCreditSpecificationPropertyToTerraform(struct?: AwsLaunchTemplate.CreditSpecificationPropertyOutputReference | AwsLaunchTemplate.CreditSpecificationProperty): any;
export declare function awsLaunchTemplateCreditSpecificationPropertyToHclTerraform(struct?: AwsLaunchTemplate.CreditSpecificationPropertyOutputReference | AwsLaunchTemplate.CreditSpecificationProperty): any;
export declare function awsLaunchTemplateEnclaveOptionsPropertyToTerraform(struct?: AwsLaunchTemplate.EnclaveOptionsPropertyOutputReference | AwsLaunchTemplate.EnclaveOptionsProperty): any;
export declare function awsLaunchTemplateEnclaveOptionsPropertyToHclTerraform(struct?: AwsLaunchTemplate.EnclaveOptionsPropertyOutputReference | AwsLaunchTemplate.EnclaveOptionsProperty): any;
export declare function awsLaunchTemplateHibernationOptionsPropertyToTerraform(struct?: AwsLaunchTemplate.HibernationOptionsPropertyOutputReference | AwsLaunchTemplate.HibernationOptionsProperty): any;
export declare function awsLaunchTemplateHibernationOptionsPropertyToHclTerraform(struct?: AwsLaunchTemplate.HibernationOptionsPropertyOutputReference | AwsLaunchTemplate.HibernationOptionsProperty): any;
export declare function awsLaunchTemplateIamInstanceProfilePropertyToTerraform(struct?: AwsLaunchTemplate.IamInstanceProfilePropertyOutputReference | AwsLaunchTemplate.IamInstanceProfileProperty): any;
export declare function awsLaunchTemplateIamInstanceProfilePropertyToHclTerraform(struct?: AwsLaunchTemplate.IamInstanceProfilePropertyOutputReference | AwsLaunchTemplate.IamInstanceProfileProperty): any;
export declare function awsLaunchTemplateSpotOptionsPropertyToTerraform(struct?: AwsLaunchTemplate.SpotOptionsPropertyOutputReference | AwsLaunchTemplate.SpotOptionsProperty): any;
export declare function awsLaunchTemplateSpotOptionsPropertyToHclTerraform(struct?: AwsLaunchTemplate.SpotOptionsPropertyOutputReference | AwsLaunchTemplate.SpotOptionsProperty): any;
export declare function awsLaunchTemplateInstanceMarketOptionsPropertyToTerraform(struct?: AwsLaunchTemplate.InstanceMarketOptionsPropertyOutputReference | AwsLaunchTemplate.InstanceMarketOptionsProperty): any;
export declare function awsLaunchTemplateInstanceMarketOptionsPropertyToHclTerraform(struct?: AwsLaunchTemplate.InstanceMarketOptionsPropertyOutputReference | AwsLaunchTemplate.InstanceMarketOptionsProperty): any;
export declare function awsLaunchTemplateAcceleratorCountPropertyToTerraform(struct?: AwsLaunchTemplate.AcceleratorCountPropertyOutputReference | AwsLaunchTemplate.AcceleratorCountProperty): any;
export declare function awsLaunchTemplateAcceleratorCountPropertyToHclTerraform(struct?: AwsLaunchTemplate.AcceleratorCountPropertyOutputReference | AwsLaunchTemplate.AcceleratorCountProperty): any;
export declare function awsLaunchTemplateAcceleratorTotalMemoryMibPropertyToTerraform(struct?: AwsLaunchTemplate.AcceleratorTotalMemoryMibPropertyOutputReference | AwsLaunchTemplate.AcceleratorTotalMemoryMibProperty): any;
export declare function awsLaunchTemplateAcceleratorTotalMemoryMibPropertyToHclTerraform(struct?: AwsLaunchTemplate.AcceleratorTotalMemoryMibPropertyOutputReference | AwsLaunchTemplate.AcceleratorTotalMemoryMibProperty): any;
export declare function awsLaunchTemplateBaselineEbsBandwidthMbpsPropertyToTerraform(struct?: AwsLaunchTemplate.BaselineEbsBandwidthMbpsPropertyOutputReference | AwsLaunchTemplate.BaselineEbsBandwidthMbpsProperty): any;
export declare function awsLaunchTemplateBaselineEbsBandwidthMbpsPropertyToHclTerraform(struct?: AwsLaunchTemplate.BaselineEbsBandwidthMbpsPropertyOutputReference | AwsLaunchTemplate.BaselineEbsBandwidthMbpsProperty): any;
export declare function awsLaunchTemplateMemoryGibPerVcpuPropertyToTerraform(struct?: AwsLaunchTemplate.MemoryGibPerVcpuPropertyOutputReference | AwsLaunchTemplate.MemoryGibPerVcpuProperty): any;
export declare function awsLaunchTemplateMemoryGibPerVcpuPropertyToHclTerraform(struct?: AwsLaunchTemplate.MemoryGibPerVcpuPropertyOutputReference | AwsLaunchTemplate.MemoryGibPerVcpuProperty): any;
export declare function awsLaunchTemplateMemoryMibPropertyToTerraform(struct?: AwsLaunchTemplate.MemoryMibPropertyOutputReference | AwsLaunchTemplate.MemoryMibProperty): any;
export declare function awsLaunchTemplateMemoryMibPropertyToHclTerraform(struct?: AwsLaunchTemplate.MemoryMibPropertyOutputReference | AwsLaunchTemplate.MemoryMibProperty): any;
export declare function awsLaunchTemplateNetworkBandwidthGbpsPropertyToTerraform(struct?: AwsLaunchTemplate.NetworkBandwidthGbpsPropertyOutputReference | AwsLaunchTemplate.NetworkBandwidthGbpsProperty): any;
export declare function awsLaunchTemplateNetworkBandwidthGbpsPropertyToHclTerraform(struct?: AwsLaunchTemplate.NetworkBandwidthGbpsPropertyOutputReference | AwsLaunchTemplate.NetworkBandwidthGbpsProperty): any;
export declare function awsLaunchTemplateNetworkInterfaceCountPropertyToTerraform(struct?: AwsLaunchTemplate.NetworkInterfaceCountPropertyOutputReference | AwsLaunchTemplate.NetworkInterfaceCountProperty): any;
export declare function awsLaunchTemplateNetworkInterfaceCountPropertyToHclTerraform(struct?: AwsLaunchTemplate.NetworkInterfaceCountPropertyOutputReference | AwsLaunchTemplate.NetworkInterfaceCountProperty): any;
export declare function awsLaunchTemplateTotalLocalStorageGbPropertyToTerraform(struct?: AwsLaunchTemplate.TotalLocalStorageGbPropertyOutputReference | AwsLaunchTemplate.TotalLocalStorageGbProperty): any;
export declare function awsLaunchTemplateTotalLocalStorageGbPropertyToHclTerraform(struct?: AwsLaunchTemplate.TotalLocalStorageGbPropertyOutputReference | AwsLaunchTemplate.TotalLocalStorageGbProperty): any;
export declare function awsLaunchTemplateVcpuCountPropertyToTerraform(struct?: AwsLaunchTemplate.VcpuCountPropertyOutputReference | AwsLaunchTemplate.VcpuCountProperty): any;
export declare function awsLaunchTemplateVcpuCountPropertyToHclTerraform(struct?: AwsLaunchTemplate.VcpuCountPropertyOutputReference | AwsLaunchTemplate.VcpuCountProperty): any;
export declare function awsLaunchTemplateInstanceRequirementsPropertyToTerraform(struct?: AwsLaunchTemplate.InstanceRequirementsPropertyOutputReference | AwsLaunchTemplate.InstanceRequirementsProperty): any;
export declare function awsLaunchTemplateInstanceRequirementsPropertyToHclTerraform(struct?: AwsLaunchTemplate.InstanceRequirementsPropertyOutputReference | AwsLaunchTemplate.InstanceRequirementsProperty): any;
export declare function awsLaunchTemplateLicenseSpecificationPropertyToTerraform(struct?: AwsLaunchTemplate.LicenseSpecificationProperty | cdktn.IResolvable): any;
export declare function awsLaunchTemplateLicenseSpecificationPropertyToHclTerraform(struct?: AwsLaunchTemplate.LicenseSpecificationProperty | cdktn.IResolvable): any;
export declare function awsLaunchTemplateMaintenanceOptionsPropertyToTerraform(struct?: AwsLaunchTemplate.MaintenanceOptionsPropertyOutputReference | AwsLaunchTemplate.MaintenanceOptionsProperty): any;
export declare function awsLaunchTemplateMaintenanceOptionsPropertyToHclTerraform(struct?: AwsLaunchTemplate.MaintenanceOptionsPropertyOutputReference | AwsLaunchTemplate.MaintenanceOptionsProperty): any;
export declare function awsLaunchTemplateMetadataOptionsPropertyToTerraform(struct?: AwsLaunchTemplate.MetadataOptionsPropertyOutputReference | AwsLaunchTemplate.MetadataOptionsProperty): any;
export declare function awsLaunchTemplateMetadataOptionsPropertyToHclTerraform(struct?: AwsLaunchTemplate.MetadataOptionsPropertyOutputReference | AwsLaunchTemplate.MetadataOptionsProperty): any;
export declare function awsLaunchTemplateMonitoringPropertyToTerraform(struct?: AwsLaunchTemplate.MonitoringPropertyOutputReference | AwsLaunchTemplate.MonitoringProperty): any;
export declare function awsLaunchTemplateMonitoringPropertyToHclTerraform(struct?: AwsLaunchTemplate.MonitoringPropertyOutputReference | AwsLaunchTemplate.MonitoringProperty): any;
export declare function awsLaunchTemplateConnectionTrackingSpecificationPropertyToTerraform(struct?: AwsLaunchTemplate.ConnectionTrackingSpecificationPropertyOutputReference | AwsLaunchTemplate.ConnectionTrackingSpecificationProperty): any;
export declare function awsLaunchTemplateConnectionTrackingSpecificationPropertyToHclTerraform(struct?: AwsLaunchTemplate.ConnectionTrackingSpecificationPropertyOutputReference | AwsLaunchTemplate.ConnectionTrackingSpecificationProperty): any;
export declare function awsLaunchTemplateEnaSrdUdpSpecificationPropertyToTerraform(struct?: AwsLaunchTemplate.EnaSrdUdpSpecificationPropertyOutputReference | AwsLaunchTemplate.EnaSrdUdpSpecificationProperty): any;
export declare function awsLaunchTemplateEnaSrdUdpSpecificationPropertyToHclTerraform(struct?: AwsLaunchTemplate.EnaSrdUdpSpecificationPropertyOutputReference | AwsLaunchTemplate.EnaSrdUdpSpecificationProperty): any;
export declare function awsLaunchTemplateEnaSrdSpecificationPropertyToTerraform(struct?: AwsLaunchTemplate.EnaSrdSpecificationPropertyOutputReference | AwsLaunchTemplate.EnaSrdSpecificationProperty): any;
export declare function awsLaunchTemplateEnaSrdSpecificationPropertyToHclTerraform(struct?: AwsLaunchTemplate.EnaSrdSpecificationPropertyOutputReference | AwsLaunchTemplate.EnaSrdSpecificationProperty): any;
export declare function awsLaunchTemplateNetworkInterfacesPropertyToTerraform(struct?: AwsLaunchTemplate.NetworkInterfacesProperty | cdktn.IResolvable): any;
export declare function awsLaunchTemplateNetworkInterfacesPropertyToHclTerraform(struct?: AwsLaunchTemplate.NetworkInterfacesProperty | cdktn.IResolvable): any;
export declare function awsLaunchTemplateNetworkPerformanceOptionsPropertyToTerraform(struct?: AwsLaunchTemplate.NetworkPerformanceOptionsPropertyOutputReference | AwsLaunchTemplate.NetworkPerformanceOptionsProperty): any;
export declare function awsLaunchTemplateNetworkPerformanceOptionsPropertyToHclTerraform(struct?: AwsLaunchTemplate.NetworkPerformanceOptionsPropertyOutputReference | AwsLaunchTemplate.NetworkPerformanceOptionsProperty): any;
export declare function awsLaunchTemplatePlacementPropertyToTerraform(struct?: AwsLaunchTemplate.PlacementPropertyOutputReference | AwsLaunchTemplate.PlacementProperty): any;
export declare function awsLaunchTemplatePlacementPropertyToHclTerraform(struct?: AwsLaunchTemplate.PlacementPropertyOutputReference | AwsLaunchTemplate.PlacementProperty): any;
export declare function awsLaunchTemplatePrivateDnsNameOptionsPropertyToTerraform(struct?: AwsLaunchTemplate.PrivateDnsNameOptionsPropertyOutputReference | AwsLaunchTemplate.PrivateDnsNameOptionsProperty): any;
export declare function awsLaunchTemplatePrivateDnsNameOptionsPropertyToHclTerraform(struct?: AwsLaunchTemplate.PrivateDnsNameOptionsPropertyOutputReference | AwsLaunchTemplate.PrivateDnsNameOptionsProperty): any;
export declare function awsLaunchTemplateSecondaryInterfacesPropertyToTerraform(struct?: AwsLaunchTemplate.SecondaryInterfacesProperty | cdktn.IResolvable): any;
export declare function awsLaunchTemplateSecondaryInterfacesPropertyToHclTerraform(struct?: AwsLaunchTemplate.SecondaryInterfacesProperty | cdktn.IResolvable): any;
export declare function awsLaunchTemplateTagSpecificationsPropertyToTerraform(struct?: AwsLaunchTemplate.TagSpecificationsProperty | cdktn.IResolvable): any;
export declare function awsLaunchTemplateTagSpecificationsPropertyToHclTerraform(struct?: AwsLaunchTemplate.TagSpecificationsProperty | cdktn.IResolvable): any;
export declare namespace AwsLaunchTemplate {
    interface EbsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#delete_on_termination AwsLaunchTemplate#delete_on_termination}
        */
        readonly deleteOnTermination?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#encrypted AwsLaunchTemplate#encrypted}
        */
        readonly encrypted?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#iops AwsLaunchTemplate#iops}
        */
        readonly iops?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#kms_key_id AwsLaunchTemplate#kms_key_id}
        */
        readonly kmsKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#snapshot_id AwsLaunchTemplate#snapshot_id}
        */
        readonly snapshotId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#throughput AwsLaunchTemplate#throughput}
        */
        readonly throughput?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#volume_initialization_rate AwsLaunchTemplate#volume_initialization_rate}
        */
        readonly volumeInitializationRate?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#volume_size AwsLaunchTemplate#volume_size}
        */
        readonly volumeSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#volume_type AwsLaunchTemplate#volume_type}
        */
        readonly volumeType?: string;
    }
    class EbsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EbsProperty | undefined;
        set internalValue(value: EbsProperty | undefined);
        private _deleteOnTermination?;
        get deleteOnTermination(): string;
        set deleteOnTermination(value: string);
        resetDeleteOnTermination(): void;
        get deleteOnTerminationInput(): string | undefined;
        private _encrypted?;
        get encrypted(): string;
        set encrypted(value: string);
        resetEncrypted(): void;
        get encryptedInput(): string | undefined;
        private _iops?;
        get iops(): number;
        set iops(value: number);
        resetIops(): void;
        get iopsInput(): number | undefined;
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        resetKmsKeyId(): void;
        get kmsKeyIdInput(): string | undefined;
        private _snapshotId?;
        get snapshotId(): string;
        set snapshotId(value: string);
        resetSnapshotId(): void;
        get snapshotIdInput(): string | undefined;
        private _throughput?;
        get throughput(): number;
        set throughput(value: number);
        resetThroughput(): void;
        get throughputInput(): number | undefined;
        private _volumeInitializationRate?;
        get volumeInitializationRate(): number;
        set volumeInitializationRate(value: number);
        resetVolumeInitializationRate(): void;
        get volumeInitializationRateInput(): number | undefined;
        private _volumeSize?;
        get volumeSize(): number;
        set volumeSize(value: number);
        resetVolumeSize(): void;
        get volumeSizeInput(): number | undefined;
        private _volumeType?;
        get volumeType(): string;
        set volumeType(value: string);
        resetVolumeType(): void;
        get volumeTypeInput(): string | undefined;
    }
    interface BlockDeviceMappingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#device_name AwsLaunchTemplate#device_name}
        */
        readonly deviceName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#no_device AwsLaunchTemplate#no_device}
        */
        readonly noDevice?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#virtual_name AwsLaunchTemplate#virtual_name}
        */
        readonly virtualName?: string;
        /**
        * ebs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#ebs AwsLaunchTemplate#ebs}
        */
        readonly ebs?: EbsProperty;
    }
    class BlockDeviceMappingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BlockDeviceMappingsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: BlockDeviceMappingsProperty | cdktn.IResolvable | undefined);
        private _deviceName?;
        get deviceName(): string;
        set deviceName(value: string);
        resetDeviceName(): void;
        get deviceNameInput(): string | undefined;
        private _noDevice?;
        get noDevice(): string;
        set noDevice(value: string);
        resetNoDevice(): void;
        get noDeviceInput(): string | undefined;
        private _virtualName?;
        get virtualName(): string;
        set virtualName(value: string);
        resetVirtualName(): void;
        get virtualNameInput(): string | undefined;
        private _ebs;
        get ebs(): EbsPropertyOutputReference;
        putEbs(value: EbsProperty): void;
        resetEbs(): void;
        get ebsInput(): EbsProperty | undefined;
    }
    class BlockDeviceMappingsPropertyList extends cdktn.ComplexList {
        internalValue?: BlockDeviceMappingsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BlockDeviceMappingsPropertyOutputReference;
    }
    interface CapacityReservationTargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#capacity_reservation_id AwsLaunchTemplate#capacity_reservation_id}
        */
        readonly capacityReservationId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#capacity_reservation_resource_group_arn AwsLaunchTemplate#capacity_reservation_resource_group_arn}
        */
        readonly capacityReservationResourceGroupArn?: string;
    }
    class CapacityReservationTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CapacityReservationTargetProperty | undefined;
        set internalValue(value: CapacityReservationTargetProperty | undefined);
        private _capacityReservationId?;
        get capacityReservationId(): string;
        set capacityReservationId(value: string);
        resetCapacityReservationId(): void;
        get capacityReservationIdInput(): string | undefined;
        private _capacityReservationResourceGroupArn?;
        get capacityReservationResourceGroupArn(): string;
        set capacityReservationResourceGroupArn(value: string);
        resetCapacityReservationResourceGroupArn(): void;
        get capacityReservationResourceGroupArnInput(): string | undefined;
    }
    interface CapacityReservationSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#capacity_reservation_preference AwsLaunchTemplate#capacity_reservation_preference}
        */
        readonly capacityReservationPreference?: string;
        /**
        * capacity_reservation_target block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#capacity_reservation_target AwsLaunchTemplate#capacity_reservation_target}
        */
        readonly capacityReservationTarget?: CapacityReservationTargetProperty;
    }
    class CapacityReservationSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CapacityReservationSpecificationProperty | undefined;
        set internalValue(value: CapacityReservationSpecificationProperty | undefined);
        private _capacityReservationPreference?;
        get capacityReservationPreference(): string;
        set capacityReservationPreference(value: string);
        resetCapacityReservationPreference(): void;
        get capacityReservationPreferenceInput(): string | undefined;
        private _capacityReservationTarget;
        get capacityReservationTarget(): CapacityReservationTargetPropertyOutputReference;
        putCapacityReservationTarget(value: CapacityReservationTargetProperty): void;
        resetCapacityReservationTarget(): void;
        get capacityReservationTargetInput(): CapacityReservationTargetProperty | undefined;
    }
    interface CpuOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#amd_sev_snp AwsLaunchTemplate#amd_sev_snp}
        */
        readonly amdSevSnp?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#core_count AwsLaunchTemplate#core_count}
        */
        readonly coreCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#nested_virtualization AwsLaunchTemplate#nested_virtualization}
        */
        readonly nestedVirtualization?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#threads_per_core AwsLaunchTemplate#threads_per_core}
        */
        readonly threadsPerCore?: number;
    }
    class CpuOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CpuOptionsProperty | undefined;
        set internalValue(value: CpuOptionsProperty | undefined);
        private _amdSevSnp?;
        get amdSevSnp(): string;
        set amdSevSnp(value: string);
        resetAmdSevSnp(): void;
        get amdSevSnpInput(): string | undefined;
        private _coreCount?;
        get coreCount(): number;
        set coreCount(value: number);
        resetCoreCount(): void;
        get coreCountInput(): number | undefined;
        private _nestedVirtualization?;
        get nestedVirtualization(): string;
        set nestedVirtualization(value: string);
        resetNestedVirtualization(): void;
        get nestedVirtualizationInput(): string | undefined;
        private _threadsPerCore?;
        get threadsPerCore(): number;
        set threadsPerCore(value: number);
        resetThreadsPerCore(): void;
        get threadsPerCoreInput(): number | undefined;
    }
    interface CreditSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#cpu_credits AwsLaunchTemplate#cpu_credits}
        */
        readonly cpuCredits?: string;
    }
    class CreditSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CreditSpecificationProperty | undefined;
        set internalValue(value: CreditSpecificationProperty | undefined);
        private _cpuCredits?;
        get cpuCredits(): string;
        set cpuCredits(value: string);
        resetCpuCredits(): void;
        get cpuCreditsInput(): string | undefined;
    }
    interface EnclaveOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#enabled AwsLaunchTemplate#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
    }
    class EnclaveOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EnclaveOptionsProperty | undefined;
        set internalValue(value: EnclaveOptionsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface HibernationOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#configured AwsLaunchTemplate#configured}
        */
        readonly configured: boolean | cdktn.IResolvable;
    }
    class HibernationOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HibernationOptionsProperty | undefined;
        set internalValue(value: HibernationOptionsProperty | undefined);
        private _configured?;
        get configured(): boolean | cdktn.IResolvable;
        set configured(value: boolean | cdktn.IResolvable);
        get configuredInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface IamInstanceProfileProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#arn AwsLaunchTemplate#arn}
        */
        readonly arn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#name AwsLaunchTemplate#name}
        */
        readonly name?: string;
    }
    class IamInstanceProfilePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IamInstanceProfileProperty | undefined;
        set internalValue(value: IamInstanceProfileProperty | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        resetArn(): void;
        get arnInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
    }
    interface SpotOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#block_duration_minutes AwsLaunchTemplate#block_duration_minutes}
        */
        readonly blockDurationMinutes?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#instance_interruption_behavior AwsLaunchTemplate#instance_interruption_behavior}
        */
        readonly instanceInterruptionBehavior?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#max_price AwsLaunchTemplate#max_price}
        */
        readonly maxPrice?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#spot_instance_type AwsLaunchTemplate#spot_instance_type}
        */
        readonly spotInstanceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#valid_until AwsLaunchTemplate#valid_until}
        */
        readonly validUntil?: string;
    }
    class SpotOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpotOptionsProperty | undefined;
        set internalValue(value: SpotOptionsProperty | undefined);
        private _blockDurationMinutes?;
        get blockDurationMinutes(): number;
        set blockDurationMinutes(value: number);
        resetBlockDurationMinutes(): void;
        get blockDurationMinutesInput(): number | undefined;
        private _instanceInterruptionBehavior?;
        get instanceInterruptionBehavior(): string;
        set instanceInterruptionBehavior(value: string);
        resetInstanceInterruptionBehavior(): void;
        get instanceInterruptionBehaviorInput(): string | undefined;
        private _maxPrice?;
        get maxPrice(): string;
        set maxPrice(value: string);
        resetMaxPrice(): void;
        get maxPriceInput(): string | undefined;
        private _spotInstanceType?;
        get spotInstanceType(): string;
        set spotInstanceType(value: string);
        resetSpotInstanceType(): void;
        get spotInstanceTypeInput(): string | undefined;
        private _validUntil?;
        get validUntil(): string;
        set validUntil(value: string);
        resetValidUntil(): void;
        get validUntilInput(): string | undefined;
    }
    interface InstanceMarketOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#market_type AwsLaunchTemplate#market_type}
        */
        readonly marketType?: string;
        /**
        * spot_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#spot_options AwsLaunchTemplate#spot_options}
        */
        readonly spotOptions?: SpotOptionsProperty;
    }
    class InstanceMarketOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InstanceMarketOptionsProperty | undefined;
        set internalValue(value: InstanceMarketOptionsProperty | undefined);
        private _marketType?;
        get marketType(): string;
        set marketType(value: string);
        resetMarketType(): void;
        get marketTypeInput(): string | undefined;
        private _spotOptions;
        get spotOptions(): SpotOptionsPropertyOutputReference;
        putSpotOptions(value: SpotOptionsProperty): void;
        resetSpotOptions(): void;
        get spotOptionsInput(): SpotOptionsProperty | undefined;
    }
    interface AcceleratorCountProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#max AwsLaunchTemplate#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#min AwsLaunchTemplate#min}
        */
        readonly min?: number;
    }
    class AcceleratorCountPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AcceleratorCountProperty | undefined;
        set internalValue(value: AcceleratorCountProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface AcceleratorTotalMemoryMibProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#max AwsLaunchTemplate#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#min AwsLaunchTemplate#min}
        */
        readonly min?: number;
    }
    class AcceleratorTotalMemoryMibPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AcceleratorTotalMemoryMibProperty | undefined;
        set internalValue(value: AcceleratorTotalMemoryMibProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface BaselineEbsBandwidthMbpsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#max AwsLaunchTemplate#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#min AwsLaunchTemplate#min}
        */
        readonly min?: number;
    }
    class BaselineEbsBandwidthMbpsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BaselineEbsBandwidthMbpsProperty | undefined;
        set internalValue(value: BaselineEbsBandwidthMbpsProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface MemoryGibPerVcpuProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#max AwsLaunchTemplate#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#min AwsLaunchTemplate#min}
        */
        readonly min?: number;
    }
    class MemoryGibPerVcpuPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MemoryGibPerVcpuProperty | undefined;
        set internalValue(value: MemoryGibPerVcpuProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface MemoryMibProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#max AwsLaunchTemplate#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#min AwsLaunchTemplate#min}
        */
        readonly min: number;
    }
    class MemoryMibPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MemoryMibProperty | undefined;
        set internalValue(value: MemoryMibProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        get minInput(): number | undefined;
    }
    interface NetworkBandwidthGbpsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#max AwsLaunchTemplate#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#min AwsLaunchTemplate#min}
        */
        readonly min?: number;
    }
    class NetworkBandwidthGbpsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NetworkBandwidthGbpsProperty | undefined;
        set internalValue(value: NetworkBandwidthGbpsProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface NetworkInterfaceCountProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#max AwsLaunchTemplate#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#min AwsLaunchTemplate#min}
        */
        readonly min?: number;
    }
    class NetworkInterfaceCountPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NetworkInterfaceCountProperty | undefined;
        set internalValue(value: NetworkInterfaceCountProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface TotalLocalStorageGbProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#max AwsLaunchTemplate#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#min AwsLaunchTemplate#min}
        */
        readonly min?: number;
    }
    class TotalLocalStorageGbPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TotalLocalStorageGbProperty | undefined;
        set internalValue(value: TotalLocalStorageGbProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface VcpuCountProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#max AwsLaunchTemplate#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#min AwsLaunchTemplate#min}
        */
        readonly min: number;
    }
    class VcpuCountPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VcpuCountProperty | undefined;
        set internalValue(value: VcpuCountProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        get minInput(): number | undefined;
    }
    interface InstanceRequirementsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#accelerator_manufacturers AwsLaunchTemplate#accelerator_manufacturers}
        */
        readonly acceleratorManufacturers?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#accelerator_names AwsLaunchTemplate#accelerator_names}
        */
        readonly acceleratorNames?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#accelerator_types AwsLaunchTemplate#accelerator_types}
        */
        readonly acceleratorTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#allowed_instance_types AwsLaunchTemplate#allowed_instance_types}
        */
        readonly allowedInstanceTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#bare_metal AwsLaunchTemplate#bare_metal}
        */
        readonly bareMetal?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#burstable_performance AwsLaunchTemplate#burstable_performance}
        */
        readonly burstablePerformance?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#cpu_manufacturers AwsLaunchTemplate#cpu_manufacturers}
        */
        readonly cpuManufacturers?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#excluded_instance_types AwsLaunchTemplate#excluded_instance_types}
        */
        readonly excludedInstanceTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#instance_generations AwsLaunchTemplate#instance_generations}
        */
        readonly instanceGenerations?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#local_storage AwsLaunchTemplate#local_storage}
        */
        readonly localStorage?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#local_storage_types AwsLaunchTemplate#local_storage_types}
        */
        readonly localStorageTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#max_spot_price_as_percentage_of_optimal_on_demand_price AwsLaunchTemplate#max_spot_price_as_percentage_of_optimal_on_demand_price}
        */
        readonly maxSpotPriceAsPercentageOfOptimalOnDemandPrice?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#on_demand_max_price_percentage_over_lowest_price AwsLaunchTemplate#on_demand_max_price_percentage_over_lowest_price}
        */
        readonly onDemandMaxPricePercentageOverLowestPrice?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#require_hibernate_support AwsLaunchTemplate#require_hibernate_support}
        */
        readonly requireHibernateSupport?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#spot_max_price_percentage_over_lowest_price AwsLaunchTemplate#spot_max_price_percentage_over_lowest_price}
        */
        readonly spotMaxPricePercentageOverLowestPrice?: number;
        /**
        * accelerator_count block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#accelerator_count AwsLaunchTemplate#accelerator_count}
        */
        readonly acceleratorCount?: AcceleratorCountProperty;
        /**
        * accelerator_total_memory_mib block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#accelerator_total_memory_mib AwsLaunchTemplate#accelerator_total_memory_mib}
        */
        readonly acceleratorTotalMemoryMib?: AcceleratorTotalMemoryMibProperty;
        /**
        * baseline_ebs_bandwidth_mbps block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#baseline_ebs_bandwidth_mbps AwsLaunchTemplate#baseline_ebs_bandwidth_mbps}
        */
        readonly baselineEbsBandwidthMbps?: BaselineEbsBandwidthMbpsProperty;
        /**
        * memory_gib_per_vcpu block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#memory_gib_per_vcpu AwsLaunchTemplate#memory_gib_per_vcpu}
        */
        readonly memoryGibPerVcpu?: MemoryGibPerVcpuProperty;
        /**
        * memory_mib block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#memory_mib AwsLaunchTemplate#memory_mib}
        */
        readonly memoryMib: MemoryMibProperty;
        /**
        * network_bandwidth_gbps block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#network_bandwidth_gbps AwsLaunchTemplate#network_bandwidth_gbps}
        */
        readonly networkBandwidthGbps?: NetworkBandwidthGbpsProperty;
        /**
        * network_interface_count block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#network_interface_count AwsLaunchTemplate#network_interface_count}
        */
        readonly networkInterfaceCount?: NetworkInterfaceCountProperty;
        /**
        * total_local_storage_gb block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#total_local_storage_gb AwsLaunchTemplate#total_local_storage_gb}
        */
        readonly totalLocalStorageGb?: TotalLocalStorageGbProperty;
        /**
        * vcpu_count block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#vcpu_count AwsLaunchTemplate#vcpu_count}
        */
        readonly vcpuCount: VcpuCountProperty;
    }
    class InstanceRequirementsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InstanceRequirementsProperty | undefined;
        set internalValue(value: InstanceRequirementsProperty | undefined);
        private _acceleratorManufacturers?;
        get acceleratorManufacturers(): string[];
        set acceleratorManufacturers(value: string[]);
        resetAcceleratorManufacturers(): void;
        get acceleratorManufacturersInput(): string[] | undefined;
        private _acceleratorNames?;
        get acceleratorNames(): string[];
        set acceleratorNames(value: string[]);
        resetAcceleratorNames(): void;
        get acceleratorNamesInput(): string[] | undefined;
        private _acceleratorTypes?;
        get acceleratorTypes(): string[];
        set acceleratorTypes(value: string[]);
        resetAcceleratorTypes(): void;
        get acceleratorTypesInput(): string[] | undefined;
        private _allowedInstanceTypes?;
        get allowedInstanceTypes(): string[];
        set allowedInstanceTypes(value: string[]);
        resetAllowedInstanceTypes(): void;
        get allowedInstanceTypesInput(): string[] | undefined;
        private _bareMetal?;
        get bareMetal(): string;
        set bareMetal(value: string);
        resetBareMetal(): void;
        get bareMetalInput(): string | undefined;
        private _burstablePerformance?;
        get burstablePerformance(): string;
        set burstablePerformance(value: string);
        resetBurstablePerformance(): void;
        get burstablePerformanceInput(): string | undefined;
        private _cpuManufacturers?;
        get cpuManufacturers(): string[];
        set cpuManufacturers(value: string[]);
        resetCpuManufacturers(): void;
        get cpuManufacturersInput(): string[] | undefined;
        private _excludedInstanceTypes?;
        get excludedInstanceTypes(): string[];
        set excludedInstanceTypes(value: string[]);
        resetExcludedInstanceTypes(): void;
        get excludedInstanceTypesInput(): string[] | undefined;
        private _instanceGenerations?;
        get instanceGenerations(): string[];
        set instanceGenerations(value: string[]);
        resetInstanceGenerations(): void;
        get instanceGenerationsInput(): string[] | undefined;
        private _localStorage?;
        get localStorage(): string;
        set localStorage(value: string);
        resetLocalStorage(): void;
        get localStorageInput(): string | undefined;
        private _localStorageTypes?;
        get localStorageTypes(): string[];
        set localStorageTypes(value: string[]);
        resetLocalStorageTypes(): void;
        get localStorageTypesInput(): string[] | undefined;
        private _maxSpotPriceAsPercentageOfOptimalOnDemandPrice?;
        get maxSpotPriceAsPercentageOfOptimalOnDemandPrice(): number;
        set maxSpotPriceAsPercentageOfOptimalOnDemandPrice(value: number);
        resetMaxSpotPriceAsPercentageOfOptimalOnDemandPrice(): void;
        get maxSpotPriceAsPercentageOfOptimalOnDemandPriceInput(): number | undefined;
        private _onDemandMaxPricePercentageOverLowestPrice?;
        get onDemandMaxPricePercentageOverLowestPrice(): number;
        set onDemandMaxPricePercentageOverLowestPrice(value: number);
        resetOnDemandMaxPricePercentageOverLowestPrice(): void;
        get onDemandMaxPricePercentageOverLowestPriceInput(): number | undefined;
        private _requireHibernateSupport?;
        get requireHibernateSupport(): boolean | cdktn.IResolvable;
        set requireHibernateSupport(value: boolean | cdktn.IResolvable);
        resetRequireHibernateSupport(): void;
        get requireHibernateSupportInput(): boolean | cdktn.IResolvable | undefined;
        private _spotMaxPricePercentageOverLowestPrice?;
        get spotMaxPricePercentageOverLowestPrice(): number;
        set spotMaxPricePercentageOverLowestPrice(value: number);
        resetSpotMaxPricePercentageOverLowestPrice(): void;
        get spotMaxPricePercentageOverLowestPriceInput(): number | undefined;
        private _acceleratorCount;
        get acceleratorCount(): AcceleratorCountPropertyOutputReference;
        putAcceleratorCount(value: AcceleratorCountProperty): void;
        resetAcceleratorCount(): void;
        get acceleratorCountInput(): AcceleratorCountProperty | undefined;
        private _acceleratorTotalMemoryMib;
        get acceleratorTotalMemoryMib(): AcceleratorTotalMemoryMibPropertyOutputReference;
        putAcceleratorTotalMemoryMib(value: AcceleratorTotalMemoryMibProperty): void;
        resetAcceleratorTotalMemoryMib(): void;
        get acceleratorTotalMemoryMibInput(): AcceleratorTotalMemoryMibProperty | undefined;
        private _baselineEbsBandwidthMbps;
        get baselineEbsBandwidthMbps(): BaselineEbsBandwidthMbpsPropertyOutputReference;
        putBaselineEbsBandwidthMbps(value: BaselineEbsBandwidthMbpsProperty): void;
        resetBaselineEbsBandwidthMbps(): void;
        get baselineEbsBandwidthMbpsInput(): BaselineEbsBandwidthMbpsProperty | undefined;
        private _memoryGibPerVcpu;
        get memoryGibPerVcpu(): MemoryGibPerVcpuPropertyOutputReference;
        putMemoryGibPerVcpu(value: MemoryGibPerVcpuProperty): void;
        resetMemoryGibPerVcpu(): void;
        get memoryGibPerVcpuInput(): MemoryGibPerVcpuProperty | undefined;
        private _memoryMib;
        get memoryMib(): MemoryMibPropertyOutputReference;
        putMemoryMib(value: MemoryMibProperty): void;
        get memoryMibInput(): MemoryMibProperty | undefined;
        private _networkBandwidthGbps;
        get networkBandwidthGbps(): NetworkBandwidthGbpsPropertyOutputReference;
        putNetworkBandwidthGbps(value: NetworkBandwidthGbpsProperty): void;
        resetNetworkBandwidthGbps(): void;
        get networkBandwidthGbpsInput(): NetworkBandwidthGbpsProperty | undefined;
        private _networkInterfaceCount;
        get networkInterfaceCount(): NetworkInterfaceCountPropertyOutputReference;
        putNetworkInterfaceCount(value: NetworkInterfaceCountProperty): void;
        resetNetworkInterfaceCount(): void;
        get networkInterfaceCountInput(): NetworkInterfaceCountProperty | undefined;
        private _totalLocalStorageGb;
        get totalLocalStorageGb(): TotalLocalStorageGbPropertyOutputReference;
        putTotalLocalStorageGb(value: TotalLocalStorageGbProperty): void;
        resetTotalLocalStorageGb(): void;
        get totalLocalStorageGbInput(): TotalLocalStorageGbProperty | undefined;
        private _vcpuCount;
        get vcpuCount(): VcpuCountPropertyOutputReference;
        putVcpuCount(value: VcpuCountProperty): void;
        get vcpuCountInput(): VcpuCountProperty | undefined;
    }
    interface LicenseSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#license_configuration_arn AwsLaunchTemplate#license_configuration_arn}
        */
        readonly licenseConfigurationArn: string;
    }
    class LicenseSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LicenseSpecificationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LicenseSpecificationProperty | cdktn.IResolvable | undefined);
        private _licenseConfigurationArn?;
        get licenseConfigurationArn(): string;
        set licenseConfigurationArn(value: string);
        get licenseConfigurationArnInput(): string | undefined;
    }
    class LicenseSpecificationPropertyList extends cdktn.ComplexList {
        internalValue?: LicenseSpecificationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LicenseSpecificationPropertyOutputReference;
    }
    interface MaintenanceOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#auto_recovery AwsLaunchTemplate#auto_recovery}
        */
        readonly autoRecovery?: string;
    }
    class MaintenanceOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MaintenanceOptionsProperty | undefined;
        set internalValue(value: MaintenanceOptionsProperty | undefined);
        private _autoRecovery?;
        get autoRecovery(): string;
        set autoRecovery(value: string);
        resetAutoRecovery(): void;
        get autoRecoveryInput(): string | undefined;
    }
    interface MetadataOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#http_endpoint AwsLaunchTemplate#http_endpoint}
        */
        readonly httpEndpoint?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#http_protocol_ipv6 AwsLaunchTemplate#http_protocol_ipv6}
        */
        readonly httpProtocolIpv6?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#http_put_response_hop_limit AwsLaunchTemplate#http_put_response_hop_limit}
        */
        readonly httpPutResponseHopLimit?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#http_tokens AwsLaunchTemplate#http_tokens}
        */
        readonly httpTokens?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#instance_metadata_tags AwsLaunchTemplate#instance_metadata_tags}
        */
        readonly instanceMetadataTags?: string;
    }
    class MetadataOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MetadataOptionsProperty | undefined;
        set internalValue(value: MetadataOptionsProperty | undefined);
        private _httpEndpoint?;
        get httpEndpoint(): string;
        set httpEndpoint(value: string);
        resetHttpEndpoint(): void;
        get httpEndpointInput(): string | undefined;
        private _httpProtocolIpv6?;
        get httpProtocolIpv6(): string;
        set httpProtocolIpv6(value: string);
        resetHttpProtocolIpv6(): void;
        get httpProtocolIpv6Input(): string | undefined;
        private _httpPutResponseHopLimit?;
        get httpPutResponseHopLimit(): number;
        set httpPutResponseHopLimit(value: number);
        resetHttpPutResponseHopLimit(): void;
        get httpPutResponseHopLimitInput(): number | undefined;
        private _httpTokens?;
        get httpTokens(): string;
        set httpTokens(value: string);
        resetHttpTokens(): void;
        get httpTokensInput(): string | undefined;
        private _instanceMetadataTags?;
        get instanceMetadataTags(): string;
        set instanceMetadataTags(value: string);
        resetInstanceMetadataTags(): void;
        get instanceMetadataTagsInput(): string | undefined;
    }
    interface MonitoringProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#enabled AwsLaunchTemplate#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
    }
    class MonitoringPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MonitoringProperty | undefined;
        set internalValue(value: MonitoringProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface ConnectionTrackingSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#tcp_established_timeout AwsLaunchTemplate#tcp_established_timeout}
        */
        readonly tcpEstablishedTimeout?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#udp_stream_timeout AwsLaunchTemplate#udp_stream_timeout}
        */
        readonly udpStreamTimeout?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#udp_timeout AwsLaunchTemplate#udp_timeout}
        */
        readonly udpTimeout?: number;
    }
    class ConnectionTrackingSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConnectionTrackingSpecificationProperty | undefined;
        set internalValue(value: ConnectionTrackingSpecificationProperty | undefined);
        private _tcpEstablishedTimeout?;
        get tcpEstablishedTimeout(): number;
        set tcpEstablishedTimeout(value: number);
        resetTcpEstablishedTimeout(): void;
        get tcpEstablishedTimeoutInput(): number | undefined;
        private _udpStreamTimeout?;
        get udpStreamTimeout(): number;
        set udpStreamTimeout(value: number);
        resetUdpStreamTimeout(): void;
        get udpStreamTimeoutInput(): number | undefined;
        private _udpTimeout?;
        get udpTimeout(): number;
        set udpTimeout(value: number);
        resetUdpTimeout(): void;
        get udpTimeoutInput(): number | undefined;
    }
    interface EnaSrdUdpSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#ena_srd_udp_enabled AwsLaunchTemplate#ena_srd_udp_enabled}
        */
        readonly enaSrdUdpEnabled?: boolean | cdktn.IResolvable;
    }
    class EnaSrdUdpSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EnaSrdUdpSpecificationProperty | undefined;
        set internalValue(value: EnaSrdUdpSpecificationProperty | undefined);
        private _enaSrdUdpEnabled?;
        get enaSrdUdpEnabled(): boolean | cdktn.IResolvable;
        set enaSrdUdpEnabled(value: boolean | cdktn.IResolvable);
        resetEnaSrdUdpEnabled(): void;
        get enaSrdUdpEnabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface EnaSrdSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#ena_srd_enabled AwsLaunchTemplate#ena_srd_enabled}
        */
        readonly enaSrdEnabled?: boolean | cdktn.IResolvable;
        /**
        * ena_srd_udp_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#ena_srd_udp_specification AwsLaunchTemplate#ena_srd_udp_specification}
        */
        readonly enaSrdUdpSpecification?: EnaSrdUdpSpecificationProperty;
    }
    class EnaSrdSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EnaSrdSpecificationProperty | undefined;
        set internalValue(value: EnaSrdSpecificationProperty | undefined);
        private _enaSrdEnabled?;
        get enaSrdEnabled(): boolean | cdktn.IResolvable;
        set enaSrdEnabled(value: boolean | cdktn.IResolvable);
        resetEnaSrdEnabled(): void;
        get enaSrdEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _enaSrdUdpSpecification;
        get enaSrdUdpSpecification(): EnaSrdUdpSpecificationPropertyOutputReference;
        putEnaSrdUdpSpecification(value: EnaSrdUdpSpecificationProperty): void;
        resetEnaSrdUdpSpecification(): void;
        get enaSrdUdpSpecificationInput(): EnaSrdUdpSpecificationProperty | undefined;
    }
    interface NetworkInterfacesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#associate_carrier_ip_address AwsLaunchTemplate#associate_carrier_ip_address}
        */
        readonly associateCarrierIpAddress?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#associate_public_ip_address AwsLaunchTemplate#associate_public_ip_address}
        */
        readonly associatePublicIpAddress?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#delete_on_termination AwsLaunchTemplate#delete_on_termination}
        */
        readonly deleteOnTermination?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#description AwsLaunchTemplate#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#device_index AwsLaunchTemplate#device_index}
        */
        readonly deviceIndex?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#ena_queue_count AwsLaunchTemplate#ena_queue_count}
        */
        readonly enaQueueCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#interface_type AwsLaunchTemplate#interface_type}
        */
        readonly interfaceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#ipv4_address_count AwsLaunchTemplate#ipv4_address_count}
        */
        readonly ipv4AddressCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#ipv4_addresses AwsLaunchTemplate#ipv4_addresses}
        */
        readonly ipv4Addresses?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#ipv4_prefix_count AwsLaunchTemplate#ipv4_prefix_count}
        */
        readonly ipv4PrefixCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#ipv4_prefixes AwsLaunchTemplate#ipv4_prefixes}
        */
        readonly ipv4Prefixes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#ipv6_address_count AwsLaunchTemplate#ipv6_address_count}
        */
        readonly ipv6AddressCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#ipv6_addresses AwsLaunchTemplate#ipv6_addresses}
        */
        readonly ipv6Addresses?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#ipv6_prefix_count AwsLaunchTemplate#ipv6_prefix_count}
        */
        readonly ipv6PrefixCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#ipv6_prefixes AwsLaunchTemplate#ipv6_prefixes}
        */
        readonly ipv6Prefixes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#network_card_index AwsLaunchTemplate#network_card_index}
        */
        readonly networkCardIndex?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#network_interface_id AwsLaunchTemplate#network_interface_id}
        */
        readonly networkInterfaceId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#primary_ipv6 AwsLaunchTemplate#primary_ipv6}
        */
        readonly primaryIpv6?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#private_ip_address AwsLaunchTemplate#private_ip_address}
        */
        readonly privateIpAddress?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#security_groups AwsLaunchTemplate#security_groups}
        */
        readonly securityGroups?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#subnet_id AwsLaunchTemplate#subnet_id}
        */
        readonly subnetId?: string;
        /**
        * connection_tracking_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#connection_tracking_specification AwsLaunchTemplate#connection_tracking_specification}
        */
        readonly connectionTrackingSpecification?: ConnectionTrackingSpecificationProperty;
        /**
        * ena_srd_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#ena_srd_specification AwsLaunchTemplate#ena_srd_specification}
        */
        readonly enaSrdSpecification?: EnaSrdSpecificationProperty;
    }
    class NetworkInterfacesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NetworkInterfacesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NetworkInterfacesProperty | cdktn.IResolvable | undefined);
        private _associateCarrierIpAddress?;
        get associateCarrierIpAddress(): string;
        set associateCarrierIpAddress(value: string);
        resetAssociateCarrierIpAddress(): void;
        get associateCarrierIpAddressInput(): string | undefined;
        private _associatePublicIpAddress?;
        get associatePublicIpAddress(): string;
        set associatePublicIpAddress(value: string);
        resetAssociatePublicIpAddress(): void;
        get associatePublicIpAddressInput(): string | undefined;
        private _deleteOnTermination?;
        get deleteOnTermination(): string;
        set deleteOnTermination(value: string);
        resetDeleteOnTermination(): void;
        get deleteOnTerminationInput(): string | undefined;
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _deviceIndex?;
        get deviceIndex(): number;
        set deviceIndex(value: number);
        resetDeviceIndex(): void;
        get deviceIndexInput(): number | undefined;
        private _enaQueueCount?;
        get enaQueueCount(): number;
        set enaQueueCount(value: number);
        resetEnaQueueCount(): void;
        get enaQueueCountInput(): number | undefined;
        private _interfaceType?;
        get interfaceType(): string;
        set interfaceType(value: string);
        resetInterfaceType(): void;
        get interfaceTypeInput(): string | undefined;
        private _ipv4AddressCount?;
        get ipv4AddressCount(): number;
        set ipv4AddressCount(value: number);
        resetIpv4AddressCount(): void;
        get ipv4AddressCountInput(): number | undefined;
        private _ipv4Addresses?;
        get ipv4Addresses(): string[];
        set ipv4Addresses(value: string[]);
        resetIpv4Addresses(): void;
        get ipv4AddressesInput(): string[] | undefined;
        private _ipv4PrefixCount?;
        get ipv4PrefixCount(): number;
        set ipv4PrefixCount(value: number);
        resetIpv4PrefixCount(): void;
        get ipv4PrefixCountInput(): number | undefined;
        private _ipv4Prefixes?;
        get ipv4Prefixes(): string[];
        set ipv4Prefixes(value: string[]);
        resetIpv4Prefixes(): void;
        get ipv4PrefixesInput(): string[] | undefined;
        private _ipv6AddressCount?;
        get ipv6AddressCount(): number;
        set ipv6AddressCount(value: number);
        resetIpv6AddressCount(): void;
        get ipv6AddressCountInput(): number | undefined;
        private _ipv6Addresses?;
        get ipv6Addresses(): string[];
        set ipv6Addresses(value: string[]);
        resetIpv6Addresses(): void;
        get ipv6AddressesInput(): string[] | undefined;
        private _ipv6PrefixCount?;
        get ipv6PrefixCount(): number;
        set ipv6PrefixCount(value: number);
        resetIpv6PrefixCount(): void;
        get ipv6PrefixCountInput(): number | undefined;
        private _ipv6Prefixes?;
        get ipv6Prefixes(): string[];
        set ipv6Prefixes(value: string[]);
        resetIpv6Prefixes(): void;
        get ipv6PrefixesInput(): string[] | undefined;
        private _networkCardIndex?;
        get networkCardIndex(): number;
        set networkCardIndex(value: number);
        resetNetworkCardIndex(): void;
        get networkCardIndexInput(): number | undefined;
        private _networkInterfaceId?;
        get networkInterfaceId(): string;
        set networkInterfaceId(value: string);
        resetNetworkInterfaceId(): void;
        get networkInterfaceIdInput(): string | undefined;
        private _primaryIpv6?;
        get primaryIpv6(): string;
        set primaryIpv6(value: string);
        resetPrimaryIpv6(): void;
        get primaryIpv6Input(): string | undefined;
        private _privateIpAddress?;
        get privateIpAddress(): string;
        set privateIpAddress(value: string);
        resetPrivateIpAddress(): void;
        get privateIpAddressInput(): string | undefined;
        private _securityGroups?;
        get securityGroups(): string[];
        set securityGroups(value: string[]);
        resetSecurityGroups(): void;
        get securityGroupsInput(): string[] | undefined;
        private _subnetId?;
        get subnetId(): string;
        set subnetId(value: string);
        resetSubnetId(): void;
        get subnetIdInput(): string | undefined;
        private _connectionTrackingSpecification;
        get connectionTrackingSpecification(): ConnectionTrackingSpecificationPropertyOutputReference;
        putConnectionTrackingSpecification(value: ConnectionTrackingSpecificationProperty): void;
        resetConnectionTrackingSpecification(): void;
        get connectionTrackingSpecificationInput(): ConnectionTrackingSpecificationProperty | undefined;
        private _enaSrdSpecification;
        get enaSrdSpecification(): EnaSrdSpecificationPropertyOutputReference;
        putEnaSrdSpecification(value: EnaSrdSpecificationProperty): void;
        resetEnaSrdSpecification(): void;
        get enaSrdSpecificationInput(): EnaSrdSpecificationProperty | undefined;
    }
    class NetworkInterfacesPropertyList extends cdktn.ComplexList {
        internalValue?: NetworkInterfacesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NetworkInterfacesPropertyOutputReference;
    }
    interface NetworkPerformanceOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#bandwidth_weighting AwsLaunchTemplate#bandwidth_weighting}
        */
        readonly bandwidthWeighting?: string;
    }
    class NetworkPerformanceOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NetworkPerformanceOptionsProperty | undefined;
        set internalValue(value: NetworkPerformanceOptionsProperty | undefined);
        private _bandwidthWeighting?;
        get bandwidthWeighting(): string;
        set bandwidthWeighting(value: string);
        resetBandwidthWeighting(): void;
        get bandwidthWeightingInput(): string | undefined;
    }
    interface PlacementProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#affinity AwsLaunchTemplate#affinity}
        */
        readonly affinity?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#availability_zone AwsLaunchTemplate#availability_zone}
        */
        readonly availabilityZone?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#group_id AwsLaunchTemplate#group_id}
        */
        readonly groupId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#group_name AwsLaunchTemplate#group_name}
        */
        readonly groupName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#host_id AwsLaunchTemplate#host_id}
        */
        readonly hostId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#host_resource_group_arn AwsLaunchTemplate#host_resource_group_arn}
        */
        readonly hostResourceGroupArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#partition_number AwsLaunchTemplate#partition_number}
        */
        readonly partitionNumber?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#spread_domain AwsLaunchTemplate#spread_domain}
        */
        readonly spreadDomain?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#tenancy AwsLaunchTemplate#tenancy}
        */
        readonly tenancy?: string;
    }
    class PlacementPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PlacementProperty | undefined;
        set internalValue(value: PlacementProperty | undefined);
        private _affinity?;
        get affinity(): string;
        set affinity(value: string);
        resetAffinity(): void;
        get affinityInput(): string | undefined;
        private _availabilityZone?;
        get availabilityZone(): string;
        set availabilityZone(value: string);
        resetAvailabilityZone(): void;
        get availabilityZoneInput(): string | undefined;
        private _groupId?;
        get groupId(): string;
        set groupId(value: string);
        resetGroupId(): void;
        get groupIdInput(): string | undefined;
        private _groupName?;
        get groupName(): string;
        set groupName(value: string);
        resetGroupName(): void;
        get groupNameInput(): string | undefined;
        private _hostId?;
        get hostId(): string;
        set hostId(value: string);
        resetHostId(): void;
        get hostIdInput(): string | undefined;
        private _hostResourceGroupArn?;
        get hostResourceGroupArn(): string;
        set hostResourceGroupArn(value: string);
        resetHostResourceGroupArn(): void;
        get hostResourceGroupArnInput(): string | undefined;
        private _partitionNumber?;
        get partitionNumber(): number;
        set partitionNumber(value: number);
        resetPartitionNumber(): void;
        get partitionNumberInput(): number | undefined;
        private _spreadDomain?;
        get spreadDomain(): string;
        set spreadDomain(value: string);
        resetSpreadDomain(): void;
        get spreadDomainInput(): string | undefined;
        private _tenancy?;
        get tenancy(): string;
        set tenancy(value: string);
        resetTenancy(): void;
        get tenancyInput(): string | undefined;
    }
    interface PrivateDnsNameOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#enable_resource_name_dns_a_record AwsLaunchTemplate#enable_resource_name_dns_a_record}
        */
        readonly enableResourceNameDnsARecord?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#enable_resource_name_dns_aaaa_record AwsLaunchTemplate#enable_resource_name_dns_aaaa_record}
        */
        readonly enableResourceNameDnsAaaaRecord?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#hostname_type AwsLaunchTemplate#hostname_type}
        */
        readonly hostnameType?: string;
    }
    class PrivateDnsNameOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PrivateDnsNameOptionsProperty | undefined;
        set internalValue(value: PrivateDnsNameOptionsProperty | undefined);
        private _enableResourceNameDnsARecord?;
        get enableResourceNameDnsARecord(): boolean | cdktn.IResolvable;
        set enableResourceNameDnsARecord(value: boolean | cdktn.IResolvable);
        resetEnableResourceNameDnsARecord(): void;
        get enableResourceNameDnsARecordInput(): boolean | cdktn.IResolvable | undefined;
        private _enableResourceNameDnsAaaaRecord?;
        get enableResourceNameDnsAaaaRecord(): boolean | cdktn.IResolvable;
        set enableResourceNameDnsAaaaRecord(value: boolean | cdktn.IResolvable);
        resetEnableResourceNameDnsAaaaRecord(): void;
        get enableResourceNameDnsAaaaRecordInput(): boolean | cdktn.IResolvable | undefined;
        private _hostnameType?;
        get hostnameType(): string;
        set hostnameType(value: string);
        resetHostnameType(): void;
        get hostnameTypeInput(): string | undefined;
    }
    interface SecondaryInterfacesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#delete_on_termination AwsLaunchTemplate#delete_on_termination}
        */
        readonly deleteOnTermination?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#device_index AwsLaunchTemplate#device_index}
        */
        readonly deviceIndex?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#interface_type AwsLaunchTemplate#interface_type}
        */
        readonly interfaceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#network_card_index AwsLaunchTemplate#network_card_index}
        */
        readonly networkCardIndex?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#private_ip_address_count AwsLaunchTemplate#private_ip_address_count}
        */
        readonly privateIpAddressCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#private_ip_addresses AwsLaunchTemplate#private_ip_addresses}
        */
        readonly privateIpAddresses?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#secondary_subnet_id AwsLaunchTemplate#secondary_subnet_id}
        */
        readonly secondarySubnetId?: string;
    }
    class SecondaryInterfacesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SecondaryInterfacesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SecondaryInterfacesProperty | cdktn.IResolvable | undefined);
        private _deleteOnTermination?;
        get deleteOnTermination(): boolean | cdktn.IResolvable;
        set deleteOnTermination(value: boolean | cdktn.IResolvable);
        resetDeleteOnTermination(): void;
        get deleteOnTerminationInput(): boolean | cdktn.IResolvable | undefined;
        private _deviceIndex?;
        get deviceIndex(): number;
        set deviceIndex(value: number);
        resetDeviceIndex(): void;
        get deviceIndexInput(): number | undefined;
        private _interfaceType?;
        get interfaceType(): string;
        set interfaceType(value: string);
        resetInterfaceType(): void;
        get interfaceTypeInput(): string | undefined;
        private _networkCardIndex?;
        get networkCardIndex(): number;
        set networkCardIndex(value: number);
        resetNetworkCardIndex(): void;
        get networkCardIndexInput(): number | undefined;
        private _privateIpAddressCount?;
        get privateIpAddressCount(): number;
        set privateIpAddressCount(value: number);
        resetPrivateIpAddressCount(): void;
        get privateIpAddressCountInput(): number | undefined;
        private _privateIpAddresses?;
        get privateIpAddresses(): string[];
        set privateIpAddresses(value: string[]);
        resetPrivateIpAddresses(): void;
        get privateIpAddressesInput(): string[] | undefined;
        private _secondarySubnetId?;
        get secondarySubnetId(): string;
        set secondarySubnetId(value: string);
        resetSecondarySubnetId(): void;
        get secondarySubnetIdInput(): string | undefined;
    }
    class SecondaryInterfacesPropertyList extends cdktn.ComplexList {
        internalValue?: SecondaryInterfacesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SecondaryInterfacesPropertyOutputReference;
    }
    interface TagSpecificationsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#resource_type AwsLaunchTemplate#resource_type}
        */
        readonly resourceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#tags AwsLaunchTemplate#tags}
        */
        readonly tags?: {
            [key: string]: string;
        };
    }
    class TagSpecificationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TagSpecificationsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TagSpecificationsProperty | cdktn.IResolvable | undefined);
        private _resourceType?;
        get resourceType(): string;
        set resourceType(value: string);
        resetResourceType(): void;
        get resourceTypeInput(): string | undefined;
        private _tags?;
        get tags(): {
            [key: string]: string;
        };
        set tags(value: {
            [key: string]: string;
        });
        resetTags(): void;
        get tagsInput(): {
            [key: string]: string;
        } | undefined;
    }
    class TagSpecificationsPropertyList extends cdktn.ComplexList {
        internalValue?: TagSpecificationsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TagSpecificationsPropertyOutputReference;
    }
}
