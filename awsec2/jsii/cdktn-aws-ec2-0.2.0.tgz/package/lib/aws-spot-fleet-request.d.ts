import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfSpotFleetRequestConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#allocation_strategy TfSpotFleetRequest#allocation_strategy}
    */
    readonly allocationStrategy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#context TfSpotFleetRequest#context}
    */
    readonly context?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#excess_capacity_termination_policy TfSpotFleetRequest#excess_capacity_termination_policy}
    */
    readonly excessCapacityTerminationPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#fleet_type TfSpotFleetRequest#fleet_type}
    */
    readonly fleetType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#iam_fleet_role TfSpotFleetRequest#iam_fleet_role}
    */
    readonly iamFleetRole: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#id TfSpotFleetRequest#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#instance_interruption_behaviour TfSpotFleetRequest#instance_interruption_behaviour}
    */
    readonly instanceInterruptionBehaviour?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#instance_pools_to_use_count TfSpotFleetRequest#instance_pools_to_use_count}
    */
    readonly instancePoolsToUseCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#load_balancers TfSpotFleetRequest#load_balancers}
    */
    readonly loadBalancers?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#on_demand_allocation_strategy TfSpotFleetRequest#on_demand_allocation_strategy}
    */
    readonly onDemandAllocationStrategy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#on_demand_max_total_price TfSpotFleetRequest#on_demand_max_total_price}
    */
    readonly onDemandMaxTotalPrice?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#on_demand_target_capacity TfSpotFleetRequest#on_demand_target_capacity}
    */
    readonly onDemandTargetCapacity?: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#region TfSpotFleetRequest#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#replace_unhealthy_instances TfSpotFleetRequest#replace_unhealthy_instances}
    */
    readonly replaceUnhealthyInstances?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#spot_price TfSpotFleetRequest#spot_price}
    */
    readonly spotPrice?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#tags TfSpotFleetRequest#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#tags_all TfSpotFleetRequest#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#target_capacity TfSpotFleetRequest#target_capacity}
    */
    readonly targetCapacity: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#target_capacity_unit_type TfSpotFleetRequest#target_capacity_unit_type}
    */
    readonly targetCapacityUnitType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#target_group_arns TfSpotFleetRequest#target_group_arns}
    */
    readonly targetGroupArns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#terminate_instances_on_delete TfSpotFleetRequest#terminate_instances_on_delete}
    */
    readonly terminateInstancesOnDelete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#terminate_instances_with_expiration TfSpotFleetRequest#terminate_instances_with_expiration}
    */
    readonly terminateInstancesWithExpiration?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#valid_from TfSpotFleetRequest#valid_from}
    */
    readonly validFrom?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#valid_until TfSpotFleetRequest#valid_until}
    */
    readonly validUntil?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#wait_for_fulfillment TfSpotFleetRequest#wait_for_fulfillment}
    */
    readonly waitForFulfillment?: boolean | cdktn.IResolvable;
    /**
    * launch_specification block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#launch_specification TfSpotFleetRequest#launch_specification}
    */
    readonly launchSpecification?: TfSpotFleetRequest.LaunchSpecificationProperty[] | cdktn.IResolvable;
    /**
    * launch_template_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#launch_template_config TfSpotFleetRequest#launch_template_config}
    */
    readonly launchTemplateConfig?: TfSpotFleetRequest.LaunchTemplateConfigProperty[] | cdktn.IResolvable;
    /**
    * spot_maintenance_strategies block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#spot_maintenance_strategies TfSpotFleetRequest#spot_maintenance_strategies}
    */
    readonly spotMaintenanceStrategies?: TfSpotFleetRequest.SpotMaintenanceStrategiesProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#timeouts TfSpotFleetRequest#timeouts}
    */
    readonly timeouts?: TfSpotFleetRequest.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request aws_spot_fleet_request}
*/
export declare class TfSpotFleetRequest extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_spot_fleet_request";
    /**
    * Generates CDKTN code for importing a TfSpotFleetRequest resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfSpotFleetRequest to import
    * @param importFromId The id of the existing TfSpotFleetRequest that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfSpotFleetRequest to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request aws_spot_fleet_request} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfSpotFleetRequestConfig
    */
    constructor(scope: Construct, id: string, config: TfSpotFleetRequestConfig);
    private _allocationStrategy?;
    get allocationStrategy(): string;
    set allocationStrategy(value: string);
    resetAllocationStrategy(): void;
    get allocationStrategyInput(): string | undefined;
    get clientToken(): string;
    private _context?;
    get context(): string;
    set context(value: string);
    resetContext(): void;
    get contextInput(): string | undefined;
    private _excessCapacityTerminationPolicy?;
    get excessCapacityTerminationPolicy(): string;
    set excessCapacityTerminationPolicy(value: string);
    resetExcessCapacityTerminationPolicy(): void;
    get excessCapacityTerminationPolicyInput(): string | undefined;
    private _fleetType?;
    get fleetType(): string;
    set fleetType(value: string);
    resetFleetType(): void;
    get fleetTypeInput(): string | undefined;
    private _iamFleetRole?;
    get iamFleetRole(): string;
    set iamFleetRole(value: string);
    get iamFleetRoleInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceInterruptionBehaviour?;
    get instanceInterruptionBehaviour(): string;
    set instanceInterruptionBehaviour(value: string);
    resetInstanceInterruptionBehaviour(): void;
    get instanceInterruptionBehaviourInput(): string | undefined;
    private _instancePoolsToUseCount?;
    get instancePoolsToUseCount(): number;
    set instancePoolsToUseCount(value: number);
    resetInstancePoolsToUseCount(): void;
    get instancePoolsToUseCountInput(): number | undefined;
    private _loadBalancers?;
    get loadBalancers(): string[];
    set loadBalancers(value: string[]);
    resetLoadBalancers(): void;
    get loadBalancersInput(): string[] | undefined;
    private _onDemandAllocationStrategy?;
    get onDemandAllocationStrategy(): string;
    set onDemandAllocationStrategy(value: string);
    resetOnDemandAllocationStrategy(): void;
    get onDemandAllocationStrategyInput(): string | undefined;
    private _onDemandMaxTotalPrice?;
    get onDemandMaxTotalPrice(): string;
    set onDemandMaxTotalPrice(value: string);
    resetOnDemandMaxTotalPrice(): void;
    get onDemandMaxTotalPriceInput(): string | undefined;
    private _onDemandTargetCapacity?;
    get onDemandTargetCapacity(): number;
    set onDemandTargetCapacity(value: number);
    resetOnDemandTargetCapacity(): void;
    get onDemandTargetCapacityInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _replaceUnhealthyInstances?;
    get replaceUnhealthyInstances(): boolean | cdktn.IResolvable;
    set replaceUnhealthyInstances(value: boolean | cdktn.IResolvable);
    resetReplaceUnhealthyInstances(): void;
    get replaceUnhealthyInstancesInput(): boolean | cdktn.IResolvable | undefined;
    private _spotPrice?;
    get spotPrice(): string;
    set spotPrice(value: string);
    resetSpotPrice(): void;
    get spotPriceInput(): string | undefined;
    get spotRequestState(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _targetCapacity?;
    get targetCapacity(): number;
    set targetCapacity(value: number);
    get targetCapacityInput(): number | undefined;
    private _targetCapacityUnitType?;
    get targetCapacityUnitType(): string;
    set targetCapacityUnitType(value: string);
    resetTargetCapacityUnitType(): void;
    get targetCapacityUnitTypeInput(): string | undefined;
    private _targetGroupArns?;
    get targetGroupArns(): string[];
    set targetGroupArns(value: string[]);
    resetTargetGroupArns(): void;
    get targetGroupArnsInput(): string[] | undefined;
    private _terminateInstancesOnDelete?;
    get terminateInstancesOnDelete(): string;
    set terminateInstancesOnDelete(value: string);
    resetTerminateInstancesOnDelete(): void;
    get terminateInstancesOnDeleteInput(): string | undefined;
    private _terminateInstancesWithExpiration?;
    get terminateInstancesWithExpiration(): boolean | cdktn.IResolvable;
    set terminateInstancesWithExpiration(value: boolean | cdktn.IResolvable);
    resetTerminateInstancesWithExpiration(): void;
    get terminateInstancesWithExpirationInput(): boolean | cdktn.IResolvable | undefined;
    private _validFrom?;
    get validFrom(): string;
    set validFrom(value: string);
    resetValidFrom(): void;
    get validFromInput(): string | undefined;
    private _validUntil?;
    get validUntil(): string;
    set validUntil(value: string);
    resetValidUntil(): void;
    get validUntilInput(): string | undefined;
    private _waitForFulfillment?;
    get waitForFulfillment(): boolean | cdktn.IResolvable;
    set waitForFulfillment(value: boolean | cdktn.IResolvable);
    resetWaitForFulfillment(): void;
    get waitForFulfillmentInput(): boolean | cdktn.IResolvable | undefined;
    private _launchSpecification;
    get launchSpecification(): TfSpotFleetRequest.LaunchSpecificationPropertyList;
    putLaunchSpecification(value: TfSpotFleetRequest.LaunchSpecificationProperty[] | cdktn.IResolvable): void;
    resetLaunchSpecification(): void;
    get launchSpecificationInput(): cdktn.IResolvable | TfSpotFleetRequest.LaunchSpecificationProperty[] | undefined;
    private _launchTemplateConfig;
    get launchTemplateConfig(): TfSpotFleetRequest.LaunchTemplateConfigPropertyList;
    putLaunchTemplateConfig(value: TfSpotFleetRequest.LaunchTemplateConfigProperty[] | cdktn.IResolvable): void;
    resetLaunchTemplateConfig(): void;
    get launchTemplateConfigInput(): cdktn.IResolvable | TfSpotFleetRequest.LaunchTemplateConfigProperty[] | undefined;
    private _spotMaintenanceStrategies;
    get spotMaintenanceStrategies(): TfSpotFleetRequest.SpotMaintenanceStrategiesPropertyOutputReference;
    putSpotMaintenanceStrategies(value: TfSpotFleetRequest.SpotMaintenanceStrategiesProperty): void;
    resetSpotMaintenanceStrategies(): void;
    get spotMaintenanceStrategiesInput(): TfSpotFleetRequest.SpotMaintenanceStrategiesProperty | undefined;
    private _timeouts;
    get timeouts(): TfSpotFleetRequest.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfSpotFleetRequest.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfSpotFleetRequest.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfSpotFleetRequestEbsBlockDevicePropertyToTerraform(struct?: TfSpotFleetRequest.EbsBlockDeviceProperty | cdktn.IResolvable): any;
export declare function tfSpotFleetRequestEbsBlockDevicePropertyToHclTerraform(struct?: TfSpotFleetRequest.EbsBlockDeviceProperty | cdktn.IResolvable): any;
export declare function tfSpotFleetRequestEphemeralBlockDevicePropertyToTerraform(struct?: TfSpotFleetRequest.EphemeralBlockDeviceProperty | cdktn.IResolvable): any;
export declare function tfSpotFleetRequestEphemeralBlockDevicePropertyToHclTerraform(struct?: TfSpotFleetRequest.EphemeralBlockDeviceProperty | cdktn.IResolvable): any;
export declare function tfSpotFleetRequestRootBlockDevicePropertyToTerraform(struct?: TfSpotFleetRequest.RootBlockDeviceProperty | cdktn.IResolvable): any;
export declare function tfSpotFleetRequestRootBlockDevicePropertyToHclTerraform(struct?: TfSpotFleetRequest.RootBlockDeviceProperty | cdktn.IResolvable): any;
export declare function tfSpotFleetRequestLaunchSpecificationPropertyToTerraform(struct?: TfSpotFleetRequest.LaunchSpecificationProperty | cdktn.IResolvable): any;
export declare function tfSpotFleetRequestLaunchSpecificationPropertyToHclTerraform(struct?: TfSpotFleetRequest.LaunchSpecificationProperty | cdktn.IResolvable): any;
export declare function tfSpotFleetRequestLaunchTemplateSpecificationPropertyToTerraform(struct?: TfSpotFleetRequest.LaunchTemplateSpecificationPropertyOutputReference | TfSpotFleetRequest.LaunchTemplateSpecificationProperty): any;
export declare function tfSpotFleetRequestLaunchTemplateSpecificationPropertyToHclTerraform(struct?: TfSpotFleetRequest.LaunchTemplateSpecificationPropertyOutputReference | TfSpotFleetRequest.LaunchTemplateSpecificationProperty): any;
export declare function tfSpotFleetRequestAcceleratorCountPropertyToTerraform(struct?: TfSpotFleetRequest.AcceleratorCountPropertyOutputReference | TfSpotFleetRequest.AcceleratorCountProperty): any;
export declare function tfSpotFleetRequestAcceleratorCountPropertyToHclTerraform(struct?: TfSpotFleetRequest.AcceleratorCountPropertyOutputReference | TfSpotFleetRequest.AcceleratorCountProperty): any;
export declare function tfSpotFleetRequestAcceleratorTotalMemoryMibPropertyToTerraform(struct?: TfSpotFleetRequest.AcceleratorTotalMemoryMibPropertyOutputReference | TfSpotFleetRequest.AcceleratorTotalMemoryMibProperty): any;
export declare function tfSpotFleetRequestAcceleratorTotalMemoryMibPropertyToHclTerraform(struct?: TfSpotFleetRequest.AcceleratorTotalMemoryMibPropertyOutputReference | TfSpotFleetRequest.AcceleratorTotalMemoryMibProperty): any;
export declare function tfSpotFleetRequestBaselineEbsBandwidthMbpsPropertyToTerraform(struct?: TfSpotFleetRequest.BaselineEbsBandwidthMbpsPropertyOutputReference | TfSpotFleetRequest.BaselineEbsBandwidthMbpsProperty): any;
export declare function tfSpotFleetRequestBaselineEbsBandwidthMbpsPropertyToHclTerraform(struct?: TfSpotFleetRequest.BaselineEbsBandwidthMbpsPropertyOutputReference | TfSpotFleetRequest.BaselineEbsBandwidthMbpsProperty): any;
export declare function tfSpotFleetRequestMemoryGibPerVcpuPropertyToTerraform(struct?: TfSpotFleetRequest.MemoryGibPerVcpuPropertyOutputReference | TfSpotFleetRequest.MemoryGibPerVcpuProperty): any;
export declare function tfSpotFleetRequestMemoryGibPerVcpuPropertyToHclTerraform(struct?: TfSpotFleetRequest.MemoryGibPerVcpuPropertyOutputReference | TfSpotFleetRequest.MemoryGibPerVcpuProperty): any;
export declare function tfSpotFleetRequestMemoryMibPropertyToTerraform(struct?: TfSpotFleetRequest.MemoryMibPropertyOutputReference | TfSpotFleetRequest.MemoryMibProperty): any;
export declare function tfSpotFleetRequestMemoryMibPropertyToHclTerraform(struct?: TfSpotFleetRequest.MemoryMibPropertyOutputReference | TfSpotFleetRequest.MemoryMibProperty): any;
export declare function tfSpotFleetRequestNetworkBandwidthGbpsPropertyToTerraform(struct?: TfSpotFleetRequest.NetworkBandwidthGbpsPropertyOutputReference | TfSpotFleetRequest.NetworkBandwidthGbpsProperty): any;
export declare function tfSpotFleetRequestNetworkBandwidthGbpsPropertyToHclTerraform(struct?: TfSpotFleetRequest.NetworkBandwidthGbpsPropertyOutputReference | TfSpotFleetRequest.NetworkBandwidthGbpsProperty): any;
export declare function tfSpotFleetRequestNetworkInterfaceCountPropertyToTerraform(struct?: TfSpotFleetRequest.NetworkInterfaceCountPropertyOutputReference | TfSpotFleetRequest.NetworkInterfaceCountProperty): any;
export declare function tfSpotFleetRequestNetworkInterfaceCountPropertyToHclTerraform(struct?: TfSpotFleetRequest.NetworkInterfaceCountPropertyOutputReference | TfSpotFleetRequest.NetworkInterfaceCountProperty): any;
export declare function tfSpotFleetRequestTotalLocalStorageGbPropertyToTerraform(struct?: TfSpotFleetRequest.TotalLocalStorageGbPropertyOutputReference | TfSpotFleetRequest.TotalLocalStorageGbProperty): any;
export declare function tfSpotFleetRequestTotalLocalStorageGbPropertyToHclTerraform(struct?: TfSpotFleetRequest.TotalLocalStorageGbPropertyOutputReference | TfSpotFleetRequest.TotalLocalStorageGbProperty): any;
export declare function tfSpotFleetRequestVcpuCountPropertyToTerraform(struct?: TfSpotFleetRequest.VcpuCountPropertyOutputReference | TfSpotFleetRequest.VcpuCountProperty): any;
export declare function tfSpotFleetRequestVcpuCountPropertyToHclTerraform(struct?: TfSpotFleetRequest.VcpuCountPropertyOutputReference | TfSpotFleetRequest.VcpuCountProperty): any;
export declare function tfSpotFleetRequestInstanceRequirementsPropertyToTerraform(struct?: TfSpotFleetRequest.InstanceRequirementsPropertyOutputReference | TfSpotFleetRequest.InstanceRequirementsProperty): any;
export declare function tfSpotFleetRequestInstanceRequirementsPropertyToHclTerraform(struct?: TfSpotFleetRequest.InstanceRequirementsPropertyOutputReference | TfSpotFleetRequest.InstanceRequirementsProperty): any;
export declare function tfSpotFleetRequestOverridesPropertyToTerraform(struct?: TfSpotFleetRequest.OverridesProperty | cdktn.IResolvable): any;
export declare function tfSpotFleetRequestOverridesPropertyToHclTerraform(struct?: TfSpotFleetRequest.OverridesProperty | cdktn.IResolvable): any;
export declare function tfSpotFleetRequestLaunchTemplateConfigPropertyToTerraform(struct?: TfSpotFleetRequest.LaunchTemplateConfigProperty | cdktn.IResolvable): any;
export declare function tfSpotFleetRequestLaunchTemplateConfigPropertyToHclTerraform(struct?: TfSpotFleetRequest.LaunchTemplateConfigProperty | cdktn.IResolvable): any;
export declare function tfSpotFleetRequestCapacityRebalancePropertyToTerraform(struct?: TfSpotFleetRequest.CapacityRebalancePropertyOutputReference | TfSpotFleetRequest.CapacityRebalanceProperty): any;
export declare function tfSpotFleetRequestCapacityRebalancePropertyToHclTerraform(struct?: TfSpotFleetRequest.CapacityRebalancePropertyOutputReference | TfSpotFleetRequest.CapacityRebalanceProperty): any;
export declare function tfSpotFleetRequestSpotMaintenanceStrategiesPropertyToTerraform(struct?: TfSpotFleetRequest.SpotMaintenanceStrategiesPropertyOutputReference | TfSpotFleetRequest.SpotMaintenanceStrategiesProperty): any;
export declare function tfSpotFleetRequestSpotMaintenanceStrategiesPropertyToHclTerraform(struct?: TfSpotFleetRequest.SpotMaintenanceStrategiesPropertyOutputReference | TfSpotFleetRequest.SpotMaintenanceStrategiesProperty): any;
export declare function tfSpotFleetRequestTimeoutsPropertyToTerraform(struct?: TfSpotFleetRequest.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfSpotFleetRequestTimeoutsPropertyToHclTerraform(struct?: TfSpotFleetRequest.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfSpotFleetRequest {
    interface EbsBlockDeviceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#delete_on_termination TfSpotFleetRequest#delete_on_termination}
        */
        readonly deleteOnTermination?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#device_name TfSpotFleetRequest#device_name}
        */
        readonly deviceName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#encrypted TfSpotFleetRequest#encrypted}
        */
        readonly encrypted?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#iops TfSpotFleetRequest#iops}
        */
        readonly iops?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#kms_key_id TfSpotFleetRequest#kms_key_id}
        */
        readonly kmsKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#snapshot_id TfSpotFleetRequest#snapshot_id}
        */
        readonly snapshotId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#throughput TfSpotFleetRequest#throughput}
        */
        readonly throughput?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#volume_size TfSpotFleetRequest#volume_size}
        */
        readonly volumeSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#volume_type TfSpotFleetRequest#volume_type}
        */
        readonly volumeType?: string;
    }
    class EbsBlockDevicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EbsBlockDeviceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EbsBlockDeviceProperty | cdktn.IResolvable | undefined);
        private _deleteOnTermination?;
        get deleteOnTermination(): boolean | cdktn.IResolvable;
        set deleteOnTermination(value: boolean | cdktn.IResolvable);
        resetDeleteOnTermination(): void;
        get deleteOnTerminationInput(): boolean | cdktn.IResolvable | undefined;
        private _deviceName?;
        get deviceName(): string;
        set deviceName(value: string);
        get deviceNameInput(): string | undefined;
        private _encrypted?;
        get encrypted(): boolean | cdktn.IResolvable;
        set encrypted(value: boolean | cdktn.IResolvable);
        resetEncrypted(): void;
        get encryptedInput(): boolean | cdktn.IResolvable | undefined;
        private _iops?;
        get iops(): number;
        set iops(value: number);
        resetIops(): void;
        get iopsInput(): number | undefined;
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        resetKmsKeyId(): void;
        get kmsKeyIdInput(): string | undefined;
        private _snapshotId?;
        get snapshotId(): string;
        set snapshotId(value: string);
        resetSnapshotId(): void;
        get snapshotIdInput(): string | undefined;
        private _throughput?;
        get throughput(): number;
        set throughput(value: number);
        resetThroughput(): void;
        get throughputInput(): number | undefined;
        private _volumeSize?;
        get volumeSize(): number;
        set volumeSize(value: number);
        resetVolumeSize(): void;
        get volumeSizeInput(): number | undefined;
        private _volumeType?;
        get volumeType(): string;
        set volumeType(value: string);
        resetVolumeType(): void;
        get volumeTypeInput(): string | undefined;
    }
    class EbsBlockDevicePropertyList extends cdktn.ComplexList {
        internalValue?: EbsBlockDeviceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EbsBlockDevicePropertyOutputReference;
    }
    interface EphemeralBlockDeviceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#device_name TfSpotFleetRequest#device_name}
        */
        readonly deviceName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#virtual_name TfSpotFleetRequest#virtual_name}
        */
        readonly virtualName: string;
    }
    class EphemeralBlockDevicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EphemeralBlockDeviceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EphemeralBlockDeviceProperty | cdktn.IResolvable | undefined);
        private _deviceName?;
        get deviceName(): string;
        set deviceName(value: string);
        get deviceNameInput(): string | undefined;
        private _virtualName?;
        get virtualName(): string;
        set virtualName(value: string);
        get virtualNameInput(): string | undefined;
    }
    class EphemeralBlockDevicePropertyList extends cdktn.ComplexList {
        internalValue?: EphemeralBlockDeviceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EphemeralBlockDevicePropertyOutputReference;
    }
    interface RootBlockDeviceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#delete_on_termination TfSpotFleetRequest#delete_on_termination}
        */
        readonly deleteOnTermination?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#encrypted TfSpotFleetRequest#encrypted}
        */
        readonly encrypted?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#iops TfSpotFleetRequest#iops}
        */
        readonly iops?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#kms_key_id TfSpotFleetRequest#kms_key_id}
        */
        readonly kmsKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#throughput TfSpotFleetRequest#throughput}
        */
        readonly throughput?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#volume_size TfSpotFleetRequest#volume_size}
        */
        readonly volumeSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#volume_type TfSpotFleetRequest#volume_type}
        */
        readonly volumeType?: string;
    }
    class RootBlockDevicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RootBlockDeviceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RootBlockDeviceProperty | cdktn.IResolvable | undefined);
        private _deleteOnTermination?;
        get deleteOnTermination(): boolean | cdktn.IResolvable;
        set deleteOnTermination(value: boolean | cdktn.IResolvable);
        resetDeleteOnTermination(): void;
        get deleteOnTerminationInput(): boolean | cdktn.IResolvable | undefined;
        private _encrypted?;
        get encrypted(): boolean | cdktn.IResolvable;
        set encrypted(value: boolean | cdktn.IResolvable);
        resetEncrypted(): void;
        get encryptedInput(): boolean | cdktn.IResolvable | undefined;
        private _iops?;
        get iops(): number;
        set iops(value: number);
        resetIops(): void;
        get iopsInput(): number | undefined;
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        resetKmsKeyId(): void;
        get kmsKeyIdInput(): string | undefined;
        private _throughput?;
        get throughput(): number;
        set throughput(value: number);
        resetThroughput(): void;
        get throughputInput(): number | undefined;
        private _volumeSize?;
        get volumeSize(): number;
        set volumeSize(value: number);
        resetVolumeSize(): void;
        get volumeSizeInput(): number | undefined;
        private _volumeType?;
        get volumeType(): string;
        set volumeType(value: string);
        resetVolumeType(): void;
        get volumeTypeInput(): string | undefined;
    }
    class RootBlockDevicePropertyList extends cdktn.ComplexList {
        internalValue?: RootBlockDeviceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RootBlockDevicePropertyOutputReference;
    }
    interface LaunchSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#ami TfSpotFleetRequest#ami}
        */
        readonly ami: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#associate_public_ip_address TfSpotFleetRequest#associate_public_ip_address}
        */
        readonly associatePublicIpAddress?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#availability_zone TfSpotFleetRequest#availability_zone}
        */
        readonly availabilityZone?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#ebs_optimized TfSpotFleetRequest#ebs_optimized}
        */
        readonly ebsOptimized?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#iam_instance_profile TfSpotFleetRequest#iam_instance_profile}
        */
        readonly iamInstanceProfile?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#iam_instance_profile_arn TfSpotFleetRequest#iam_instance_profile_arn}
        */
        readonly iamInstanceProfileArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#instance_type TfSpotFleetRequest#instance_type}
        */
        readonly instanceType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#key_name TfSpotFleetRequest#key_name}
        */
        readonly keyName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#monitoring TfSpotFleetRequest#monitoring}
        */
        readonly monitoring?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#placement_group TfSpotFleetRequest#placement_group}
        */
        readonly placementGroup?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#placement_tenancy TfSpotFleetRequest#placement_tenancy}
        */
        readonly placementTenancy?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#spot_price TfSpotFleetRequest#spot_price}
        */
        readonly spotPrice?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#subnet_id TfSpotFleetRequest#subnet_id}
        */
        readonly subnetId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#tags TfSpotFleetRequest#tags}
        */
        readonly tags?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#user_data TfSpotFleetRequest#user_data}
        */
        readonly userData?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#vpc_security_group_ids TfSpotFleetRequest#vpc_security_group_ids}
        */
        readonly vpcSecurityGroupIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#weighted_capacity TfSpotFleetRequest#weighted_capacity}
        */
        readonly weightedCapacity?: string;
        /**
        * ebs_block_device block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#ebs_block_device TfSpotFleetRequest#ebs_block_device}
        */
        readonly ebsBlockDevice?: EbsBlockDeviceProperty[] | cdktn.IResolvable;
        /**
        * ephemeral_block_device block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#ephemeral_block_device TfSpotFleetRequest#ephemeral_block_device}
        */
        readonly ephemeralBlockDevice?: EphemeralBlockDeviceProperty[] | cdktn.IResolvable;
        /**
        * root_block_device block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#root_block_device TfSpotFleetRequest#root_block_device}
        */
        readonly rootBlockDevice?: RootBlockDeviceProperty[] | cdktn.IResolvable;
    }
    class LaunchSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LaunchSpecificationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LaunchSpecificationProperty | cdktn.IResolvable | undefined);
        private _ami?;
        get ami(): string;
        set ami(value: string);
        get amiInput(): string | undefined;
        private _associatePublicIpAddress?;
        get associatePublicIpAddress(): boolean | cdktn.IResolvable;
        set associatePublicIpAddress(value: boolean | cdktn.IResolvable);
        resetAssociatePublicIpAddress(): void;
        get associatePublicIpAddressInput(): boolean | cdktn.IResolvable | undefined;
        private _availabilityZone?;
        get availabilityZone(): string;
        set availabilityZone(value: string);
        resetAvailabilityZone(): void;
        get availabilityZoneInput(): string | undefined;
        private _ebsOptimized?;
        get ebsOptimized(): boolean | cdktn.IResolvable;
        set ebsOptimized(value: boolean | cdktn.IResolvable);
        resetEbsOptimized(): void;
        get ebsOptimizedInput(): boolean | cdktn.IResolvable | undefined;
        private _iamInstanceProfile?;
        get iamInstanceProfile(): string;
        set iamInstanceProfile(value: string);
        resetIamInstanceProfile(): void;
        get iamInstanceProfileInput(): string | undefined;
        private _iamInstanceProfileArn?;
        get iamInstanceProfileArn(): string;
        set iamInstanceProfileArn(value: string);
        resetIamInstanceProfileArn(): void;
        get iamInstanceProfileArnInput(): string | undefined;
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        get instanceTypeInput(): string | undefined;
        private _keyName?;
        get keyName(): string;
        set keyName(value: string);
        resetKeyName(): void;
        get keyNameInput(): string | undefined;
        private _monitoring?;
        get monitoring(): boolean | cdktn.IResolvable;
        set monitoring(value: boolean | cdktn.IResolvable);
        resetMonitoring(): void;
        get monitoringInput(): boolean | cdktn.IResolvable | undefined;
        private _placementGroup?;
        get placementGroup(): string;
        set placementGroup(value: string);
        resetPlacementGroup(): void;
        get placementGroupInput(): string | undefined;
        private _placementTenancy?;
        get placementTenancy(): string;
        set placementTenancy(value: string);
        resetPlacementTenancy(): void;
        get placementTenancyInput(): string | undefined;
        private _spotPrice?;
        get spotPrice(): string;
        set spotPrice(value: string);
        resetSpotPrice(): void;
        get spotPriceInput(): string | undefined;
        private _subnetId?;
        get subnetId(): string;
        set subnetId(value: string);
        resetSubnetId(): void;
        get subnetIdInput(): string | undefined;
        private _tags?;
        get tags(): {
            [key: string]: string;
        };
        set tags(value: {
            [key: string]: string;
        });
        resetTags(): void;
        get tagsInput(): {
            [key: string]: string;
        } | undefined;
        private _userData?;
        get userData(): string;
        set userData(value: string);
        resetUserData(): void;
        get userDataInput(): string | undefined;
        private _vpcSecurityGroupIds?;
        get vpcSecurityGroupIds(): string[];
        set vpcSecurityGroupIds(value: string[]);
        resetVpcSecurityGroupIds(): void;
        get vpcSecurityGroupIdsInput(): string[] | undefined;
        private _weightedCapacity?;
        get weightedCapacity(): string;
        set weightedCapacity(value: string);
        resetWeightedCapacity(): void;
        get weightedCapacityInput(): string | undefined;
        private _ebsBlockDevice;
        get ebsBlockDevice(): EbsBlockDevicePropertyList;
        putEbsBlockDevice(value: EbsBlockDeviceProperty[] | cdktn.IResolvable): void;
        resetEbsBlockDevice(): void;
        get ebsBlockDeviceInput(): cdktn.IResolvable | EbsBlockDeviceProperty[] | undefined;
        private _ephemeralBlockDevice;
        get ephemeralBlockDevice(): EphemeralBlockDevicePropertyList;
        putEphemeralBlockDevice(value: EphemeralBlockDeviceProperty[] | cdktn.IResolvable): void;
        resetEphemeralBlockDevice(): void;
        get ephemeralBlockDeviceInput(): cdktn.IResolvable | EphemeralBlockDeviceProperty[] | undefined;
        private _rootBlockDevice;
        get rootBlockDevice(): RootBlockDevicePropertyList;
        putRootBlockDevice(value: RootBlockDeviceProperty[] | cdktn.IResolvable): void;
        resetRootBlockDevice(): void;
        get rootBlockDeviceInput(): cdktn.IResolvable | RootBlockDeviceProperty[] | undefined;
    }
    class LaunchSpecificationPropertyList extends cdktn.ComplexList {
        internalValue?: LaunchSpecificationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LaunchSpecificationPropertyOutputReference;
    }
    interface LaunchTemplateSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#id TfSpotFleetRequest#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#name TfSpotFleetRequest#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#version TfSpotFleetRequest#version}
        */
        readonly version?: string;
    }
    class LaunchTemplateSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LaunchTemplateSpecificationProperty | undefined;
        set internalValue(value: LaunchTemplateSpecificationProperty | undefined);
        private _id?;
        get id(): string;
        set id(value: string);
        resetId(): void;
        get idInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _version?;
        get version(): string;
        set version(value: string);
        resetVersion(): void;
        get versionInput(): string | undefined;
    }
    interface AcceleratorCountProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#max TfSpotFleetRequest#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#min TfSpotFleetRequest#min}
        */
        readonly min?: number;
    }
    class AcceleratorCountPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AcceleratorCountProperty | undefined;
        set internalValue(value: AcceleratorCountProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface AcceleratorTotalMemoryMibProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#max TfSpotFleetRequest#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#min TfSpotFleetRequest#min}
        */
        readonly min?: number;
    }
    class AcceleratorTotalMemoryMibPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AcceleratorTotalMemoryMibProperty | undefined;
        set internalValue(value: AcceleratorTotalMemoryMibProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface BaselineEbsBandwidthMbpsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#max TfSpotFleetRequest#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#min TfSpotFleetRequest#min}
        */
        readonly min?: number;
    }
    class BaselineEbsBandwidthMbpsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BaselineEbsBandwidthMbpsProperty | undefined;
        set internalValue(value: BaselineEbsBandwidthMbpsProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface MemoryGibPerVcpuProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#max TfSpotFleetRequest#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#min TfSpotFleetRequest#min}
        */
        readonly min?: number;
    }
    class MemoryGibPerVcpuPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MemoryGibPerVcpuProperty | undefined;
        set internalValue(value: MemoryGibPerVcpuProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface MemoryMibProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#max TfSpotFleetRequest#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#min TfSpotFleetRequest#min}
        */
        readonly min?: number;
    }
    class MemoryMibPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MemoryMibProperty | undefined;
        set internalValue(value: MemoryMibProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface NetworkBandwidthGbpsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#max TfSpotFleetRequest#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#min TfSpotFleetRequest#min}
        */
        readonly min?: number;
    }
    class NetworkBandwidthGbpsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NetworkBandwidthGbpsProperty | undefined;
        set internalValue(value: NetworkBandwidthGbpsProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface NetworkInterfaceCountProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#max TfSpotFleetRequest#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#min TfSpotFleetRequest#min}
        */
        readonly min?: number;
    }
    class NetworkInterfaceCountPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NetworkInterfaceCountProperty | undefined;
        set internalValue(value: NetworkInterfaceCountProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface TotalLocalStorageGbProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#max TfSpotFleetRequest#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#min TfSpotFleetRequest#min}
        */
        readonly min?: number;
    }
    class TotalLocalStorageGbPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TotalLocalStorageGbProperty | undefined;
        set internalValue(value: TotalLocalStorageGbProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface VcpuCountProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#max TfSpotFleetRequest#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#min TfSpotFleetRequest#min}
        */
        readonly min?: number;
    }
    class VcpuCountPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VcpuCountProperty | undefined;
        set internalValue(value: VcpuCountProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface InstanceRequirementsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#accelerator_manufacturers TfSpotFleetRequest#accelerator_manufacturers}
        */
        readonly acceleratorManufacturers?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#accelerator_names TfSpotFleetRequest#accelerator_names}
        */
        readonly acceleratorNames?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#accelerator_types TfSpotFleetRequest#accelerator_types}
        */
        readonly acceleratorTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#allowed_instance_types TfSpotFleetRequest#allowed_instance_types}
        */
        readonly allowedInstanceTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#bare_metal TfSpotFleetRequest#bare_metal}
        */
        readonly bareMetal?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#burstable_performance TfSpotFleetRequest#burstable_performance}
        */
        readonly burstablePerformance?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#cpu_manufacturers TfSpotFleetRequest#cpu_manufacturers}
        */
        readonly cpuManufacturers?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#excluded_instance_types TfSpotFleetRequest#excluded_instance_types}
        */
        readonly excludedInstanceTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#instance_generations TfSpotFleetRequest#instance_generations}
        */
        readonly instanceGenerations?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#local_storage TfSpotFleetRequest#local_storage}
        */
        readonly localStorage?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#local_storage_types TfSpotFleetRequest#local_storage_types}
        */
        readonly localStorageTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#on_demand_max_price_percentage_over_lowest_price TfSpotFleetRequest#on_demand_max_price_percentage_over_lowest_price}
        */
        readonly onDemandMaxPricePercentageOverLowestPrice?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#require_hibernate_support TfSpotFleetRequest#require_hibernate_support}
        */
        readonly requireHibernateSupport?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#spot_max_price_percentage_over_lowest_price TfSpotFleetRequest#spot_max_price_percentage_over_lowest_price}
        */
        readonly spotMaxPricePercentageOverLowestPrice?: number;
        /**
        * accelerator_count block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#accelerator_count TfSpotFleetRequest#accelerator_count}
        */
        readonly acceleratorCount?: AcceleratorCountProperty;
        /**
        * accelerator_total_memory_mib block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#accelerator_total_memory_mib TfSpotFleetRequest#accelerator_total_memory_mib}
        */
        readonly acceleratorTotalMemoryMib?: AcceleratorTotalMemoryMibProperty;
        /**
        * baseline_ebs_bandwidth_mbps block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#baseline_ebs_bandwidth_mbps TfSpotFleetRequest#baseline_ebs_bandwidth_mbps}
        */
        readonly baselineEbsBandwidthMbps?: BaselineEbsBandwidthMbpsProperty;
        /**
        * memory_gib_per_vcpu block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#memory_gib_per_vcpu TfSpotFleetRequest#memory_gib_per_vcpu}
        */
        readonly memoryGibPerVcpu?: MemoryGibPerVcpuProperty;
        /**
        * memory_mib block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#memory_mib TfSpotFleetRequest#memory_mib}
        */
        readonly memoryMib?: MemoryMibProperty;
        /**
        * network_bandwidth_gbps block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#network_bandwidth_gbps TfSpotFleetRequest#network_bandwidth_gbps}
        */
        readonly networkBandwidthGbps?: NetworkBandwidthGbpsProperty;
        /**
        * network_interface_count block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#network_interface_count TfSpotFleetRequest#network_interface_count}
        */
        readonly networkInterfaceCount?: NetworkInterfaceCountProperty;
        /**
        * total_local_storage_gb block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#total_local_storage_gb TfSpotFleetRequest#total_local_storage_gb}
        */
        readonly totalLocalStorageGb?: TotalLocalStorageGbProperty;
        /**
        * vcpu_count block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#vcpu_count TfSpotFleetRequest#vcpu_count}
        */
        readonly vcpuCount?: VcpuCountProperty;
    }
    class InstanceRequirementsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InstanceRequirementsProperty | undefined;
        set internalValue(value: InstanceRequirementsProperty | undefined);
        private _acceleratorManufacturers?;
        get acceleratorManufacturers(): string[];
        set acceleratorManufacturers(value: string[]);
        resetAcceleratorManufacturers(): void;
        get acceleratorManufacturersInput(): string[] | undefined;
        private _acceleratorNames?;
        get acceleratorNames(): string[];
        set acceleratorNames(value: string[]);
        resetAcceleratorNames(): void;
        get acceleratorNamesInput(): string[] | undefined;
        private _acceleratorTypes?;
        get acceleratorTypes(): string[];
        set acceleratorTypes(value: string[]);
        resetAcceleratorTypes(): void;
        get acceleratorTypesInput(): string[] | undefined;
        private _allowedInstanceTypes?;
        get allowedInstanceTypes(): string[];
        set allowedInstanceTypes(value: string[]);
        resetAllowedInstanceTypes(): void;
        get allowedInstanceTypesInput(): string[] | undefined;
        private _bareMetal?;
        get bareMetal(): string;
        set bareMetal(value: string);
        resetBareMetal(): void;
        get bareMetalInput(): string | undefined;
        private _burstablePerformance?;
        get burstablePerformance(): string;
        set burstablePerformance(value: string);
        resetBurstablePerformance(): void;
        get burstablePerformanceInput(): string | undefined;
        private _cpuManufacturers?;
        get cpuManufacturers(): string[];
        set cpuManufacturers(value: string[]);
        resetCpuManufacturers(): void;
        get cpuManufacturersInput(): string[] | undefined;
        private _excludedInstanceTypes?;
        get excludedInstanceTypes(): string[];
        set excludedInstanceTypes(value: string[]);
        resetExcludedInstanceTypes(): void;
        get excludedInstanceTypesInput(): string[] | undefined;
        private _instanceGenerations?;
        get instanceGenerations(): string[];
        set instanceGenerations(value: string[]);
        resetInstanceGenerations(): void;
        get instanceGenerationsInput(): string[] | undefined;
        private _localStorage?;
        get localStorage(): string;
        set localStorage(value: string);
        resetLocalStorage(): void;
        get localStorageInput(): string | undefined;
        private _localStorageTypes?;
        get localStorageTypes(): string[];
        set localStorageTypes(value: string[]);
        resetLocalStorageTypes(): void;
        get localStorageTypesInput(): string[] | undefined;
        private _onDemandMaxPricePercentageOverLowestPrice?;
        get onDemandMaxPricePercentageOverLowestPrice(): number;
        set onDemandMaxPricePercentageOverLowestPrice(value: number);
        resetOnDemandMaxPricePercentageOverLowestPrice(): void;
        get onDemandMaxPricePercentageOverLowestPriceInput(): number | undefined;
        private _requireHibernateSupport?;
        get requireHibernateSupport(): boolean | cdktn.IResolvable;
        set requireHibernateSupport(value: boolean | cdktn.IResolvable);
        resetRequireHibernateSupport(): void;
        get requireHibernateSupportInput(): boolean | cdktn.IResolvable | undefined;
        private _spotMaxPricePercentageOverLowestPrice?;
        get spotMaxPricePercentageOverLowestPrice(): number;
        set spotMaxPricePercentageOverLowestPrice(value: number);
        resetSpotMaxPricePercentageOverLowestPrice(): void;
        get spotMaxPricePercentageOverLowestPriceInput(): number | undefined;
        private _acceleratorCount;
        get acceleratorCount(): AcceleratorCountPropertyOutputReference;
        putAcceleratorCount(value: AcceleratorCountProperty): void;
        resetAcceleratorCount(): void;
        get acceleratorCountInput(): AcceleratorCountProperty | undefined;
        private _acceleratorTotalMemoryMib;
        get acceleratorTotalMemoryMib(): AcceleratorTotalMemoryMibPropertyOutputReference;
        putAcceleratorTotalMemoryMib(value: AcceleratorTotalMemoryMibProperty): void;
        resetAcceleratorTotalMemoryMib(): void;
        get acceleratorTotalMemoryMibInput(): AcceleratorTotalMemoryMibProperty | undefined;
        private _baselineEbsBandwidthMbps;
        get baselineEbsBandwidthMbps(): BaselineEbsBandwidthMbpsPropertyOutputReference;
        putBaselineEbsBandwidthMbps(value: BaselineEbsBandwidthMbpsProperty): void;
        resetBaselineEbsBandwidthMbps(): void;
        get baselineEbsBandwidthMbpsInput(): BaselineEbsBandwidthMbpsProperty | undefined;
        private _memoryGibPerVcpu;
        get memoryGibPerVcpu(): MemoryGibPerVcpuPropertyOutputReference;
        putMemoryGibPerVcpu(value: MemoryGibPerVcpuProperty): void;
        resetMemoryGibPerVcpu(): void;
        get memoryGibPerVcpuInput(): MemoryGibPerVcpuProperty | undefined;
        private _memoryMib;
        get memoryMib(): MemoryMibPropertyOutputReference;
        putMemoryMib(value: MemoryMibProperty): void;
        resetMemoryMib(): void;
        get memoryMibInput(): MemoryMibProperty | undefined;
        private _networkBandwidthGbps;
        get networkBandwidthGbps(): NetworkBandwidthGbpsPropertyOutputReference;
        putNetworkBandwidthGbps(value: NetworkBandwidthGbpsProperty): void;
        resetNetworkBandwidthGbps(): void;
        get networkBandwidthGbpsInput(): NetworkBandwidthGbpsProperty | undefined;
        private _networkInterfaceCount;
        get networkInterfaceCount(): NetworkInterfaceCountPropertyOutputReference;
        putNetworkInterfaceCount(value: NetworkInterfaceCountProperty): void;
        resetNetworkInterfaceCount(): void;
        get networkInterfaceCountInput(): NetworkInterfaceCountProperty | undefined;
        private _totalLocalStorageGb;
        get totalLocalStorageGb(): TotalLocalStorageGbPropertyOutputReference;
        putTotalLocalStorageGb(value: TotalLocalStorageGbProperty): void;
        resetTotalLocalStorageGb(): void;
        get totalLocalStorageGbInput(): TotalLocalStorageGbProperty | undefined;
        private _vcpuCount;
        get vcpuCount(): VcpuCountPropertyOutputReference;
        putVcpuCount(value: VcpuCountProperty): void;
        resetVcpuCount(): void;
        get vcpuCountInput(): VcpuCountProperty | undefined;
    }
    interface OverridesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#availability_zone TfSpotFleetRequest#availability_zone}
        */
        readonly availabilityZone?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#instance_type TfSpotFleetRequest#instance_type}
        */
        readonly instanceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#priority TfSpotFleetRequest#priority}
        */
        readonly priority?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#spot_price TfSpotFleetRequest#spot_price}
        */
        readonly spotPrice?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#subnet_id TfSpotFleetRequest#subnet_id}
        */
        readonly subnetId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#weighted_capacity TfSpotFleetRequest#weighted_capacity}
        */
        readonly weightedCapacity?: number;
        /**
        * instance_requirements block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#instance_requirements TfSpotFleetRequest#instance_requirements}
        */
        readonly instanceRequirements?: InstanceRequirementsProperty;
    }
    class OverridesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OverridesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OverridesProperty | cdktn.IResolvable | undefined);
        private _availabilityZone?;
        get availabilityZone(): string;
        set availabilityZone(value: string);
        resetAvailabilityZone(): void;
        get availabilityZoneInput(): string | undefined;
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        resetInstanceType(): void;
        get instanceTypeInput(): string | undefined;
        private _priority?;
        get priority(): number;
        set priority(value: number);
        resetPriority(): void;
        get priorityInput(): number | undefined;
        private _spotPrice?;
        get spotPrice(): string;
        set spotPrice(value: string);
        resetSpotPrice(): void;
        get spotPriceInput(): string | undefined;
        private _subnetId?;
        get subnetId(): string;
        set subnetId(value: string);
        resetSubnetId(): void;
        get subnetIdInput(): string | undefined;
        private _weightedCapacity?;
        get weightedCapacity(): number;
        set weightedCapacity(value: number);
        resetWeightedCapacity(): void;
        get weightedCapacityInput(): number | undefined;
        private _instanceRequirements;
        get instanceRequirements(): InstanceRequirementsPropertyOutputReference;
        putInstanceRequirements(value: InstanceRequirementsProperty): void;
        resetInstanceRequirements(): void;
        get instanceRequirementsInput(): InstanceRequirementsProperty | undefined;
    }
    class OverridesPropertyList extends cdktn.ComplexList {
        internalValue?: OverridesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OverridesPropertyOutputReference;
    }
    interface LaunchTemplateConfigProperty {
        /**
        * launch_template_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#launch_template_specification TfSpotFleetRequest#launch_template_specification}
        */
        readonly launchTemplateSpecification: LaunchTemplateSpecificationProperty;
        /**
        * overrides block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#overrides TfSpotFleetRequest#overrides}
        */
        readonly overrides?: OverridesProperty[] | cdktn.IResolvable;
    }
    class LaunchTemplateConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LaunchTemplateConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LaunchTemplateConfigProperty | cdktn.IResolvable | undefined);
        private _launchTemplateSpecification;
        get launchTemplateSpecification(): LaunchTemplateSpecificationPropertyOutputReference;
        putLaunchTemplateSpecification(value: LaunchTemplateSpecificationProperty): void;
        get launchTemplateSpecificationInput(): LaunchTemplateSpecificationProperty | undefined;
        private _overrides;
        get overrides(): OverridesPropertyList;
        putOverrides(value: OverridesProperty[] | cdktn.IResolvable): void;
        resetOverrides(): void;
        get overridesInput(): cdktn.IResolvable | OverridesProperty[] | undefined;
    }
    class LaunchTemplateConfigPropertyList extends cdktn.ComplexList {
        internalValue?: LaunchTemplateConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LaunchTemplateConfigPropertyOutputReference;
    }
    interface CapacityRebalanceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#replacement_strategy TfSpotFleetRequest#replacement_strategy}
        */
        readonly replacementStrategy?: string;
    }
    class CapacityRebalancePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CapacityRebalanceProperty | undefined;
        set internalValue(value: CapacityRebalanceProperty | undefined);
        private _replacementStrategy?;
        get replacementStrategy(): string;
        set replacementStrategy(value: string);
        resetReplacementStrategy(): void;
        get replacementStrategyInput(): string | undefined;
    }
    interface SpotMaintenanceStrategiesProperty {
        /**
        * capacity_rebalance block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#capacity_rebalance TfSpotFleetRequest#capacity_rebalance}
        */
        readonly capacityRebalance?: CapacityRebalanceProperty;
    }
    class SpotMaintenanceStrategiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpotMaintenanceStrategiesProperty | undefined;
        set internalValue(value: SpotMaintenanceStrategiesProperty | undefined);
        private _capacityRebalance;
        get capacityRebalance(): CapacityRebalancePropertyOutputReference;
        putCapacityRebalance(value: CapacityRebalanceProperty): void;
        resetCapacityRebalance(): void;
        get capacityRebalanceInput(): CapacityRebalanceProperty | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#create TfSpotFleetRequest#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#delete TfSpotFleetRequest#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_fleet_request#update TfSpotFleetRequest#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
