import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfAmiConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami#architecture TfAmi#architecture}
    */
    readonly architecture?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami#boot_mode TfAmi#boot_mode}
    */
    readonly bootMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami#deprecation_time TfAmi#deprecation_time}
    */
    readonly deprecationTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami#description TfAmi#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami#ena_support TfAmi#ena_support}
    */
    readonly enaSupport?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami#id TfAmi#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami#image_location TfAmi#image_location}
    */
    readonly imageLocation?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami#imds_support TfAmi#imds_support}
    */
    readonly imdsSupport?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami#kernel_id TfAmi#kernel_id}
    */
    readonly kernelId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami#name TfAmi#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami#ramdisk_id TfAmi#ramdisk_id}
    */
    readonly ramdiskId?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami#region TfAmi#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami#root_device_name TfAmi#root_device_name}
    */
    readonly rootDeviceName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami#sriov_net_support TfAmi#sriov_net_support}
    */
    readonly sriovNetSupport?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami#tags TfAmi#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami#tags_all TfAmi#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami#tpm_support TfAmi#tpm_support}
    */
    readonly tpmSupport?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami#uefi_data TfAmi#uefi_data}
    */
    readonly uefiData?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami#virtualization_type TfAmi#virtualization_type}
    */
    readonly virtualizationType?: string;
    /**
    * ebs_block_device block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami#ebs_block_device TfAmi#ebs_block_device}
    */
    readonly ebsBlockDevice?: TfAmi.EbsBlockDeviceProperty[] | cdktn.IResolvable;
    /**
    * ephemeral_block_device block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami#ephemeral_block_device TfAmi#ephemeral_block_device}
    */
    readonly ephemeralBlockDevice?: TfAmi.EphemeralBlockDeviceProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami#timeouts TfAmi#timeouts}
    */
    readonly timeouts?: TfAmi.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami aws_ami}
*/
export declare class TfAmi extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ami";
    /**
    * Generates CDKTN code for importing a TfAmi resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfAmi to import
    * @param importFromId The id of the existing TfAmi that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfAmi to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami aws_ami} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfAmiConfig
    */
    constructor(scope: Construct, id: string, config: TfAmiConfig);
    private _architecture?;
    get architecture(): string;
    set architecture(value: string);
    resetArchitecture(): void;
    get architectureInput(): string | undefined;
    get arn(): string;
    private _bootMode?;
    get bootMode(): string;
    set bootMode(value: string);
    resetBootMode(): void;
    get bootModeInput(): string | undefined;
    private _deprecationTime?;
    get deprecationTime(): string;
    set deprecationTime(value: string);
    resetDeprecationTime(): void;
    get deprecationTimeInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enaSupport?;
    get enaSupport(): boolean | cdktn.IResolvable;
    set enaSupport(value: boolean | cdktn.IResolvable);
    resetEnaSupport(): void;
    get enaSupportInput(): boolean | cdktn.IResolvable | undefined;
    get hypervisor(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _imageLocation?;
    get imageLocation(): string;
    set imageLocation(value: string);
    resetImageLocation(): void;
    get imageLocationInput(): string | undefined;
    get imageOwnerAlias(): string;
    get imageType(): string;
    private _imdsSupport?;
    get imdsSupport(): string;
    set imdsSupport(value: string);
    resetImdsSupport(): void;
    get imdsSupportInput(): string | undefined;
    private _kernelId?;
    get kernelId(): string;
    set kernelId(value: string);
    resetKernelId(): void;
    get kernelIdInput(): string | undefined;
    get lastLaunchedTime(): string;
    get manageEbsSnapshots(): cdktn.IResolvable;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get ownerId(): string;
    get platform(): string;
    get platformDetails(): string;
    get public(): cdktn.IResolvable;
    private _ramdiskId?;
    get ramdiskId(): string;
    set ramdiskId(value: string);
    resetRamdiskId(): void;
    get ramdiskIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _rootDeviceName?;
    get rootDeviceName(): string;
    set rootDeviceName(value: string);
    resetRootDeviceName(): void;
    get rootDeviceNameInput(): string | undefined;
    get rootSnapshotId(): string;
    private _sriovNetSupport?;
    get sriovNetSupport(): string;
    set sriovNetSupport(value: string);
    resetSriovNetSupport(): void;
    get sriovNetSupportInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _tpmSupport?;
    get tpmSupport(): string;
    set tpmSupport(value: string);
    resetTpmSupport(): void;
    get tpmSupportInput(): string | undefined;
    private _uefiData?;
    get uefiData(): string;
    set uefiData(value: string);
    resetUefiData(): void;
    get uefiDataInput(): string | undefined;
    get usageOperation(): string;
    private _virtualizationType?;
    get virtualizationType(): string;
    set virtualizationType(value: string);
    resetVirtualizationType(): void;
    get virtualizationTypeInput(): string | undefined;
    private _ebsBlockDevice;
    get ebsBlockDevice(): TfAmi.EbsBlockDevicePropertyList;
    putEbsBlockDevice(value: TfAmi.EbsBlockDeviceProperty[] | cdktn.IResolvable): void;
    resetEbsBlockDevice(): void;
    get ebsBlockDeviceInput(): cdktn.IResolvable | TfAmi.EbsBlockDeviceProperty[] | undefined;
    private _ephemeralBlockDevice;
    get ephemeralBlockDevice(): TfAmi.EphemeralBlockDevicePropertyList;
    putEphemeralBlockDevice(value: TfAmi.EphemeralBlockDeviceProperty[] | cdktn.IResolvable): void;
    resetEphemeralBlockDevice(): void;
    get ephemeralBlockDeviceInput(): cdktn.IResolvable | TfAmi.EphemeralBlockDeviceProperty[] | undefined;
    private _timeouts;
    get timeouts(): TfAmi.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfAmi.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfAmi.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfAmiEbsBlockDevicePropertyToTerraform(struct?: TfAmi.EbsBlockDeviceProperty | cdktn.IResolvable): any;
export declare function tfAmiEbsBlockDevicePropertyToHclTerraform(struct?: TfAmi.EbsBlockDeviceProperty | cdktn.IResolvable): any;
export declare function tfAmiEphemeralBlockDevicePropertyToTerraform(struct?: TfAmi.EphemeralBlockDeviceProperty | cdktn.IResolvable): any;
export declare function tfAmiEphemeralBlockDevicePropertyToHclTerraform(struct?: TfAmi.EphemeralBlockDeviceProperty | cdktn.IResolvable): any;
export declare function tfAmiTimeoutsPropertyToTerraform(struct?: TfAmi.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfAmiTimeoutsPropertyToHclTerraform(struct?: TfAmi.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfAmi {
    interface EbsBlockDeviceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami#delete_on_termination TfAmi#delete_on_termination}
        */
        readonly deleteOnTermination?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami#device_name TfAmi#device_name}
        */
        readonly deviceName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami#encrypted TfAmi#encrypted}
        */
        readonly encrypted?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami#iops TfAmi#iops}
        */
        readonly iops?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami#outpost_arn TfAmi#outpost_arn}
        */
        readonly outpostArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami#snapshot_id TfAmi#snapshot_id}
        */
        readonly snapshotId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami#throughput TfAmi#throughput}
        */
        readonly throughput?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami#volume_size TfAmi#volume_size}
        */
        readonly volumeSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami#volume_type TfAmi#volume_type}
        */
        readonly volumeType?: string;
    }
    class EbsBlockDevicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EbsBlockDeviceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EbsBlockDeviceProperty | cdktn.IResolvable | undefined);
        private _deleteOnTermination?;
        get deleteOnTermination(): boolean | cdktn.IResolvable;
        set deleteOnTermination(value: boolean | cdktn.IResolvable);
        resetDeleteOnTermination(): void;
        get deleteOnTerminationInput(): boolean | cdktn.IResolvable | undefined;
        private _deviceName?;
        get deviceName(): string;
        set deviceName(value: string);
        get deviceNameInput(): string | undefined;
        private _encrypted?;
        get encrypted(): boolean | cdktn.IResolvable;
        set encrypted(value: boolean | cdktn.IResolvable);
        resetEncrypted(): void;
        get encryptedInput(): boolean | cdktn.IResolvable | undefined;
        private _iops?;
        get iops(): number;
        set iops(value: number);
        resetIops(): void;
        get iopsInput(): number | undefined;
        private _outpostArn?;
        get outpostArn(): string;
        set outpostArn(value: string);
        resetOutpostArn(): void;
        get outpostArnInput(): string | undefined;
        private _snapshotId?;
        get snapshotId(): string;
        set snapshotId(value: string);
        resetSnapshotId(): void;
        get snapshotIdInput(): string | undefined;
        private _throughput?;
        get throughput(): number;
        set throughput(value: number);
        resetThroughput(): void;
        get throughputInput(): number | undefined;
        private _volumeSize?;
        get volumeSize(): number;
        set volumeSize(value: number);
        resetVolumeSize(): void;
        get volumeSizeInput(): number | undefined;
        private _volumeType?;
        get volumeType(): string;
        set volumeType(value: string);
        resetVolumeType(): void;
        get volumeTypeInput(): string | undefined;
    }
    class EbsBlockDevicePropertyList extends cdktn.ComplexList {
        internalValue?: EbsBlockDeviceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EbsBlockDevicePropertyOutputReference;
    }
    interface EphemeralBlockDeviceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami#device_name TfAmi#device_name}
        */
        readonly deviceName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami#virtual_name TfAmi#virtual_name}
        */
        readonly virtualName: string;
    }
    class EphemeralBlockDevicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EphemeralBlockDeviceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EphemeralBlockDeviceProperty | cdktn.IResolvable | undefined);
        private _deviceName?;
        get deviceName(): string;
        set deviceName(value: string);
        get deviceNameInput(): string | undefined;
        private _virtualName?;
        get virtualName(): string;
        set virtualName(value: string);
        get virtualNameInput(): string | undefined;
    }
    class EphemeralBlockDevicePropertyList extends cdktn.ComplexList {
        internalValue?: EphemeralBlockDeviceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EphemeralBlockDevicePropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami#create TfAmi#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami#delete TfAmi#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami#update TfAmi#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
