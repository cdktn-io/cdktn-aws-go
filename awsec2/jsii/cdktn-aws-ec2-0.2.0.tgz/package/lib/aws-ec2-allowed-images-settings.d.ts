import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfAllowedImagesSettingsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_allowed_images_settings#region TfAllowedImagesSettings#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_allowed_images_settings#state TfAllowedImagesSettings#state}
    */
    readonly state: string;
    /**
    * image_criterion block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_allowed_images_settings#image_criterion TfAllowedImagesSettings#image_criterion}
    */
    readonly imageCriterion?: TfAllowedImagesSettings.ImageCriterionProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_allowed_images_settings aws_ec2_allowed_images_settings}
*/
export declare class TfAllowedImagesSettings extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ec2_allowed_images_settings";
    /**
    * Generates CDKTN code for importing a TfAllowedImagesSettings resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfAllowedImagesSettings to import
    * @param importFromId The id of the existing TfAllowedImagesSettings that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_allowed_images_settings#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfAllowedImagesSettings to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_allowed_images_settings aws_ec2_allowed_images_settings} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfAllowedImagesSettingsConfig
    */
    constructor(scope: Construct, id: string, config: TfAllowedImagesSettingsConfig);
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _state?;
    get state(): string;
    set state(value: string);
    get stateInput(): string | undefined;
    private _imageCriterion;
    get imageCriterion(): TfAllowedImagesSettings.ImageCriterionPropertyList;
    putImageCriterion(value: TfAllowedImagesSettings.ImageCriterionProperty[] | cdktn.IResolvable): void;
    resetImageCriterion(): void;
    get imageCriterionInput(): cdktn.IResolvable | TfAllowedImagesSettings.ImageCriterionProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfAllowedImagesSettingsCreationDateConditionPropertyToTerraform(struct?: TfAllowedImagesSettings.CreationDateConditionProperty | cdktn.IResolvable): any;
export declare function tfAllowedImagesSettingsCreationDateConditionPropertyToHclTerraform(struct?: TfAllowedImagesSettings.CreationDateConditionProperty | cdktn.IResolvable): any;
export declare function tfAllowedImagesSettingsDeprecationTimeConditionPropertyToTerraform(struct?: TfAllowedImagesSettings.DeprecationTimeConditionProperty | cdktn.IResolvable): any;
export declare function tfAllowedImagesSettingsDeprecationTimeConditionPropertyToHclTerraform(struct?: TfAllowedImagesSettings.DeprecationTimeConditionProperty | cdktn.IResolvable): any;
export declare function tfAllowedImagesSettingsImageCriterionPropertyToTerraform(struct?: TfAllowedImagesSettings.ImageCriterionProperty | cdktn.IResolvable): any;
export declare function tfAllowedImagesSettingsImageCriterionPropertyToHclTerraform(struct?: TfAllowedImagesSettings.ImageCriterionProperty | cdktn.IResolvable): any;
export declare namespace TfAllowedImagesSettings {
    interface CreationDateConditionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_allowed_images_settings#maximum_days_since_created TfAllowedImagesSettings#maximum_days_since_created}
        */
        readonly maximumDaysSinceCreated?: number;
    }
    class CreationDateConditionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CreationDateConditionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CreationDateConditionProperty | cdktn.IResolvable | undefined);
        private _maximumDaysSinceCreated?;
        get maximumDaysSinceCreated(): number;
        set maximumDaysSinceCreated(value: number);
        resetMaximumDaysSinceCreated(): void;
        get maximumDaysSinceCreatedInput(): number | undefined;
    }
    class CreationDateConditionPropertyList extends cdktn.ComplexList {
        internalValue?: CreationDateConditionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CreationDateConditionPropertyOutputReference;
    }
    interface DeprecationTimeConditionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_allowed_images_settings#maximum_days_since_deprecated TfAllowedImagesSettings#maximum_days_since_deprecated}
        */
        readonly maximumDaysSinceDeprecated?: number;
    }
    class DeprecationTimeConditionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DeprecationTimeConditionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DeprecationTimeConditionProperty | cdktn.IResolvable | undefined);
        private _maximumDaysSinceDeprecated?;
        get maximumDaysSinceDeprecated(): number;
        set maximumDaysSinceDeprecated(value: number);
        resetMaximumDaysSinceDeprecated(): void;
        get maximumDaysSinceDeprecatedInput(): number | undefined;
    }
    class DeprecationTimeConditionPropertyList extends cdktn.ComplexList {
        internalValue?: DeprecationTimeConditionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DeprecationTimeConditionPropertyOutputReference;
    }
    interface ImageCriterionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_allowed_images_settings#image_names TfAllowedImagesSettings#image_names}
        */
        readonly imageNames?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_allowed_images_settings#image_providers TfAllowedImagesSettings#image_providers}
        */
        readonly imageProviders?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_allowed_images_settings#marketplace_product_codes TfAllowedImagesSettings#marketplace_product_codes}
        */
        readonly marketplaceProductCodes?: string[];
        /**
        * creation_date_condition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_allowed_images_settings#creation_date_condition TfAllowedImagesSettings#creation_date_condition}
        */
        readonly creationDateCondition?: CreationDateConditionProperty[] | cdktn.IResolvable;
        /**
        * deprecation_time_condition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_allowed_images_settings#deprecation_time_condition TfAllowedImagesSettings#deprecation_time_condition}
        */
        readonly deprecationTimeCondition?: DeprecationTimeConditionProperty[] | cdktn.IResolvable;
    }
    class ImageCriterionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ImageCriterionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ImageCriterionProperty | cdktn.IResolvable | undefined);
        private _imageNames?;
        get imageNames(): string[];
        set imageNames(value: string[]);
        resetImageNames(): void;
        get imageNamesInput(): string[] | undefined;
        private _imageProviders?;
        get imageProviders(): string[];
        set imageProviders(value: string[]);
        resetImageProviders(): void;
        get imageProvidersInput(): string[] | undefined;
        private _marketplaceProductCodes?;
        get marketplaceProductCodes(): string[];
        set marketplaceProductCodes(value: string[]);
        resetMarketplaceProductCodes(): void;
        get marketplaceProductCodesInput(): string[] | undefined;
        private _creationDateCondition;
        get creationDateCondition(): CreationDateConditionPropertyList;
        putCreationDateCondition(value: CreationDateConditionProperty[] | cdktn.IResolvable): void;
        resetCreationDateCondition(): void;
        get creationDateConditionInput(): cdktn.IResolvable | CreationDateConditionProperty[] | undefined;
        private _deprecationTimeCondition;
        get deprecationTimeCondition(): DeprecationTimeConditionPropertyList;
        putDeprecationTimeCondition(value: DeprecationTimeConditionProperty[] | cdktn.IResolvable): void;
        resetDeprecationTimeCondition(): void;
        get deprecationTimeConditionInput(): cdktn.IResolvable | DeprecationTimeConditionProperty[] | undefined;
    }
    class ImageCriterionPropertyList extends cdktn.ComplexList {
        internalValue?: ImageCriterionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ImageCriterionPropertyOutputReference;
    }
}
