import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfAvailabilityZonesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/availability_zones#all_availability_zones DataTfAvailabilityZones#all_availability_zones}
    */
    readonly allAvailabilityZones?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/availability_zones#exclude_names DataTfAvailabilityZones#exclude_names}
    */
    readonly excludeNames?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/availability_zones#exclude_zone_ids DataTfAvailabilityZones#exclude_zone_ids}
    */
    readonly excludeZoneIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/availability_zones#id DataTfAvailabilityZones#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/availability_zones#region DataTfAvailabilityZones#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/availability_zones#state DataTfAvailabilityZones#state}
    */
    readonly state?: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/availability_zones#filter DataTfAvailabilityZones#filter}
    */
    readonly filter?: DataTfAvailabilityZones.FilterProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/availability_zones#timeouts DataTfAvailabilityZones#timeouts}
    */
    readonly timeouts?: DataTfAvailabilityZones.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/availability_zones aws_availability_zones}
*/
export declare class DataTfAvailabilityZones extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_availability_zones";
    /**
    * Generates CDKTN code for importing a DataTfAvailabilityZones resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfAvailabilityZones to import
    * @param importFromId The id of the existing DataTfAvailabilityZones that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/availability_zones#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfAvailabilityZones to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/availability_zones aws_availability_zones} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfAvailabilityZonesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataTfAvailabilityZonesConfig);
    private _allAvailabilityZones?;
    get allAvailabilityZones(): boolean | cdktn.IResolvable;
    set allAvailabilityZones(value: boolean | cdktn.IResolvable);
    resetAllAvailabilityZones(): void;
    get allAvailabilityZonesInput(): boolean | cdktn.IResolvable | undefined;
    private _excludeNames?;
    get excludeNames(): string[];
    set excludeNames(value: string[]);
    resetExcludeNames(): void;
    get excludeNamesInput(): string[] | undefined;
    private _excludeZoneIds?;
    get excludeZoneIds(): string[];
    set excludeZoneIds(value: string[]);
    resetExcludeZoneIds(): void;
    get excludeZoneIdsInput(): string[] | undefined;
    get groupNames(): string[];
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get names(): string[];
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
    get zoneIds(): string[];
    private _filter;
    get filter(): DataTfAvailabilityZones.FilterPropertyList;
    putFilter(value: DataTfAvailabilityZones.FilterProperty[] | cdktn.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataTfAvailabilityZones.FilterProperty[] | undefined;
    private _timeouts;
    get timeouts(): DataTfAvailabilityZones.TimeoutsPropertyOutputReference;
    putTimeouts(value: DataTfAvailabilityZones.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataTfAvailabilityZones.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfAvailabilityZonesFilterPropertyToTerraform(struct?: DataTfAvailabilityZones.FilterProperty | cdktn.IResolvable): any;
export declare function dataTfAvailabilityZonesFilterPropertyToHclTerraform(struct?: DataTfAvailabilityZones.FilterProperty | cdktn.IResolvable): any;
export declare function dataTfAvailabilityZonesTimeoutsPropertyToTerraform(struct?: DataTfAvailabilityZones.TimeoutsProperty | cdktn.IResolvable): any;
export declare function dataTfAvailabilityZonesTimeoutsPropertyToHclTerraform(struct?: DataTfAvailabilityZones.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace DataTfAvailabilityZones {
    interface FilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/availability_zones#name DataTfAvailabilityZones#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/availability_zones#values DataTfAvailabilityZones#values}
        */
        readonly values: string[];
    }
    class FilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FilterProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class FilterPropertyList extends cdktn.ComplexList {
        internalValue?: FilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/availability_zones#read DataTfAvailabilityZones#read}
        */
        readonly read?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _read?;
        get read(): string;
        set read(value: string);
        resetRead(): void;
        get readInput(): string | undefined;
    }
}
