import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfInstanceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/instance#get_password_data DataTfInstance#get_password_data}
    */
    readonly fetchPasswordData?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/instance#get_user_data DataTfInstance#get_user_data}
    */
    readonly fetchUserData?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/instance#id DataTfInstance#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/instance#instance_id DataTfInstance#instance_id}
    */
    readonly instanceId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/instance#instance_tags DataTfInstance#instance_tags}
    */
    readonly instanceTags?: {
        [key: string]: string;
    };
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/instance#region DataTfInstance#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/instance#tags DataTfInstance#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/instance#filter DataTfInstance#filter}
    */
    readonly filter?: DataTfInstance.FilterProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/instance#timeouts DataTfInstance#timeouts}
    */
    readonly timeouts?: DataTfInstance.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/instance aws_instance}
*/
export declare class DataTfInstance extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_instance";
    /**
    * Generates CDKTN code for importing a DataTfInstance resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfInstance to import
    * @param importFromId The id of the existing DataTfInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/instance aws_instance} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfInstanceConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataTfInstanceConfig);
    get ami(): string;
    get arn(): string;
    get associatePublicIpAddress(): cdktn.IResolvable;
    get availabilityZone(): string;
    private _creditSpecification;
    get creditSpecification(): DataTfInstance.CreditSpecificationPropertyList;
    get disableApiStop(): cdktn.IResolvable;
    get disableApiTermination(): cdktn.IResolvable;
    private _ebsBlockDevice;
    get ebsBlockDevice(): DataTfInstance.EbsBlockDevicePropertyList;
    get ebsOptimized(): cdktn.IResolvable;
    private _enclaveOptions;
    get enclaveOptions(): DataTfInstance.EnclaveOptionsPropertyList;
    private _ephemeralBlockDevice;
    get ephemeralBlockDevice(): DataTfInstance.EphemeralBlockDevicePropertyList;
    private _getPasswordData?;
    get fetchPasswordData(): boolean | cdktn.IResolvable;
    set fetchPasswordData(value: boolean | cdktn.IResolvable);
    resetFetchPasswordData(): void;
    get fetchPasswordDataInput(): boolean | cdktn.IResolvable | undefined;
    private _getUserData?;
    get fetchUserData(): boolean | cdktn.IResolvable;
    set fetchUserData(value: boolean | cdktn.IResolvable);
    resetFetchUserData(): void;
    get fetchUserDataInput(): boolean | cdktn.IResolvable | undefined;
    get hostId(): string;
    get hostResourceGroupArn(): string;
    get iamInstanceProfile(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    resetInstanceId(): void;
    get instanceIdInput(): string | undefined;
    get instanceState(): string;
    private _instanceTags?;
    get instanceTags(): {
        [key: string]: string;
    };
    set instanceTags(value: {
        [key: string]: string;
    });
    resetInstanceTags(): void;
    get instanceTagsInput(): {
        [key: string]: string;
    } | undefined;
    get instanceType(): string;
    get ipv6Addresses(): string[];
    get keyName(): string;
    get launchTime(): string;
    private _maintenanceOptions;
    get maintenanceOptions(): DataTfInstance.MaintenanceOptionsPropertyList;
    private _metadataOptions;
    get metadataOptions(): DataTfInstance.MetadataOptionsPropertyList;
    get monitoring(): cdktn.IResolvable;
    get networkInterfaceId(): string;
    get outpostArn(): string;
    get passwordData(): string;
    get placementGroup(): string;
    get placementGroupId(): string;
    get placementPartitionNumber(): number;
    get privateDns(): string;
    private _privateDnsNameOptions;
    get privateDnsNameOptions(): DataTfInstance.PrivateDnsNameOptionsPropertyList;
    get privateIp(): string;
    get publicDns(): string;
    get publicIp(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _rootBlockDevice;
    get rootBlockDevice(): DataTfInstance.RootBlockDevicePropertyList;
    get secondaryPrivateIps(): string[];
    get securityGroups(): string[];
    get sourceDestCheck(): cdktn.IResolvable;
    get subnetId(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    get tenancy(): string;
    get userData(): string;
    get userDataBase64(): string;
    get vpcSecurityGroupIds(): string[];
    private _filter;
    get filter(): DataTfInstance.FilterPropertyList;
    putFilter(value: DataTfInstance.FilterProperty[] | cdktn.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataTfInstance.FilterProperty[] | undefined;
    private _timeouts;
    get timeouts(): DataTfInstance.TimeoutsPropertyOutputReference;
    putTimeouts(value: DataTfInstance.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataTfInstance.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfInstanceCreditSpecificationPropertyToTerraform(struct?: DataTfInstance.CreditSpecificationProperty): any;
export declare function dataTfInstanceCreditSpecificationPropertyToHclTerraform(struct?: DataTfInstance.CreditSpecificationProperty): any;
export declare function dataTfInstanceEbsBlockDevicePropertyToTerraform(struct?: DataTfInstance.EbsBlockDeviceProperty): any;
export declare function dataTfInstanceEbsBlockDevicePropertyToHclTerraform(struct?: DataTfInstance.EbsBlockDeviceProperty): any;
export declare function dataTfInstanceEnclaveOptionsPropertyToTerraform(struct?: DataTfInstance.EnclaveOptionsProperty): any;
export declare function dataTfInstanceEnclaveOptionsPropertyToHclTerraform(struct?: DataTfInstance.EnclaveOptionsProperty): any;
export declare function dataTfInstanceEphemeralBlockDevicePropertyToTerraform(struct?: DataTfInstance.EphemeralBlockDeviceProperty): any;
export declare function dataTfInstanceEphemeralBlockDevicePropertyToHclTerraform(struct?: DataTfInstance.EphemeralBlockDeviceProperty): any;
export declare function dataTfInstanceMaintenanceOptionsPropertyToTerraform(struct?: DataTfInstance.MaintenanceOptionsProperty): any;
export declare function dataTfInstanceMaintenanceOptionsPropertyToHclTerraform(struct?: DataTfInstance.MaintenanceOptionsProperty): any;
export declare function dataTfInstanceMetadataOptionsPropertyToTerraform(struct?: DataTfInstance.MetadataOptionsProperty): any;
export declare function dataTfInstanceMetadataOptionsPropertyToHclTerraform(struct?: DataTfInstance.MetadataOptionsProperty): any;
export declare function dataTfInstancePrivateDnsNameOptionsPropertyToTerraform(struct?: DataTfInstance.PrivateDnsNameOptionsProperty): any;
export declare function dataTfInstancePrivateDnsNameOptionsPropertyToHclTerraform(struct?: DataTfInstance.PrivateDnsNameOptionsProperty): any;
export declare function dataTfInstanceRootBlockDevicePropertyToTerraform(struct?: DataTfInstance.RootBlockDeviceProperty): any;
export declare function dataTfInstanceRootBlockDevicePropertyToHclTerraform(struct?: DataTfInstance.RootBlockDeviceProperty): any;
export declare function dataTfInstanceFilterPropertyToTerraform(struct?: DataTfInstance.FilterProperty | cdktn.IResolvable): any;
export declare function dataTfInstanceFilterPropertyToHclTerraform(struct?: DataTfInstance.FilterProperty | cdktn.IResolvable): any;
export declare function dataTfInstanceTimeoutsPropertyToTerraform(struct?: DataTfInstance.TimeoutsProperty | cdktn.IResolvable): any;
export declare function dataTfInstanceTimeoutsPropertyToHclTerraform(struct?: DataTfInstance.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace DataTfInstance {
    interface CreditSpecificationProperty {
    }
    class CreditSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CreditSpecificationProperty | undefined;
        set internalValue(value: CreditSpecificationProperty | undefined);
        get cpuCredits(): string;
    }
    class CreditSpecificationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CreditSpecificationPropertyOutputReference;
    }
    interface EbsBlockDeviceProperty {
    }
    class EbsBlockDevicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EbsBlockDeviceProperty | undefined;
        set internalValue(value: EbsBlockDeviceProperty | undefined);
        get deleteOnTermination(): cdktn.IResolvable;
        get deviceName(): string;
        get encrypted(): cdktn.IResolvable;
        get iops(): number;
        get kmsKeyId(): string;
        get snapshotId(): string;
        private _tags;
        get tags(): cdktn.StringMap;
        get throughput(): number;
        get volumeId(): string;
        get volumeSize(): number;
        get volumeType(): string;
    }
    class EbsBlockDevicePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EbsBlockDevicePropertyOutputReference;
    }
    interface EnclaveOptionsProperty {
    }
    class EnclaveOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EnclaveOptionsProperty | undefined;
        set internalValue(value: EnclaveOptionsProperty | undefined);
        get enabled(): cdktn.IResolvable;
    }
    class EnclaveOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EnclaveOptionsPropertyOutputReference;
    }
    interface EphemeralBlockDeviceProperty {
    }
    class EphemeralBlockDevicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EphemeralBlockDeviceProperty | undefined;
        set internalValue(value: EphemeralBlockDeviceProperty | undefined);
        get deviceName(): string;
        get noDevice(): cdktn.IResolvable;
        get virtualName(): string;
    }
    class EphemeralBlockDevicePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EphemeralBlockDevicePropertyOutputReference;
    }
    interface MaintenanceOptionsProperty {
    }
    class MaintenanceOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MaintenanceOptionsProperty | undefined;
        set internalValue(value: MaintenanceOptionsProperty | undefined);
        get autoRecovery(): string;
    }
    class MaintenanceOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MaintenanceOptionsPropertyOutputReference;
    }
    interface MetadataOptionsProperty {
    }
    class MetadataOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MetadataOptionsProperty | undefined;
        set internalValue(value: MetadataOptionsProperty | undefined);
        get httpEndpoint(): string;
        get httpProtocolIpv6(): string;
        get httpPutResponseHopLimit(): number;
        get httpTokens(): string;
        get instanceMetadataTags(): string;
    }
    class MetadataOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MetadataOptionsPropertyOutputReference;
    }
    interface PrivateDnsNameOptionsProperty {
    }
    class PrivateDnsNameOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PrivateDnsNameOptionsProperty | undefined;
        set internalValue(value: PrivateDnsNameOptionsProperty | undefined);
        get enableResourceNameDnsARecord(): cdktn.IResolvable;
        get enableResourceNameDnsAaaaRecord(): cdktn.IResolvable;
        get hostnameType(): string;
    }
    class PrivateDnsNameOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PrivateDnsNameOptionsPropertyOutputReference;
    }
    interface RootBlockDeviceProperty {
    }
    class RootBlockDevicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RootBlockDeviceProperty | undefined;
        set internalValue(value: RootBlockDeviceProperty | undefined);
        get deleteOnTermination(): cdktn.IResolvable;
        get deviceName(): string;
        get encrypted(): cdktn.IResolvable;
        get iops(): number;
        get kmsKeyId(): string;
        private _tags;
        get tags(): cdktn.StringMap;
        get throughput(): number;
        get volumeId(): string;
        get volumeSize(): number;
        get volumeType(): string;
    }
    class RootBlockDevicePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RootBlockDevicePropertyOutputReference;
    }
    interface FilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/instance#name DataTfInstance#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/instance#values DataTfInstance#values}
        */
        readonly values: string[];
    }
    class FilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FilterProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class FilterPropertyList extends cdktn.ComplexList {
        internalValue?: FilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/instance#read DataTfInstance#read}
        */
        readonly read?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _read?;
        get read(): string;
        set read(value: string);
        resetRead(): void;
        get readInput(): string | undefined;
    }
}
