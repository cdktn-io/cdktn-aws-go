import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfSpotInstanceRequestConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#ami TfSpotInstanceRequest#ami}
    */
    readonly ami?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#associate_public_ip_address TfSpotInstanceRequest#associate_public_ip_address}
    */
    readonly associatePublicIpAddress?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#availability_zone TfSpotInstanceRequest#availability_zone}
    */
    readonly availabilityZone?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#disable_api_stop TfSpotInstanceRequest#disable_api_stop}
    */
    readonly disableApiStop?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#disable_api_termination TfSpotInstanceRequest#disable_api_termination}
    */
    readonly disableApiTermination?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#ebs_optimized TfSpotInstanceRequest#ebs_optimized}
    */
    readonly ebsOptimized?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#enable_primary_ipv6 TfSpotInstanceRequest#enable_primary_ipv6}
    */
    readonly enablePrimaryIpv6?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#force_destroy TfSpotInstanceRequest#force_destroy}
    */
    readonly forceDestroy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#get_password_data TfSpotInstanceRequest#get_password_data}
    */
    readonly fetchPasswordData?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#hibernation TfSpotInstanceRequest#hibernation}
    */
    readonly hibernation?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#host_id TfSpotInstanceRequest#host_id}
    */
    readonly hostId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#host_resource_group_arn TfSpotInstanceRequest#host_resource_group_arn}
    */
    readonly hostResourceGroupArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#iam_instance_profile TfSpotInstanceRequest#iam_instance_profile}
    */
    readonly iamInstanceProfile?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#id TfSpotInstanceRequest#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#instance_initiated_shutdown_behavior TfSpotInstanceRequest#instance_initiated_shutdown_behavior}
    */
    readonly instanceInitiatedShutdownBehavior?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#instance_interruption_behavior TfSpotInstanceRequest#instance_interruption_behavior}
    */
    readonly instanceInterruptionBehavior?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#instance_type TfSpotInstanceRequest#instance_type}
    */
    readonly instanceType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#ipv6_address_count TfSpotInstanceRequest#ipv6_address_count}
    */
    readonly ipv6AddressCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#ipv6_addresses TfSpotInstanceRequest#ipv6_addresses}
    */
    readonly ipv6Addresses?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#key_name TfSpotInstanceRequest#key_name}
    */
    readonly keyName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#launch_group TfSpotInstanceRequest#launch_group}
    */
    readonly launchGroup?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#monitoring TfSpotInstanceRequest#monitoring}
    */
    readonly monitoring?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#placement_group TfSpotInstanceRequest#placement_group}
    */
    readonly placementGroup?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#placement_group_id TfSpotInstanceRequest#placement_group_id}
    */
    readonly placementGroupId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#placement_partition_number TfSpotInstanceRequest#placement_partition_number}
    */
    readonly placementPartitionNumber?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#private_ip TfSpotInstanceRequest#private_ip}
    */
    readonly privateIp?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#region TfSpotInstanceRequest#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#secondary_private_ips TfSpotInstanceRequest#secondary_private_ips}
    */
    readonly secondaryPrivateIps?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#security_groups TfSpotInstanceRequest#security_groups}
    */
    readonly securityGroups?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#source_dest_check TfSpotInstanceRequest#source_dest_check}
    */
    readonly sourceDestCheck?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#spot_price TfSpotInstanceRequest#spot_price}
    */
    readonly spotPrice?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#spot_type TfSpotInstanceRequest#spot_type}
    */
    readonly spotType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#subnet_id TfSpotInstanceRequest#subnet_id}
    */
    readonly subnetId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#tags TfSpotInstanceRequest#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#tags_all TfSpotInstanceRequest#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#tenancy TfSpotInstanceRequest#tenancy}
    */
    readonly tenancy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#user_data TfSpotInstanceRequest#user_data}
    */
    readonly userData?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#user_data_base64 TfSpotInstanceRequest#user_data_base64}
    */
    readonly userDataBase64?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#user_data_replace_on_change TfSpotInstanceRequest#user_data_replace_on_change}
    */
    readonly userDataReplaceOnChange?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#valid_from TfSpotInstanceRequest#valid_from}
    */
    readonly validFrom?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#valid_until TfSpotInstanceRequest#valid_until}
    */
    readonly validUntil?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#volume_tags TfSpotInstanceRequest#volume_tags}
    */
    readonly volumeTags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#vpc_security_group_ids TfSpotInstanceRequest#vpc_security_group_ids}
    */
    readonly vpcSecurityGroupIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#wait_for_fulfillment TfSpotInstanceRequest#wait_for_fulfillment}
    */
    readonly waitForFulfillment?: boolean | cdktn.IResolvable;
    /**
    * capacity_reservation_specification block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#capacity_reservation_specification TfSpotInstanceRequest#capacity_reservation_specification}
    */
    readonly capacityReservationSpecification?: TfSpotInstanceRequest.CapacityReservationSpecificationProperty;
    /**
    * cpu_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#cpu_options TfSpotInstanceRequest#cpu_options}
    */
    readonly cpuOptions?: TfSpotInstanceRequest.CpuOptionsProperty;
    /**
    * credit_specification block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#credit_specification TfSpotInstanceRequest#credit_specification}
    */
    readonly creditSpecification?: TfSpotInstanceRequest.CreditSpecificationProperty;
    /**
    * ebs_block_device block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#ebs_block_device TfSpotInstanceRequest#ebs_block_device}
    */
    readonly ebsBlockDevice?: TfSpotInstanceRequest.EbsBlockDeviceProperty[] | cdktn.IResolvable;
    /**
    * enclave_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#enclave_options TfSpotInstanceRequest#enclave_options}
    */
    readonly enclaveOptions?: TfSpotInstanceRequest.EnclaveOptionsProperty;
    /**
    * ephemeral_block_device block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#ephemeral_block_device TfSpotInstanceRequest#ephemeral_block_device}
    */
    readonly ephemeralBlockDevice?: TfSpotInstanceRequest.EphemeralBlockDeviceProperty[] | cdktn.IResolvable;
    /**
    * launch_template block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#launch_template TfSpotInstanceRequest#launch_template}
    */
    readonly launchTemplate?: TfSpotInstanceRequest.LaunchTemplateProperty;
    /**
    * maintenance_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#maintenance_options TfSpotInstanceRequest#maintenance_options}
    */
    readonly maintenanceOptions?: TfSpotInstanceRequest.MaintenanceOptionsProperty;
    /**
    * metadata_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#metadata_options TfSpotInstanceRequest#metadata_options}
    */
    readonly metadataOptions?: TfSpotInstanceRequest.MetadataOptionsProperty;
    /**
    * network_interface block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#network_interface TfSpotInstanceRequest#network_interface}
    */
    readonly networkInterface?: TfSpotInstanceRequest.NetworkInterfaceProperty[] | cdktn.IResolvable;
    /**
    * private_dns_name_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#private_dns_name_options TfSpotInstanceRequest#private_dns_name_options}
    */
    readonly privateDnsNameOptions?: TfSpotInstanceRequest.PrivateDnsNameOptionsProperty;
    /**
    * root_block_device block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#root_block_device TfSpotInstanceRequest#root_block_device}
    */
    readonly rootBlockDevice?: TfSpotInstanceRequest.RootBlockDeviceProperty;
    /**
    * secondary_network_interface block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#secondary_network_interface TfSpotInstanceRequest#secondary_network_interface}
    */
    readonly secondaryNetworkInterface?: TfSpotInstanceRequest.SecondaryNetworkInterfaceProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#timeouts TfSpotInstanceRequest#timeouts}
    */
    readonly timeouts?: TfSpotInstanceRequest.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request aws_spot_instance_request}
*/
export declare class TfSpotInstanceRequest extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_spot_instance_request";
    /**
    * Generates CDKTN code for importing a TfSpotInstanceRequest resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfSpotInstanceRequest to import
    * @param importFromId The id of the existing TfSpotInstanceRequest that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfSpotInstanceRequest to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request aws_spot_instance_request} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfSpotInstanceRequestConfig = {}
    */
    constructor(scope: Construct, id: string, config?: TfSpotInstanceRequestConfig);
    private _ami?;
    get ami(): string;
    set ami(value: string);
    resetAmi(): void;
    get amiInput(): string | undefined;
    get arn(): string;
    private _associatePublicIpAddress?;
    get associatePublicIpAddress(): boolean | cdktn.IResolvable;
    set associatePublicIpAddress(value: boolean | cdktn.IResolvable);
    resetAssociatePublicIpAddress(): void;
    get associatePublicIpAddressInput(): boolean | cdktn.IResolvable | undefined;
    private _availabilityZone?;
    get availabilityZone(): string;
    set availabilityZone(value: string);
    resetAvailabilityZone(): void;
    get availabilityZoneInput(): string | undefined;
    private _disableApiStop?;
    get disableApiStop(): boolean | cdktn.IResolvable;
    set disableApiStop(value: boolean | cdktn.IResolvable);
    resetDisableApiStop(): void;
    get disableApiStopInput(): boolean | cdktn.IResolvable | undefined;
    private _disableApiTermination?;
    get disableApiTermination(): boolean | cdktn.IResolvable;
    set disableApiTermination(value: boolean | cdktn.IResolvable);
    resetDisableApiTermination(): void;
    get disableApiTerminationInput(): boolean | cdktn.IResolvable | undefined;
    private _ebsOptimized?;
    get ebsOptimized(): boolean | cdktn.IResolvable;
    set ebsOptimized(value: boolean | cdktn.IResolvable);
    resetEbsOptimized(): void;
    get ebsOptimizedInput(): boolean | cdktn.IResolvable | undefined;
    private _enablePrimaryIpv6?;
    get enablePrimaryIpv6(): boolean | cdktn.IResolvable;
    set enablePrimaryIpv6(value: boolean | cdktn.IResolvable);
    resetEnablePrimaryIpv6(): void;
    get enablePrimaryIpv6Input(): boolean | cdktn.IResolvable | undefined;
    private _forceDestroy?;
    get forceDestroy(): boolean | cdktn.IResolvable;
    set forceDestroy(value: boolean | cdktn.IResolvable);
    resetForceDestroy(): void;
    get forceDestroyInput(): boolean | cdktn.IResolvable | undefined;
    private _getPasswordData?;
    get fetchPasswordData(): boolean | cdktn.IResolvable;
    set fetchPasswordData(value: boolean | cdktn.IResolvable);
    resetFetchPasswordData(): void;
    get fetchPasswordDataInput(): boolean | cdktn.IResolvable | undefined;
    private _hibernation?;
    get hibernation(): boolean | cdktn.IResolvable;
    set hibernation(value: boolean | cdktn.IResolvable);
    resetHibernation(): void;
    get hibernationInput(): boolean | cdktn.IResolvable | undefined;
    private _hostId?;
    get hostId(): string;
    set hostId(value: string);
    resetHostId(): void;
    get hostIdInput(): string | undefined;
    private _hostResourceGroupArn?;
    get hostResourceGroupArn(): string;
    set hostResourceGroupArn(value: string);
    resetHostResourceGroupArn(): void;
    get hostResourceGroupArnInput(): string | undefined;
    private _iamInstanceProfile?;
    get iamInstanceProfile(): string;
    set iamInstanceProfile(value: string);
    resetIamInstanceProfile(): void;
    get iamInstanceProfileInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceInitiatedShutdownBehavior?;
    get instanceInitiatedShutdownBehavior(): string;
    set instanceInitiatedShutdownBehavior(value: string);
    resetInstanceInitiatedShutdownBehavior(): void;
    get instanceInitiatedShutdownBehaviorInput(): string | undefined;
    private _instanceInterruptionBehavior?;
    get instanceInterruptionBehavior(): string;
    set instanceInterruptionBehavior(value: string);
    resetInstanceInterruptionBehavior(): void;
    get instanceInterruptionBehaviorInput(): string | undefined;
    get instanceState(): string;
    private _instanceType?;
    get instanceType(): string;
    set instanceType(value: string);
    resetInstanceType(): void;
    get instanceTypeInput(): string | undefined;
    private _ipv6AddressCount?;
    get ipv6AddressCount(): number;
    set ipv6AddressCount(value: number);
    resetIpv6AddressCount(): void;
    get ipv6AddressCountInput(): number | undefined;
    private _ipv6Addresses?;
    get ipv6Addresses(): string[];
    set ipv6Addresses(value: string[]);
    resetIpv6Addresses(): void;
    get ipv6AddressesInput(): string[] | undefined;
    private _keyName?;
    get keyName(): string;
    set keyName(value: string);
    resetKeyName(): void;
    get keyNameInput(): string | undefined;
    private _launchGroup?;
    get launchGroup(): string;
    set launchGroup(value: string);
    resetLaunchGroup(): void;
    get launchGroupInput(): string | undefined;
    private _monitoring?;
    get monitoring(): boolean | cdktn.IResolvable;
    set monitoring(value: boolean | cdktn.IResolvable);
    resetMonitoring(): void;
    get monitoringInput(): boolean | cdktn.IResolvable | undefined;
    get outpostArn(): string;
    get passwordData(): string;
    private _placementGroup?;
    get placementGroup(): string;
    set placementGroup(value: string);
    resetPlacementGroup(): void;
    get placementGroupInput(): string | undefined;
    private _placementGroupId?;
    get placementGroupId(): string;
    set placementGroupId(value: string);
    resetPlacementGroupId(): void;
    get placementGroupIdInput(): string | undefined;
    private _placementPartitionNumber?;
    get placementPartitionNumber(): number;
    set placementPartitionNumber(value: number);
    resetPlacementPartitionNumber(): void;
    get placementPartitionNumberInput(): number | undefined;
    private _primaryNetworkInterface;
    get primaryNetworkInterface(): TfSpotInstanceRequest.PrimaryNetworkInterfacePropertyList;
    get primaryNetworkInterfaceId(): string;
    get privateDns(): string;
    private _privateIp?;
    get privateIp(): string;
    set privateIp(value: string);
    resetPrivateIp(): void;
    get privateIpInput(): string | undefined;
    get publicDns(): string;
    get publicIp(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _secondaryPrivateIps?;
    get secondaryPrivateIps(): string[];
    set secondaryPrivateIps(value: string[]);
    resetSecondaryPrivateIps(): void;
    get secondaryPrivateIpsInput(): string[] | undefined;
    private _securityGroups?;
    get securityGroups(): string[];
    set securityGroups(value: string[]);
    resetSecurityGroups(): void;
    get securityGroupsInput(): string[] | undefined;
    private _sourceDestCheck?;
    get sourceDestCheck(): boolean | cdktn.IResolvable;
    set sourceDestCheck(value: boolean | cdktn.IResolvable);
    resetSourceDestCheck(): void;
    get sourceDestCheckInput(): boolean | cdktn.IResolvable | undefined;
    get spotBidStatus(): string;
    get spotInstanceId(): string;
    private _spotPrice?;
    get spotPrice(): string;
    set spotPrice(value: string);
    resetSpotPrice(): void;
    get spotPriceInput(): string | undefined;
    get spotRequestState(): string;
    private _spotType?;
    get spotType(): string;
    set spotType(value: string);
    resetSpotType(): void;
    get spotTypeInput(): string | undefined;
    private _subnetId?;
    get subnetId(): string;
    set subnetId(value: string);
    resetSubnetId(): void;
    get subnetIdInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _tenancy?;
    get tenancy(): string;
    set tenancy(value: string);
    resetTenancy(): void;
    get tenancyInput(): string | undefined;
    private _userData?;
    get userData(): string;
    set userData(value: string);
    resetUserData(): void;
    get userDataInput(): string | undefined;
    private _userDataBase64?;
    get userDataBase64(): string;
    set userDataBase64(value: string);
    resetUserDataBase64(): void;
    get userDataBase64Input(): string | undefined;
    private _userDataReplaceOnChange?;
    get userDataReplaceOnChange(): boolean | cdktn.IResolvable;
    set userDataReplaceOnChange(value: boolean | cdktn.IResolvable);
    resetUserDataReplaceOnChange(): void;
    get userDataReplaceOnChangeInput(): boolean | cdktn.IResolvable | undefined;
    private _validFrom?;
    get validFrom(): string;
    set validFrom(value: string);
    resetValidFrom(): void;
    get validFromInput(): string | undefined;
    private _validUntil?;
    get validUntil(): string;
    set validUntil(value: string);
    resetValidUntil(): void;
    get validUntilInput(): string | undefined;
    private _volumeTags?;
    get volumeTags(): {
        [key: string]: string;
    };
    set volumeTags(value: {
        [key: string]: string;
    });
    resetVolumeTags(): void;
    get volumeTagsInput(): {
        [key: string]: string;
    } | undefined;
    private _vpcSecurityGroupIds?;
    get vpcSecurityGroupIds(): string[];
    set vpcSecurityGroupIds(value: string[]);
    resetVpcSecurityGroupIds(): void;
    get vpcSecurityGroupIdsInput(): string[] | undefined;
    private _waitForFulfillment?;
    get waitForFulfillment(): boolean | cdktn.IResolvable;
    set waitForFulfillment(value: boolean | cdktn.IResolvable);
    resetWaitForFulfillment(): void;
    get waitForFulfillmentInput(): boolean | cdktn.IResolvable | undefined;
    private _capacityReservationSpecification;
    get capacityReservationSpecification(): TfSpotInstanceRequest.CapacityReservationSpecificationPropertyOutputReference;
    putCapacityReservationSpecification(value: TfSpotInstanceRequest.CapacityReservationSpecificationProperty): void;
    resetCapacityReservationSpecification(): void;
    get capacityReservationSpecificationInput(): TfSpotInstanceRequest.CapacityReservationSpecificationProperty | undefined;
    private _cpuOptions;
    get cpuOptions(): TfSpotInstanceRequest.CpuOptionsPropertyOutputReference;
    putCpuOptions(value: TfSpotInstanceRequest.CpuOptionsProperty): void;
    resetCpuOptions(): void;
    get cpuOptionsInput(): TfSpotInstanceRequest.CpuOptionsProperty | undefined;
    private _creditSpecification;
    get creditSpecification(): TfSpotInstanceRequest.CreditSpecificationPropertyOutputReference;
    putCreditSpecification(value: TfSpotInstanceRequest.CreditSpecificationProperty): void;
    resetCreditSpecification(): void;
    get creditSpecificationInput(): TfSpotInstanceRequest.CreditSpecificationProperty | undefined;
    private _ebsBlockDevice;
    get ebsBlockDevice(): TfSpotInstanceRequest.EbsBlockDevicePropertyList;
    putEbsBlockDevice(value: TfSpotInstanceRequest.EbsBlockDeviceProperty[] | cdktn.IResolvable): void;
    resetEbsBlockDevice(): void;
    get ebsBlockDeviceInput(): cdktn.IResolvable | TfSpotInstanceRequest.EbsBlockDeviceProperty[] | undefined;
    private _enclaveOptions;
    get enclaveOptions(): TfSpotInstanceRequest.EnclaveOptionsPropertyOutputReference;
    putEnclaveOptions(value: TfSpotInstanceRequest.EnclaveOptionsProperty): void;
    resetEnclaveOptions(): void;
    get enclaveOptionsInput(): TfSpotInstanceRequest.EnclaveOptionsProperty | undefined;
    private _ephemeralBlockDevice;
    get ephemeralBlockDevice(): TfSpotInstanceRequest.EphemeralBlockDevicePropertyList;
    putEphemeralBlockDevice(value: TfSpotInstanceRequest.EphemeralBlockDeviceProperty[] | cdktn.IResolvable): void;
    resetEphemeralBlockDevice(): void;
    get ephemeralBlockDeviceInput(): cdktn.IResolvable | TfSpotInstanceRequest.EphemeralBlockDeviceProperty[] | undefined;
    private _launchTemplate;
    get launchTemplate(): TfSpotInstanceRequest.LaunchTemplatePropertyOutputReference;
    putLaunchTemplate(value: TfSpotInstanceRequest.LaunchTemplateProperty): void;
    resetLaunchTemplate(): void;
    get launchTemplateInput(): TfSpotInstanceRequest.LaunchTemplateProperty | undefined;
    private _maintenanceOptions;
    get maintenanceOptions(): TfSpotInstanceRequest.MaintenanceOptionsPropertyOutputReference;
    putMaintenanceOptions(value: TfSpotInstanceRequest.MaintenanceOptionsProperty): void;
    resetMaintenanceOptions(): void;
    get maintenanceOptionsInput(): TfSpotInstanceRequest.MaintenanceOptionsProperty | undefined;
    private _metadataOptions;
    get metadataOptions(): TfSpotInstanceRequest.MetadataOptionsPropertyOutputReference;
    putMetadataOptions(value: TfSpotInstanceRequest.MetadataOptionsProperty): void;
    resetMetadataOptions(): void;
    get metadataOptionsInput(): TfSpotInstanceRequest.MetadataOptionsProperty | undefined;
    private _networkInterface;
    get networkInterface(): TfSpotInstanceRequest.NetworkInterfacePropertyList;
    putNetworkInterface(value: TfSpotInstanceRequest.NetworkInterfaceProperty[] | cdktn.IResolvable): void;
    resetNetworkInterface(): void;
    get networkInterfaceInput(): cdktn.IResolvable | TfSpotInstanceRequest.NetworkInterfaceProperty[] | undefined;
    private _privateDnsNameOptions;
    get privateDnsNameOptions(): TfSpotInstanceRequest.PrivateDnsNameOptionsPropertyOutputReference;
    putPrivateDnsNameOptions(value: TfSpotInstanceRequest.PrivateDnsNameOptionsProperty): void;
    resetPrivateDnsNameOptions(): void;
    get privateDnsNameOptionsInput(): TfSpotInstanceRequest.PrivateDnsNameOptionsProperty | undefined;
    private _rootBlockDevice;
    get rootBlockDevice(): TfSpotInstanceRequest.RootBlockDevicePropertyOutputReference;
    putRootBlockDevice(value: TfSpotInstanceRequest.RootBlockDeviceProperty): void;
    resetRootBlockDevice(): void;
    get rootBlockDeviceInput(): TfSpotInstanceRequest.RootBlockDeviceProperty | undefined;
    private _secondaryNetworkInterface;
    get secondaryNetworkInterface(): TfSpotInstanceRequest.SecondaryNetworkInterfacePropertyList;
    putSecondaryNetworkInterface(value: TfSpotInstanceRequest.SecondaryNetworkInterfaceProperty[] | cdktn.IResolvable): void;
    resetSecondaryNetworkInterface(): void;
    get secondaryNetworkInterfaceInput(): cdktn.IResolvable | TfSpotInstanceRequest.SecondaryNetworkInterfaceProperty[] | undefined;
    private _timeouts;
    get timeouts(): TfSpotInstanceRequest.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfSpotInstanceRequest.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfSpotInstanceRequest.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfSpotInstanceRequestPrimaryNetworkInterfacePropertyToTerraform(struct?: TfSpotInstanceRequest.PrimaryNetworkInterfaceProperty): any;
export declare function tfSpotInstanceRequestPrimaryNetworkInterfacePropertyToHclTerraform(struct?: TfSpotInstanceRequest.PrimaryNetworkInterfaceProperty): any;
export declare function tfSpotInstanceRequestCapacityReservationTargetPropertyToTerraform(struct?: TfSpotInstanceRequest.CapacityReservationTargetPropertyOutputReference | TfSpotInstanceRequest.CapacityReservationTargetProperty): any;
export declare function tfSpotInstanceRequestCapacityReservationTargetPropertyToHclTerraform(struct?: TfSpotInstanceRequest.CapacityReservationTargetPropertyOutputReference | TfSpotInstanceRequest.CapacityReservationTargetProperty): any;
export declare function tfSpotInstanceRequestCapacityReservationSpecificationPropertyToTerraform(struct?: TfSpotInstanceRequest.CapacityReservationSpecificationPropertyOutputReference | TfSpotInstanceRequest.CapacityReservationSpecificationProperty): any;
export declare function tfSpotInstanceRequestCapacityReservationSpecificationPropertyToHclTerraform(struct?: TfSpotInstanceRequest.CapacityReservationSpecificationPropertyOutputReference | TfSpotInstanceRequest.CapacityReservationSpecificationProperty): any;
export declare function tfSpotInstanceRequestCpuOptionsPropertyToTerraform(struct?: TfSpotInstanceRequest.CpuOptionsPropertyOutputReference | TfSpotInstanceRequest.CpuOptionsProperty): any;
export declare function tfSpotInstanceRequestCpuOptionsPropertyToHclTerraform(struct?: TfSpotInstanceRequest.CpuOptionsPropertyOutputReference | TfSpotInstanceRequest.CpuOptionsProperty): any;
export declare function tfSpotInstanceRequestCreditSpecificationPropertyToTerraform(struct?: TfSpotInstanceRequest.CreditSpecificationPropertyOutputReference | TfSpotInstanceRequest.CreditSpecificationProperty): any;
export declare function tfSpotInstanceRequestCreditSpecificationPropertyToHclTerraform(struct?: TfSpotInstanceRequest.CreditSpecificationPropertyOutputReference | TfSpotInstanceRequest.CreditSpecificationProperty): any;
export declare function tfSpotInstanceRequestEbsBlockDevicePropertyToTerraform(struct?: TfSpotInstanceRequest.EbsBlockDeviceProperty | cdktn.IResolvable): any;
export declare function tfSpotInstanceRequestEbsBlockDevicePropertyToHclTerraform(struct?: TfSpotInstanceRequest.EbsBlockDeviceProperty | cdktn.IResolvable): any;
export declare function tfSpotInstanceRequestEnclaveOptionsPropertyToTerraform(struct?: TfSpotInstanceRequest.EnclaveOptionsPropertyOutputReference | TfSpotInstanceRequest.EnclaveOptionsProperty): any;
export declare function tfSpotInstanceRequestEnclaveOptionsPropertyToHclTerraform(struct?: TfSpotInstanceRequest.EnclaveOptionsPropertyOutputReference | TfSpotInstanceRequest.EnclaveOptionsProperty): any;
export declare function tfSpotInstanceRequestEphemeralBlockDevicePropertyToTerraform(struct?: TfSpotInstanceRequest.EphemeralBlockDeviceProperty | cdktn.IResolvable): any;
export declare function tfSpotInstanceRequestEphemeralBlockDevicePropertyToHclTerraform(struct?: TfSpotInstanceRequest.EphemeralBlockDeviceProperty | cdktn.IResolvable): any;
export declare function tfSpotInstanceRequestLaunchTemplatePropertyToTerraform(struct?: TfSpotInstanceRequest.LaunchTemplatePropertyOutputReference | TfSpotInstanceRequest.LaunchTemplateProperty): any;
export declare function tfSpotInstanceRequestLaunchTemplatePropertyToHclTerraform(struct?: TfSpotInstanceRequest.LaunchTemplatePropertyOutputReference | TfSpotInstanceRequest.LaunchTemplateProperty): any;
export declare function tfSpotInstanceRequestMaintenanceOptionsPropertyToTerraform(struct?: TfSpotInstanceRequest.MaintenanceOptionsPropertyOutputReference | TfSpotInstanceRequest.MaintenanceOptionsProperty): any;
export declare function tfSpotInstanceRequestMaintenanceOptionsPropertyToHclTerraform(struct?: TfSpotInstanceRequest.MaintenanceOptionsPropertyOutputReference | TfSpotInstanceRequest.MaintenanceOptionsProperty): any;
export declare function tfSpotInstanceRequestMetadataOptionsPropertyToTerraform(struct?: TfSpotInstanceRequest.MetadataOptionsPropertyOutputReference | TfSpotInstanceRequest.MetadataOptionsProperty): any;
export declare function tfSpotInstanceRequestMetadataOptionsPropertyToHclTerraform(struct?: TfSpotInstanceRequest.MetadataOptionsPropertyOutputReference | TfSpotInstanceRequest.MetadataOptionsProperty): any;
export declare function tfSpotInstanceRequestNetworkInterfacePropertyToTerraform(struct?: TfSpotInstanceRequest.NetworkInterfaceProperty | cdktn.IResolvable): any;
export declare function tfSpotInstanceRequestNetworkInterfacePropertyToHclTerraform(struct?: TfSpotInstanceRequest.NetworkInterfaceProperty | cdktn.IResolvable): any;
export declare function tfSpotInstanceRequestPrivateDnsNameOptionsPropertyToTerraform(struct?: TfSpotInstanceRequest.PrivateDnsNameOptionsPropertyOutputReference | TfSpotInstanceRequest.PrivateDnsNameOptionsProperty): any;
export declare function tfSpotInstanceRequestPrivateDnsNameOptionsPropertyToHclTerraform(struct?: TfSpotInstanceRequest.PrivateDnsNameOptionsPropertyOutputReference | TfSpotInstanceRequest.PrivateDnsNameOptionsProperty): any;
export declare function tfSpotInstanceRequestRootBlockDevicePropertyToTerraform(struct?: TfSpotInstanceRequest.RootBlockDevicePropertyOutputReference | TfSpotInstanceRequest.RootBlockDeviceProperty): any;
export declare function tfSpotInstanceRequestRootBlockDevicePropertyToHclTerraform(struct?: TfSpotInstanceRequest.RootBlockDevicePropertyOutputReference | TfSpotInstanceRequest.RootBlockDeviceProperty): any;
export declare function tfSpotInstanceRequestSecondaryNetworkInterfacePropertyToTerraform(struct?: TfSpotInstanceRequest.SecondaryNetworkInterfaceProperty | cdktn.IResolvable): any;
export declare function tfSpotInstanceRequestSecondaryNetworkInterfacePropertyToHclTerraform(struct?: TfSpotInstanceRequest.SecondaryNetworkInterfaceProperty | cdktn.IResolvable): any;
export declare function tfSpotInstanceRequestTimeoutsPropertyToTerraform(struct?: TfSpotInstanceRequest.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfSpotInstanceRequestTimeoutsPropertyToHclTerraform(struct?: TfSpotInstanceRequest.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfSpotInstanceRequest {
    interface PrimaryNetworkInterfaceProperty {
    }
    class PrimaryNetworkInterfacePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PrimaryNetworkInterfaceProperty | undefined;
        set internalValue(value: PrimaryNetworkInterfaceProperty | undefined);
        get deleteOnTermination(): cdktn.IResolvable;
        get networkInterfaceId(): string;
    }
    class PrimaryNetworkInterfacePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PrimaryNetworkInterfacePropertyOutputReference;
    }
    interface CapacityReservationTargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#capacity_reservation_id TfSpotInstanceRequest#capacity_reservation_id}
        */
        readonly capacityReservationId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#capacity_reservation_resource_group_arn TfSpotInstanceRequest#capacity_reservation_resource_group_arn}
        */
        readonly capacityReservationResourceGroupArn?: string;
    }
    class CapacityReservationTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CapacityReservationTargetProperty | undefined;
        set internalValue(value: CapacityReservationTargetProperty | undefined);
        private _capacityReservationId?;
        get capacityReservationId(): string;
        set capacityReservationId(value: string);
        resetCapacityReservationId(): void;
        get capacityReservationIdInput(): string | undefined;
        private _capacityReservationResourceGroupArn?;
        get capacityReservationResourceGroupArn(): string;
        set capacityReservationResourceGroupArn(value: string);
        resetCapacityReservationResourceGroupArn(): void;
        get capacityReservationResourceGroupArnInput(): string | undefined;
    }
    interface CapacityReservationSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#capacity_reservation_preference TfSpotInstanceRequest#capacity_reservation_preference}
        */
        readonly capacityReservationPreference?: string;
        /**
        * capacity_reservation_target block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#capacity_reservation_target TfSpotInstanceRequest#capacity_reservation_target}
        */
        readonly capacityReservationTarget?: CapacityReservationTargetProperty;
    }
    class CapacityReservationSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CapacityReservationSpecificationProperty | undefined;
        set internalValue(value: CapacityReservationSpecificationProperty | undefined);
        private _capacityReservationPreference?;
        get capacityReservationPreference(): string;
        set capacityReservationPreference(value: string);
        resetCapacityReservationPreference(): void;
        get capacityReservationPreferenceInput(): string | undefined;
        private _capacityReservationTarget;
        get capacityReservationTarget(): CapacityReservationTargetPropertyOutputReference;
        putCapacityReservationTarget(value: CapacityReservationTargetProperty): void;
        resetCapacityReservationTarget(): void;
        get capacityReservationTargetInput(): CapacityReservationTargetProperty | undefined;
    }
    interface CpuOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#amd_sev_snp TfSpotInstanceRequest#amd_sev_snp}
        */
        readonly amdSevSnp?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#core_count TfSpotInstanceRequest#core_count}
        */
        readonly coreCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#nested_virtualization TfSpotInstanceRequest#nested_virtualization}
        */
        readonly nestedVirtualization?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#threads_per_core TfSpotInstanceRequest#threads_per_core}
        */
        readonly threadsPerCore?: number;
    }
    class CpuOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CpuOptionsProperty | undefined;
        set internalValue(value: CpuOptionsProperty | undefined);
        private _amdSevSnp?;
        get amdSevSnp(): string;
        set amdSevSnp(value: string);
        resetAmdSevSnp(): void;
        get amdSevSnpInput(): string | undefined;
        private _coreCount?;
        get coreCount(): number;
        set coreCount(value: number);
        resetCoreCount(): void;
        get coreCountInput(): number | undefined;
        private _nestedVirtualization?;
        get nestedVirtualization(): string;
        set nestedVirtualization(value: string);
        resetNestedVirtualization(): void;
        get nestedVirtualizationInput(): string | undefined;
        private _threadsPerCore?;
        get threadsPerCore(): number;
        set threadsPerCore(value: number);
        resetThreadsPerCore(): void;
        get threadsPerCoreInput(): number | undefined;
    }
    interface CreditSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#cpu_credits TfSpotInstanceRequest#cpu_credits}
        */
        readonly cpuCredits?: string;
    }
    class CreditSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CreditSpecificationProperty | undefined;
        set internalValue(value: CreditSpecificationProperty | undefined);
        private _cpuCredits?;
        get cpuCredits(): string;
        set cpuCredits(value: string);
        resetCpuCredits(): void;
        get cpuCreditsInput(): string | undefined;
    }
    interface EbsBlockDeviceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#delete_on_termination TfSpotInstanceRequest#delete_on_termination}
        */
        readonly deleteOnTermination?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#device_name TfSpotInstanceRequest#device_name}
        */
        readonly deviceName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#encrypted TfSpotInstanceRequest#encrypted}
        */
        readonly encrypted?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#iops TfSpotInstanceRequest#iops}
        */
        readonly iops?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#kms_key_id TfSpotInstanceRequest#kms_key_id}
        */
        readonly kmsKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#snapshot_id TfSpotInstanceRequest#snapshot_id}
        */
        readonly snapshotId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#tags TfSpotInstanceRequest#tags}
        */
        readonly tags?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#tags_all TfSpotInstanceRequest#tags_all}
        */
        readonly tagsAll?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#throughput TfSpotInstanceRequest#throughput}
        */
        readonly throughput?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#volume_size TfSpotInstanceRequest#volume_size}
        */
        readonly volumeSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#volume_type TfSpotInstanceRequest#volume_type}
        */
        readonly volumeType?: string;
    }
    class EbsBlockDevicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EbsBlockDeviceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EbsBlockDeviceProperty | cdktn.IResolvable | undefined);
        private _deleteOnTermination?;
        get deleteOnTermination(): boolean | cdktn.IResolvable;
        set deleteOnTermination(value: boolean | cdktn.IResolvable);
        resetDeleteOnTermination(): void;
        get deleteOnTerminationInput(): boolean | cdktn.IResolvable | undefined;
        private _deviceName?;
        get deviceName(): string;
        set deviceName(value: string);
        get deviceNameInput(): string | undefined;
        private _encrypted?;
        get encrypted(): boolean | cdktn.IResolvable;
        set encrypted(value: boolean | cdktn.IResolvable);
        resetEncrypted(): void;
        get encryptedInput(): boolean | cdktn.IResolvable | undefined;
        private _iops?;
        get iops(): number;
        set iops(value: number);
        resetIops(): void;
        get iopsInput(): number | undefined;
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        resetKmsKeyId(): void;
        get kmsKeyIdInput(): string | undefined;
        private _snapshotId?;
        get snapshotId(): string;
        set snapshotId(value: string);
        resetSnapshotId(): void;
        get snapshotIdInput(): string | undefined;
        private _tags?;
        get tags(): {
            [key: string]: string;
        };
        set tags(value: {
            [key: string]: string;
        });
        resetTags(): void;
        get tagsInput(): {
            [key: string]: string;
        } | undefined;
        private _tagsAll?;
        get tagsAll(): {
            [key: string]: string;
        };
        set tagsAll(value: {
            [key: string]: string;
        });
        resetTagsAll(): void;
        get tagsAllInput(): {
            [key: string]: string;
        } | undefined;
        private _throughput?;
        get throughput(): number;
        set throughput(value: number);
        resetThroughput(): void;
        get throughputInput(): number | undefined;
        get volumeId(): string;
        private _volumeSize?;
        get volumeSize(): number;
        set volumeSize(value: number);
        resetVolumeSize(): void;
        get volumeSizeInput(): number | undefined;
        private _volumeType?;
        get volumeType(): string;
        set volumeType(value: string);
        resetVolumeType(): void;
        get volumeTypeInput(): string | undefined;
    }
    class EbsBlockDevicePropertyList extends cdktn.ComplexList {
        internalValue?: EbsBlockDeviceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EbsBlockDevicePropertyOutputReference;
    }
    interface EnclaveOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#enabled TfSpotInstanceRequest#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
    }
    class EnclaveOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EnclaveOptionsProperty | undefined;
        set internalValue(value: EnclaveOptionsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface EphemeralBlockDeviceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#device_name TfSpotInstanceRequest#device_name}
        */
        readonly deviceName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#no_device TfSpotInstanceRequest#no_device}
        */
        readonly noDevice?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#virtual_name TfSpotInstanceRequest#virtual_name}
        */
        readonly virtualName?: string;
    }
    class EphemeralBlockDevicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EphemeralBlockDeviceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EphemeralBlockDeviceProperty | cdktn.IResolvable | undefined);
        private _deviceName?;
        get deviceName(): string;
        set deviceName(value: string);
        get deviceNameInput(): string | undefined;
        private _noDevice?;
        get noDevice(): boolean | cdktn.IResolvable;
        set noDevice(value: boolean | cdktn.IResolvable);
        resetNoDevice(): void;
        get noDeviceInput(): boolean | cdktn.IResolvable | undefined;
        private _virtualName?;
        get virtualName(): string;
        set virtualName(value: string);
        resetVirtualName(): void;
        get virtualNameInput(): string | undefined;
    }
    class EphemeralBlockDevicePropertyList extends cdktn.ComplexList {
        internalValue?: EphemeralBlockDeviceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EphemeralBlockDevicePropertyOutputReference;
    }
    interface LaunchTemplateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#id TfSpotInstanceRequest#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#name TfSpotInstanceRequest#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#version TfSpotInstanceRequest#version}
        */
        readonly version?: string;
    }
    class LaunchTemplatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LaunchTemplateProperty | undefined;
        set internalValue(value: LaunchTemplateProperty | undefined);
        private _id?;
        get id(): string;
        set id(value: string);
        resetId(): void;
        get idInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _version?;
        get version(): string;
        set version(value: string);
        resetVersion(): void;
        get versionInput(): string | undefined;
    }
    interface MaintenanceOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#auto_recovery TfSpotInstanceRequest#auto_recovery}
        */
        readonly autoRecovery?: string;
    }
    class MaintenanceOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MaintenanceOptionsProperty | undefined;
        set internalValue(value: MaintenanceOptionsProperty | undefined);
        private _autoRecovery?;
        get autoRecovery(): string;
        set autoRecovery(value: string);
        resetAutoRecovery(): void;
        get autoRecoveryInput(): string | undefined;
    }
    interface MetadataOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#http_endpoint TfSpotInstanceRequest#http_endpoint}
        */
        readonly httpEndpoint?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#http_protocol_ipv6 TfSpotInstanceRequest#http_protocol_ipv6}
        */
        readonly httpProtocolIpv6?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#http_put_response_hop_limit TfSpotInstanceRequest#http_put_response_hop_limit}
        */
        readonly httpPutResponseHopLimit?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#http_tokens TfSpotInstanceRequest#http_tokens}
        */
        readonly httpTokens?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#instance_metadata_tags TfSpotInstanceRequest#instance_metadata_tags}
        */
        readonly instanceMetadataTags?: string;
    }
    class MetadataOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MetadataOptionsProperty | undefined;
        set internalValue(value: MetadataOptionsProperty | undefined);
        private _httpEndpoint?;
        get httpEndpoint(): string;
        set httpEndpoint(value: string);
        resetHttpEndpoint(): void;
        get httpEndpointInput(): string | undefined;
        private _httpProtocolIpv6?;
        get httpProtocolIpv6(): string;
        set httpProtocolIpv6(value: string);
        resetHttpProtocolIpv6(): void;
        get httpProtocolIpv6Input(): string | undefined;
        private _httpPutResponseHopLimit?;
        get httpPutResponseHopLimit(): number;
        set httpPutResponseHopLimit(value: number);
        resetHttpPutResponseHopLimit(): void;
        get httpPutResponseHopLimitInput(): number | undefined;
        private _httpTokens?;
        get httpTokens(): string;
        set httpTokens(value: string);
        resetHttpTokens(): void;
        get httpTokensInput(): string | undefined;
        private _instanceMetadataTags?;
        get instanceMetadataTags(): string;
        set instanceMetadataTags(value: string);
        resetInstanceMetadataTags(): void;
        get instanceMetadataTagsInput(): string | undefined;
    }
    interface NetworkInterfaceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#delete_on_termination TfSpotInstanceRequest#delete_on_termination}
        */
        readonly deleteOnTermination?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#device_index TfSpotInstanceRequest#device_index}
        */
        readonly deviceIndex: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#network_interface_id TfSpotInstanceRequest#network_interface_id}
        */
        readonly networkInterfaceId: string;
    }
    class NetworkInterfacePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NetworkInterfaceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NetworkInterfaceProperty | cdktn.IResolvable | undefined);
        private _deleteOnTermination?;
        get deleteOnTermination(): boolean | cdktn.IResolvable;
        set deleteOnTermination(value: boolean | cdktn.IResolvable);
        resetDeleteOnTermination(): void;
        get deleteOnTerminationInput(): boolean | cdktn.IResolvable | undefined;
        private _deviceIndex?;
        get deviceIndex(): number;
        set deviceIndex(value: number);
        get deviceIndexInput(): number | undefined;
        get networkCardIndex(): number;
        private _networkInterfaceId?;
        get networkInterfaceId(): string;
        set networkInterfaceId(value: string);
        get networkInterfaceIdInput(): string | undefined;
    }
    class NetworkInterfacePropertyList extends cdktn.ComplexList {
        internalValue?: NetworkInterfaceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NetworkInterfacePropertyOutputReference;
    }
    interface PrivateDnsNameOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#enable_resource_name_dns_a_record TfSpotInstanceRequest#enable_resource_name_dns_a_record}
        */
        readonly enableResourceNameDnsARecord?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#enable_resource_name_dns_aaaa_record TfSpotInstanceRequest#enable_resource_name_dns_aaaa_record}
        */
        readonly enableResourceNameDnsAaaaRecord?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#hostname_type TfSpotInstanceRequest#hostname_type}
        */
        readonly hostnameType?: string;
    }
    class PrivateDnsNameOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PrivateDnsNameOptionsProperty | undefined;
        set internalValue(value: PrivateDnsNameOptionsProperty | undefined);
        private _enableResourceNameDnsARecord?;
        get enableResourceNameDnsARecord(): boolean | cdktn.IResolvable;
        set enableResourceNameDnsARecord(value: boolean | cdktn.IResolvable);
        resetEnableResourceNameDnsARecord(): void;
        get enableResourceNameDnsARecordInput(): boolean | cdktn.IResolvable | undefined;
        private _enableResourceNameDnsAaaaRecord?;
        get enableResourceNameDnsAaaaRecord(): boolean | cdktn.IResolvable;
        set enableResourceNameDnsAaaaRecord(value: boolean | cdktn.IResolvable);
        resetEnableResourceNameDnsAaaaRecord(): void;
        get enableResourceNameDnsAaaaRecordInput(): boolean | cdktn.IResolvable | undefined;
        private _hostnameType?;
        get hostnameType(): string;
        set hostnameType(value: string);
        resetHostnameType(): void;
        get hostnameTypeInput(): string | undefined;
    }
    interface RootBlockDeviceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#delete_on_termination TfSpotInstanceRequest#delete_on_termination}
        */
        readonly deleteOnTermination?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#encrypted TfSpotInstanceRequest#encrypted}
        */
        readonly encrypted?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#iops TfSpotInstanceRequest#iops}
        */
        readonly iops?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#kms_key_id TfSpotInstanceRequest#kms_key_id}
        */
        readonly kmsKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#tags TfSpotInstanceRequest#tags}
        */
        readonly tags?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#tags_all TfSpotInstanceRequest#tags_all}
        */
        readonly tagsAll?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#throughput TfSpotInstanceRequest#throughput}
        */
        readonly throughput?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#volume_size TfSpotInstanceRequest#volume_size}
        */
        readonly volumeSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#volume_type TfSpotInstanceRequest#volume_type}
        */
        readonly volumeType?: string;
    }
    class RootBlockDevicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RootBlockDeviceProperty | undefined;
        set internalValue(value: RootBlockDeviceProperty | undefined);
        private _deleteOnTermination?;
        get deleteOnTermination(): boolean | cdktn.IResolvable;
        set deleteOnTermination(value: boolean | cdktn.IResolvable);
        resetDeleteOnTermination(): void;
        get deleteOnTerminationInput(): boolean | cdktn.IResolvable | undefined;
        get deviceName(): string;
        private _encrypted?;
        get encrypted(): boolean | cdktn.IResolvable;
        set encrypted(value: boolean | cdktn.IResolvable);
        resetEncrypted(): void;
        get encryptedInput(): boolean | cdktn.IResolvable | undefined;
        private _iops?;
        get iops(): number;
        set iops(value: number);
        resetIops(): void;
        get iopsInput(): number | undefined;
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        resetKmsKeyId(): void;
        get kmsKeyIdInput(): string | undefined;
        private _tags?;
        get tags(): {
            [key: string]: string;
        };
        set tags(value: {
            [key: string]: string;
        });
        resetTags(): void;
        get tagsInput(): {
            [key: string]: string;
        } | undefined;
        private _tagsAll?;
        get tagsAll(): {
            [key: string]: string;
        };
        set tagsAll(value: {
            [key: string]: string;
        });
        resetTagsAll(): void;
        get tagsAllInput(): {
            [key: string]: string;
        } | undefined;
        private _throughput?;
        get throughput(): number;
        set throughput(value: number);
        resetThroughput(): void;
        get throughputInput(): number | undefined;
        get volumeId(): string;
        private _volumeSize?;
        get volumeSize(): number;
        set volumeSize(value: number);
        resetVolumeSize(): void;
        get volumeSizeInput(): number | undefined;
        private _volumeType?;
        get volumeType(): string;
        set volumeType(value: string);
        resetVolumeType(): void;
        get volumeTypeInput(): string | undefined;
    }
    interface SecondaryNetworkInterfaceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#delete_on_termination TfSpotInstanceRequest#delete_on_termination}
        */
        readonly deleteOnTermination?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#device_index TfSpotInstanceRequest#device_index}
        */
        readonly deviceIndex?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#interface_type TfSpotInstanceRequest#interface_type}
        */
        readonly interfaceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#network_card_index TfSpotInstanceRequest#network_card_index}
        */
        readonly networkCardIndex: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#private_ip_address_count TfSpotInstanceRequest#private_ip_address_count}
        */
        readonly privateIpAddressCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#secondary_subnet_id TfSpotInstanceRequest#secondary_subnet_id}
        */
        readonly secondarySubnetId: string;
    }
    class SecondaryNetworkInterfacePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SecondaryNetworkInterfaceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SecondaryNetworkInterfaceProperty | cdktn.IResolvable | undefined);
        private _deleteOnTermination?;
        get deleteOnTermination(): boolean | cdktn.IResolvable;
        set deleteOnTermination(value: boolean | cdktn.IResolvable);
        resetDeleteOnTermination(): void;
        get deleteOnTerminationInput(): boolean | cdktn.IResolvable | undefined;
        private _deviceIndex?;
        get deviceIndex(): number;
        set deviceIndex(value: number);
        resetDeviceIndex(): void;
        get deviceIndexInput(): number | undefined;
        private _interfaceType?;
        get interfaceType(): string;
        set interfaceType(value: string);
        resetInterfaceType(): void;
        get interfaceTypeInput(): string | undefined;
        get macAddress(): string;
        private _networkCardIndex?;
        get networkCardIndex(): number;
        set networkCardIndex(value: number);
        get networkCardIndexInput(): number | undefined;
        private _privateIpAddressCount?;
        get privateIpAddressCount(): number;
        set privateIpAddressCount(value: number);
        resetPrivateIpAddressCount(): void;
        get privateIpAddressCountInput(): number | undefined;
        get privateIpAddresses(): string[];
        get secondaryInterfaceId(): string;
        get secondaryNetworkId(): string;
        private _secondarySubnetId?;
        get secondarySubnetId(): string;
        set secondarySubnetId(value: string);
        get secondarySubnetIdInput(): string | undefined;
        get sourceDestCheck(): cdktn.IResolvable;
        get status(): string;
    }
    class SecondaryNetworkInterfacePropertyList extends cdktn.ComplexList {
        internalValue?: SecondaryNetworkInterfaceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SecondaryNetworkInterfacePropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#create TfSpotInstanceRequest#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#delete TfSpotInstanceRequest#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/spot_instance_request#read TfSpotInstanceRequest#read}
        */
        readonly read?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _read?;
        get read(): string;
        set read(value: string);
        resetRead(): void;
        get readInput(): string | undefined;
    }
}
