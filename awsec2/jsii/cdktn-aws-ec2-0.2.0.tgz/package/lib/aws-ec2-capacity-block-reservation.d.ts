import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfCapacityBlockReservationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_capacity_block_reservation#capacity_block_offering_id TfCapacityBlockReservation#capacity_block_offering_id}
    */
    readonly capacityBlockOfferingId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_capacity_block_reservation#instance_platform TfCapacityBlockReservation#instance_platform}
    */
    readonly instancePlatform: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_capacity_block_reservation#region TfCapacityBlockReservation#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_capacity_block_reservation#tags TfCapacityBlockReservation#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_capacity_block_reservation#timeouts TfCapacityBlockReservation#timeouts}
    */
    readonly timeouts?: TfCapacityBlockReservation.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_capacity_block_reservation aws_ec2_capacity_block_reservation}
*/
export declare class TfCapacityBlockReservation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ec2_capacity_block_reservation";
    /**
    * Generates CDKTN code for importing a TfCapacityBlockReservation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfCapacityBlockReservation to import
    * @param importFromId The id of the existing TfCapacityBlockReservation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_capacity_block_reservation#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfCapacityBlockReservation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_capacity_block_reservation aws_ec2_capacity_block_reservation} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfCapacityBlockReservationConfig
    */
    constructor(scope: Construct, id: string, config: TfCapacityBlockReservationConfig);
    get arn(): string;
    get availabilityZone(): string;
    private _capacityBlockOfferingId?;
    get capacityBlockOfferingId(): string;
    set capacityBlockOfferingId(value: string);
    get capacityBlockOfferingIdInput(): string | undefined;
    get createdDate(): string;
    get ebsOptimized(): cdktn.IResolvable;
    get endDate(): string;
    get endDateType(): string;
    get id(): string;
    get instanceCount(): number;
    private _instancePlatform?;
    get instancePlatform(): string;
    set instancePlatform(value: string);
    get instancePlatformInput(): string | undefined;
    get instanceType(): string;
    get outpostArn(): string;
    get placementGroupArn(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get reservationType(): string;
    get startDate(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    get tenancy(): string;
    private _timeouts;
    get timeouts(): TfCapacityBlockReservation.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfCapacityBlockReservation.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfCapacityBlockReservation.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfCapacityBlockReservationTimeoutsPropertyToTerraform(struct?: TfCapacityBlockReservation.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfCapacityBlockReservationTimeoutsPropertyToHclTerraform(struct?: TfCapacityBlockReservation.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfCapacityBlockReservation {
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_capacity_block_reservation#create TfCapacityBlockReservation#create}
        */
        readonly create?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
    }
}
