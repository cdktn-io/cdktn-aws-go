import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfImageBlockPublicAccessConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_image_block_public_access#id TfImageBlockPublicAccess#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_image_block_public_access#region TfImageBlockPublicAccess#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_image_block_public_access#state TfImageBlockPublicAccess#state}
    */
    readonly state: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_image_block_public_access#timeouts TfImageBlockPublicAccess#timeouts}
    */
    readonly timeouts?: TfImageBlockPublicAccess.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_image_block_public_access aws_ec2_image_block_public_access}
*/
export declare class TfImageBlockPublicAccess extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ec2_image_block_public_access";
    /**
    * Generates CDKTN code for importing a TfImageBlockPublicAccess resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfImageBlockPublicAccess to import
    * @param importFromId The id of the existing TfImageBlockPublicAccess that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_image_block_public_access#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfImageBlockPublicAccess to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_image_block_public_access aws_ec2_image_block_public_access} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfImageBlockPublicAccessConfig
    */
    constructor(scope: Construct, id: string, config: TfImageBlockPublicAccessConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _state?;
    get state(): string;
    set state(value: string);
    get stateInput(): string | undefined;
    private _timeouts;
    get timeouts(): TfImageBlockPublicAccess.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfImageBlockPublicAccess.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfImageBlockPublicAccess.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfImageBlockPublicAccessTimeoutsPropertyToTerraform(struct?: TfImageBlockPublicAccess.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfImageBlockPublicAccessTimeoutsPropertyToHclTerraform(struct?: TfImageBlockPublicAccess.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfImageBlockPublicAccess {
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_image_block_public_access#update TfImageBlockPublicAccess#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
