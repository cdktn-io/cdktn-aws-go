import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfFleetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#context TfFleet#context}
    */
    readonly context?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#excess_capacity_termination_policy TfFleet#excess_capacity_termination_policy}
    */
    readonly excessCapacityTerminationPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#fleet_state TfFleet#fleet_state}
    */
    readonly fleetState?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#fulfilled_capacity TfFleet#fulfilled_capacity}
    */
    readonly fulfilledCapacity?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#fulfilled_on_demand_capacity TfFleet#fulfilled_on_demand_capacity}
    */
    readonly fulfilledOnDemandCapacity?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#id TfFleet#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#region TfFleet#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#replace_unhealthy_instances TfFleet#replace_unhealthy_instances}
    */
    readonly replaceUnhealthyInstances?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#tags TfFleet#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#tags_all TfFleet#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#terminate_instances TfFleet#terminate_instances}
    */
    readonly terminateInstances?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#terminate_instances_with_expiration TfFleet#terminate_instances_with_expiration}
    */
    readonly terminateInstancesWithExpiration?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#type TfFleet#type}
    */
    readonly type?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#valid_from TfFleet#valid_from}
    */
    readonly validFrom?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#valid_until TfFleet#valid_until}
    */
    readonly validUntil?: string;
    /**
    * fleet_instance_set block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#fleet_instance_set TfFleet#fleet_instance_set}
    */
    readonly fleetInstanceSet?: TfFleet.FleetInstanceSetProperty[] | cdktn.IResolvable;
    /**
    * launch_template_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#launch_template_config TfFleet#launch_template_config}
    */
    readonly launchTemplateConfig: TfFleet.LaunchTemplateConfigProperty[] | cdktn.IResolvable;
    /**
    * on_demand_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#on_demand_options TfFleet#on_demand_options}
    */
    readonly onDemandOptions?: TfFleet.OnDemandOptionsProperty;
    /**
    * spot_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#spot_options TfFleet#spot_options}
    */
    readonly spotOptions?: TfFleet.SpotOptionsProperty;
    /**
    * target_capacity_specification block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#target_capacity_specification TfFleet#target_capacity_specification}
    */
    readonly targetCapacitySpecification: TfFleet.TargetCapacitySpecificationProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#timeouts TfFleet#timeouts}
    */
    readonly timeouts?: TfFleet.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet aws_ec2_fleet}
*/
export declare class TfFleet extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ec2_fleet";
    /**
    * Generates CDKTN code for importing a TfFleet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfFleet to import
    * @param importFromId The id of the existing TfFleet that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfFleet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet aws_ec2_fleet} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfFleetConfig
    */
    constructor(scope: Construct, id: string, config: TfFleetConfig);
    get arn(): string;
    private _context?;
    get context(): string;
    set context(value: string);
    resetContext(): void;
    get contextInput(): string | undefined;
    private _excessCapacityTerminationPolicy?;
    get excessCapacityTerminationPolicy(): string;
    set excessCapacityTerminationPolicy(value: string);
    resetExcessCapacityTerminationPolicy(): void;
    get excessCapacityTerminationPolicyInput(): string | undefined;
    private _fleetState?;
    get fleetState(): string;
    set fleetState(value: string);
    resetFleetState(): void;
    get fleetStateInput(): string | undefined;
    private _fulfilledCapacity?;
    get fulfilledCapacity(): number;
    set fulfilledCapacity(value: number);
    resetFulfilledCapacity(): void;
    get fulfilledCapacityInput(): number | undefined;
    private _fulfilledOnDemandCapacity?;
    get fulfilledOnDemandCapacity(): number;
    set fulfilledOnDemandCapacity(value: number);
    resetFulfilledOnDemandCapacity(): void;
    get fulfilledOnDemandCapacityInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _replaceUnhealthyInstances?;
    get replaceUnhealthyInstances(): boolean | cdktn.IResolvable;
    set replaceUnhealthyInstances(value: boolean | cdktn.IResolvable);
    resetReplaceUnhealthyInstances(): void;
    get replaceUnhealthyInstancesInput(): boolean | cdktn.IResolvable | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _terminateInstances?;
    get terminateInstances(): boolean | cdktn.IResolvable;
    set terminateInstances(value: boolean | cdktn.IResolvable);
    resetTerminateInstances(): void;
    get terminateInstancesInput(): boolean | cdktn.IResolvable | undefined;
    private _terminateInstancesWithExpiration?;
    get terminateInstancesWithExpiration(): boolean | cdktn.IResolvable;
    set terminateInstancesWithExpiration(value: boolean | cdktn.IResolvable);
    resetTerminateInstancesWithExpiration(): void;
    get terminateInstancesWithExpirationInput(): boolean | cdktn.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _validFrom?;
    get validFrom(): string;
    set validFrom(value: string);
    resetValidFrom(): void;
    get validFromInput(): string | undefined;
    private _validUntil?;
    get validUntil(): string;
    set validUntil(value: string);
    resetValidUntil(): void;
    get validUntilInput(): string | undefined;
    private _fleetInstanceSet;
    get fleetInstanceSet(): TfFleet.FleetInstanceSetPropertyList;
    putFleetInstanceSet(value: TfFleet.FleetInstanceSetProperty[] | cdktn.IResolvable): void;
    resetFleetInstanceSet(): void;
    get fleetInstanceSetInput(): cdktn.IResolvable | TfFleet.FleetInstanceSetProperty[] | undefined;
    private _launchTemplateConfig;
    get launchTemplateConfig(): TfFleet.LaunchTemplateConfigPropertyList;
    putLaunchTemplateConfig(value: TfFleet.LaunchTemplateConfigProperty[] | cdktn.IResolvable): void;
    get launchTemplateConfigInput(): cdktn.IResolvable | TfFleet.LaunchTemplateConfigProperty[] | undefined;
    private _onDemandOptions;
    get onDemandOptions(): TfFleet.OnDemandOptionsPropertyOutputReference;
    putOnDemandOptions(value: TfFleet.OnDemandOptionsProperty): void;
    resetOnDemandOptions(): void;
    get onDemandOptionsInput(): TfFleet.OnDemandOptionsProperty | undefined;
    private _spotOptions;
    get spotOptions(): TfFleet.SpotOptionsPropertyOutputReference;
    putSpotOptions(value: TfFleet.SpotOptionsProperty): void;
    resetSpotOptions(): void;
    get spotOptionsInput(): TfFleet.SpotOptionsProperty | undefined;
    private _targetCapacitySpecification;
    get targetCapacitySpecification(): TfFleet.TargetCapacitySpecificationPropertyOutputReference;
    putTargetCapacitySpecification(value: TfFleet.TargetCapacitySpecificationProperty): void;
    get targetCapacitySpecificationInput(): TfFleet.TargetCapacitySpecificationProperty | undefined;
    private _timeouts;
    get timeouts(): TfFleet.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfFleet.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfFleet.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfFleetFleetInstanceSetPropertyToTerraform(struct?: TfFleet.FleetInstanceSetProperty | cdktn.IResolvable): any;
export declare function tfFleetFleetInstanceSetPropertyToHclTerraform(struct?: TfFleet.FleetInstanceSetProperty | cdktn.IResolvable): any;
export declare function tfFleetLaunchTemplateSpecificationPropertyToTerraform(struct?: TfFleet.LaunchTemplateSpecificationPropertyOutputReference | TfFleet.LaunchTemplateSpecificationProperty): any;
export declare function tfFleetLaunchTemplateSpecificationPropertyToHclTerraform(struct?: TfFleet.LaunchTemplateSpecificationPropertyOutputReference | TfFleet.LaunchTemplateSpecificationProperty): any;
export declare function tfFleetAcceleratorCountPropertyToTerraform(struct?: TfFleet.AcceleratorCountPropertyOutputReference | TfFleet.AcceleratorCountProperty): any;
export declare function tfFleetAcceleratorCountPropertyToHclTerraform(struct?: TfFleet.AcceleratorCountPropertyOutputReference | TfFleet.AcceleratorCountProperty): any;
export declare function tfFleetAcceleratorTotalMemoryMibPropertyToTerraform(struct?: TfFleet.AcceleratorTotalMemoryMibPropertyOutputReference | TfFleet.AcceleratorTotalMemoryMibProperty): any;
export declare function tfFleetAcceleratorTotalMemoryMibPropertyToHclTerraform(struct?: TfFleet.AcceleratorTotalMemoryMibPropertyOutputReference | TfFleet.AcceleratorTotalMemoryMibProperty): any;
export declare function tfFleetBaselineEbsBandwidthMbpsPropertyToTerraform(struct?: TfFleet.BaselineEbsBandwidthMbpsPropertyOutputReference | TfFleet.BaselineEbsBandwidthMbpsProperty): any;
export declare function tfFleetBaselineEbsBandwidthMbpsPropertyToHclTerraform(struct?: TfFleet.BaselineEbsBandwidthMbpsPropertyOutputReference | TfFleet.BaselineEbsBandwidthMbpsProperty): any;
export declare function tfFleetMemoryGibPerVcpuPropertyToTerraform(struct?: TfFleet.MemoryGibPerVcpuPropertyOutputReference | TfFleet.MemoryGibPerVcpuProperty): any;
export declare function tfFleetMemoryGibPerVcpuPropertyToHclTerraform(struct?: TfFleet.MemoryGibPerVcpuPropertyOutputReference | TfFleet.MemoryGibPerVcpuProperty): any;
export declare function tfFleetMemoryMibPropertyToTerraform(struct?: TfFleet.MemoryMibPropertyOutputReference | TfFleet.MemoryMibProperty): any;
export declare function tfFleetMemoryMibPropertyToHclTerraform(struct?: TfFleet.MemoryMibPropertyOutputReference | TfFleet.MemoryMibProperty): any;
export declare function tfFleetNetworkBandwidthGbpsPropertyToTerraform(struct?: TfFleet.NetworkBandwidthGbpsPropertyOutputReference | TfFleet.NetworkBandwidthGbpsProperty): any;
export declare function tfFleetNetworkBandwidthGbpsPropertyToHclTerraform(struct?: TfFleet.NetworkBandwidthGbpsPropertyOutputReference | TfFleet.NetworkBandwidthGbpsProperty): any;
export declare function tfFleetNetworkInterfaceCountPropertyToTerraform(struct?: TfFleet.NetworkInterfaceCountPropertyOutputReference | TfFleet.NetworkInterfaceCountProperty): any;
export declare function tfFleetNetworkInterfaceCountPropertyToHclTerraform(struct?: TfFleet.NetworkInterfaceCountPropertyOutputReference | TfFleet.NetworkInterfaceCountProperty): any;
export declare function tfFleetTotalLocalStorageGbPropertyToTerraform(struct?: TfFleet.TotalLocalStorageGbPropertyOutputReference | TfFleet.TotalLocalStorageGbProperty): any;
export declare function tfFleetTotalLocalStorageGbPropertyToHclTerraform(struct?: TfFleet.TotalLocalStorageGbPropertyOutputReference | TfFleet.TotalLocalStorageGbProperty): any;
export declare function tfFleetVcpuCountPropertyToTerraform(struct?: TfFleet.VcpuCountPropertyOutputReference | TfFleet.VcpuCountProperty): any;
export declare function tfFleetVcpuCountPropertyToHclTerraform(struct?: TfFleet.VcpuCountPropertyOutputReference | TfFleet.VcpuCountProperty): any;
export declare function tfFleetInstanceRequirementsPropertyToTerraform(struct?: TfFleet.InstanceRequirementsPropertyOutputReference | TfFleet.InstanceRequirementsProperty): any;
export declare function tfFleetInstanceRequirementsPropertyToHclTerraform(struct?: TfFleet.InstanceRequirementsPropertyOutputReference | TfFleet.InstanceRequirementsProperty): any;
export declare function tfFleetOverridePropertyToTerraform(struct?: TfFleet.OverrideProperty | cdktn.IResolvable): any;
export declare function tfFleetOverridePropertyToHclTerraform(struct?: TfFleet.OverrideProperty | cdktn.IResolvable): any;
export declare function tfFleetLaunchTemplateConfigPropertyToTerraform(struct?: TfFleet.LaunchTemplateConfigProperty | cdktn.IResolvable): any;
export declare function tfFleetLaunchTemplateConfigPropertyToHclTerraform(struct?: TfFleet.LaunchTemplateConfigProperty | cdktn.IResolvable): any;
export declare function tfFleetCapacityReservationOptionsPropertyToTerraform(struct?: TfFleet.CapacityReservationOptionsPropertyOutputReference | TfFleet.CapacityReservationOptionsProperty): any;
export declare function tfFleetCapacityReservationOptionsPropertyToHclTerraform(struct?: TfFleet.CapacityReservationOptionsPropertyOutputReference | TfFleet.CapacityReservationOptionsProperty): any;
export declare function tfFleetOnDemandOptionsPropertyToTerraform(struct?: TfFleet.OnDemandOptionsPropertyOutputReference | TfFleet.OnDemandOptionsProperty): any;
export declare function tfFleetOnDemandOptionsPropertyToHclTerraform(struct?: TfFleet.OnDemandOptionsPropertyOutputReference | TfFleet.OnDemandOptionsProperty): any;
export declare function tfFleetCapacityRebalancePropertyToTerraform(struct?: TfFleet.CapacityRebalancePropertyOutputReference | TfFleet.CapacityRebalanceProperty): any;
export declare function tfFleetCapacityRebalancePropertyToHclTerraform(struct?: TfFleet.CapacityRebalancePropertyOutputReference | TfFleet.CapacityRebalanceProperty): any;
export declare function tfFleetMaintenanceStrategiesPropertyToTerraform(struct?: TfFleet.MaintenanceStrategiesPropertyOutputReference | TfFleet.MaintenanceStrategiesProperty): any;
export declare function tfFleetMaintenanceStrategiesPropertyToHclTerraform(struct?: TfFleet.MaintenanceStrategiesPropertyOutputReference | TfFleet.MaintenanceStrategiesProperty): any;
export declare function tfFleetSpotOptionsPropertyToTerraform(struct?: TfFleet.SpotOptionsPropertyOutputReference | TfFleet.SpotOptionsProperty): any;
export declare function tfFleetSpotOptionsPropertyToHclTerraform(struct?: TfFleet.SpotOptionsPropertyOutputReference | TfFleet.SpotOptionsProperty): any;
export declare function tfFleetTargetCapacitySpecificationPropertyToTerraform(struct?: TfFleet.TargetCapacitySpecificationPropertyOutputReference | TfFleet.TargetCapacitySpecificationProperty): any;
export declare function tfFleetTargetCapacitySpecificationPropertyToHclTerraform(struct?: TfFleet.TargetCapacitySpecificationPropertyOutputReference | TfFleet.TargetCapacitySpecificationProperty): any;
export declare function tfFleetTimeoutsPropertyToTerraform(struct?: TfFleet.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfFleetTimeoutsPropertyToHclTerraform(struct?: TfFleet.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfFleet {
    interface FleetInstanceSetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#instance_ids TfFleet#instance_ids}
        */
        readonly instanceIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#instance_type TfFleet#instance_type}
        */
        readonly instanceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#lifecycle TfFleet#lifecycle}
        */
        readonly lifecycle?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#platform TfFleet#platform}
        */
        readonly platform?: string;
    }
    class FleetInstanceSetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FleetInstanceSetProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FleetInstanceSetProperty | cdktn.IResolvable | undefined);
        private _instanceIds?;
        get instanceIds(): string[];
        set instanceIds(value: string[]);
        resetInstanceIds(): void;
        get instanceIdsInput(): string[] | undefined;
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        resetInstanceType(): void;
        get instanceTypeInput(): string | undefined;
        private _lifecycle?;
        get lifecycle(): string;
        set lifecycle(value: string);
        resetLifecycle(): void;
        get lifecycleInput(): string | undefined;
        private _platform?;
        get platform(): string;
        set platform(value: string);
        resetPlatform(): void;
        get platformInput(): string | undefined;
    }
    class FleetInstanceSetPropertyList extends cdktn.ComplexList {
        internalValue?: FleetInstanceSetProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FleetInstanceSetPropertyOutputReference;
    }
    interface LaunchTemplateSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#launch_template_id TfFleet#launch_template_id}
        */
        readonly launchTemplateId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#launch_template_name TfFleet#launch_template_name}
        */
        readonly launchTemplateName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#version TfFleet#version}
        */
        readonly version: string;
    }
    class LaunchTemplateSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LaunchTemplateSpecificationProperty | undefined;
        set internalValue(value: LaunchTemplateSpecificationProperty | undefined);
        private _launchTemplateId?;
        get launchTemplateId(): string;
        set launchTemplateId(value: string);
        resetLaunchTemplateId(): void;
        get launchTemplateIdInput(): string | undefined;
        private _launchTemplateName?;
        get launchTemplateName(): string;
        set launchTemplateName(value: string);
        resetLaunchTemplateName(): void;
        get launchTemplateNameInput(): string | undefined;
        private _version?;
        get version(): string;
        set version(value: string);
        get versionInput(): string | undefined;
    }
    interface AcceleratorCountProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#max TfFleet#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#min TfFleet#min}
        */
        readonly min?: number;
    }
    class AcceleratorCountPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AcceleratorCountProperty | undefined;
        set internalValue(value: AcceleratorCountProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface AcceleratorTotalMemoryMibProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#max TfFleet#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#min TfFleet#min}
        */
        readonly min?: number;
    }
    class AcceleratorTotalMemoryMibPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AcceleratorTotalMemoryMibProperty | undefined;
        set internalValue(value: AcceleratorTotalMemoryMibProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface BaselineEbsBandwidthMbpsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#max TfFleet#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#min TfFleet#min}
        */
        readonly min?: number;
    }
    class BaselineEbsBandwidthMbpsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BaselineEbsBandwidthMbpsProperty | undefined;
        set internalValue(value: BaselineEbsBandwidthMbpsProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface MemoryGibPerVcpuProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#max TfFleet#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#min TfFleet#min}
        */
        readonly min?: number;
    }
    class MemoryGibPerVcpuPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MemoryGibPerVcpuProperty | undefined;
        set internalValue(value: MemoryGibPerVcpuProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface MemoryMibProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#max TfFleet#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#min TfFleet#min}
        */
        readonly min: number;
    }
    class MemoryMibPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MemoryMibProperty | undefined;
        set internalValue(value: MemoryMibProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        get minInput(): number | undefined;
    }
    interface NetworkBandwidthGbpsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#max TfFleet#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#min TfFleet#min}
        */
        readonly min?: number;
    }
    class NetworkBandwidthGbpsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NetworkBandwidthGbpsProperty | undefined;
        set internalValue(value: NetworkBandwidthGbpsProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface NetworkInterfaceCountProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#max TfFleet#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#min TfFleet#min}
        */
        readonly min?: number;
    }
    class NetworkInterfaceCountPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NetworkInterfaceCountProperty | undefined;
        set internalValue(value: NetworkInterfaceCountProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface TotalLocalStorageGbProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#max TfFleet#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#min TfFleet#min}
        */
        readonly min?: number;
    }
    class TotalLocalStorageGbPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TotalLocalStorageGbProperty | undefined;
        set internalValue(value: TotalLocalStorageGbProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface VcpuCountProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#max TfFleet#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#min TfFleet#min}
        */
        readonly min: number;
    }
    class VcpuCountPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VcpuCountProperty | undefined;
        set internalValue(value: VcpuCountProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        get minInput(): number | undefined;
    }
    interface InstanceRequirementsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#accelerator_manufacturers TfFleet#accelerator_manufacturers}
        */
        readonly acceleratorManufacturers?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#accelerator_names TfFleet#accelerator_names}
        */
        readonly acceleratorNames?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#accelerator_types TfFleet#accelerator_types}
        */
        readonly acceleratorTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#allowed_instance_types TfFleet#allowed_instance_types}
        */
        readonly allowedInstanceTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#bare_metal TfFleet#bare_metal}
        */
        readonly bareMetal?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#burstable_performance TfFleet#burstable_performance}
        */
        readonly burstablePerformance?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#cpu_manufacturers TfFleet#cpu_manufacturers}
        */
        readonly cpuManufacturers?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#excluded_instance_types TfFleet#excluded_instance_types}
        */
        readonly excludedInstanceTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#instance_generations TfFleet#instance_generations}
        */
        readonly instanceGenerations?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#local_storage TfFleet#local_storage}
        */
        readonly localStorage?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#local_storage_types TfFleet#local_storage_types}
        */
        readonly localStorageTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#max_spot_price_as_percentage_of_optimal_on_demand_price TfFleet#max_spot_price_as_percentage_of_optimal_on_demand_price}
        */
        readonly maxSpotPriceAsPercentageOfOptimalOnDemandPrice?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#on_demand_max_price_percentage_over_lowest_price TfFleet#on_demand_max_price_percentage_over_lowest_price}
        */
        readonly onDemandMaxPricePercentageOverLowestPrice?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#require_hibernate_support TfFleet#require_hibernate_support}
        */
        readonly requireHibernateSupport?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#spot_max_price_percentage_over_lowest_price TfFleet#spot_max_price_percentage_over_lowest_price}
        */
        readonly spotMaxPricePercentageOverLowestPrice?: number;
        /**
        * accelerator_count block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#accelerator_count TfFleet#accelerator_count}
        */
        readonly acceleratorCount?: AcceleratorCountProperty;
        /**
        * accelerator_total_memory_mib block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#accelerator_total_memory_mib TfFleet#accelerator_total_memory_mib}
        */
        readonly acceleratorTotalMemoryMib?: AcceleratorTotalMemoryMibProperty;
        /**
        * baseline_ebs_bandwidth_mbps block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#baseline_ebs_bandwidth_mbps TfFleet#baseline_ebs_bandwidth_mbps}
        */
        readonly baselineEbsBandwidthMbps?: BaselineEbsBandwidthMbpsProperty;
        /**
        * memory_gib_per_vcpu block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#memory_gib_per_vcpu TfFleet#memory_gib_per_vcpu}
        */
        readonly memoryGibPerVcpu?: MemoryGibPerVcpuProperty;
        /**
        * memory_mib block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#memory_mib TfFleet#memory_mib}
        */
        readonly memoryMib: MemoryMibProperty;
        /**
        * network_bandwidth_gbps block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#network_bandwidth_gbps TfFleet#network_bandwidth_gbps}
        */
        readonly networkBandwidthGbps?: NetworkBandwidthGbpsProperty;
        /**
        * network_interface_count block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#network_interface_count TfFleet#network_interface_count}
        */
        readonly networkInterfaceCount?: NetworkInterfaceCountProperty;
        /**
        * total_local_storage_gb block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#total_local_storage_gb TfFleet#total_local_storage_gb}
        */
        readonly totalLocalStorageGb?: TotalLocalStorageGbProperty;
        /**
        * vcpu_count block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#vcpu_count TfFleet#vcpu_count}
        */
        readonly vcpuCount: VcpuCountProperty;
    }
    class InstanceRequirementsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InstanceRequirementsProperty | undefined;
        set internalValue(value: InstanceRequirementsProperty | undefined);
        private _acceleratorManufacturers?;
        get acceleratorManufacturers(): string[];
        set acceleratorManufacturers(value: string[]);
        resetAcceleratorManufacturers(): void;
        get acceleratorManufacturersInput(): string[] | undefined;
        private _acceleratorNames?;
        get acceleratorNames(): string[];
        set acceleratorNames(value: string[]);
        resetAcceleratorNames(): void;
        get acceleratorNamesInput(): string[] | undefined;
        private _acceleratorTypes?;
        get acceleratorTypes(): string[];
        set acceleratorTypes(value: string[]);
        resetAcceleratorTypes(): void;
        get acceleratorTypesInput(): string[] | undefined;
        private _allowedInstanceTypes?;
        get allowedInstanceTypes(): string[];
        set allowedInstanceTypes(value: string[]);
        resetAllowedInstanceTypes(): void;
        get allowedInstanceTypesInput(): string[] | undefined;
        private _bareMetal?;
        get bareMetal(): string;
        set bareMetal(value: string);
        resetBareMetal(): void;
        get bareMetalInput(): string | undefined;
        private _burstablePerformance?;
        get burstablePerformance(): string;
        set burstablePerformance(value: string);
        resetBurstablePerformance(): void;
        get burstablePerformanceInput(): string | undefined;
        private _cpuManufacturers?;
        get cpuManufacturers(): string[];
        set cpuManufacturers(value: string[]);
        resetCpuManufacturers(): void;
        get cpuManufacturersInput(): string[] | undefined;
        private _excludedInstanceTypes?;
        get excludedInstanceTypes(): string[];
        set excludedInstanceTypes(value: string[]);
        resetExcludedInstanceTypes(): void;
        get excludedInstanceTypesInput(): string[] | undefined;
        private _instanceGenerations?;
        get instanceGenerations(): string[];
        set instanceGenerations(value: string[]);
        resetInstanceGenerations(): void;
        get instanceGenerationsInput(): string[] | undefined;
        private _localStorage?;
        get localStorage(): string;
        set localStorage(value: string);
        resetLocalStorage(): void;
        get localStorageInput(): string | undefined;
        private _localStorageTypes?;
        get localStorageTypes(): string[];
        set localStorageTypes(value: string[]);
        resetLocalStorageTypes(): void;
        get localStorageTypesInput(): string[] | undefined;
        private _maxSpotPriceAsPercentageOfOptimalOnDemandPrice?;
        get maxSpotPriceAsPercentageOfOptimalOnDemandPrice(): number;
        set maxSpotPriceAsPercentageOfOptimalOnDemandPrice(value: number);
        resetMaxSpotPriceAsPercentageOfOptimalOnDemandPrice(): void;
        get maxSpotPriceAsPercentageOfOptimalOnDemandPriceInput(): number | undefined;
        private _onDemandMaxPricePercentageOverLowestPrice?;
        get onDemandMaxPricePercentageOverLowestPrice(): number;
        set onDemandMaxPricePercentageOverLowestPrice(value: number);
        resetOnDemandMaxPricePercentageOverLowestPrice(): void;
        get onDemandMaxPricePercentageOverLowestPriceInput(): number | undefined;
        private _requireHibernateSupport?;
        get requireHibernateSupport(): boolean | cdktn.IResolvable;
        set requireHibernateSupport(value: boolean | cdktn.IResolvable);
        resetRequireHibernateSupport(): void;
        get requireHibernateSupportInput(): boolean | cdktn.IResolvable | undefined;
        private _spotMaxPricePercentageOverLowestPrice?;
        get spotMaxPricePercentageOverLowestPrice(): number;
        set spotMaxPricePercentageOverLowestPrice(value: number);
        resetSpotMaxPricePercentageOverLowestPrice(): void;
        get spotMaxPricePercentageOverLowestPriceInput(): number | undefined;
        private _acceleratorCount;
        get acceleratorCount(): AcceleratorCountPropertyOutputReference;
        putAcceleratorCount(value: AcceleratorCountProperty): void;
        resetAcceleratorCount(): void;
        get acceleratorCountInput(): AcceleratorCountProperty | undefined;
        private _acceleratorTotalMemoryMib;
        get acceleratorTotalMemoryMib(): AcceleratorTotalMemoryMibPropertyOutputReference;
        putAcceleratorTotalMemoryMib(value: AcceleratorTotalMemoryMibProperty): void;
        resetAcceleratorTotalMemoryMib(): void;
        get acceleratorTotalMemoryMibInput(): AcceleratorTotalMemoryMibProperty | undefined;
        private _baselineEbsBandwidthMbps;
        get baselineEbsBandwidthMbps(): BaselineEbsBandwidthMbpsPropertyOutputReference;
        putBaselineEbsBandwidthMbps(value: BaselineEbsBandwidthMbpsProperty): void;
        resetBaselineEbsBandwidthMbps(): void;
        get baselineEbsBandwidthMbpsInput(): BaselineEbsBandwidthMbpsProperty | undefined;
        private _memoryGibPerVcpu;
        get memoryGibPerVcpu(): MemoryGibPerVcpuPropertyOutputReference;
        putMemoryGibPerVcpu(value: MemoryGibPerVcpuProperty): void;
        resetMemoryGibPerVcpu(): void;
        get memoryGibPerVcpuInput(): MemoryGibPerVcpuProperty | undefined;
        private _memoryMib;
        get memoryMib(): MemoryMibPropertyOutputReference;
        putMemoryMib(value: MemoryMibProperty): void;
        get memoryMibInput(): MemoryMibProperty | undefined;
        private _networkBandwidthGbps;
        get networkBandwidthGbps(): NetworkBandwidthGbpsPropertyOutputReference;
        putNetworkBandwidthGbps(value: NetworkBandwidthGbpsProperty): void;
        resetNetworkBandwidthGbps(): void;
        get networkBandwidthGbpsInput(): NetworkBandwidthGbpsProperty | undefined;
        private _networkInterfaceCount;
        get networkInterfaceCount(): NetworkInterfaceCountPropertyOutputReference;
        putNetworkInterfaceCount(value: NetworkInterfaceCountProperty): void;
        resetNetworkInterfaceCount(): void;
        get networkInterfaceCountInput(): NetworkInterfaceCountProperty | undefined;
        private _totalLocalStorageGb;
        get totalLocalStorageGb(): TotalLocalStorageGbPropertyOutputReference;
        putTotalLocalStorageGb(value: TotalLocalStorageGbProperty): void;
        resetTotalLocalStorageGb(): void;
        get totalLocalStorageGbInput(): TotalLocalStorageGbProperty | undefined;
        private _vcpuCount;
        get vcpuCount(): VcpuCountPropertyOutputReference;
        putVcpuCount(value: VcpuCountProperty): void;
        get vcpuCountInput(): VcpuCountProperty | undefined;
    }
    interface OverrideProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#availability_zone TfFleet#availability_zone}
        */
        readonly availabilityZone?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#instance_type TfFleet#instance_type}
        */
        readonly instanceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#max_price TfFleet#max_price}
        */
        readonly maxPrice?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#priority TfFleet#priority}
        */
        readonly priority?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#subnet_id TfFleet#subnet_id}
        */
        readonly subnetId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#weighted_capacity TfFleet#weighted_capacity}
        */
        readonly weightedCapacity?: number;
        /**
        * instance_requirements block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#instance_requirements TfFleet#instance_requirements}
        */
        readonly instanceRequirements?: InstanceRequirementsProperty;
    }
    class OverridePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OverrideProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OverrideProperty | cdktn.IResolvable | undefined);
        private _availabilityZone?;
        get availabilityZone(): string;
        set availabilityZone(value: string);
        resetAvailabilityZone(): void;
        get availabilityZoneInput(): string | undefined;
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        resetInstanceType(): void;
        get instanceTypeInput(): string | undefined;
        private _maxPrice?;
        get maxPrice(): string;
        set maxPrice(value: string);
        resetMaxPrice(): void;
        get maxPriceInput(): string | undefined;
        private _priority?;
        get priority(): number;
        set priority(value: number);
        resetPriority(): void;
        get priorityInput(): number | undefined;
        private _subnetId?;
        get subnetId(): string;
        set subnetId(value: string);
        resetSubnetId(): void;
        get subnetIdInput(): string | undefined;
        private _weightedCapacity?;
        get weightedCapacity(): number;
        set weightedCapacity(value: number);
        resetWeightedCapacity(): void;
        get weightedCapacityInput(): number | undefined;
        private _instanceRequirements;
        get instanceRequirements(): InstanceRequirementsPropertyOutputReference;
        putInstanceRequirements(value: InstanceRequirementsProperty): void;
        resetInstanceRequirements(): void;
        get instanceRequirementsInput(): InstanceRequirementsProperty | undefined;
    }
    class OverridePropertyList extends cdktn.ComplexList {
        internalValue?: OverrideProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OverridePropertyOutputReference;
    }
    interface LaunchTemplateConfigProperty {
        /**
        * launch_template_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#launch_template_specification TfFleet#launch_template_specification}
        */
        readonly launchTemplateSpecification?: LaunchTemplateSpecificationProperty;
        /**
        * override block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#override TfFleet#override}
        */
        readonly override?: OverrideProperty[] | cdktn.IResolvable;
    }
    class LaunchTemplateConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LaunchTemplateConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LaunchTemplateConfigProperty | cdktn.IResolvable | undefined);
        private _launchTemplateSpecification;
        get launchTemplateSpecification(): LaunchTemplateSpecificationPropertyOutputReference;
        putLaunchTemplateSpecification(value: LaunchTemplateSpecificationProperty): void;
        resetLaunchTemplateSpecification(): void;
        get launchTemplateSpecificationInput(): LaunchTemplateSpecificationProperty | undefined;
        private _override;
        get override(): OverridePropertyList;
        putOverride(value: OverrideProperty[] | cdktn.IResolvable): void;
        resetOverride(): void;
        get overrideInput(): cdktn.IResolvable | OverrideProperty[] | undefined;
    }
    class LaunchTemplateConfigPropertyList extends cdktn.ComplexList {
        internalValue?: LaunchTemplateConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LaunchTemplateConfigPropertyOutputReference;
    }
    interface CapacityReservationOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#usage_strategy TfFleet#usage_strategy}
        */
        readonly usageStrategy?: string;
    }
    class CapacityReservationOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CapacityReservationOptionsProperty | undefined;
        set internalValue(value: CapacityReservationOptionsProperty | undefined);
        private _usageStrategy?;
        get usageStrategy(): string;
        set usageStrategy(value: string);
        resetUsageStrategy(): void;
        get usageStrategyInput(): string | undefined;
    }
    interface OnDemandOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#allocation_strategy TfFleet#allocation_strategy}
        */
        readonly allocationStrategy?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#max_total_price TfFleet#max_total_price}
        */
        readonly maxTotalPrice?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#min_target_capacity TfFleet#min_target_capacity}
        */
        readonly minTargetCapacity?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#single_availability_zone TfFleet#single_availability_zone}
        */
        readonly singleAvailabilityZone?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#single_instance_type TfFleet#single_instance_type}
        */
        readonly singleInstanceType?: boolean | cdktn.IResolvable;
        /**
        * capacity_reservation_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#capacity_reservation_options TfFleet#capacity_reservation_options}
        */
        readonly capacityReservationOptions?: CapacityReservationOptionsProperty;
    }
    class OnDemandOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OnDemandOptionsProperty | undefined;
        set internalValue(value: OnDemandOptionsProperty | undefined);
        private _allocationStrategy?;
        get allocationStrategy(): string;
        set allocationStrategy(value: string);
        resetAllocationStrategy(): void;
        get allocationStrategyInput(): string | undefined;
        private _maxTotalPrice?;
        get maxTotalPrice(): string;
        set maxTotalPrice(value: string);
        resetMaxTotalPrice(): void;
        get maxTotalPriceInput(): string | undefined;
        private _minTargetCapacity?;
        get minTargetCapacity(): number;
        set minTargetCapacity(value: number);
        resetMinTargetCapacity(): void;
        get minTargetCapacityInput(): number | undefined;
        private _singleAvailabilityZone?;
        get singleAvailabilityZone(): boolean | cdktn.IResolvable;
        set singleAvailabilityZone(value: boolean | cdktn.IResolvable);
        resetSingleAvailabilityZone(): void;
        get singleAvailabilityZoneInput(): boolean | cdktn.IResolvable | undefined;
        private _singleInstanceType?;
        get singleInstanceType(): boolean | cdktn.IResolvable;
        set singleInstanceType(value: boolean | cdktn.IResolvable);
        resetSingleInstanceType(): void;
        get singleInstanceTypeInput(): boolean | cdktn.IResolvable | undefined;
        private _capacityReservationOptions;
        get capacityReservationOptions(): CapacityReservationOptionsPropertyOutputReference;
        putCapacityReservationOptions(value: CapacityReservationOptionsProperty): void;
        resetCapacityReservationOptions(): void;
        get capacityReservationOptionsInput(): CapacityReservationOptionsProperty | undefined;
    }
    interface CapacityRebalanceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#replacement_strategy TfFleet#replacement_strategy}
        */
        readonly replacementStrategy?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#termination_delay TfFleet#termination_delay}
        */
        readonly terminationDelay?: number;
    }
    class CapacityRebalancePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CapacityRebalanceProperty | undefined;
        set internalValue(value: CapacityRebalanceProperty | undefined);
        private _replacementStrategy?;
        get replacementStrategy(): string;
        set replacementStrategy(value: string);
        resetReplacementStrategy(): void;
        get replacementStrategyInput(): string | undefined;
        private _terminationDelay?;
        get terminationDelay(): number;
        set terminationDelay(value: number);
        resetTerminationDelay(): void;
        get terminationDelayInput(): number | undefined;
    }
    interface MaintenanceStrategiesProperty {
        /**
        * capacity_rebalance block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#capacity_rebalance TfFleet#capacity_rebalance}
        */
        readonly capacityRebalance?: CapacityRebalanceProperty;
    }
    class MaintenanceStrategiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MaintenanceStrategiesProperty | undefined;
        set internalValue(value: MaintenanceStrategiesProperty | undefined);
        private _capacityRebalance;
        get capacityRebalance(): CapacityRebalancePropertyOutputReference;
        putCapacityRebalance(value: CapacityRebalanceProperty): void;
        resetCapacityRebalance(): void;
        get capacityRebalanceInput(): CapacityRebalanceProperty | undefined;
    }
    interface SpotOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#allocation_strategy TfFleet#allocation_strategy}
        */
        readonly allocationStrategy?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#instance_interruption_behavior TfFleet#instance_interruption_behavior}
        */
        readonly instanceInterruptionBehavior?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#instance_pools_to_use_count TfFleet#instance_pools_to_use_count}
        */
        readonly instancePoolsToUseCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#max_total_price TfFleet#max_total_price}
        */
        readonly maxTotalPrice?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#min_target_capacity TfFleet#min_target_capacity}
        */
        readonly minTargetCapacity?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#single_availability_zone TfFleet#single_availability_zone}
        */
        readonly singleAvailabilityZone?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#single_instance_type TfFleet#single_instance_type}
        */
        readonly singleInstanceType?: boolean | cdktn.IResolvable;
        /**
        * maintenance_strategies block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#maintenance_strategies TfFleet#maintenance_strategies}
        */
        readonly maintenanceStrategies?: MaintenanceStrategiesProperty;
    }
    class SpotOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpotOptionsProperty | undefined;
        set internalValue(value: SpotOptionsProperty | undefined);
        private _allocationStrategy?;
        get allocationStrategy(): string;
        set allocationStrategy(value: string);
        resetAllocationStrategy(): void;
        get allocationStrategyInput(): string | undefined;
        private _instanceInterruptionBehavior?;
        get instanceInterruptionBehavior(): string;
        set instanceInterruptionBehavior(value: string);
        resetInstanceInterruptionBehavior(): void;
        get instanceInterruptionBehaviorInput(): string | undefined;
        private _instancePoolsToUseCount?;
        get instancePoolsToUseCount(): number;
        set instancePoolsToUseCount(value: number);
        resetInstancePoolsToUseCount(): void;
        get instancePoolsToUseCountInput(): number | undefined;
        private _maxTotalPrice?;
        get maxTotalPrice(): string;
        set maxTotalPrice(value: string);
        resetMaxTotalPrice(): void;
        get maxTotalPriceInput(): string | undefined;
        private _minTargetCapacity?;
        get minTargetCapacity(): number;
        set minTargetCapacity(value: number);
        resetMinTargetCapacity(): void;
        get minTargetCapacityInput(): number | undefined;
        private _singleAvailabilityZone?;
        get singleAvailabilityZone(): boolean | cdktn.IResolvable;
        set singleAvailabilityZone(value: boolean | cdktn.IResolvable);
        resetSingleAvailabilityZone(): void;
        get singleAvailabilityZoneInput(): boolean | cdktn.IResolvable | undefined;
        private _singleInstanceType?;
        get singleInstanceType(): boolean | cdktn.IResolvable;
        set singleInstanceType(value: boolean | cdktn.IResolvable);
        resetSingleInstanceType(): void;
        get singleInstanceTypeInput(): boolean | cdktn.IResolvable | undefined;
        private _maintenanceStrategies;
        get maintenanceStrategies(): MaintenanceStrategiesPropertyOutputReference;
        putMaintenanceStrategies(value: MaintenanceStrategiesProperty): void;
        resetMaintenanceStrategies(): void;
        get maintenanceStrategiesInput(): MaintenanceStrategiesProperty | undefined;
    }
    interface TargetCapacitySpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#default_target_capacity_type TfFleet#default_target_capacity_type}
        */
        readonly defaultTargetCapacityType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#on_demand_target_capacity TfFleet#on_demand_target_capacity}
        */
        readonly onDemandTargetCapacity?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#spot_target_capacity TfFleet#spot_target_capacity}
        */
        readonly spotTargetCapacity?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#target_capacity_unit_type TfFleet#target_capacity_unit_type}
        */
        readonly targetCapacityUnitType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#total_target_capacity TfFleet#total_target_capacity}
        */
        readonly totalTargetCapacity: number;
    }
    class TargetCapacitySpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TargetCapacitySpecificationProperty | undefined;
        set internalValue(value: TargetCapacitySpecificationProperty | undefined);
        private _defaultTargetCapacityType?;
        get defaultTargetCapacityType(): string;
        set defaultTargetCapacityType(value: string);
        get defaultTargetCapacityTypeInput(): string | undefined;
        private _onDemandTargetCapacity?;
        get onDemandTargetCapacity(): number;
        set onDemandTargetCapacity(value: number);
        resetOnDemandTargetCapacity(): void;
        get onDemandTargetCapacityInput(): number | undefined;
        private _spotTargetCapacity?;
        get spotTargetCapacity(): number;
        set spotTargetCapacity(value: number);
        resetSpotTargetCapacity(): void;
        get spotTargetCapacityInput(): number | undefined;
        private _targetCapacityUnitType?;
        get targetCapacityUnitType(): string;
        set targetCapacityUnitType(value: string);
        resetTargetCapacityUnitType(): void;
        get targetCapacityUnitTypeInput(): string | undefined;
        private _totalTargetCapacity?;
        get totalTargetCapacity(): number;
        set totalTargetCapacity(value: number);
        get totalTargetCapacityInput(): number | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#create TfFleet#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#delete TfFleet#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_fleet#update TfFleet#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
