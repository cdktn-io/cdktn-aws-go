import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfPublicIpv4PoolConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_public_ipv4_pool#id DataTfPublicIpv4Pool#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_public_ipv4_pool#pool_id DataTfPublicIpv4Pool#pool_id}
    */
    readonly poolId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_public_ipv4_pool#region DataTfPublicIpv4Pool#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_public_ipv4_pool#tags DataTfPublicIpv4Pool#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_public_ipv4_pool aws_ec2_public_ipv4_pool}
*/
export declare class DataTfPublicIpv4Pool extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_ec2_public_ipv4_pool";
    /**
    * Generates CDKTN code for importing a DataTfPublicIpv4Pool resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfPublicIpv4Pool to import
    * @param importFromId The id of the existing DataTfPublicIpv4Pool that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_public_ipv4_pool#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfPublicIpv4Pool to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_public_ipv4_pool aws_ec2_public_ipv4_pool} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfPublicIpv4PoolConfig
    */
    constructor(scope: Construct, id: string, config: DataTfPublicIpv4PoolConfig);
    get description(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get networkBorderGroup(): string;
    private _poolAddressRanges;
    get poolAddressRanges(): DataTfPublicIpv4Pool.PoolAddressRangesPropertyList;
    private _poolId?;
    get poolId(): string;
    set poolId(value: string);
    get poolIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    get totalAddressCount(): number;
    get totalAvailableAddressCount(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfPublicIpv4PoolPoolAddressRangesPropertyToTerraform(struct?: DataTfPublicIpv4Pool.PoolAddressRangesProperty): any;
export declare function dataTfPublicIpv4PoolPoolAddressRangesPropertyToHclTerraform(struct?: DataTfPublicIpv4Pool.PoolAddressRangesProperty): any;
export declare namespace DataTfPublicIpv4Pool {
    interface PoolAddressRangesProperty {
    }
    class PoolAddressRangesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PoolAddressRangesProperty | undefined;
        set internalValue(value: PoolAddressRangesProperty | undefined);
        get addressCount(): number;
        get availableAddressCount(): number;
        get firstAddress(): string;
        get lastAddress(): string;
    }
    class PoolAddressRangesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PoolAddressRangesPropertyOutputReference;
    }
}
