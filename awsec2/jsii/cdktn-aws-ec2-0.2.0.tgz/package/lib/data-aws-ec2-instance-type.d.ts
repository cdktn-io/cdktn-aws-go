import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfInstanceTypeConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_instance_type#id DataTfInstanceType#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_instance_type#instance_type DataTfInstanceType#instance_type}
    */
    readonly instanceType: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_instance_type#region DataTfInstanceType#region}
    */
    readonly region?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_instance_type#timeouts DataTfInstanceType#timeouts}
    */
    readonly timeouts?: DataTfInstanceType.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_instance_type aws_ec2_instance_type}
*/
export declare class DataTfInstanceType extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_ec2_instance_type";
    /**
    * Generates CDKTN code for importing a DataTfInstanceType resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfInstanceType to import
    * @param importFromId The id of the existing DataTfInstanceType that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_instance_type#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfInstanceType to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_instance_type aws_ec2_instance_type} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfInstanceTypeConfig
    */
    constructor(scope: Construct, id: string, config: DataTfInstanceTypeConfig);
    get autoRecoverySupported(): cdktn.IResolvable;
    get bandwidthWeightings(): string[];
    get bareMetal(): cdktn.IResolvable;
    get bootModes(): string[];
    get burstablePerformanceSupported(): cdktn.IResolvable;
    get currentGeneration(): cdktn.IResolvable;
    get dedicatedHostsSupported(): cdktn.IResolvable;
    get defaultCores(): number;
    get defaultNetworkCardIndex(): number;
    get defaultThreadsPerCore(): number;
    get defaultVcpus(): number;
    get ebsEncryptionSupport(): string;
    get ebsNvmeSupport(): string;
    get ebsOptimizedSupport(): string;
    get ebsPerformanceBaselineBandwidth(): number;
    get ebsPerformanceBaselineIops(): number;
    get ebsPerformanceBaselineThroughput(): number;
    get ebsPerformanceMaximumBandwidth(): number;
    get ebsPerformanceMaximumIops(): number;
    get ebsPerformanceMaximumThroughput(): number;
    get efaMaximumInterfaces(): number;
    get efaSupported(): cdktn.IResolvable;
    get enaSrdSupported(): cdktn.IResolvable;
    get enaSupport(): string;
    get encryptionInTransitSupported(): cdktn.IResolvable;
    private _fpgas;
    get fpgas(): DataTfInstanceType.FpgasPropertyList;
    get freeTierEligible(): cdktn.IResolvable;
    private _gpus;
    get gpus(): DataTfInstanceType.GpusPropertyList;
    get hibernationSupported(): cdktn.IResolvable;
    get hypervisor(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _inferenceAccelerators;
    get inferenceAccelerators(): DataTfInstanceType.InferenceAcceleratorsPropertyList;
    private _instanceDisks;
    get instanceDisks(): DataTfInstanceType.InstanceDisksPropertyList;
    get instanceStorageSupported(): cdktn.IResolvable;
    private _instanceType?;
    get instanceType(): string;
    set instanceType(value: string);
    get instanceTypeInput(): string | undefined;
    get ipv6Supported(): cdktn.IResolvable;
    get maximumIpv4AddressesPerInterface(): number;
    get maximumIpv6AddressesPerInterface(): number;
    get maximumNetworkCards(): number;
    get maximumNetworkInterfaces(): number;
    private _mediaAccelerators;
    get mediaAccelerators(): DataTfInstanceType.MediaAcceleratorsPropertyList;
    get memorySize(): number;
    private _networkCards;
    get networkCards(): DataTfInstanceType.NetworkCardsPropertyList;
    get networkPerformance(): string;
    private _neuronDevices;
    get neuronDevices(): DataTfInstanceType.NeuronDevicesPropertyList;
    get nitroEnclavesSupport(): string;
    get nitroTpmSupport(): string;
    get nitroTpmSupportedVersions(): string[];
    get phcSupport(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get supportedArchitectures(): string[];
    get supportedCpuFeatures(): string[];
    get supportedPlacementStrategies(): string[];
    get supportedRootDeviceTypes(): string[];
    get supportedUsagesClasses(): string[];
    get supportedVirtualizationTypes(): string[];
    get sustainedClockSpeed(): number;
    get totalFpgaMemory(): number;
    get totalGpuMemory(): number;
    get totalInferenceMemory(): number;
    get totalInstanceStorage(): number;
    get totalMediaMemory(): number;
    get totalNeuronDeviceMemory(): number;
    get validCores(): number[];
    get validThreadsPerCore(): number[];
    private _timeouts;
    get timeouts(): DataTfInstanceType.TimeoutsPropertyOutputReference;
    putTimeouts(value: DataTfInstanceType.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataTfInstanceType.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfInstanceTypeFpgasPropertyToTerraform(struct?: DataTfInstanceType.FpgasProperty): any;
export declare function dataTfInstanceTypeFpgasPropertyToHclTerraform(struct?: DataTfInstanceType.FpgasProperty): any;
export declare function dataTfInstanceTypeGpusPropertyToTerraform(struct?: DataTfInstanceType.GpusProperty): any;
export declare function dataTfInstanceTypeGpusPropertyToHclTerraform(struct?: DataTfInstanceType.GpusProperty): any;
export declare function dataTfInstanceTypeInferenceAcceleratorsPropertyToTerraform(struct?: DataTfInstanceType.InferenceAcceleratorsProperty): any;
export declare function dataTfInstanceTypeInferenceAcceleratorsPropertyToHclTerraform(struct?: DataTfInstanceType.InferenceAcceleratorsProperty): any;
export declare function dataTfInstanceTypeInstanceDisksPropertyToTerraform(struct?: DataTfInstanceType.InstanceDisksProperty): any;
export declare function dataTfInstanceTypeInstanceDisksPropertyToHclTerraform(struct?: DataTfInstanceType.InstanceDisksProperty): any;
export declare function dataTfInstanceTypeMediaAcceleratorsPropertyToTerraform(struct?: DataTfInstanceType.MediaAcceleratorsProperty): any;
export declare function dataTfInstanceTypeMediaAcceleratorsPropertyToHclTerraform(struct?: DataTfInstanceType.MediaAcceleratorsProperty): any;
export declare function dataTfInstanceTypeNetworkCardsPropertyToTerraform(struct?: DataTfInstanceType.NetworkCardsProperty): any;
export declare function dataTfInstanceTypeNetworkCardsPropertyToHclTerraform(struct?: DataTfInstanceType.NetworkCardsProperty): any;
export declare function dataTfInstanceTypeNeuronDevicesPropertyToTerraform(struct?: DataTfInstanceType.NeuronDevicesProperty): any;
export declare function dataTfInstanceTypeNeuronDevicesPropertyToHclTerraform(struct?: DataTfInstanceType.NeuronDevicesProperty): any;
export declare function dataTfInstanceTypeTimeoutsPropertyToTerraform(struct?: DataTfInstanceType.TimeoutsProperty | cdktn.IResolvable): any;
export declare function dataTfInstanceTypeTimeoutsPropertyToHclTerraform(struct?: DataTfInstanceType.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace DataTfInstanceType {
    interface FpgasProperty {
    }
    class FpgasPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FpgasProperty | undefined;
        set internalValue(value: FpgasProperty | undefined);
        get count(): number;
        get manufacturer(): string;
        get memorySize(): number;
        get name(): string;
    }
    class FpgasPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FpgasPropertyOutputReference;
    }
    interface GpusProperty {
    }
    class GpusPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GpusProperty | undefined;
        set internalValue(value: GpusProperty | undefined);
        get count(): number;
        get manufacturer(): string;
        get memorySize(): number;
        get name(): string;
    }
    class GpusPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GpusPropertyOutputReference;
    }
    interface InferenceAcceleratorsProperty {
    }
    class InferenceAcceleratorsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InferenceAcceleratorsProperty | undefined;
        set internalValue(value: InferenceAcceleratorsProperty | undefined);
        get count(): number;
        get manufacturer(): string;
        get memorySize(): number;
        get name(): string;
    }
    class InferenceAcceleratorsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InferenceAcceleratorsPropertyOutputReference;
    }
    interface InstanceDisksProperty {
    }
    class InstanceDisksPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InstanceDisksProperty | undefined;
        set internalValue(value: InstanceDisksProperty | undefined);
        get count(): number;
        get size(): number;
        get type(): string;
    }
    class InstanceDisksPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InstanceDisksPropertyOutputReference;
    }
    interface MediaAcceleratorsProperty {
    }
    class MediaAcceleratorsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MediaAcceleratorsProperty | undefined;
        set internalValue(value: MediaAcceleratorsProperty | undefined);
        get count(): number;
        get manufacturer(): string;
        get memorySize(): number;
        get name(): string;
    }
    class MediaAcceleratorsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MediaAcceleratorsPropertyOutputReference;
    }
    interface NetworkCardsProperty {
    }
    class NetworkCardsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NetworkCardsProperty | undefined;
        set internalValue(value: NetworkCardsProperty | undefined);
        get baselineBandwidth(): number;
        get index(): number;
        get maximumInterfaces(): number;
        get peakBandwidth(): number;
        get performance(): string;
    }
    class NetworkCardsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NetworkCardsPropertyOutputReference;
    }
    interface NeuronDevicesProperty {
    }
    class NeuronDevicesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NeuronDevicesProperty | undefined;
        set internalValue(value: NeuronDevicesProperty | undefined);
        get coreCount(): number;
        get coreVersion(): number;
        get count(): number;
        get memorySize(): number;
        get name(): string;
    }
    class NeuronDevicesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NeuronDevicesPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_instance_type#read DataTfInstanceType#read}
        */
        readonly read?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _read?;
        get read(): string;
        set read(value: string);
        resetRead(): void;
        get readInput(): string | undefined;
    }
}
