import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfAmiFromInstanceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami_from_instance#deprecation_time TfAmiFromInstance#deprecation_time}
    */
    readonly deprecationTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami_from_instance#description TfAmiFromInstance#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami_from_instance#id TfAmiFromInstance#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami_from_instance#name TfAmiFromInstance#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami_from_instance#region TfAmiFromInstance#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami_from_instance#snapshot_without_reboot TfAmiFromInstance#snapshot_without_reboot}
    */
    readonly snapshotWithoutReboot?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami_from_instance#source_instance_id TfAmiFromInstance#source_instance_id}
    */
    readonly sourceInstanceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami_from_instance#tags TfAmiFromInstance#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami_from_instance#tags_all TfAmiFromInstance#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * ebs_block_device block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami_from_instance#ebs_block_device TfAmiFromInstance#ebs_block_device}
    */
    readonly ebsBlockDevice?: TfAmiFromInstance.EbsBlockDeviceProperty[] | cdktn.IResolvable;
    /**
    * ephemeral_block_device block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami_from_instance#ephemeral_block_device TfAmiFromInstance#ephemeral_block_device}
    */
    readonly ephemeralBlockDevice?: TfAmiFromInstance.EphemeralBlockDeviceProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami_from_instance#timeouts TfAmiFromInstance#timeouts}
    */
    readonly timeouts?: TfAmiFromInstance.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami_from_instance aws_ami_from_instance}
*/
export declare class TfAmiFromInstance extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ami_from_instance";
    /**
    * Generates CDKTN code for importing a TfAmiFromInstance resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfAmiFromInstance to import
    * @param importFromId The id of the existing TfAmiFromInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami_from_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfAmiFromInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami_from_instance aws_ami_from_instance} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfAmiFromInstanceConfig
    */
    constructor(scope: Construct, id: string, config: TfAmiFromInstanceConfig);
    get architecture(): string;
    get arn(): string;
    get bootMode(): string;
    private _deprecationTime?;
    get deprecationTime(): string;
    set deprecationTime(value: string);
    resetDeprecationTime(): void;
    get deprecationTimeInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get enaSupport(): cdktn.IResolvable;
    get hypervisor(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get imageLocation(): string;
    get imageOwnerAlias(): string;
    get imageType(): string;
    get imdsSupport(): string;
    get kernelId(): string;
    get lastLaunchedTime(): string;
    get manageEbsSnapshots(): cdktn.IResolvable;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get ownerId(): string;
    get platform(): string;
    get platformDetails(): string;
    get public(): cdktn.IResolvable;
    get ramdiskId(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get rootDeviceName(): string;
    get rootSnapshotId(): string;
    private _snapshotWithoutReboot?;
    get snapshotWithoutReboot(): boolean | cdktn.IResolvable;
    set snapshotWithoutReboot(value: boolean | cdktn.IResolvable);
    resetSnapshotWithoutReboot(): void;
    get snapshotWithoutRebootInput(): boolean | cdktn.IResolvable | undefined;
    private _sourceInstanceId?;
    get sourceInstanceId(): string;
    set sourceInstanceId(value: string);
    get sourceInstanceIdInput(): string | undefined;
    get sriovNetSupport(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get tpmSupport(): string;
    get uefiData(): string;
    get usageOperation(): string;
    get virtualizationType(): string;
    private _ebsBlockDevice;
    get ebsBlockDevice(): TfAmiFromInstance.EbsBlockDevicePropertyList;
    putEbsBlockDevice(value: TfAmiFromInstance.EbsBlockDeviceProperty[] | cdktn.IResolvable): void;
    resetEbsBlockDevice(): void;
    get ebsBlockDeviceInput(): cdktn.IResolvable | TfAmiFromInstance.EbsBlockDeviceProperty[] | undefined;
    private _ephemeralBlockDevice;
    get ephemeralBlockDevice(): TfAmiFromInstance.EphemeralBlockDevicePropertyList;
    putEphemeralBlockDevice(value: TfAmiFromInstance.EphemeralBlockDeviceProperty[] | cdktn.IResolvable): void;
    resetEphemeralBlockDevice(): void;
    get ephemeralBlockDeviceInput(): cdktn.IResolvable | TfAmiFromInstance.EphemeralBlockDeviceProperty[] | undefined;
    private _timeouts;
    get timeouts(): TfAmiFromInstance.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfAmiFromInstance.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfAmiFromInstance.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfAmiFromInstanceEbsBlockDevicePropertyToTerraform(struct?: TfAmiFromInstance.EbsBlockDeviceProperty | cdktn.IResolvable): any;
export declare function tfAmiFromInstanceEbsBlockDevicePropertyToHclTerraform(struct?: TfAmiFromInstance.EbsBlockDeviceProperty | cdktn.IResolvable): any;
export declare function tfAmiFromInstanceEphemeralBlockDevicePropertyToTerraform(struct?: TfAmiFromInstance.EphemeralBlockDeviceProperty | cdktn.IResolvable): any;
export declare function tfAmiFromInstanceEphemeralBlockDevicePropertyToHclTerraform(struct?: TfAmiFromInstance.EphemeralBlockDeviceProperty | cdktn.IResolvable): any;
export declare function tfAmiFromInstanceTimeoutsPropertyToTerraform(struct?: TfAmiFromInstance.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfAmiFromInstanceTimeoutsPropertyToHclTerraform(struct?: TfAmiFromInstance.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfAmiFromInstance {
    interface EbsBlockDeviceProperty {
    }
    class EbsBlockDevicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EbsBlockDeviceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EbsBlockDeviceProperty | cdktn.IResolvable | undefined);
        get deleteOnTermination(): cdktn.IResolvable;
        get deviceName(): string;
        get encrypted(): cdktn.IResolvable;
        get iops(): number;
        get outpostArn(): string;
        get snapshotId(): string;
        get throughput(): number;
        get volumeSize(): number;
        get volumeType(): string;
    }
    class EbsBlockDevicePropertyList extends cdktn.ComplexList {
        internalValue?: EbsBlockDeviceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EbsBlockDevicePropertyOutputReference;
    }
    interface EphemeralBlockDeviceProperty {
    }
    class EphemeralBlockDevicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EphemeralBlockDeviceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EphemeralBlockDeviceProperty | cdktn.IResolvable | undefined);
        get deviceName(): string;
        get virtualName(): string;
    }
    class EphemeralBlockDevicePropertyList extends cdktn.ComplexList {
        internalValue?: EphemeralBlockDeviceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EphemeralBlockDevicePropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami_from_instance#create TfAmiFromInstance#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami_from_instance#delete TfAmiFromInstance#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ami_from_instance#update TfAmiFromInstance#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
