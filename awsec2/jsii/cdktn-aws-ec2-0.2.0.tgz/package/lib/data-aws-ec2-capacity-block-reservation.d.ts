import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfCapacityBlockReservationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_capacity_block_reservation#id DataTfCapacityBlockReservation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_capacity_block_reservation#region DataTfCapacityBlockReservation#region}
    */
    readonly region?: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_capacity_block_reservation#filter DataTfCapacityBlockReservation#filter}
    */
    readonly filter?: DataTfCapacityBlockReservation.FilterProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_capacity_block_reservation aws_ec2_capacity_block_reservation}
*/
export declare class DataTfCapacityBlockReservation extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_ec2_capacity_block_reservation";
    /**
    * Generates CDKTN code for importing a DataTfCapacityBlockReservation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfCapacityBlockReservation to import
    * @param importFromId The id of the existing DataTfCapacityBlockReservation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_capacity_block_reservation#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfCapacityBlockReservation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_capacity_block_reservation aws_ec2_capacity_block_reservation} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfCapacityBlockReservationConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataTfCapacityBlockReservationConfig);
    get arn(): string;
    get availabilityZone(): string;
    get availabilityZoneId(): string;
    get availableInstanceCount(): number;
    get capacityBlockId(): string;
    private _commitmentInfo;
    get commitmentInfo(): DataTfCapacityBlockReservation.CommitmentInfoPropertyOutputReference;
    get createdDate(): string;
    get deliveryPreference(): string;
    get ebsOptimized(): cdktn.IResolvable;
    get endDate(): string;
    get endDateType(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get instanceCount(): number;
    get instanceMatchCriteria(): string;
    get instancePlatform(): string;
    get instanceType(): string;
    private _interruptibleCapacityAllocation;
    get interruptibleCapacityAllocation(): DataTfCapacityBlockReservation.InterruptibleCapacityAllocationPropertyOutputReference;
    private _interruptionInfo;
    get interruptionInfo(): DataTfCapacityBlockReservation.InterruptionInfoPropertyOutputReference;
    get outpostArn(): string;
    get ownerId(): string;
    get placementGroupArn(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get reservationType(): string;
    get startDate(): string;
    get state(): string;
    private _tags;
    get tags(): cdktn.StringMap;
    get tenancy(): string;
    private _filter;
    get filter(): DataTfCapacityBlockReservation.FilterPropertyList;
    putFilter(value: DataTfCapacityBlockReservation.FilterProperty[] | cdktn.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataTfCapacityBlockReservation.FilterProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfCapacityBlockReservationCommitmentInfoPropertyToTerraform(struct?: DataTfCapacityBlockReservation.CommitmentInfoProperty): any;
export declare function dataTfCapacityBlockReservationCommitmentInfoPropertyToHclTerraform(struct?: DataTfCapacityBlockReservation.CommitmentInfoProperty): any;
export declare function dataTfCapacityBlockReservationInterruptibleCapacityAllocationPropertyToTerraform(struct?: DataTfCapacityBlockReservation.InterruptibleCapacityAllocationProperty): any;
export declare function dataTfCapacityBlockReservationInterruptibleCapacityAllocationPropertyToHclTerraform(struct?: DataTfCapacityBlockReservation.InterruptibleCapacityAllocationProperty): any;
export declare function dataTfCapacityBlockReservationInterruptionInfoPropertyToTerraform(struct?: DataTfCapacityBlockReservation.InterruptionInfoProperty): any;
export declare function dataTfCapacityBlockReservationInterruptionInfoPropertyToHclTerraform(struct?: DataTfCapacityBlockReservation.InterruptionInfoProperty): any;
export declare function dataTfCapacityBlockReservationFilterPropertyToTerraform(struct?: DataTfCapacityBlockReservation.FilterProperty | cdktn.IResolvable): any;
export declare function dataTfCapacityBlockReservationFilterPropertyToHclTerraform(struct?: DataTfCapacityBlockReservation.FilterProperty | cdktn.IResolvable): any;
export declare namespace DataTfCapacityBlockReservation {
    interface CommitmentInfoProperty {
    }
    class CommitmentInfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CommitmentInfoProperty | undefined;
        set internalValue(value: CommitmentInfoProperty | undefined);
        get commitmentEndDate(): string;
        get committedInstanceCount(): number;
    }
    interface InterruptibleCapacityAllocationProperty {
    }
    class InterruptibleCapacityAllocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InterruptibleCapacityAllocationProperty | undefined;
        set internalValue(value: InterruptibleCapacityAllocationProperty | undefined);
        get instanceCount(): number;
        get interruptibleCapacityReservationId(): string;
        get interruptionType(): string;
        get status(): string;
        get targetInstanceCount(): number;
    }
    interface InterruptionInfoProperty {
    }
    class InterruptionInfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InterruptionInfoProperty | undefined;
        set internalValue(value: InterruptionInfoProperty | undefined);
        get interruptionType(): string;
        get sourceCapacityReservationId(): string;
    }
    interface FilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_capacity_block_reservation#name DataTfCapacityBlockReservation#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_capacity_block_reservation#values DataTfCapacityBlockReservation#values}
        */
        readonly values: string[];
    }
    class FilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FilterProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class FilterPropertyList extends cdktn.ComplexList {
        internalValue?: FilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterPropertyOutputReference;
    }
}
