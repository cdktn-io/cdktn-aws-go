import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfLaunchTemplateConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#default_version TfLaunchTemplate#default_version}
    */
    readonly defaultVersion?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#description TfLaunchTemplate#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#disable_api_stop TfLaunchTemplate#disable_api_stop}
    */
    readonly disableApiStop?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#disable_api_termination TfLaunchTemplate#disable_api_termination}
    */
    readonly disableApiTermination?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#ebs_optimized TfLaunchTemplate#ebs_optimized}
    */
    readonly ebsOptimized?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#id TfLaunchTemplate#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#image_id TfLaunchTemplate#image_id}
    */
    readonly imageId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#instance_initiated_shutdown_behavior TfLaunchTemplate#instance_initiated_shutdown_behavior}
    */
    readonly instanceInitiatedShutdownBehavior?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#instance_type TfLaunchTemplate#instance_type}
    */
    readonly instanceType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#kernel_id TfLaunchTemplate#kernel_id}
    */
    readonly kernelId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#key_name TfLaunchTemplate#key_name}
    */
    readonly keyName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#name TfLaunchTemplate#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#name_prefix TfLaunchTemplate#name_prefix}
    */
    readonly namePrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#ram_disk_id TfLaunchTemplate#ram_disk_id}
    */
    readonly ramDiskId?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#region TfLaunchTemplate#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#security_group_names TfLaunchTemplate#security_group_names}
    */
    readonly securityGroupNames?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#tags TfLaunchTemplate#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#tags_all TfLaunchTemplate#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#update_default_version TfLaunchTemplate#update_default_version}
    */
    readonly updateDefaultVersion?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#user_data TfLaunchTemplate#user_data}
    */
    readonly userData?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#vpc_security_group_ids TfLaunchTemplate#vpc_security_group_ids}
    */
    readonly vpcSecurityGroupIds?: string[];
    /**
    * block_device_mappings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#block_device_mappings TfLaunchTemplate#block_device_mappings}
    */
    readonly blockDeviceMappings?: TfLaunchTemplate.BlockDeviceMappingsProperty[] | cdktn.IResolvable;
    /**
    * capacity_reservation_specification block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#capacity_reservation_specification TfLaunchTemplate#capacity_reservation_specification}
    */
    readonly capacityReservationSpecification?: TfLaunchTemplate.CapacityReservationSpecificationProperty;
    /**
    * cpu_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#cpu_options TfLaunchTemplate#cpu_options}
    */
    readonly cpuOptions?: TfLaunchTemplate.CpuOptionsProperty;
    /**
    * credit_specification block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#credit_specification TfLaunchTemplate#credit_specification}
    */
    readonly creditSpecification?: TfLaunchTemplate.CreditSpecificationProperty;
    /**
    * enclave_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#enclave_options TfLaunchTemplate#enclave_options}
    */
    readonly enclaveOptions?: TfLaunchTemplate.EnclaveOptionsProperty;
    /**
    * hibernation_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#hibernation_options TfLaunchTemplate#hibernation_options}
    */
    readonly hibernationOptions?: TfLaunchTemplate.HibernationOptionsProperty;
    /**
    * iam_instance_profile block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#iam_instance_profile TfLaunchTemplate#iam_instance_profile}
    */
    readonly iamInstanceProfile?: TfLaunchTemplate.IamInstanceProfileProperty;
    /**
    * instance_market_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#instance_market_options TfLaunchTemplate#instance_market_options}
    */
    readonly instanceMarketOptions?: TfLaunchTemplate.InstanceMarketOptionsProperty;
    /**
    * instance_requirements block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#instance_requirements TfLaunchTemplate#instance_requirements}
    */
    readonly instanceRequirements?: TfLaunchTemplate.InstanceRequirementsProperty;
    /**
    * license_specification block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#license_specification TfLaunchTemplate#license_specification}
    */
    readonly licenseSpecification?: TfLaunchTemplate.LicenseSpecificationProperty[] | cdktn.IResolvable;
    /**
    * maintenance_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#maintenance_options TfLaunchTemplate#maintenance_options}
    */
    readonly maintenanceOptions?: TfLaunchTemplate.MaintenanceOptionsProperty;
    /**
    * metadata_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#metadata_options TfLaunchTemplate#metadata_options}
    */
    readonly metadataOptions?: TfLaunchTemplate.MetadataOptionsProperty;
    /**
    * monitoring block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#monitoring TfLaunchTemplate#monitoring}
    */
    readonly monitoring?: TfLaunchTemplate.MonitoringProperty;
    /**
    * network_interfaces block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#network_interfaces TfLaunchTemplate#network_interfaces}
    */
    readonly networkInterfaces?: TfLaunchTemplate.NetworkInterfacesProperty[] | cdktn.IResolvable;
    /**
    * network_performance_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#network_performance_options TfLaunchTemplate#network_performance_options}
    */
    readonly networkPerformanceOptions?: TfLaunchTemplate.NetworkPerformanceOptionsProperty;
    /**
    * placement block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#placement TfLaunchTemplate#placement}
    */
    readonly placement?: TfLaunchTemplate.PlacementProperty;
    /**
    * private_dns_name_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#private_dns_name_options TfLaunchTemplate#private_dns_name_options}
    */
    readonly privateDnsNameOptions?: TfLaunchTemplate.PrivateDnsNameOptionsProperty;
    /**
    * secondary_interfaces block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#secondary_interfaces TfLaunchTemplate#secondary_interfaces}
    */
    readonly secondaryInterfaces?: TfLaunchTemplate.SecondaryInterfacesProperty[] | cdktn.IResolvable;
    /**
    * tag_specifications block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#tag_specifications TfLaunchTemplate#tag_specifications}
    */
    readonly tagSpecifications?: TfLaunchTemplate.TagSpecificationsProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template aws_launch_template}
*/
export declare class TfLaunchTemplate extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_launch_template";
    /**
    * Generates CDKTN code for importing a TfLaunchTemplate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfLaunchTemplate to import
    * @param importFromId The id of the existing TfLaunchTemplate that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfLaunchTemplate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template aws_launch_template} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfLaunchTemplateConfig = {}
    */
    constructor(scope: Construct, id: string, config?: TfLaunchTemplateConfig);
    get arn(): string;
    private _defaultVersion?;
    get defaultVersion(): number;
    set defaultVersion(value: number);
    resetDefaultVersion(): void;
    get defaultVersionInput(): number | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _disableApiStop?;
    get disableApiStop(): boolean | cdktn.IResolvable;
    set disableApiStop(value: boolean | cdktn.IResolvable);
    resetDisableApiStop(): void;
    get disableApiStopInput(): boolean | cdktn.IResolvable | undefined;
    private _disableApiTermination?;
    get disableApiTermination(): boolean | cdktn.IResolvable;
    set disableApiTermination(value: boolean | cdktn.IResolvable);
    resetDisableApiTermination(): void;
    get disableApiTerminationInput(): boolean | cdktn.IResolvable | undefined;
    private _ebsOptimized?;
    get ebsOptimized(): string;
    set ebsOptimized(value: string);
    resetEbsOptimized(): void;
    get ebsOptimizedInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _imageId?;
    get imageId(): string;
    set imageId(value: string);
    resetImageId(): void;
    get imageIdInput(): string | undefined;
    private _instanceInitiatedShutdownBehavior?;
    get instanceInitiatedShutdownBehavior(): string;
    set instanceInitiatedShutdownBehavior(value: string);
    resetInstanceInitiatedShutdownBehavior(): void;
    get instanceInitiatedShutdownBehaviorInput(): string | undefined;
    private _instanceType?;
    get instanceType(): string;
    set instanceType(value: string);
    resetInstanceType(): void;
    get instanceTypeInput(): string | undefined;
    private _kernelId?;
    get kernelId(): string;
    set kernelId(value: string);
    resetKernelId(): void;
    get kernelIdInput(): string | undefined;
    private _keyName?;
    get keyName(): string;
    set keyName(value: string);
    resetKeyName(): void;
    get keyNameInput(): string | undefined;
    get latestVersion(): number;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namePrefix?;
    get namePrefix(): string;
    set namePrefix(value: string);
    resetNamePrefix(): void;
    get namePrefixInput(): string | undefined;
    private _ramDiskId?;
    get ramDiskId(): string;
    set ramDiskId(value: string);
    resetRamDiskId(): void;
    get ramDiskIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _securityGroupNames?;
    get securityGroupNames(): string[];
    set securityGroupNames(value: string[]);
    resetSecurityGroupNames(): void;
    get securityGroupNamesInput(): string[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _updateDefaultVersion?;
    get updateDefaultVersion(): boolean | cdktn.IResolvable;
    set updateDefaultVersion(value: boolean | cdktn.IResolvable);
    resetUpdateDefaultVersion(): void;
    get updateDefaultVersionInput(): boolean | cdktn.IResolvable | undefined;
    private _userData?;
    get userData(): string;
    set userData(value: string);
    resetUserData(): void;
    get userDataInput(): string | undefined;
    private _vpcSecurityGroupIds?;
    get vpcSecurityGroupIds(): string[];
    set vpcSecurityGroupIds(value: string[]);
    resetVpcSecurityGroupIds(): void;
    get vpcSecurityGroupIdsInput(): string[] | undefined;
    private _blockDeviceMappings;
    get blockDeviceMappings(): TfLaunchTemplate.BlockDeviceMappingsPropertyList;
    putBlockDeviceMappings(value: TfLaunchTemplate.BlockDeviceMappingsProperty[] | cdktn.IResolvable): void;
    resetBlockDeviceMappings(): void;
    get blockDeviceMappingsInput(): cdktn.IResolvable | TfLaunchTemplate.BlockDeviceMappingsProperty[] | undefined;
    private _capacityReservationSpecification;
    get capacityReservationSpecification(): TfLaunchTemplate.CapacityReservationSpecificationPropertyOutputReference;
    putCapacityReservationSpecification(value: TfLaunchTemplate.CapacityReservationSpecificationProperty): void;
    resetCapacityReservationSpecification(): void;
    get capacityReservationSpecificationInput(): TfLaunchTemplate.CapacityReservationSpecificationProperty | undefined;
    private _cpuOptions;
    get cpuOptions(): TfLaunchTemplate.CpuOptionsPropertyOutputReference;
    putCpuOptions(value: TfLaunchTemplate.CpuOptionsProperty): void;
    resetCpuOptions(): void;
    get cpuOptionsInput(): TfLaunchTemplate.CpuOptionsProperty | undefined;
    private _creditSpecification;
    get creditSpecification(): TfLaunchTemplate.CreditSpecificationPropertyOutputReference;
    putCreditSpecification(value: TfLaunchTemplate.CreditSpecificationProperty): void;
    resetCreditSpecification(): void;
    get creditSpecificationInput(): TfLaunchTemplate.CreditSpecificationProperty | undefined;
    private _enclaveOptions;
    get enclaveOptions(): TfLaunchTemplate.EnclaveOptionsPropertyOutputReference;
    putEnclaveOptions(value: TfLaunchTemplate.EnclaveOptionsProperty): void;
    resetEnclaveOptions(): void;
    get enclaveOptionsInput(): TfLaunchTemplate.EnclaveOptionsProperty | undefined;
    private _hibernationOptions;
    get hibernationOptions(): TfLaunchTemplate.HibernationOptionsPropertyOutputReference;
    putHibernationOptions(value: TfLaunchTemplate.HibernationOptionsProperty): void;
    resetHibernationOptions(): void;
    get hibernationOptionsInput(): TfLaunchTemplate.HibernationOptionsProperty | undefined;
    private _iamInstanceProfile;
    get iamInstanceProfile(): TfLaunchTemplate.IamInstanceProfilePropertyOutputReference;
    putIamInstanceProfile(value: TfLaunchTemplate.IamInstanceProfileProperty): void;
    resetIamInstanceProfile(): void;
    get iamInstanceProfileInput(): TfLaunchTemplate.IamInstanceProfileProperty | undefined;
    private _instanceMarketOptions;
    get instanceMarketOptions(): TfLaunchTemplate.InstanceMarketOptionsPropertyOutputReference;
    putInstanceMarketOptions(value: TfLaunchTemplate.InstanceMarketOptionsProperty): void;
    resetInstanceMarketOptions(): void;
    get instanceMarketOptionsInput(): TfLaunchTemplate.InstanceMarketOptionsProperty | undefined;
    private _instanceRequirements;
    get instanceRequirements(): TfLaunchTemplate.InstanceRequirementsPropertyOutputReference;
    putInstanceRequirements(value: TfLaunchTemplate.InstanceRequirementsProperty): void;
    resetInstanceRequirements(): void;
    get instanceRequirementsInput(): TfLaunchTemplate.InstanceRequirementsProperty | undefined;
    private _licenseSpecification;
    get licenseSpecification(): TfLaunchTemplate.LicenseSpecificationPropertyList;
    putLicenseSpecification(value: TfLaunchTemplate.LicenseSpecificationProperty[] | cdktn.IResolvable): void;
    resetLicenseSpecification(): void;
    get licenseSpecificationInput(): cdktn.IResolvable | TfLaunchTemplate.LicenseSpecificationProperty[] | undefined;
    private _maintenanceOptions;
    get maintenanceOptions(): TfLaunchTemplate.MaintenanceOptionsPropertyOutputReference;
    putMaintenanceOptions(value: TfLaunchTemplate.MaintenanceOptionsProperty): void;
    resetMaintenanceOptions(): void;
    get maintenanceOptionsInput(): TfLaunchTemplate.MaintenanceOptionsProperty | undefined;
    private _metadataOptions;
    get metadataOptions(): TfLaunchTemplate.MetadataOptionsPropertyOutputReference;
    putMetadataOptions(value: TfLaunchTemplate.MetadataOptionsProperty): void;
    resetMetadataOptions(): void;
    get metadataOptionsInput(): TfLaunchTemplate.MetadataOptionsProperty | undefined;
    private _monitoring;
    get monitoring(): TfLaunchTemplate.MonitoringPropertyOutputReference;
    putMonitoring(value: TfLaunchTemplate.MonitoringProperty): void;
    resetMonitoring(): void;
    get monitoringInput(): TfLaunchTemplate.MonitoringProperty | undefined;
    private _networkInterfaces;
    get networkInterfaces(): TfLaunchTemplate.NetworkInterfacesPropertyList;
    putNetworkInterfaces(value: TfLaunchTemplate.NetworkInterfacesProperty[] | cdktn.IResolvable): void;
    resetNetworkInterfaces(): void;
    get networkInterfacesInput(): cdktn.IResolvable | TfLaunchTemplate.NetworkInterfacesProperty[] | undefined;
    private _networkPerformanceOptions;
    get networkPerformanceOptions(): TfLaunchTemplate.NetworkPerformanceOptionsPropertyOutputReference;
    putNetworkPerformanceOptions(value: TfLaunchTemplate.NetworkPerformanceOptionsProperty): void;
    resetNetworkPerformanceOptions(): void;
    get networkPerformanceOptionsInput(): TfLaunchTemplate.NetworkPerformanceOptionsProperty | undefined;
    private _placement;
    get placement(): TfLaunchTemplate.PlacementPropertyOutputReference;
    putPlacement(value: TfLaunchTemplate.PlacementProperty): void;
    resetPlacement(): void;
    get placementInput(): TfLaunchTemplate.PlacementProperty | undefined;
    private _privateDnsNameOptions;
    get privateDnsNameOptions(): TfLaunchTemplate.PrivateDnsNameOptionsPropertyOutputReference;
    putPrivateDnsNameOptions(value: TfLaunchTemplate.PrivateDnsNameOptionsProperty): void;
    resetPrivateDnsNameOptions(): void;
    get privateDnsNameOptionsInput(): TfLaunchTemplate.PrivateDnsNameOptionsProperty | undefined;
    private _secondaryInterfaces;
    get secondaryInterfaces(): TfLaunchTemplate.SecondaryInterfacesPropertyList;
    putSecondaryInterfaces(value: TfLaunchTemplate.SecondaryInterfacesProperty[] | cdktn.IResolvable): void;
    resetSecondaryInterfaces(): void;
    get secondaryInterfacesInput(): cdktn.IResolvable | TfLaunchTemplate.SecondaryInterfacesProperty[] | undefined;
    private _tagSpecifications;
    get tagSpecifications(): TfLaunchTemplate.TagSpecificationsPropertyList;
    putTagSpecifications(value: TfLaunchTemplate.TagSpecificationsProperty[] | cdktn.IResolvable): void;
    resetTagSpecifications(): void;
    get tagSpecificationsInput(): cdktn.IResolvable | TfLaunchTemplate.TagSpecificationsProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfLaunchTemplateEbsPropertyToTerraform(struct?: TfLaunchTemplate.EbsPropertyOutputReference | TfLaunchTemplate.EbsProperty): any;
export declare function tfLaunchTemplateEbsPropertyToHclTerraform(struct?: TfLaunchTemplate.EbsPropertyOutputReference | TfLaunchTemplate.EbsProperty): any;
export declare function tfLaunchTemplateBlockDeviceMappingsPropertyToTerraform(struct?: TfLaunchTemplate.BlockDeviceMappingsProperty | cdktn.IResolvable): any;
export declare function tfLaunchTemplateBlockDeviceMappingsPropertyToHclTerraform(struct?: TfLaunchTemplate.BlockDeviceMappingsProperty | cdktn.IResolvable): any;
export declare function tfLaunchTemplateCapacityReservationTargetPropertyToTerraform(struct?: TfLaunchTemplate.CapacityReservationTargetPropertyOutputReference | TfLaunchTemplate.CapacityReservationTargetProperty): any;
export declare function tfLaunchTemplateCapacityReservationTargetPropertyToHclTerraform(struct?: TfLaunchTemplate.CapacityReservationTargetPropertyOutputReference | TfLaunchTemplate.CapacityReservationTargetProperty): any;
export declare function tfLaunchTemplateCapacityReservationSpecificationPropertyToTerraform(struct?: TfLaunchTemplate.CapacityReservationSpecificationPropertyOutputReference | TfLaunchTemplate.CapacityReservationSpecificationProperty): any;
export declare function tfLaunchTemplateCapacityReservationSpecificationPropertyToHclTerraform(struct?: TfLaunchTemplate.CapacityReservationSpecificationPropertyOutputReference | TfLaunchTemplate.CapacityReservationSpecificationProperty): any;
export declare function tfLaunchTemplateCpuOptionsPropertyToTerraform(struct?: TfLaunchTemplate.CpuOptionsPropertyOutputReference | TfLaunchTemplate.CpuOptionsProperty): any;
export declare function tfLaunchTemplateCpuOptionsPropertyToHclTerraform(struct?: TfLaunchTemplate.CpuOptionsPropertyOutputReference | TfLaunchTemplate.CpuOptionsProperty): any;
export declare function tfLaunchTemplateCreditSpecificationPropertyToTerraform(struct?: TfLaunchTemplate.CreditSpecificationPropertyOutputReference | TfLaunchTemplate.CreditSpecificationProperty): any;
export declare function tfLaunchTemplateCreditSpecificationPropertyToHclTerraform(struct?: TfLaunchTemplate.CreditSpecificationPropertyOutputReference | TfLaunchTemplate.CreditSpecificationProperty): any;
export declare function tfLaunchTemplateEnclaveOptionsPropertyToTerraform(struct?: TfLaunchTemplate.EnclaveOptionsPropertyOutputReference | TfLaunchTemplate.EnclaveOptionsProperty): any;
export declare function tfLaunchTemplateEnclaveOptionsPropertyToHclTerraform(struct?: TfLaunchTemplate.EnclaveOptionsPropertyOutputReference | TfLaunchTemplate.EnclaveOptionsProperty): any;
export declare function tfLaunchTemplateHibernationOptionsPropertyToTerraform(struct?: TfLaunchTemplate.HibernationOptionsPropertyOutputReference | TfLaunchTemplate.HibernationOptionsProperty): any;
export declare function tfLaunchTemplateHibernationOptionsPropertyToHclTerraform(struct?: TfLaunchTemplate.HibernationOptionsPropertyOutputReference | TfLaunchTemplate.HibernationOptionsProperty): any;
export declare function tfLaunchTemplateIamInstanceProfilePropertyToTerraform(struct?: TfLaunchTemplate.IamInstanceProfilePropertyOutputReference | TfLaunchTemplate.IamInstanceProfileProperty): any;
export declare function tfLaunchTemplateIamInstanceProfilePropertyToHclTerraform(struct?: TfLaunchTemplate.IamInstanceProfilePropertyOutputReference | TfLaunchTemplate.IamInstanceProfileProperty): any;
export declare function tfLaunchTemplateSpotOptionsPropertyToTerraform(struct?: TfLaunchTemplate.SpotOptionsPropertyOutputReference | TfLaunchTemplate.SpotOptionsProperty): any;
export declare function tfLaunchTemplateSpotOptionsPropertyToHclTerraform(struct?: TfLaunchTemplate.SpotOptionsPropertyOutputReference | TfLaunchTemplate.SpotOptionsProperty): any;
export declare function tfLaunchTemplateInstanceMarketOptionsPropertyToTerraform(struct?: TfLaunchTemplate.InstanceMarketOptionsPropertyOutputReference | TfLaunchTemplate.InstanceMarketOptionsProperty): any;
export declare function tfLaunchTemplateInstanceMarketOptionsPropertyToHclTerraform(struct?: TfLaunchTemplate.InstanceMarketOptionsPropertyOutputReference | TfLaunchTemplate.InstanceMarketOptionsProperty): any;
export declare function tfLaunchTemplateAcceleratorCountPropertyToTerraform(struct?: TfLaunchTemplate.AcceleratorCountPropertyOutputReference | TfLaunchTemplate.AcceleratorCountProperty): any;
export declare function tfLaunchTemplateAcceleratorCountPropertyToHclTerraform(struct?: TfLaunchTemplate.AcceleratorCountPropertyOutputReference | TfLaunchTemplate.AcceleratorCountProperty): any;
export declare function tfLaunchTemplateAcceleratorTotalMemoryMibPropertyToTerraform(struct?: TfLaunchTemplate.AcceleratorTotalMemoryMibPropertyOutputReference | TfLaunchTemplate.AcceleratorTotalMemoryMibProperty): any;
export declare function tfLaunchTemplateAcceleratorTotalMemoryMibPropertyToHclTerraform(struct?: TfLaunchTemplate.AcceleratorTotalMemoryMibPropertyOutputReference | TfLaunchTemplate.AcceleratorTotalMemoryMibProperty): any;
export declare function tfLaunchTemplateBaselineEbsBandwidthMbpsPropertyToTerraform(struct?: TfLaunchTemplate.BaselineEbsBandwidthMbpsPropertyOutputReference | TfLaunchTemplate.BaselineEbsBandwidthMbpsProperty): any;
export declare function tfLaunchTemplateBaselineEbsBandwidthMbpsPropertyToHclTerraform(struct?: TfLaunchTemplate.BaselineEbsBandwidthMbpsPropertyOutputReference | TfLaunchTemplate.BaselineEbsBandwidthMbpsProperty): any;
export declare function tfLaunchTemplateMemoryGibPerVcpuPropertyToTerraform(struct?: TfLaunchTemplate.MemoryGibPerVcpuPropertyOutputReference | TfLaunchTemplate.MemoryGibPerVcpuProperty): any;
export declare function tfLaunchTemplateMemoryGibPerVcpuPropertyToHclTerraform(struct?: TfLaunchTemplate.MemoryGibPerVcpuPropertyOutputReference | TfLaunchTemplate.MemoryGibPerVcpuProperty): any;
export declare function tfLaunchTemplateMemoryMibPropertyToTerraform(struct?: TfLaunchTemplate.MemoryMibPropertyOutputReference | TfLaunchTemplate.MemoryMibProperty): any;
export declare function tfLaunchTemplateMemoryMibPropertyToHclTerraform(struct?: TfLaunchTemplate.MemoryMibPropertyOutputReference | TfLaunchTemplate.MemoryMibProperty): any;
export declare function tfLaunchTemplateNetworkBandwidthGbpsPropertyToTerraform(struct?: TfLaunchTemplate.NetworkBandwidthGbpsPropertyOutputReference | TfLaunchTemplate.NetworkBandwidthGbpsProperty): any;
export declare function tfLaunchTemplateNetworkBandwidthGbpsPropertyToHclTerraform(struct?: TfLaunchTemplate.NetworkBandwidthGbpsPropertyOutputReference | TfLaunchTemplate.NetworkBandwidthGbpsProperty): any;
export declare function tfLaunchTemplateNetworkInterfaceCountPropertyToTerraform(struct?: TfLaunchTemplate.NetworkInterfaceCountPropertyOutputReference | TfLaunchTemplate.NetworkInterfaceCountProperty): any;
export declare function tfLaunchTemplateNetworkInterfaceCountPropertyToHclTerraform(struct?: TfLaunchTemplate.NetworkInterfaceCountPropertyOutputReference | TfLaunchTemplate.NetworkInterfaceCountProperty): any;
export declare function tfLaunchTemplateTotalLocalStorageGbPropertyToTerraform(struct?: TfLaunchTemplate.TotalLocalStorageGbPropertyOutputReference | TfLaunchTemplate.TotalLocalStorageGbProperty): any;
export declare function tfLaunchTemplateTotalLocalStorageGbPropertyToHclTerraform(struct?: TfLaunchTemplate.TotalLocalStorageGbPropertyOutputReference | TfLaunchTemplate.TotalLocalStorageGbProperty): any;
export declare function tfLaunchTemplateVcpuCountPropertyToTerraform(struct?: TfLaunchTemplate.VcpuCountPropertyOutputReference | TfLaunchTemplate.VcpuCountProperty): any;
export declare function tfLaunchTemplateVcpuCountPropertyToHclTerraform(struct?: TfLaunchTemplate.VcpuCountPropertyOutputReference | TfLaunchTemplate.VcpuCountProperty): any;
export declare function tfLaunchTemplateInstanceRequirementsPropertyToTerraform(struct?: TfLaunchTemplate.InstanceRequirementsPropertyOutputReference | TfLaunchTemplate.InstanceRequirementsProperty): any;
export declare function tfLaunchTemplateInstanceRequirementsPropertyToHclTerraform(struct?: TfLaunchTemplate.InstanceRequirementsPropertyOutputReference | TfLaunchTemplate.InstanceRequirementsProperty): any;
export declare function tfLaunchTemplateLicenseSpecificationPropertyToTerraform(struct?: TfLaunchTemplate.LicenseSpecificationProperty | cdktn.IResolvable): any;
export declare function tfLaunchTemplateLicenseSpecificationPropertyToHclTerraform(struct?: TfLaunchTemplate.LicenseSpecificationProperty | cdktn.IResolvable): any;
export declare function tfLaunchTemplateMaintenanceOptionsPropertyToTerraform(struct?: TfLaunchTemplate.MaintenanceOptionsPropertyOutputReference | TfLaunchTemplate.MaintenanceOptionsProperty): any;
export declare function tfLaunchTemplateMaintenanceOptionsPropertyToHclTerraform(struct?: TfLaunchTemplate.MaintenanceOptionsPropertyOutputReference | TfLaunchTemplate.MaintenanceOptionsProperty): any;
export declare function tfLaunchTemplateMetadataOptionsPropertyToTerraform(struct?: TfLaunchTemplate.MetadataOptionsPropertyOutputReference | TfLaunchTemplate.MetadataOptionsProperty): any;
export declare function tfLaunchTemplateMetadataOptionsPropertyToHclTerraform(struct?: TfLaunchTemplate.MetadataOptionsPropertyOutputReference | TfLaunchTemplate.MetadataOptionsProperty): any;
export declare function tfLaunchTemplateMonitoringPropertyToTerraform(struct?: TfLaunchTemplate.MonitoringPropertyOutputReference | TfLaunchTemplate.MonitoringProperty): any;
export declare function tfLaunchTemplateMonitoringPropertyToHclTerraform(struct?: TfLaunchTemplate.MonitoringPropertyOutputReference | TfLaunchTemplate.MonitoringProperty): any;
export declare function tfLaunchTemplateConnectionTrackingSpecificationPropertyToTerraform(struct?: TfLaunchTemplate.ConnectionTrackingSpecificationPropertyOutputReference | TfLaunchTemplate.ConnectionTrackingSpecificationProperty): any;
export declare function tfLaunchTemplateConnectionTrackingSpecificationPropertyToHclTerraform(struct?: TfLaunchTemplate.ConnectionTrackingSpecificationPropertyOutputReference | TfLaunchTemplate.ConnectionTrackingSpecificationProperty): any;
export declare function tfLaunchTemplateEnaSrdUdpSpecificationPropertyToTerraform(struct?: TfLaunchTemplate.EnaSrdUdpSpecificationPropertyOutputReference | TfLaunchTemplate.EnaSrdUdpSpecificationProperty): any;
export declare function tfLaunchTemplateEnaSrdUdpSpecificationPropertyToHclTerraform(struct?: TfLaunchTemplate.EnaSrdUdpSpecificationPropertyOutputReference | TfLaunchTemplate.EnaSrdUdpSpecificationProperty): any;
export declare function tfLaunchTemplateEnaSrdSpecificationPropertyToTerraform(struct?: TfLaunchTemplate.EnaSrdSpecificationPropertyOutputReference | TfLaunchTemplate.EnaSrdSpecificationProperty): any;
export declare function tfLaunchTemplateEnaSrdSpecificationPropertyToHclTerraform(struct?: TfLaunchTemplate.EnaSrdSpecificationPropertyOutputReference | TfLaunchTemplate.EnaSrdSpecificationProperty): any;
export declare function tfLaunchTemplateNetworkInterfacesPropertyToTerraform(struct?: TfLaunchTemplate.NetworkInterfacesProperty | cdktn.IResolvable): any;
export declare function tfLaunchTemplateNetworkInterfacesPropertyToHclTerraform(struct?: TfLaunchTemplate.NetworkInterfacesProperty | cdktn.IResolvable): any;
export declare function tfLaunchTemplateNetworkPerformanceOptionsPropertyToTerraform(struct?: TfLaunchTemplate.NetworkPerformanceOptionsPropertyOutputReference | TfLaunchTemplate.NetworkPerformanceOptionsProperty): any;
export declare function tfLaunchTemplateNetworkPerformanceOptionsPropertyToHclTerraform(struct?: TfLaunchTemplate.NetworkPerformanceOptionsPropertyOutputReference | TfLaunchTemplate.NetworkPerformanceOptionsProperty): any;
export declare function tfLaunchTemplatePlacementPropertyToTerraform(struct?: TfLaunchTemplate.PlacementPropertyOutputReference | TfLaunchTemplate.PlacementProperty): any;
export declare function tfLaunchTemplatePlacementPropertyToHclTerraform(struct?: TfLaunchTemplate.PlacementPropertyOutputReference | TfLaunchTemplate.PlacementProperty): any;
export declare function tfLaunchTemplatePrivateDnsNameOptionsPropertyToTerraform(struct?: TfLaunchTemplate.PrivateDnsNameOptionsPropertyOutputReference | TfLaunchTemplate.PrivateDnsNameOptionsProperty): any;
export declare function tfLaunchTemplatePrivateDnsNameOptionsPropertyToHclTerraform(struct?: TfLaunchTemplate.PrivateDnsNameOptionsPropertyOutputReference | TfLaunchTemplate.PrivateDnsNameOptionsProperty): any;
export declare function tfLaunchTemplateSecondaryInterfacesPropertyToTerraform(struct?: TfLaunchTemplate.SecondaryInterfacesProperty | cdktn.IResolvable): any;
export declare function tfLaunchTemplateSecondaryInterfacesPropertyToHclTerraform(struct?: TfLaunchTemplate.SecondaryInterfacesProperty | cdktn.IResolvable): any;
export declare function tfLaunchTemplateTagSpecificationsPropertyToTerraform(struct?: TfLaunchTemplate.TagSpecificationsProperty | cdktn.IResolvable): any;
export declare function tfLaunchTemplateTagSpecificationsPropertyToHclTerraform(struct?: TfLaunchTemplate.TagSpecificationsProperty | cdktn.IResolvable): any;
export declare namespace TfLaunchTemplate {
    interface EbsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#delete_on_termination TfLaunchTemplate#delete_on_termination}
        */
        readonly deleteOnTermination?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#encrypted TfLaunchTemplate#encrypted}
        */
        readonly encrypted?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#iops TfLaunchTemplate#iops}
        */
        readonly iops?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#kms_key_id TfLaunchTemplate#kms_key_id}
        */
        readonly kmsKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#snapshot_id TfLaunchTemplate#snapshot_id}
        */
        readonly snapshotId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#throughput TfLaunchTemplate#throughput}
        */
        readonly throughput?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#volume_initialization_rate TfLaunchTemplate#volume_initialization_rate}
        */
        readonly volumeInitializationRate?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#volume_size TfLaunchTemplate#volume_size}
        */
        readonly volumeSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#volume_type TfLaunchTemplate#volume_type}
        */
        readonly volumeType?: string;
    }
    class EbsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EbsProperty | undefined;
        set internalValue(value: EbsProperty | undefined);
        private _deleteOnTermination?;
        get deleteOnTermination(): string;
        set deleteOnTermination(value: string);
        resetDeleteOnTermination(): void;
        get deleteOnTerminationInput(): string | undefined;
        private _encrypted?;
        get encrypted(): string;
        set encrypted(value: string);
        resetEncrypted(): void;
        get encryptedInput(): string | undefined;
        private _iops?;
        get iops(): number;
        set iops(value: number);
        resetIops(): void;
        get iopsInput(): number | undefined;
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        resetKmsKeyId(): void;
        get kmsKeyIdInput(): string | undefined;
        private _snapshotId?;
        get snapshotId(): string;
        set snapshotId(value: string);
        resetSnapshotId(): void;
        get snapshotIdInput(): string | undefined;
        private _throughput?;
        get throughput(): number;
        set throughput(value: number);
        resetThroughput(): void;
        get throughputInput(): number | undefined;
        private _volumeInitializationRate?;
        get volumeInitializationRate(): number;
        set volumeInitializationRate(value: number);
        resetVolumeInitializationRate(): void;
        get volumeInitializationRateInput(): number | undefined;
        private _volumeSize?;
        get volumeSize(): number;
        set volumeSize(value: number);
        resetVolumeSize(): void;
        get volumeSizeInput(): number | undefined;
        private _volumeType?;
        get volumeType(): string;
        set volumeType(value: string);
        resetVolumeType(): void;
        get volumeTypeInput(): string | undefined;
    }
    interface BlockDeviceMappingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#device_name TfLaunchTemplate#device_name}
        */
        readonly deviceName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#no_device TfLaunchTemplate#no_device}
        */
        readonly noDevice?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#virtual_name TfLaunchTemplate#virtual_name}
        */
        readonly virtualName?: string;
        /**
        * ebs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#ebs TfLaunchTemplate#ebs}
        */
        readonly ebs?: EbsProperty;
    }
    class BlockDeviceMappingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BlockDeviceMappingsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: BlockDeviceMappingsProperty | cdktn.IResolvable | undefined);
        private _deviceName?;
        get deviceName(): string;
        set deviceName(value: string);
        resetDeviceName(): void;
        get deviceNameInput(): string | undefined;
        private _noDevice?;
        get noDevice(): string;
        set noDevice(value: string);
        resetNoDevice(): void;
        get noDeviceInput(): string | undefined;
        private _virtualName?;
        get virtualName(): string;
        set virtualName(value: string);
        resetVirtualName(): void;
        get virtualNameInput(): string | undefined;
        private _ebs;
        get ebs(): EbsPropertyOutputReference;
        putEbs(value: EbsProperty): void;
        resetEbs(): void;
        get ebsInput(): EbsProperty | undefined;
    }
    class BlockDeviceMappingsPropertyList extends cdktn.ComplexList {
        internalValue?: BlockDeviceMappingsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BlockDeviceMappingsPropertyOutputReference;
    }
    interface CapacityReservationTargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#capacity_reservation_id TfLaunchTemplate#capacity_reservation_id}
        */
        readonly capacityReservationId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#capacity_reservation_resource_group_arn TfLaunchTemplate#capacity_reservation_resource_group_arn}
        */
        readonly capacityReservationResourceGroupArn?: string;
    }
    class CapacityReservationTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CapacityReservationTargetProperty | undefined;
        set internalValue(value: CapacityReservationTargetProperty | undefined);
        private _capacityReservationId?;
        get capacityReservationId(): string;
        set capacityReservationId(value: string);
        resetCapacityReservationId(): void;
        get capacityReservationIdInput(): string | undefined;
        private _capacityReservationResourceGroupArn?;
        get capacityReservationResourceGroupArn(): string;
        set capacityReservationResourceGroupArn(value: string);
        resetCapacityReservationResourceGroupArn(): void;
        get capacityReservationResourceGroupArnInput(): string | undefined;
    }
    interface CapacityReservationSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#capacity_reservation_preference TfLaunchTemplate#capacity_reservation_preference}
        */
        readonly capacityReservationPreference?: string;
        /**
        * capacity_reservation_target block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#capacity_reservation_target TfLaunchTemplate#capacity_reservation_target}
        */
        readonly capacityReservationTarget?: CapacityReservationTargetProperty;
    }
    class CapacityReservationSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CapacityReservationSpecificationProperty | undefined;
        set internalValue(value: CapacityReservationSpecificationProperty | undefined);
        private _capacityReservationPreference?;
        get capacityReservationPreference(): string;
        set capacityReservationPreference(value: string);
        resetCapacityReservationPreference(): void;
        get capacityReservationPreferenceInput(): string | undefined;
        private _capacityReservationTarget;
        get capacityReservationTarget(): CapacityReservationTargetPropertyOutputReference;
        putCapacityReservationTarget(value: CapacityReservationTargetProperty): void;
        resetCapacityReservationTarget(): void;
        get capacityReservationTargetInput(): CapacityReservationTargetProperty | undefined;
    }
    interface CpuOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#amd_sev_snp TfLaunchTemplate#amd_sev_snp}
        */
        readonly amdSevSnp?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#core_count TfLaunchTemplate#core_count}
        */
        readonly coreCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#nested_virtualization TfLaunchTemplate#nested_virtualization}
        */
        readonly nestedVirtualization?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#threads_per_core TfLaunchTemplate#threads_per_core}
        */
        readonly threadsPerCore?: number;
    }
    class CpuOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CpuOptionsProperty | undefined;
        set internalValue(value: CpuOptionsProperty | undefined);
        private _amdSevSnp?;
        get amdSevSnp(): string;
        set amdSevSnp(value: string);
        resetAmdSevSnp(): void;
        get amdSevSnpInput(): string | undefined;
        private _coreCount?;
        get coreCount(): number;
        set coreCount(value: number);
        resetCoreCount(): void;
        get coreCountInput(): number | undefined;
        private _nestedVirtualization?;
        get nestedVirtualization(): string;
        set nestedVirtualization(value: string);
        resetNestedVirtualization(): void;
        get nestedVirtualizationInput(): string | undefined;
        private _threadsPerCore?;
        get threadsPerCore(): number;
        set threadsPerCore(value: number);
        resetThreadsPerCore(): void;
        get threadsPerCoreInput(): number | undefined;
    }
    interface CreditSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#cpu_credits TfLaunchTemplate#cpu_credits}
        */
        readonly cpuCredits?: string;
    }
    class CreditSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CreditSpecificationProperty | undefined;
        set internalValue(value: CreditSpecificationProperty | undefined);
        private _cpuCredits?;
        get cpuCredits(): string;
        set cpuCredits(value: string);
        resetCpuCredits(): void;
        get cpuCreditsInput(): string | undefined;
    }
    interface EnclaveOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#enabled TfLaunchTemplate#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
    }
    class EnclaveOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EnclaveOptionsProperty | undefined;
        set internalValue(value: EnclaveOptionsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface HibernationOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#configured TfLaunchTemplate#configured}
        */
        readonly configured: boolean | cdktn.IResolvable;
    }
    class HibernationOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HibernationOptionsProperty | undefined;
        set internalValue(value: HibernationOptionsProperty | undefined);
        private _configured?;
        get configured(): boolean | cdktn.IResolvable;
        set configured(value: boolean | cdktn.IResolvable);
        get configuredInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface IamInstanceProfileProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#arn TfLaunchTemplate#arn}
        */
        readonly arn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#name TfLaunchTemplate#name}
        */
        readonly name?: string;
    }
    class IamInstanceProfilePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IamInstanceProfileProperty | undefined;
        set internalValue(value: IamInstanceProfileProperty | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        resetArn(): void;
        get arnInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
    }
    interface SpotOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#block_duration_minutes TfLaunchTemplate#block_duration_minutes}
        */
        readonly blockDurationMinutes?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#instance_interruption_behavior TfLaunchTemplate#instance_interruption_behavior}
        */
        readonly instanceInterruptionBehavior?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#max_price TfLaunchTemplate#max_price}
        */
        readonly maxPrice?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#spot_instance_type TfLaunchTemplate#spot_instance_type}
        */
        readonly spotInstanceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#valid_until TfLaunchTemplate#valid_until}
        */
        readonly validUntil?: string;
    }
    class SpotOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpotOptionsProperty | undefined;
        set internalValue(value: SpotOptionsProperty | undefined);
        private _blockDurationMinutes?;
        get blockDurationMinutes(): number;
        set blockDurationMinutes(value: number);
        resetBlockDurationMinutes(): void;
        get blockDurationMinutesInput(): number | undefined;
        private _instanceInterruptionBehavior?;
        get instanceInterruptionBehavior(): string;
        set instanceInterruptionBehavior(value: string);
        resetInstanceInterruptionBehavior(): void;
        get instanceInterruptionBehaviorInput(): string | undefined;
        private _maxPrice?;
        get maxPrice(): string;
        set maxPrice(value: string);
        resetMaxPrice(): void;
        get maxPriceInput(): string | undefined;
        private _spotInstanceType?;
        get spotInstanceType(): string;
        set spotInstanceType(value: string);
        resetSpotInstanceType(): void;
        get spotInstanceTypeInput(): string | undefined;
        private _validUntil?;
        get validUntil(): string;
        set validUntil(value: string);
        resetValidUntil(): void;
        get validUntilInput(): string | undefined;
    }
    interface InstanceMarketOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#market_type TfLaunchTemplate#market_type}
        */
        readonly marketType?: string;
        /**
        * spot_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#spot_options TfLaunchTemplate#spot_options}
        */
        readonly spotOptions?: SpotOptionsProperty;
    }
    class InstanceMarketOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InstanceMarketOptionsProperty | undefined;
        set internalValue(value: InstanceMarketOptionsProperty | undefined);
        private _marketType?;
        get marketType(): string;
        set marketType(value: string);
        resetMarketType(): void;
        get marketTypeInput(): string | undefined;
        private _spotOptions;
        get spotOptions(): SpotOptionsPropertyOutputReference;
        putSpotOptions(value: SpotOptionsProperty): void;
        resetSpotOptions(): void;
        get spotOptionsInput(): SpotOptionsProperty | undefined;
    }
    interface AcceleratorCountProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#max TfLaunchTemplate#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#min TfLaunchTemplate#min}
        */
        readonly min?: number;
    }
    class AcceleratorCountPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AcceleratorCountProperty | undefined;
        set internalValue(value: AcceleratorCountProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface AcceleratorTotalMemoryMibProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#max TfLaunchTemplate#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#min TfLaunchTemplate#min}
        */
        readonly min?: number;
    }
    class AcceleratorTotalMemoryMibPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AcceleratorTotalMemoryMibProperty | undefined;
        set internalValue(value: AcceleratorTotalMemoryMibProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface BaselineEbsBandwidthMbpsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#max TfLaunchTemplate#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#min TfLaunchTemplate#min}
        */
        readonly min?: number;
    }
    class BaselineEbsBandwidthMbpsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BaselineEbsBandwidthMbpsProperty | undefined;
        set internalValue(value: BaselineEbsBandwidthMbpsProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface MemoryGibPerVcpuProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#max TfLaunchTemplate#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#min TfLaunchTemplate#min}
        */
        readonly min?: number;
    }
    class MemoryGibPerVcpuPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MemoryGibPerVcpuProperty | undefined;
        set internalValue(value: MemoryGibPerVcpuProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface MemoryMibProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#max TfLaunchTemplate#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#min TfLaunchTemplate#min}
        */
        readonly min: number;
    }
    class MemoryMibPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MemoryMibProperty | undefined;
        set internalValue(value: MemoryMibProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        get minInput(): number | undefined;
    }
    interface NetworkBandwidthGbpsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#max TfLaunchTemplate#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#min TfLaunchTemplate#min}
        */
        readonly min?: number;
    }
    class NetworkBandwidthGbpsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NetworkBandwidthGbpsProperty | undefined;
        set internalValue(value: NetworkBandwidthGbpsProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface NetworkInterfaceCountProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#max TfLaunchTemplate#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#min TfLaunchTemplate#min}
        */
        readonly min?: number;
    }
    class NetworkInterfaceCountPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NetworkInterfaceCountProperty | undefined;
        set internalValue(value: NetworkInterfaceCountProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface TotalLocalStorageGbProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#max TfLaunchTemplate#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#min TfLaunchTemplate#min}
        */
        readonly min?: number;
    }
    class TotalLocalStorageGbPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TotalLocalStorageGbProperty | undefined;
        set internalValue(value: TotalLocalStorageGbProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface VcpuCountProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#max TfLaunchTemplate#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#min TfLaunchTemplate#min}
        */
        readonly min: number;
    }
    class VcpuCountPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VcpuCountProperty | undefined;
        set internalValue(value: VcpuCountProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        get minInput(): number | undefined;
    }
    interface InstanceRequirementsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#accelerator_manufacturers TfLaunchTemplate#accelerator_manufacturers}
        */
        readonly acceleratorManufacturers?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#accelerator_names TfLaunchTemplate#accelerator_names}
        */
        readonly acceleratorNames?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#accelerator_types TfLaunchTemplate#accelerator_types}
        */
        readonly acceleratorTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#allowed_instance_types TfLaunchTemplate#allowed_instance_types}
        */
        readonly allowedInstanceTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#bare_metal TfLaunchTemplate#bare_metal}
        */
        readonly bareMetal?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#burstable_performance TfLaunchTemplate#burstable_performance}
        */
        readonly burstablePerformance?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#cpu_manufacturers TfLaunchTemplate#cpu_manufacturers}
        */
        readonly cpuManufacturers?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#excluded_instance_types TfLaunchTemplate#excluded_instance_types}
        */
        readonly excludedInstanceTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#instance_generations TfLaunchTemplate#instance_generations}
        */
        readonly instanceGenerations?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#local_storage TfLaunchTemplate#local_storage}
        */
        readonly localStorage?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#local_storage_types TfLaunchTemplate#local_storage_types}
        */
        readonly localStorageTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#max_spot_price_as_percentage_of_optimal_on_demand_price TfLaunchTemplate#max_spot_price_as_percentage_of_optimal_on_demand_price}
        */
        readonly maxSpotPriceAsPercentageOfOptimalOnDemandPrice?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#on_demand_max_price_percentage_over_lowest_price TfLaunchTemplate#on_demand_max_price_percentage_over_lowest_price}
        */
        readonly onDemandMaxPricePercentageOverLowestPrice?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#require_hibernate_support TfLaunchTemplate#require_hibernate_support}
        */
        readonly requireHibernateSupport?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#spot_max_price_percentage_over_lowest_price TfLaunchTemplate#spot_max_price_percentage_over_lowest_price}
        */
        readonly spotMaxPricePercentageOverLowestPrice?: number;
        /**
        * accelerator_count block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#accelerator_count TfLaunchTemplate#accelerator_count}
        */
        readonly acceleratorCount?: AcceleratorCountProperty;
        /**
        * accelerator_total_memory_mib block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#accelerator_total_memory_mib TfLaunchTemplate#accelerator_total_memory_mib}
        */
        readonly acceleratorTotalMemoryMib?: AcceleratorTotalMemoryMibProperty;
        /**
        * baseline_ebs_bandwidth_mbps block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#baseline_ebs_bandwidth_mbps TfLaunchTemplate#baseline_ebs_bandwidth_mbps}
        */
        readonly baselineEbsBandwidthMbps?: BaselineEbsBandwidthMbpsProperty;
        /**
        * memory_gib_per_vcpu block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#memory_gib_per_vcpu TfLaunchTemplate#memory_gib_per_vcpu}
        */
        readonly memoryGibPerVcpu?: MemoryGibPerVcpuProperty;
        /**
        * memory_mib block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#memory_mib TfLaunchTemplate#memory_mib}
        */
        readonly memoryMib: MemoryMibProperty;
        /**
        * network_bandwidth_gbps block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#network_bandwidth_gbps TfLaunchTemplate#network_bandwidth_gbps}
        */
        readonly networkBandwidthGbps?: NetworkBandwidthGbpsProperty;
        /**
        * network_interface_count block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#network_interface_count TfLaunchTemplate#network_interface_count}
        */
        readonly networkInterfaceCount?: NetworkInterfaceCountProperty;
        /**
        * total_local_storage_gb block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#total_local_storage_gb TfLaunchTemplate#total_local_storage_gb}
        */
        readonly totalLocalStorageGb?: TotalLocalStorageGbProperty;
        /**
        * vcpu_count block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#vcpu_count TfLaunchTemplate#vcpu_count}
        */
        readonly vcpuCount: VcpuCountProperty;
    }
    class InstanceRequirementsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InstanceRequirementsProperty | undefined;
        set internalValue(value: InstanceRequirementsProperty | undefined);
        private _acceleratorManufacturers?;
        get acceleratorManufacturers(): string[];
        set acceleratorManufacturers(value: string[]);
        resetAcceleratorManufacturers(): void;
        get acceleratorManufacturersInput(): string[] | undefined;
        private _acceleratorNames?;
        get acceleratorNames(): string[];
        set acceleratorNames(value: string[]);
        resetAcceleratorNames(): void;
        get acceleratorNamesInput(): string[] | undefined;
        private _acceleratorTypes?;
        get acceleratorTypes(): string[];
        set acceleratorTypes(value: string[]);
        resetAcceleratorTypes(): void;
        get acceleratorTypesInput(): string[] | undefined;
        private _allowedInstanceTypes?;
        get allowedInstanceTypes(): string[];
        set allowedInstanceTypes(value: string[]);
        resetAllowedInstanceTypes(): void;
        get allowedInstanceTypesInput(): string[] | undefined;
        private _bareMetal?;
        get bareMetal(): string;
        set bareMetal(value: string);
        resetBareMetal(): void;
        get bareMetalInput(): string | undefined;
        private _burstablePerformance?;
        get burstablePerformance(): string;
        set burstablePerformance(value: string);
        resetBurstablePerformance(): void;
        get burstablePerformanceInput(): string | undefined;
        private _cpuManufacturers?;
        get cpuManufacturers(): string[];
        set cpuManufacturers(value: string[]);
        resetCpuManufacturers(): void;
        get cpuManufacturersInput(): string[] | undefined;
        private _excludedInstanceTypes?;
        get excludedInstanceTypes(): string[];
        set excludedInstanceTypes(value: string[]);
        resetExcludedInstanceTypes(): void;
        get excludedInstanceTypesInput(): string[] | undefined;
        private _instanceGenerations?;
        get instanceGenerations(): string[];
        set instanceGenerations(value: string[]);
        resetInstanceGenerations(): void;
        get instanceGenerationsInput(): string[] | undefined;
        private _localStorage?;
        get localStorage(): string;
        set localStorage(value: string);
        resetLocalStorage(): void;
        get localStorageInput(): string | undefined;
        private _localStorageTypes?;
        get localStorageTypes(): string[];
        set localStorageTypes(value: string[]);
        resetLocalStorageTypes(): void;
        get localStorageTypesInput(): string[] | undefined;
        private _maxSpotPriceAsPercentageOfOptimalOnDemandPrice?;
        get maxSpotPriceAsPercentageOfOptimalOnDemandPrice(): number;
        set maxSpotPriceAsPercentageOfOptimalOnDemandPrice(value: number);
        resetMaxSpotPriceAsPercentageOfOptimalOnDemandPrice(): void;
        get maxSpotPriceAsPercentageOfOptimalOnDemandPriceInput(): number | undefined;
        private _onDemandMaxPricePercentageOverLowestPrice?;
        get onDemandMaxPricePercentageOverLowestPrice(): number;
        set onDemandMaxPricePercentageOverLowestPrice(value: number);
        resetOnDemandMaxPricePercentageOverLowestPrice(): void;
        get onDemandMaxPricePercentageOverLowestPriceInput(): number | undefined;
        private _requireHibernateSupport?;
        get requireHibernateSupport(): boolean | cdktn.IResolvable;
        set requireHibernateSupport(value: boolean | cdktn.IResolvable);
        resetRequireHibernateSupport(): void;
        get requireHibernateSupportInput(): boolean | cdktn.IResolvable | undefined;
        private _spotMaxPricePercentageOverLowestPrice?;
        get spotMaxPricePercentageOverLowestPrice(): number;
        set spotMaxPricePercentageOverLowestPrice(value: number);
        resetSpotMaxPricePercentageOverLowestPrice(): void;
        get spotMaxPricePercentageOverLowestPriceInput(): number | undefined;
        private _acceleratorCount;
        get acceleratorCount(): AcceleratorCountPropertyOutputReference;
        putAcceleratorCount(value: AcceleratorCountProperty): void;
        resetAcceleratorCount(): void;
        get acceleratorCountInput(): AcceleratorCountProperty | undefined;
        private _acceleratorTotalMemoryMib;
        get acceleratorTotalMemoryMib(): AcceleratorTotalMemoryMibPropertyOutputReference;
        putAcceleratorTotalMemoryMib(value: AcceleratorTotalMemoryMibProperty): void;
        resetAcceleratorTotalMemoryMib(): void;
        get acceleratorTotalMemoryMibInput(): AcceleratorTotalMemoryMibProperty | undefined;
        private _baselineEbsBandwidthMbps;
        get baselineEbsBandwidthMbps(): BaselineEbsBandwidthMbpsPropertyOutputReference;
        putBaselineEbsBandwidthMbps(value: BaselineEbsBandwidthMbpsProperty): void;
        resetBaselineEbsBandwidthMbps(): void;
        get baselineEbsBandwidthMbpsInput(): BaselineEbsBandwidthMbpsProperty | undefined;
        private _memoryGibPerVcpu;
        get memoryGibPerVcpu(): MemoryGibPerVcpuPropertyOutputReference;
        putMemoryGibPerVcpu(value: MemoryGibPerVcpuProperty): void;
        resetMemoryGibPerVcpu(): void;
        get memoryGibPerVcpuInput(): MemoryGibPerVcpuProperty | undefined;
        private _memoryMib;
        get memoryMib(): MemoryMibPropertyOutputReference;
        putMemoryMib(value: MemoryMibProperty): void;
        get memoryMibInput(): MemoryMibProperty | undefined;
        private _networkBandwidthGbps;
        get networkBandwidthGbps(): NetworkBandwidthGbpsPropertyOutputReference;
        putNetworkBandwidthGbps(value: NetworkBandwidthGbpsProperty): void;
        resetNetworkBandwidthGbps(): void;
        get networkBandwidthGbpsInput(): NetworkBandwidthGbpsProperty | undefined;
        private _networkInterfaceCount;
        get networkInterfaceCount(): NetworkInterfaceCountPropertyOutputReference;
        putNetworkInterfaceCount(value: NetworkInterfaceCountProperty): void;
        resetNetworkInterfaceCount(): void;
        get networkInterfaceCountInput(): NetworkInterfaceCountProperty | undefined;
        private _totalLocalStorageGb;
        get totalLocalStorageGb(): TotalLocalStorageGbPropertyOutputReference;
        putTotalLocalStorageGb(value: TotalLocalStorageGbProperty): void;
        resetTotalLocalStorageGb(): void;
        get totalLocalStorageGbInput(): TotalLocalStorageGbProperty | undefined;
        private _vcpuCount;
        get vcpuCount(): VcpuCountPropertyOutputReference;
        putVcpuCount(value: VcpuCountProperty): void;
        get vcpuCountInput(): VcpuCountProperty | undefined;
    }
    interface LicenseSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#license_configuration_arn TfLaunchTemplate#license_configuration_arn}
        */
        readonly licenseConfigurationArn: string;
    }
    class LicenseSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LicenseSpecificationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LicenseSpecificationProperty | cdktn.IResolvable | undefined);
        private _licenseConfigurationArn?;
        get licenseConfigurationArn(): string;
        set licenseConfigurationArn(value: string);
        get licenseConfigurationArnInput(): string | undefined;
    }
    class LicenseSpecificationPropertyList extends cdktn.ComplexList {
        internalValue?: LicenseSpecificationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LicenseSpecificationPropertyOutputReference;
    }
    interface MaintenanceOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#auto_recovery TfLaunchTemplate#auto_recovery}
        */
        readonly autoRecovery?: string;
    }
    class MaintenanceOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MaintenanceOptionsProperty | undefined;
        set internalValue(value: MaintenanceOptionsProperty | undefined);
        private _autoRecovery?;
        get autoRecovery(): string;
        set autoRecovery(value: string);
        resetAutoRecovery(): void;
        get autoRecoveryInput(): string | undefined;
    }
    interface MetadataOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#http_endpoint TfLaunchTemplate#http_endpoint}
        */
        readonly httpEndpoint?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#http_protocol_ipv6 TfLaunchTemplate#http_protocol_ipv6}
        */
        readonly httpProtocolIpv6?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#http_put_response_hop_limit TfLaunchTemplate#http_put_response_hop_limit}
        */
        readonly httpPutResponseHopLimit?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#http_tokens TfLaunchTemplate#http_tokens}
        */
        readonly httpTokens?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#instance_metadata_tags TfLaunchTemplate#instance_metadata_tags}
        */
        readonly instanceMetadataTags?: string;
    }
    class MetadataOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MetadataOptionsProperty | undefined;
        set internalValue(value: MetadataOptionsProperty | undefined);
        private _httpEndpoint?;
        get httpEndpoint(): string;
        set httpEndpoint(value: string);
        resetHttpEndpoint(): void;
        get httpEndpointInput(): string | undefined;
        private _httpProtocolIpv6?;
        get httpProtocolIpv6(): string;
        set httpProtocolIpv6(value: string);
        resetHttpProtocolIpv6(): void;
        get httpProtocolIpv6Input(): string | undefined;
        private _httpPutResponseHopLimit?;
        get httpPutResponseHopLimit(): number;
        set httpPutResponseHopLimit(value: number);
        resetHttpPutResponseHopLimit(): void;
        get httpPutResponseHopLimitInput(): number | undefined;
        private _httpTokens?;
        get httpTokens(): string;
        set httpTokens(value: string);
        resetHttpTokens(): void;
        get httpTokensInput(): string | undefined;
        private _instanceMetadataTags?;
        get instanceMetadataTags(): string;
        set instanceMetadataTags(value: string);
        resetInstanceMetadataTags(): void;
        get instanceMetadataTagsInput(): string | undefined;
    }
    interface MonitoringProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#enabled TfLaunchTemplate#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
    }
    class MonitoringPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MonitoringProperty | undefined;
        set internalValue(value: MonitoringProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface ConnectionTrackingSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#tcp_established_timeout TfLaunchTemplate#tcp_established_timeout}
        */
        readonly tcpEstablishedTimeout?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#udp_stream_timeout TfLaunchTemplate#udp_stream_timeout}
        */
        readonly udpStreamTimeout?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#udp_timeout TfLaunchTemplate#udp_timeout}
        */
        readonly udpTimeout?: number;
    }
    class ConnectionTrackingSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConnectionTrackingSpecificationProperty | undefined;
        set internalValue(value: ConnectionTrackingSpecificationProperty | undefined);
        private _tcpEstablishedTimeout?;
        get tcpEstablishedTimeout(): number;
        set tcpEstablishedTimeout(value: number);
        resetTcpEstablishedTimeout(): void;
        get tcpEstablishedTimeoutInput(): number | undefined;
        private _udpStreamTimeout?;
        get udpStreamTimeout(): number;
        set udpStreamTimeout(value: number);
        resetUdpStreamTimeout(): void;
        get udpStreamTimeoutInput(): number | undefined;
        private _udpTimeout?;
        get udpTimeout(): number;
        set udpTimeout(value: number);
        resetUdpTimeout(): void;
        get udpTimeoutInput(): number | undefined;
    }
    interface EnaSrdUdpSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#ena_srd_udp_enabled TfLaunchTemplate#ena_srd_udp_enabled}
        */
        readonly enaSrdUdpEnabled?: boolean | cdktn.IResolvable;
    }
    class EnaSrdUdpSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EnaSrdUdpSpecificationProperty | undefined;
        set internalValue(value: EnaSrdUdpSpecificationProperty | undefined);
        private _enaSrdUdpEnabled?;
        get enaSrdUdpEnabled(): boolean | cdktn.IResolvable;
        set enaSrdUdpEnabled(value: boolean | cdktn.IResolvable);
        resetEnaSrdUdpEnabled(): void;
        get enaSrdUdpEnabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface EnaSrdSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#ena_srd_enabled TfLaunchTemplate#ena_srd_enabled}
        */
        readonly enaSrdEnabled?: boolean | cdktn.IResolvable;
        /**
        * ena_srd_udp_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#ena_srd_udp_specification TfLaunchTemplate#ena_srd_udp_specification}
        */
        readonly enaSrdUdpSpecification?: EnaSrdUdpSpecificationProperty;
    }
    class EnaSrdSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EnaSrdSpecificationProperty | undefined;
        set internalValue(value: EnaSrdSpecificationProperty | undefined);
        private _enaSrdEnabled?;
        get enaSrdEnabled(): boolean | cdktn.IResolvable;
        set enaSrdEnabled(value: boolean | cdktn.IResolvable);
        resetEnaSrdEnabled(): void;
        get enaSrdEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _enaSrdUdpSpecification;
        get enaSrdUdpSpecification(): EnaSrdUdpSpecificationPropertyOutputReference;
        putEnaSrdUdpSpecification(value: EnaSrdUdpSpecificationProperty): void;
        resetEnaSrdUdpSpecification(): void;
        get enaSrdUdpSpecificationInput(): EnaSrdUdpSpecificationProperty | undefined;
    }
    interface NetworkInterfacesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#associate_carrier_ip_address TfLaunchTemplate#associate_carrier_ip_address}
        */
        readonly associateCarrierIpAddress?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#associate_public_ip_address TfLaunchTemplate#associate_public_ip_address}
        */
        readonly associatePublicIpAddress?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#delete_on_termination TfLaunchTemplate#delete_on_termination}
        */
        readonly deleteOnTermination?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#description TfLaunchTemplate#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#device_index TfLaunchTemplate#device_index}
        */
        readonly deviceIndex?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#ena_queue_count TfLaunchTemplate#ena_queue_count}
        */
        readonly enaQueueCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#interface_type TfLaunchTemplate#interface_type}
        */
        readonly interfaceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#ipv4_address_count TfLaunchTemplate#ipv4_address_count}
        */
        readonly ipv4AddressCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#ipv4_addresses TfLaunchTemplate#ipv4_addresses}
        */
        readonly ipv4Addresses?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#ipv4_prefix_count TfLaunchTemplate#ipv4_prefix_count}
        */
        readonly ipv4PrefixCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#ipv4_prefixes TfLaunchTemplate#ipv4_prefixes}
        */
        readonly ipv4Prefixes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#ipv6_address_count TfLaunchTemplate#ipv6_address_count}
        */
        readonly ipv6AddressCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#ipv6_addresses TfLaunchTemplate#ipv6_addresses}
        */
        readonly ipv6Addresses?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#ipv6_prefix_count TfLaunchTemplate#ipv6_prefix_count}
        */
        readonly ipv6PrefixCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#ipv6_prefixes TfLaunchTemplate#ipv6_prefixes}
        */
        readonly ipv6Prefixes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#network_card_index TfLaunchTemplate#network_card_index}
        */
        readonly networkCardIndex?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#network_interface_id TfLaunchTemplate#network_interface_id}
        */
        readonly networkInterfaceId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#primary_ipv6 TfLaunchTemplate#primary_ipv6}
        */
        readonly primaryIpv6?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#private_ip_address TfLaunchTemplate#private_ip_address}
        */
        readonly privateIpAddress?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#security_groups TfLaunchTemplate#security_groups}
        */
        readonly securityGroups?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#subnet_id TfLaunchTemplate#subnet_id}
        */
        readonly subnetId?: string;
        /**
        * connection_tracking_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#connection_tracking_specification TfLaunchTemplate#connection_tracking_specification}
        */
        readonly connectionTrackingSpecification?: ConnectionTrackingSpecificationProperty;
        /**
        * ena_srd_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#ena_srd_specification TfLaunchTemplate#ena_srd_specification}
        */
        readonly enaSrdSpecification?: EnaSrdSpecificationProperty;
    }
    class NetworkInterfacesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NetworkInterfacesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NetworkInterfacesProperty | cdktn.IResolvable | undefined);
        private _associateCarrierIpAddress?;
        get associateCarrierIpAddress(): string;
        set associateCarrierIpAddress(value: string);
        resetAssociateCarrierIpAddress(): void;
        get associateCarrierIpAddressInput(): string | undefined;
        private _associatePublicIpAddress?;
        get associatePublicIpAddress(): string;
        set associatePublicIpAddress(value: string);
        resetAssociatePublicIpAddress(): void;
        get associatePublicIpAddressInput(): string | undefined;
        private _deleteOnTermination?;
        get deleteOnTermination(): string;
        set deleteOnTermination(value: string);
        resetDeleteOnTermination(): void;
        get deleteOnTerminationInput(): string | undefined;
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _deviceIndex?;
        get deviceIndex(): number;
        set deviceIndex(value: number);
        resetDeviceIndex(): void;
        get deviceIndexInput(): number | undefined;
        private _enaQueueCount?;
        get enaQueueCount(): number;
        set enaQueueCount(value: number);
        resetEnaQueueCount(): void;
        get enaQueueCountInput(): number | undefined;
        private _interfaceType?;
        get interfaceType(): string;
        set interfaceType(value: string);
        resetInterfaceType(): void;
        get interfaceTypeInput(): string | undefined;
        private _ipv4AddressCount?;
        get ipv4AddressCount(): number;
        set ipv4AddressCount(value: number);
        resetIpv4AddressCount(): void;
        get ipv4AddressCountInput(): number | undefined;
        private _ipv4Addresses?;
        get ipv4Addresses(): string[];
        set ipv4Addresses(value: string[]);
        resetIpv4Addresses(): void;
        get ipv4AddressesInput(): string[] | undefined;
        private _ipv4PrefixCount?;
        get ipv4PrefixCount(): number;
        set ipv4PrefixCount(value: number);
        resetIpv4PrefixCount(): void;
        get ipv4PrefixCountInput(): number | undefined;
        private _ipv4Prefixes?;
        get ipv4Prefixes(): string[];
        set ipv4Prefixes(value: string[]);
        resetIpv4Prefixes(): void;
        get ipv4PrefixesInput(): string[] | undefined;
        private _ipv6AddressCount?;
        get ipv6AddressCount(): number;
        set ipv6AddressCount(value: number);
        resetIpv6AddressCount(): void;
        get ipv6AddressCountInput(): number | undefined;
        private _ipv6Addresses?;
        get ipv6Addresses(): string[];
        set ipv6Addresses(value: string[]);
        resetIpv6Addresses(): void;
        get ipv6AddressesInput(): string[] | undefined;
        private _ipv6PrefixCount?;
        get ipv6PrefixCount(): number;
        set ipv6PrefixCount(value: number);
        resetIpv6PrefixCount(): void;
        get ipv6PrefixCountInput(): number | undefined;
        private _ipv6Prefixes?;
        get ipv6Prefixes(): string[];
        set ipv6Prefixes(value: string[]);
        resetIpv6Prefixes(): void;
        get ipv6PrefixesInput(): string[] | undefined;
        private _networkCardIndex?;
        get networkCardIndex(): number;
        set networkCardIndex(value: number);
        resetNetworkCardIndex(): void;
        get networkCardIndexInput(): number | undefined;
        private _networkInterfaceId?;
        get networkInterfaceId(): string;
        set networkInterfaceId(value: string);
        resetNetworkInterfaceId(): void;
        get networkInterfaceIdInput(): string | undefined;
        private _primaryIpv6?;
        get primaryIpv6(): string;
        set primaryIpv6(value: string);
        resetPrimaryIpv6(): void;
        get primaryIpv6Input(): string | undefined;
        private _privateIpAddress?;
        get privateIpAddress(): string;
        set privateIpAddress(value: string);
        resetPrivateIpAddress(): void;
        get privateIpAddressInput(): string | undefined;
        private _securityGroups?;
        get securityGroups(): string[];
        set securityGroups(value: string[]);
        resetSecurityGroups(): void;
        get securityGroupsInput(): string[] | undefined;
        private _subnetId?;
        get subnetId(): string;
        set subnetId(value: string);
        resetSubnetId(): void;
        get subnetIdInput(): string | undefined;
        private _connectionTrackingSpecification;
        get connectionTrackingSpecification(): ConnectionTrackingSpecificationPropertyOutputReference;
        putConnectionTrackingSpecification(value: ConnectionTrackingSpecificationProperty): void;
        resetConnectionTrackingSpecification(): void;
        get connectionTrackingSpecificationInput(): ConnectionTrackingSpecificationProperty | undefined;
        private _enaSrdSpecification;
        get enaSrdSpecification(): EnaSrdSpecificationPropertyOutputReference;
        putEnaSrdSpecification(value: EnaSrdSpecificationProperty): void;
        resetEnaSrdSpecification(): void;
        get enaSrdSpecificationInput(): EnaSrdSpecificationProperty | undefined;
    }
    class NetworkInterfacesPropertyList extends cdktn.ComplexList {
        internalValue?: NetworkInterfacesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NetworkInterfacesPropertyOutputReference;
    }
    interface NetworkPerformanceOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#bandwidth_weighting TfLaunchTemplate#bandwidth_weighting}
        */
        readonly bandwidthWeighting?: string;
    }
    class NetworkPerformanceOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NetworkPerformanceOptionsProperty | undefined;
        set internalValue(value: NetworkPerformanceOptionsProperty | undefined);
        private _bandwidthWeighting?;
        get bandwidthWeighting(): string;
        set bandwidthWeighting(value: string);
        resetBandwidthWeighting(): void;
        get bandwidthWeightingInput(): string | undefined;
    }
    interface PlacementProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#affinity TfLaunchTemplate#affinity}
        */
        readonly affinity?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#availability_zone TfLaunchTemplate#availability_zone}
        */
        readonly availabilityZone?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#group_id TfLaunchTemplate#group_id}
        */
        readonly groupId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#group_name TfLaunchTemplate#group_name}
        */
        readonly groupName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#host_id TfLaunchTemplate#host_id}
        */
        readonly hostId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#host_resource_group_arn TfLaunchTemplate#host_resource_group_arn}
        */
        readonly hostResourceGroupArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#partition_number TfLaunchTemplate#partition_number}
        */
        readonly partitionNumber?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#spread_domain TfLaunchTemplate#spread_domain}
        */
        readonly spreadDomain?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#tenancy TfLaunchTemplate#tenancy}
        */
        readonly tenancy?: string;
    }
    class PlacementPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PlacementProperty | undefined;
        set internalValue(value: PlacementProperty | undefined);
        private _affinity?;
        get affinity(): string;
        set affinity(value: string);
        resetAffinity(): void;
        get affinityInput(): string | undefined;
        private _availabilityZone?;
        get availabilityZone(): string;
        set availabilityZone(value: string);
        resetAvailabilityZone(): void;
        get availabilityZoneInput(): string | undefined;
        private _groupId?;
        get groupId(): string;
        set groupId(value: string);
        resetGroupId(): void;
        get groupIdInput(): string | undefined;
        private _groupName?;
        get groupName(): string;
        set groupName(value: string);
        resetGroupName(): void;
        get groupNameInput(): string | undefined;
        private _hostId?;
        get hostId(): string;
        set hostId(value: string);
        resetHostId(): void;
        get hostIdInput(): string | undefined;
        private _hostResourceGroupArn?;
        get hostResourceGroupArn(): string;
        set hostResourceGroupArn(value: string);
        resetHostResourceGroupArn(): void;
        get hostResourceGroupArnInput(): string | undefined;
        private _partitionNumber?;
        get partitionNumber(): number;
        set partitionNumber(value: number);
        resetPartitionNumber(): void;
        get partitionNumberInput(): number | undefined;
        private _spreadDomain?;
        get spreadDomain(): string;
        set spreadDomain(value: string);
        resetSpreadDomain(): void;
        get spreadDomainInput(): string | undefined;
        private _tenancy?;
        get tenancy(): string;
        set tenancy(value: string);
        resetTenancy(): void;
        get tenancyInput(): string | undefined;
    }
    interface PrivateDnsNameOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#enable_resource_name_dns_a_record TfLaunchTemplate#enable_resource_name_dns_a_record}
        */
        readonly enableResourceNameDnsARecord?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#enable_resource_name_dns_aaaa_record TfLaunchTemplate#enable_resource_name_dns_aaaa_record}
        */
        readonly enableResourceNameDnsAaaaRecord?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#hostname_type TfLaunchTemplate#hostname_type}
        */
        readonly hostnameType?: string;
    }
    class PrivateDnsNameOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PrivateDnsNameOptionsProperty | undefined;
        set internalValue(value: PrivateDnsNameOptionsProperty | undefined);
        private _enableResourceNameDnsARecord?;
        get enableResourceNameDnsARecord(): boolean | cdktn.IResolvable;
        set enableResourceNameDnsARecord(value: boolean | cdktn.IResolvable);
        resetEnableResourceNameDnsARecord(): void;
        get enableResourceNameDnsARecordInput(): boolean | cdktn.IResolvable | undefined;
        private _enableResourceNameDnsAaaaRecord?;
        get enableResourceNameDnsAaaaRecord(): boolean | cdktn.IResolvable;
        set enableResourceNameDnsAaaaRecord(value: boolean | cdktn.IResolvable);
        resetEnableResourceNameDnsAaaaRecord(): void;
        get enableResourceNameDnsAaaaRecordInput(): boolean | cdktn.IResolvable | undefined;
        private _hostnameType?;
        get hostnameType(): string;
        set hostnameType(value: string);
        resetHostnameType(): void;
        get hostnameTypeInput(): string | undefined;
    }
    interface SecondaryInterfacesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#delete_on_termination TfLaunchTemplate#delete_on_termination}
        */
        readonly deleteOnTermination?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#device_index TfLaunchTemplate#device_index}
        */
        readonly deviceIndex?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#interface_type TfLaunchTemplate#interface_type}
        */
        readonly interfaceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#network_card_index TfLaunchTemplate#network_card_index}
        */
        readonly networkCardIndex?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#private_ip_address_count TfLaunchTemplate#private_ip_address_count}
        */
        readonly privateIpAddressCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#private_ip_addresses TfLaunchTemplate#private_ip_addresses}
        */
        readonly privateIpAddresses?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#secondary_subnet_id TfLaunchTemplate#secondary_subnet_id}
        */
        readonly secondarySubnetId?: string;
    }
    class SecondaryInterfacesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SecondaryInterfacesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SecondaryInterfacesProperty | cdktn.IResolvable | undefined);
        private _deleteOnTermination?;
        get deleteOnTermination(): boolean | cdktn.IResolvable;
        set deleteOnTermination(value: boolean | cdktn.IResolvable);
        resetDeleteOnTermination(): void;
        get deleteOnTerminationInput(): boolean | cdktn.IResolvable | undefined;
        private _deviceIndex?;
        get deviceIndex(): number;
        set deviceIndex(value: number);
        resetDeviceIndex(): void;
        get deviceIndexInput(): number | undefined;
        private _interfaceType?;
        get interfaceType(): string;
        set interfaceType(value: string);
        resetInterfaceType(): void;
        get interfaceTypeInput(): string | undefined;
        private _networkCardIndex?;
        get networkCardIndex(): number;
        set networkCardIndex(value: number);
        resetNetworkCardIndex(): void;
        get networkCardIndexInput(): number | undefined;
        private _privateIpAddressCount?;
        get privateIpAddressCount(): number;
        set privateIpAddressCount(value: number);
        resetPrivateIpAddressCount(): void;
        get privateIpAddressCountInput(): number | undefined;
        private _privateIpAddresses?;
        get privateIpAddresses(): string[];
        set privateIpAddresses(value: string[]);
        resetPrivateIpAddresses(): void;
        get privateIpAddressesInput(): string[] | undefined;
        private _secondarySubnetId?;
        get secondarySubnetId(): string;
        set secondarySubnetId(value: string);
        resetSecondarySubnetId(): void;
        get secondarySubnetIdInput(): string | undefined;
    }
    class SecondaryInterfacesPropertyList extends cdktn.ComplexList {
        internalValue?: SecondaryInterfacesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SecondaryInterfacesPropertyOutputReference;
    }
    interface TagSpecificationsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#resource_type TfLaunchTemplate#resource_type}
        */
        readonly resourceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_template#tags TfLaunchTemplate#tags}
        */
        readonly tags?: {
            [key: string]: string;
        };
    }
    class TagSpecificationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TagSpecificationsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TagSpecificationsProperty | cdktn.IResolvable | undefined);
        private _resourceType?;
        get resourceType(): string;
        set resourceType(value: string);
        resetResourceType(): void;
        get resourceTypeInput(): string | undefined;
        private _tags?;
        get tags(): {
            [key: string]: string;
        };
        set tags(value: {
            [key: string]: string;
        });
        resetTags(): void;
        get tagsInput(): {
            [key: string]: string;
        } | undefined;
    }
    class TagSpecificationsPropertyList extends cdktn.ComplexList {
        internalValue?: TagSpecificationsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TagSpecificationsPropertyOutputReference;
    }
}
