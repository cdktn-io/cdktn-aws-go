import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsGrafanaWorkspaceServiceAccountConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace_service_account#grafana_role AwsGrafanaWorkspaceServiceAccount#grafana_role}
    */
    readonly grafanaRole: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace_service_account#name AwsGrafanaWorkspaceServiceAccount#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace_service_account#region AwsGrafanaWorkspaceServiceAccount#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace_service_account#workspace_id AwsGrafanaWorkspaceServiceAccount#workspace_id}
    */
    readonly workspaceId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace_service_account aws_grafana_workspace_service_account}
*/
export declare class AwsGrafanaWorkspaceServiceAccount extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_grafana_workspace_service_account";
    /**
    * Generates CDKTN code for importing a AwsGrafanaWorkspaceServiceAccount resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsGrafanaWorkspaceServiceAccount to import
    * @param importFromId The id of the existing AwsGrafanaWorkspaceServiceAccount that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace_service_account#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsGrafanaWorkspaceServiceAccount to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace_service_account aws_grafana_workspace_service_account} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsGrafanaWorkspaceServiceAccountConfig
    */
    constructor(scope: Construct, id: string, config: AwsGrafanaWorkspaceServiceAccountConfig);
    private _grafanaRole?;
    get grafanaRole(): string;
    set grafanaRole(value: string);
    get grafanaRoleInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get serviceAccountId(): string;
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
