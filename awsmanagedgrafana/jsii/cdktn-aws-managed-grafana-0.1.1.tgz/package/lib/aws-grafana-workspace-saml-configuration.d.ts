import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsGrafanaWorkspaceSamlConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace_saml_configuration#admin_role_values AwsGrafanaWorkspaceSamlConfiguration#admin_role_values}
    */
    readonly adminRoleValues?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace_saml_configuration#allowed_organizations AwsGrafanaWorkspaceSamlConfiguration#allowed_organizations}
    */
    readonly allowedOrganizations?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace_saml_configuration#editor_role_values AwsGrafanaWorkspaceSamlConfiguration#editor_role_values}
    */
    readonly editorRoleValues: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace_saml_configuration#email_assertion AwsGrafanaWorkspaceSamlConfiguration#email_assertion}
    */
    readonly emailAssertion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace_saml_configuration#groups_assertion AwsGrafanaWorkspaceSamlConfiguration#groups_assertion}
    */
    readonly groupsAssertion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace_saml_configuration#id AwsGrafanaWorkspaceSamlConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace_saml_configuration#idp_metadata_url AwsGrafanaWorkspaceSamlConfiguration#idp_metadata_url}
    */
    readonly idpMetadataUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace_saml_configuration#idp_metadata_xml AwsGrafanaWorkspaceSamlConfiguration#idp_metadata_xml}
    */
    readonly idpMetadataXml?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace_saml_configuration#login_assertion AwsGrafanaWorkspaceSamlConfiguration#login_assertion}
    */
    readonly loginAssertion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace_saml_configuration#login_validity_duration AwsGrafanaWorkspaceSamlConfiguration#login_validity_duration}
    */
    readonly loginValidityDuration?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace_saml_configuration#name_assertion AwsGrafanaWorkspaceSamlConfiguration#name_assertion}
    */
    readonly nameAssertion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace_saml_configuration#org_assertion AwsGrafanaWorkspaceSamlConfiguration#org_assertion}
    */
    readonly orgAssertion?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace_saml_configuration#region AwsGrafanaWorkspaceSamlConfiguration#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace_saml_configuration#role_assertion AwsGrafanaWorkspaceSamlConfiguration#role_assertion}
    */
    readonly roleAssertion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace_saml_configuration#workspace_id AwsGrafanaWorkspaceSamlConfiguration#workspace_id}
    */
    readonly workspaceId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace_saml_configuration#timeouts AwsGrafanaWorkspaceSamlConfiguration#timeouts}
    */
    readonly timeouts?: AwsGrafanaWorkspaceSamlConfiguration.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace_saml_configuration aws_grafana_workspace_saml_configuration}
*/
export declare class AwsGrafanaWorkspaceSamlConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_grafana_workspace_saml_configuration";
    /**
    * Generates CDKTN code for importing a AwsGrafanaWorkspaceSamlConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsGrafanaWorkspaceSamlConfiguration to import
    * @param importFromId The id of the existing AwsGrafanaWorkspaceSamlConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace_saml_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsGrafanaWorkspaceSamlConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace_saml_configuration aws_grafana_workspace_saml_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsGrafanaWorkspaceSamlConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AwsGrafanaWorkspaceSamlConfigurationConfig);
    private _adminRoleValues?;
    get adminRoleValues(): string[];
    set adminRoleValues(value: string[]);
    resetAdminRoleValues(): void;
    get adminRoleValuesInput(): string[] | undefined;
    private _allowedOrganizations?;
    get allowedOrganizations(): string[];
    set allowedOrganizations(value: string[]);
    resetAllowedOrganizations(): void;
    get allowedOrganizationsInput(): string[] | undefined;
    private _editorRoleValues?;
    get editorRoleValues(): string[];
    set editorRoleValues(value: string[]);
    get editorRoleValuesInput(): string[] | undefined;
    private _emailAssertion?;
    get emailAssertion(): string;
    set emailAssertion(value: string);
    resetEmailAssertion(): void;
    get emailAssertionInput(): string | undefined;
    private _groupsAssertion?;
    get groupsAssertion(): string;
    set groupsAssertion(value: string);
    resetGroupsAssertion(): void;
    get groupsAssertionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _idpMetadataUrl?;
    get idpMetadataUrl(): string;
    set idpMetadataUrl(value: string);
    resetIdpMetadataUrl(): void;
    get idpMetadataUrlInput(): string | undefined;
    private _idpMetadataXml?;
    get idpMetadataXml(): string;
    set idpMetadataXml(value: string);
    resetIdpMetadataXml(): void;
    get idpMetadataXmlInput(): string | undefined;
    private _loginAssertion?;
    get loginAssertion(): string;
    set loginAssertion(value: string);
    resetLoginAssertion(): void;
    get loginAssertionInput(): string | undefined;
    private _loginValidityDuration?;
    get loginValidityDuration(): number;
    set loginValidityDuration(value: number);
    resetLoginValidityDuration(): void;
    get loginValidityDurationInput(): number | undefined;
    private _nameAssertion?;
    get nameAssertion(): string;
    set nameAssertion(value: string);
    resetNameAssertion(): void;
    get nameAssertionInput(): string | undefined;
    private _orgAssertion?;
    get orgAssertion(): string;
    set orgAssertion(value: string);
    resetOrgAssertion(): void;
    get orgAssertionInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleAssertion?;
    get roleAssertion(): string;
    set roleAssertion(value: string);
    resetRoleAssertion(): void;
    get roleAssertionInput(): string | undefined;
    get status(): string;
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): AwsGrafanaWorkspaceSamlConfiguration.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsGrafanaWorkspaceSamlConfiguration.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsGrafanaWorkspaceSamlConfiguration.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsGrafanaWorkspaceSamlConfigurationTimeoutsPropertyToTerraform(struct?: AwsGrafanaWorkspaceSamlConfiguration.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsGrafanaWorkspaceSamlConfigurationTimeoutsPropertyToHclTerraform(struct?: AwsGrafanaWorkspaceSamlConfiguration.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsGrafanaWorkspaceSamlConfiguration {
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace_saml_configuration#create AwsGrafanaWorkspaceSamlConfiguration#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace_saml_configuration#delete AwsGrafanaWorkspaceSamlConfiguration#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
