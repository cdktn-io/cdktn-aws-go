import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsGrafanaLicenseAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_license_association#grafana_token AwsGrafanaLicenseAssociation#grafana_token}
    */
    readonly grafanaToken?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_license_association#id AwsGrafanaLicenseAssociation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_license_association#license_type AwsGrafanaLicenseAssociation#license_type}
    */
    readonly licenseType: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_license_association#region AwsGrafanaLicenseAssociation#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_license_association#workspace_id AwsGrafanaLicenseAssociation#workspace_id}
    */
    readonly workspaceId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_license_association#timeouts AwsGrafanaLicenseAssociation#timeouts}
    */
    readonly timeouts?: AwsGrafanaLicenseAssociation.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_license_association aws_grafana_license_association}
*/
export declare class AwsGrafanaLicenseAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_grafana_license_association";
    /**
    * Generates CDKTN code for importing a AwsGrafanaLicenseAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsGrafanaLicenseAssociation to import
    * @param importFromId The id of the existing AwsGrafanaLicenseAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_license_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsGrafanaLicenseAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_license_association aws_grafana_license_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsGrafanaLicenseAssociationConfig
    */
    constructor(scope: Construct, id: string, config: AwsGrafanaLicenseAssociationConfig);
    get freeTrialExpiration(): string;
    private _grafanaToken?;
    get grafanaToken(): string;
    set grafanaToken(value: string);
    resetGrafanaToken(): void;
    get grafanaTokenInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get licenseExpiration(): string;
    private _licenseType?;
    get licenseType(): string;
    set licenseType(value: string);
    get licenseTypeInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): AwsGrafanaLicenseAssociation.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsGrafanaLicenseAssociation.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): AwsGrafanaLicenseAssociation.TimeoutsProperty | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsGrafanaLicenseAssociationTimeoutsPropertyToTerraform(struct?: AwsGrafanaLicenseAssociation.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsGrafanaLicenseAssociationTimeoutsPropertyToHclTerraform(struct?: AwsGrafanaLicenseAssociation.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsGrafanaLicenseAssociation {
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_license_association#create AwsGrafanaLicenseAssociation#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_license_association#delete AwsGrafanaLicenseAssociation#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
