import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfWorkspaceServiceAccountTokenConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace_service_account_token#name TfWorkspaceServiceAccountToken#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace_service_account_token#region TfWorkspaceServiceAccountToken#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace_service_account_token#seconds_to_live TfWorkspaceServiceAccountToken#seconds_to_live}
    */
    readonly secondsToLive: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace_service_account_token#service_account_id TfWorkspaceServiceAccountToken#service_account_id}
    */
    readonly serviceAccountId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace_service_account_token#workspace_id TfWorkspaceServiceAccountToken#workspace_id}
    */
    readonly workspaceId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace_service_account_token aws_grafana_workspace_service_account_token}
*/
export declare class TfWorkspaceServiceAccountToken extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_grafana_workspace_service_account_token";
    /**
    * Generates CDKTN code for importing a TfWorkspaceServiceAccountToken resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfWorkspaceServiceAccountToken to import
    * @param importFromId The id of the existing TfWorkspaceServiceAccountToken that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace_service_account_token#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfWorkspaceServiceAccountToken to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace_service_account_token aws_grafana_workspace_service_account_token} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfWorkspaceServiceAccountTokenConfig
    */
    constructor(scope: Construct, id: string, config: TfWorkspaceServiceAccountTokenConfig);
    get createdAt(): string;
    get expiresAt(): string;
    get id(): string;
    get key(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _secondsToLive?;
    get secondsToLive(): number;
    set secondsToLive(value: number);
    get secondsToLiveInput(): number | undefined;
    private _serviceAccountId?;
    get serviceAccountId(): string;
    set serviceAccountId(value: string);
    get serviceAccountIdInput(): string | undefined;
    get serviceAccountTokenId(): string;
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
