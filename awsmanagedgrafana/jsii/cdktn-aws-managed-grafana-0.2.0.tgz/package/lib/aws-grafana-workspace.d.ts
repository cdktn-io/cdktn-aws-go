import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfWorkspaceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace#account_access_type TfWorkspace#account_access_type}
    */
    readonly accountAccessType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace#authentication_providers TfWorkspace#authentication_providers}
    */
    readonly authenticationProviders: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace#configuration TfWorkspace#configuration}
    */
    readonly configuration?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace#data_sources TfWorkspace#data_sources}
    */
    readonly dataSources?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace#description TfWorkspace#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace#grafana_version TfWorkspace#grafana_version}
    */
    readonly grafanaVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace#id TfWorkspace#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace#kms_key_id TfWorkspace#kms_key_id}
    */
    readonly kmsKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace#name TfWorkspace#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace#notification_destinations TfWorkspace#notification_destinations}
    */
    readonly notificationDestinations?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace#organization_role_name TfWorkspace#organization_role_name}
    */
    readonly organizationRoleName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace#organizational_units TfWorkspace#organizational_units}
    */
    readonly organizationalUnits?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace#permission_type TfWorkspace#permission_type}
    */
    readonly permissionType: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace#region TfWorkspace#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace#role_arn TfWorkspace#role_arn}
    */
    readonly roleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace#stack_set_name TfWorkspace#stack_set_name}
    */
    readonly stackSetName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace#tags TfWorkspace#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace#tags_all TfWorkspace#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * network_access_control block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace#network_access_control TfWorkspace#network_access_control}
    */
    readonly networkAccessControl?: TfWorkspace.NetworkAccessControlProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace#timeouts TfWorkspace#timeouts}
    */
    readonly timeouts?: TfWorkspace.TimeoutsProperty;
    /**
    * vpc_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace#vpc_configuration TfWorkspace#vpc_configuration}
    */
    readonly vpcConfiguration?: TfWorkspace.VpcConfigurationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace aws_grafana_workspace}
*/
export declare class TfWorkspace extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_grafana_workspace";
    /**
    * Generates CDKTN code for importing a TfWorkspace resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfWorkspace to import
    * @param importFromId The id of the existing TfWorkspace that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfWorkspace to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace aws_grafana_workspace} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfWorkspaceConfig
    */
    constructor(scope: Construct, id: string, config: TfWorkspaceConfig);
    private _accountAccessType?;
    get accountAccessType(): string;
    set accountAccessType(value: string);
    get accountAccessTypeInput(): string | undefined;
    get arn(): string;
    private _authenticationProviders?;
    get authenticationProviders(): string[];
    set authenticationProviders(value: string[]);
    get authenticationProvidersInput(): string[] | undefined;
    private _configuration?;
    get configuration(): string;
    set configuration(value: string);
    resetConfiguration(): void;
    get configurationInput(): string | undefined;
    private _dataSources?;
    get dataSources(): string[];
    set dataSources(value: string[]);
    resetDataSources(): void;
    get dataSourcesInput(): string[] | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get endpoint(): string;
    private _grafanaVersion?;
    get grafanaVersion(): string;
    set grafanaVersion(value: string);
    resetGrafanaVersion(): void;
    get grafanaVersionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _kmsKeyId?;
    get kmsKeyId(): string;
    set kmsKeyId(value: string);
    resetKmsKeyId(): void;
    get kmsKeyIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _notificationDestinations?;
    get notificationDestinations(): string[];
    set notificationDestinations(value: string[]);
    resetNotificationDestinations(): void;
    get notificationDestinationsInput(): string[] | undefined;
    private _organizationRoleName?;
    get organizationRoleName(): string;
    set organizationRoleName(value: string);
    resetOrganizationRoleName(): void;
    get organizationRoleNameInput(): string | undefined;
    private _organizationalUnits?;
    get organizationalUnits(): string[];
    set organizationalUnits(value: string[]);
    resetOrganizationalUnits(): void;
    get organizationalUnitsInput(): string[] | undefined;
    private _permissionType?;
    get permissionType(): string;
    set permissionType(value: string);
    get permissionTypeInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    resetRoleArn(): void;
    get roleArnInput(): string | undefined;
    get samlConfigurationStatus(): string;
    private _stackSetName?;
    get stackSetName(): string;
    set stackSetName(value: string);
    resetStackSetName(): void;
    get stackSetNameInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _networkAccessControl;
    get networkAccessControl(): TfWorkspace.NetworkAccessControlPropertyOutputReference;
    putNetworkAccessControl(value: TfWorkspace.NetworkAccessControlProperty): void;
    resetNetworkAccessControl(): void;
    get networkAccessControlInput(): TfWorkspace.NetworkAccessControlProperty | undefined;
    private _timeouts;
    get timeouts(): TfWorkspace.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfWorkspace.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfWorkspace.TimeoutsProperty | undefined;
    private _vpcConfiguration;
    get vpcConfiguration(): TfWorkspace.VpcConfigurationPropertyOutputReference;
    putVpcConfiguration(value: TfWorkspace.VpcConfigurationProperty): void;
    resetVpcConfiguration(): void;
    get vpcConfigurationInput(): TfWorkspace.VpcConfigurationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfWorkspaceNetworkAccessControlPropertyToTerraform(struct?: TfWorkspace.NetworkAccessControlPropertyOutputReference | TfWorkspace.NetworkAccessControlProperty): any;
export declare function tfWorkspaceNetworkAccessControlPropertyToHclTerraform(struct?: TfWorkspace.NetworkAccessControlPropertyOutputReference | TfWorkspace.NetworkAccessControlProperty): any;
export declare function tfWorkspaceTimeoutsPropertyToTerraform(struct?: TfWorkspace.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfWorkspaceTimeoutsPropertyToHclTerraform(struct?: TfWorkspace.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfWorkspaceVpcConfigurationPropertyToTerraform(struct?: TfWorkspace.VpcConfigurationPropertyOutputReference | TfWorkspace.VpcConfigurationProperty): any;
export declare function tfWorkspaceVpcConfigurationPropertyToHclTerraform(struct?: TfWorkspace.VpcConfigurationPropertyOutputReference | TfWorkspace.VpcConfigurationProperty): any;
export declare namespace TfWorkspace {
    interface NetworkAccessControlProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace#prefix_list_ids TfWorkspace#prefix_list_ids}
        */
        readonly prefixListIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace#vpce_ids TfWorkspace#vpce_ids}
        */
        readonly vpceIds: string[];
    }
    class NetworkAccessControlPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NetworkAccessControlProperty | undefined;
        set internalValue(value: NetworkAccessControlProperty | undefined);
        private _prefixListIds?;
        get prefixListIds(): string[];
        set prefixListIds(value: string[]);
        get prefixListIdsInput(): string[] | undefined;
        private _vpceIds?;
        get vpceIds(): string[];
        set vpceIds(value: string[]);
        get vpceIdsInput(): string[] | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace#create TfWorkspace#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace#update TfWorkspace#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface VpcConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace#security_group_ids TfWorkspace#security_group_ids}
        */
        readonly securityGroupIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/grafana_workspace#subnet_ids TfWorkspace#subnet_ids}
        */
        readonly subnetIds: string[];
    }
    class VpcConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VpcConfigurationProperty | undefined;
        set internalValue(value: VpcConfigurationProperty | undefined);
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        get subnetIdsInput(): string[] | undefined;
    }
}
