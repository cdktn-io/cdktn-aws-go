import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfNodeGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#ami_type TfNodeGroup#ami_type}
    */
    readonly amiType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#capacity_type TfNodeGroup#capacity_type}
    */
    readonly capacityType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#cluster_name TfNodeGroup#cluster_name}
    */
    readonly clusterName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#disk_size TfNodeGroup#disk_size}
    */
    readonly diskSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#force_update_version TfNodeGroup#force_update_version}
    */
    readonly forceUpdateVersion?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#id TfNodeGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#instance_types TfNodeGroup#instance_types}
    */
    readonly instanceTypes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#labels TfNodeGroup#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#node_group_name TfNodeGroup#node_group_name}
    */
    readonly nodeGroupName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#node_group_name_prefix TfNodeGroup#node_group_name_prefix}
    */
    readonly nodeGroupNamePrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#node_role_arn TfNodeGroup#node_role_arn}
    */
    readonly nodeRoleArn: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#region TfNodeGroup#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#release_version TfNodeGroup#release_version}
    */
    readonly releaseVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#subnet_ids TfNodeGroup#subnet_ids}
    */
    readonly subnetIds: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#tags TfNodeGroup#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#tags_all TfNodeGroup#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#version TfNodeGroup#version}
    */
    readonly version?: string;
    /**
    * launch_template block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#launch_template TfNodeGroup#launch_template}
    */
    readonly launchTemplate?: TfNodeGroup.LaunchTemplateProperty;
    /**
    * node_repair_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#node_repair_config TfNodeGroup#node_repair_config}
    */
    readonly nodeRepairConfig?: TfNodeGroup.NodeRepairConfigProperty;
    /**
    * remote_access block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#remote_access TfNodeGroup#remote_access}
    */
    readonly remoteAccess?: TfNodeGroup.RemoteAccessProperty;
    /**
    * scaling_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#scaling_config TfNodeGroup#scaling_config}
    */
    readonly scalingConfig: TfNodeGroup.ScalingConfigProperty;
    /**
    * taint block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#taint TfNodeGroup#taint}
    */
    readonly taint?: TfNodeGroup.TaintProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#timeouts TfNodeGroup#timeouts}
    */
    readonly timeouts?: TfNodeGroup.TimeoutsProperty;
    /**
    * update_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#update_config TfNodeGroup#update_config}
    */
    readonly updateConfig?: TfNodeGroup.UpdateConfigProperty;
    /**
    * warm_pool_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#warm_pool_config TfNodeGroup#warm_pool_config}
    */
    readonly warmPoolConfig?: TfNodeGroup.WarmPoolConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group aws_eks_node_group}
*/
export declare class TfNodeGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_eks_node_group";
    /**
    * Generates CDKTN code for importing a TfNodeGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfNodeGroup to import
    * @param importFromId The id of the existing TfNodeGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfNodeGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group aws_eks_node_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfNodeGroupConfig
    */
    constructor(scope: Construct, id: string, config: TfNodeGroupConfig);
    private _amiType?;
    get amiType(): string;
    set amiType(value: string);
    resetAmiType(): void;
    get amiTypeInput(): string | undefined;
    get arn(): string;
    private _capacityType?;
    get capacityType(): string;
    set capacityType(value: string);
    resetCapacityType(): void;
    get capacityTypeInput(): string | undefined;
    private _clusterName?;
    get clusterName(): string;
    set clusterName(value: string);
    get clusterNameInput(): string | undefined;
    private _diskSize?;
    get diskSize(): number;
    set diskSize(value: number);
    resetDiskSize(): void;
    get diskSizeInput(): number | undefined;
    private _forceUpdateVersion?;
    get forceUpdateVersion(): boolean | cdktn.IResolvable;
    set forceUpdateVersion(value: boolean | cdktn.IResolvable);
    resetForceUpdateVersion(): void;
    get forceUpdateVersionInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceTypes?;
    get instanceTypes(): string[];
    set instanceTypes(value: string[]);
    resetInstanceTypes(): void;
    get instanceTypesInput(): string[] | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _nodeGroupName?;
    get nodeGroupName(): string;
    set nodeGroupName(value: string);
    resetNodeGroupName(): void;
    get nodeGroupNameInput(): string | undefined;
    private _nodeGroupNamePrefix?;
    get nodeGroupNamePrefix(): string;
    set nodeGroupNamePrefix(value: string);
    resetNodeGroupNamePrefix(): void;
    get nodeGroupNamePrefixInput(): string | undefined;
    private _nodeRoleArn?;
    get nodeRoleArn(): string;
    set nodeRoleArn(value: string);
    get nodeRoleArnInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _releaseVersion?;
    get releaseVersion(): string;
    set releaseVersion(value: string);
    resetReleaseVersion(): void;
    get releaseVersionInput(): string | undefined;
    private _resources;
    get resources(): TfNodeGroup.ResourcesPropertyList;
    get status(): string;
    private _subnetIds?;
    get subnetIds(): string[];
    set subnetIds(value: string[]);
    get subnetIdsInput(): string[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
    private _launchTemplate;
    get launchTemplate(): TfNodeGroup.LaunchTemplatePropertyOutputReference;
    putLaunchTemplate(value: TfNodeGroup.LaunchTemplateProperty): void;
    resetLaunchTemplate(): void;
    get launchTemplateInput(): TfNodeGroup.LaunchTemplateProperty | undefined;
    private _nodeRepairConfig;
    get nodeRepairConfig(): TfNodeGroup.NodeRepairConfigPropertyOutputReference;
    putNodeRepairConfig(value: TfNodeGroup.NodeRepairConfigProperty): void;
    resetNodeRepairConfig(): void;
    get nodeRepairConfigInput(): TfNodeGroup.NodeRepairConfigProperty | undefined;
    private _remoteAccess;
    get remoteAccess(): TfNodeGroup.RemoteAccessPropertyOutputReference;
    putRemoteAccess(value: TfNodeGroup.RemoteAccessProperty): void;
    resetRemoteAccess(): void;
    get remoteAccessInput(): TfNodeGroup.RemoteAccessProperty | undefined;
    private _scalingConfig;
    get scalingConfig(): TfNodeGroup.ScalingConfigPropertyOutputReference;
    putScalingConfig(value: TfNodeGroup.ScalingConfigProperty): void;
    get scalingConfigInput(): TfNodeGroup.ScalingConfigProperty | undefined;
    private _taint;
    get taint(): TfNodeGroup.TaintPropertyList;
    putTaint(value: TfNodeGroup.TaintProperty[] | cdktn.IResolvable): void;
    resetTaint(): void;
    get taintInput(): cdktn.IResolvable | TfNodeGroup.TaintProperty[] | undefined;
    private _timeouts;
    get timeouts(): TfNodeGroup.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfNodeGroup.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfNodeGroup.TimeoutsProperty | undefined;
    private _updateConfig;
    get updateConfig(): TfNodeGroup.UpdateConfigPropertyOutputReference;
    putUpdateConfig(value: TfNodeGroup.UpdateConfigProperty): void;
    resetUpdateConfig(): void;
    get updateConfigInput(): TfNodeGroup.UpdateConfigProperty | undefined;
    private _warmPoolConfig;
    get warmPoolConfig(): TfNodeGroup.WarmPoolConfigPropertyOutputReference;
    putWarmPoolConfig(value: TfNodeGroup.WarmPoolConfigProperty): void;
    resetWarmPoolConfig(): void;
    get warmPoolConfigInput(): TfNodeGroup.WarmPoolConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfNodeGroupAutoscalingGroupsPropertyToTerraform(struct?: TfNodeGroup.AutoscalingGroupsProperty): any;
export declare function tfNodeGroupAutoscalingGroupsPropertyToHclTerraform(struct?: TfNodeGroup.AutoscalingGroupsProperty): any;
export declare function tfNodeGroupResourcesPropertyToTerraform(struct?: TfNodeGroup.ResourcesProperty): any;
export declare function tfNodeGroupResourcesPropertyToHclTerraform(struct?: TfNodeGroup.ResourcesProperty): any;
export declare function tfNodeGroupLaunchTemplatePropertyToTerraform(struct?: TfNodeGroup.LaunchTemplatePropertyOutputReference | TfNodeGroup.LaunchTemplateProperty): any;
export declare function tfNodeGroupLaunchTemplatePropertyToHclTerraform(struct?: TfNodeGroup.LaunchTemplatePropertyOutputReference | TfNodeGroup.LaunchTemplateProperty): any;
export declare function tfNodeGroupNodeRepairConfigOverridesPropertyToTerraform(struct?: TfNodeGroup.NodeRepairConfigOverridesProperty | cdktn.IResolvable): any;
export declare function tfNodeGroupNodeRepairConfigOverridesPropertyToHclTerraform(struct?: TfNodeGroup.NodeRepairConfigOverridesProperty | cdktn.IResolvable): any;
export declare function tfNodeGroupNodeRepairConfigPropertyToTerraform(struct?: TfNodeGroup.NodeRepairConfigPropertyOutputReference | TfNodeGroup.NodeRepairConfigProperty): any;
export declare function tfNodeGroupNodeRepairConfigPropertyToHclTerraform(struct?: TfNodeGroup.NodeRepairConfigPropertyOutputReference | TfNodeGroup.NodeRepairConfigProperty): any;
export declare function tfNodeGroupRemoteAccessPropertyToTerraform(struct?: TfNodeGroup.RemoteAccessPropertyOutputReference | TfNodeGroup.RemoteAccessProperty): any;
export declare function tfNodeGroupRemoteAccessPropertyToHclTerraform(struct?: TfNodeGroup.RemoteAccessPropertyOutputReference | TfNodeGroup.RemoteAccessProperty): any;
export declare function tfNodeGroupScalingConfigPropertyToTerraform(struct?: TfNodeGroup.ScalingConfigPropertyOutputReference | TfNodeGroup.ScalingConfigProperty): any;
export declare function tfNodeGroupScalingConfigPropertyToHclTerraform(struct?: TfNodeGroup.ScalingConfigPropertyOutputReference | TfNodeGroup.ScalingConfigProperty): any;
export declare function tfNodeGroupTaintPropertyToTerraform(struct?: TfNodeGroup.TaintProperty | cdktn.IResolvable): any;
export declare function tfNodeGroupTaintPropertyToHclTerraform(struct?: TfNodeGroup.TaintProperty | cdktn.IResolvable): any;
export declare function tfNodeGroupTimeoutsPropertyToTerraform(struct?: TfNodeGroup.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfNodeGroupTimeoutsPropertyToHclTerraform(struct?: TfNodeGroup.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfNodeGroupUpdateConfigPropertyToTerraform(struct?: TfNodeGroup.UpdateConfigPropertyOutputReference | TfNodeGroup.UpdateConfigProperty): any;
export declare function tfNodeGroupUpdateConfigPropertyToHclTerraform(struct?: TfNodeGroup.UpdateConfigPropertyOutputReference | TfNodeGroup.UpdateConfigProperty): any;
export declare function tfNodeGroupWarmPoolConfigPropertyToTerraform(struct?: TfNodeGroup.WarmPoolConfigPropertyOutputReference | TfNodeGroup.WarmPoolConfigProperty): any;
export declare function tfNodeGroupWarmPoolConfigPropertyToHclTerraform(struct?: TfNodeGroup.WarmPoolConfigPropertyOutputReference | TfNodeGroup.WarmPoolConfigProperty): any;
export declare namespace TfNodeGroup {
    interface AutoscalingGroupsProperty {
    }
    class AutoscalingGroupsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AutoscalingGroupsProperty | undefined;
        set internalValue(value: AutoscalingGroupsProperty | undefined);
        get name(): string;
    }
    class AutoscalingGroupsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AutoscalingGroupsPropertyOutputReference;
    }
    interface ResourcesProperty {
    }
    class ResourcesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourcesProperty | undefined;
        set internalValue(value: ResourcesProperty | undefined);
        private _autoscalingGroups;
        get autoscalingGroups(): AutoscalingGroupsPropertyList;
        get remoteAccessSecurityGroupId(): string;
    }
    class ResourcesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourcesPropertyOutputReference;
    }
    interface LaunchTemplateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#id TfNodeGroup#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#name TfNodeGroup#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#version TfNodeGroup#version}
        */
        readonly version: string;
    }
    class LaunchTemplatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LaunchTemplateProperty | undefined;
        set internalValue(value: LaunchTemplateProperty | undefined);
        private _id?;
        get id(): string;
        set id(value: string);
        resetId(): void;
        get idInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _version?;
        get version(): string;
        set version(value: string);
        get versionInput(): string | undefined;
    }
    interface NodeRepairConfigOverridesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#min_repair_wait_time_mins TfNodeGroup#min_repair_wait_time_mins}
        */
        readonly minRepairWaitTimeMins: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#node_monitoring_condition TfNodeGroup#node_monitoring_condition}
        */
        readonly nodeMonitoringCondition: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#node_unhealthy_reason TfNodeGroup#node_unhealthy_reason}
        */
        readonly nodeUnhealthyReason: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#repair_action TfNodeGroup#repair_action}
        */
        readonly repairAction: string;
    }
    class NodeRepairConfigOverridesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NodeRepairConfigOverridesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NodeRepairConfigOverridesProperty | cdktn.IResolvable | undefined);
        private _minRepairWaitTimeMins?;
        get minRepairWaitTimeMins(): number;
        set minRepairWaitTimeMins(value: number);
        get minRepairWaitTimeMinsInput(): number | undefined;
        private _nodeMonitoringCondition?;
        get nodeMonitoringCondition(): string;
        set nodeMonitoringCondition(value: string);
        get nodeMonitoringConditionInput(): string | undefined;
        private _nodeUnhealthyReason?;
        get nodeUnhealthyReason(): string;
        set nodeUnhealthyReason(value: string);
        get nodeUnhealthyReasonInput(): string | undefined;
        private _repairAction?;
        get repairAction(): string;
        set repairAction(value: string);
        get repairActionInput(): string | undefined;
    }
    class NodeRepairConfigOverridesPropertyList extends cdktn.ComplexList {
        internalValue?: NodeRepairConfigOverridesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NodeRepairConfigOverridesPropertyOutputReference;
    }
    interface NodeRepairConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#enabled TfNodeGroup#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#max_parallel_nodes_repaired_count TfNodeGroup#max_parallel_nodes_repaired_count}
        */
        readonly maxParallelNodesRepairedCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#max_parallel_nodes_repaired_percentage TfNodeGroup#max_parallel_nodes_repaired_percentage}
        */
        readonly maxParallelNodesRepairedPercentage?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#max_unhealthy_node_threshold_count TfNodeGroup#max_unhealthy_node_threshold_count}
        */
        readonly maxUnhealthyNodeThresholdCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#max_unhealthy_node_threshold_percentage TfNodeGroup#max_unhealthy_node_threshold_percentage}
        */
        readonly maxUnhealthyNodeThresholdPercentage?: number;
        /**
        * node_repair_config_overrides block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#node_repair_config_overrides TfNodeGroup#node_repair_config_overrides}
        */
        readonly nodeRepairConfigOverrides?: NodeRepairConfigOverridesProperty[] | cdktn.IResolvable;
    }
    class NodeRepairConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NodeRepairConfigProperty | undefined;
        set internalValue(value: NodeRepairConfigProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _maxParallelNodesRepairedCount?;
        get maxParallelNodesRepairedCount(): number;
        set maxParallelNodesRepairedCount(value: number);
        resetMaxParallelNodesRepairedCount(): void;
        get maxParallelNodesRepairedCountInput(): number | undefined;
        private _maxParallelNodesRepairedPercentage?;
        get maxParallelNodesRepairedPercentage(): number;
        set maxParallelNodesRepairedPercentage(value: number);
        resetMaxParallelNodesRepairedPercentage(): void;
        get maxParallelNodesRepairedPercentageInput(): number | undefined;
        private _maxUnhealthyNodeThresholdCount?;
        get maxUnhealthyNodeThresholdCount(): number;
        set maxUnhealthyNodeThresholdCount(value: number);
        resetMaxUnhealthyNodeThresholdCount(): void;
        get maxUnhealthyNodeThresholdCountInput(): number | undefined;
        private _maxUnhealthyNodeThresholdPercentage?;
        get maxUnhealthyNodeThresholdPercentage(): number;
        set maxUnhealthyNodeThresholdPercentage(value: number);
        resetMaxUnhealthyNodeThresholdPercentage(): void;
        get maxUnhealthyNodeThresholdPercentageInput(): number | undefined;
        private _nodeRepairConfigOverrides;
        get nodeRepairConfigOverrides(): NodeRepairConfigOverridesPropertyList;
        putNodeRepairConfigOverrides(value: NodeRepairConfigOverridesProperty[] | cdktn.IResolvable): void;
        resetNodeRepairConfigOverrides(): void;
        get nodeRepairConfigOverridesInput(): cdktn.IResolvable | NodeRepairConfigOverridesProperty[] | undefined;
    }
    interface RemoteAccessProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#ec2_ssh_key TfNodeGroup#ec2_ssh_key}
        */
        readonly ec2SshKey?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#source_security_group_ids TfNodeGroup#source_security_group_ids}
        */
        readonly sourceSecurityGroupIds?: string[];
    }
    class RemoteAccessPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RemoteAccessProperty | undefined;
        set internalValue(value: RemoteAccessProperty | undefined);
        private _ec2SshKey?;
        get ec2SshKey(): string;
        set ec2SshKey(value: string);
        resetEc2SshKey(): void;
        get ec2SshKeyInput(): string | undefined;
        private _sourceSecurityGroupIds?;
        get sourceSecurityGroupIds(): string[];
        set sourceSecurityGroupIds(value: string[]);
        resetSourceSecurityGroupIds(): void;
        get sourceSecurityGroupIdsInput(): string[] | undefined;
    }
    interface ScalingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#desired_size TfNodeGroup#desired_size}
        */
        readonly desiredSize: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#max_size TfNodeGroup#max_size}
        */
        readonly maxSize: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#min_size TfNodeGroup#min_size}
        */
        readonly minSize: number;
    }
    class ScalingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ScalingConfigProperty | undefined;
        set internalValue(value: ScalingConfigProperty | undefined);
        private _desiredSize?;
        get desiredSize(): number;
        set desiredSize(value: number);
        get desiredSizeInput(): number | undefined;
        private _maxSize?;
        get maxSize(): number;
        set maxSize(value: number);
        get maxSizeInput(): number | undefined;
        private _minSize?;
        get minSize(): number;
        set minSize(value: number);
        get minSizeInput(): number | undefined;
    }
    interface TaintProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#effect TfNodeGroup#effect}
        */
        readonly effect: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#key TfNodeGroup#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#value TfNodeGroup#value}
        */
        readonly value?: string;
    }
    class TaintPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TaintProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TaintProperty | cdktn.IResolvable | undefined);
        private _effect?;
        get effect(): string;
        set effect(value: string);
        get effectInput(): string | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        resetValue(): void;
        get valueInput(): string | undefined;
    }
    class TaintPropertyList extends cdktn.ComplexList {
        internalValue?: TaintProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TaintPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#create TfNodeGroup#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#delete TfNodeGroup#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#update TfNodeGroup#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface UpdateConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#max_unavailable TfNodeGroup#max_unavailable}
        */
        readonly maxUnavailable?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#max_unavailable_percentage TfNodeGroup#max_unavailable_percentage}
        */
        readonly maxUnavailablePercentage?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#update_strategy TfNodeGroup#update_strategy}
        */
        readonly updateStrategy?: string;
    }
    class UpdateConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UpdateConfigProperty | undefined;
        set internalValue(value: UpdateConfigProperty | undefined);
        private _maxUnavailable?;
        get maxUnavailable(): number;
        set maxUnavailable(value: number);
        resetMaxUnavailable(): void;
        get maxUnavailableInput(): number | undefined;
        private _maxUnavailablePercentage?;
        get maxUnavailablePercentage(): number;
        set maxUnavailablePercentage(value: number);
        resetMaxUnavailablePercentage(): void;
        get maxUnavailablePercentageInput(): number | undefined;
        private _updateStrategy?;
        get updateStrategy(): string;
        set updateStrategy(value: string);
        resetUpdateStrategy(): void;
        get updateStrategyInput(): string | undefined;
    }
    interface WarmPoolConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#max_group_prepared_capacity TfNodeGroup#max_group_prepared_capacity}
        */
        readonly maxGroupPreparedCapacity?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#min_size TfNodeGroup#min_size}
        */
        readonly minSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#pool_state TfNodeGroup#pool_state}
        */
        readonly poolState?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_node_group#reuse_on_scale_in TfNodeGroup#reuse_on_scale_in}
        */
        readonly reuseOnScaleIn?: boolean | cdktn.IResolvable;
    }
    class WarmPoolConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): WarmPoolConfigProperty | undefined;
        set internalValue(value: WarmPoolConfigProperty | undefined);
        private _maxGroupPreparedCapacity?;
        get maxGroupPreparedCapacity(): number;
        set maxGroupPreparedCapacity(value: number);
        resetMaxGroupPreparedCapacity(): void;
        get maxGroupPreparedCapacityInput(): number | undefined;
        private _minSize?;
        get minSize(): number;
        set minSize(value: number);
        resetMinSize(): void;
        get minSizeInput(): number | undefined;
        private _poolState?;
        get poolState(): string;
        set poolState(value: string);
        resetPoolState(): void;
        get poolStateInput(): string | undefined;
        private _reuseOnScaleIn?;
        get reuseOnScaleIn(): boolean | cdktn.IResolvable;
        set reuseOnScaleIn(value: boolean | cdktn.IResolvable);
        resetReuseOnScaleIn(): void;
        get reuseOnScaleInInput(): boolean | cdktn.IResolvable | undefined;
    }
}
