import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfClusterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/eks_cluster#id DataTfCluster#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/eks_cluster#name DataTfCluster#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/eks_cluster#region DataTfCluster#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/eks_cluster#tags DataTfCluster#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/eks_cluster aws_eks_cluster}
*/
export declare class DataTfCluster extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_eks_cluster";
    /**
    * Generates CDKTN code for importing a DataTfCluster resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfCluster to import
    * @param importFromId The id of the existing DataTfCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/eks_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/eks_cluster aws_eks_cluster} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfClusterConfig
    */
    constructor(scope: Construct, id: string, config: DataTfClusterConfig);
    private _accessConfig;
    get accessConfig(): DataTfCluster.AccessConfigPropertyList;
    get arn(): string;
    private _certificateAuthority;
    get certificateAuthority(): DataTfCluster.CertificateAuthorityPropertyList;
    get clusterId(): string;
    private _computeConfig;
    get computeConfig(): DataTfCluster.ComputeConfigPropertyList;
    private _controlPlaneScalingConfig;
    get controlPlaneScalingConfig(): DataTfCluster.ControlPlaneScalingConfigPropertyList;
    get createdAt(): string;
    get deletionProtection(): cdktn.IResolvable;
    get enabledClusterLogTypes(): string[];
    get endpoint(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _identity;
    get identity(): DataTfCluster.IdentityPropertyList;
    private _kubeApiServerConfig;
    get kubeApiServerConfig(): DataTfCluster.KubeApiServerConfigPropertyList;
    private _kubeControllerManagerConfig;
    get kubeControllerManagerConfig(): DataTfCluster.KubeControllerManagerConfigPropertyList;
    private _kubeSchedulerConfig;
    get kubeSchedulerConfig(): DataTfCluster.KubeSchedulerConfigPropertyList;
    private _kubernetesNetworkConfig;
    get kubernetesNetworkConfig(): DataTfCluster.KubernetesNetworkConfigPropertyList;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _outpostConfig;
    get outpostConfig(): DataTfCluster.OutpostConfigPropertyList;
    get platformVersion(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _remoteNetworkConfig;
    get remoteNetworkConfig(): DataTfCluster.RemoteNetworkConfigPropertyList;
    get roleArn(): string;
    get status(): string;
    private _storageConfig;
    get storageConfig(): DataTfCluster.StorageConfigPropertyList;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _upgradePolicy;
    get upgradePolicy(): DataTfCluster.UpgradePolicyPropertyList;
    get version(): string;
    private _vpcConfig;
    get vpcConfig(): DataTfCluster.VpcConfigPropertyList;
    private _zonalShiftConfig;
    get zonalShiftConfig(): DataTfCluster.ZonalShiftConfigPropertyList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfClusterAccessConfigPropertyToTerraform(struct?: DataTfCluster.AccessConfigProperty): any;
export declare function dataTfClusterAccessConfigPropertyToHclTerraform(struct?: DataTfCluster.AccessConfigProperty): any;
export declare function dataTfClusterCertificateAuthorityPropertyToTerraform(struct?: DataTfCluster.CertificateAuthorityProperty): any;
export declare function dataTfClusterCertificateAuthorityPropertyToHclTerraform(struct?: DataTfCluster.CertificateAuthorityProperty): any;
export declare function dataTfClusterComputeConfigPropertyToTerraform(struct?: DataTfCluster.ComputeConfigProperty): any;
export declare function dataTfClusterComputeConfigPropertyToHclTerraform(struct?: DataTfCluster.ComputeConfigProperty): any;
export declare function dataTfClusterControlPlaneScalingConfigPropertyToTerraform(struct?: DataTfCluster.ControlPlaneScalingConfigProperty): any;
export declare function dataTfClusterControlPlaneScalingConfigPropertyToHclTerraform(struct?: DataTfCluster.ControlPlaneScalingConfigProperty): any;
export declare function dataTfClusterOidcPropertyToTerraform(struct?: DataTfCluster.OidcProperty): any;
export declare function dataTfClusterOidcPropertyToHclTerraform(struct?: DataTfCluster.OidcProperty): any;
export declare function dataTfClusterIdentityPropertyToTerraform(struct?: DataTfCluster.IdentityProperty): any;
export declare function dataTfClusterIdentityPropertyToHclTerraform(struct?: DataTfCluster.IdentityProperty): any;
export declare function dataTfClusterServiceNodePortRangePropertyToTerraform(struct?: DataTfCluster.ServiceNodePortRangeProperty): any;
export declare function dataTfClusterServiceNodePortRangePropertyToHclTerraform(struct?: DataTfCluster.ServiceNodePortRangeProperty): any;
export declare function dataTfClusterKubeApiServerConfigPropertyToTerraform(struct?: DataTfCluster.KubeApiServerConfigProperty): any;
export declare function dataTfClusterKubeApiServerConfigPropertyToHclTerraform(struct?: DataTfCluster.KubeApiServerConfigProperty): any;
export declare function dataTfClusterHorizontalPodAutoscalerControllerConfigPropertyToTerraform(struct?: DataTfCluster.HorizontalPodAutoscalerControllerConfigProperty): any;
export declare function dataTfClusterHorizontalPodAutoscalerControllerConfigPropertyToHclTerraform(struct?: DataTfCluster.HorizontalPodAutoscalerControllerConfigProperty): any;
export declare function dataTfClusterKubeControllerManagerConfigPropertyToTerraform(struct?: DataTfCluster.KubeControllerManagerConfigProperty): any;
export declare function dataTfClusterKubeControllerManagerConfigPropertyToHclTerraform(struct?: DataTfCluster.KubeControllerManagerConfigProperty): any;
export declare function dataTfClusterResourcePropertyToTerraform(struct?: DataTfCluster.ResourceProperty): any;
export declare function dataTfClusterResourcePropertyToHclTerraform(struct?: DataTfCluster.ResourceProperty): any;
export declare function dataTfClusterScoringStrategyPropertyToTerraform(struct?: DataTfCluster.ScoringStrategyProperty): any;
export declare function dataTfClusterScoringStrategyPropertyToHclTerraform(struct?: DataTfCluster.ScoringStrategyProperty): any;
export declare function dataTfClusterNodeResourcesFitPropertyToTerraform(struct?: DataTfCluster.NodeResourcesFitProperty): any;
export declare function dataTfClusterNodeResourcesFitPropertyToHclTerraform(struct?: DataTfCluster.NodeResourcesFitProperty): any;
export declare function dataTfClusterKubeSchedulerConfigPropertyToTerraform(struct?: DataTfCluster.KubeSchedulerConfigProperty): any;
export declare function dataTfClusterKubeSchedulerConfigPropertyToHclTerraform(struct?: DataTfCluster.KubeSchedulerConfigProperty): any;
export declare function dataTfClusterElasticLoadBalancingPropertyToTerraform(struct?: DataTfCluster.ElasticLoadBalancingProperty): any;
export declare function dataTfClusterElasticLoadBalancingPropertyToHclTerraform(struct?: DataTfCluster.ElasticLoadBalancingProperty): any;
export declare function dataTfClusterKubernetesNetworkConfigPropertyToTerraform(struct?: DataTfCluster.KubernetesNetworkConfigProperty): any;
export declare function dataTfClusterKubernetesNetworkConfigPropertyToHclTerraform(struct?: DataTfCluster.KubernetesNetworkConfigProperty): any;
export declare function dataTfClusterControlPlanePlacementPropertyToTerraform(struct?: DataTfCluster.ControlPlanePlacementProperty): any;
export declare function dataTfClusterControlPlanePlacementPropertyToHclTerraform(struct?: DataTfCluster.ControlPlanePlacementProperty): any;
export declare function dataTfClusterEtcdPlacementPropertyToTerraform(struct?: DataTfCluster.EtcdPlacementProperty): any;
export declare function dataTfClusterEtcdPlacementPropertyToHclTerraform(struct?: DataTfCluster.EtcdPlacementProperty): any;
export declare function dataTfClusterOutpostConfigPropertyToTerraform(struct?: DataTfCluster.OutpostConfigProperty): any;
export declare function dataTfClusterOutpostConfigPropertyToHclTerraform(struct?: DataTfCluster.OutpostConfigProperty): any;
export declare function dataTfClusterRemoteNodeNetworksPropertyToTerraform(struct?: DataTfCluster.RemoteNodeNetworksProperty): any;
export declare function dataTfClusterRemoteNodeNetworksPropertyToHclTerraform(struct?: DataTfCluster.RemoteNodeNetworksProperty): any;
export declare function dataTfClusterRemotePodNetworksPropertyToTerraform(struct?: DataTfCluster.RemotePodNetworksProperty): any;
export declare function dataTfClusterRemotePodNetworksPropertyToHclTerraform(struct?: DataTfCluster.RemotePodNetworksProperty): any;
export declare function dataTfClusterRemoteNetworkConfigPropertyToTerraform(struct?: DataTfCluster.RemoteNetworkConfigProperty): any;
export declare function dataTfClusterRemoteNetworkConfigPropertyToHclTerraform(struct?: DataTfCluster.RemoteNetworkConfigProperty): any;
export declare function dataTfClusterBlockStoragePropertyToTerraform(struct?: DataTfCluster.BlockStorageProperty): any;
export declare function dataTfClusterBlockStoragePropertyToHclTerraform(struct?: DataTfCluster.BlockStorageProperty): any;
export declare function dataTfClusterStorageConfigPropertyToTerraform(struct?: DataTfCluster.StorageConfigProperty): any;
export declare function dataTfClusterStorageConfigPropertyToHclTerraform(struct?: DataTfCluster.StorageConfigProperty): any;
export declare function dataTfClusterUpgradePolicyPropertyToTerraform(struct?: DataTfCluster.UpgradePolicyProperty): any;
export declare function dataTfClusterUpgradePolicyPropertyToHclTerraform(struct?: DataTfCluster.UpgradePolicyProperty): any;
export declare function dataTfClusterVpcConfigPropertyToTerraform(struct?: DataTfCluster.VpcConfigProperty): any;
export declare function dataTfClusterVpcConfigPropertyToHclTerraform(struct?: DataTfCluster.VpcConfigProperty): any;
export declare function dataTfClusterZonalShiftConfigPropertyToTerraform(struct?: DataTfCluster.ZonalShiftConfigProperty): any;
export declare function dataTfClusterZonalShiftConfigPropertyToHclTerraform(struct?: DataTfCluster.ZonalShiftConfigProperty): any;
export declare namespace DataTfCluster {
    interface AccessConfigProperty {
    }
    class AccessConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AccessConfigProperty | undefined;
        set internalValue(value: AccessConfigProperty | undefined);
        get authenticationMode(): string;
        get bootstrapClusterCreatorAdminPermissions(): cdktn.IResolvable;
    }
    class AccessConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AccessConfigPropertyOutputReference;
    }
    interface CertificateAuthorityProperty {
    }
    class CertificateAuthorityPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CertificateAuthorityProperty | undefined;
        set internalValue(value: CertificateAuthorityProperty | undefined);
        get data(): string;
    }
    class CertificateAuthorityPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CertificateAuthorityPropertyOutputReference;
    }
    interface ComputeConfigProperty {
    }
    class ComputeConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ComputeConfigProperty | undefined;
        set internalValue(value: ComputeConfigProperty | undefined);
        get enabled(): cdktn.IResolvable;
        get nodePools(): string[];
        get nodeRoleArn(): string;
    }
    class ComputeConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ComputeConfigPropertyOutputReference;
    }
    interface ControlPlaneScalingConfigProperty {
    }
    class ControlPlaneScalingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ControlPlaneScalingConfigProperty | undefined;
        set internalValue(value: ControlPlaneScalingConfigProperty | undefined);
        get tier(): string;
    }
    class ControlPlaneScalingConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ControlPlaneScalingConfigPropertyOutputReference;
    }
    interface OidcProperty {
    }
    class OidcPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OidcProperty | undefined;
        set internalValue(value: OidcProperty | undefined);
        get issuer(): string;
    }
    class OidcPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OidcPropertyOutputReference;
    }
    interface IdentityProperty {
    }
    class IdentityPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IdentityProperty | undefined;
        set internalValue(value: IdentityProperty | undefined);
        private _oidc;
        get oidc(): OidcPropertyList;
    }
    class IdentityPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IdentityPropertyOutputReference;
    }
    interface ServiceNodePortRangeProperty {
    }
    class ServiceNodePortRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ServiceNodePortRangeProperty | undefined;
        set internalValue(value: ServiceNodePortRangeProperty | undefined);
        get maxPort(): number;
        get minPort(): number;
    }
    class ServiceNodePortRangePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ServiceNodePortRangePropertyOutputReference;
    }
    interface KubeApiServerConfigProperty {
    }
    class KubeApiServerConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KubeApiServerConfigProperty | undefined;
        set internalValue(value: KubeApiServerConfigProperty | undefined);
        get eventTtl(): string;
        private _serviceNodePortRange;
        get serviceNodePortRange(): ServiceNodePortRangePropertyList;
    }
    class KubeApiServerConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KubeApiServerConfigPropertyOutputReference;
    }
    interface HorizontalPodAutoscalerControllerConfigProperty {
    }
    class HorizontalPodAutoscalerControllerConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HorizontalPodAutoscalerControllerConfigProperty | undefined;
        set internalValue(value: HorizontalPodAutoscalerControllerConfigProperty | undefined);
        get horizontalPodAutoscalerSyncPeriod(): string;
    }
    class HorizontalPodAutoscalerControllerConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HorizontalPodAutoscalerControllerConfigPropertyOutputReference;
    }
    interface KubeControllerManagerConfigProperty {
    }
    class KubeControllerManagerConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KubeControllerManagerConfigProperty | undefined;
        set internalValue(value: KubeControllerManagerConfigProperty | undefined);
        private _horizontalPodAutoscalerControllerConfig;
        get horizontalPodAutoscalerControllerConfig(): HorizontalPodAutoscalerControllerConfigPropertyList;
    }
    class KubeControllerManagerConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KubeControllerManagerConfigPropertyOutputReference;
    }
    interface ResourceProperty {
    }
    class ResourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceProperty | undefined;
        set internalValue(value: ResourceProperty | undefined);
        get name(): string;
        get weight(): number;
    }
    class ResourcePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourcePropertyOutputReference;
    }
    interface ScoringStrategyProperty {
    }
    class ScoringStrategyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ScoringStrategyProperty | undefined;
        set internalValue(value: ScoringStrategyProperty | undefined);
        private _resource;
        get resource(): ResourcePropertyList;
        get type(): string;
    }
    class ScoringStrategyPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ScoringStrategyPropertyOutputReference;
    }
    interface NodeResourcesFitProperty {
    }
    class NodeResourcesFitPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NodeResourcesFitProperty | undefined;
        set internalValue(value: NodeResourcesFitProperty | undefined);
        private _scoringStrategy;
        get scoringStrategy(): ScoringStrategyPropertyList;
    }
    class NodeResourcesFitPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NodeResourcesFitPropertyOutputReference;
    }
    interface KubeSchedulerConfigProperty {
    }
    class KubeSchedulerConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KubeSchedulerConfigProperty | undefined;
        set internalValue(value: KubeSchedulerConfigProperty | undefined);
        private _nodeResourcesFit;
        get nodeResourcesFit(): NodeResourcesFitPropertyList;
    }
    class KubeSchedulerConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KubeSchedulerConfigPropertyOutputReference;
    }
    interface ElasticLoadBalancingProperty {
    }
    class ElasticLoadBalancingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ElasticLoadBalancingProperty | undefined;
        set internalValue(value: ElasticLoadBalancingProperty | undefined);
        get enabled(): cdktn.IResolvable;
    }
    class ElasticLoadBalancingPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ElasticLoadBalancingPropertyOutputReference;
    }
    interface KubernetesNetworkConfigProperty {
    }
    class KubernetesNetworkConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KubernetesNetworkConfigProperty | undefined;
        set internalValue(value: KubernetesNetworkConfigProperty | undefined);
        private _elasticLoadBalancing;
        get elasticLoadBalancing(): ElasticLoadBalancingPropertyList;
        get ipFamily(): string;
        get serviceIpv4Cidr(): string;
        get serviceIpv6Cidr(): string;
    }
    class KubernetesNetworkConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KubernetesNetworkConfigPropertyOutputReference;
    }
    interface ControlPlanePlacementProperty {
    }
    class ControlPlanePlacementPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ControlPlanePlacementProperty | undefined;
        set internalValue(value: ControlPlanePlacementProperty | undefined);
        get groupName(): string;
        get spreadLevel(): string;
    }
    class ControlPlanePlacementPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ControlPlanePlacementPropertyOutputReference;
    }
    interface EtcdPlacementProperty {
    }
    class EtcdPlacementPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EtcdPlacementProperty | undefined;
        set internalValue(value: EtcdPlacementProperty | undefined);
        get spreadLevel(): string;
    }
    class EtcdPlacementPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EtcdPlacementPropertyOutputReference;
    }
    interface OutpostConfigProperty {
    }
    class OutpostConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OutpostConfigProperty | undefined;
        set internalValue(value: OutpostConfigProperty | undefined);
        get controlPlaneInstanceType(): string;
        private _controlPlanePlacement;
        get controlPlanePlacement(): ControlPlanePlacementPropertyList;
        get etcdInstanceType(): string;
        private _etcdPlacement;
        get etcdPlacement(): EtcdPlacementPropertyList;
        get outpostArns(): string[];
    }
    class OutpostConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OutpostConfigPropertyOutputReference;
    }
    interface RemoteNodeNetworksProperty {
    }
    class RemoteNodeNetworksPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RemoteNodeNetworksProperty | undefined;
        set internalValue(value: RemoteNodeNetworksProperty | undefined);
        get cidrs(): string[];
    }
    class RemoteNodeNetworksPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RemoteNodeNetworksPropertyOutputReference;
    }
    interface RemotePodNetworksProperty {
    }
    class RemotePodNetworksPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RemotePodNetworksProperty | undefined;
        set internalValue(value: RemotePodNetworksProperty | undefined);
        get cidrs(): string[];
    }
    class RemotePodNetworksPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RemotePodNetworksPropertyOutputReference;
    }
    interface RemoteNetworkConfigProperty {
    }
    class RemoteNetworkConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RemoteNetworkConfigProperty | undefined;
        set internalValue(value: RemoteNetworkConfigProperty | undefined);
        private _remoteNodeNetworks;
        get remoteNodeNetworks(): RemoteNodeNetworksPropertyList;
        private _remotePodNetworks;
        get remotePodNetworks(): RemotePodNetworksPropertyList;
    }
    class RemoteNetworkConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RemoteNetworkConfigPropertyOutputReference;
    }
    interface BlockStorageProperty {
    }
    class BlockStoragePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BlockStorageProperty | undefined;
        set internalValue(value: BlockStorageProperty | undefined);
        get enabled(): cdktn.IResolvable;
    }
    class BlockStoragePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BlockStoragePropertyOutputReference;
    }
    interface StorageConfigProperty {
    }
    class StorageConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StorageConfigProperty | undefined;
        set internalValue(value: StorageConfigProperty | undefined);
        private _blockStorage;
        get blockStorage(): BlockStoragePropertyList;
    }
    class StorageConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StorageConfigPropertyOutputReference;
    }
    interface UpgradePolicyProperty {
    }
    class UpgradePolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): UpgradePolicyProperty | undefined;
        set internalValue(value: UpgradePolicyProperty | undefined);
        get supportType(): string;
    }
    class UpgradePolicyPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): UpgradePolicyPropertyOutputReference;
    }
    interface VpcConfigProperty {
    }
    class VpcConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VpcConfigProperty | undefined;
        set internalValue(value: VpcConfigProperty | undefined);
        get clusterSecurityGroupId(): string;
        get controlPlaneEgressMode(): string;
        get endpointPrivateAccess(): cdktn.IResolvable;
        get endpointPublicAccess(): cdktn.IResolvable;
        get publicAccessCidrs(): string[];
        get securityGroupIds(): string[];
        get subnetIds(): string[];
        get vpcId(): string;
    }
    class VpcConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VpcConfigPropertyOutputReference;
    }
    interface ZonalShiftConfigProperty {
    }
    class ZonalShiftConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ZonalShiftConfigProperty | undefined;
        set internalValue(value: ZonalShiftConfigProperty | undefined);
        get enabled(): cdktn.IResolvable;
    }
    class ZonalShiftConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ZonalShiftConfigPropertyOutputReference;
    }
}
