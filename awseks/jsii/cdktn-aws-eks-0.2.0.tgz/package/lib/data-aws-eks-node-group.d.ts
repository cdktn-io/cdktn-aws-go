import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfNodeGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/eks_node_group#cluster_name DataTfNodeGroup#cluster_name}
    */
    readonly clusterName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/eks_node_group#id DataTfNodeGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/eks_node_group#node_group_name DataTfNodeGroup#node_group_name}
    */
    readonly nodeGroupName: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/eks_node_group#region DataTfNodeGroup#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/eks_node_group#tags DataTfNodeGroup#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/eks_node_group aws_eks_node_group}
*/
export declare class DataTfNodeGroup extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_eks_node_group";
    /**
    * Generates CDKTN code for importing a DataTfNodeGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfNodeGroup to import
    * @param importFromId The id of the existing DataTfNodeGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/eks_node_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfNodeGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/eks_node_group aws_eks_node_group} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfNodeGroupConfig
    */
    constructor(scope: Construct, id: string, config: DataTfNodeGroupConfig);
    get amiType(): string;
    get arn(): string;
    get capacityType(): string;
    private _clusterName?;
    get clusterName(): string;
    set clusterName(value: string);
    get clusterNameInput(): string | undefined;
    get diskSize(): number;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get instanceTypes(): string[];
    private _labels;
    get labels(): cdktn.StringMap;
    private _launchTemplate;
    get launchTemplate(): DataTfNodeGroup.LaunchTemplatePropertyList;
    private _nodeGroupName?;
    get nodeGroupName(): string;
    set nodeGroupName(value: string);
    get nodeGroupNameInput(): string | undefined;
    get nodeRoleArn(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get releaseVersion(): string;
    private _remoteAccess;
    get remoteAccess(): DataTfNodeGroup.RemoteAccessPropertyList;
    private _resources;
    get resources(): DataTfNodeGroup.ResourcesPropertyList;
    private _scalingConfig;
    get scalingConfig(): DataTfNodeGroup.ScalingConfigPropertyList;
    get status(): string;
    get subnetIds(): string[];
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _taints;
    get taints(): DataTfNodeGroup.TaintsPropertyList;
    private _updateConfig;
    get updateConfig(): DataTfNodeGroup.UpdateConfigPropertyList;
    get version(): string;
    private _warmPoolConfig;
    get warmPoolConfig(): DataTfNodeGroup.WarmPoolConfigPropertyList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfNodeGroupLaunchTemplatePropertyToTerraform(struct?: DataTfNodeGroup.LaunchTemplateProperty): any;
export declare function dataTfNodeGroupLaunchTemplatePropertyToHclTerraform(struct?: DataTfNodeGroup.LaunchTemplateProperty): any;
export declare function dataTfNodeGroupRemoteAccessPropertyToTerraform(struct?: DataTfNodeGroup.RemoteAccessProperty): any;
export declare function dataTfNodeGroupRemoteAccessPropertyToHclTerraform(struct?: DataTfNodeGroup.RemoteAccessProperty): any;
export declare function dataTfNodeGroupAutoscalingGroupsPropertyToTerraform(struct?: DataTfNodeGroup.AutoscalingGroupsProperty): any;
export declare function dataTfNodeGroupAutoscalingGroupsPropertyToHclTerraform(struct?: DataTfNodeGroup.AutoscalingGroupsProperty): any;
export declare function dataTfNodeGroupResourcesPropertyToTerraform(struct?: DataTfNodeGroup.ResourcesProperty): any;
export declare function dataTfNodeGroupResourcesPropertyToHclTerraform(struct?: DataTfNodeGroup.ResourcesProperty): any;
export declare function dataTfNodeGroupScalingConfigPropertyToTerraform(struct?: DataTfNodeGroup.ScalingConfigProperty): any;
export declare function dataTfNodeGroupScalingConfigPropertyToHclTerraform(struct?: DataTfNodeGroup.ScalingConfigProperty): any;
export declare function dataTfNodeGroupTaintsPropertyToTerraform(struct?: DataTfNodeGroup.TaintsProperty): any;
export declare function dataTfNodeGroupTaintsPropertyToHclTerraform(struct?: DataTfNodeGroup.TaintsProperty): any;
export declare function dataTfNodeGroupUpdateConfigPropertyToTerraform(struct?: DataTfNodeGroup.UpdateConfigProperty): any;
export declare function dataTfNodeGroupUpdateConfigPropertyToHclTerraform(struct?: DataTfNodeGroup.UpdateConfigProperty): any;
export declare function dataTfNodeGroupWarmPoolConfigPropertyToTerraform(struct?: DataTfNodeGroup.WarmPoolConfigProperty): any;
export declare function dataTfNodeGroupWarmPoolConfigPropertyToHclTerraform(struct?: DataTfNodeGroup.WarmPoolConfigProperty): any;
export declare namespace DataTfNodeGroup {
    interface LaunchTemplateProperty {
    }
    class LaunchTemplatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LaunchTemplateProperty | undefined;
        set internalValue(value: LaunchTemplateProperty | undefined);
        get id(): string;
        get name(): string;
        get version(): string;
    }
    class LaunchTemplatePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LaunchTemplatePropertyOutputReference;
    }
    interface RemoteAccessProperty {
    }
    class RemoteAccessPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RemoteAccessProperty | undefined;
        set internalValue(value: RemoteAccessProperty | undefined);
        get ec2SshKey(): string;
        get sourceSecurityGroupIds(): string[];
    }
    class RemoteAccessPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RemoteAccessPropertyOutputReference;
    }
    interface AutoscalingGroupsProperty {
    }
    class AutoscalingGroupsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AutoscalingGroupsProperty | undefined;
        set internalValue(value: AutoscalingGroupsProperty | undefined);
        get name(): string;
    }
    class AutoscalingGroupsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AutoscalingGroupsPropertyOutputReference;
    }
    interface ResourcesProperty {
    }
    class ResourcesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourcesProperty | undefined;
        set internalValue(value: ResourcesProperty | undefined);
        private _autoscalingGroups;
        get autoscalingGroups(): AutoscalingGroupsPropertyList;
        get remoteAccessSecurityGroupId(): string;
    }
    class ResourcesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourcesPropertyOutputReference;
    }
    interface ScalingConfigProperty {
    }
    class ScalingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ScalingConfigProperty | undefined;
        set internalValue(value: ScalingConfigProperty | undefined);
        get desiredSize(): number;
        get maxSize(): number;
        get minSize(): number;
    }
    class ScalingConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ScalingConfigPropertyOutputReference;
    }
    interface TaintsProperty {
    }
    class TaintsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TaintsProperty | undefined;
        set internalValue(value: TaintsProperty | undefined);
        get effect(): string;
        get key(): string;
        get value(): string;
    }
    class TaintsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TaintsPropertyOutputReference;
    }
    interface UpdateConfigProperty {
    }
    class UpdateConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): UpdateConfigProperty | undefined;
        set internalValue(value: UpdateConfigProperty | undefined);
        get maxUnavailable(): number;
        get maxUnavailablePercentage(): number;
        get updateStrategy(): string;
    }
    class UpdateConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): UpdateConfigPropertyOutputReference;
    }
    interface WarmPoolConfigProperty {
    }
    class WarmPoolConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WarmPoolConfigProperty | undefined;
        set internalValue(value: WarmPoolConfigProperty | undefined);
        get maxGroupPreparedCapacity(): number;
        get minSize(): number;
        get poolState(): string;
        get reuseOnScaleIn(): cdktn.IResolvable;
    }
    class WarmPoolConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WarmPoolConfigPropertyOutputReference;
    }
}
