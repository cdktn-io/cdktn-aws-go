import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfClusterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#bootstrap_self_managed_addons TfCluster#bootstrap_self_managed_addons}
    */
    readonly bootstrapSelfManagedAddons?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#deletion_protection TfCluster#deletion_protection}
    */
    readonly deletionProtection?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#enabled_cluster_log_types TfCluster#enabled_cluster_log_types}
    */
    readonly enabledClusterLogTypes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#force_update_version TfCluster#force_update_version}
    */
    readonly forceUpdateVersion?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#id TfCluster#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#name TfCluster#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#region TfCluster#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#role_arn TfCluster#role_arn}
    */
    readonly roleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#tags TfCluster#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#tags_all TfCluster#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#version TfCluster#version}
    */
    readonly version?: string;
    /**
    * access_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#access_config TfCluster#access_config}
    */
    readonly accessConfig?: TfCluster.AccessConfigProperty;
    /**
    * compute_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#compute_config TfCluster#compute_config}
    */
    readonly computeConfig?: TfCluster.ComputeConfigProperty;
    /**
    * control_plane_scaling_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#control_plane_scaling_config TfCluster#control_plane_scaling_config}
    */
    readonly controlPlaneScalingConfig?: TfCluster.ControlPlaneScalingConfigProperty;
    /**
    * encryption_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#encryption_config TfCluster#encryption_config}
    */
    readonly encryptionConfig?: TfCluster.EncryptionConfigProperty;
    /**
    * kube_api_server_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#kube_api_server_config TfCluster#kube_api_server_config}
    */
    readonly kubeApiServerConfig?: TfCluster.KubeApiServerConfigProperty;
    /**
    * kube_controller_manager_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#kube_controller_manager_config TfCluster#kube_controller_manager_config}
    */
    readonly kubeControllerManagerConfig?: TfCluster.KubeControllerManagerConfigProperty;
    /**
    * kube_scheduler_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#kube_scheduler_config TfCluster#kube_scheduler_config}
    */
    readonly kubeSchedulerConfig?: TfCluster.KubeSchedulerConfigProperty;
    /**
    * kubernetes_network_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#kubernetes_network_config TfCluster#kubernetes_network_config}
    */
    readonly kubernetesNetworkConfig?: TfCluster.KubernetesNetworkConfigProperty;
    /**
    * outpost_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#outpost_config TfCluster#outpost_config}
    */
    readonly outpostConfig?: TfCluster.OutpostConfigProperty;
    /**
    * remote_network_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#remote_network_config TfCluster#remote_network_config}
    */
    readonly remoteNetworkConfig?: TfCluster.RemoteNetworkConfigProperty;
    /**
    * storage_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#storage_config TfCluster#storage_config}
    */
    readonly storageConfig?: TfCluster.StorageConfigProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#timeouts TfCluster#timeouts}
    */
    readonly timeouts?: TfCluster.TimeoutsProperty;
    /**
    * upgrade_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#upgrade_policy TfCluster#upgrade_policy}
    */
    readonly upgradePolicy?: TfCluster.UpgradePolicyProperty;
    /**
    * vpc_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#vpc_config TfCluster#vpc_config}
    */
    readonly vpcConfig: TfCluster.VpcConfigProperty;
    /**
    * zonal_shift_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#zonal_shift_config TfCluster#zonal_shift_config}
    */
    readonly zonalShiftConfig?: TfCluster.ZonalShiftConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster aws_eks_cluster}
*/
export declare class TfCluster extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_eks_cluster";
    /**
    * Generates CDKTN code for importing a TfCluster resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfCluster to import
    * @param importFromId The id of the existing TfCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster aws_eks_cluster} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfClusterConfig
    */
    constructor(scope: Construct, id: string, config: TfClusterConfig);
    get arn(): string;
    private _bootstrapSelfManagedAddons?;
    get bootstrapSelfManagedAddons(): boolean | cdktn.IResolvable;
    set bootstrapSelfManagedAddons(value: boolean | cdktn.IResolvable);
    resetBootstrapSelfManagedAddons(): void;
    get bootstrapSelfManagedAddonsInput(): boolean | cdktn.IResolvable | undefined;
    private _certificateAuthority;
    get certificateAuthority(): TfCluster.CertificateAuthorityPropertyList;
    get clusterId(): string;
    get createdAt(): string;
    private _deletionProtection?;
    get deletionProtection(): boolean | cdktn.IResolvable;
    set deletionProtection(value: boolean | cdktn.IResolvable);
    resetDeletionProtection(): void;
    get deletionProtectionInput(): boolean | cdktn.IResolvable | undefined;
    private _enabledClusterLogTypes?;
    get enabledClusterLogTypes(): string[];
    set enabledClusterLogTypes(value: string[]);
    resetEnabledClusterLogTypes(): void;
    get enabledClusterLogTypesInput(): string[] | undefined;
    get endpoint(): string;
    private _forceUpdateVersion?;
    get forceUpdateVersion(): boolean | cdktn.IResolvable;
    set forceUpdateVersion(value: boolean | cdktn.IResolvable);
    resetForceUpdateVersion(): void;
    get forceUpdateVersionInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _identity;
    get identity(): TfCluster.IdentityPropertyList;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get platformVersion(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
    private _accessConfig;
    get accessConfig(): TfCluster.AccessConfigPropertyOutputReference;
    putAccessConfig(value: TfCluster.AccessConfigProperty): void;
    resetAccessConfig(): void;
    get accessConfigInput(): TfCluster.AccessConfigProperty | undefined;
    private _computeConfig;
    get computeConfig(): TfCluster.ComputeConfigPropertyOutputReference;
    putComputeConfig(value: TfCluster.ComputeConfigProperty): void;
    resetComputeConfig(): void;
    get computeConfigInput(): TfCluster.ComputeConfigProperty | undefined;
    private _controlPlaneScalingConfig;
    get controlPlaneScalingConfig(): TfCluster.ControlPlaneScalingConfigPropertyOutputReference;
    putControlPlaneScalingConfig(value: TfCluster.ControlPlaneScalingConfigProperty): void;
    resetControlPlaneScalingConfig(): void;
    get controlPlaneScalingConfigInput(): TfCluster.ControlPlaneScalingConfigProperty | undefined;
    private _encryptionConfig;
    get encryptionConfig(): TfCluster.EncryptionConfigPropertyOutputReference;
    putEncryptionConfig(value: TfCluster.EncryptionConfigProperty): void;
    resetEncryptionConfig(): void;
    get encryptionConfigInput(): TfCluster.EncryptionConfigProperty | undefined;
    private _kubeApiServerConfig;
    get kubeApiServerConfig(): TfCluster.KubeApiServerConfigPropertyOutputReference;
    putKubeApiServerConfig(value: TfCluster.KubeApiServerConfigProperty): void;
    resetKubeApiServerConfig(): void;
    get kubeApiServerConfigInput(): TfCluster.KubeApiServerConfigProperty | undefined;
    private _kubeControllerManagerConfig;
    get kubeControllerManagerConfig(): TfCluster.KubeControllerManagerConfigPropertyOutputReference;
    putKubeControllerManagerConfig(value: TfCluster.KubeControllerManagerConfigProperty): void;
    resetKubeControllerManagerConfig(): void;
    get kubeControllerManagerConfigInput(): TfCluster.KubeControllerManagerConfigProperty | undefined;
    private _kubeSchedulerConfig;
    get kubeSchedulerConfig(): TfCluster.KubeSchedulerConfigPropertyOutputReference;
    putKubeSchedulerConfig(value: TfCluster.KubeSchedulerConfigProperty): void;
    resetKubeSchedulerConfig(): void;
    get kubeSchedulerConfigInput(): TfCluster.KubeSchedulerConfigProperty | undefined;
    private _kubernetesNetworkConfig;
    get kubernetesNetworkConfig(): TfCluster.KubernetesNetworkConfigPropertyOutputReference;
    putKubernetesNetworkConfig(value: TfCluster.KubernetesNetworkConfigProperty): void;
    resetKubernetesNetworkConfig(): void;
    get kubernetesNetworkConfigInput(): TfCluster.KubernetesNetworkConfigProperty | undefined;
    private _outpostConfig;
    get outpostConfig(): TfCluster.OutpostConfigPropertyOutputReference;
    putOutpostConfig(value: TfCluster.OutpostConfigProperty): void;
    resetOutpostConfig(): void;
    get outpostConfigInput(): TfCluster.OutpostConfigProperty | undefined;
    private _remoteNetworkConfig;
    get remoteNetworkConfig(): TfCluster.RemoteNetworkConfigPropertyOutputReference;
    putRemoteNetworkConfig(value: TfCluster.RemoteNetworkConfigProperty): void;
    resetRemoteNetworkConfig(): void;
    get remoteNetworkConfigInput(): TfCluster.RemoteNetworkConfigProperty | undefined;
    private _storageConfig;
    get storageConfig(): TfCluster.StorageConfigPropertyOutputReference;
    putStorageConfig(value: TfCluster.StorageConfigProperty): void;
    resetStorageConfig(): void;
    get storageConfigInput(): TfCluster.StorageConfigProperty | undefined;
    private _timeouts;
    get timeouts(): TfCluster.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfCluster.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfCluster.TimeoutsProperty | undefined;
    private _upgradePolicy;
    get upgradePolicy(): TfCluster.UpgradePolicyPropertyOutputReference;
    putUpgradePolicy(value: TfCluster.UpgradePolicyProperty): void;
    resetUpgradePolicy(): void;
    get upgradePolicyInput(): TfCluster.UpgradePolicyProperty | undefined;
    private _vpcConfig;
    get vpcConfig(): TfCluster.VpcConfigPropertyOutputReference;
    putVpcConfig(value: TfCluster.VpcConfigProperty): void;
    get vpcConfigInput(): TfCluster.VpcConfigProperty | undefined;
    private _zonalShiftConfig;
    get zonalShiftConfig(): TfCluster.ZonalShiftConfigPropertyOutputReference;
    putZonalShiftConfig(value: TfCluster.ZonalShiftConfigProperty): void;
    resetZonalShiftConfig(): void;
    get zonalShiftConfigInput(): TfCluster.ZonalShiftConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfClusterCertificateAuthorityPropertyToTerraform(struct?: TfCluster.CertificateAuthorityProperty): any;
export declare function tfClusterCertificateAuthorityPropertyToHclTerraform(struct?: TfCluster.CertificateAuthorityProperty): any;
export declare function tfClusterOidcPropertyToTerraform(struct?: TfCluster.OidcProperty): any;
export declare function tfClusterOidcPropertyToHclTerraform(struct?: TfCluster.OidcProperty): any;
export declare function tfClusterIdentityPropertyToTerraform(struct?: TfCluster.IdentityProperty): any;
export declare function tfClusterIdentityPropertyToHclTerraform(struct?: TfCluster.IdentityProperty): any;
export declare function tfClusterAccessConfigPropertyToTerraform(struct?: TfCluster.AccessConfigPropertyOutputReference | TfCluster.AccessConfigProperty): any;
export declare function tfClusterAccessConfigPropertyToHclTerraform(struct?: TfCluster.AccessConfigPropertyOutputReference | TfCluster.AccessConfigProperty): any;
export declare function tfClusterComputeConfigPropertyToTerraform(struct?: TfCluster.ComputeConfigPropertyOutputReference | TfCluster.ComputeConfigProperty): any;
export declare function tfClusterComputeConfigPropertyToHclTerraform(struct?: TfCluster.ComputeConfigPropertyOutputReference | TfCluster.ComputeConfigProperty): any;
export declare function tfClusterControlPlaneScalingConfigPropertyToTerraform(struct?: TfCluster.ControlPlaneScalingConfigPropertyOutputReference | TfCluster.ControlPlaneScalingConfigProperty): any;
export declare function tfClusterControlPlaneScalingConfigPropertyToHclTerraform(struct?: TfCluster.ControlPlaneScalingConfigPropertyOutputReference | TfCluster.ControlPlaneScalingConfigProperty): any;
export declare function tfClusterProviderPropertyToTerraform(struct?: TfCluster.ProviderPropertyOutputReference | TfCluster.ProviderProperty): any;
export declare function tfClusterProviderPropertyToHclTerraform(struct?: TfCluster.ProviderPropertyOutputReference | TfCluster.ProviderProperty): any;
export declare function tfClusterEncryptionConfigPropertyToTerraform(struct?: TfCluster.EncryptionConfigPropertyOutputReference | TfCluster.EncryptionConfigProperty): any;
export declare function tfClusterEncryptionConfigPropertyToHclTerraform(struct?: TfCluster.EncryptionConfigPropertyOutputReference | TfCluster.EncryptionConfigProperty): any;
export declare function tfClusterServiceNodePortRangePropertyToTerraform(struct?: TfCluster.ServiceNodePortRangePropertyOutputReference | TfCluster.ServiceNodePortRangeProperty): any;
export declare function tfClusterServiceNodePortRangePropertyToHclTerraform(struct?: TfCluster.ServiceNodePortRangePropertyOutputReference | TfCluster.ServiceNodePortRangeProperty): any;
export declare function tfClusterKubeApiServerConfigPropertyToTerraform(struct?: TfCluster.KubeApiServerConfigPropertyOutputReference | TfCluster.KubeApiServerConfigProperty): any;
export declare function tfClusterKubeApiServerConfigPropertyToHclTerraform(struct?: TfCluster.KubeApiServerConfigPropertyOutputReference | TfCluster.KubeApiServerConfigProperty): any;
export declare function tfClusterHorizontalPodAutoscalerControllerConfigPropertyToTerraform(struct?: TfCluster.HorizontalPodAutoscalerControllerConfigPropertyOutputReference | TfCluster.HorizontalPodAutoscalerControllerConfigProperty): any;
export declare function tfClusterHorizontalPodAutoscalerControllerConfigPropertyToHclTerraform(struct?: TfCluster.HorizontalPodAutoscalerControllerConfigPropertyOutputReference | TfCluster.HorizontalPodAutoscalerControllerConfigProperty): any;
export declare function tfClusterKubeControllerManagerConfigPropertyToTerraform(struct?: TfCluster.KubeControllerManagerConfigPropertyOutputReference | TfCluster.KubeControllerManagerConfigProperty): any;
export declare function tfClusterKubeControllerManagerConfigPropertyToHclTerraform(struct?: TfCluster.KubeControllerManagerConfigPropertyOutputReference | TfCluster.KubeControllerManagerConfigProperty): any;
export declare function tfClusterResourcePropertyToTerraform(struct?: TfCluster.ResourceProperty | cdktn.IResolvable): any;
export declare function tfClusterResourcePropertyToHclTerraform(struct?: TfCluster.ResourceProperty | cdktn.IResolvable): any;
export declare function tfClusterScoringStrategyPropertyToTerraform(struct?: TfCluster.ScoringStrategyPropertyOutputReference | TfCluster.ScoringStrategyProperty): any;
export declare function tfClusterScoringStrategyPropertyToHclTerraform(struct?: TfCluster.ScoringStrategyPropertyOutputReference | TfCluster.ScoringStrategyProperty): any;
export declare function tfClusterNodeResourcesFitPropertyToTerraform(struct?: TfCluster.NodeResourcesFitPropertyOutputReference | TfCluster.NodeResourcesFitProperty): any;
export declare function tfClusterNodeResourcesFitPropertyToHclTerraform(struct?: TfCluster.NodeResourcesFitPropertyOutputReference | TfCluster.NodeResourcesFitProperty): any;
export declare function tfClusterKubeSchedulerConfigPropertyToTerraform(struct?: TfCluster.KubeSchedulerConfigPropertyOutputReference | TfCluster.KubeSchedulerConfigProperty): any;
export declare function tfClusterKubeSchedulerConfigPropertyToHclTerraform(struct?: TfCluster.KubeSchedulerConfigPropertyOutputReference | TfCluster.KubeSchedulerConfigProperty): any;
export declare function tfClusterElasticLoadBalancingPropertyToTerraform(struct?: TfCluster.ElasticLoadBalancingPropertyOutputReference | TfCluster.ElasticLoadBalancingProperty): any;
export declare function tfClusterElasticLoadBalancingPropertyToHclTerraform(struct?: TfCluster.ElasticLoadBalancingPropertyOutputReference | TfCluster.ElasticLoadBalancingProperty): any;
export declare function tfClusterKubernetesNetworkConfigPropertyToTerraform(struct?: TfCluster.KubernetesNetworkConfigPropertyOutputReference | TfCluster.KubernetesNetworkConfigProperty): any;
export declare function tfClusterKubernetesNetworkConfigPropertyToHclTerraform(struct?: TfCluster.KubernetesNetworkConfigPropertyOutputReference | TfCluster.KubernetesNetworkConfigProperty): any;
export declare function tfClusterControlPlanePlacementPropertyToTerraform(struct?: TfCluster.ControlPlanePlacementPropertyOutputReference | TfCluster.ControlPlanePlacementProperty): any;
export declare function tfClusterControlPlanePlacementPropertyToHclTerraform(struct?: TfCluster.ControlPlanePlacementPropertyOutputReference | TfCluster.ControlPlanePlacementProperty): any;
export declare function tfClusterEtcdPlacementPropertyToTerraform(struct?: TfCluster.EtcdPlacementPropertyOutputReference | TfCluster.EtcdPlacementProperty): any;
export declare function tfClusterEtcdPlacementPropertyToHclTerraform(struct?: TfCluster.EtcdPlacementPropertyOutputReference | TfCluster.EtcdPlacementProperty): any;
export declare function tfClusterOutpostConfigPropertyToTerraform(struct?: TfCluster.OutpostConfigPropertyOutputReference | TfCluster.OutpostConfigProperty): any;
export declare function tfClusterOutpostConfigPropertyToHclTerraform(struct?: TfCluster.OutpostConfigPropertyOutputReference | TfCluster.OutpostConfigProperty): any;
export declare function tfClusterRemoteNodeNetworksPropertyToTerraform(struct?: TfCluster.RemoteNodeNetworksPropertyOutputReference | TfCluster.RemoteNodeNetworksProperty): any;
export declare function tfClusterRemoteNodeNetworksPropertyToHclTerraform(struct?: TfCluster.RemoteNodeNetworksPropertyOutputReference | TfCluster.RemoteNodeNetworksProperty): any;
export declare function tfClusterRemotePodNetworksPropertyToTerraform(struct?: TfCluster.RemotePodNetworksPropertyOutputReference | TfCluster.RemotePodNetworksProperty): any;
export declare function tfClusterRemotePodNetworksPropertyToHclTerraform(struct?: TfCluster.RemotePodNetworksPropertyOutputReference | TfCluster.RemotePodNetworksProperty): any;
export declare function tfClusterRemoteNetworkConfigPropertyToTerraform(struct?: TfCluster.RemoteNetworkConfigPropertyOutputReference | TfCluster.RemoteNetworkConfigProperty): any;
export declare function tfClusterRemoteNetworkConfigPropertyToHclTerraform(struct?: TfCluster.RemoteNetworkConfigPropertyOutputReference | TfCluster.RemoteNetworkConfigProperty): any;
export declare function tfClusterBlockStoragePropertyToTerraform(struct?: TfCluster.BlockStoragePropertyOutputReference | TfCluster.BlockStorageProperty): any;
export declare function tfClusterBlockStoragePropertyToHclTerraform(struct?: TfCluster.BlockStoragePropertyOutputReference | TfCluster.BlockStorageProperty): any;
export declare function tfClusterStorageConfigPropertyToTerraform(struct?: TfCluster.StorageConfigPropertyOutputReference | TfCluster.StorageConfigProperty): any;
export declare function tfClusterStorageConfigPropertyToHclTerraform(struct?: TfCluster.StorageConfigPropertyOutputReference | TfCluster.StorageConfigProperty): any;
export declare function tfClusterTimeoutsPropertyToTerraform(struct?: TfCluster.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfClusterTimeoutsPropertyToHclTerraform(struct?: TfCluster.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfClusterUpgradePolicyPropertyToTerraform(struct?: TfCluster.UpgradePolicyPropertyOutputReference | TfCluster.UpgradePolicyProperty): any;
export declare function tfClusterUpgradePolicyPropertyToHclTerraform(struct?: TfCluster.UpgradePolicyPropertyOutputReference | TfCluster.UpgradePolicyProperty): any;
export declare function tfClusterVpcConfigPropertyToTerraform(struct?: TfCluster.VpcConfigPropertyOutputReference | TfCluster.VpcConfigProperty): any;
export declare function tfClusterVpcConfigPropertyToHclTerraform(struct?: TfCluster.VpcConfigPropertyOutputReference | TfCluster.VpcConfigProperty): any;
export declare function tfClusterZonalShiftConfigPropertyToTerraform(struct?: TfCluster.ZonalShiftConfigPropertyOutputReference | TfCluster.ZonalShiftConfigProperty): any;
export declare function tfClusterZonalShiftConfigPropertyToHclTerraform(struct?: TfCluster.ZonalShiftConfigPropertyOutputReference | TfCluster.ZonalShiftConfigProperty): any;
export declare namespace TfCluster {
    interface CertificateAuthorityProperty {
    }
    class CertificateAuthorityPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CertificateAuthorityProperty | undefined;
        set internalValue(value: CertificateAuthorityProperty | undefined);
        get data(): string;
    }
    class CertificateAuthorityPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CertificateAuthorityPropertyOutputReference;
    }
    interface OidcProperty {
    }
    class OidcPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OidcProperty | undefined;
        set internalValue(value: OidcProperty | undefined);
        get issuer(): string;
    }
    class OidcPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OidcPropertyOutputReference;
    }
    interface IdentityProperty {
    }
    class IdentityPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IdentityProperty | undefined;
        set internalValue(value: IdentityProperty | undefined);
        private _oidc;
        get oidc(): OidcPropertyList;
    }
    class IdentityPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IdentityPropertyOutputReference;
    }
    interface AccessConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#authentication_mode TfCluster#authentication_mode}
        */
        readonly authenticationMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#bootstrap_cluster_creator_admin_permissions TfCluster#bootstrap_cluster_creator_admin_permissions}
        */
        readonly bootstrapClusterCreatorAdminPermissions?: boolean | cdktn.IResolvable;
    }
    class AccessConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AccessConfigProperty | undefined;
        set internalValue(value: AccessConfigProperty | undefined);
        private _authenticationMode?;
        get authenticationMode(): string;
        set authenticationMode(value: string);
        resetAuthenticationMode(): void;
        get authenticationModeInput(): string | undefined;
        private _bootstrapClusterCreatorAdminPermissions?;
        get bootstrapClusterCreatorAdminPermissions(): boolean | cdktn.IResolvable;
        set bootstrapClusterCreatorAdminPermissions(value: boolean | cdktn.IResolvable);
        resetBootstrapClusterCreatorAdminPermissions(): void;
        get bootstrapClusterCreatorAdminPermissionsInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface ComputeConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#enabled TfCluster#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#node_pools TfCluster#node_pools}
        */
        readonly nodePools?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#node_role_arn TfCluster#node_role_arn}
        */
        readonly nodeRoleArn?: string;
    }
    class ComputeConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ComputeConfigProperty | undefined;
        set internalValue(value: ComputeConfigProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _nodePools?;
        get nodePools(): string[];
        set nodePools(value: string[]);
        resetNodePools(): void;
        get nodePoolsInput(): string[] | undefined;
        private _nodeRoleArn?;
        get nodeRoleArn(): string;
        set nodeRoleArn(value: string);
        resetNodeRoleArn(): void;
        get nodeRoleArnInput(): string | undefined;
    }
    interface ControlPlaneScalingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#tier TfCluster#tier}
        */
        readonly tier?: string;
    }
    class ControlPlaneScalingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ControlPlaneScalingConfigProperty | undefined;
        set internalValue(value: ControlPlaneScalingConfigProperty | undefined);
        private _tier?;
        get tier(): string;
        set tier(value: string);
        resetTier(): void;
        get tierInput(): string | undefined;
    }
    interface ProviderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#key_arn TfCluster#key_arn}
        */
        readonly keyArn: string;
    }
    class ProviderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ProviderProperty | undefined;
        set internalValue(value: ProviderProperty | undefined);
        private _keyArn?;
        get keyArn(): string;
        set keyArn(value: string);
        get keyArnInput(): string | undefined;
    }
    interface EncryptionConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#resources TfCluster#resources}
        */
        readonly resources: string[];
        /**
        * provider block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#provider TfCluster#provider}
        */
        readonly provider: ProviderProperty;
    }
    class EncryptionConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncryptionConfigProperty | undefined;
        set internalValue(value: EncryptionConfigProperty | undefined);
        private _resources?;
        get resources(): string[];
        set resources(value: string[]);
        get resourcesInput(): string[] | undefined;
        private _provider;
        get provider(): ProviderPropertyOutputReference;
        putProvider(value: ProviderProperty): void;
        get providerInput(): ProviderProperty | undefined;
    }
    interface ServiceNodePortRangeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#max_port TfCluster#max_port}
        */
        readonly maxPort?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#min_port TfCluster#min_port}
        */
        readonly minPort?: number;
    }
    class ServiceNodePortRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ServiceNodePortRangeProperty | undefined;
        set internalValue(value: ServiceNodePortRangeProperty | undefined);
        private _maxPort?;
        get maxPort(): number;
        set maxPort(value: number);
        resetMaxPort(): void;
        get maxPortInput(): number | undefined;
        private _minPort?;
        get minPort(): number;
        set minPort(value: number);
        resetMinPort(): void;
        get minPortInput(): number | undefined;
    }
    interface KubeApiServerConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#event_ttl TfCluster#event_ttl}
        */
        readonly eventTtl?: string;
        /**
        * service_node_port_range block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#service_node_port_range TfCluster#service_node_port_range}
        */
        readonly serviceNodePortRange?: ServiceNodePortRangeProperty;
    }
    class KubeApiServerConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): KubeApiServerConfigProperty | undefined;
        set internalValue(value: KubeApiServerConfigProperty | undefined);
        private _eventTtl?;
        get eventTtl(): string;
        set eventTtl(value: string);
        resetEventTtl(): void;
        get eventTtlInput(): string | undefined;
        private _serviceNodePortRange;
        get serviceNodePortRange(): ServiceNodePortRangePropertyOutputReference;
        putServiceNodePortRange(value: ServiceNodePortRangeProperty): void;
        resetServiceNodePortRange(): void;
        get serviceNodePortRangeInput(): ServiceNodePortRangeProperty | undefined;
    }
    interface HorizontalPodAutoscalerControllerConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#horizontal_pod_autoscaler_sync_period TfCluster#horizontal_pod_autoscaler_sync_period}
        */
        readonly horizontalPodAutoscalerSyncPeriod?: string;
    }
    class HorizontalPodAutoscalerControllerConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HorizontalPodAutoscalerControllerConfigProperty | undefined;
        set internalValue(value: HorizontalPodAutoscalerControllerConfigProperty | undefined);
        private _horizontalPodAutoscalerSyncPeriod?;
        get horizontalPodAutoscalerSyncPeriod(): string;
        set horizontalPodAutoscalerSyncPeriod(value: string);
        resetHorizontalPodAutoscalerSyncPeriod(): void;
        get horizontalPodAutoscalerSyncPeriodInput(): string | undefined;
    }
    interface KubeControllerManagerConfigProperty {
        /**
        * horizontal_pod_autoscaler_controller_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#horizontal_pod_autoscaler_controller_config TfCluster#horizontal_pod_autoscaler_controller_config}
        */
        readonly horizontalPodAutoscalerControllerConfig?: HorizontalPodAutoscalerControllerConfigProperty;
    }
    class KubeControllerManagerConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): KubeControllerManagerConfigProperty | undefined;
        set internalValue(value: KubeControllerManagerConfigProperty | undefined);
        private _horizontalPodAutoscalerControllerConfig;
        get horizontalPodAutoscalerControllerConfig(): HorizontalPodAutoscalerControllerConfigPropertyOutputReference;
        putHorizontalPodAutoscalerControllerConfig(value: HorizontalPodAutoscalerControllerConfigProperty): void;
        resetHorizontalPodAutoscalerControllerConfig(): void;
        get horizontalPodAutoscalerControllerConfigInput(): HorizontalPodAutoscalerControllerConfigProperty | undefined;
    }
    interface ResourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#name TfCluster#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#weight TfCluster#weight}
        */
        readonly weight?: number;
    }
    class ResourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _weight?;
        get weight(): number;
        set weight(value: number);
        resetWeight(): void;
        get weightInput(): number | undefined;
    }
    class ResourcePropertyList extends cdktn.ComplexList {
        internalValue?: ResourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourcePropertyOutputReference;
    }
    interface ScoringStrategyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#type TfCluster#type}
        */
        readonly type?: string;
        /**
        * resource block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#resource TfCluster#resource}
        */
        readonly resource?: ResourceProperty[] | cdktn.IResolvable;
    }
    class ScoringStrategyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ScoringStrategyProperty | undefined;
        set internalValue(value: ScoringStrategyProperty | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
        private _resource;
        get resource(): ResourcePropertyList;
        putResource(value: ResourceProperty[] | cdktn.IResolvable): void;
        resetResource(): void;
        get resourceInput(): cdktn.IResolvable | ResourceProperty[] | undefined;
    }
    interface NodeResourcesFitProperty {
        /**
        * scoring_strategy block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#scoring_strategy TfCluster#scoring_strategy}
        */
        readonly scoringStrategy?: ScoringStrategyProperty;
    }
    class NodeResourcesFitPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NodeResourcesFitProperty | undefined;
        set internalValue(value: NodeResourcesFitProperty | undefined);
        private _scoringStrategy;
        get scoringStrategy(): ScoringStrategyPropertyOutputReference;
        putScoringStrategy(value: ScoringStrategyProperty): void;
        resetScoringStrategy(): void;
        get scoringStrategyInput(): ScoringStrategyProperty | undefined;
    }
    interface KubeSchedulerConfigProperty {
        /**
        * node_resources_fit block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#node_resources_fit TfCluster#node_resources_fit}
        */
        readonly nodeResourcesFit?: NodeResourcesFitProperty;
    }
    class KubeSchedulerConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): KubeSchedulerConfigProperty | undefined;
        set internalValue(value: KubeSchedulerConfigProperty | undefined);
        private _nodeResourcesFit;
        get nodeResourcesFit(): NodeResourcesFitPropertyOutputReference;
        putNodeResourcesFit(value: NodeResourcesFitProperty): void;
        resetNodeResourcesFit(): void;
        get nodeResourcesFitInput(): NodeResourcesFitProperty | undefined;
    }
    interface ElasticLoadBalancingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#enabled TfCluster#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
    }
    class ElasticLoadBalancingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ElasticLoadBalancingProperty | undefined;
        set internalValue(value: ElasticLoadBalancingProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface KubernetesNetworkConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#ip_family TfCluster#ip_family}
        */
        readonly ipFamily?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#service_ipv4_cidr TfCluster#service_ipv4_cidr}
        */
        readonly serviceIpv4Cidr?: string;
        /**
        * elastic_load_balancing block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#elastic_load_balancing TfCluster#elastic_load_balancing}
        */
        readonly elasticLoadBalancing?: ElasticLoadBalancingProperty;
    }
    class KubernetesNetworkConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): KubernetesNetworkConfigProperty | undefined;
        set internalValue(value: KubernetesNetworkConfigProperty | undefined);
        private _ipFamily?;
        get ipFamily(): string;
        set ipFamily(value: string);
        resetIpFamily(): void;
        get ipFamilyInput(): string | undefined;
        private _serviceIpv4Cidr?;
        get serviceIpv4Cidr(): string;
        set serviceIpv4Cidr(value: string);
        resetServiceIpv4Cidr(): void;
        get serviceIpv4CidrInput(): string | undefined;
        get serviceIpv6Cidr(): string;
        private _elasticLoadBalancing;
        get elasticLoadBalancing(): ElasticLoadBalancingPropertyOutputReference;
        putElasticLoadBalancing(value: ElasticLoadBalancingProperty): void;
        resetElasticLoadBalancing(): void;
        get elasticLoadBalancingInput(): ElasticLoadBalancingProperty | undefined;
    }
    interface ControlPlanePlacementProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#group_name TfCluster#group_name}
        */
        readonly groupName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#spread_level TfCluster#spread_level}
        */
        readonly spreadLevel?: string;
    }
    class ControlPlanePlacementPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ControlPlanePlacementProperty | undefined;
        set internalValue(value: ControlPlanePlacementProperty | undefined);
        private _groupName?;
        get groupName(): string;
        set groupName(value: string);
        resetGroupName(): void;
        get groupNameInput(): string | undefined;
        private _spreadLevel?;
        get spreadLevel(): string;
        set spreadLevel(value: string);
        resetSpreadLevel(): void;
        get spreadLevelInput(): string | undefined;
    }
    interface EtcdPlacementProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#spread_level TfCluster#spread_level}
        */
        readonly spreadLevel?: string;
    }
    class EtcdPlacementPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EtcdPlacementProperty | undefined;
        set internalValue(value: EtcdPlacementProperty | undefined);
        private _spreadLevel?;
        get spreadLevel(): string;
        set spreadLevel(value: string);
        resetSpreadLevel(): void;
        get spreadLevelInput(): string | undefined;
    }
    interface OutpostConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#control_plane_instance_type TfCluster#control_plane_instance_type}
        */
        readonly controlPlaneInstanceType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#etcd_instance_type TfCluster#etcd_instance_type}
        */
        readonly etcdInstanceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#outpost_arns TfCluster#outpost_arns}
        */
        readonly outpostArns: string[];
        /**
        * control_plane_placement block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#control_plane_placement TfCluster#control_plane_placement}
        */
        readonly controlPlanePlacement?: ControlPlanePlacementProperty;
        /**
        * etcd_placement block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#etcd_placement TfCluster#etcd_placement}
        */
        readonly etcdPlacement?: EtcdPlacementProperty;
    }
    class OutpostConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OutpostConfigProperty | undefined;
        set internalValue(value: OutpostConfigProperty | undefined);
        private _controlPlaneInstanceType?;
        get controlPlaneInstanceType(): string;
        set controlPlaneInstanceType(value: string);
        get controlPlaneInstanceTypeInput(): string | undefined;
        private _etcdInstanceType?;
        get etcdInstanceType(): string;
        set etcdInstanceType(value: string);
        resetEtcdInstanceType(): void;
        get etcdInstanceTypeInput(): string | undefined;
        private _outpostArns?;
        get outpostArns(): string[];
        set outpostArns(value: string[]);
        get outpostArnsInput(): string[] | undefined;
        private _controlPlanePlacement;
        get controlPlanePlacement(): ControlPlanePlacementPropertyOutputReference;
        putControlPlanePlacement(value: ControlPlanePlacementProperty): void;
        resetControlPlanePlacement(): void;
        get controlPlanePlacementInput(): ControlPlanePlacementProperty | undefined;
        private _etcdPlacement;
        get etcdPlacement(): EtcdPlacementPropertyOutputReference;
        putEtcdPlacement(value: EtcdPlacementProperty): void;
        resetEtcdPlacement(): void;
        get etcdPlacementInput(): EtcdPlacementProperty | undefined;
    }
    interface RemoteNodeNetworksProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#cidrs TfCluster#cidrs}
        */
        readonly cidrs?: string[];
    }
    class RemoteNodeNetworksPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RemoteNodeNetworksProperty | undefined;
        set internalValue(value: RemoteNodeNetworksProperty | undefined);
        private _cidrs?;
        get cidrs(): string[];
        set cidrs(value: string[]);
        resetCidrs(): void;
        get cidrsInput(): string[] | undefined;
    }
    interface RemotePodNetworksProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#cidrs TfCluster#cidrs}
        */
        readonly cidrs?: string[];
    }
    class RemotePodNetworksPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RemotePodNetworksProperty | undefined;
        set internalValue(value: RemotePodNetworksProperty | undefined);
        private _cidrs?;
        get cidrs(): string[];
        set cidrs(value: string[]);
        resetCidrs(): void;
        get cidrsInput(): string[] | undefined;
    }
    interface RemoteNetworkConfigProperty {
        /**
        * remote_node_networks block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#remote_node_networks TfCluster#remote_node_networks}
        */
        readonly remoteNodeNetworks?: RemoteNodeNetworksProperty;
        /**
        * remote_pod_networks block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#remote_pod_networks TfCluster#remote_pod_networks}
        */
        readonly remotePodNetworks?: RemotePodNetworksProperty;
    }
    class RemoteNetworkConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RemoteNetworkConfigProperty | undefined;
        set internalValue(value: RemoteNetworkConfigProperty | undefined);
        private _remoteNodeNetworks;
        get remoteNodeNetworks(): RemoteNodeNetworksPropertyOutputReference;
        putRemoteNodeNetworks(value: RemoteNodeNetworksProperty): void;
        resetRemoteNodeNetworks(): void;
        get remoteNodeNetworksInput(): RemoteNodeNetworksProperty | undefined;
        private _remotePodNetworks;
        get remotePodNetworks(): RemotePodNetworksPropertyOutputReference;
        putRemotePodNetworks(value: RemotePodNetworksProperty): void;
        resetRemotePodNetworks(): void;
        get remotePodNetworksInput(): RemotePodNetworksProperty | undefined;
    }
    interface BlockStorageProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#enabled TfCluster#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
    }
    class BlockStoragePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BlockStorageProperty | undefined;
        set internalValue(value: BlockStorageProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface StorageConfigProperty {
        /**
        * block_storage block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#block_storage TfCluster#block_storage}
        */
        readonly blockStorage?: BlockStorageProperty;
    }
    class StorageConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StorageConfigProperty | undefined;
        set internalValue(value: StorageConfigProperty | undefined);
        private _blockStorage;
        get blockStorage(): BlockStoragePropertyOutputReference;
        putBlockStorage(value: BlockStorageProperty): void;
        resetBlockStorage(): void;
        get blockStorageInput(): BlockStorageProperty | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#create TfCluster#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#delete TfCluster#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#update TfCluster#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface UpgradePolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#support_type TfCluster#support_type}
        */
        readonly supportType?: string;
    }
    class UpgradePolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UpgradePolicyProperty | undefined;
        set internalValue(value: UpgradePolicyProperty | undefined);
        private _supportType?;
        get supportType(): string;
        set supportType(value: string);
        resetSupportType(): void;
        get supportTypeInput(): string | undefined;
    }
    interface VpcConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#control_plane_egress_mode TfCluster#control_plane_egress_mode}
        */
        readonly controlPlaneEgressMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#endpoint_private_access TfCluster#endpoint_private_access}
        */
        readonly endpointPrivateAccess?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#endpoint_public_access TfCluster#endpoint_public_access}
        */
        readonly endpointPublicAccess?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#public_access_cidrs TfCluster#public_access_cidrs}
        */
        readonly publicAccessCidrs?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#security_group_ids TfCluster#security_group_ids}
        */
        readonly securityGroupIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#subnet_ids TfCluster#subnet_ids}
        */
        readonly subnetIds: string[];
    }
    class VpcConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VpcConfigProperty | undefined;
        set internalValue(value: VpcConfigProperty | undefined);
        get clusterSecurityGroupId(): string;
        private _controlPlaneEgressMode?;
        get controlPlaneEgressMode(): string;
        set controlPlaneEgressMode(value: string);
        resetControlPlaneEgressMode(): void;
        get controlPlaneEgressModeInput(): string | undefined;
        private _endpointPrivateAccess?;
        get endpointPrivateAccess(): boolean | cdktn.IResolvable;
        set endpointPrivateAccess(value: boolean | cdktn.IResolvable);
        resetEndpointPrivateAccess(): void;
        get endpointPrivateAccessInput(): boolean | cdktn.IResolvable | undefined;
        private _endpointPublicAccess?;
        get endpointPublicAccess(): boolean | cdktn.IResolvable;
        set endpointPublicAccess(value: boolean | cdktn.IResolvable);
        resetEndpointPublicAccess(): void;
        get endpointPublicAccessInput(): boolean | cdktn.IResolvable | undefined;
        private _publicAccessCidrs?;
        get publicAccessCidrs(): string[];
        set publicAccessCidrs(value: string[]);
        resetPublicAccessCidrs(): void;
        get publicAccessCidrsInput(): string[] | undefined;
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        resetSecurityGroupIds(): void;
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        get subnetIdsInput(): string[] | undefined;
        get vpcId(): string;
    }
    interface ZonalShiftConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#enabled TfCluster#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
    }
    class ZonalShiftConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ZonalShiftConfigProperty | undefined;
        set internalValue(value: ZonalShiftConfigProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
}
