import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfIdentityProviderConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_identity_provider_config#cluster_name TfIdentityProviderConfig#cluster_name}
    */
    readonly clusterName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_identity_provider_config#id TfIdentityProviderConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_identity_provider_config#region TfIdentityProviderConfig#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_identity_provider_config#tags TfIdentityProviderConfig#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_identity_provider_config#tags_all TfIdentityProviderConfig#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * oidc block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_identity_provider_config#oidc TfIdentityProviderConfig#oidc}
    */
    readonly oidc: TfIdentityProviderConfig.OidcProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_identity_provider_config#timeouts TfIdentityProviderConfig#timeouts}
    */
    readonly timeouts?: TfIdentityProviderConfig.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_identity_provider_config aws_eks_identity_provider_config}
*/
export declare class TfIdentityProviderConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_eks_identity_provider_config";
    /**
    * Generates CDKTN code for importing a TfIdentityProviderConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfIdentityProviderConfig to import
    * @param importFromId The id of the existing TfIdentityProviderConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_identity_provider_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfIdentityProviderConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_identity_provider_config aws_eks_identity_provider_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfIdentityProviderConfigConfig
    */
    constructor(scope: Construct, id: string, config: TfIdentityProviderConfigConfig);
    get arn(): string;
    private _clusterName?;
    get clusterName(): string;
    set clusterName(value: string);
    get clusterNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get identityProviderConfigName(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _oidc;
    get oidc(): TfIdentityProviderConfig.OidcPropertyOutputReference;
    putOidc(value: TfIdentityProviderConfig.OidcProperty): void;
    get oidcInput(): TfIdentityProviderConfig.OidcProperty | undefined;
    private _timeouts;
    get timeouts(): TfIdentityProviderConfig.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfIdentityProviderConfig.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfIdentityProviderConfig.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfIdentityProviderConfigOidcPropertyToTerraform(struct?: TfIdentityProviderConfig.OidcPropertyOutputReference | TfIdentityProviderConfig.OidcProperty): any;
export declare function tfIdentityProviderConfigOidcPropertyToHclTerraform(struct?: TfIdentityProviderConfig.OidcPropertyOutputReference | TfIdentityProviderConfig.OidcProperty): any;
export declare function tfIdentityProviderConfigTimeoutsPropertyToTerraform(struct?: TfIdentityProviderConfig.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfIdentityProviderConfigTimeoutsPropertyToHclTerraform(struct?: TfIdentityProviderConfig.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfIdentityProviderConfig {
    interface OidcProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_identity_provider_config#client_id TfIdentityProviderConfig#client_id}
        */
        readonly clientId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_identity_provider_config#groups_claim TfIdentityProviderConfig#groups_claim}
        */
        readonly groupsClaim?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_identity_provider_config#groups_prefix TfIdentityProviderConfig#groups_prefix}
        */
        readonly groupsPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_identity_provider_config#identity_provider_config_name TfIdentityProviderConfig#identity_provider_config_name}
        */
        readonly identityProviderConfigName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_identity_provider_config#issuer_url TfIdentityProviderConfig#issuer_url}
        */
        readonly issuerUrl: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_identity_provider_config#required_claims TfIdentityProviderConfig#required_claims}
        */
        readonly requiredClaims?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_identity_provider_config#username_claim TfIdentityProviderConfig#username_claim}
        */
        readonly usernameClaim?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_identity_provider_config#username_prefix TfIdentityProviderConfig#username_prefix}
        */
        readonly usernamePrefix?: string;
    }
    class OidcPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OidcProperty | undefined;
        set internalValue(value: OidcProperty | undefined);
        private _clientId?;
        get clientId(): string;
        set clientId(value: string);
        get clientIdInput(): string | undefined;
        private _groupsClaim?;
        get groupsClaim(): string;
        set groupsClaim(value: string);
        resetGroupsClaim(): void;
        get groupsClaimInput(): string | undefined;
        private _groupsPrefix?;
        get groupsPrefix(): string;
        set groupsPrefix(value: string);
        resetGroupsPrefix(): void;
        get groupsPrefixInput(): string | undefined;
        private _identityProviderConfigName?;
        get identityProviderConfigName(): string;
        set identityProviderConfigName(value: string);
        get identityProviderConfigNameInput(): string | undefined;
        private _issuerUrl?;
        get issuerUrl(): string;
        set issuerUrl(value: string);
        get issuerUrlInput(): string | undefined;
        private _requiredClaims?;
        get requiredClaims(): {
            [key: string]: string;
        };
        set requiredClaims(value: {
            [key: string]: string;
        });
        resetRequiredClaims(): void;
        get requiredClaimsInput(): {
            [key: string]: string;
        } | undefined;
        private _usernameClaim?;
        get usernameClaim(): string;
        set usernameClaim(value: string);
        resetUsernameClaim(): void;
        get usernameClaimInput(): string | undefined;
        private _usernamePrefix?;
        get usernamePrefix(): string;
        set usernamePrefix(value: string);
        resetUsernamePrefix(): void;
        get usernamePrefixInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_identity_provider_config#create TfIdentityProviderConfig#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_identity_provider_config#delete TfIdentityProviderConfig#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
