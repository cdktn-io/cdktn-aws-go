import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsEksAddonConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_addon#addon_name AwsEksAddon#addon_name}
    */
    readonly addonName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_addon#addon_version AwsEksAddon#addon_version}
    */
    readonly addonVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_addon#cluster_name AwsEksAddon#cluster_name}
    */
    readonly clusterName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_addon#configuration_values AwsEksAddon#configuration_values}
    */
    readonly configurationValues?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_addon#id AwsEksAddon#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_addon#preserve AwsEksAddon#preserve}
    */
    readonly preserve?: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_addon#region AwsEksAddon#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_addon#resolve_conflicts_on_create AwsEksAddon#resolve_conflicts_on_create}
    */
    readonly resolveConflictsOnCreate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_addon#resolve_conflicts_on_update AwsEksAddon#resolve_conflicts_on_update}
    */
    readonly resolveConflictsOnUpdate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_addon#service_account_role_arn AwsEksAddon#service_account_role_arn}
    */
    readonly serviceAccountRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_addon#tags AwsEksAddon#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_addon#tags_all AwsEksAddon#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * namespace_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_addon#namespace_config AwsEksAddon#namespace_config}
    */
    readonly namespaceConfig?: AwsEksAddon.NamespaceConfigProperty;
    /**
    * pod_identity_association block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_addon#pod_identity_association AwsEksAddon#pod_identity_association}
    */
    readonly podIdentityAssociation?: AwsEksAddon.PodIdentityAssociationProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_addon#timeouts AwsEksAddon#timeouts}
    */
    readonly timeouts?: AwsEksAddon.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_addon aws_eks_addon}
*/
export declare class AwsEksAddon extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_eks_addon";
    /**
    * Generates CDKTN code for importing a AwsEksAddon resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsEksAddon to import
    * @param importFromId The id of the existing AwsEksAddon that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_addon#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsEksAddon to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_addon aws_eks_addon} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsEksAddonConfig
    */
    constructor(scope: Construct, id: string, config: AwsEksAddonConfig);
    private _addonName?;
    get addonName(): string;
    set addonName(value: string);
    get addonNameInput(): string | undefined;
    private _addonVersion?;
    get addonVersion(): string;
    set addonVersion(value: string);
    resetAddonVersion(): void;
    get addonVersionInput(): string | undefined;
    get arn(): string;
    private _clusterName?;
    get clusterName(): string;
    set clusterName(value: string);
    get clusterNameInput(): string | undefined;
    private _configurationValues?;
    get configurationValues(): string;
    set configurationValues(value: string);
    resetConfigurationValues(): void;
    get configurationValuesInput(): string | undefined;
    get createdAt(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get modifiedAt(): string;
    private _preserve?;
    get preserve(): boolean | cdktn.IResolvable;
    set preserve(value: boolean | cdktn.IResolvable);
    resetPreserve(): void;
    get preserveInput(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resolveConflictsOnCreate?;
    get resolveConflictsOnCreate(): string;
    set resolveConflictsOnCreate(value: string);
    resetResolveConflictsOnCreate(): void;
    get resolveConflictsOnCreateInput(): string | undefined;
    private _resolveConflictsOnUpdate?;
    get resolveConflictsOnUpdate(): string;
    set resolveConflictsOnUpdate(value: string);
    resetResolveConflictsOnUpdate(): void;
    get resolveConflictsOnUpdateInput(): string | undefined;
    private _serviceAccountRoleArn?;
    get serviceAccountRoleArn(): string;
    set serviceAccountRoleArn(value: string);
    resetServiceAccountRoleArn(): void;
    get serviceAccountRoleArnInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _namespaceConfig;
    get namespaceConfig(): AwsEksAddon.NamespaceConfigPropertyOutputReference;
    putNamespaceConfig(value: AwsEksAddon.NamespaceConfigProperty): void;
    resetNamespaceConfig(): void;
    get namespaceConfigInput(): AwsEksAddon.NamespaceConfigProperty | undefined;
    private _podIdentityAssociation;
    get podIdentityAssociation(): AwsEksAddon.PodIdentityAssociationPropertyList;
    putPodIdentityAssociation(value: AwsEksAddon.PodIdentityAssociationProperty[] | cdktn.IResolvable): void;
    resetPodIdentityAssociation(): void;
    get podIdentityAssociationInput(): cdktn.IResolvable | AwsEksAddon.PodIdentityAssociationProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsEksAddon.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsEksAddon.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsEksAddon.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsEksAddonNamespaceConfigPropertyToTerraform(struct?: AwsEksAddon.NamespaceConfigPropertyOutputReference | AwsEksAddon.NamespaceConfigProperty): any;
export declare function awsEksAddonNamespaceConfigPropertyToHclTerraform(struct?: AwsEksAddon.NamespaceConfigPropertyOutputReference | AwsEksAddon.NamespaceConfigProperty): any;
export declare function awsEksAddonPodIdentityAssociationPropertyToTerraform(struct?: AwsEksAddon.PodIdentityAssociationProperty | cdktn.IResolvable): any;
export declare function awsEksAddonPodIdentityAssociationPropertyToHclTerraform(struct?: AwsEksAddon.PodIdentityAssociationProperty | cdktn.IResolvable): any;
export declare function awsEksAddonTimeoutsPropertyToTerraform(struct?: AwsEksAddon.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsEksAddonTimeoutsPropertyToHclTerraform(struct?: AwsEksAddon.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsEksAddon {
    interface NamespaceConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_addon#namespace AwsEksAddon#namespace}
        */
        readonly namespace?: string;
    }
    class NamespaceConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NamespaceConfigProperty | undefined;
        set internalValue(value: NamespaceConfigProperty | undefined);
        private _namespace?;
        get namespace(): string;
        set namespace(value: string);
        resetNamespace(): void;
        get namespaceInput(): string | undefined;
    }
    interface PodIdentityAssociationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_addon#role_arn AwsEksAddon#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_addon#service_account AwsEksAddon#service_account}
        */
        readonly serviceAccount: string;
    }
    class PodIdentityAssociationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PodIdentityAssociationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PodIdentityAssociationProperty | cdktn.IResolvable | undefined);
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _serviceAccount?;
        get serviceAccount(): string;
        set serviceAccount(value: string);
        get serviceAccountInput(): string | undefined;
    }
    class PodIdentityAssociationPropertyList extends cdktn.ComplexList {
        internalValue?: PodIdentityAssociationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PodIdentityAssociationPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_addon#create AwsEksAddon#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_addon#delete AwsEksAddon#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_addon#update AwsEksAddon#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
