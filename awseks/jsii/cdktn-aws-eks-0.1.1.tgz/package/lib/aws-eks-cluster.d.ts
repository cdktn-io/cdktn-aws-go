import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsEksClusterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#bootstrap_self_managed_addons AwsEksCluster#bootstrap_self_managed_addons}
    */
    readonly bootstrapSelfManagedAddons?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#deletion_protection AwsEksCluster#deletion_protection}
    */
    readonly deletionProtection?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#enabled_cluster_log_types AwsEksCluster#enabled_cluster_log_types}
    */
    readonly enabledClusterLogTypes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#force_update_version AwsEksCluster#force_update_version}
    */
    readonly forceUpdateVersion?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#id AwsEksCluster#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#name AwsEksCluster#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#region AwsEksCluster#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#role_arn AwsEksCluster#role_arn}
    */
    readonly roleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#tags AwsEksCluster#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#tags_all AwsEksCluster#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#version AwsEksCluster#version}
    */
    readonly version?: string;
    /**
    * access_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#access_config AwsEksCluster#access_config}
    */
    readonly accessConfig?: AwsEksCluster.AccessConfigProperty;
    /**
    * compute_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#compute_config AwsEksCluster#compute_config}
    */
    readonly computeConfig?: AwsEksCluster.ComputeConfigProperty;
    /**
    * control_plane_scaling_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#control_plane_scaling_config AwsEksCluster#control_plane_scaling_config}
    */
    readonly controlPlaneScalingConfig?: AwsEksCluster.ControlPlaneScalingConfigProperty;
    /**
    * encryption_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#encryption_config AwsEksCluster#encryption_config}
    */
    readonly encryptionConfig?: AwsEksCluster.EncryptionConfigProperty;
    /**
    * kube_api_server_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#kube_api_server_config AwsEksCluster#kube_api_server_config}
    */
    readonly kubeApiServerConfig?: AwsEksCluster.KubeApiServerConfigProperty;
    /**
    * kube_controller_manager_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#kube_controller_manager_config AwsEksCluster#kube_controller_manager_config}
    */
    readonly kubeControllerManagerConfig?: AwsEksCluster.KubeControllerManagerConfigProperty;
    /**
    * kube_scheduler_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#kube_scheduler_config AwsEksCluster#kube_scheduler_config}
    */
    readonly kubeSchedulerConfig?: AwsEksCluster.KubeSchedulerConfigProperty;
    /**
    * kubernetes_network_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#kubernetes_network_config AwsEksCluster#kubernetes_network_config}
    */
    readonly kubernetesNetworkConfig?: AwsEksCluster.KubernetesNetworkConfigProperty;
    /**
    * outpost_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#outpost_config AwsEksCluster#outpost_config}
    */
    readonly outpostConfig?: AwsEksCluster.OutpostConfigProperty;
    /**
    * remote_network_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#remote_network_config AwsEksCluster#remote_network_config}
    */
    readonly remoteNetworkConfig?: AwsEksCluster.RemoteNetworkConfigProperty;
    /**
    * storage_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#storage_config AwsEksCluster#storage_config}
    */
    readonly storageConfig?: AwsEksCluster.StorageConfigProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#timeouts AwsEksCluster#timeouts}
    */
    readonly timeouts?: AwsEksCluster.TimeoutsProperty;
    /**
    * upgrade_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#upgrade_policy AwsEksCluster#upgrade_policy}
    */
    readonly upgradePolicy?: AwsEksCluster.UpgradePolicyProperty;
    /**
    * vpc_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#vpc_config AwsEksCluster#vpc_config}
    */
    readonly vpcConfig: AwsEksCluster.VpcConfigProperty;
    /**
    * zonal_shift_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#zonal_shift_config AwsEksCluster#zonal_shift_config}
    */
    readonly zonalShiftConfig?: AwsEksCluster.ZonalShiftConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster aws_eks_cluster}
*/
export declare class AwsEksCluster extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_eks_cluster";
    /**
    * Generates CDKTN code for importing a AwsEksCluster resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsEksCluster to import
    * @param importFromId The id of the existing AwsEksCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsEksCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster aws_eks_cluster} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsEksClusterConfig
    */
    constructor(scope: Construct, id: string, config: AwsEksClusterConfig);
    get arn(): string;
    private _bootstrapSelfManagedAddons?;
    get bootstrapSelfManagedAddons(): boolean | cdktn.IResolvable;
    set bootstrapSelfManagedAddons(value: boolean | cdktn.IResolvable);
    resetBootstrapSelfManagedAddons(): void;
    get bootstrapSelfManagedAddonsInput(): boolean | cdktn.IResolvable | undefined;
    private _certificateAuthority;
    get certificateAuthority(): AwsEksCluster.CertificateAuthorityPropertyList;
    get clusterId(): string;
    get createdAt(): string;
    private _deletionProtection?;
    get deletionProtection(): boolean | cdktn.IResolvable;
    set deletionProtection(value: boolean | cdktn.IResolvable);
    resetDeletionProtection(): void;
    get deletionProtectionInput(): boolean | cdktn.IResolvable | undefined;
    private _enabledClusterLogTypes?;
    get enabledClusterLogTypes(): string[];
    set enabledClusterLogTypes(value: string[]);
    resetEnabledClusterLogTypes(): void;
    get enabledClusterLogTypesInput(): string[] | undefined;
    get endpoint(): string;
    private _forceUpdateVersion?;
    get forceUpdateVersion(): boolean | cdktn.IResolvable;
    set forceUpdateVersion(value: boolean | cdktn.IResolvable);
    resetForceUpdateVersion(): void;
    get forceUpdateVersionInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _identity;
    get identity(): AwsEksCluster.IdentityPropertyList;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get platformVersion(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
    private _accessConfig;
    get accessConfig(): AwsEksCluster.AccessConfigPropertyOutputReference;
    putAccessConfig(value: AwsEksCluster.AccessConfigProperty): void;
    resetAccessConfig(): void;
    get accessConfigInput(): AwsEksCluster.AccessConfigProperty | undefined;
    private _computeConfig;
    get computeConfig(): AwsEksCluster.ComputeConfigPropertyOutputReference;
    putComputeConfig(value: AwsEksCluster.ComputeConfigProperty): void;
    resetComputeConfig(): void;
    get computeConfigInput(): AwsEksCluster.ComputeConfigProperty | undefined;
    private _controlPlaneScalingConfig;
    get controlPlaneScalingConfig(): AwsEksCluster.ControlPlaneScalingConfigPropertyOutputReference;
    putControlPlaneScalingConfig(value: AwsEksCluster.ControlPlaneScalingConfigProperty): void;
    resetControlPlaneScalingConfig(): void;
    get controlPlaneScalingConfigInput(): AwsEksCluster.ControlPlaneScalingConfigProperty | undefined;
    private _encryptionConfig;
    get encryptionConfig(): AwsEksCluster.EncryptionConfigPropertyOutputReference;
    putEncryptionConfig(value: AwsEksCluster.EncryptionConfigProperty): void;
    resetEncryptionConfig(): void;
    get encryptionConfigInput(): AwsEksCluster.EncryptionConfigProperty | undefined;
    private _kubeApiServerConfig;
    get kubeApiServerConfig(): AwsEksCluster.KubeApiServerConfigPropertyOutputReference;
    putKubeApiServerConfig(value: AwsEksCluster.KubeApiServerConfigProperty): void;
    resetKubeApiServerConfig(): void;
    get kubeApiServerConfigInput(): AwsEksCluster.KubeApiServerConfigProperty | undefined;
    private _kubeControllerManagerConfig;
    get kubeControllerManagerConfig(): AwsEksCluster.KubeControllerManagerConfigPropertyOutputReference;
    putKubeControllerManagerConfig(value: AwsEksCluster.KubeControllerManagerConfigProperty): void;
    resetKubeControllerManagerConfig(): void;
    get kubeControllerManagerConfigInput(): AwsEksCluster.KubeControllerManagerConfigProperty | undefined;
    private _kubeSchedulerConfig;
    get kubeSchedulerConfig(): AwsEksCluster.KubeSchedulerConfigPropertyOutputReference;
    putKubeSchedulerConfig(value: AwsEksCluster.KubeSchedulerConfigProperty): void;
    resetKubeSchedulerConfig(): void;
    get kubeSchedulerConfigInput(): AwsEksCluster.KubeSchedulerConfigProperty | undefined;
    private _kubernetesNetworkConfig;
    get kubernetesNetworkConfig(): AwsEksCluster.KubernetesNetworkConfigPropertyOutputReference;
    putKubernetesNetworkConfig(value: AwsEksCluster.KubernetesNetworkConfigProperty): void;
    resetKubernetesNetworkConfig(): void;
    get kubernetesNetworkConfigInput(): AwsEksCluster.KubernetesNetworkConfigProperty | undefined;
    private _outpostConfig;
    get outpostConfig(): AwsEksCluster.OutpostConfigPropertyOutputReference;
    putOutpostConfig(value: AwsEksCluster.OutpostConfigProperty): void;
    resetOutpostConfig(): void;
    get outpostConfigInput(): AwsEksCluster.OutpostConfigProperty | undefined;
    private _remoteNetworkConfig;
    get remoteNetworkConfig(): AwsEksCluster.RemoteNetworkConfigPropertyOutputReference;
    putRemoteNetworkConfig(value: AwsEksCluster.RemoteNetworkConfigProperty): void;
    resetRemoteNetworkConfig(): void;
    get remoteNetworkConfigInput(): AwsEksCluster.RemoteNetworkConfigProperty | undefined;
    private _storageConfig;
    get storageConfig(): AwsEksCluster.StorageConfigPropertyOutputReference;
    putStorageConfig(value: AwsEksCluster.StorageConfigProperty): void;
    resetStorageConfig(): void;
    get storageConfigInput(): AwsEksCluster.StorageConfigProperty | undefined;
    private _timeouts;
    get timeouts(): AwsEksCluster.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsEksCluster.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsEksCluster.TimeoutsProperty | undefined;
    private _upgradePolicy;
    get upgradePolicy(): AwsEksCluster.UpgradePolicyPropertyOutputReference;
    putUpgradePolicy(value: AwsEksCluster.UpgradePolicyProperty): void;
    resetUpgradePolicy(): void;
    get upgradePolicyInput(): AwsEksCluster.UpgradePolicyProperty | undefined;
    private _vpcConfig;
    get vpcConfig(): AwsEksCluster.VpcConfigPropertyOutputReference;
    putVpcConfig(value: AwsEksCluster.VpcConfigProperty): void;
    get vpcConfigInput(): AwsEksCluster.VpcConfigProperty | undefined;
    private _zonalShiftConfig;
    get zonalShiftConfig(): AwsEksCluster.ZonalShiftConfigPropertyOutputReference;
    putZonalShiftConfig(value: AwsEksCluster.ZonalShiftConfigProperty): void;
    resetZonalShiftConfig(): void;
    get zonalShiftConfigInput(): AwsEksCluster.ZonalShiftConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsEksClusterCertificateAuthorityPropertyToTerraform(struct?: AwsEksCluster.CertificateAuthorityProperty): any;
export declare function awsEksClusterCertificateAuthorityPropertyToHclTerraform(struct?: AwsEksCluster.CertificateAuthorityProperty): any;
export declare function awsEksClusterOidcPropertyToTerraform(struct?: AwsEksCluster.OidcProperty): any;
export declare function awsEksClusterOidcPropertyToHclTerraform(struct?: AwsEksCluster.OidcProperty): any;
export declare function awsEksClusterIdentityPropertyToTerraform(struct?: AwsEksCluster.IdentityProperty): any;
export declare function awsEksClusterIdentityPropertyToHclTerraform(struct?: AwsEksCluster.IdentityProperty): any;
export declare function awsEksClusterAccessConfigPropertyToTerraform(struct?: AwsEksCluster.AccessConfigPropertyOutputReference | AwsEksCluster.AccessConfigProperty): any;
export declare function awsEksClusterAccessConfigPropertyToHclTerraform(struct?: AwsEksCluster.AccessConfigPropertyOutputReference | AwsEksCluster.AccessConfigProperty): any;
export declare function awsEksClusterComputeConfigPropertyToTerraform(struct?: AwsEksCluster.ComputeConfigPropertyOutputReference | AwsEksCluster.ComputeConfigProperty): any;
export declare function awsEksClusterComputeConfigPropertyToHclTerraform(struct?: AwsEksCluster.ComputeConfigPropertyOutputReference | AwsEksCluster.ComputeConfigProperty): any;
export declare function awsEksClusterControlPlaneScalingConfigPropertyToTerraform(struct?: AwsEksCluster.ControlPlaneScalingConfigPropertyOutputReference | AwsEksCluster.ControlPlaneScalingConfigProperty): any;
export declare function awsEksClusterControlPlaneScalingConfigPropertyToHclTerraform(struct?: AwsEksCluster.ControlPlaneScalingConfigPropertyOutputReference | AwsEksCluster.ControlPlaneScalingConfigProperty): any;
export declare function awsEksClusterProviderPropertyToTerraform(struct?: AwsEksCluster.ProviderPropertyOutputReference | AwsEksCluster.ProviderProperty): any;
export declare function awsEksClusterProviderPropertyToHclTerraform(struct?: AwsEksCluster.ProviderPropertyOutputReference | AwsEksCluster.ProviderProperty): any;
export declare function awsEksClusterEncryptionConfigPropertyToTerraform(struct?: AwsEksCluster.EncryptionConfigPropertyOutputReference | AwsEksCluster.EncryptionConfigProperty): any;
export declare function awsEksClusterEncryptionConfigPropertyToHclTerraform(struct?: AwsEksCluster.EncryptionConfigPropertyOutputReference | AwsEksCluster.EncryptionConfigProperty): any;
export declare function awsEksClusterServiceNodePortRangePropertyToTerraform(struct?: AwsEksCluster.ServiceNodePortRangePropertyOutputReference | AwsEksCluster.ServiceNodePortRangeProperty): any;
export declare function awsEksClusterServiceNodePortRangePropertyToHclTerraform(struct?: AwsEksCluster.ServiceNodePortRangePropertyOutputReference | AwsEksCluster.ServiceNodePortRangeProperty): any;
export declare function awsEksClusterKubeApiServerConfigPropertyToTerraform(struct?: AwsEksCluster.KubeApiServerConfigPropertyOutputReference | AwsEksCluster.KubeApiServerConfigProperty): any;
export declare function awsEksClusterKubeApiServerConfigPropertyToHclTerraform(struct?: AwsEksCluster.KubeApiServerConfigPropertyOutputReference | AwsEksCluster.KubeApiServerConfigProperty): any;
export declare function awsEksClusterHorizontalPodAutoscalerControllerConfigPropertyToTerraform(struct?: AwsEksCluster.HorizontalPodAutoscalerControllerConfigPropertyOutputReference | AwsEksCluster.HorizontalPodAutoscalerControllerConfigProperty): any;
export declare function awsEksClusterHorizontalPodAutoscalerControllerConfigPropertyToHclTerraform(struct?: AwsEksCluster.HorizontalPodAutoscalerControllerConfigPropertyOutputReference | AwsEksCluster.HorizontalPodAutoscalerControllerConfigProperty): any;
export declare function awsEksClusterKubeControllerManagerConfigPropertyToTerraform(struct?: AwsEksCluster.KubeControllerManagerConfigPropertyOutputReference | AwsEksCluster.KubeControllerManagerConfigProperty): any;
export declare function awsEksClusterKubeControllerManagerConfigPropertyToHclTerraform(struct?: AwsEksCluster.KubeControllerManagerConfigPropertyOutputReference | AwsEksCluster.KubeControllerManagerConfigProperty): any;
export declare function awsEksClusterResourcePropertyToTerraform(struct?: AwsEksCluster.ResourceProperty | cdktn.IResolvable): any;
export declare function awsEksClusterResourcePropertyToHclTerraform(struct?: AwsEksCluster.ResourceProperty | cdktn.IResolvable): any;
export declare function awsEksClusterScoringStrategyPropertyToTerraform(struct?: AwsEksCluster.ScoringStrategyPropertyOutputReference | AwsEksCluster.ScoringStrategyProperty): any;
export declare function awsEksClusterScoringStrategyPropertyToHclTerraform(struct?: AwsEksCluster.ScoringStrategyPropertyOutputReference | AwsEksCluster.ScoringStrategyProperty): any;
export declare function awsEksClusterNodeResourcesFitPropertyToTerraform(struct?: AwsEksCluster.NodeResourcesFitPropertyOutputReference | AwsEksCluster.NodeResourcesFitProperty): any;
export declare function awsEksClusterNodeResourcesFitPropertyToHclTerraform(struct?: AwsEksCluster.NodeResourcesFitPropertyOutputReference | AwsEksCluster.NodeResourcesFitProperty): any;
export declare function awsEksClusterKubeSchedulerConfigPropertyToTerraform(struct?: AwsEksCluster.KubeSchedulerConfigPropertyOutputReference | AwsEksCluster.KubeSchedulerConfigProperty): any;
export declare function awsEksClusterKubeSchedulerConfigPropertyToHclTerraform(struct?: AwsEksCluster.KubeSchedulerConfigPropertyOutputReference | AwsEksCluster.KubeSchedulerConfigProperty): any;
export declare function awsEksClusterElasticLoadBalancingPropertyToTerraform(struct?: AwsEksCluster.ElasticLoadBalancingPropertyOutputReference | AwsEksCluster.ElasticLoadBalancingProperty): any;
export declare function awsEksClusterElasticLoadBalancingPropertyToHclTerraform(struct?: AwsEksCluster.ElasticLoadBalancingPropertyOutputReference | AwsEksCluster.ElasticLoadBalancingProperty): any;
export declare function awsEksClusterKubernetesNetworkConfigPropertyToTerraform(struct?: AwsEksCluster.KubernetesNetworkConfigPropertyOutputReference | AwsEksCluster.KubernetesNetworkConfigProperty): any;
export declare function awsEksClusterKubernetesNetworkConfigPropertyToHclTerraform(struct?: AwsEksCluster.KubernetesNetworkConfigPropertyOutputReference | AwsEksCluster.KubernetesNetworkConfigProperty): any;
export declare function awsEksClusterControlPlanePlacementPropertyToTerraform(struct?: AwsEksCluster.ControlPlanePlacementPropertyOutputReference | AwsEksCluster.ControlPlanePlacementProperty): any;
export declare function awsEksClusterControlPlanePlacementPropertyToHclTerraform(struct?: AwsEksCluster.ControlPlanePlacementPropertyOutputReference | AwsEksCluster.ControlPlanePlacementProperty): any;
export declare function awsEksClusterEtcdPlacementPropertyToTerraform(struct?: AwsEksCluster.EtcdPlacementPropertyOutputReference | AwsEksCluster.EtcdPlacementProperty): any;
export declare function awsEksClusterEtcdPlacementPropertyToHclTerraform(struct?: AwsEksCluster.EtcdPlacementPropertyOutputReference | AwsEksCluster.EtcdPlacementProperty): any;
export declare function awsEksClusterOutpostConfigPropertyToTerraform(struct?: AwsEksCluster.OutpostConfigPropertyOutputReference | AwsEksCluster.OutpostConfigProperty): any;
export declare function awsEksClusterOutpostConfigPropertyToHclTerraform(struct?: AwsEksCluster.OutpostConfigPropertyOutputReference | AwsEksCluster.OutpostConfigProperty): any;
export declare function awsEksClusterRemoteNodeNetworksPropertyToTerraform(struct?: AwsEksCluster.RemoteNodeNetworksPropertyOutputReference | AwsEksCluster.RemoteNodeNetworksProperty): any;
export declare function awsEksClusterRemoteNodeNetworksPropertyToHclTerraform(struct?: AwsEksCluster.RemoteNodeNetworksPropertyOutputReference | AwsEksCluster.RemoteNodeNetworksProperty): any;
export declare function awsEksClusterRemotePodNetworksPropertyToTerraform(struct?: AwsEksCluster.RemotePodNetworksPropertyOutputReference | AwsEksCluster.RemotePodNetworksProperty): any;
export declare function awsEksClusterRemotePodNetworksPropertyToHclTerraform(struct?: AwsEksCluster.RemotePodNetworksPropertyOutputReference | AwsEksCluster.RemotePodNetworksProperty): any;
export declare function awsEksClusterRemoteNetworkConfigPropertyToTerraform(struct?: AwsEksCluster.RemoteNetworkConfigPropertyOutputReference | AwsEksCluster.RemoteNetworkConfigProperty): any;
export declare function awsEksClusterRemoteNetworkConfigPropertyToHclTerraform(struct?: AwsEksCluster.RemoteNetworkConfigPropertyOutputReference | AwsEksCluster.RemoteNetworkConfigProperty): any;
export declare function awsEksClusterBlockStoragePropertyToTerraform(struct?: AwsEksCluster.BlockStoragePropertyOutputReference | AwsEksCluster.BlockStorageProperty): any;
export declare function awsEksClusterBlockStoragePropertyToHclTerraform(struct?: AwsEksCluster.BlockStoragePropertyOutputReference | AwsEksCluster.BlockStorageProperty): any;
export declare function awsEksClusterStorageConfigPropertyToTerraform(struct?: AwsEksCluster.StorageConfigPropertyOutputReference | AwsEksCluster.StorageConfigProperty): any;
export declare function awsEksClusterStorageConfigPropertyToHclTerraform(struct?: AwsEksCluster.StorageConfigPropertyOutputReference | AwsEksCluster.StorageConfigProperty): any;
export declare function awsEksClusterTimeoutsPropertyToTerraform(struct?: AwsEksCluster.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsEksClusterTimeoutsPropertyToHclTerraform(struct?: AwsEksCluster.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsEksClusterUpgradePolicyPropertyToTerraform(struct?: AwsEksCluster.UpgradePolicyPropertyOutputReference | AwsEksCluster.UpgradePolicyProperty): any;
export declare function awsEksClusterUpgradePolicyPropertyToHclTerraform(struct?: AwsEksCluster.UpgradePolicyPropertyOutputReference | AwsEksCluster.UpgradePolicyProperty): any;
export declare function awsEksClusterVpcConfigPropertyToTerraform(struct?: AwsEksCluster.VpcConfigPropertyOutputReference | AwsEksCluster.VpcConfigProperty): any;
export declare function awsEksClusterVpcConfigPropertyToHclTerraform(struct?: AwsEksCluster.VpcConfigPropertyOutputReference | AwsEksCluster.VpcConfigProperty): any;
export declare function awsEksClusterZonalShiftConfigPropertyToTerraform(struct?: AwsEksCluster.ZonalShiftConfigPropertyOutputReference | AwsEksCluster.ZonalShiftConfigProperty): any;
export declare function awsEksClusterZonalShiftConfigPropertyToHclTerraform(struct?: AwsEksCluster.ZonalShiftConfigPropertyOutputReference | AwsEksCluster.ZonalShiftConfigProperty): any;
export declare namespace AwsEksCluster {
    interface CertificateAuthorityProperty {
    }
    class CertificateAuthorityPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CertificateAuthorityProperty | undefined;
        set internalValue(value: CertificateAuthorityProperty | undefined);
        get data(): string;
    }
    class CertificateAuthorityPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CertificateAuthorityPropertyOutputReference;
    }
    interface OidcProperty {
    }
    class OidcPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OidcProperty | undefined;
        set internalValue(value: OidcProperty | undefined);
        get issuer(): string;
    }
    class OidcPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OidcPropertyOutputReference;
    }
    interface IdentityProperty {
    }
    class IdentityPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IdentityProperty | undefined;
        set internalValue(value: IdentityProperty | undefined);
        private _oidc;
        get oidc(): OidcPropertyList;
    }
    class IdentityPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IdentityPropertyOutputReference;
    }
    interface AccessConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#authentication_mode AwsEksCluster#authentication_mode}
        */
        readonly authenticationMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#bootstrap_cluster_creator_admin_permissions AwsEksCluster#bootstrap_cluster_creator_admin_permissions}
        */
        readonly bootstrapClusterCreatorAdminPermissions?: boolean | cdktn.IResolvable;
    }
    class AccessConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AccessConfigProperty | undefined;
        set internalValue(value: AccessConfigProperty | undefined);
        private _authenticationMode?;
        get authenticationMode(): string;
        set authenticationMode(value: string);
        resetAuthenticationMode(): void;
        get authenticationModeInput(): string | undefined;
        private _bootstrapClusterCreatorAdminPermissions?;
        get bootstrapClusterCreatorAdminPermissions(): boolean | cdktn.IResolvable;
        set bootstrapClusterCreatorAdminPermissions(value: boolean | cdktn.IResolvable);
        resetBootstrapClusterCreatorAdminPermissions(): void;
        get bootstrapClusterCreatorAdminPermissionsInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface ComputeConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#enabled AwsEksCluster#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#node_pools AwsEksCluster#node_pools}
        */
        readonly nodePools?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#node_role_arn AwsEksCluster#node_role_arn}
        */
        readonly nodeRoleArn?: string;
    }
    class ComputeConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ComputeConfigProperty | undefined;
        set internalValue(value: ComputeConfigProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _nodePools?;
        get nodePools(): string[];
        set nodePools(value: string[]);
        resetNodePools(): void;
        get nodePoolsInput(): string[] | undefined;
        private _nodeRoleArn?;
        get nodeRoleArn(): string;
        set nodeRoleArn(value: string);
        resetNodeRoleArn(): void;
        get nodeRoleArnInput(): string | undefined;
    }
    interface ControlPlaneScalingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#tier AwsEksCluster#tier}
        */
        readonly tier?: string;
    }
    class ControlPlaneScalingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ControlPlaneScalingConfigProperty | undefined;
        set internalValue(value: ControlPlaneScalingConfigProperty | undefined);
        private _tier?;
        get tier(): string;
        set tier(value: string);
        resetTier(): void;
        get tierInput(): string | undefined;
    }
    interface ProviderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#key_arn AwsEksCluster#key_arn}
        */
        readonly keyArn: string;
    }
    class ProviderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ProviderProperty | undefined;
        set internalValue(value: ProviderProperty | undefined);
        private _keyArn?;
        get keyArn(): string;
        set keyArn(value: string);
        get keyArnInput(): string | undefined;
    }
    interface EncryptionConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#resources AwsEksCluster#resources}
        */
        readonly resources: string[];
        /**
        * provider block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#provider AwsEksCluster#provider}
        */
        readonly provider: ProviderProperty;
    }
    class EncryptionConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncryptionConfigProperty | undefined;
        set internalValue(value: EncryptionConfigProperty | undefined);
        private _resources?;
        get resources(): string[];
        set resources(value: string[]);
        get resourcesInput(): string[] | undefined;
        private _provider;
        get provider(): ProviderPropertyOutputReference;
        putProvider(value: ProviderProperty): void;
        get providerInput(): ProviderProperty | undefined;
    }
    interface ServiceNodePortRangeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#max_port AwsEksCluster#max_port}
        */
        readonly maxPort?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#min_port AwsEksCluster#min_port}
        */
        readonly minPort?: number;
    }
    class ServiceNodePortRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ServiceNodePortRangeProperty | undefined;
        set internalValue(value: ServiceNodePortRangeProperty | undefined);
        private _maxPort?;
        get maxPort(): number;
        set maxPort(value: number);
        resetMaxPort(): void;
        get maxPortInput(): number | undefined;
        private _minPort?;
        get minPort(): number;
        set minPort(value: number);
        resetMinPort(): void;
        get minPortInput(): number | undefined;
    }
    interface KubeApiServerConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#event_ttl AwsEksCluster#event_ttl}
        */
        readonly eventTtl?: string;
        /**
        * service_node_port_range block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#service_node_port_range AwsEksCluster#service_node_port_range}
        */
        readonly serviceNodePortRange?: ServiceNodePortRangeProperty;
    }
    class KubeApiServerConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): KubeApiServerConfigProperty | undefined;
        set internalValue(value: KubeApiServerConfigProperty | undefined);
        private _eventTtl?;
        get eventTtl(): string;
        set eventTtl(value: string);
        resetEventTtl(): void;
        get eventTtlInput(): string | undefined;
        private _serviceNodePortRange;
        get serviceNodePortRange(): ServiceNodePortRangePropertyOutputReference;
        putServiceNodePortRange(value: ServiceNodePortRangeProperty): void;
        resetServiceNodePortRange(): void;
        get serviceNodePortRangeInput(): ServiceNodePortRangeProperty | undefined;
    }
    interface HorizontalPodAutoscalerControllerConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#horizontal_pod_autoscaler_sync_period AwsEksCluster#horizontal_pod_autoscaler_sync_period}
        */
        readonly horizontalPodAutoscalerSyncPeriod?: string;
    }
    class HorizontalPodAutoscalerControllerConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HorizontalPodAutoscalerControllerConfigProperty | undefined;
        set internalValue(value: HorizontalPodAutoscalerControllerConfigProperty | undefined);
        private _horizontalPodAutoscalerSyncPeriod?;
        get horizontalPodAutoscalerSyncPeriod(): string;
        set horizontalPodAutoscalerSyncPeriod(value: string);
        resetHorizontalPodAutoscalerSyncPeriod(): void;
        get horizontalPodAutoscalerSyncPeriodInput(): string | undefined;
    }
    interface KubeControllerManagerConfigProperty {
        /**
        * horizontal_pod_autoscaler_controller_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#horizontal_pod_autoscaler_controller_config AwsEksCluster#horizontal_pod_autoscaler_controller_config}
        */
        readonly horizontalPodAutoscalerControllerConfig?: HorizontalPodAutoscalerControllerConfigProperty;
    }
    class KubeControllerManagerConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): KubeControllerManagerConfigProperty | undefined;
        set internalValue(value: KubeControllerManagerConfigProperty | undefined);
        private _horizontalPodAutoscalerControllerConfig;
        get horizontalPodAutoscalerControllerConfig(): HorizontalPodAutoscalerControllerConfigPropertyOutputReference;
        putHorizontalPodAutoscalerControllerConfig(value: HorizontalPodAutoscalerControllerConfigProperty): void;
        resetHorizontalPodAutoscalerControllerConfig(): void;
        get horizontalPodAutoscalerControllerConfigInput(): HorizontalPodAutoscalerControllerConfigProperty | undefined;
    }
    interface ResourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#name AwsEksCluster#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#weight AwsEksCluster#weight}
        */
        readonly weight?: number;
    }
    class ResourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _weight?;
        get weight(): number;
        set weight(value: number);
        resetWeight(): void;
        get weightInput(): number | undefined;
    }
    class ResourcePropertyList extends cdktn.ComplexList {
        internalValue?: ResourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourcePropertyOutputReference;
    }
    interface ScoringStrategyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#type AwsEksCluster#type}
        */
        readonly type?: string;
        /**
        * resource block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#resource AwsEksCluster#resource}
        */
        readonly resource?: ResourceProperty[] | cdktn.IResolvable;
    }
    class ScoringStrategyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ScoringStrategyProperty | undefined;
        set internalValue(value: ScoringStrategyProperty | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
        private _resource;
        get resource(): ResourcePropertyList;
        putResource(value: ResourceProperty[] | cdktn.IResolvable): void;
        resetResource(): void;
        get resourceInput(): cdktn.IResolvable | ResourceProperty[] | undefined;
    }
    interface NodeResourcesFitProperty {
        /**
        * scoring_strategy block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#scoring_strategy AwsEksCluster#scoring_strategy}
        */
        readonly scoringStrategy?: ScoringStrategyProperty;
    }
    class NodeResourcesFitPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NodeResourcesFitProperty | undefined;
        set internalValue(value: NodeResourcesFitProperty | undefined);
        private _scoringStrategy;
        get scoringStrategy(): ScoringStrategyPropertyOutputReference;
        putScoringStrategy(value: ScoringStrategyProperty): void;
        resetScoringStrategy(): void;
        get scoringStrategyInput(): ScoringStrategyProperty | undefined;
    }
    interface KubeSchedulerConfigProperty {
        /**
        * node_resources_fit block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#node_resources_fit AwsEksCluster#node_resources_fit}
        */
        readonly nodeResourcesFit?: NodeResourcesFitProperty;
    }
    class KubeSchedulerConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): KubeSchedulerConfigProperty | undefined;
        set internalValue(value: KubeSchedulerConfigProperty | undefined);
        private _nodeResourcesFit;
        get nodeResourcesFit(): NodeResourcesFitPropertyOutputReference;
        putNodeResourcesFit(value: NodeResourcesFitProperty): void;
        resetNodeResourcesFit(): void;
        get nodeResourcesFitInput(): NodeResourcesFitProperty | undefined;
    }
    interface ElasticLoadBalancingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#enabled AwsEksCluster#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
    }
    class ElasticLoadBalancingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ElasticLoadBalancingProperty | undefined;
        set internalValue(value: ElasticLoadBalancingProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface KubernetesNetworkConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#ip_family AwsEksCluster#ip_family}
        */
        readonly ipFamily?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#service_ipv4_cidr AwsEksCluster#service_ipv4_cidr}
        */
        readonly serviceIpv4Cidr?: string;
        /**
        * elastic_load_balancing block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#elastic_load_balancing AwsEksCluster#elastic_load_balancing}
        */
        readonly elasticLoadBalancing?: ElasticLoadBalancingProperty;
    }
    class KubernetesNetworkConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): KubernetesNetworkConfigProperty | undefined;
        set internalValue(value: KubernetesNetworkConfigProperty | undefined);
        private _ipFamily?;
        get ipFamily(): string;
        set ipFamily(value: string);
        resetIpFamily(): void;
        get ipFamilyInput(): string | undefined;
        private _serviceIpv4Cidr?;
        get serviceIpv4Cidr(): string;
        set serviceIpv4Cidr(value: string);
        resetServiceIpv4Cidr(): void;
        get serviceIpv4CidrInput(): string | undefined;
        get serviceIpv6Cidr(): string;
        private _elasticLoadBalancing;
        get elasticLoadBalancing(): ElasticLoadBalancingPropertyOutputReference;
        putElasticLoadBalancing(value: ElasticLoadBalancingProperty): void;
        resetElasticLoadBalancing(): void;
        get elasticLoadBalancingInput(): ElasticLoadBalancingProperty | undefined;
    }
    interface ControlPlanePlacementProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#group_name AwsEksCluster#group_name}
        */
        readonly groupName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#spread_level AwsEksCluster#spread_level}
        */
        readonly spreadLevel?: string;
    }
    class ControlPlanePlacementPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ControlPlanePlacementProperty | undefined;
        set internalValue(value: ControlPlanePlacementProperty | undefined);
        private _groupName?;
        get groupName(): string;
        set groupName(value: string);
        resetGroupName(): void;
        get groupNameInput(): string | undefined;
        private _spreadLevel?;
        get spreadLevel(): string;
        set spreadLevel(value: string);
        resetSpreadLevel(): void;
        get spreadLevelInput(): string | undefined;
    }
    interface EtcdPlacementProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#spread_level AwsEksCluster#spread_level}
        */
        readonly spreadLevel?: string;
    }
    class EtcdPlacementPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EtcdPlacementProperty | undefined;
        set internalValue(value: EtcdPlacementProperty | undefined);
        private _spreadLevel?;
        get spreadLevel(): string;
        set spreadLevel(value: string);
        resetSpreadLevel(): void;
        get spreadLevelInput(): string | undefined;
    }
    interface OutpostConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#control_plane_instance_type AwsEksCluster#control_plane_instance_type}
        */
        readonly controlPlaneInstanceType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#etcd_instance_type AwsEksCluster#etcd_instance_type}
        */
        readonly etcdInstanceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#outpost_arns AwsEksCluster#outpost_arns}
        */
        readonly outpostArns: string[];
        /**
        * control_plane_placement block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#control_plane_placement AwsEksCluster#control_plane_placement}
        */
        readonly controlPlanePlacement?: ControlPlanePlacementProperty;
        /**
        * etcd_placement block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#etcd_placement AwsEksCluster#etcd_placement}
        */
        readonly etcdPlacement?: EtcdPlacementProperty;
    }
    class OutpostConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OutpostConfigProperty | undefined;
        set internalValue(value: OutpostConfigProperty | undefined);
        private _controlPlaneInstanceType?;
        get controlPlaneInstanceType(): string;
        set controlPlaneInstanceType(value: string);
        get controlPlaneInstanceTypeInput(): string | undefined;
        private _etcdInstanceType?;
        get etcdInstanceType(): string;
        set etcdInstanceType(value: string);
        resetEtcdInstanceType(): void;
        get etcdInstanceTypeInput(): string | undefined;
        private _outpostArns?;
        get outpostArns(): string[];
        set outpostArns(value: string[]);
        get outpostArnsInput(): string[] | undefined;
        private _controlPlanePlacement;
        get controlPlanePlacement(): ControlPlanePlacementPropertyOutputReference;
        putControlPlanePlacement(value: ControlPlanePlacementProperty): void;
        resetControlPlanePlacement(): void;
        get controlPlanePlacementInput(): ControlPlanePlacementProperty | undefined;
        private _etcdPlacement;
        get etcdPlacement(): EtcdPlacementPropertyOutputReference;
        putEtcdPlacement(value: EtcdPlacementProperty): void;
        resetEtcdPlacement(): void;
        get etcdPlacementInput(): EtcdPlacementProperty | undefined;
    }
    interface RemoteNodeNetworksProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#cidrs AwsEksCluster#cidrs}
        */
        readonly cidrs?: string[];
    }
    class RemoteNodeNetworksPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RemoteNodeNetworksProperty | undefined;
        set internalValue(value: RemoteNodeNetworksProperty | undefined);
        private _cidrs?;
        get cidrs(): string[];
        set cidrs(value: string[]);
        resetCidrs(): void;
        get cidrsInput(): string[] | undefined;
    }
    interface RemotePodNetworksProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#cidrs AwsEksCluster#cidrs}
        */
        readonly cidrs?: string[];
    }
    class RemotePodNetworksPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RemotePodNetworksProperty | undefined;
        set internalValue(value: RemotePodNetworksProperty | undefined);
        private _cidrs?;
        get cidrs(): string[];
        set cidrs(value: string[]);
        resetCidrs(): void;
        get cidrsInput(): string[] | undefined;
    }
    interface RemoteNetworkConfigProperty {
        /**
        * remote_node_networks block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#remote_node_networks AwsEksCluster#remote_node_networks}
        */
        readonly remoteNodeNetworks?: RemoteNodeNetworksProperty;
        /**
        * remote_pod_networks block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#remote_pod_networks AwsEksCluster#remote_pod_networks}
        */
        readonly remotePodNetworks?: RemotePodNetworksProperty;
    }
    class RemoteNetworkConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RemoteNetworkConfigProperty | undefined;
        set internalValue(value: RemoteNetworkConfigProperty | undefined);
        private _remoteNodeNetworks;
        get remoteNodeNetworks(): RemoteNodeNetworksPropertyOutputReference;
        putRemoteNodeNetworks(value: RemoteNodeNetworksProperty): void;
        resetRemoteNodeNetworks(): void;
        get remoteNodeNetworksInput(): RemoteNodeNetworksProperty | undefined;
        private _remotePodNetworks;
        get remotePodNetworks(): RemotePodNetworksPropertyOutputReference;
        putRemotePodNetworks(value: RemotePodNetworksProperty): void;
        resetRemotePodNetworks(): void;
        get remotePodNetworksInput(): RemotePodNetworksProperty | undefined;
    }
    interface BlockStorageProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#enabled AwsEksCluster#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
    }
    class BlockStoragePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BlockStorageProperty | undefined;
        set internalValue(value: BlockStorageProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface StorageConfigProperty {
        /**
        * block_storage block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#block_storage AwsEksCluster#block_storage}
        */
        readonly blockStorage?: BlockStorageProperty;
    }
    class StorageConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StorageConfigProperty | undefined;
        set internalValue(value: StorageConfigProperty | undefined);
        private _blockStorage;
        get blockStorage(): BlockStoragePropertyOutputReference;
        putBlockStorage(value: BlockStorageProperty): void;
        resetBlockStorage(): void;
        get blockStorageInput(): BlockStorageProperty | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#create AwsEksCluster#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#delete AwsEksCluster#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#update AwsEksCluster#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface UpgradePolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#support_type AwsEksCluster#support_type}
        */
        readonly supportType?: string;
    }
    class UpgradePolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UpgradePolicyProperty | undefined;
        set internalValue(value: UpgradePolicyProperty | undefined);
        private _supportType?;
        get supportType(): string;
        set supportType(value: string);
        resetSupportType(): void;
        get supportTypeInput(): string | undefined;
    }
    interface VpcConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#control_plane_egress_mode AwsEksCluster#control_plane_egress_mode}
        */
        readonly controlPlaneEgressMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#endpoint_private_access AwsEksCluster#endpoint_private_access}
        */
        readonly endpointPrivateAccess?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#endpoint_public_access AwsEksCluster#endpoint_public_access}
        */
        readonly endpointPublicAccess?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#public_access_cidrs AwsEksCluster#public_access_cidrs}
        */
        readonly publicAccessCidrs?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#security_group_ids AwsEksCluster#security_group_ids}
        */
        readonly securityGroupIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#subnet_ids AwsEksCluster#subnet_ids}
        */
        readonly subnetIds: string[];
    }
    class VpcConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VpcConfigProperty | undefined;
        set internalValue(value: VpcConfigProperty | undefined);
        get clusterSecurityGroupId(): string;
        private _controlPlaneEgressMode?;
        get controlPlaneEgressMode(): string;
        set controlPlaneEgressMode(value: string);
        resetControlPlaneEgressMode(): void;
        get controlPlaneEgressModeInput(): string | undefined;
        private _endpointPrivateAccess?;
        get endpointPrivateAccess(): boolean | cdktn.IResolvable;
        set endpointPrivateAccess(value: boolean | cdktn.IResolvable);
        resetEndpointPrivateAccess(): void;
        get endpointPrivateAccessInput(): boolean | cdktn.IResolvable | undefined;
        private _endpointPublicAccess?;
        get endpointPublicAccess(): boolean | cdktn.IResolvable;
        set endpointPublicAccess(value: boolean | cdktn.IResolvable);
        resetEndpointPublicAccess(): void;
        get endpointPublicAccessInput(): boolean | cdktn.IResolvable | undefined;
        private _publicAccessCidrs?;
        get publicAccessCidrs(): string[];
        set publicAccessCidrs(value: string[]);
        resetPublicAccessCidrs(): void;
        get publicAccessCidrsInput(): string[] | undefined;
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        resetSecurityGroupIds(): void;
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        get subnetIdsInput(): string[] | undefined;
        get vpcId(): string;
    }
    interface ZonalShiftConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#enabled AwsEksCluster#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
    }
    class ZonalShiftConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ZonalShiftConfigProperty | undefined;
        set internalValue(value: ZonalShiftConfigProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
}
