import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsIdentitystoreUserConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_user#id DataAwsIdentitystoreUser#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_user#identity_store_id DataAwsIdentitystoreUser#identity_store_id}
    */
    readonly identityStoreId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_user#region DataAwsIdentitystoreUser#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_user#user_id DataAwsIdentitystoreUser#user_id}
    */
    readonly userId?: string;
    /**
    * alternate_identifier block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_user#alternate_identifier DataAwsIdentitystoreUser#alternate_identifier}
    */
    readonly alternateIdentifier?: DataAwsIdentitystoreUser.AlternateIdentifierProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_user aws_identitystore_user}
*/
export declare class DataAwsIdentitystoreUser extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_identitystore_user";
    /**
    * Generates CDKTN code for importing a DataAwsIdentitystoreUser resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsIdentitystoreUser to import
    * @param importFromId The id of the existing DataAwsIdentitystoreUser that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_user#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsIdentitystoreUser to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_user aws_identitystore_user} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsIdentitystoreUserConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsIdentitystoreUserConfig);
    private _addresses;
    get addresses(): DataAwsIdentitystoreUser.AddressesPropertyList;
    get displayName(): string;
    private _emails;
    get emails(): DataAwsIdentitystoreUser.EmailsPropertyList;
    private _externalIds;
    get externalIds(): DataAwsIdentitystoreUser.ExternalIdsPropertyList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _identityStoreId?;
    get identityStoreId(): string;
    set identityStoreId(value: string);
    get identityStoreIdInput(): string | undefined;
    get locale(): string;
    private _name;
    get name(): DataAwsIdentitystoreUser.NamePropertyList;
    get nickname(): string;
    private _phoneNumbers;
    get phoneNumbers(): DataAwsIdentitystoreUser.PhoneNumbersPropertyList;
    get preferredLanguage(): string;
    get profileUrl(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get timezone(): string;
    get title(): string;
    private _userId?;
    get userId(): string;
    set userId(value: string);
    resetUserId(): void;
    get userIdInput(): string | undefined;
    get userName(): string;
    get userStatus(): string;
    get userType(): string;
    private _alternateIdentifier;
    get alternateIdentifier(): DataAwsIdentitystoreUser.AlternateIdentifierPropertyOutputReference;
    putAlternateIdentifier(value: DataAwsIdentitystoreUser.AlternateIdentifierProperty): void;
    resetAlternateIdentifier(): void;
    get alternateIdentifierInput(): DataAwsIdentitystoreUser.AlternateIdentifierProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsIdentitystoreUserAddressesPropertyToTerraform(struct?: DataAwsIdentitystoreUser.AddressesProperty): any;
export declare function dataAwsIdentitystoreUserAddressesPropertyToHclTerraform(struct?: DataAwsIdentitystoreUser.AddressesProperty): any;
export declare function dataAwsIdentitystoreUserEmailsPropertyToTerraform(struct?: DataAwsIdentitystoreUser.EmailsProperty): any;
export declare function dataAwsIdentitystoreUserEmailsPropertyToHclTerraform(struct?: DataAwsIdentitystoreUser.EmailsProperty): any;
export declare function dataAwsIdentitystoreUserExternalIdsPropertyToTerraform(struct?: DataAwsIdentitystoreUser.ExternalIdsProperty): any;
export declare function dataAwsIdentitystoreUserExternalIdsPropertyToHclTerraform(struct?: DataAwsIdentitystoreUser.ExternalIdsProperty): any;
export declare function dataAwsIdentitystoreUserNamePropertyToTerraform(struct?: DataAwsIdentitystoreUser.NameProperty): any;
export declare function dataAwsIdentitystoreUserNamePropertyToHclTerraform(struct?: DataAwsIdentitystoreUser.NameProperty): any;
export declare function dataAwsIdentitystoreUserPhoneNumbersPropertyToTerraform(struct?: DataAwsIdentitystoreUser.PhoneNumbersProperty): any;
export declare function dataAwsIdentitystoreUserPhoneNumbersPropertyToHclTerraform(struct?: DataAwsIdentitystoreUser.PhoneNumbersProperty): any;
export declare function dataAwsIdentitystoreUserExternalIdPropertyToTerraform(struct?: DataAwsIdentitystoreUser.ExternalIdPropertyOutputReference | DataAwsIdentitystoreUser.ExternalIdProperty): any;
export declare function dataAwsIdentitystoreUserExternalIdPropertyToHclTerraform(struct?: DataAwsIdentitystoreUser.ExternalIdPropertyOutputReference | DataAwsIdentitystoreUser.ExternalIdProperty): any;
export declare function dataAwsIdentitystoreUserUniqueAttributePropertyToTerraform(struct?: DataAwsIdentitystoreUser.UniqueAttributePropertyOutputReference | DataAwsIdentitystoreUser.UniqueAttributeProperty): any;
export declare function dataAwsIdentitystoreUserUniqueAttributePropertyToHclTerraform(struct?: DataAwsIdentitystoreUser.UniqueAttributePropertyOutputReference | DataAwsIdentitystoreUser.UniqueAttributeProperty): any;
export declare function dataAwsIdentitystoreUserAlternateIdentifierPropertyToTerraform(struct?: DataAwsIdentitystoreUser.AlternateIdentifierPropertyOutputReference | DataAwsIdentitystoreUser.AlternateIdentifierProperty): any;
export declare function dataAwsIdentitystoreUserAlternateIdentifierPropertyToHclTerraform(struct?: DataAwsIdentitystoreUser.AlternateIdentifierPropertyOutputReference | DataAwsIdentitystoreUser.AlternateIdentifierProperty): any;
export declare namespace DataAwsIdentitystoreUser {
    interface AddressesProperty {
    }
    class AddressesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AddressesProperty | undefined;
        set internalValue(value: AddressesProperty | undefined);
        get country(): string;
        get formatted(): string;
        get locality(): string;
        get postalCode(): string;
        get primary(): cdktn.IResolvable;
        get region(): string;
        get streetAddress(): string;
        get type(): string;
    }
    class AddressesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AddressesPropertyOutputReference;
    }
    interface EmailsProperty {
    }
    class EmailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EmailsProperty | undefined;
        set internalValue(value: EmailsProperty | undefined);
        get primary(): cdktn.IResolvable;
        get type(): string;
        get value(): string;
    }
    class EmailsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EmailsPropertyOutputReference;
    }
    interface ExternalIdsProperty {
    }
    class ExternalIdsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExternalIdsProperty | undefined;
        set internalValue(value: ExternalIdsProperty | undefined);
        get id(): string;
        get issuer(): string;
    }
    class ExternalIdsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExternalIdsPropertyOutputReference;
    }
    interface NameProperty {
    }
    class NamePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NameProperty | undefined;
        set internalValue(value: NameProperty | undefined);
        get familyName(): string;
        get formatted(): string;
        get givenName(): string;
        get honorificPrefix(): string;
        get honorificSuffix(): string;
        get middleName(): string;
    }
    class NamePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NamePropertyOutputReference;
    }
    interface PhoneNumbersProperty {
    }
    class PhoneNumbersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PhoneNumbersProperty | undefined;
        set internalValue(value: PhoneNumbersProperty | undefined);
        get primary(): cdktn.IResolvable;
        get type(): string;
        get value(): string;
    }
    class PhoneNumbersPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PhoneNumbersPropertyOutputReference;
    }
    interface ExternalIdProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_user#id DataAwsIdentitystoreUser#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_user#issuer DataAwsIdentitystoreUser#issuer}
        */
        readonly issuer: string;
    }
    class ExternalIdPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ExternalIdProperty | undefined;
        set internalValue(value: ExternalIdProperty | undefined);
        private _id?;
        get id(): string;
        set id(value: string);
        get idInput(): string | undefined;
        private _issuer?;
        get issuer(): string;
        set issuer(value: string);
        get issuerInput(): string | undefined;
    }
    interface UniqueAttributeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_user#attribute_path DataAwsIdentitystoreUser#attribute_path}
        */
        readonly attributePath: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_user#attribute_value DataAwsIdentitystoreUser#attribute_value}
        */
        readonly attributeValue: string;
    }
    class UniqueAttributePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UniqueAttributeProperty | undefined;
        set internalValue(value: UniqueAttributeProperty | undefined);
        private _attributePath?;
        get attributePath(): string;
        set attributePath(value: string);
        get attributePathInput(): string | undefined;
        private _attributeValue?;
        get attributeValue(): string;
        set attributeValue(value: string);
        get attributeValueInput(): string | undefined;
    }
    interface AlternateIdentifierProperty {
        /**
        * external_id block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_user#external_id DataAwsIdentitystoreUser#external_id}
        */
        readonly externalId?: ExternalIdProperty;
        /**
        * unique_attribute block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_user#unique_attribute DataAwsIdentitystoreUser#unique_attribute}
        */
        readonly uniqueAttribute?: UniqueAttributeProperty;
    }
    class AlternateIdentifierPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AlternateIdentifierProperty | undefined;
        set internalValue(value: AlternateIdentifierProperty | undefined);
        private _externalId;
        get externalId(): ExternalIdPropertyOutputReference;
        putExternalId(value: ExternalIdProperty): void;
        resetExternalId(): void;
        get externalIdInput(): ExternalIdProperty | undefined;
        private _uniqueAttribute;
        get uniqueAttribute(): UniqueAttributePropertyOutputReference;
        putUniqueAttribute(value: UniqueAttributeProperty): void;
        resetUniqueAttribute(): void;
        get uniqueAttributeInput(): UniqueAttributeProperty | undefined;
    }
}
