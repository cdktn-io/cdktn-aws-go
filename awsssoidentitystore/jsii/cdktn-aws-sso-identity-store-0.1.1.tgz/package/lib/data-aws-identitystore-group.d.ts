import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsIdentitystoreGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_group#group_id DataAwsIdentitystoreGroup#group_id}
    */
    readonly groupId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_group#id DataAwsIdentitystoreGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_group#identity_store_id DataAwsIdentitystoreGroup#identity_store_id}
    */
    readonly identityStoreId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_group#region DataAwsIdentitystoreGroup#region}
    */
    readonly region?: string;
    /**
    * alternate_identifier block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_group#alternate_identifier DataAwsIdentitystoreGroup#alternate_identifier}
    */
    readonly alternateIdentifier?: DataAwsIdentitystoreGroup.AlternateIdentifierProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_group aws_identitystore_group}
*/
export declare class DataAwsIdentitystoreGroup extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_identitystore_group";
    /**
    * Generates CDKTN code for importing a DataAwsIdentitystoreGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsIdentitystoreGroup to import
    * @param importFromId The id of the existing DataAwsIdentitystoreGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsIdentitystoreGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_group aws_identitystore_group} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsIdentitystoreGroupConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsIdentitystoreGroupConfig);
    get description(): string;
    get displayName(): string;
    private _externalIds;
    get externalIds(): DataAwsIdentitystoreGroup.ExternalIdsPropertyList;
    private _groupId?;
    get groupId(): string;
    set groupId(value: string);
    resetGroupId(): void;
    get groupIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _identityStoreId?;
    get identityStoreId(): string;
    set identityStoreId(value: string);
    get identityStoreIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _alternateIdentifier;
    get alternateIdentifier(): DataAwsIdentitystoreGroup.AlternateIdentifierPropertyOutputReference;
    putAlternateIdentifier(value: DataAwsIdentitystoreGroup.AlternateIdentifierProperty): void;
    resetAlternateIdentifier(): void;
    get alternateIdentifierInput(): DataAwsIdentitystoreGroup.AlternateIdentifierProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsIdentitystoreGroupExternalIdsPropertyToTerraform(struct?: DataAwsIdentitystoreGroup.ExternalIdsProperty): any;
export declare function dataAwsIdentitystoreGroupExternalIdsPropertyToHclTerraform(struct?: DataAwsIdentitystoreGroup.ExternalIdsProperty): any;
export declare function dataAwsIdentitystoreGroupExternalIdPropertyToTerraform(struct?: DataAwsIdentitystoreGroup.ExternalIdPropertyOutputReference | DataAwsIdentitystoreGroup.ExternalIdProperty): any;
export declare function dataAwsIdentitystoreGroupExternalIdPropertyToHclTerraform(struct?: DataAwsIdentitystoreGroup.ExternalIdPropertyOutputReference | DataAwsIdentitystoreGroup.ExternalIdProperty): any;
export declare function dataAwsIdentitystoreGroupUniqueAttributePropertyToTerraform(struct?: DataAwsIdentitystoreGroup.UniqueAttributePropertyOutputReference | DataAwsIdentitystoreGroup.UniqueAttributeProperty): any;
export declare function dataAwsIdentitystoreGroupUniqueAttributePropertyToHclTerraform(struct?: DataAwsIdentitystoreGroup.UniqueAttributePropertyOutputReference | DataAwsIdentitystoreGroup.UniqueAttributeProperty): any;
export declare function dataAwsIdentitystoreGroupAlternateIdentifierPropertyToTerraform(struct?: DataAwsIdentitystoreGroup.AlternateIdentifierPropertyOutputReference | DataAwsIdentitystoreGroup.AlternateIdentifierProperty): any;
export declare function dataAwsIdentitystoreGroupAlternateIdentifierPropertyToHclTerraform(struct?: DataAwsIdentitystoreGroup.AlternateIdentifierPropertyOutputReference | DataAwsIdentitystoreGroup.AlternateIdentifierProperty): any;
export declare namespace DataAwsIdentitystoreGroup {
    interface ExternalIdsProperty {
    }
    class ExternalIdsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExternalIdsProperty | undefined;
        set internalValue(value: ExternalIdsProperty | undefined);
        get id(): string;
        get issuer(): string;
    }
    class ExternalIdsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExternalIdsPropertyOutputReference;
    }
    interface ExternalIdProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_group#id DataAwsIdentitystoreGroup#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_group#issuer DataAwsIdentitystoreGroup#issuer}
        */
        readonly issuer: string;
    }
    class ExternalIdPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ExternalIdProperty | undefined;
        set internalValue(value: ExternalIdProperty | undefined);
        private _id?;
        get id(): string;
        set id(value: string);
        get idInput(): string | undefined;
        private _issuer?;
        get issuer(): string;
        set issuer(value: string);
        get issuerInput(): string | undefined;
    }
    interface UniqueAttributeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_group#attribute_path DataAwsIdentitystoreGroup#attribute_path}
        */
        readonly attributePath: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_group#attribute_value DataAwsIdentitystoreGroup#attribute_value}
        */
        readonly attributeValue: string;
    }
    class UniqueAttributePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UniqueAttributeProperty | undefined;
        set internalValue(value: UniqueAttributeProperty | undefined);
        private _attributePath?;
        get attributePath(): string;
        set attributePath(value: string);
        get attributePathInput(): string | undefined;
        private _attributeValue?;
        get attributeValue(): string;
        set attributeValue(value: string);
        get attributeValueInput(): string | undefined;
    }
    interface AlternateIdentifierProperty {
        /**
        * external_id block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_group#external_id DataAwsIdentitystoreGroup#external_id}
        */
        readonly externalId?: ExternalIdProperty;
        /**
        * unique_attribute block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_group#unique_attribute DataAwsIdentitystoreGroup#unique_attribute}
        */
        readonly uniqueAttribute?: UniqueAttributeProperty;
    }
    class AlternateIdentifierPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AlternateIdentifierProperty | undefined;
        set internalValue(value: AlternateIdentifierProperty | undefined);
        private _externalId;
        get externalId(): ExternalIdPropertyOutputReference;
        putExternalId(value: ExternalIdProperty): void;
        resetExternalId(): void;
        get externalIdInput(): ExternalIdProperty | undefined;
        private _uniqueAttribute;
        get uniqueAttribute(): UniqueAttributePropertyOutputReference;
        putUniqueAttribute(value: UniqueAttributeProperty): void;
        resetUniqueAttribute(): void;
        get uniqueAttributeInput(): UniqueAttributeProperty | undefined;
    }
}
