import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsIdentitystoreGroupMembershipsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_group_memberships#group_id DataAwsIdentitystoreGroupMemberships#group_id}
    */
    readonly groupId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_group_memberships#identity_store_id DataAwsIdentitystoreGroupMemberships#identity_store_id}
    */
    readonly identityStoreId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_group_memberships#region DataAwsIdentitystoreGroupMemberships#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_group_memberships aws_identitystore_group_memberships}
*/
export declare class DataAwsIdentitystoreGroupMemberships extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_identitystore_group_memberships";
    /**
    * Generates CDKTN code for importing a DataAwsIdentitystoreGroupMemberships resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsIdentitystoreGroupMemberships to import
    * @param importFromId The id of the existing DataAwsIdentitystoreGroupMemberships that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_group_memberships#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsIdentitystoreGroupMemberships to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_group_memberships aws_identitystore_group_memberships} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsIdentitystoreGroupMembershipsConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsIdentitystoreGroupMembershipsConfig);
    private _groupId?;
    get groupId(): string;
    set groupId(value: string);
    get groupIdInput(): string | undefined;
    private _groupMemberships;
    get groupMemberships(): DataAwsIdentitystoreGroupMemberships.GroupMembershipsPropertyList;
    private _identityStoreId?;
    get identityStoreId(): string;
    set identityStoreId(value: string);
    get identityStoreIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsIdentitystoreGroupMembershipsMemberIdPropertyToTerraform(struct?: DataAwsIdentitystoreGroupMemberships.MemberIdProperty): any;
export declare function dataAwsIdentitystoreGroupMembershipsMemberIdPropertyToHclTerraform(struct?: DataAwsIdentitystoreGroupMemberships.MemberIdProperty): any;
export declare function dataAwsIdentitystoreGroupMembershipsGroupMembershipsPropertyToTerraform(struct?: DataAwsIdentitystoreGroupMemberships.GroupMembershipsProperty): any;
export declare function dataAwsIdentitystoreGroupMembershipsGroupMembershipsPropertyToHclTerraform(struct?: DataAwsIdentitystoreGroupMemberships.GroupMembershipsProperty): any;
export declare namespace DataAwsIdentitystoreGroupMemberships {
    interface MemberIdProperty {
    }
    class MemberIdPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MemberIdProperty | undefined;
        set internalValue(value: MemberIdProperty | undefined);
        get userId(): string;
    }
    interface GroupMembershipsProperty {
    }
    class GroupMembershipsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GroupMembershipsProperty | undefined;
        set internalValue(value: GroupMembershipsProperty | undefined);
        get groupId(): string;
        get identityStoreId(): string;
        private _memberId;
        get memberId(): MemberIdPropertyOutputReference;
        get membershipId(): string;
    }
    class GroupMembershipsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GroupMembershipsPropertyOutputReference;
    }
}
