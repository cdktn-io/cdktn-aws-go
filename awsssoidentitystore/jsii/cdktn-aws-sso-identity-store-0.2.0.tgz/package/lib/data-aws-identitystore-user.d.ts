import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfUserConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_user#id DataTfUser#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_user#identity_store_id DataTfUser#identity_store_id}
    */
    readonly identityStoreId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_user#region DataTfUser#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_user#user_id DataTfUser#user_id}
    */
    readonly userId?: string;
    /**
    * alternate_identifier block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_user#alternate_identifier DataTfUser#alternate_identifier}
    */
    readonly alternateIdentifier?: DataTfUser.AlternateIdentifierProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_user aws_identitystore_user}
*/
export declare class DataTfUser extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_identitystore_user";
    /**
    * Generates CDKTN code for importing a DataTfUser resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfUser to import
    * @param importFromId The id of the existing DataTfUser that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_user#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfUser to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_user aws_identitystore_user} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfUserConfig
    */
    constructor(scope: Construct, id: string, config: DataTfUserConfig);
    private _addresses;
    get addresses(): DataTfUser.AddressesPropertyList;
    get displayName(): string;
    private _emails;
    get emails(): DataTfUser.EmailsPropertyList;
    private _externalIds;
    get externalIds(): DataTfUser.ExternalIdsPropertyList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _identityStoreId?;
    get identityStoreId(): string;
    set identityStoreId(value: string);
    get identityStoreIdInput(): string | undefined;
    get locale(): string;
    private _name;
    get name(): DataTfUser.NamePropertyList;
    get nickname(): string;
    private _phoneNumbers;
    get phoneNumbers(): DataTfUser.PhoneNumbersPropertyList;
    get preferredLanguage(): string;
    get profileUrl(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get timezone(): string;
    get title(): string;
    private _userId?;
    get userId(): string;
    set userId(value: string);
    resetUserId(): void;
    get userIdInput(): string | undefined;
    get userName(): string;
    get userStatus(): string;
    get userType(): string;
    private _alternateIdentifier;
    get alternateIdentifier(): DataTfUser.AlternateIdentifierPropertyOutputReference;
    putAlternateIdentifier(value: DataTfUser.AlternateIdentifierProperty): void;
    resetAlternateIdentifier(): void;
    get alternateIdentifierInput(): DataTfUser.AlternateIdentifierProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfUserAddressesPropertyToTerraform(struct?: DataTfUser.AddressesProperty): any;
export declare function dataTfUserAddressesPropertyToHclTerraform(struct?: DataTfUser.AddressesProperty): any;
export declare function dataTfUserEmailsPropertyToTerraform(struct?: DataTfUser.EmailsProperty): any;
export declare function dataTfUserEmailsPropertyToHclTerraform(struct?: DataTfUser.EmailsProperty): any;
export declare function dataTfUserExternalIdsPropertyToTerraform(struct?: DataTfUser.ExternalIdsProperty): any;
export declare function dataTfUserExternalIdsPropertyToHclTerraform(struct?: DataTfUser.ExternalIdsProperty): any;
export declare function dataTfUserNamePropertyToTerraform(struct?: DataTfUser.NameProperty): any;
export declare function dataTfUserNamePropertyToHclTerraform(struct?: DataTfUser.NameProperty): any;
export declare function dataTfUserPhoneNumbersPropertyToTerraform(struct?: DataTfUser.PhoneNumbersProperty): any;
export declare function dataTfUserPhoneNumbersPropertyToHclTerraform(struct?: DataTfUser.PhoneNumbersProperty): any;
export declare function dataTfUserExternalIdPropertyToTerraform(struct?: DataTfUser.ExternalIdPropertyOutputReference | DataTfUser.ExternalIdProperty): any;
export declare function dataTfUserExternalIdPropertyToHclTerraform(struct?: DataTfUser.ExternalIdPropertyOutputReference | DataTfUser.ExternalIdProperty): any;
export declare function dataTfUserUniqueAttributePropertyToTerraform(struct?: DataTfUser.UniqueAttributePropertyOutputReference | DataTfUser.UniqueAttributeProperty): any;
export declare function dataTfUserUniqueAttributePropertyToHclTerraform(struct?: DataTfUser.UniqueAttributePropertyOutputReference | DataTfUser.UniqueAttributeProperty): any;
export declare function dataTfUserAlternateIdentifierPropertyToTerraform(struct?: DataTfUser.AlternateIdentifierPropertyOutputReference | DataTfUser.AlternateIdentifierProperty): any;
export declare function dataTfUserAlternateIdentifierPropertyToHclTerraform(struct?: DataTfUser.AlternateIdentifierPropertyOutputReference | DataTfUser.AlternateIdentifierProperty): any;
export declare namespace DataTfUser {
    interface AddressesProperty {
    }
    class AddressesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AddressesProperty | undefined;
        set internalValue(value: AddressesProperty | undefined);
        get country(): string;
        get formatted(): string;
        get locality(): string;
        get postalCode(): string;
        get primary(): cdktn.IResolvable;
        get region(): string;
        get streetAddress(): string;
        get type(): string;
    }
    class AddressesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AddressesPropertyOutputReference;
    }
    interface EmailsProperty {
    }
    class EmailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EmailsProperty | undefined;
        set internalValue(value: EmailsProperty | undefined);
        get primary(): cdktn.IResolvable;
        get type(): string;
        get value(): string;
    }
    class EmailsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EmailsPropertyOutputReference;
    }
    interface ExternalIdsProperty {
    }
    class ExternalIdsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExternalIdsProperty | undefined;
        set internalValue(value: ExternalIdsProperty | undefined);
        get id(): string;
        get issuer(): string;
    }
    class ExternalIdsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExternalIdsPropertyOutputReference;
    }
    interface NameProperty {
    }
    class NamePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NameProperty | undefined;
        set internalValue(value: NameProperty | undefined);
        get familyName(): string;
        get formatted(): string;
        get givenName(): string;
        get honorificPrefix(): string;
        get honorificSuffix(): string;
        get middleName(): string;
    }
    class NamePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NamePropertyOutputReference;
    }
    interface PhoneNumbersProperty {
    }
    class PhoneNumbersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PhoneNumbersProperty | undefined;
        set internalValue(value: PhoneNumbersProperty | undefined);
        get primary(): cdktn.IResolvable;
        get type(): string;
        get value(): string;
    }
    class PhoneNumbersPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PhoneNumbersPropertyOutputReference;
    }
    interface ExternalIdProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_user#id DataTfUser#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_user#issuer DataTfUser#issuer}
        */
        readonly issuer: string;
    }
    class ExternalIdPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ExternalIdProperty | undefined;
        set internalValue(value: ExternalIdProperty | undefined);
        private _id?;
        get id(): string;
        set id(value: string);
        get idInput(): string | undefined;
        private _issuer?;
        get issuer(): string;
        set issuer(value: string);
        get issuerInput(): string | undefined;
    }
    interface UniqueAttributeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_user#attribute_path DataTfUser#attribute_path}
        */
        readonly attributePath: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_user#attribute_value DataTfUser#attribute_value}
        */
        readonly attributeValue: string;
    }
    class UniqueAttributePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UniqueAttributeProperty | undefined;
        set internalValue(value: UniqueAttributeProperty | undefined);
        private _attributePath?;
        get attributePath(): string;
        set attributePath(value: string);
        get attributePathInput(): string | undefined;
        private _attributeValue?;
        get attributeValue(): string;
        set attributeValue(value: string);
        get attributeValueInput(): string | undefined;
    }
    interface AlternateIdentifierProperty {
        /**
        * external_id block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_user#external_id DataTfUser#external_id}
        */
        readonly externalId?: ExternalIdProperty;
        /**
        * unique_attribute block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_user#unique_attribute DataTfUser#unique_attribute}
        */
        readonly uniqueAttribute?: UniqueAttributeProperty;
    }
    class AlternateIdentifierPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AlternateIdentifierProperty | undefined;
        set internalValue(value: AlternateIdentifierProperty | undefined);
        private _externalId;
        get externalId(): ExternalIdPropertyOutputReference;
        putExternalId(value: ExternalIdProperty): void;
        resetExternalId(): void;
        get externalIdInput(): ExternalIdProperty | undefined;
        private _uniqueAttribute;
        get uniqueAttribute(): UniqueAttributePropertyOutputReference;
        putUniqueAttribute(value: UniqueAttributeProperty): void;
        resetUniqueAttribute(): void;
        get uniqueAttributeInput(): UniqueAttributeProperty | undefined;
    }
}
