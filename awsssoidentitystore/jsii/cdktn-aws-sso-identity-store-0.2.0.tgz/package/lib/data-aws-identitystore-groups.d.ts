import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfGroupsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_groups#identity_store_id DataTfGroups#identity_store_id}
    */
    readonly identityStoreId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_groups#region DataTfGroups#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_groups aws_identitystore_groups}
*/
export declare class DataTfGroups extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_identitystore_groups";
    /**
    * Generates CDKTN code for importing a DataTfGroups resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfGroups to import
    * @param importFromId The id of the existing DataTfGroups that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_groups#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfGroups to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_groups aws_identitystore_groups} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfGroupsConfig
    */
    constructor(scope: Construct, id: string, config: DataTfGroupsConfig);
    private _groups;
    get groups(): DataTfGroups.GroupsPropertyList;
    private _identityStoreId?;
    get identityStoreId(): string;
    set identityStoreId(value: string);
    get identityStoreIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfGroupsExternalIdsPropertyToTerraform(struct?: DataTfGroups.ExternalIdsProperty): any;
export declare function dataTfGroupsExternalIdsPropertyToHclTerraform(struct?: DataTfGroups.ExternalIdsProperty): any;
export declare function dataTfGroupsGroupsPropertyToTerraform(struct?: DataTfGroups.GroupsProperty): any;
export declare function dataTfGroupsGroupsPropertyToHclTerraform(struct?: DataTfGroups.GroupsProperty): any;
export declare namespace DataTfGroups {
    interface ExternalIdsProperty {
    }
    class ExternalIdsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExternalIdsProperty | undefined;
        set internalValue(value: ExternalIdsProperty | undefined);
        get id(): string;
        get issuer(): string;
    }
    class ExternalIdsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExternalIdsPropertyOutputReference;
    }
    interface GroupsProperty {
    }
    class GroupsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GroupsProperty | undefined;
        set internalValue(value: GroupsProperty | undefined);
        get description(): string;
        get displayName(): string;
        private _externalIds;
        get externalIds(): ExternalIdsPropertyList;
        get groupId(): string;
        get identityStoreId(): string;
    }
    class GroupsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GroupsPropertyOutputReference;
    }
}
