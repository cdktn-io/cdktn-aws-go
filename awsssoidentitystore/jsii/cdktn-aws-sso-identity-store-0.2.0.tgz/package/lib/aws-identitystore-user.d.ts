import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfUserConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/identitystore_user#display_name TfUser#display_name}
    */
    readonly displayName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/identitystore_user#id TfUser#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/identitystore_user#identity_store_id TfUser#identity_store_id}
    */
    readonly identityStoreId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/identitystore_user#locale TfUser#locale}
    */
    readonly locale?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/identitystore_user#nickname TfUser#nickname}
    */
    readonly nickname?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/identitystore_user#preferred_language TfUser#preferred_language}
    */
    readonly preferredLanguage?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/identitystore_user#profile_url TfUser#profile_url}
    */
    readonly profileUrl?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/identitystore_user#region TfUser#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/identitystore_user#timezone TfUser#timezone}
    */
    readonly timezone?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/identitystore_user#title TfUser#title}
    */
    readonly title?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/identitystore_user#user_name TfUser#user_name}
    */
    readonly userName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/identitystore_user#user_type TfUser#user_type}
    */
    readonly userType?: string;
    /**
    * addresses block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/identitystore_user#addresses TfUser#addresses}
    */
    readonly addresses?: TfUser.AddressesProperty;
    /**
    * emails block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/identitystore_user#emails TfUser#emails}
    */
    readonly emails?: TfUser.EmailsProperty;
    /**
    * name block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/identitystore_user#name TfUser#name}
    */
    readonly name: TfUser.NameProperty;
    /**
    * phone_numbers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/identitystore_user#phone_numbers TfUser#phone_numbers}
    */
    readonly phoneNumbers?: TfUser.PhoneNumbersProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/identitystore_user aws_identitystore_user}
*/
export declare class TfUser extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_identitystore_user";
    /**
    * Generates CDKTN code for importing a TfUser resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfUser to import
    * @param importFromId The id of the existing TfUser that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/identitystore_user#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfUser to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/identitystore_user aws_identitystore_user} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfUserConfig
    */
    constructor(scope: Construct, id: string, config: TfUserConfig);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _externalIds;
    get externalIds(): TfUser.ExternalIdsPropertyList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _identityStoreId?;
    get identityStoreId(): string;
    set identityStoreId(value: string);
    get identityStoreIdInput(): string | undefined;
    private _locale?;
    get locale(): string;
    set locale(value: string);
    resetLocale(): void;
    get localeInput(): string | undefined;
    private _nickname?;
    get nickname(): string;
    set nickname(value: string);
    resetNickname(): void;
    get nicknameInput(): string | undefined;
    private _preferredLanguage?;
    get preferredLanguage(): string;
    set preferredLanguage(value: string);
    resetPreferredLanguage(): void;
    get preferredLanguageInput(): string | undefined;
    private _profileUrl?;
    get profileUrl(): string;
    set profileUrl(value: string);
    resetProfileUrl(): void;
    get profileUrlInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _timezone?;
    get timezone(): string;
    set timezone(value: string);
    resetTimezone(): void;
    get timezoneInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
    get userId(): string;
    private _userName?;
    get userName(): string;
    set userName(value: string);
    get userNameInput(): string | undefined;
    get userStatus(): string;
    private _userType?;
    get userType(): string;
    set userType(value: string);
    resetUserType(): void;
    get userTypeInput(): string | undefined;
    private _addresses;
    get addresses(): TfUser.AddressesPropertyOutputReference;
    putAddresses(value: TfUser.AddressesProperty): void;
    resetAddresses(): void;
    get addressesInput(): TfUser.AddressesProperty | undefined;
    private _emails;
    get emails(): TfUser.EmailsPropertyOutputReference;
    putEmails(value: TfUser.EmailsProperty): void;
    resetEmails(): void;
    get emailsInput(): TfUser.EmailsProperty | undefined;
    private _name;
    get name(): TfUser.NamePropertyOutputReference;
    putName(value: TfUser.NameProperty): void;
    get nameInput(): TfUser.NameProperty | undefined;
    private _phoneNumbers;
    get phoneNumbers(): TfUser.PhoneNumbersPropertyOutputReference;
    putPhoneNumbers(value: TfUser.PhoneNumbersProperty): void;
    resetPhoneNumbers(): void;
    get phoneNumbersInput(): TfUser.PhoneNumbersProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfUserExternalIdsPropertyToTerraform(struct?: TfUser.ExternalIdsProperty): any;
export declare function tfUserExternalIdsPropertyToHclTerraform(struct?: TfUser.ExternalIdsProperty): any;
export declare function tfUserAddressesPropertyToTerraform(struct?: TfUser.AddressesPropertyOutputReference | TfUser.AddressesProperty): any;
export declare function tfUserAddressesPropertyToHclTerraform(struct?: TfUser.AddressesPropertyOutputReference | TfUser.AddressesProperty): any;
export declare function tfUserEmailsPropertyToTerraform(struct?: TfUser.EmailsPropertyOutputReference | TfUser.EmailsProperty): any;
export declare function tfUserEmailsPropertyToHclTerraform(struct?: TfUser.EmailsPropertyOutputReference | TfUser.EmailsProperty): any;
export declare function tfUserNamePropertyToTerraform(struct?: TfUser.NamePropertyOutputReference | TfUser.NameProperty): any;
export declare function tfUserNamePropertyToHclTerraform(struct?: TfUser.NamePropertyOutputReference | TfUser.NameProperty): any;
export declare function tfUserPhoneNumbersPropertyToTerraform(struct?: TfUser.PhoneNumbersPropertyOutputReference | TfUser.PhoneNumbersProperty): any;
export declare function tfUserPhoneNumbersPropertyToHclTerraform(struct?: TfUser.PhoneNumbersPropertyOutputReference | TfUser.PhoneNumbersProperty): any;
export declare namespace TfUser {
    interface ExternalIdsProperty {
    }
    class ExternalIdsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExternalIdsProperty | undefined;
        set internalValue(value: ExternalIdsProperty | undefined);
        get id(): string;
        get issuer(): string;
    }
    class ExternalIdsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExternalIdsPropertyOutputReference;
    }
    interface AddressesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/identitystore_user#country TfUser#country}
        */
        readonly country?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/identitystore_user#formatted TfUser#formatted}
        */
        readonly formatted?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/identitystore_user#locality TfUser#locality}
        */
        readonly locality?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/identitystore_user#postal_code TfUser#postal_code}
        */
        readonly postalCode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/identitystore_user#primary TfUser#primary}
        */
        readonly primary?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/identitystore_user#region TfUser#region}
        */
        readonly region?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/identitystore_user#street_address TfUser#street_address}
        */
        readonly streetAddress?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/identitystore_user#type TfUser#type}
        */
        readonly type?: string;
    }
    class AddressesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AddressesProperty | undefined;
        set internalValue(value: AddressesProperty | undefined);
        private _country?;
        get country(): string;
        set country(value: string);
        resetCountry(): void;
        get countryInput(): string | undefined;
        private _formatted?;
        get formatted(): string;
        set formatted(value: string);
        resetFormatted(): void;
        get formattedInput(): string | undefined;
        private _locality?;
        get locality(): string;
        set locality(value: string);
        resetLocality(): void;
        get localityInput(): string | undefined;
        private _postalCode?;
        get postalCode(): string;
        set postalCode(value: string);
        resetPostalCode(): void;
        get postalCodeInput(): string | undefined;
        private _primary?;
        get primary(): boolean | cdktn.IResolvable;
        set primary(value: boolean | cdktn.IResolvable);
        resetPrimary(): void;
        get primaryInput(): boolean | cdktn.IResolvable | undefined;
        private _region?;
        get region(): string;
        set region(value: string);
        resetRegion(): void;
        get regionInput(): string | undefined;
        private _streetAddress?;
        get streetAddress(): string;
        set streetAddress(value: string);
        resetStreetAddress(): void;
        get streetAddressInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
    }
    interface EmailsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/identitystore_user#primary TfUser#primary}
        */
        readonly primary?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/identitystore_user#type TfUser#type}
        */
        readonly type?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/identitystore_user#value TfUser#value}
        */
        readonly value?: string;
    }
    class EmailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EmailsProperty | undefined;
        set internalValue(value: EmailsProperty | undefined);
        private _primary?;
        get primary(): boolean | cdktn.IResolvable;
        set primary(value: boolean | cdktn.IResolvable);
        resetPrimary(): void;
        get primaryInput(): boolean | cdktn.IResolvable | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        resetValue(): void;
        get valueInput(): string | undefined;
    }
    interface NameProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/identitystore_user#family_name TfUser#family_name}
        */
        readonly familyName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/identitystore_user#formatted TfUser#formatted}
        */
        readonly formatted?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/identitystore_user#given_name TfUser#given_name}
        */
        readonly givenName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/identitystore_user#honorific_prefix TfUser#honorific_prefix}
        */
        readonly honorificPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/identitystore_user#honorific_suffix TfUser#honorific_suffix}
        */
        readonly honorificSuffix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/identitystore_user#middle_name TfUser#middle_name}
        */
        readonly middleName?: string;
    }
    class NamePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NameProperty | undefined;
        set internalValue(value: NameProperty | undefined);
        private _familyName?;
        get familyName(): string;
        set familyName(value: string);
        get familyNameInput(): string | undefined;
        private _formatted?;
        get formatted(): string;
        set formatted(value: string);
        resetFormatted(): void;
        get formattedInput(): string | undefined;
        private _givenName?;
        get givenName(): string;
        set givenName(value: string);
        get givenNameInput(): string | undefined;
        private _honorificPrefix?;
        get honorificPrefix(): string;
        set honorificPrefix(value: string);
        resetHonorificPrefix(): void;
        get honorificPrefixInput(): string | undefined;
        private _honorificSuffix?;
        get honorificSuffix(): string;
        set honorificSuffix(value: string);
        resetHonorificSuffix(): void;
        get honorificSuffixInput(): string | undefined;
        private _middleName?;
        get middleName(): string;
        set middleName(value: string);
        resetMiddleName(): void;
        get middleNameInput(): string | undefined;
    }
    interface PhoneNumbersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/identitystore_user#primary TfUser#primary}
        */
        readonly primary?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/identitystore_user#type TfUser#type}
        */
        readonly type?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/identitystore_user#value TfUser#value}
        */
        readonly value?: string;
    }
    class PhoneNumbersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PhoneNumbersProperty | undefined;
        set internalValue(value: PhoneNumbersProperty | undefined);
        private _primary?;
        get primary(): boolean | cdktn.IResolvable;
        set primary(value: boolean | cdktn.IResolvable);
        resetPrimary(): void;
        get primaryInput(): boolean | cdktn.IResolvable | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        resetValue(): void;
        get valueInput(): string | undefined;
    }
}
