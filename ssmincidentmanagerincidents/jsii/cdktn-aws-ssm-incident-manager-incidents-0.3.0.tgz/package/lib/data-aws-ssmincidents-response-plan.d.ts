import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsResponsePlanConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssmincidents_response_plan#arn DataAwsResponsePlan#arn}
    */
    readonly arn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssmincidents_response_plan#id DataAwsResponsePlan#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssmincidents_response_plan#region DataAwsResponsePlan#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssmincidents_response_plan#tags DataAwsResponsePlan#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssmincidents_response_plan aws_ssmincidents_response_plan}
*/
export declare class DataAwsResponsePlan extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_ssmincidents_response_plan";
    /**
    * Generates CDKTN code for importing a DataAwsResponsePlan resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsResponsePlan to import
    * @param importFromId The id of the existing DataAwsResponsePlan that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssmincidents_response_plan#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsResponsePlan to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssmincidents_response_plan aws_ssmincidents_response_plan} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsResponsePlanConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsResponsePlanConfig);
    private _action;
    get action(): DataAwsResponsePlan.ActionPropertyList;
    private _arn?;
    get arn(): string;
    set arn(value: string);
    get arnInput(): string | undefined;
    get chatChannel(): string[];
    get displayName(): string;
    get engagements(): string[];
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _incidentTemplate;
    get incidentTemplate(): DataAwsResponsePlan.IncidentTemplatePropertyList;
    private _integration;
    get integration(): DataAwsResponsePlan.IntegrationPropertyList;
    get name(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsResponsePlanParameterPropertyToTerraform(struct?: DataAwsResponsePlan.ParameterProperty): any;
export declare function dataAwsResponsePlanParameterPropertyToHclTerraform(struct?: DataAwsResponsePlan.ParameterProperty): any;
export declare function dataAwsResponsePlanSsmAutomationPropertyToTerraform(struct?: DataAwsResponsePlan.SsmAutomationProperty): any;
export declare function dataAwsResponsePlanSsmAutomationPropertyToHclTerraform(struct?: DataAwsResponsePlan.SsmAutomationProperty): any;
export declare function dataAwsResponsePlanActionPropertyToTerraform(struct?: DataAwsResponsePlan.ActionProperty): any;
export declare function dataAwsResponsePlanActionPropertyToHclTerraform(struct?: DataAwsResponsePlan.ActionProperty): any;
export declare function dataAwsResponsePlanNotificationTargetPropertyToTerraform(struct?: DataAwsResponsePlan.NotificationTargetProperty): any;
export declare function dataAwsResponsePlanNotificationTargetPropertyToHclTerraform(struct?: DataAwsResponsePlan.NotificationTargetProperty): any;
export declare function dataAwsResponsePlanIncidentTemplatePropertyToTerraform(struct?: DataAwsResponsePlan.IncidentTemplateProperty): any;
export declare function dataAwsResponsePlanIncidentTemplatePropertyToHclTerraform(struct?: DataAwsResponsePlan.IncidentTemplateProperty): any;
export declare function dataAwsResponsePlanPagerdutyPropertyToTerraform(struct?: DataAwsResponsePlan.PagerdutyProperty): any;
export declare function dataAwsResponsePlanPagerdutyPropertyToHclTerraform(struct?: DataAwsResponsePlan.PagerdutyProperty): any;
export declare function dataAwsResponsePlanIntegrationPropertyToTerraform(struct?: DataAwsResponsePlan.IntegrationProperty): any;
export declare function dataAwsResponsePlanIntegrationPropertyToHclTerraform(struct?: DataAwsResponsePlan.IntegrationProperty): any;
export declare namespace DataAwsResponsePlan {
    interface ParameterProperty {
    }
    class ParameterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ParameterProperty | undefined;
        set internalValue(value: ParameterProperty | undefined);
        get name(): string;
        get values(): string[];
    }
    class ParameterPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ParameterPropertyOutputReference;
    }
    interface SsmAutomationProperty {
    }
    class SsmAutomationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SsmAutomationProperty | undefined;
        set internalValue(value: SsmAutomationProperty | undefined);
        get documentName(): string;
        get documentVersion(): string;
        private _dynamicParameters;
        get dynamicParameters(): cdktn.StringMap;
        private _parameter;
        get parameter(): ParameterPropertyList;
        get roleArn(): string;
        get targetAccount(): string;
    }
    class SsmAutomationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SsmAutomationPropertyOutputReference;
    }
    interface ActionProperty {
    }
    class ActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ActionProperty | undefined;
        set internalValue(value: ActionProperty | undefined);
        private _ssmAutomation;
        get ssmAutomation(): SsmAutomationPropertyList;
    }
    class ActionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ActionPropertyOutputReference;
    }
    interface NotificationTargetProperty {
    }
    class NotificationTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NotificationTargetProperty | undefined;
        set internalValue(value: NotificationTargetProperty | undefined);
        get snsTopicArn(): string;
    }
    class NotificationTargetPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NotificationTargetPropertyOutputReference;
    }
    interface IncidentTemplateProperty {
    }
    class IncidentTemplatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IncidentTemplateProperty | undefined;
        set internalValue(value: IncidentTemplateProperty | undefined);
        get dedupeString(): string;
        get impact(): number;
        private _incidentTags;
        get incidentTags(): cdktn.StringMap;
        private _notificationTarget;
        get notificationTarget(): NotificationTargetPropertyList;
        get summary(): string;
        get title(): string;
    }
    class IncidentTemplatePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IncidentTemplatePropertyOutputReference;
    }
    interface PagerdutyProperty {
    }
    class PagerdutyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PagerdutyProperty | undefined;
        set internalValue(value: PagerdutyProperty | undefined);
        get name(): string;
        get secretId(): string;
        get serviceId(): string;
    }
    class PagerdutyPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PagerdutyPropertyOutputReference;
    }
    interface IntegrationProperty {
    }
    class IntegrationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IntegrationProperty | undefined;
        set internalValue(value: IntegrationProperty | undefined);
        private _pagerduty;
        get pagerduty(): PagerdutyPropertyList;
    }
    class IntegrationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IntegrationPropertyOutputReference;
    }
}
