import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsProfilingGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/codeguruprofiler_profiling_group#name DataAwsProfilingGroup#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/codeguruprofiler_profiling_group#region DataAwsProfilingGroup#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/codeguruprofiler_profiling_group aws_codeguruprofiler_profiling_group}
*/
export declare class DataAwsProfilingGroup extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_codeguruprofiler_profiling_group";
    /**
    * Generates CDKTN code for importing a DataAwsProfilingGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsProfilingGroup to import
    * @param importFromId The id of the existing DataAwsProfilingGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/codeguruprofiler_profiling_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsProfilingGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/codeguruprofiler_profiling_group aws_codeguruprofiler_profiling_group} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsProfilingGroupConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsProfilingGroupConfig);
    private _agentOrchestrationConfig;
    get agentOrchestrationConfig(): DataAwsProfilingGroup.AgentOrchestrationConfigPropertyList;
    get arn(): string;
    get computePlatform(): string;
    get createdAt(): string;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _profilingStatus;
    get profilingStatus(): DataAwsProfilingGroup.ProfilingStatusPropertyList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags;
    get tags(): cdktn.StringMap;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsProfilingGroupAgentOrchestrationConfigPropertyToTerraform(struct?: DataAwsProfilingGroup.AgentOrchestrationConfigProperty): any;
export declare function dataAwsProfilingGroupAgentOrchestrationConfigPropertyToHclTerraform(struct?: DataAwsProfilingGroup.AgentOrchestrationConfigProperty): any;
export declare function dataAwsProfilingGroupLatestAggregatedProfilePropertyToTerraform(struct?: DataAwsProfilingGroup.LatestAggregatedProfileProperty): any;
export declare function dataAwsProfilingGroupLatestAggregatedProfilePropertyToHclTerraform(struct?: DataAwsProfilingGroup.LatestAggregatedProfileProperty): any;
export declare function dataAwsProfilingGroupProfilingStatusPropertyToTerraform(struct?: DataAwsProfilingGroup.ProfilingStatusProperty): any;
export declare function dataAwsProfilingGroupProfilingStatusPropertyToHclTerraform(struct?: DataAwsProfilingGroup.ProfilingStatusProperty): any;
export declare namespace DataAwsProfilingGroup {
    interface AgentOrchestrationConfigProperty {
    }
    class AgentOrchestrationConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AgentOrchestrationConfigProperty | undefined;
        set internalValue(value: AgentOrchestrationConfigProperty | undefined);
        get profilingEnabled(): cdktn.IResolvable;
    }
    class AgentOrchestrationConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AgentOrchestrationConfigPropertyOutputReference;
    }
    interface LatestAggregatedProfileProperty {
    }
    class LatestAggregatedProfilePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LatestAggregatedProfileProperty | undefined;
        set internalValue(value: LatestAggregatedProfileProperty | undefined);
        get period(): string;
        get start(): string;
    }
    class LatestAggregatedProfilePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LatestAggregatedProfilePropertyOutputReference;
    }
    interface ProfilingStatusProperty {
    }
    class ProfilingStatusPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ProfilingStatusProperty | undefined;
        set internalValue(value: ProfilingStatusProperty | undefined);
        get latestAgentOrchestratedAt(): string;
        get latestAgentProfileReportedAt(): string;
        private _latestAggregatedProfile;
        get latestAggregatedProfile(): LatestAggregatedProfilePropertyList;
    }
    class ProfilingStatusPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ProfilingStatusPropertyOutputReference;
    }
}
