import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_group#group_id DataAwsGroup#group_id}
    */
    readonly groupId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_group#id DataAwsGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_group#identity_store_id DataAwsGroup#identity_store_id}
    */
    readonly identityStoreId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_group#region DataAwsGroup#region}
    */
    readonly region?: string;
    /**
    * alternate_identifier block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_group#alternate_identifier DataAwsGroup#alternate_identifier}
    */
    readonly alternateIdentifier?: DataAwsGroup.AlternateIdentifierProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_group aws_identitystore_group}
*/
export declare class DataAwsGroup extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_identitystore_group";
    /**
    * Generates CDKTN code for importing a DataAwsGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsGroup to import
    * @param importFromId The id of the existing DataAwsGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_group aws_identitystore_group} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsGroupConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsGroupConfig);
    get description(): string;
    get displayName(): string;
    private _externalIds;
    get externalIds(): DataAwsGroup.ExternalIdsPropertyList;
    private _groupId?;
    get groupId(): string;
    set groupId(value: string);
    resetGroupId(): void;
    get groupIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _identityStoreId?;
    get identityStoreId(): string;
    set identityStoreId(value: string);
    get identityStoreIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _alternateIdentifier;
    get alternateIdentifier(): DataAwsGroup.AlternateIdentifierPropertyOutputReference;
    putAlternateIdentifier(value: DataAwsGroup.AlternateIdentifierProperty): void;
    resetAlternateIdentifier(): void;
    get alternateIdentifierInput(): DataAwsGroup.AlternateIdentifierProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsGroupExternalIdsPropertyToTerraform(struct?: DataAwsGroup.ExternalIdsProperty): any;
export declare function dataAwsGroupExternalIdsPropertyToHclTerraform(struct?: DataAwsGroup.ExternalIdsProperty): any;
export declare function dataAwsGroupExternalIdPropertyToTerraform(struct?: DataAwsGroup.ExternalIdPropertyOutputReference | DataAwsGroup.ExternalIdProperty): any;
export declare function dataAwsGroupExternalIdPropertyToHclTerraform(struct?: DataAwsGroup.ExternalIdPropertyOutputReference | DataAwsGroup.ExternalIdProperty): any;
export declare function dataAwsGroupUniqueAttributePropertyToTerraform(struct?: DataAwsGroup.UniqueAttributePropertyOutputReference | DataAwsGroup.UniqueAttributeProperty): any;
export declare function dataAwsGroupUniqueAttributePropertyToHclTerraform(struct?: DataAwsGroup.UniqueAttributePropertyOutputReference | DataAwsGroup.UniqueAttributeProperty): any;
export declare function dataAwsGroupAlternateIdentifierPropertyToTerraform(struct?: DataAwsGroup.AlternateIdentifierPropertyOutputReference | DataAwsGroup.AlternateIdentifierProperty): any;
export declare function dataAwsGroupAlternateIdentifierPropertyToHclTerraform(struct?: DataAwsGroup.AlternateIdentifierPropertyOutputReference | DataAwsGroup.AlternateIdentifierProperty): any;
export declare namespace DataAwsGroup {
    interface ExternalIdsProperty {
    }
    class ExternalIdsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExternalIdsProperty | undefined;
        set internalValue(value: ExternalIdsProperty | undefined);
        get id(): string;
        get issuer(): string;
    }
    class ExternalIdsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExternalIdsPropertyOutputReference;
    }
    interface ExternalIdProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_group#id DataAwsGroup#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_group#issuer DataAwsGroup#issuer}
        */
        readonly issuer: string;
    }
    class ExternalIdPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ExternalIdProperty | undefined;
        set internalValue(value: ExternalIdProperty | undefined);
        private _id?;
        get id(): string;
        set id(value: string);
        get idInput(): string | undefined;
        private _issuer?;
        get issuer(): string;
        set issuer(value: string);
        get issuerInput(): string | undefined;
    }
    interface UniqueAttributeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_group#attribute_path DataAwsGroup#attribute_path}
        */
        readonly attributePath: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_group#attribute_value DataAwsGroup#attribute_value}
        */
        readonly attributeValue: string;
    }
    class UniqueAttributePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UniqueAttributeProperty | undefined;
        set internalValue(value: UniqueAttributeProperty | undefined);
        private _attributePath?;
        get attributePath(): string;
        set attributePath(value: string);
        get attributePathInput(): string | undefined;
        private _attributeValue?;
        get attributeValue(): string;
        set attributeValue(value: string);
        get attributeValueInput(): string | undefined;
    }
    interface AlternateIdentifierProperty {
        /**
        * external_id block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_group#external_id DataAwsGroup#external_id}
        */
        readonly externalId?: ExternalIdProperty;
        /**
        * unique_attribute block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_group#unique_attribute DataAwsGroup#unique_attribute}
        */
        readonly uniqueAttribute?: UniqueAttributeProperty;
    }
    class AlternateIdentifierPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AlternateIdentifierProperty | undefined;
        set internalValue(value: AlternateIdentifierProperty | undefined);
        private _externalId;
        get externalId(): ExternalIdPropertyOutputReference;
        putExternalId(value: ExternalIdProperty): void;
        resetExternalId(): void;
        get externalIdInput(): ExternalIdProperty | undefined;
        private _uniqueAttribute;
        get uniqueAttribute(): UniqueAttributePropertyOutputReference;
        putUniqueAttribute(value: UniqueAttributeProperty): void;
        resetUniqueAttribute(): void;
        get uniqueAttributeInput(): UniqueAttributeProperty | undefined;
    }
}
