import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsUsersConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_users#identity_store_id DataAwsUsers#identity_store_id}
    */
    readonly identityStoreId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_users#region DataAwsUsers#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_users aws_identitystore_users}
*/
export declare class DataAwsUsers extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_identitystore_users";
    /**
    * Generates CDKTN code for importing a DataAwsUsers resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsUsers to import
    * @param importFromId The id of the existing DataAwsUsers that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_users#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsUsers to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/identitystore_users aws_identitystore_users} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsUsersConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsUsersConfig);
    private _identityStoreId?;
    get identityStoreId(): string;
    set identityStoreId(value: string);
    get identityStoreIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _users;
    get users(): DataAwsUsers.UsersPropertyList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsUsersAddressesPropertyToTerraform(struct?: DataAwsUsers.AddressesProperty): any;
export declare function dataAwsUsersAddressesPropertyToHclTerraform(struct?: DataAwsUsers.AddressesProperty): any;
export declare function dataAwsUsersEmailsPropertyToTerraform(struct?: DataAwsUsers.EmailsProperty): any;
export declare function dataAwsUsersEmailsPropertyToHclTerraform(struct?: DataAwsUsers.EmailsProperty): any;
export declare function dataAwsUsersExternalIdsPropertyToTerraform(struct?: DataAwsUsers.ExternalIdsProperty): any;
export declare function dataAwsUsersExternalIdsPropertyToHclTerraform(struct?: DataAwsUsers.ExternalIdsProperty): any;
export declare function dataAwsUsersNamePropertyToTerraform(struct?: DataAwsUsers.NameProperty): any;
export declare function dataAwsUsersNamePropertyToHclTerraform(struct?: DataAwsUsers.NameProperty): any;
export declare function dataAwsUsersPhoneNumbersPropertyToTerraform(struct?: DataAwsUsers.PhoneNumbersProperty): any;
export declare function dataAwsUsersPhoneNumbersPropertyToHclTerraform(struct?: DataAwsUsers.PhoneNumbersProperty): any;
export declare function dataAwsUsersUsersPropertyToTerraform(struct?: DataAwsUsers.UsersProperty): any;
export declare function dataAwsUsersUsersPropertyToHclTerraform(struct?: DataAwsUsers.UsersProperty): any;
export declare namespace DataAwsUsers {
    interface AddressesProperty {
    }
    class AddressesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AddressesProperty | undefined;
        set internalValue(value: AddressesProperty | undefined);
        get country(): string;
        get formatted(): string;
        get locality(): string;
        get postalCode(): string;
        get primary(): cdktn.IResolvable;
        get region(): string;
        get streetAddress(): string;
        get type(): string;
    }
    class AddressesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AddressesPropertyOutputReference;
    }
    interface EmailsProperty {
    }
    class EmailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EmailsProperty | undefined;
        set internalValue(value: EmailsProperty | undefined);
        get primary(): cdktn.IResolvable;
        get type(): string;
        get value(): string;
    }
    class EmailsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EmailsPropertyOutputReference;
    }
    interface ExternalIdsProperty {
    }
    class ExternalIdsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExternalIdsProperty | undefined;
        set internalValue(value: ExternalIdsProperty | undefined);
        get id(): string;
        get issuer(): string;
    }
    class ExternalIdsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExternalIdsPropertyOutputReference;
    }
    interface NameProperty {
    }
    class NamePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NameProperty | undefined;
        set internalValue(value: NameProperty | undefined);
        get familyName(): string;
        get formatted(): string;
        get givenName(): string;
        get honorificPrefix(): string;
        get honorificSuffix(): string;
        get middleName(): string;
    }
    class NamePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NamePropertyOutputReference;
    }
    interface PhoneNumbersProperty {
    }
    class PhoneNumbersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PhoneNumbersProperty | undefined;
        set internalValue(value: PhoneNumbersProperty | undefined);
        get primary(): cdktn.IResolvable;
        get type(): string;
        get value(): string;
    }
    class PhoneNumbersPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PhoneNumbersPropertyOutputReference;
    }
    interface UsersProperty {
    }
    class UsersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): UsersProperty | undefined;
        set internalValue(value: UsersProperty | undefined);
        private _addresses;
        get addresses(): AddressesPropertyList;
        get displayName(): string;
        private _emails;
        get emails(): EmailsPropertyList;
        private _externalIds;
        get externalIds(): ExternalIdsPropertyList;
        get identityStoreId(): string;
        get locale(): string;
        private _name;
        get name(): NamePropertyList;
        get nickname(): string;
        private _phoneNumbers;
        get phoneNumbers(): PhoneNumbersPropertyList;
        get preferredLanguage(): string;
        get profileUrl(): string;
        get timezone(): string;
        get title(): string;
        get userId(): string;
        get userName(): string;
        get userStatus(): string;
        get userType(): string;
    }
    class UsersPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): UsersPropertyOutputReference;
    }
}
