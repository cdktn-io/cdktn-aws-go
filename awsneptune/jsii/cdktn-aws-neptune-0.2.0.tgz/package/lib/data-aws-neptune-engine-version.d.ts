import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfEngineVersionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/neptune_engine_version#default_only DataTfEngineVersion#default_only}
    */
    readonly defaultOnly?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/neptune_engine_version#engine DataTfEngineVersion#engine}
    */
    readonly engine?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/neptune_engine_version#has_major_target DataTfEngineVersion#has_major_target}
    */
    readonly hasMajorTarget?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/neptune_engine_version#has_minor_target DataTfEngineVersion#has_minor_target}
    */
    readonly hasMinorTarget?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/neptune_engine_version#id DataTfEngineVersion#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/neptune_engine_version#latest DataTfEngineVersion#latest}
    */
    readonly latest?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/neptune_engine_version#parameter_group_family DataTfEngineVersion#parameter_group_family}
    */
    readonly parameterGroupFamily?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/neptune_engine_version#preferred_major_targets DataTfEngineVersion#preferred_major_targets}
    */
    readonly preferredMajorTargets?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/neptune_engine_version#preferred_upgrade_targets DataTfEngineVersion#preferred_upgrade_targets}
    */
    readonly preferredUpgradeTargets?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/neptune_engine_version#preferred_versions DataTfEngineVersion#preferred_versions}
    */
    readonly preferredVersions?: string[];
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/neptune_engine_version#region DataTfEngineVersion#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/neptune_engine_version#version DataTfEngineVersion#version}
    */
    readonly version?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/neptune_engine_version aws_neptune_engine_version}
*/
export declare class DataTfEngineVersion extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_neptune_engine_version";
    /**
    * Generates CDKTN code for importing a DataTfEngineVersion resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfEngineVersion to import
    * @param importFromId The id of the existing DataTfEngineVersion that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/neptune_engine_version#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfEngineVersion to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/neptune_engine_version aws_neptune_engine_version} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfEngineVersionConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataTfEngineVersionConfig);
    get defaultCharacterSet(): string;
    private _defaultOnly?;
    get defaultOnly(): boolean | cdktn.IResolvable;
    set defaultOnly(value: boolean | cdktn.IResolvable);
    resetDefaultOnly(): void;
    get defaultOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _engine?;
    get engine(): string;
    set engine(value: string);
    resetEngine(): void;
    get engineInput(): string | undefined;
    get engineDescription(): string;
    get exportableLogTypes(): string[];
    private _hasMajorTarget?;
    get hasMajorTarget(): boolean | cdktn.IResolvable;
    set hasMajorTarget(value: boolean | cdktn.IResolvable);
    resetHasMajorTarget(): void;
    get hasMajorTargetInput(): boolean | cdktn.IResolvable | undefined;
    private _hasMinorTarget?;
    get hasMinorTarget(): boolean | cdktn.IResolvable;
    set hasMinorTarget(value: boolean | cdktn.IResolvable);
    resetHasMinorTarget(): void;
    get hasMinorTargetInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _latest?;
    get latest(): boolean | cdktn.IResolvable;
    set latest(value: boolean | cdktn.IResolvable);
    resetLatest(): void;
    get latestInput(): boolean | cdktn.IResolvable | undefined;
    private _parameterGroupFamily?;
    get parameterGroupFamily(): string;
    set parameterGroupFamily(value: string);
    resetParameterGroupFamily(): void;
    get parameterGroupFamilyInput(): string | undefined;
    private _preferredMajorTargets?;
    get preferredMajorTargets(): string[];
    set preferredMajorTargets(value: string[]);
    resetPreferredMajorTargets(): void;
    get preferredMajorTargetsInput(): string[] | undefined;
    private _preferredUpgradeTargets?;
    get preferredUpgradeTargets(): string[];
    set preferredUpgradeTargets(value: string[]);
    resetPreferredUpgradeTargets(): void;
    get preferredUpgradeTargetsInput(): string[] | undefined;
    private _preferredVersions?;
    get preferredVersions(): string[];
    set preferredVersions(value: string[]);
    resetPreferredVersions(): void;
    get preferredVersionsInput(): string[] | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get supportedCharacterSets(): string[];
    get supportedTimezones(): string[];
    get supportsGlobalDatabases(): cdktn.IResolvable;
    get supportsLogExportsToCloudwatch(): cdktn.IResolvable;
    get supportsReadReplica(): cdktn.IResolvable;
    get validMajorTargets(): string[];
    get validMinorTargets(): string[];
    get validUpgradeTargets(): string[];
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
    get versionActual(): string;
    get versionDescription(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
