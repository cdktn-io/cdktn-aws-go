import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSchedulerScheduleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#action_after_completion AwsSchedulerSchedule#action_after_completion}
    */
    readonly actionAfterCompletion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#description AwsSchedulerSchedule#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#end_date AwsSchedulerSchedule#end_date}
    */
    readonly endDate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#group_name AwsSchedulerSchedule#group_name}
    */
    readonly groupName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#id AwsSchedulerSchedule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#kms_key_arn AwsSchedulerSchedule#kms_key_arn}
    */
    readonly kmsKeyArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#name AwsSchedulerSchedule#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#name_prefix AwsSchedulerSchedule#name_prefix}
    */
    readonly namePrefix?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#region AwsSchedulerSchedule#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#schedule_expression AwsSchedulerSchedule#schedule_expression}
    */
    readonly scheduleExpression: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#schedule_expression_timezone AwsSchedulerSchedule#schedule_expression_timezone}
    */
    readonly scheduleExpressionTimezone?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#start_date AwsSchedulerSchedule#start_date}
    */
    readonly startDate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#state AwsSchedulerSchedule#state}
    */
    readonly state?: string;
    /**
    * flexible_time_window block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#flexible_time_window AwsSchedulerSchedule#flexible_time_window}
    */
    readonly flexibleTimeWindow: AwsSchedulerSchedule.FlexibleTimeWindowProperty;
    /**
    * target block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#target AwsSchedulerSchedule#target}
    */
    readonly target: AwsSchedulerSchedule.TargetProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule aws_scheduler_schedule}
*/
export declare class AwsSchedulerSchedule extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_scheduler_schedule";
    /**
    * Generates CDKTN code for importing a AwsSchedulerSchedule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSchedulerSchedule to import
    * @param importFromId The id of the existing AwsSchedulerSchedule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSchedulerSchedule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule aws_scheduler_schedule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSchedulerScheduleConfig
    */
    constructor(scope: Construct, id: string, config: AwsSchedulerScheduleConfig);
    private _actionAfterCompletion?;
    get actionAfterCompletion(): string;
    set actionAfterCompletion(value: string);
    resetActionAfterCompletion(): void;
    get actionAfterCompletionInput(): string | undefined;
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _endDate?;
    get endDate(): string;
    set endDate(value: string);
    resetEndDate(): void;
    get endDateInput(): string | undefined;
    private _groupName?;
    get groupName(): string;
    set groupName(value: string);
    resetGroupName(): void;
    get groupNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _kmsKeyArn?;
    get kmsKeyArn(): string;
    set kmsKeyArn(value: string);
    resetKmsKeyArn(): void;
    get kmsKeyArnInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namePrefix?;
    get namePrefix(): string;
    set namePrefix(value: string);
    resetNamePrefix(): void;
    get namePrefixInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _scheduleExpression?;
    get scheduleExpression(): string;
    set scheduleExpression(value: string);
    get scheduleExpressionInput(): string | undefined;
    private _scheduleExpressionTimezone?;
    get scheduleExpressionTimezone(): string;
    set scheduleExpressionTimezone(value: string);
    resetScheduleExpressionTimezone(): void;
    get scheduleExpressionTimezoneInput(): string | undefined;
    private _startDate?;
    get startDate(): string;
    set startDate(value: string);
    resetStartDate(): void;
    get startDateInput(): string | undefined;
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
    private _flexibleTimeWindow;
    get flexibleTimeWindow(): AwsSchedulerSchedule.FlexibleTimeWindowPropertyOutputReference;
    putFlexibleTimeWindow(value: AwsSchedulerSchedule.FlexibleTimeWindowProperty): void;
    get flexibleTimeWindowInput(): AwsSchedulerSchedule.FlexibleTimeWindowProperty | undefined;
    private _target;
    get target(): AwsSchedulerSchedule.TargetPropertyOutputReference;
    putTarget(value: AwsSchedulerSchedule.TargetProperty): void;
    get targetInput(): AwsSchedulerSchedule.TargetProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsSchedulerScheduleFlexibleTimeWindowPropertyToTerraform(struct?: AwsSchedulerSchedule.FlexibleTimeWindowPropertyOutputReference | AwsSchedulerSchedule.FlexibleTimeWindowProperty): any;
export declare function awsSchedulerScheduleFlexibleTimeWindowPropertyToHclTerraform(struct?: AwsSchedulerSchedule.FlexibleTimeWindowPropertyOutputReference | AwsSchedulerSchedule.FlexibleTimeWindowProperty): any;
export declare function awsSchedulerScheduleDeadLetterConfigPropertyToTerraform(struct?: AwsSchedulerSchedule.DeadLetterConfigPropertyOutputReference | AwsSchedulerSchedule.DeadLetterConfigProperty): any;
export declare function awsSchedulerScheduleDeadLetterConfigPropertyToHclTerraform(struct?: AwsSchedulerSchedule.DeadLetterConfigPropertyOutputReference | AwsSchedulerSchedule.DeadLetterConfigProperty): any;
export declare function awsSchedulerScheduleCapacityProviderStrategyPropertyToTerraform(struct?: AwsSchedulerSchedule.CapacityProviderStrategyProperty | cdktn.IResolvable): any;
export declare function awsSchedulerScheduleCapacityProviderStrategyPropertyToHclTerraform(struct?: AwsSchedulerSchedule.CapacityProviderStrategyProperty | cdktn.IResolvable): any;
export declare function awsSchedulerScheduleNetworkConfigurationPropertyToTerraform(struct?: AwsSchedulerSchedule.NetworkConfigurationPropertyOutputReference | AwsSchedulerSchedule.NetworkConfigurationProperty): any;
export declare function awsSchedulerScheduleNetworkConfigurationPropertyToHclTerraform(struct?: AwsSchedulerSchedule.NetworkConfigurationPropertyOutputReference | AwsSchedulerSchedule.NetworkConfigurationProperty): any;
export declare function awsSchedulerSchedulePlacementConstraintsPropertyToTerraform(struct?: AwsSchedulerSchedule.PlacementConstraintsProperty | cdktn.IResolvable): any;
export declare function awsSchedulerSchedulePlacementConstraintsPropertyToHclTerraform(struct?: AwsSchedulerSchedule.PlacementConstraintsProperty | cdktn.IResolvable): any;
export declare function awsSchedulerSchedulePlacementStrategyPropertyToTerraform(struct?: AwsSchedulerSchedule.PlacementStrategyProperty | cdktn.IResolvable): any;
export declare function awsSchedulerSchedulePlacementStrategyPropertyToHclTerraform(struct?: AwsSchedulerSchedule.PlacementStrategyProperty | cdktn.IResolvable): any;
export declare function awsSchedulerScheduleEcsParametersPropertyToTerraform(struct?: AwsSchedulerSchedule.EcsParametersPropertyOutputReference | AwsSchedulerSchedule.EcsParametersProperty): any;
export declare function awsSchedulerScheduleEcsParametersPropertyToHclTerraform(struct?: AwsSchedulerSchedule.EcsParametersPropertyOutputReference | AwsSchedulerSchedule.EcsParametersProperty): any;
export declare function awsSchedulerScheduleEventbridgeParametersPropertyToTerraform(struct?: AwsSchedulerSchedule.EventbridgeParametersPropertyOutputReference | AwsSchedulerSchedule.EventbridgeParametersProperty): any;
export declare function awsSchedulerScheduleEventbridgeParametersPropertyToHclTerraform(struct?: AwsSchedulerSchedule.EventbridgeParametersPropertyOutputReference | AwsSchedulerSchedule.EventbridgeParametersProperty): any;
export declare function awsSchedulerScheduleKinesisParametersPropertyToTerraform(struct?: AwsSchedulerSchedule.KinesisParametersPropertyOutputReference | AwsSchedulerSchedule.KinesisParametersProperty): any;
export declare function awsSchedulerScheduleKinesisParametersPropertyToHclTerraform(struct?: AwsSchedulerSchedule.KinesisParametersPropertyOutputReference | AwsSchedulerSchedule.KinesisParametersProperty): any;
export declare function awsSchedulerScheduleRetryPolicyPropertyToTerraform(struct?: AwsSchedulerSchedule.RetryPolicyPropertyOutputReference | AwsSchedulerSchedule.RetryPolicyProperty): any;
export declare function awsSchedulerScheduleRetryPolicyPropertyToHclTerraform(struct?: AwsSchedulerSchedule.RetryPolicyPropertyOutputReference | AwsSchedulerSchedule.RetryPolicyProperty): any;
export declare function awsSchedulerSchedulePipelineParameterPropertyToTerraform(struct?: AwsSchedulerSchedule.PipelineParameterProperty | cdktn.IResolvable): any;
export declare function awsSchedulerSchedulePipelineParameterPropertyToHclTerraform(struct?: AwsSchedulerSchedule.PipelineParameterProperty | cdktn.IResolvable): any;
export declare function awsSchedulerScheduleSagemakerPipelineParametersPropertyToTerraform(struct?: AwsSchedulerSchedule.SagemakerPipelineParametersPropertyOutputReference | AwsSchedulerSchedule.SagemakerPipelineParametersProperty): any;
export declare function awsSchedulerScheduleSagemakerPipelineParametersPropertyToHclTerraform(struct?: AwsSchedulerSchedule.SagemakerPipelineParametersPropertyOutputReference | AwsSchedulerSchedule.SagemakerPipelineParametersProperty): any;
export declare function awsSchedulerScheduleSqsParametersPropertyToTerraform(struct?: AwsSchedulerSchedule.SqsParametersPropertyOutputReference | AwsSchedulerSchedule.SqsParametersProperty): any;
export declare function awsSchedulerScheduleSqsParametersPropertyToHclTerraform(struct?: AwsSchedulerSchedule.SqsParametersPropertyOutputReference | AwsSchedulerSchedule.SqsParametersProperty): any;
export declare function awsSchedulerScheduleTargetPropertyToTerraform(struct?: AwsSchedulerSchedule.TargetPropertyOutputReference | AwsSchedulerSchedule.TargetProperty): any;
export declare function awsSchedulerScheduleTargetPropertyToHclTerraform(struct?: AwsSchedulerSchedule.TargetPropertyOutputReference | AwsSchedulerSchedule.TargetProperty): any;
export declare namespace AwsSchedulerSchedule {
    interface FlexibleTimeWindowProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#maximum_window_in_minutes AwsSchedulerSchedule#maximum_window_in_minutes}
        */
        readonly maximumWindowInMinutes?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#mode AwsSchedulerSchedule#mode}
        */
        readonly mode: string;
    }
    class FlexibleTimeWindowPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FlexibleTimeWindowProperty | undefined;
        set internalValue(value: FlexibleTimeWindowProperty | undefined);
        private _maximumWindowInMinutes?;
        get maximumWindowInMinutes(): number;
        set maximumWindowInMinutes(value: number);
        resetMaximumWindowInMinutes(): void;
        get maximumWindowInMinutesInput(): number | undefined;
        private _mode?;
        get mode(): string;
        set mode(value: string);
        get modeInput(): string | undefined;
    }
    interface DeadLetterConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#arn AwsSchedulerSchedule#arn}
        */
        readonly arn: string;
    }
    class DeadLetterConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DeadLetterConfigProperty | undefined;
        set internalValue(value: DeadLetterConfigProperty | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
    }
    interface CapacityProviderStrategyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#base AwsSchedulerSchedule#base}
        */
        readonly base?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#capacity_provider AwsSchedulerSchedule#capacity_provider}
        */
        readonly capacityProvider: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#weight AwsSchedulerSchedule#weight}
        */
        readonly weight?: number;
    }
    class CapacityProviderStrategyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CapacityProviderStrategyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CapacityProviderStrategyProperty | cdktn.IResolvable | undefined);
        private _base?;
        get base(): number;
        set base(value: number);
        resetBase(): void;
        get baseInput(): number | undefined;
        private _capacityProvider?;
        get capacityProvider(): string;
        set capacityProvider(value: string);
        get capacityProviderInput(): string | undefined;
        private _weight?;
        get weight(): number;
        set weight(value: number);
        resetWeight(): void;
        get weightInput(): number | undefined;
    }
    class CapacityProviderStrategyPropertyList extends cdktn.ComplexList {
        internalValue?: CapacityProviderStrategyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CapacityProviderStrategyPropertyOutputReference;
    }
    interface NetworkConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#assign_public_ip AwsSchedulerSchedule#assign_public_ip}
        */
        readonly assignPublicIp?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#security_groups AwsSchedulerSchedule#security_groups}
        */
        readonly securityGroups?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#subnets AwsSchedulerSchedule#subnets}
        */
        readonly subnets: string[];
    }
    class NetworkConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NetworkConfigurationProperty | undefined;
        set internalValue(value: NetworkConfigurationProperty | undefined);
        private _assignPublicIp?;
        get assignPublicIp(): boolean | cdktn.IResolvable;
        set assignPublicIp(value: boolean | cdktn.IResolvable);
        resetAssignPublicIp(): void;
        get assignPublicIpInput(): boolean | cdktn.IResolvable | undefined;
        private _securityGroups?;
        get securityGroups(): string[];
        set securityGroups(value: string[]);
        resetSecurityGroups(): void;
        get securityGroupsInput(): string[] | undefined;
        private _subnets?;
        get subnets(): string[];
        set subnets(value: string[]);
        get subnetsInput(): string[] | undefined;
    }
    interface PlacementConstraintsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#expression AwsSchedulerSchedule#expression}
        */
        readonly expression?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#type AwsSchedulerSchedule#type}
        */
        readonly type: string;
    }
    class PlacementConstraintsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PlacementConstraintsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PlacementConstraintsProperty | cdktn.IResolvable | undefined);
        private _expression?;
        get expression(): string;
        set expression(value: string);
        resetExpression(): void;
        get expressionInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class PlacementConstraintsPropertyList extends cdktn.ComplexList {
        internalValue?: PlacementConstraintsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PlacementConstraintsPropertyOutputReference;
    }
    interface PlacementStrategyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#field AwsSchedulerSchedule#field}
        */
        readonly field?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#type AwsSchedulerSchedule#type}
        */
        readonly type: string;
    }
    class PlacementStrategyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PlacementStrategyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PlacementStrategyProperty | cdktn.IResolvable | undefined);
        private _field?;
        get field(): string;
        set field(value: string);
        resetField(): void;
        get fieldInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class PlacementStrategyPropertyList extends cdktn.ComplexList {
        internalValue?: PlacementStrategyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PlacementStrategyPropertyOutputReference;
    }
    interface EcsParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#enable_ecs_managed_tags AwsSchedulerSchedule#enable_ecs_managed_tags}
        */
        readonly enableEcsManagedTags?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#enable_execute_command AwsSchedulerSchedule#enable_execute_command}
        */
        readonly enableExecuteCommand?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#group AwsSchedulerSchedule#group}
        */
        readonly group?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#launch_type AwsSchedulerSchedule#launch_type}
        */
        readonly launchType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#platform_version AwsSchedulerSchedule#platform_version}
        */
        readonly platformVersion?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#propagate_tags AwsSchedulerSchedule#propagate_tags}
        */
        readonly propagateTags?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#reference_id AwsSchedulerSchedule#reference_id}
        */
        readonly referenceId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#tags AwsSchedulerSchedule#tags}
        */
        readonly tags?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#task_count AwsSchedulerSchedule#task_count}
        */
        readonly taskCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#task_definition_arn AwsSchedulerSchedule#task_definition_arn}
        */
        readonly taskDefinitionArn: string;
        /**
        * capacity_provider_strategy block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#capacity_provider_strategy AwsSchedulerSchedule#capacity_provider_strategy}
        */
        readonly capacityProviderStrategy?: CapacityProviderStrategyProperty[] | cdktn.IResolvable;
        /**
        * network_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#network_configuration AwsSchedulerSchedule#network_configuration}
        */
        readonly networkConfiguration?: NetworkConfigurationProperty;
        /**
        * placement_constraints block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#placement_constraints AwsSchedulerSchedule#placement_constraints}
        */
        readonly placementConstraints?: PlacementConstraintsProperty[] | cdktn.IResolvable;
        /**
        * placement_strategy block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#placement_strategy AwsSchedulerSchedule#placement_strategy}
        */
        readonly placementStrategy?: PlacementStrategyProperty[] | cdktn.IResolvable;
    }
    class EcsParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EcsParametersProperty | undefined;
        set internalValue(value: EcsParametersProperty | undefined);
        private _enableEcsManagedTags?;
        get enableEcsManagedTags(): boolean | cdktn.IResolvable;
        set enableEcsManagedTags(value: boolean | cdktn.IResolvable);
        resetEnableEcsManagedTags(): void;
        get enableEcsManagedTagsInput(): boolean | cdktn.IResolvable | undefined;
        private _enableExecuteCommand?;
        get enableExecuteCommand(): boolean | cdktn.IResolvable;
        set enableExecuteCommand(value: boolean | cdktn.IResolvable);
        resetEnableExecuteCommand(): void;
        get enableExecuteCommandInput(): boolean | cdktn.IResolvable | undefined;
        private _group?;
        get group(): string;
        set group(value: string);
        resetGroup(): void;
        get groupInput(): string | undefined;
        private _launchType?;
        get launchType(): string;
        set launchType(value: string);
        resetLaunchType(): void;
        get launchTypeInput(): string | undefined;
        private _platformVersion?;
        get platformVersion(): string;
        set platformVersion(value: string);
        resetPlatformVersion(): void;
        get platformVersionInput(): string | undefined;
        private _propagateTags?;
        get propagateTags(): string;
        set propagateTags(value: string);
        resetPropagateTags(): void;
        get propagateTagsInput(): string | undefined;
        private _referenceId?;
        get referenceId(): string;
        set referenceId(value: string);
        resetReferenceId(): void;
        get referenceIdInput(): string | undefined;
        private _tags?;
        get tags(): {
            [key: string]: string;
        };
        set tags(value: {
            [key: string]: string;
        });
        resetTags(): void;
        get tagsInput(): {
            [key: string]: string;
        } | undefined;
        private _taskCount?;
        get taskCount(): number;
        set taskCount(value: number);
        resetTaskCount(): void;
        get taskCountInput(): number | undefined;
        private _taskDefinitionArn?;
        get taskDefinitionArn(): string;
        set taskDefinitionArn(value: string);
        get taskDefinitionArnInput(): string | undefined;
        private _capacityProviderStrategy;
        get capacityProviderStrategy(): CapacityProviderStrategyPropertyList;
        putCapacityProviderStrategy(value: CapacityProviderStrategyProperty[] | cdktn.IResolvable): void;
        resetCapacityProviderStrategy(): void;
        get capacityProviderStrategyInput(): cdktn.IResolvable | CapacityProviderStrategyProperty[] | undefined;
        private _networkConfiguration;
        get networkConfiguration(): NetworkConfigurationPropertyOutputReference;
        putNetworkConfiguration(value: NetworkConfigurationProperty): void;
        resetNetworkConfiguration(): void;
        get networkConfigurationInput(): NetworkConfigurationProperty | undefined;
        private _placementConstraints;
        get placementConstraints(): PlacementConstraintsPropertyList;
        putPlacementConstraints(value: PlacementConstraintsProperty[] | cdktn.IResolvable): void;
        resetPlacementConstraints(): void;
        get placementConstraintsInput(): cdktn.IResolvable | PlacementConstraintsProperty[] | undefined;
        private _placementStrategy;
        get placementStrategy(): PlacementStrategyPropertyList;
        putPlacementStrategy(value: PlacementStrategyProperty[] | cdktn.IResolvable): void;
        resetPlacementStrategy(): void;
        get placementStrategyInput(): cdktn.IResolvable | PlacementStrategyProperty[] | undefined;
    }
    interface EventbridgeParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#detail_type AwsSchedulerSchedule#detail_type}
        */
        readonly detailType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#source AwsSchedulerSchedule#source}
        */
        readonly source: string;
    }
    class EventbridgeParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EventbridgeParametersProperty | undefined;
        set internalValue(value: EventbridgeParametersProperty | undefined);
        private _detailType?;
        get detailType(): string;
        set detailType(value: string);
        get detailTypeInput(): string | undefined;
        private _source?;
        get source(): string;
        set source(value: string);
        get sourceInput(): string | undefined;
    }
    interface KinesisParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#partition_key AwsSchedulerSchedule#partition_key}
        */
        readonly partitionKey: string;
    }
    class KinesisParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): KinesisParametersProperty | undefined;
        set internalValue(value: KinesisParametersProperty | undefined);
        private _partitionKey?;
        get partitionKey(): string;
        set partitionKey(value: string);
        get partitionKeyInput(): string | undefined;
    }
    interface RetryPolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#maximum_event_age_in_seconds AwsSchedulerSchedule#maximum_event_age_in_seconds}
        */
        readonly maximumEventAgeInSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#maximum_retry_attempts AwsSchedulerSchedule#maximum_retry_attempts}
        */
        readonly maximumRetryAttempts?: number;
    }
    class RetryPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RetryPolicyProperty | undefined;
        set internalValue(value: RetryPolicyProperty | undefined);
        private _maximumEventAgeInSeconds?;
        get maximumEventAgeInSeconds(): number;
        set maximumEventAgeInSeconds(value: number);
        resetMaximumEventAgeInSeconds(): void;
        get maximumEventAgeInSecondsInput(): number | undefined;
        private _maximumRetryAttempts?;
        get maximumRetryAttempts(): number;
        set maximumRetryAttempts(value: number);
        resetMaximumRetryAttempts(): void;
        get maximumRetryAttemptsInput(): number | undefined;
    }
    interface PipelineParameterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#name AwsSchedulerSchedule#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#value AwsSchedulerSchedule#value}
        */
        readonly value: string;
    }
    class PipelineParameterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PipelineParameterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PipelineParameterProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class PipelineParameterPropertyList extends cdktn.ComplexList {
        internalValue?: PipelineParameterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PipelineParameterPropertyOutputReference;
    }
    interface SagemakerPipelineParametersProperty {
        /**
        * pipeline_parameter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#pipeline_parameter AwsSchedulerSchedule#pipeline_parameter}
        */
        readonly pipelineParameter?: PipelineParameterProperty[] | cdktn.IResolvable;
    }
    class SagemakerPipelineParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SagemakerPipelineParametersProperty | undefined;
        set internalValue(value: SagemakerPipelineParametersProperty | undefined);
        private _pipelineParameter;
        get pipelineParameter(): PipelineParameterPropertyList;
        putPipelineParameter(value: PipelineParameterProperty[] | cdktn.IResolvable): void;
        resetPipelineParameter(): void;
        get pipelineParameterInput(): cdktn.IResolvable | PipelineParameterProperty[] | undefined;
    }
    interface SqsParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#message_group_id AwsSchedulerSchedule#message_group_id}
        */
        readonly messageGroupId?: string;
    }
    class SqsParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SqsParametersProperty | undefined;
        set internalValue(value: SqsParametersProperty | undefined);
        private _messageGroupId?;
        get messageGroupId(): string;
        set messageGroupId(value: string);
        resetMessageGroupId(): void;
        get messageGroupIdInput(): string | undefined;
    }
    interface TargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#arn AwsSchedulerSchedule#arn}
        */
        readonly arn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#input AwsSchedulerSchedule#input}
        */
        readonly input?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#role_arn AwsSchedulerSchedule#role_arn}
        */
        readonly roleArn: string;
        /**
        * dead_letter_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#dead_letter_config AwsSchedulerSchedule#dead_letter_config}
        */
        readonly deadLetterConfig?: DeadLetterConfigProperty;
        /**
        * ecs_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#ecs_parameters AwsSchedulerSchedule#ecs_parameters}
        */
        readonly ecsParameters?: EcsParametersProperty;
        /**
        * eventbridge_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#eventbridge_parameters AwsSchedulerSchedule#eventbridge_parameters}
        */
        readonly eventbridgeParameters?: EventbridgeParametersProperty;
        /**
        * kinesis_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#kinesis_parameters AwsSchedulerSchedule#kinesis_parameters}
        */
        readonly kinesisParameters?: KinesisParametersProperty;
        /**
        * retry_policy block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#retry_policy AwsSchedulerSchedule#retry_policy}
        */
        readonly retryPolicy?: RetryPolicyProperty;
        /**
        * sagemaker_pipeline_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#sagemaker_pipeline_parameters AwsSchedulerSchedule#sagemaker_pipeline_parameters}
        */
        readonly sagemakerPipelineParameters?: SagemakerPipelineParametersProperty;
        /**
        * sqs_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/scheduler_schedule#sqs_parameters AwsSchedulerSchedule#sqs_parameters}
        */
        readonly sqsParameters?: SqsParametersProperty;
    }
    class TargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TargetProperty | undefined;
        set internalValue(value: TargetProperty | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
        private _input?;
        get input(): string;
        set input(value: string);
        resetInput(): void;
        get inputInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _deadLetterConfig;
        get deadLetterConfig(): DeadLetterConfigPropertyOutputReference;
        putDeadLetterConfig(value: DeadLetterConfigProperty): void;
        resetDeadLetterConfig(): void;
        get deadLetterConfigInput(): DeadLetterConfigProperty | undefined;
        private _ecsParameters;
        get ecsParameters(): EcsParametersPropertyOutputReference;
        putEcsParameters(value: EcsParametersProperty): void;
        resetEcsParameters(): void;
        get ecsParametersInput(): EcsParametersProperty | undefined;
        private _eventbridgeParameters;
        get eventbridgeParameters(): EventbridgeParametersPropertyOutputReference;
        putEventbridgeParameters(value: EventbridgeParametersProperty): void;
        resetEventbridgeParameters(): void;
        get eventbridgeParametersInput(): EventbridgeParametersProperty | undefined;
        private _kinesisParameters;
        get kinesisParameters(): KinesisParametersPropertyOutputReference;
        putKinesisParameters(value: KinesisParametersProperty): void;
        resetKinesisParameters(): void;
        get kinesisParametersInput(): KinesisParametersProperty | undefined;
        private _retryPolicy;
        get retryPolicy(): RetryPolicyPropertyOutputReference;
        putRetryPolicy(value: RetryPolicyProperty): void;
        resetRetryPolicy(): void;
        get retryPolicyInput(): RetryPolicyProperty | undefined;
        private _sagemakerPipelineParameters;
        get sagemakerPipelineParameters(): SagemakerPipelineParametersPropertyOutputReference;
        putSagemakerPipelineParameters(value: SagemakerPipelineParametersProperty): void;
        resetSagemakerPipelineParameters(): void;
        get sagemakerPipelineParametersInput(): SagemakerPipelineParametersProperty | undefined;
        private _sqsParameters;
        get sqsParameters(): SqsParametersPropertyOutputReference;
        putSqsParameters(value: SqsParametersProperty): void;
        resetSqsParameters(): void;
        get sqsParametersInput(): SqsParametersProperty | undefined;
    }
}
