import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsWorkspaceswebUserSettingsAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_user_settings_association#portal_arn AwsWorkspaceswebUserSettingsAssociation#portal_arn}
    */
    readonly portalArn: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_user_settings_association#region AwsWorkspaceswebUserSettingsAssociation#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_user_settings_association#user_settings_arn AwsWorkspaceswebUserSettingsAssociation#user_settings_arn}
    */
    readonly userSettingsArn: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_user_settings_association aws_workspacesweb_user_settings_association}
*/
export declare class AwsWorkspaceswebUserSettingsAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_workspacesweb_user_settings_association";
    /**
    * Generates CDKTN code for importing a AwsWorkspaceswebUserSettingsAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsWorkspaceswebUserSettingsAssociation to import
    * @param importFromId The id of the existing AwsWorkspaceswebUserSettingsAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_user_settings_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsWorkspaceswebUserSettingsAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_user_settings_association aws_workspacesweb_user_settings_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsWorkspaceswebUserSettingsAssociationConfig
    */
    constructor(scope: Construct, id: string, config: AwsWorkspaceswebUserSettingsAssociationConfig);
    private _portalArn?;
    get portalArn(): string;
    set portalArn(value: string);
    get portalArnInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _userSettingsArn?;
    get userSettingsArn(): string;
    set userSettingsArn(value: string);
    get userSettingsArnInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
