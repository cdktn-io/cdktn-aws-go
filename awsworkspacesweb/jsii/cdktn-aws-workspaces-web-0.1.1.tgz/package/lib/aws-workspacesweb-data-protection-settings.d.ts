import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsWorkspaceswebDataProtectionSettingsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_data_protection_settings#additional_encryption_context AwsWorkspaceswebDataProtectionSettings#additional_encryption_context}
    */
    readonly additionalEncryptionContext?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_data_protection_settings#customer_managed_key AwsWorkspaceswebDataProtectionSettings#customer_managed_key}
    */
    readonly customerManagedKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_data_protection_settings#description AwsWorkspaceswebDataProtectionSettings#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_data_protection_settings#display_name AwsWorkspaceswebDataProtectionSettings#display_name}
    */
    readonly displayName: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_data_protection_settings#region AwsWorkspaceswebDataProtectionSettings#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_data_protection_settings#tags AwsWorkspaceswebDataProtectionSettings#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * inline_redaction_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_data_protection_settings#inline_redaction_configuration AwsWorkspaceswebDataProtectionSettings#inline_redaction_configuration}
    */
    readonly inlineRedactionConfiguration?: AwsWorkspaceswebDataProtectionSettings.InlineRedactionConfigurationProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_data_protection_settings aws_workspacesweb_data_protection_settings}
*/
export declare class AwsWorkspaceswebDataProtectionSettings extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_workspacesweb_data_protection_settings";
    /**
    * Generates CDKTN code for importing a AwsWorkspaceswebDataProtectionSettings resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsWorkspaceswebDataProtectionSettings to import
    * @param importFromId The id of the existing AwsWorkspaceswebDataProtectionSettings that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_data_protection_settings#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsWorkspaceswebDataProtectionSettings to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_data_protection_settings aws_workspacesweb_data_protection_settings} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsWorkspaceswebDataProtectionSettingsConfig
    */
    constructor(scope: Construct, id: string, config: AwsWorkspaceswebDataProtectionSettingsConfig);
    private _additionalEncryptionContext?;
    get additionalEncryptionContext(): {
        [key: string]: string;
    };
    set additionalEncryptionContext(value: {
        [key: string]: string;
    });
    resetAdditionalEncryptionContext(): void;
    get additionalEncryptionContextInput(): {
        [key: string]: string;
    } | undefined;
    get associatedPortalArns(): string[];
    private _customerManagedKey?;
    get customerManagedKey(): string;
    set customerManagedKey(value: string);
    resetCustomerManagedKey(): void;
    get customerManagedKeyInput(): string | undefined;
    get dataProtectionSettingsArn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _inlineRedactionConfiguration;
    get inlineRedactionConfiguration(): AwsWorkspaceswebDataProtectionSettings.InlineRedactionConfigurationPropertyList;
    putInlineRedactionConfiguration(value: AwsWorkspaceswebDataProtectionSettings.InlineRedactionConfigurationProperty[] | cdktn.IResolvable): void;
    resetInlineRedactionConfiguration(): void;
    get inlineRedactionConfigurationInput(): cdktn.IResolvable | AwsWorkspaceswebDataProtectionSettings.InlineRedactionConfigurationProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsWorkspaceswebDataProtectionSettingsCustomPatternPropertyToTerraform(struct?: AwsWorkspaceswebDataProtectionSettings.CustomPatternProperty | cdktn.IResolvable): any;
export declare function awsWorkspaceswebDataProtectionSettingsCustomPatternPropertyToHclTerraform(struct?: AwsWorkspaceswebDataProtectionSettings.CustomPatternProperty | cdktn.IResolvable): any;
export declare function awsWorkspaceswebDataProtectionSettingsRedactionPlaceHolderPropertyToTerraform(struct?: AwsWorkspaceswebDataProtectionSettings.RedactionPlaceHolderProperty | cdktn.IResolvable): any;
export declare function awsWorkspaceswebDataProtectionSettingsRedactionPlaceHolderPropertyToHclTerraform(struct?: AwsWorkspaceswebDataProtectionSettings.RedactionPlaceHolderProperty | cdktn.IResolvable): any;
export declare function awsWorkspaceswebDataProtectionSettingsInlineRedactionPatternPropertyToTerraform(struct?: AwsWorkspaceswebDataProtectionSettings.InlineRedactionPatternProperty | cdktn.IResolvable): any;
export declare function awsWorkspaceswebDataProtectionSettingsInlineRedactionPatternPropertyToHclTerraform(struct?: AwsWorkspaceswebDataProtectionSettings.InlineRedactionPatternProperty | cdktn.IResolvable): any;
export declare function awsWorkspaceswebDataProtectionSettingsInlineRedactionConfigurationPropertyToTerraform(struct?: AwsWorkspaceswebDataProtectionSettings.InlineRedactionConfigurationProperty | cdktn.IResolvable): any;
export declare function awsWorkspaceswebDataProtectionSettingsInlineRedactionConfigurationPropertyToHclTerraform(struct?: AwsWorkspaceswebDataProtectionSettings.InlineRedactionConfigurationProperty | cdktn.IResolvable): any;
export declare namespace AwsWorkspaceswebDataProtectionSettings {
    interface CustomPatternProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_data_protection_settings#keyword_regex AwsWorkspaceswebDataProtectionSettings#keyword_regex}
        */
        readonly keywordRegex?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_data_protection_settings#pattern_description AwsWorkspaceswebDataProtectionSettings#pattern_description}
        */
        readonly patternDescription?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_data_protection_settings#pattern_name AwsWorkspaceswebDataProtectionSettings#pattern_name}
        */
        readonly patternName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_data_protection_settings#pattern_regex AwsWorkspaceswebDataProtectionSettings#pattern_regex}
        */
        readonly patternRegex: string;
    }
    class CustomPatternPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomPatternProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CustomPatternProperty | cdktn.IResolvable | undefined);
        private _keywordRegex?;
        get keywordRegex(): string;
        set keywordRegex(value: string);
        resetKeywordRegex(): void;
        get keywordRegexInput(): string | undefined;
        private _patternDescription?;
        get patternDescription(): string;
        set patternDescription(value: string);
        resetPatternDescription(): void;
        get patternDescriptionInput(): string | undefined;
        private _patternName?;
        get patternName(): string;
        set patternName(value: string);
        get patternNameInput(): string | undefined;
        private _patternRegex?;
        get patternRegex(): string;
        set patternRegex(value: string);
        get patternRegexInput(): string | undefined;
    }
    class CustomPatternPropertyList extends cdktn.ComplexList {
        internalValue?: CustomPatternProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomPatternPropertyOutputReference;
    }
    interface RedactionPlaceHolderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_data_protection_settings#redaction_place_holder_text AwsWorkspaceswebDataProtectionSettings#redaction_place_holder_text}
        */
        readonly redactionPlaceHolderText?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_data_protection_settings#redaction_place_holder_type AwsWorkspaceswebDataProtectionSettings#redaction_place_holder_type}
        */
        readonly redactionPlaceHolderType: string;
    }
    class RedactionPlaceHolderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RedactionPlaceHolderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RedactionPlaceHolderProperty | cdktn.IResolvable | undefined);
        private _redactionPlaceHolderText?;
        get redactionPlaceHolderText(): string;
        set redactionPlaceHolderText(value: string);
        resetRedactionPlaceHolderText(): void;
        get redactionPlaceHolderTextInput(): string | undefined;
        private _redactionPlaceHolderType?;
        get redactionPlaceHolderType(): string;
        set redactionPlaceHolderType(value: string);
        get redactionPlaceHolderTypeInput(): string | undefined;
    }
    class RedactionPlaceHolderPropertyList extends cdktn.ComplexList {
        internalValue?: RedactionPlaceHolderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RedactionPlaceHolderPropertyOutputReference;
    }
    interface InlineRedactionPatternProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_data_protection_settings#built_in_pattern_id AwsWorkspaceswebDataProtectionSettings#built_in_pattern_id}
        */
        readonly builtInPatternId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_data_protection_settings#confidence_level AwsWorkspaceswebDataProtectionSettings#confidence_level}
        */
        readonly confidenceLevel?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_data_protection_settings#enforced_urls AwsWorkspaceswebDataProtectionSettings#enforced_urls}
        */
        readonly enforcedUrls?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_data_protection_settings#exempt_urls AwsWorkspaceswebDataProtectionSettings#exempt_urls}
        */
        readonly exemptUrls?: string[];
        /**
        * custom_pattern block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_data_protection_settings#custom_pattern AwsWorkspaceswebDataProtectionSettings#custom_pattern}
        */
        readonly customPattern?: CustomPatternProperty[] | cdktn.IResolvable;
        /**
        * redaction_place_holder block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_data_protection_settings#redaction_place_holder AwsWorkspaceswebDataProtectionSettings#redaction_place_holder}
        */
        readonly redactionPlaceHolder?: RedactionPlaceHolderProperty[] | cdktn.IResolvable;
    }
    class InlineRedactionPatternPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InlineRedactionPatternProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InlineRedactionPatternProperty | cdktn.IResolvable | undefined);
        private _builtInPatternId?;
        get builtInPatternId(): string;
        set builtInPatternId(value: string);
        resetBuiltInPatternId(): void;
        get builtInPatternIdInput(): string | undefined;
        private _confidenceLevel?;
        get confidenceLevel(): number;
        set confidenceLevel(value: number);
        resetConfidenceLevel(): void;
        get confidenceLevelInput(): number | undefined;
        private _enforcedUrls?;
        get enforcedUrls(): string[];
        set enforcedUrls(value: string[]);
        resetEnforcedUrls(): void;
        get enforcedUrlsInput(): string[] | undefined;
        private _exemptUrls?;
        get exemptUrls(): string[];
        set exemptUrls(value: string[]);
        resetExemptUrls(): void;
        get exemptUrlsInput(): string[] | undefined;
        private _customPattern;
        get customPattern(): CustomPatternPropertyList;
        putCustomPattern(value: CustomPatternProperty[] | cdktn.IResolvable): void;
        resetCustomPattern(): void;
        get customPatternInput(): cdktn.IResolvable | CustomPatternProperty[] | undefined;
        private _redactionPlaceHolder;
        get redactionPlaceHolder(): RedactionPlaceHolderPropertyList;
        putRedactionPlaceHolder(value: RedactionPlaceHolderProperty[] | cdktn.IResolvable): void;
        resetRedactionPlaceHolder(): void;
        get redactionPlaceHolderInput(): cdktn.IResolvable | RedactionPlaceHolderProperty[] | undefined;
    }
    class InlineRedactionPatternPropertyList extends cdktn.ComplexList {
        internalValue?: InlineRedactionPatternProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InlineRedactionPatternPropertyOutputReference;
    }
    interface InlineRedactionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_data_protection_settings#global_confidence_level AwsWorkspaceswebDataProtectionSettings#global_confidence_level}
        */
        readonly globalConfidenceLevel?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_data_protection_settings#global_enforced_urls AwsWorkspaceswebDataProtectionSettings#global_enforced_urls}
        */
        readonly globalEnforcedUrls?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_data_protection_settings#global_exempt_urls AwsWorkspaceswebDataProtectionSettings#global_exempt_urls}
        */
        readonly globalExemptUrls?: string[];
        /**
        * inline_redaction_pattern block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_data_protection_settings#inline_redaction_pattern AwsWorkspaceswebDataProtectionSettings#inline_redaction_pattern}
        */
        readonly inlineRedactionPattern?: InlineRedactionPatternProperty[] | cdktn.IResolvable;
    }
    class InlineRedactionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InlineRedactionConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InlineRedactionConfigurationProperty | cdktn.IResolvable | undefined);
        private _globalConfidenceLevel?;
        get globalConfidenceLevel(): number;
        set globalConfidenceLevel(value: number);
        resetGlobalConfidenceLevel(): void;
        get globalConfidenceLevelInput(): number | undefined;
        private _globalEnforcedUrls?;
        get globalEnforcedUrls(): string[];
        set globalEnforcedUrls(value: string[]);
        resetGlobalEnforcedUrls(): void;
        get globalEnforcedUrlsInput(): string[] | undefined;
        private _globalExemptUrls?;
        get globalExemptUrls(): string[];
        set globalExemptUrls(value: string[]);
        resetGlobalExemptUrls(): void;
        get globalExemptUrlsInput(): string[] | undefined;
        private _inlineRedactionPattern;
        get inlineRedactionPattern(): InlineRedactionPatternPropertyList;
        putInlineRedactionPattern(value: InlineRedactionPatternProperty[] | cdktn.IResolvable): void;
        resetInlineRedactionPattern(): void;
        get inlineRedactionPatternInput(): cdktn.IResolvable | InlineRedactionPatternProperty[] | undefined;
    }
    class InlineRedactionConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: InlineRedactionConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InlineRedactionConfigurationPropertyOutputReference;
    }
}
