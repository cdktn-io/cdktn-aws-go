import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsWorkspaceswebIdentityProviderConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_identity_provider#identity_provider_details AwsWorkspaceswebIdentityProvider#identity_provider_details}
    */
    readonly identityProviderDetails: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_identity_provider#identity_provider_name AwsWorkspaceswebIdentityProvider#identity_provider_name}
    */
    readonly identityProviderName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_identity_provider#identity_provider_type AwsWorkspaceswebIdentityProvider#identity_provider_type}
    */
    readonly identityProviderType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_identity_provider#portal_arn AwsWorkspaceswebIdentityProvider#portal_arn}
    */
    readonly portalArn: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_identity_provider#region AwsWorkspaceswebIdentityProvider#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_identity_provider#tags AwsWorkspaceswebIdentityProvider#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_identity_provider aws_workspacesweb_identity_provider}
*/
export declare class AwsWorkspaceswebIdentityProvider extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_workspacesweb_identity_provider";
    /**
    * Generates CDKTN code for importing a AwsWorkspaceswebIdentityProvider resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsWorkspaceswebIdentityProvider to import
    * @param importFromId The id of the existing AwsWorkspaceswebIdentityProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_identity_provider#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsWorkspaceswebIdentityProvider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_identity_provider aws_workspacesweb_identity_provider} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsWorkspaceswebIdentityProviderConfig
    */
    constructor(scope: Construct, id: string, config: AwsWorkspaceswebIdentityProviderConfig);
    get identityProviderArn(): string;
    private _identityProviderDetails?;
    get identityProviderDetails(): {
        [key: string]: string;
    };
    set identityProviderDetails(value: {
        [key: string]: string;
    });
    get identityProviderDetailsInput(): {
        [key: string]: string;
    } | undefined;
    private _identityProviderName?;
    get identityProviderName(): string;
    set identityProviderName(value: string);
    get identityProviderNameInput(): string | undefined;
    private _identityProviderType?;
    get identityProviderType(): string;
    set identityProviderType(value: string);
    get identityProviderTypeInput(): string | undefined;
    private _portalArn?;
    get portalArn(): string;
    set portalArn(value: string);
    get portalArnInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
