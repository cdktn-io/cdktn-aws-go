import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfUserSettingsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_user_settings#additional_encryption_context TfUserSettings#additional_encryption_context}
    */
    readonly additionalEncryptionContext?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_user_settings#copy_allowed TfUserSettings#copy_allowed}
    */
    readonly copyAllowed: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_user_settings#customer_managed_key TfUserSettings#customer_managed_key}
    */
    readonly customerManagedKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_user_settings#deep_link_allowed TfUserSettings#deep_link_allowed}
    */
    readonly deepLinkAllowed?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_user_settings#disconnect_timeout_in_minutes TfUserSettings#disconnect_timeout_in_minutes}
    */
    readonly disconnectTimeoutInMinutes?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_user_settings#download_allowed TfUserSettings#download_allowed}
    */
    readonly downloadAllowed: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_user_settings#idle_disconnect_timeout_in_minutes TfUserSettings#idle_disconnect_timeout_in_minutes}
    */
    readonly idleDisconnectTimeoutInMinutes?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_user_settings#paste_allowed TfUserSettings#paste_allowed}
    */
    readonly pasteAllowed: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_user_settings#print_allowed TfUserSettings#print_allowed}
    */
    readonly printAllowed: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_user_settings#region TfUserSettings#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_user_settings#tags TfUserSettings#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_user_settings#upload_allowed TfUserSettings#upload_allowed}
    */
    readonly uploadAllowed: string;
    /**
    * cookie_synchronization_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_user_settings#cookie_synchronization_configuration TfUserSettings#cookie_synchronization_configuration}
    */
    readonly cookieSynchronizationConfiguration?: TfUserSettings.CookieSynchronizationConfigurationProperty[] | cdktn.IResolvable;
    /**
    * toolbar_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_user_settings#toolbar_configuration TfUserSettings#toolbar_configuration}
    */
    readonly toolbarConfiguration?: TfUserSettings.ToolbarConfigurationProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_user_settings aws_workspacesweb_user_settings}
*/
export declare class TfUserSettings extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_workspacesweb_user_settings";
    /**
    * Generates CDKTN code for importing a TfUserSettings resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfUserSettings to import
    * @param importFromId The id of the existing TfUserSettings that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_user_settings#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfUserSettings to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_user_settings aws_workspacesweb_user_settings} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfUserSettingsConfig
    */
    constructor(scope: Construct, id: string, config: TfUserSettingsConfig);
    private _additionalEncryptionContext?;
    get additionalEncryptionContext(): {
        [key: string]: string;
    };
    set additionalEncryptionContext(value: {
        [key: string]: string;
    });
    resetAdditionalEncryptionContext(): void;
    get additionalEncryptionContextInput(): {
        [key: string]: string;
    } | undefined;
    get associatedPortalArns(): string[];
    private _copyAllowed?;
    get copyAllowed(): string;
    set copyAllowed(value: string);
    get copyAllowedInput(): string | undefined;
    private _customerManagedKey?;
    get customerManagedKey(): string;
    set customerManagedKey(value: string);
    resetCustomerManagedKey(): void;
    get customerManagedKeyInput(): string | undefined;
    private _deepLinkAllowed?;
    get deepLinkAllowed(): string;
    set deepLinkAllowed(value: string);
    resetDeepLinkAllowed(): void;
    get deepLinkAllowedInput(): string | undefined;
    private _disconnectTimeoutInMinutes?;
    get disconnectTimeoutInMinutes(): number;
    set disconnectTimeoutInMinutes(value: number);
    resetDisconnectTimeoutInMinutes(): void;
    get disconnectTimeoutInMinutesInput(): number | undefined;
    private _downloadAllowed?;
    get downloadAllowed(): string;
    set downloadAllowed(value: string);
    get downloadAllowedInput(): string | undefined;
    private _idleDisconnectTimeoutInMinutes?;
    get idleDisconnectTimeoutInMinutes(): number;
    set idleDisconnectTimeoutInMinutes(value: number);
    resetIdleDisconnectTimeoutInMinutes(): void;
    get idleDisconnectTimeoutInMinutesInput(): number | undefined;
    private _pasteAllowed?;
    get pasteAllowed(): string;
    set pasteAllowed(value: string);
    get pasteAllowedInput(): string | undefined;
    private _printAllowed?;
    get printAllowed(): string;
    set printAllowed(value: string);
    get printAllowedInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _uploadAllowed?;
    get uploadAllowed(): string;
    set uploadAllowed(value: string);
    get uploadAllowedInput(): string | undefined;
    get userSettingsArn(): string;
    private _cookieSynchronizationConfiguration;
    get cookieSynchronizationConfiguration(): TfUserSettings.CookieSynchronizationConfigurationPropertyList;
    putCookieSynchronizationConfiguration(value: TfUserSettings.CookieSynchronizationConfigurationProperty[] | cdktn.IResolvable): void;
    resetCookieSynchronizationConfiguration(): void;
    get cookieSynchronizationConfigurationInput(): cdktn.IResolvable | TfUserSettings.CookieSynchronizationConfigurationProperty[] | undefined;
    private _toolbarConfiguration;
    get toolbarConfiguration(): TfUserSettings.ToolbarConfigurationPropertyList;
    putToolbarConfiguration(value: TfUserSettings.ToolbarConfigurationProperty[] | cdktn.IResolvable): void;
    resetToolbarConfiguration(): void;
    get toolbarConfigurationInput(): cdktn.IResolvable | TfUserSettings.ToolbarConfigurationProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfUserSettingsAllowlistPropertyToTerraform(struct?: TfUserSettings.AllowlistProperty | cdktn.IResolvable): any;
export declare function tfUserSettingsAllowlistPropertyToHclTerraform(struct?: TfUserSettings.AllowlistProperty | cdktn.IResolvable): any;
export declare function tfUserSettingsBlocklistPropertyToTerraform(struct?: TfUserSettings.BlocklistProperty | cdktn.IResolvable): any;
export declare function tfUserSettingsBlocklistPropertyToHclTerraform(struct?: TfUserSettings.BlocklistProperty | cdktn.IResolvable): any;
export declare function tfUserSettingsCookieSynchronizationConfigurationPropertyToTerraform(struct?: TfUserSettings.CookieSynchronizationConfigurationProperty | cdktn.IResolvable): any;
export declare function tfUserSettingsCookieSynchronizationConfigurationPropertyToHclTerraform(struct?: TfUserSettings.CookieSynchronizationConfigurationProperty | cdktn.IResolvable): any;
export declare function tfUserSettingsToolbarConfigurationPropertyToTerraform(struct?: TfUserSettings.ToolbarConfigurationProperty | cdktn.IResolvable): any;
export declare function tfUserSettingsToolbarConfigurationPropertyToHclTerraform(struct?: TfUserSettings.ToolbarConfigurationProperty | cdktn.IResolvable): any;
export declare namespace TfUserSettings {
    interface AllowlistProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_user_settings#domain TfUserSettings#domain}
        */
        readonly domain: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_user_settings#name TfUserSettings#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_user_settings#path TfUserSettings#path}
        */
        readonly path?: string;
    }
    class AllowlistPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AllowlistProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AllowlistProperty | cdktn.IResolvable | undefined);
        private _domain?;
        get domain(): string;
        set domain(value: string);
        get domainInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _path?;
        get path(): string;
        set path(value: string);
        resetPath(): void;
        get pathInput(): string | undefined;
    }
    class AllowlistPropertyList extends cdktn.ComplexList {
        internalValue?: AllowlistProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AllowlistPropertyOutputReference;
    }
    interface BlocklistProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_user_settings#domain TfUserSettings#domain}
        */
        readonly domain: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_user_settings#name TfUserSettings#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_user_settings#path TfUserSettings#path}
        */
        readonly path?: string;
    }
    class BlocklistPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BlocklistProperty | cdktn.IResolvable | undefined;
        set internalValue(value: BlocklistProperty | cdktn.IResolvable | undefined);
        private _domain?;
        get domain(): string;
        set domain(value: string);
        get domainInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _path?;
        get path(): string;
        set path(value: string);
        resetPath(): void;
        get pathInput(): string | undefined;
    }
    class BlocklistPropertyList extends cdktn.ComplexList {
        internalValue?: BlocklistProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BlocklistPropertyOutputReference;
    }
    interface CookieSynchronizationConfigurationProperty {
        /**
        * allowlist block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_user_settings#allowlist TfUserSettings#allowlist}
        */
        readonly allowlist?: AllowlistProperty[] | cdktn.IResolvable;
        /**
        * blocklist block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_user_settings#blocklist TfUserSettings#blocklist}
        */
        readonly blocklist?: BlocklistProperty[] | cdktn.IResolvable;
    }
    class CookieSynchronizationConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CookieSynchronizationConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CookieSynchronizationConfigurationProperty | cdktn.IResolvable | undefined);
        private _allowlist;
        get allowlist(): AllowlistPropertyList;
        putAllowlist(value: AllowlistProperty[] | cdktn.IResolvable): void;
        resetAllowlist(): void;
        get allowlistInput(): cdktn.IResolvable | AllowlistProperty[] | undefined;
        private _blocklist;
        get blocklist(): BlocklistPropertyList;
        putBlocklist(value: BlocklistProperty[] | cdktn.IResolvable): void;
        resetBlocklist(): void;
        get blocklistInput(): cdktn.IResolvable | BlocklistProperty[] | undefined;
    }
    class CookieSynchronizationConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: CookieSynchronizationConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CookieSynchronizationConfigurationPropertyOutputReference;
    }
    interface ToolbarConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_user_settings#hidden_toolbar_items TfUserSettings#hidden_toolbar_items}
        */
        readonly hiddenToolbarItems?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_user_settings#max_display_resolution TfUserSettings#max_display_resolution}
        */
        readonly maxDisplayResolution?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_user_settings#toolbar_type TfUserSettings#toolbar_type}
        */
        readonly toolbarType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_user_settings#visual_mode TfUserSettings#visual_mode}
        */
        readonly visualMode?: string;
    }
    class ToolbarConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ToolbarConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ToolbarConfigurationProperty | cdktn.IResolvable | undefined);
        private _hiddenToolbarItems?;
        get hiddenToolbarItems(): string[];
        set hiddenToolbarItems(value: string[]);
        resetHiddenToolbarItems(): void;
        get hiddenToolbarItemsInput(): string[] | undefined;
        private _maxDisplayResolution?;
        get maxDisplayResolution(): string;
        set maxDisplayResolution(value: string);
        resetMaxDisplayResolution(): void;
        get maxDisplayResolutionInput(): string | undefined;
        private _toolbarType?;
        get toolbarType(): string;
        set toolbarType(value: string);
        resetToolbarType(): void;
        get toolbarTypeInput(): string | undefined;
        private _visualMode?;
        get visualMode(): string;
        set visualMode(value: string);
        resetVisualMode(): void;
        get visualModeInput(): string | undefined;
    }
    class ToolbarConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: ToolbarConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ToolbarConfigurationPropertyOutputReference;
    }
}
