import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfSessionLoggerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_session_logger#additional_encryption_context TfSessionLogger#additional_encryption_context}
    */
    readonly additionalEncryptionContext?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_session_logger#customer_managed_key TfSessionLogger#customer_managed_key}
    */
    readonly customerManagedKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_session_logger#display_name TfSessionLogger#display_name}
    */
    readonly displayName?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_session_logger#region TfSessionLogger#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_session_logger#tags TfSessionLogger#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * event_filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_session_logger#event_filter TfSessionLogger#event_filter}
    */
    readonly eventFilter?: TfSessionLogger.EventFilterProperty[] | cdktn.IResolvable;
    /**
    * log_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_session_logger#log_configuration TfSessionLogger#log_configuration}
    */
    readonly logConfiguration?: TfSessionLogger.LogConfigurationProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_session_logger aws_workspacesweb_session_logger}
*/
export declare class TfSessionLogger extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_workspacesweb_session_logger";
    /**
    * Generates CDKTN code for importing a TfSessionLogger resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfSessionLogger to import
    * @param importFromId The id of the existing TfSessionLogger that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_session_logger#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfSessionLogger to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_session_logger aws_workspacesweb_session_logger} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfSessionLoggerConfig = {}
    */
    constructor(scope: Construct, id: string, config?: TfSessionLoggerConfig);
    private _additionalEncryptionContext?;
    get additionalEncryptionContext(): {
        [key: string]: string;
    };
    set additionalEncryptionContext(value: {
        [key: string]: string;
    });
    resetAdditionalEncryptionContext(): void;
    get additionalEncryptionContextInput(): {
        [key: string]: string;
    } | undefined;
    get associatedPortalArns(): string[];
    private _customerManagedKey?;
    get customerManagedKey(): string;
    set customerManagedKey(value: string);
    resetCustomerManagedKey(): void;
    get customerManagedKeyInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get sessionLoggerArn(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _eventFilter;
    get eventFilter(): TfSessionLogger.EventFilterPropertyList;
    putEventFilter(value: TfSessionLogger.EventFilterProperty[] | cdktn.IResolvable): void;
    resetEventFilter(): void;
    get eventFilterInput(): cdktn.IResolvable | TfSessionLogger.EventFilterProperty[] | undefined;
    private _logConfiguration;
    get logConfiguration(): TfSessionLogger.LogConfigurationPropertyList;
    putLogConfiguration(value: TfSessionLogger.LogConfigurationProperty[] | cdktn.IResolvable): void;
    resetLogConfiguration(): void;
    get logConfigurationInput(): cdktn.IResolvable | TfSessionLogger.LogConfigurationProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfSessionLoggerAllPropertyToTerraform(struct?: TfSessionLogger.AllProperty | cdktn.IResolvable): any;
export declare function tfSessionLoggerAllPropertyToHclTerraform(struct?: TfSessionLogger.AllProperty | cdktn.IResolvable): any;
export declare function tfSessionLoggerEventFilterPropertyToTerraform(struct?: TfSessionLogger.EventFilterProperty | cdktn.IResolvable): any;
export declare function tfSessionLoggerEventFilterPropertyToHclTerraform(struct?: TfSessionLogger.EventFilterProperty | cdktn.IResolvable): any;
export declare function tfSessionLoggerS3PropertyToTerraform(struct?: TfSessionLogger.S3Property | cdktn.IResolvable): any;
export declare function tfSessionLoggerS3PropertyToHclTerraform(struct?: TfSessionLogger.S3Property | cdktn.IResolvable): any;
export declare function tfSessionLoggerLogConfigurationPropertyToTerraform(struct?: TfSessionLogger.LogConfigurationProperty | cdktn.IResolvable): any;
export declare function tfSessionLoggerLogConfigurationPropertyToHclTerraform(struct?: TfSessionLogger.LogConfigurationProperty | cdktn.IResolvable): any;
export declare namespace TfSessionLogger {
    interface AllProperty {
    }
    class AllPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AllProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AllProperty | cdktn.IResolvable | undefined);
    }
    class AllPropertyList extends cdktn.ComplexList {
        internalValue?: AllProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AllPropertyOutputReference;
    }
    interface EventFilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_session_logger#include TfSessionLogger#include}
        */
        readonly include?: string[];
        /**
        * all block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_session_logger#all TfSessionLogger#all}
        */
        readonly all?: AllProperty[] | cdktn.IResolvable;
    }
    class EventFilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EventFilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EventFilterProperty | cdktn.IResolvable | undefined);
        private _include?;
        get include(): string[];
        set include(value: string[]);
        resetInclude(): void;
        get includeInput(): string[] | undefined;
        private _all;
        get all(): AllPropertyList;
        putAll(value: AllProperty[] | cdktn.IResolvable): void;
        resetAll(): void;
        get allInput(): cdktn.IResolvable | AllProperty[] | undefined;
    }
    class EventFilterPropertyList extends cdktn.ComplexList {
        internalValue?: EventFilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EventFilterPropertyOutputReference;
    }
    interface S3Property {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_session_logger#bucket TfSessionLogger#bucket}
        */
        readonly bucket: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_session_logger#bucket_owner TfSessionLogger#bucket_owner}
        */
        readonly bucketOwner?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_session_logger#folder_structure TfSessionLogger#folder_structure}
        */
        readonly folderStructure: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_session_logger#key_prefix TfSessionLogger#key_prefix}
        */
        readonly keyPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_session_logger#log_file_format TfSessionLogger#log_file_format}
        */
        readonly logFileFormat: string;
    }
    class S3PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3Property | cdktn.IResolvable | undefined;
        set internalValue(value: S3Property | cdktn.IResolvable | undefined);
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        get bucketInput(): string | undefined;
        private _bucketOwner?;
        get bucketOwner(): string;
        set bucketOwner(value: string);
        resetBucketOwner(): void;
        get bucketOwnerInput(): string | undefined;
        private _folderStructure?;
        get folderStructure(): string;
        set folderStructure(value: string);
        get folderStructureInput(): string | undefined;
        private _keyPrefix?;
        get keyPrefix(): string;
        set keyPrefix(value: string);
        resetKeyPrefix(): void;
        get keyPrefixInput(): string | undefined;
        private _logFileFormat?;
        get logFileFormat(): string;
        set logFileFormat(value: string);
        get logFileFormatInput(): string | undefined;
    }
    class S3PropertyList extends cdktn.ComplexList {
        internalValue?: S3Property[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3PropertyOutputReference;
    }
    interface LogConfigurationProperty {
        /**
        * s3 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_session_logger#s3 TfSessionLogger#s3}
        */
        readonly s3?: S3Property[] | cdktn.IResolvable;
    }
    class LogConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LogConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LogConfigurationProperty | cdktn.IResolvable | undefined);
        private _s3;
        get s3(): S3PropertyList;
        putS3(value: S3Property[] | cdktn.IResolvable): void;
        resetS3(): void;
        get s3Input(): cdktn.IResolvable | S3Property[] | undefined;
    }
    class LogConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: LogConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LogConfigurationPropertyOutputReference;
    }
}
