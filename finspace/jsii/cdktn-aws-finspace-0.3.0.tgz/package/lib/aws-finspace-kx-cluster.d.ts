import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsKxClusterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#availability_zone_id AwsKxCluster#availability_zone_id}
    */
    readonly availabilityZoneId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#az_mode AwsKxCluster#az_mode}
    */
    readonly azMode: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#command_line_arguments AwsKxCluster#command_line_arguments}
    */
    readonly commandLineArguments?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#description AwsKxCluster#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#environment_id AwsKxCluster#environment_id}
    */
    readonly environmentId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#execution_role AwsKxCluster#execution_role}
    */
    readonly executionRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#id AwsKxCluster#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#initialization_script AwsKxCluster#initialization_script}
    */
    readonly initializationScript?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#name AwsKxCluster#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#region AwsKxCluster#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#release_label AwsKxCluster#release_label}
    */
    readonly releaseLabel: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#tags AwsKxCluster#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#tags_all AwsKxCluster#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#type AwsKxCluster#type}
    */
    readonly type: string;
    /**
    * auto_scaling_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#auto_scaling_configuration AwsKxCluster#auto_scaling_configuration}
    */
    readonly autoScalingConfiguration?: AwsKxCluster.AutoScalingConfigurationProperty;
    /**
    * cache_storage_configurations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#cache_storage_configurations AwsKxCluster#cache_storage_configurations}
    */
    readonly cacheStorageConfigurations?: AwsKxCluster.CacheStorageConfigurationsProperty[] | cdktn.IResolvable;
    /**
    * capacity_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#capacity_configuration AwsKxCluster#capacity_configuration}
    */
    readonly capacityConfiguration?: AwsKxCluster.CapacityConfigurationProperty;
    /**
    * code block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#code AwsKxCluster#code}
    */
    readonly code?: AwsKxCluster.CodeProperty;
    /**
    * database block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#database AwsKxCluster#database}
    */
    readonly database?: AwsKxCluster.DatabaseProperty[] | cdktn.IResolvable;
    /**
    * savedown_storage_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#savedown_storage_configuration AwsKxCluster#savedown_storage_configuration}
    */
    readonly savedownStorageConfiguration?: AwsKxCluster.SavedownStorageConfigurationProperty;
    /**
    * scaling_group_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#scaling_group_configuration AwsKxCluster#scaling_group_configuration}
    */
    readonly scalingGroupConfiguration?: AwsKxCluster.ScalingGroupConfigurationProperty;
    /**
    * tickerplant_log_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#tickerplant_log_configuration AwsKxCluster#tickerplant_log_configuration}
    */
    readonly tickerplantLogConfiguration?: AwsKxCluster.TickerplantLogConfigurationProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#timeouts AwsKxCluster#timeouts}
    */
    readonly timeouts?: AwsKxCluster.TimeoutsProperty;
    /**
    * vpc_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#vpc_configuration AwsKxCluster#vpc_configuration}
    */
    readonly vpcConfiguration: AwsKxCluster.VpcConfigurationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster aws_finspace_kx_cluster}
*/
export declare class AwsKxCluster extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_finspace_kx_cluster";
    /**
    * Generates CDKTN code for importing a AwsKxCluster resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsKxCluster to import
    * @param importFromId The id of the existing AwsKxCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsKxCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster aws_finspace_kx_cluster} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsKxClusterConfig
    */
    constructor(scope: Construct, id: string, config: AwsKxClusterConfig);
    get arn(): string;
    private _availabilityZoneId?;
    get availabilityZoneId(): string;
    set availabilityZoneId(value: string);
    resetAvailabilityZoneId(): void;
    get availabilityZoneIdInput(): string | undefined;
    private _azMode?;
    get azMode(): string;
    set azMode(value: string);
    get azModeInput(): string | undefined;
    private _commandLineArguments?;
    get commandLineArguments(): {
        [key: string]: string;
    };
    set commandLineArguments(value: {
        [key: string]: string;
    });
    resetCommandLineArguments(): void;
    get commandLineArgumentsInput(): {
        [key: string]: string;
    } | undefined;
    get createdTimestamp(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _environmentId?;
    get environmentId(): string;
    set environmentId(value: string);
    get environmentIdInput(): string | undefined;
    private _executionRole?;
    get executionRole(): string;
    set executionRole(value: string);
    resetExecutionRole(): void;
    get executionRoleInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _initializationScript?;
    get initializationScript(): string;
    set initializationScript(value: string);
    resetInitializationScript(): void;
    get initializationScriptInput(): string | undefined;
    get lastModifiedTimestamp(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _releaseLabel?;
    get releaseLabel(): string;
    set releaseLabel(value: string);
    get releaseLabelInput(): string | undefined;
    get status(): string;
    get statusReason(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _autoScalingConfiguration;
    get autoScalingConfiguration(): AwsKxCluster.AutoScalingConfigurationPropertyOutputReference;
    putAutoScalingConfiguration(value: AwsKxCluster.AutoScalingConfigurationProperty): void;
    resetAutoScalingConfiguration(): void;
    get autoScalingConfigurationInput(): AwsKxCluster.AutoScalingConfigurationProperty | undefined;
    private _cacheStorageConfigurations;
    get cacheStorageConfigurations(): AwsKxCluster.CacheStorageConfigurationsPropertyList;
    putCacheStorageConfigurations(value: AwsKxCluster.CacheStorageConfigurationsProperty[] | cdktn.IResolvable): void;
    resetCacheStorageConfigurations(): void;
    get cacheStorageConfigurationsInput(): cdktn.IResolvable | AwsKxCluster.CacheStorageConfigurationsProperty[] | undefined;
    private _capacityConfiguration;
    get capacityConfiguration(): AwsKxCluster.CapacityConfigurationPropertyOutputReference;
    putCapacityConfiguration(value: AwsKxCluster.CapacityConfigurationProperty): void;
    resetCapacityConfiguration(): void;
    get capacityConfigurationInput(): AwsKxCluster.CapacityConfigurationProperty | undefined;
    private _code;
    get code(): AwsKxCluster.CodePropertyOutputReference;
    putCode(value: AwsKxCluster.CodeProperty): void;
    resetCode(): void;
    get codeInput(): AwsKxCluster.CodeProperty | undefined;
    private _database;
    get database(): AwsKxCluster.DatabasePropertyList;
    putDatabase(value: AwsKxCluster.DatabaseProperty[] | cdktn.IResolvable): void;
    resetDatabase(): void;
    get databaseInput(): cdktn.IResolvable | AwsKxCluster.DatabaseProperty[] | undefined;
    private _savedownStorageConfiguration;
    get savedownStorageConfiguration(): AwsKxCluster.SavedownStorageConfigurationPropertyOutputReference;
    putSavedownStorageConfiguration(value: AwsKxCluster.SavedownStorageConfigurationProperty): void;
    resetSavedownStorageConfiguration(): void;
    get savedownStorageConfigurationInput(): AwsKxCluster.SavedownStorageConfigurationProperty | undefined;
    private _scalingGroupConfiguration;
    get scalingGroupConfiguration(): AwsKxCluster.ScalingGroupConfigurationPropertyOutputReference;
    putScalingGroupConfiguration(value: AwsKxCluster.ScalingGroupConfigurationProperty): void;
    resetScalingGroupConfiguration(): void;
    get scalingGroupConfigurationInput(): AwsKxCluster.ScalingGroupConfigurationProperty | undefined;
    private _tickerplantLogConfiguration;
    get tickerplantLogConfiguration(): AwsKxCluster.TickerplantLogConfigurationPropertyList;
    putTickerplantLogConfiguration(value: AwsKxCluster.TickerplantLogConfigurationProperty[] | cdktn.IResolvable): void;
    resetTickerplantLogConfiguration(): void;
    get tickerplantLogConfigurationInput(): cdktn.IResolvable | AwsKxCluster.TickerplantLogConfigurationProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsKxCluster.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsKxCluster.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsKxCluster.TimeoutsProperty | undefined;
    private _vpcConfiguration;
    get vpcConfiguration(): AwsKxCluster.VpcConfigurationPropertyOutputReference;
    putVpcConfiguration(value: AwsKxCluster.VpcConfigurationProperty): void;
    get vpcConfigurationInput(): AwsKxCluster.VpcConfigurationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsKxClusterAutoScalingConfigurationPropertyToTerraform(struct?: AwsKxCluster.AutoScalingConfigurationPropertyOutputReference | AwsKxCluster.AutoScalingConfigurationProperty): any;
export declare function awsKxClusterAutoScalingConfigurationPropertyToHclTerraform(struct?: AwsKxCluster.AutoScalingConfigurationPropertyOutputReference | AwsKxCluster.AutoScalingConfigurationProperty): any;
export declare function awsKxClusterCacheStorageConfigurationsPropertyToTerraform(struct?: AwsKxCluster.CacheStorageConfigurationsProperty | cdktn.IResolvable): any;
export declare function awsKxClusterCacheStorageConfigurationsPropertyToHclTerraform(struct?: AwsKxCluster.CacheStorageConfigurationsProperty | cdktn.IResolvable): any;
export declare function awsKxClusterCapacityConfigurationPropertyToTerraform(struct?: AwsKxCluster.CapacityConfigurationPropertyOutputReference | AwsKxCluster.CapacityConfigurationProperty): any;
export declare function awsKxClusterCapacityConfigurationPropertyToHclTerraform(struct?: AwsKxCluster.CapacityConfigurationPropertyOutputReference | AwsKxCluster.CapacityConfigurationProperty): any;
export declare function awsKxClusterCodePropertyToTerraform(struct?: AwsKxCluster.CodePropertyOutputReference | AwsKxCluster.CodeProperty): any;
export declare function awsKxClusterCodePropertyToHclTerraform(struct?: AwsKxCluster.CodePropertyOutputReference | AwsKxCluster.CodeProperty): any;
export declare function awsKxClusterCacheConfigurationsPropertyToTerraform(struct?: AwsKxCluster.CacheConfigurationsProperty | cdktn.IResolvable): any;
export declare function awsKxClusterCacheConfigurationsPropertyToHclTerraform(struct?: AwsKxCluster.CacheConfigurationsProperty | cdktn.IResolvable): any;
export declare function awsKxClusterDatabasePropertyToTerraform(struct?: AwsKxCluster.DatabaseProperty | cdktn.IResolvable): any;
export declare function awsKxClusterDatabasePropertyToHclTerraform(struct?: AwsKxCluster.DatabaseProperty | cdktn.IResolvable): any;
export declare function awsKxClusterSavedownStorageConfigurationPropertyToTerraform(struct?: AwsKxCluster.SavedownStorageConfigurationPropertyOutputReference | AwsKxCluster.SavedownStorageConfigurationProperty): any;
export declare function awsKxClusterSavedownStorageConfigurationPropertyToHclTerraform(struct?: AwsKxCluster.SavedownStorageConfigurationPropertyOutputReference | AwsKxCluster.SavedownStorageConfigurationProperty): any;
export declare function awsKxClusterScalingGroupConfigurationPropertyToTerraform(struct?: AwsKxCluster.ScalingGroupConfigurationPropertyOutputReference | AwsKxCluster.ScalingGroupConfigurationProperty): any;
export declare function awsKxClusterScalingGroupConfigurationPropertyToHclTerraform(struct?: AwsKxCluster.ScalingGroupConfigurationPropertyOutputReference | AwsKxCluster.ScalingGroupConfigurationProperty): any;
export declare function awsKxClusterTickerplantLogConfigurationPropertyToTerraform(struct?: AwsKxCluster.TickerplantLogConfigurationProperty | cdktn.IResolvable): any;
export declare function awsKxClusterTickerplantLogConfigurationPropertyToHclTerraform(struct?: AwsKxCluster.TickerplantLogConfigurationProperty | cdktn.IResolvable): any;
export declare function awsKxClusterTimeoutsPropertyToTerraform(struct?: AwsKxCluster.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsKxClusterTimeoutsPropertyToHclTerraform(struct?: AwsKxCluster.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsKxClusterVpcConfigurationPropertyToTerraform(struct?: AwsKxCluster.VpcConfigurationPropertyOutputReference | AwsKxCluster.VpcConfigurationProperty): any;
export declare function awsKxClusterVpcConfigurationPropertyToHclTerraform(struct?: AwsKxCluster.VpcConfigurationPropertyOutputReference | AwsKxCluster.VpcConfigurationProperty): any;
export declare namespace AwsKxCluster {
    interface AutoScalingConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#auto_scaling_metric AwsKxCluster#auto_scaling_metric}
        */
        readonly autoScalingMetric: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#max_node_count AwsKxCluster#max_node_count}
        */
        readonly maxNodeCount: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#metric_target AwsKxCluster#metric_target}
        */
        readonly metricTarget: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#min_node_count AwsKxCluster#min_node_count}
        */
        readonly minNodeCount: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#scale_in_cooldown_seconds AwsKxCluster#scale_in_cooldown_seconds}
        */
        readonly scaleInCooldownSeconds: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#scale_out_cooldown_seconds AwsKxCluster#scale_out_cooldown_seconds}
        */
        readonly scaleOutCooldownSeconds: number;
    }
    class AutoScalingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AutoScalingConfigurationProperty | undefined;
        set internalValue(value: AutoScalingConfigurationProperty | undefined);
        private _autoScalingMetric?;
        get autoScalingMetric(): string;
        set autoScalingMetric(value: string);
        get autoScalingMetricInput(): string | undefined;
        private _maxNodeCount?;
        get maxNodeCount(): number;
        set maxNodeCount(value: number);
        get maxNodeCountInput(): number | undefined;
        private _metricTarget?;
        get metricTarget(): number;
        set metricTarget(value: number);
        get metricTargetInput(): number | undefined;
        private _minNodeCount?;
        get minNodeCount(): number;
        set minNodeCount(value: number);
        get minNodeCountInput(): number | undefined;
        private _scaleInCooldownSeconds?;
        get scaleInCooldownSeconds(): number;
        set scaleInCooldownSeconds(value: number);
        get scaleInCooldownSecondsInput(): number | undefined;
        private _scaleOutCooldownSeconds?;
        get scaleOutCooldownSeconds(): number;
        set scaleOutCooldownSeconds(value: number);
        get scaleOutCooldownSecondsInput(): number | undefined;
    }
    interface CacheStorageConfigurationsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#size AwsKxCluster#size}
        */
        readonly size: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#type AwsKxCluster#type}
        */
        readonly type: string;
    }
    class CacheStorageConfigurationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CacheStorageConfigurationsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CacheStorageConfigurationsProperty | cdktn.IResolvable | undefined);
        private _size?;
        get size(): number;
        set size(value: number);
        get sizeInput(): number | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class CacheStorageConfigurationsPropertyList extends cdktn.ComplexList {
        internalValue?: CacheStorageConfigurationsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CacheStorageConfigurationsPropertyOutputReference;
    }
    interface CapacityConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#node_count AwsKxCluster#node_count}
        */
        readonly nodeCount: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#node_type AwsKxCluster#node_type}
        */
        readonly nodeType: string;
    }
    class CapacityConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CapacityConfigurationProperty | undefined;
        set internalValue(value: CapacityConfigurationProperty | undefined);
        private _nodeCount?;
        get nodeCount(): number;
        set nodeCount(value: number);
        get nodeCountInput(): number | undefined;
        private _nodeType?;
        get nodeType(): string;
        set nodeType(value: string);
        get nodeTypeInput(): string | undefined;
    }
    interface CodeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#s3_bucket AwsKxCluster#s3_bucket}
        */
        readonly s3Bucket: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#s3_key AwsKxCluster#s3_key}
        */
        readonly s3Key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#s3_object_version AwsKxCluster#s3_object_version}
        */
        readonly s3ObjectVersion?: string;
    }
    class CodePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CodeProperty | undefined;
        set internalValue(value: CodeProperty | undefined);
        private _s3Bucket?;
        get s3Bucket(): string;
        set s3Bucket(value: string);
        get s3BucketInput(): string | undefined;
        private _s3Key?;
        get s3Key(): string;
        set s3Key(value: string);
        get s3KeyInput(): string | undefined;
        private _s3ObjectVersion?;
        get s3ObjectVersion(): string;
        set s3ObjectVersion(value: string);
        resetS3ObjectVersion(): void;
        get s3ObjectVersionInput(): string | undefined;
    }
    interface CacheConfigurationsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#cache_type AwsKxCluster#cache_type}
        */
        readonly cacheType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#db_paths AwsKxCluster#db_paths}
        */
        readonly dbPaths?: string[];
    }
    class CacheConfigurationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CacheConfigurationsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CacheConfigurationsProperty | cdktn.IResolvable | undefined);
        private _cacheType?;
        get cacheType(): string;
        set cacheType(value: string);
        get cacheTypeInput(): string | undefined;
        private _dbPaths?;
        get dbPaths(): string[];
        set dbPaths(value: string[]);
        resetDbPaths(): void;
        get dbPathsInput(): string[] | undefined;
    }
    class CacheConfigurationsPropertyList extends cdktn.ComplexList {
        internalValue?: CacheConfigurationsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CacheConfigurationsPropertyOutputReference;
    }
    interface DatabaseProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#changeset_id AwsKxCluster#changeset_id}
        */
        readonly changesetId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#database_name AwsKxCluster#database_name}
        */
        readonly databaseName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#dataview_name AwsKxCluster#dataview_name}
        */
        readonly dataviewName?: string;
        /**
        * cache_configurations block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#cache_configurations AwsKxCluster#cache_configurations}
        */
        readonly cacheConfigurations?: CacheConfigurationsProperty[] | cdktn.IResolvable;
    }
    class DatabasePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DatabaseProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DatabaseProperty | cdktn.IResolvable | undefined);
        private _changesetId?;
        get changesetId(): string;
        set changesetId(value: string);
        resetChangesetId(): void;
        get changesetIdInput(): string | undefined;
        private _databaseName?;
        get databaseName(): string;
        set databaseName(value: string);
        get databaseNameInput(): string | undefined;
        private _dataviewName?;
        get dataviewName(): string;
        set dataviewName(value: string);
        resetDataviewName(): void;
        get dataviewNameInput(): string | undefined;
        private _cacheConfigurations;
        get cacheConfigurations(): CacheConfigurationsPropertyList;
        putCacheConfigurations(value: CacheConfigurationsProperty[] | cdktn.IResolvable): void;
        resetCacheConfigurations(): void;
        get cacheConfigurationsInput(): cdktn.IResolvable | CacheConfigurationsProperty[] | undefined;
    }
    class DatabasePropertyList extends cdktn.ComplexList {
        internalValue?: DatabaseProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DatabasePropertyOutputReference;
    }
    interface SavedownStorageConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#size AwsKxCluster#size}
        */
        readonly size?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#type AwsKxCluster#type}
        */
        readonly type?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#volume_name AwsKxCluster#volume_name}
        */
        readonly volumeName?: string;
    }
    class SavedownStorageConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SavedownStorageConfigurationProperty | undefined;
        set internalValue(value: SavedownStorageConfigurationProperty | undefined);
        private _size?;
        get size(): number;
        set size(value: number);
        resetSize(): void;
        get sizeInput(): number | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
        private _volumeName?;
        get volumeName(): string;
        set volumeName(value: string);
        resetVolumeName(): void;
        get volumeNameInput(): string | undefined;
    }
    interface ScalingGroupConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#cpu AwsKxCluster#cpu}
        */
        readonly cpu?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#memory_limit AwsKxCluster#memory_limit}
        */
        readonly memoryLimit?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#memory_reservation AwsKxCluster#memory_reservation}
        */
        readonly memoryReservation: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#node_count AwsKxCluster#node_count}
        */
        readonly nodeCount: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#scaling_group_name AwsKxCluster#scaling_group_name}
        */
        readonly scalingGroupName: string;
    }
    class ScalingGroupConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ScalingGroupConfigurationProperty | undefined;
        set internalValue(value: ScalingGroupConfigurationProperty | undefined);
        private _cpu?;
        get cpu(): number;
        set cpu(value: number);
        resetCpu(): void;
        get cpuInput(): number | undefined;
        private _memoryLimit?;
        get memoryLimit(): number;
        set memoryLimit(value: number);
        resetMemoryLimit(): void;
        get memoryLimitInput(): number | undefined;
        private _memoryReservation?;
        get memoryReservation(): number;
        set memoryReservation(value: number);
        get memoryReservationInput(): number | undefined;
        private _nodeCount?;
        get nodeCount(): number;
        set nodeCount(value: number);
        get nodeCountInput(): number | undefined;
        private _scalingGroupName?;
        get scalingGroupName(): string;
        set scalingGroupName(value: string);
        get scalingGroupNameInput(): string | undefined;
    }
    interface TickerplantLogConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#tickerplant_log_volumes AwsKxCluster#tickerplant_log_volumes}
        */
        readonly tickerplantLogVolumes: string[];
    }
    class TickerplantLogConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TickerplantLogConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TickerplantLogConfigurationProperty | cdktn.IResolvable | undefined);
        private _tickerplantLogVolumes?;
        get tickerplantLogVolumes(): string[];
        set tickerplantLogVolumes(value: string[]);
        get tickerplantLogVolumesInput(): string[] | undefined;
    }
    class TickerplantLogConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: TickerplantLogConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TickerplantLogConfigurationPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#create AwsKxCluster#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#delete AwsKxCluster#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#update AwsKxCluster#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface VpcConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#ip_address_type AwsKxCluster#ip_address_type}
        */
        readonly ipAddressType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#security_group_ids AwsKxCluster#security_group_ids}
        */
        readonly securityGroupIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#subnet_ids AwsKxCluster#subnet_ids}
        */
        readonly subnetIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#vpc_id AwsKxCluster#vpc_id}
        */
        readonly vpcId: string;
    }
    class VpcConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VpcConfigurationProperty | undefined;
        set internalValue(value: VpcConfigurationProperty | undefined);
        private _ipAddressType?;
        get ipAddressType(): string;
        set ipAddressType(value: string);
        get ipAddressTypeInput(): string | undefined;
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        get subnetIdsInput(): string[] | undefined;
        private _vpcId?;
        get vpcId(): string;
        set vpcId(value: string);
        get vpcIdInput(): string | undefined;
    }
}
