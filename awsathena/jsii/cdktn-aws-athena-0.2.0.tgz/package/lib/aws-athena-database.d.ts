import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfDatabaseConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_database#bucket TfDatabase#bucket}
    */
    readonly bucket?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_database#comment TfDatabase#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_database#expected_bucket_owner TfDatabase#expected_bucket_owner}
    */
    readonly expectedBucketOwner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_database#force_destroy TfDatabase#force_destroy}
    */
    readonly forceDestroy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_database#id TfDatabase#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_database#name TfDatabase#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_database#properties TfDatabase#properties}
    */
    readonly properties?: {
        [key: string]: string;
    };
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_database#region TfDatabase#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_database#workgroup TfDatabase#workgroup}
    */
    readonly workgroup?: string;
    /**
    * acl_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_database#acl_configuration TfDatabase#acl_configuration}
    */
    readonly aclConfiguration?: TfDatabase.AclConfigurationProperty;
    /**
    * encryption_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_database#encryption_configuration TfDatabase#encryption_configuration}
    */
    readonly encryptionConfiguration?: TfDatabase.EncryptionConfigurationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_database aws_athena_database}
*/
export declare class TfDatabase extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_athena_database";
    /**
    * Generates CDKTN code for importing a TfDatabase resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfDatabase to import
    * @param importFromId The id of the existing TfDatabase that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_database#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfDatabase to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_database aws_athena_database} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfDatabaseConfig
    */
    constructor(scope: Construct, id: string, config: TfDatabaseConfig);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    resetBucket(): void;
    get bucketInput(): string | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _expectedBucketOwner?;
    get expectedBucketOwner(): string;
    set expectedBucketOwner(value: string);
    resetExpectedBucketOwner(): void;
    get expectedBucketOwnerInput(): string | undefined;
    private _forceDestroy?;
    get forceDestroy(): boolean | cdktn.IResolvable;
    set forceDestroy(value: boolean | cdktn.IResolvable);
    resetForceDestroy(): void;
    get forceDestroyInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _properties?;
    get properties(): {
        [key: string]: string;
    };
    set properties(value: {
        [key: string]: string;
    });
    resetProperties(): void;
    get propertiesInput(): {
        [key: string]: string;
    } | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _workgroup?;
    get workgroup(): string;
    set workgroup(value: string);
    resetWorkgroup(): void;
    get workgroupInput(): string | undefined;
    private _aclConfiguration;
    get aclConfiguration(): TfDatabase.AclConfigurationPropertyOutputReference;
    putAclConfiguration(value: TfDatabase.AclConfigurationProperty): void;
    resetAclConfiguration(): void;
    get aclConfigurationInput(): TfDatabase.AclConfigurationProperty | undefined;
    private _encryptionConfiguration;
    get encryptionConfiguration(): TfDatabase.EncryptionConfigurationPropertyOutputReference;
    putEncryptionConfiguration(value: TfDatabase.EncryptionConfigurationProperty): void;
    resetEncryptionConfiguration(): void;
    get encryptionConfigurationInput(): TfDatabase.EncryptionConfigurationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfDatabaseAclConfigurationPropertyToTerraform(struct?: TfDatabase.AclConfigurationPropertyOutputReference | TfDatabase.AclConfigurationProperty): any;
export declare function tfDatabaseAclConfigurationPropertyToHclTerraform(struct?: TfDatabase.AclConfigurationPropertyOutputReference | TfDatabase.AclConfigurationProperty): any;
export declare function tfDatabaseEncryptionConfigurationPropertyToTerraform(struct?: TfDatabase.EncryptionConfigurationPropertyOutputReference | TfDatabase.EncryptionConfigurationProperty): any;
export declare function tfDatabaseEncryptionConfigurationPropertyToHclTerraform(struct?: TfDatabase.EncryptionConfigurationPropertyOutputReference | TfDatabase.EncryptionConfigurationProperty): any;
export declare namespace TfDatabase {
    interface AclConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_database#s3_acl_option TfDatabase#s3_acl_option}
        */
        readonly s3AclOption: string;
    }
    class AclConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AclConfigurationProperty | undefined;
        set internalValue(value: AclConfigurationProperty | undefined);
        private _s3AclOption?;
        get s3AclOption(): string;
        set s3AclOption(value: string);
        get s3AclOptionInput(): string | undefined;
    }
    interface EncryptionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_database#encryption_option TfDatabase#encryption_option}
        */
        readonly encryptionOption: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_database#kms_key TfDatabase#kms_key}
        */
        readonly kmsKey?: string;
    }
    class EncryptionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncryptionConfigurationProperty | undefined;
        set internalValue(value: EncryptionConfigurationProperty | undefined);
        private _encryptionOption?;
        get encryptionOption(): string;
        set encryptionOption(value: string);
        get encryptionOptionInput(): string | undefined;
        private _kmsKey?;
        get kmsKey(): string;
        set kmsKey(value: string);
        resetKmsKey(): void;
        get kmsKeyInput(): string | undefined;
    }
}
