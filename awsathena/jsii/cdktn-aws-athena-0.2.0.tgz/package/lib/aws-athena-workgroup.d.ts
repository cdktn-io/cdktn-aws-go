import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfWorkgroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#description TfWorkgroup#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#force_destroy TfWorkgroup#force_destroy}
    */
    readonly forceDestroy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#id TfWorkgroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#name TfWorkgroup#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#region TfWorkgroup#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#state TfWorkgroup#state}
    */
    readonly state?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#tags TfWorkgroup#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#tags_all TfWorkgroup#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#configuration TfWorkgroup#configuration}
    */
    readonly configuration?: TfWorkgroup.ConfigurationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup aws_athena_workgroup}
*/
export declare class TfWorkgroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_athena_workgroup";
    /**
    * Generates CDKTN code for importing a TfWorkgroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfWorkgroup to import
    * @param importFromId The id of the existing TfWorkgroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfWorkgroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup aws_athena_workgroup} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfWorkgroupConfig
    */
    constructor(scope: Construct, id: string, config: TfWorkgroupConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _forceDestroy?;
    get forceDestroy(): boolean | cdktn.IResolvable;
    set forceDestroy(value: boolean | cdktn.IResolvable);
    resetForceDestroy(): void;
    get forceDestroyInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _configuration;
    get configuration(): TfWorkgroup.ConfigurationPropertyOutputReference;
    putConfiguration(value: TfWorkgroup.ConfigurationProperty): void;
    resetConfiguration(): void;
    get configurationInput(): TfWorkgroup.ConfigurationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfWorkgroupCustomerContentEncryptionConfigurationPropertyToTerraform(struct?: TfWorkgroup.CustomerContentEncryptionConfigurationPropertyOutputReference | TfWorkgroup.CustomerContentEncryptionConfigurationProperty): any;
export declare function tfWorkgroupCustomerContentEncryptionConfigurationPropertyToHclTerraform(struct?: TfWorkgroup.CustomerContentEncryptionConfigurationPropertyOutputReference | TfWorkgroup.CustomerContentEncryptionConfigurationProperty): any;
export declare function tfWorkgroupEngineVersionPropertyToTerraform(struct?: TfWorkgroup.EngineVersionPropertyOutputReference | TfWorkgroup.EngineVersionProperty): any;
export declare function tfWorkgroupEngineVersionPropertyToHclTerraform(struct?: TfWorkgroup.EngineVersionPropertyOutputReference | TfWorkgroup.EngineVersionProperty): any;
export declare function tfWorkgroupIdentityCenterConfigurationPropertyToTerraform(struct?: TfWorkgroup.IdentityCenterConfigurationPropertyOutputReference | TfWorkgroup.IdentityCenterConfigurationProperty): any;
export declare function tfWorkgroupIdentityCenterConfigurationPropertyToHclTerraform(struct?: TfWorkgroup.IdentityCenterConfigurationPropertyOutputReference | TfWorkgroup.IdentityCenterConfigurationProperty): any;
export declare function tfWorkgroupConfigurationManagedQueryResultsConfigurationEncryptionConfigurationPropertyToTerraform(struct?: TfWorkgroup.ConfigurationManagedQueryResultsConfigurationEncryptionConfigurationPropertyOutputReference | TfWorkgroup.ConfigurationManagedQueryResultsConfigurationEncryptionConfigurationProperty): any;
export declare function tfWorkgroupConfigurationManagedQueryResultsConfigurationEncryptionConfigurationPropertyToHclTerraform(struct?: TfWorkgroup.ConfigurationManagedQueryResultsConfigurationEncryptionConfigurationPropertyOutputReference | TfWorkgroup.ConfigurationManagedQueryResultsConfigurationEncryptionConfigurationProperty): any;
export declare function tfWorkgroupManagedQueryResultsConfigurationPropertyToTerraform(struct?: TfWorkgroup.ManagedQueryResultsConfigurationPropertyOutputReference | TfWorkgroup.ManagedQueryResultsConfigurationProperty): any;
export declare function tfWorkgroupManagedQueryResultsConfigurationPropertyToHclTerraform(struct?: TfWorkgroup.ManagedQueryResultsConfigurationPropertyOutputReference | TfWorkgroup.ManagedQueryResultsConfigurationProperty): any;
export declare function tfWorkgroupLogTypePropertyToTerraform(struct?: TfWorkgroup.LogTypeProperty | cdktn.IResolvable): any;
export declare function tfWorkgroupLogTypePropertyToHclTerraform(struct?: TfWorkgroup.LogTypeProperty | cdktn.IResolvable): any;
export declare function tfWorkgroupCloudWatchLoggingConfigurationPropertyToTerraform(struct?: TfWorkgroup.CloudWatchLoggingConfigurationPropertyOutputReference | TfWorkgroup.CloudWatchLoggingConfigurationProperty): any;
export declare function tfWorkgroupCloudWatchLoggingConfigurationPropertyToHclTerraform(struct?: TfWorkgroup.CloudWatchLoggingConfigurationPropertyOutputReference | TfWorkgroup.CloudWatchLoggingConfigurationProperty): any;
export declare function tfWorkgroupManagedLoggingConfigurationPropertyToTerraform(struct?: TfWorkgroup.ManagedLoggingConfigurationPropertyOutputReference | TfWorkgroup.ManagedLoggingConfigurationProperty): any;
export declare function tfWorkgroupManagedLoggingConfigurationPropertyToHclTerraform(struct?: TfWorkgroup.ManagedLoggingConfigurationPropertyOutputReference | TfWorkgroup.ManagedLoggingConfigurationProperty): any;
export declare function tfWorkgroupS3LoggingConfigurationPropertyToTerraform(struct?: TfWorkgroup.S3LoggingConfigurationPropertyOutputReference | TfWorkgroup.S3LoggingConfigurationProperty): any;
export declare function tfWorkgroupS3LoggingConfigurationPropertyToHclTerraform(struct?: TfWorkgroup.S3LoggingConfigurationPropertyOutputReference | TfWorkgroup.S3LoggingConfigurationProperty): any;
export declare function tfWorkgroupMonitoringConfigurationPropertyToTerraform(struct?: TfWorkgroup.MonitoringConfigurationPropertyOutputReference | TfWorkgroup.MonitoringConfigurationProperty): any;
export declare function tfWorkgroupMonitoringConfigurationPropertyToHclTerraform(struct?: TfWorkgroup.MonitoringConfigurationPropertyOutputReference | TfWorkgroup.MonitoringConfigurationProperty): any;
export declare function tfWorkgroupQueryResultsS3AccessGrantsConfigurationPropertyToTerraform(struct?: TfWorkgroup.QueryResultsS3AccessGrantsConfigurationPropertyOutputReference | TfWorkgroup.QueryResultsS3AccessGrantsConfigurationProperty): any;
export declare function tfWorkgroupQueryResultsS3AccessGrantsConfigurationPropertyToHclTerraform(struct?: TfWorkgroup.QueryResultsS3AccessGrantsConfigurationPropertyOutputReference | TfWorkgroup.QueryResultsS3AccessGrantsConfigurationProperty): any;
export declare function tfWorkgroupAclConfigurationPropertyToTerraform(struct?: TfWorkgroup.AclConfigurationPropertyOutputReference | TfWorkgroup.AclConfigurationProperty): any;
export declare function tfWorkgroupAclConfigurationPropertyToHclTerraform(struct?: TfWorkgroup.AclConfigurationPropertyOutputReference | TfWorkgroup.AclConfigurationProperty): any;
export declare function tfWorkgroupConfigurationResultConfigurationEncryptionConfigurationPropertyToTerraform(struct?: TfWorkgroup.ConfigurationResultConfigurationEncryptionConfigurationPropertyOutputReference | TfWorkgroup.ConfigurationResultConfigurationEncryptionConfigurationProperty): any;
export declare function tfWorkgroupConfigurationResultConfigurationEncryptionConfigurationPropertyToHclTerraform(struct?: TfWorkgroup.ConfigurationResultConfigurationEncryptionConfigurationPropertyOutputReference | TfWorkgroup.ConfigurationResultConfigurationEncryptionConfigurationProperty): any;
export declare function tfWorkgroupResultConfigurationPropertyToTerraform(struct?: TfWorkgroup.ResultConfigurationPropertyOutputReference | TfWorkgroup.ResultConfigurationProperty): any;
export declare function tfWorkgroupResultConfigurationPropertyToHclTerraform(struct?: TfWorkgroup.ResultConfigurationPropertyOutputReference | TfWorkgroup.ResultConfigurationProperty): any;
export declare function tfWorkgroupConfigurationPropertyToTerraform(struct?: TfWorkgroup.ConfigurationPropertyOutputReference | TfWorkgroup.ConfigurationProperty): any;
export declare function tfWorkgroupConfigurationPropertyToHclTerraform(struct?: TfWorkgroup.ConfigurationPropertyOutputReference | TfWorkgroup.ConfigurationProperty): any;
export declare namespace TfWorkgroup {
    interface CustomerContentEncryptionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#kms_key TfWorkgroup#kms_key}
        */
        readonly kmsKey?: string;
    }
    class CustomerContentEncryptionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CustomerContentEncryptionConfigurationProperty | undefined;
        set internalValue(value: CustomerContentEncryptionConfigurationProperty | undefined);
        private _kmsKey?;
        get kmsKey(): string;
        set kmsKey(value: string);
        resetKmsKey(): void;
        get kmsKeyInput(): string | undefined;
    }
    interface EngineVersionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#selected_engine_version TfWorkgroup#selected_engine_version}
        */
        readonly selectedEngineVersion?: string;
    }
    class EngineVersionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EngineVersionProperty | undefined;
        set internalValue(value: EngineVersionProperty | undefined);
        get effectiveEngineVersion(): string;
        private _selectedEngineVersion?;
        get selectedEngineVersion(): string;
        set selectedEngineVersion(value: string);
        resetSelectedEngineVersion(): void;
        get selectedEngineVersionInput(): string | undefined;
    }
    interface IdentityCenterConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#enable_identity_center TfWorkgroup#enable_identity_center}
        */
        readonly enableIdentityCenter?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#identity_center_instance_arn TfWorkgroup#identity_center_instance_arn}
        */
        readonly identityCenterInstanceArn?: string;
    }
    class IdentityCenterConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IdentityCenterConfigurationProperty | undefined;
        set internalValue(value: IdentityCenterConfigurationProperty | undefined);
        private _enableIdentityCenter?;
        get enableIdentityCenter(): boolean | cdktn.IResolvable;
        set enableIdentityCenter(value: boolean | cdktn.IResolvable);
        resetEnableIdentityCenter(): void;
        get enableIdentityCenterInput(): boolean | cdktn.IResolvable | undefined;
        private _identityCenterInstanceArn?;
        get identityCenterInstanceArn(): string;
        set identityCenterInstanceArn(value: string);
        resetIdentityCenterInstanceArn(): void;
        get identityCenterInstanceArnInput(): string | undefined;
    }
    interface ConfigurationManagedQueryResultsConfigurationEncryptionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#kms_key TfWorkgroup#kms_key}
        */
        readonly kmsKey?: string;
    }
    class ConfigurationManagedQueryResultsConfigurationEncryptionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConfigurationManagedQueryResultsConfigurationEncryptionConfigurationProperty | undefined;
        set internalValue(value: ConfigurationManagedQueryResultsConfigurationEncryptionConfigurationProperty | undefined);
        private _kmsKey?;
        get kmsKey(): string;
        set kmsKey(value: string);
        resetKmsKey(): void;
        get kmsKeyInput(): string | undefined;
    }
    interface ManagedQueryResultsConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#enabled TfWorkgroup#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * encryption_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#encryption_configuration TfWorkgroup#encryption_configuration}
        */
        readonly encryptionConfiguration?: ConfigurationManagedQueryResultsConfigurationEncryptionConfigurationProperty;
    }
    class ManagedQueryResultsConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ManagedQueryResultsConfigurationProperty | undefined;
        set internalValue(value: ManagedQueryResultsConfigurationProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _encryptionConfiguration;
        get encryptionConfiguration(): ConfigurationManagedQueryResultsConfigurationEncryptionConfigurationPropertyOutputReference;
        putEncryptionConfiguration(value: ConfigurationManagedQueryResultsConfigurationEncryptionConfigurationProperty): void;
        resetEncryptionConfiguration(): void;
        get encryptionConfigurationInput(): ConfigurationManagedQueryResultsConfigurationEncryptionConfigurationProperty | undefined;
    }
    interface LogTypeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#key TfWorkgroup#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#values TfWorkgroup#values}
        */
        readonly values: string[];
    }
    class LogTypePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LogTypeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LogTypeProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class LogTypePropertyList extends cdktn.ComplexList {
        internalValue?: LogTypeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LogTypePropertyOutputReference;
    }
    interface CloudWatchLoggingConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#enabled TfWorkgroup#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#log_group TfWorkgroup#log_group}
        */
        readonly logGroup?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#log_stream_name_prefix TfWorkgroup#log_stream_name_prefix}
        */
        readonly logStreamNamePrefix?: string;
        /**
        * log_type block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#log_type TfWorkgroup#log_type}
        */
        readonly logType?: LogTypeProperty[] | cdktn.IResolvable;
    }
    class CloudWatchLoggingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CloudWatchLoggingConfigurationProperty | undefined;
        set internalValue(value: CloudWatchLoggingConfigurationProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _logGroup?;
        get logGroup(): string;
        set logGroup(value: string);
        resetLogGroup(): void;
        get logGroupInput(): string | undefined;
        private _logStreamNamePrefix?;
        get logStreamNamePrefix(): string;
        set logStreamNamePrefix(value: string);
        resetLogStreamNamePrefix(): void;
        get logStreamNamePrefixInput(): string | undefined;
        private _logType;
        get logType(): LogTypePropertyList;
        putLogType(value: LogTypeProperty[] | cdktn.IResolvable): void;
        resetLogType(): void;
        get logTypeInput(): cdktn.IResolvable | LogTypeProperty[] | undefined;
    }
    interface ManagedLoggingConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#enabled TfWorkgroup#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#kms_key TfWorkgroup#kms_key}
        */
        readonly kmsKey?: string;
    }
    class ManagedLoggingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ManagedLoggingConfigurationProperty | undefined;
        set internalValue(value: ManagedLoggingConfigurationProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _kmsKey?;
        get kmsKey(): string;
        set kmsKey(value: string);
        resetKmsKey(): void;
        get kmsKeyInput(): string | undefined;
    }
    interface S3LoggingConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#enabled TfWorkgroup#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#kms_key TfWorkgroup#kms_key}
        */
        readonly kmsKey?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#log_location TfWorkgroup#log_location}
        */
        readonly logLocation?: string;
    }
    class S3LoggingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3LoggingConfigurationProperty | undefined;
        set internalValue(value: S3LoggingConfigurationProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _kmsKey?;
        get kmsKey(): string;
        set kmsKey(value: string);
        resetKmsKey(): void;
        get kmsKeyInput(): string | undefined;
        private _logLocation?;
        get logLocation(): string;
        set logLocation(value: string);
        resetLogLocation(): void;
        get logLocationInput(): string | undefined;
    }
    interface MonitoringConfigurationProperty {
        /**
        * cloud_watch_logging_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#cloud_watch_logging_configuration TfWorkgroup#cloud_watch_logging_configuration}
        */
        readonly cloudWatchLoggingConfiguration?: CloudWatchLoggingConfigurationProperty;
        /**
        * managed_logging_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#managed_logging_configuration TfWorkgroup#managed_logging_configuration}
        */
        readonly managedLoggingConfiguration?: ManagedLoggingConfigurationProperty;
        /**
        * s3_logging_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#s3_logging_configuration TfWorkgroup#s3_logging_configuration}
        */
        readonly s3LoggingConfiguration?: S3LoggingConfigurationProperty;
    }
    class MonitoringConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MonitoringConfigurationProperty | undefined;
        set internalValue(value: MonitoringConfigurationProperty | undefined);
        private _cloudWatchLoggingConfiguration;
        get cloudWatchLoggingConfiguration(): CloudWatchLoggingConfigurationPropertyOutputReference;
        putCloudWatchLoggingConfiguration(value: CloudWatchLoggingConfigurationProperty): void;
        resetCloudWatchLoggingConfiguration(): void;
        get cloudWatchLoggingConfigurationInput(): CloudWatchLoggingConfigurationProperty | undefined;
        private _managedLoggingConfiguration;
        get managedLoggingConfiguration(): ManagedLoggingConfigurationPropertyOutputReference;
        putManagedLoggingConfiguration(value: ManagedLoggingConfigurationProperty): void;
        resetManagedLoggingConfiguration(): void;
        get managedLoggingConfigurationInput(): ManagedLoggingConfigurationProperty | undefined;
        private _s3LoggingConfiguration;
        get s3LoggingConfiguration(): S3LoggingConfigurationPropertyOutputReference;
        putS3LoggingConfiguration(value: S3LoggingConfigurationProperty): void;
        resetS3LoggingConfiguration(): void;
        get s3LoggingConfigurationInput(): S3LoggingConfigurationProperty | undefined;
    }
    interface QueryResultsS3AccessGrantsConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#authentication_type TfWorkgroup#authentication_type}
        */
        readonly authenticationType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#create_user_level_prefix TfWorkgroup#create_user_level_prefix}
        */
        readonly createUserLevelPrefix?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#enable_s3_access_grants TfWorkgroup#enable_s3_access_grants}
        */
        readonly enableS3AccessGrants: boolean | cdktn.IResolvable;
    }
    class QueryResultsS3AccessGrantsConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): QueryResultsS3AccessGrantsConfigurationProperty | undefined;
        set internalValue(value: QueryResultsS3AccessGrantsConfigurationProperty | undefined);
        private _authenticationType?;
        get authenticationType(): string;
        set authenticationType(value: string);
        get authenticationTypeInput(): string | undefined;
        private _createUserLevelPrefix?;
        get createUserLevelPrefix(): boolean | cdktn.IResolvable;
        set createUserLevelPrefix(value: boolean | cdktn.IResolvable);
        resetCreateUserLevelPrefix(): void;
        get createUserLevelPrefixInput(): boolean | cdktn.IResolvable | undefined;
        private _enableS3AccessGrants?;
        get enableS3AccessGrants(): boolean | cdktn.IResolvable;
        set enableS3AccessGrants(value: boolean | cdktn.IResolvable);
        get enableS3AccessGrantsInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface AclConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#s3_acl_option TfWorkgroup#s3_acl_option}
        */
        readonly s3AclOption: string;
    }
    class AclConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AclConfigurationProperty | undefined;
        set internalValue(value: AclConfigurationProperty | undefined);
        private _s3AclOption?;
        get s3AclOption(): string;
        set s3AclOption(value: string);
        get s3AclOptionInput(): string | undefined;
    }
    interface ConfigurationResultConfigurationEncryptionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#encryption_option TfWorkgroup#encryption_option}
        */
        readonly encryptionOption?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#kms_key_arn TfWorkgroup#kms_key_arn}
        */
        readonly kmsKeyArn?: string;
    }
    class ConfigurationResultConfigurationEncryptionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConfigurationResultConfigurationEncryptionConfigurationProperty | undefined;
        set internalValue(value: ConfigurationResultConfigurationEncryptionConfigurationProperty | undefined);
        private _encryptionOption?;
        get encryptionOption(): string;
        set encryptionOption(value: string);
        resetEncryptionOption(): void;
        get encryptionOptionInput(): string | undefined;
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        resetKmsKeyArn(): void;
        get kmsKeyArnInput(): string | undefined;
    }
    interface ResultConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#expected_bucket_owner TfWorkgroup#expected_bucket_owner}
        */
        readonly expectedBucketOwner?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#output_location TfWorkgroup#output_location}
        */
        readonly outputLocation?: string;
        /**
        * acl_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#acl_configuration TfWorkgroup#acl_configuration}
        */
        readonly aclConfiguration?: AclConfigurationProperty;
        /**
        * encryption_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#encryption_configuration TfWorkgroup#encryption_configuration}
        */
        readonly encryptionConfiguration?: ConfigurationResultConfigurationEncryptionConfigurationProperty;
    }
    class ResultConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ResultConfigurationProperty | undefined;
        set internalValue(value: ResultConfigurationProperty | undefined);
        private _expectedBucketOwner?;
        get expectedBucketOwner(): string;
        set expectedBucketOwner(value: string);
        resetExpectedBucketOwner(): void;
        get expectedBucketOwnerInput(): string | undefined;
        private _outputLocation?;
        get outputLocation(): string;
        set outputLocation(value: string);
        resetOutputLocation(): void;
        get outputLocationInput(): string | undefined;
        private _aclConfiguration;
        get aclConfiguration(): AclConfigurationPropertyOutputReference;
        putAclConfiguration(value: AclConfigurationProperty): void;
        resetAclConfiguration(): void;
        get aclConfigurationInput(): AclConfigurationProperty | undefined;
        private _encryptionConfiguration;
        get encryptionConfiguration(): ConfigurationResultConfigurationEncryptionConfigurationPropertyOutputReference;
        putEncryptionConfiguration(value: ConfigurationResultConfigurationEncryptionConfigurationProperty): void;
        resetEncryptionConfiguration(): void;
        get encryptionConfigurationInput(): ConfigurationResultConfigurationEncryptionConfigurationProperty | undefined;
    }
    interface ConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#bytes_scanned_cutoff_per_query TfWorkgroup#bytes_scanned_cutoff_per_query}
        */
        readonly bytesScannedCutoffPerQuery?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#enable_minimum_encryption_configuration TfWorkgroup#enable_minimum_encryption_configuration}
        */
        readonly enableMinimumEncryptionConfiguration?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#enforce_workgroup_configuration TfWorkgroup#enforce_workgroup_configuration}
        */
        readonly enforceWorkgroupConfiguration?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#execution_role TfWorkgroup#execution_role}
        */
        readonly executionRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#publish_cloudwatch_metrics_enabled TfWorkgroup#publish_cloudwatch_metrics_enabled}
        */
        readonly publishCloudwatchMetricsEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#requester_pays_enabled TfWorkgroup#requester_pays_enabled}
        */
        readonly requesterPaysEnabled?: boolean | cdktn.IResolvable;
        /**
        * customer_content_encryption_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#customer_content_encryption_configuration TfWorkgroup#customer_content_encryption_configuration}
        */
        readonly customerContentEncryptionConfiguration?: CustomerContentEncryptionConfigurationProperty;
        /**
        * engine_version block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#engine_version TfWorkgroup#engine_version}
        */
        readonly engineVersion?: EngineVersionProperty;
        /**
        * identity_center_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#identity_center_configuration TfWorkgroup#identity_center_configuration}
        */
        readonly identityCenterConfiguration?: IdentityCenterConfigurationProperty;
        /**
        * managed_query_results_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#managed_query_results_configuration TfWorkgroup#managed_query_results_configuration}
        */
        readonly managedQueryResultsConfiguration?: ManagedQueryResultsConfigurationProperty;
        /**
        * monitoring_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#monitoring_configuration TfWorkgroup#monitoring_configuration}
        */
        readonly monitoringConfiguration?: MonitoringConfigurationProperty;
        /**
        * query_results_s3_access_grants_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#query_results_s3_access_grants_configuration TfWorkgroup#query_results_s3_access_grants_configuration}
        */
        readonly queryResultsS3AccessGrantsConfiguration?: QueryResultsS3AccessGrantsConfigurationProperty;
        /**
        * result_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#result_configuration TfWorkgroup#result_configuration}
        */
        readonly resultConfiguration?: ResultConfigurationProperty;
    }
    class ConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConfigurationProperty | undefined;
        set internalValue(value: ConfigurationProperty | undefined);
        private _bytesScannedCutoffPerQuery?;
        get bytesScannedCutoffPerQuery(): number;
        set bytesScannedCutoffPerQuery(value: number);
        resetBytesScannedCutoffPerQuery(): void;
        get bytesScannedCutoffPerQueryInput(): number | undefined;
        private _enableMinimumEncryptionConfiguration?;
        get enableMinimumEncryptionConfiguration(): boolean | cdktn.IResolvable;
        set enableMinimumEncryptionConfiguration(value: boolean | cdktn.IResolvable);
        resetEnableMinimumEncryptionConfiguration(): void;
        get enableMinimumEncryptionConfigurationInput(): boolean | cdktn.IResolvable | undefined;
        private _enforceWorkgroupConfiguration?;
        get enforceWorkgroupConfiguration(): boolean | cdktn.IResolvable;
        set enforceWorkgroupConfiguration(value: boolean | cdktn.IResolvable);
        resetEnforceWorkgroupConfiguration(): void;
        get enforceWorkgroupConfigurationInput(): boolean | cdktn.IResolvable | undefined;
        private _executionRole?;
        get executionRole(): string;
        set executionRole(value: string);
        resetExecutionRole(): void;
        get executionRoleInput(): string | undefined;
        private _publishCloudwatchMetricsEnabled?;
        get publishCloudwatchMetricsEnabled(): boolean | cdktn.IResolvable;
        set publishCloudwatchMetricsEnabled(value: boolean | cdktn.IResolvable);
        resetPublishCloudwatchMetricsEnabled(): void;
        get publishCloudwatchMetricsEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _requesterPaysEnabled?;
        get requesterPaysEnabled(): boolean | cdktn.IResolvable;
        set requesterPaysEnabled(value: boolean | cdktn.IResolvable);
        resetRequesterPaysEnabled(): void;
        get requesterPaysEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _customerContentEncryptionConfiguration;
        get customerContentEncryptionConfiguration(): CustomerContentEncryptionConfigurationPropertyOutputReference;
        putCustomerContentEncryptionConfiguration(value: CustomerContentEncryptionConfigurationProperty): void;
        resetCustomerContentEncryptionConfiguration(): void;
        get customerContentEncryptionConfigurationInput(): CustomerContentEncryptionConfigurationProperty | undefined;
        private _engineVersion;
        get engineVersion(): EngineVersionPropertyOutputReference;
        putEngineVersion(value: EngineVersionProperty): void;
        resetEngineVersion(): void;
        get engineVersionInput(): EngineVersionProperty | undefined;
        private _identityCenterConfiguration;
        get identityCenterConfiguration(): IdentityCenterConfigurationPropertyOutputReference;
        putIdentityCenterConfiguration(value: IdentityCenterConfigurationProperty): void;
        resetIdentityCenterConfiguration(): void;
        get identityCenterConfigurationInput(): IdentityCenterConfigurationProperty | undefined;
        private _managedQueryResultsConfiguration;
        get managedQueryResultsConfiguration(): ManagedQueryResultsConfigurationPropertyOutputReference;
        putManagedQueryResultsConfiguration(value: ManagedQueryResultsConfigurationProperty): void;
        resetManagedQueryResultsConfiguration(): void;
        get managedQueryResultsConfigurationInput(): ManagedQueryResultsConfigurationProperty | undefined;
        private _monitoringConfiguration;
        get monitoringConfiguration(): MonitoringConfigurationPropertyOutputReference;
        putMonitoringConfiguration(value: MonitoringConfigurationProperty): void;
        resetMonitoringConfiguration(): void;
        get monitoringConfigurationInput(): MonitoringConfigurationProperty | undefined;
        private _queryResultsS3AccessGrantsConfiguration;
        get queryResultsS3AccessGrantsConfiguration(): QueryResultsS3AccessGrantsConfigurationPropertyOutputReference;
        putQueryResultsS3AccessGrantsConfiguration(value: QueryResultsS3AccessGrantsConfigurationProperty): void;
        resetQueryResultsS3AccessGrantsConfiguration(): void;
        get queryResultsS3AccessGrantsConfigurationInput(): QueryResultsS3AccessGrantsConfigurationProperty | undefined;
        private _resultConfiguration;
        get resultConfiguration(): ResultConfigurationPropertyOutputReference;
        putResultConfiguration(value: ResultConfigurationProperty): void;
        resetResultConfiguration(): void;
        get resultConfigurationInput(): ResultConfigurationProperty | undefined;
    }
}
