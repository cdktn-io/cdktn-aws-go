import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsResiliencehubv2InputSourceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_input_source#region AwsResiliencehubv2InputSource#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_input_source#service_arn AwsResiliencehubv2InputSource#service_arn}
    */
    readonly serviceArn: string;
    /**
    * resource_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_input_source#resource_configuration AwsResiliencehubv2InputSource#resource_configuration}
    */
    readonly resourceConfiguration?: AwsResiliencehubv2InputSource.ResourceConfigurationProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_input_source aws_resiliencehubv2_input_source}
*/
export declare class AwsResiliencehubv2InputSource extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_resiliencehubv2_input_source";
    /**
    * Generates CDKTN code for importing a AwsResiliencehubv2InputSource resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsResiliencehubv2InputSource to import
    * @param importFromId The id of the existing AwsResiliencehubv2InputSource that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_input_source#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsResiliencehubv2InputSource to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_input_source aws_resiliencehubv2_input_source} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsResiliencehubv2InputSourceConfig
    */
    constructor(scope: Construct, id: string, config: AwsResiliencehubv2InputSourceConfig);
    get inputSourceId(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _serviceArn?;
    get serviceArn(): string;
    set serviceArn(value: string);
    get serviceArnInput(): string | undefined;
    private _resourceConfiguration;
    get resourceConfiguration(): AwsResiliencehubv2InputSource.ResourceConfigurationPropertyList;
    putResourceConfiguration(value: AwsResiliencehubv2InputSource.ResourceConfigurationProperty[] | cdktn.IResolvable): void;
    resetResourceConfiguration(): void;
    get resourceConfigurationInput(): cdktn.IResolvable | AwsResiliencehubv2InputSource.ResourceConfigurationProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsResiliencehubv2InputSourceEksPropertyToTerraform(struct?: AwsResiliencehubv2InputSource.EksProperty | cdktn.IResolvable): any;
export declare function awsResiliencehubv2InputSourceEksPropertyToHclTerraform(struct?: AwsResiliencehubv2InputSource.EksProperty | cdktn.IResolvable): any;
export declare function awsResiliencehubv2InputSourceResourceTagPropertyToTerraform(struct?: AwsResiliencehubv2InputSource.ResourceTagProperty | cdktn.IResolvable): any;
export declare function awsResiliencehubv2InputSourceResourceTagPropertyToHclTerraform(struct?: AwsResiliencehubv2InputSource.ResourceTagProperty | cdktn.IResolvable): any;
export declare function awsResiliencehubv2InputSourceResourceConfigurationPropertyToTerraform(struct?: AwsResiliencehubv2InputSource.ResourceConfigurationProperty | cdktn.IResolvable): any;
export declare function awsResiliencehubv2InputSourceResourceConfigurationPropertyToHclTerraform(struct?: AwsResiliencehubv2InputSource.ResourceConfigurationProperty | cdktn.IResolvable): any;
export declare namespace AwsResiliencehubv2InputSource {
    interface EksProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_input_source#cluster_arn AwsResiliencehubv2InputSource#cluster_arn}
        */
        readonly clusterArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_input_source#namespaces AwsResiliencehubv2InputSource#namespaces}
        */
        readonly namespaces: string[];
    }
    class EksPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EksProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EksProperty | cdktn.IResolvable | undefined);
        private _clusterArn?;
        get clusterArn(): string;
        set clusterArn(value: string);
        get clusterArnInput(): string | undefined;
        private _namespaces?;
        get namespaces(): string[];
        set namespaces(value: string[]);
        get namespacesInput(): string[] | undefined;
    }
    class EksPropertyList extends cdktn.ComplexList {
        internalValue?: EksProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EksPropertyOutputReference;
    }
    interface ResourceTagProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_input_source#key AwsResiliencehubv2InputSource#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_input_source#values AwsResiliencehubv2InputSource#values}
        */
        readonly values: string[];
    }
    class ResourceTagPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceTagProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceTagProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class ResourceTagPropertyList extends cdktn.ComplexList {
        internalValue?: ResourceTagProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceTagPropertyOutputReference;
    }
    interface ResourceConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_input_source#cfn_stack_arn AwsResiliencehubv2InputSource#cfn_stack_arn}
        */
        readonly cfnStackArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_input_source#design_file_s3_url AwsResiliencehubv2InputSource#design_file_s3_url}
        */
        readonly designFileS3Url?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_input_source#tf_state_file_url AwsResiliencehubv2InputSource#tf_state_file_url}
        */
        readonly tfStateFileUrl?: string;
        /**
        * eks block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_input_source#eks AwsResiliencehubv2InputSource#eks}
        */
        readonly eks?: EksProperty[] | cdktn.IResolvable;
        /**
        * resource_tag block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_input_source#resource_tag AwsResiliencehubv2InputSource#resource_tag}
        */
        readonly resourceTag?: ResourceTagProperty[] | cdktn.IResolvable;
    }
    class ResourceConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceConfigurationProperty | cdktn.IResolvable | undefined);
        private _cfnStackArn?;
        get cfnStackArn(): string;
        set cfnStackArn(value: string);
        resetCfnStackArn(): void;
        get cfnStackArnInput(): string | undefined;
        private _designFileS3Url?;
        get designFileS3Url(): string;
        set designFileS3Url(value: string);
        resetDesignFileS3Url(): void;
        get designFileS3UrlInput(): string | undefined;
        private _tfStateFileUrl?;
        get tfStateFileUrl(): string;
        set tfStateFileUrl(value: string);
        resetTfStateFileUrl(): void;
        get tfStateFileUrlInput(): string | undefined;
        private _eks;
        get eks(): EksPropertyList;
        putEks(value: EksProperty[] | cdktn.IResolvable): void;
        resetEks(): void;
        get eksInput(): cdktn.IResolvable | EksProperty[] | undefined;
        private _resourceTag;
        get resourceTag(): ResourceTagPropertyList;
        putResourceTag(value: ResourceTagProperty[] | cdktn.IResolvable): void;
        resetResourceTag(): void;
        get resourceTagInput(): cdktn.IResolvable | ResourceTagProperty[] | undefined;
    }
    class ResourceConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: ResourceConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceConfigurationPropertyOutputReference;
    }
}
