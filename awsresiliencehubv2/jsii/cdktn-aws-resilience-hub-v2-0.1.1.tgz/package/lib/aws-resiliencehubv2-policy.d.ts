import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsResiliencehubv2PolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#description AwsResiliencehubv2Policy#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#kms_key_id AwsResiliencehubv2Policy#kms_key_id}
    */
    readonly kmsKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#name AwsResiliencehubv2Policy#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#region AwsResiliencehubv2Policy#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#tags AwsResiliencehubv2Policy#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * availability_slo block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#availability_slo AwsResiliencehubv2Policy#availability_slo}
    */
    readonly availabilitySlo?: AwsResiliencehubv2Policy.AvailabilitySloProperty[] | cdktn.IResolvable;
    /**
    * data_recovery block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#data_recovery AwsResiliencehubv2Policy#data_recovery}
    */
    readonly dataRecovery?: AwsResiliencehubv2Policy.DataRecoveryProperty[] | cdktn.IResolvable;
    /**
    * multi_az block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#multi_az AwsResiliencehubv2Policy#multi_az}
    */
    readonly multiAz?: AwsResiliencehubv2Policy.MultiAzProperty[] | cdktn.IResolvable;
    /**
    * multi_region block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#multi_region AwsResiliencehubv2Policy#multi_region}
    */
    readonly multiRegion?: AwsResiliencehubv2Policy.MultiRegionProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy aws_resiliencehubv2_policy}
*/
export declare class AwsResiliencehubv2Policy extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_resiliencehubv2_policy";
    /**
    * Generates CDKTN code for importing a AwsResiliencehubv2Policy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsResiliencehubv2Policy to import
    * @param importFromId The id of the existing AwsResiliencehubv2Policy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsResiliencehubv2Policy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy aws_resiliencehubv2_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsResiliencehubv2PolicyConfig
    */
    constructor(scope: Construct, id: string, config: AwsResiliencehubv2PolicyConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _kmsKeyId?;
    get kmsKeyId(): string;
    set kmsKeyId(value: string);
    resetKmsKeyId(): void;
    get kmsKeyIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _availabilitySlo;
    get availabilitySlo(): AwsResiliencehubv2Policy.AvailabilitySloPropertyList;
    putAvailabilitySlo(value: AwsResiliencehubv2Policy.AvailabilitySloProperty[] | cdktn.IResolvable): void;
    resetAvailabilitySlo(): void;
    get availabilitySloInput(): cdktn.IResolvable | AwsResiliencehubv2Policy.AvailabilitySloProperty[] | undefined;
    private _dataRecovery;
    get dataRecovery(): AwsResiliencehubv2Policy.DataRecoveryPropertyList;
    putDataRecovery(value: AwsResiliencehubv2Policy.DataRecoveryProperty[] | cdktn.IResolvable): void;
    resetDataRecovery(): void;
    get dataRecoveryInput(): cdktn.IResolvable | AwsResiliencehubv2Policy.DataRecoveryProperty[] | undefined;
    private _multiAz;
    get multiAz(): AwsResiliencehubv2Policy.MultiAzPropertyList;
    putMultiAz(value: AwsResiliencehubv2Policy.MultiAzProperty[] | cdktn.IResolvable): void;
    resetMultiAz(): void;
    get multiAzInput(): cdktn.IResolvable | AwsResiliencehubv2Policy.MultiAzProperty[] | undefined;
    private _multiRegion;
    get multiRegion(): AwsResiliencehubv2Policy.MultiRegionPropertyList;
    putMultiRegion(value: AwsResiliencehubv2Policy.MultiRegionProperty[] | cdktn.IResolvable): void;
    resetMultiRegion(): void;
    get multiRegionInput(): cdktn.IResolvable | AwsResiliencehubv2Policy.MultiRegionProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsResiliencehubv2PolicyAvailabilitySloPropertyToTerraform(struct?: AwsResiliencehubv2Policy.AvailabilitySloProperty | cdktn.IResolvable): any;
export declare function awsResiliencehubv2PolicyAvailabilitySloPropertyToHclTerraform(struct?: AwsResiliencehubv2Policy.AvailabilitySloProperty | cdktn.IResolvable): any;
export declare function awsResiliencehubv2PolicyDataRecoveryPropertyToTerraform(struct?: AwsResiliencehubv2Policy.DataRecoveryProperty | cdktn.IResolvable): any;
export declare function awsResiliencehubv2PolicyDataRecoveryPropertyToHclTerraform(struct?: AwsResiliencehubv2Policy.DataRecoveryProperty | cdktn.IResolvable): any;
export declare function awsResiliencehubv2PolicyMultiAzPropertyToTerraform(struct?: AwsResiliencehubv2Policy.MultiAzProperty | cdktn.IResolvable): any;
export declare function awsResiliencehubv2PolicyMultiAzPropertyToHclTerraform(struct?: AwsResiliencehubv2Policy.MultiAzProperty | cdktn.IResolvable): any;
export declare function awsResiliencehubv2PolicyMultiRegionPropertyToTerraform(struct?: AwsResiliencehubv2Policy.MultiRegionProperty | cdktn.IResolvable): any;
export declare function awsResiliencehubv2PolicyMultiRegionPropertyToHclTerraform(struct?: AwsResiliencehubv2Policy.MultiRegionProperty | cdktn.IResolvable): any;
export declare namespace AwsResiliencehubv2Policy {
    interface AvailabilitySloProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#target AwsResiliencehubv2Policy#target}
        */
        readonly target: number;
    }
    class AvailabilitySloPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AvailabilitySloProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AvailabilitySloProperty | cdktn.IResolvable | undefined);
        private _target?;
        get target(): number;
        set target(value: number);
        get targetInput(): number | undefined;
    }
    class AvailabilitySloPropertyList extends cdktn.ComplexList {
        internalValue?: AvailabilitySloProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AvailabilitySloPropertyOutputReference;
    }
    interface DataRecoveryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#time_between_backups_in_minutes AwsResiliencehubv2Policy#time_between_backups_in_minutes}
        */
        readonly timeBetweenBackupsInMinutes: number;
    }
    class DataRecoveryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataRecoveryProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DataRecoveryProperty | cdktn.IResolvable | undefined);
        private _timeBetweenBackupsInMinutes?;
        get timeBetweenBackupsInMinutes(): number;
        set timeBetweenBackupsInMinutes(value: number);
        get timeBetweenBackupsInMinutesInput(): number | undefined;
    }
    class DataRecoveryPropertyList extends cdktn.ComplexList {
        internalValue?: DataRecoveryProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataRecoveryPropertyOutputReference;
    }
    interface MultiAzProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#disaster_recovery_approach AwsResiliencehubv2Policy#disaster_recovery_approach}
        */
        readonly disasterRecoveryApproach: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#rpo_in_minutes AwsResiliencehubv2Policy#rpo_in_minutes}
        */
        readonly rpoInMinutes?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#rto_in_minutes AwsResiliencehubv2Policy#rto_in_minutes}
        */
        readonly rtoInMinutes?: number;
    }
    class MultiAzPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MultiAzProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MultiAzProperty | cdktn.IResolvable | undefined);
        private _disasterRecoveryApproach?;
        get disasterRecoveryApproach(): string;
        set disasterRecoveryApproach(value: string);
        get disasterRecoveryApproachInput(): string | undefined;
        private _rpoInMinutes?;
        get rpoInMinutes(): number;
        set rpoInMinutes(value: number);
        resetRpoInMinutes(): void;
        get rpoInMinutesInput(): number | undefined;
        private _rtoInMinutes?;
        get rtoInMinutes(): number;
        set rtoInMinutes(value: number);
        resetRtoInMinutes(): void;
        get rtoInMinutesInput(): number | undefined;
    }
    class MultiAzPropertyList extends cdktn.ComplexList {
        internalValue?: MultiAzProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MultiAzPropertyOutputReference;
    }
    interface MultiRegionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#disaster_recovery_approach AwsResiliencehubv2Policy#disaster_recovery_approach}
        */
        readonly disasterRecoveryApproach: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#rpo_in_minutes AwsResiliencehubv2Policy#rpo_in_minutes}
        */
        readonly rpoInMinutes?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#rto_in_minutes AwsResiliencehubv2Policy#rto_in_minutes}
        */
        readonly rtoInMinutes?: number;
    }
    class MultiRegionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MultiRegionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MultiRegionProperty | cdktn.IResolvable | undefined);
        private _disasterRecoveryApproach?;
        get disasterRecoveryApproach(): string;
        set disasterRecoveryApproach(value: string);
        get disasterRecoveryApproachInput(): string | undefined;
        private _rpoInMinutes?;
        get rpoInMinutes(): number;
        set rpoInMinutes(value: number);
        resetRpoInMinutes(): void;
        get rpoInMinutesInput(): number | undefined;
        private _rtoInMinutes?;
        get rtoInMinutes(): number;
        set rtoInMinutes(value: number);
        resetRtoInMinutes(): void;
        get rtoInMinutesInput(): number | undefined;
    }
    class MultiRegionPropertyList extends cdktn.ComplexList {
        internalValue?: MultiRegionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MultiRegionPropertyOutputReference;
    }
}
