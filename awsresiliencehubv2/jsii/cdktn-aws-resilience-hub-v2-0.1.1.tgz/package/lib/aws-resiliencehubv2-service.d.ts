import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsResiliencehubv2ServiceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_service#dependency_discovery AwsResiliencehubv2Service#dependency_discovery}
    */
    readonly dependencyDiscovery?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_service#description AwsResiliencehubv2Service#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_service#kms_key_id AwsResiliencehubv2Service#kms_key_id}
    */
    readonly kmsKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_service#name AwsResiliencehubv2Service#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_service#policy_arn AwsResiliencehubv2Service#policy_arn}
    */
    readonly policyArn?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_service#region AwsResiliencehubv2Service#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_service#regions AwsResiliencehubv2Service#regions}
    */
    readonly regions: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_service#tags AwsResiliencehubv2Service#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * associated_system block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_service#associated_system AwsResiliencehubv2Service#associated_system}
    */
    readonly associatedSystem?: AwsResiliencehubv2Service.AssociatedSystemProperty[] | cdktn.IResolvable;
    /**
    * permission_model block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_service#permission_model AwsResiliencehubv2Service#permission_model}
    */
    readonly permissionModel?: AwsResiliencehubv2Service.PermissionModelProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_service aws_resiliencehubv2_service}
*/
export declare class AwsResiliencehubv2Service extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_resiliencehubv2_service";
    /**
    * Generates CDKTN code for importing a AwsResiliencehubv2Service resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsResiliencehubv2Service to import
    * @param importFromId The id of the existing AwsResiliencehubv2Service that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_service#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsResiliencehubv2Service to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_service aws_resiliencehubv2_service} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsResiliencehubv2ServiceConfig
    */
    constructor(scope: Construct, id: string, config: AwsResiliencehubv2ServiceConfig);
    get arn(): string;
    private _dependencyDiscovery?;
    get dependencyDiscovery(): string;
    set dependencyDiscovery(value: string);
    resetDependencyDiscovery(): void;
    get dependencyDiscoveryInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _kmsKeyId?;
    get kmsKeyId(): string;
    set kmsKeyId(value: string);
    resetKmsKeyId(): void;
    get kmsKeyIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _policyArn?;
    get policyArn(): string;
    set policyArn(value: string);
    resetPolicyArn(): void;
    get policyArnInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _regions?;
    get regions(): string[];
    set regions(value: string[]);
    get regionsInput(): string[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _associatedSystem;
    get associatedSystem(): AwsResiliencehubv2Service.AssociatedSystemPropertyList;
    putAssociatedSystem(value: AwsResiliencehubv2Service.AssociatedSystemProperty[] | cdktn.IResolvable): void;
    resetAssociatedSystem(): void;
    get associatedSystemInput(): cdktn.IResolvable | AwsResiliencehubv2Service.AssociatedSystemProperty[] | undefined;
    private _permissionModel;
    get permissionModel(): AwsResiliencehubv2Service.PermissionModelPropertyList;
    putPermissionModel(value: AwsResiliencehubv2Service.PermissionModelProperty[] | cdktn.IResolvable): void;
    resetPermissionModel(): void;
    get permissionModelInput(): cdktn.IResolvable | AwsResiliencehubv2Service.PermissionModelProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsResiliencehubv2ServiceAssociatedSystemPropertyToTerraform(struct?: AwsResiliencehubv2Service.AssociatedSystemProperty | cdktn.IResolvable): any;
export declare function awsResiliencehubv2ServiceAssociatedSystemPropertyToHclTerraform(struct?: AwsResiliencehubv2Service.AssociatedSystemProperty | cdktn.IResolvable): any;
export declare function awsResiliencehubv2ServiceCrossAccountRolePropertyToTerraform(struct?: AwsResiliencehubv2Service.CrossAccountRoleProperty | cdktn.IResolvable): any;
export declare function awsResiliencehubv2ServiceCrossAccountRolePropertyToHclTerraform(struct?: AwsResiliencehubv2Service.CrossAccountRoleProperty | cdktn.IResolvable): any;
export declare function awsResiliencehubv2ServicePermissionModelPropertyToTerraform(struct?: AwsResiliencehubv2Service.PermissionModelProperty | cdktn.IResolvable): any;
export declare function awsResiliencehubv2ServicePermissionModelPropertyToHclTerraform(struct?: AwsResiliencehubv2Service.PermissionModelProperty | cdktn.IResolvable): any;
export declare namespace AwsResiliencehubv2Service {
    interface AssociatedSystemProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_service#system_arn AwsResiliencehubv2Service#system_arn}
        */
        readonly systemArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_service#user_journey_ids AwsResiliencehubv2Service#user_journey_ids}
        */
        readonly userJourneyIds?: string[];
    }
    class AssociatedSystemPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AssociatedSystemProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AssociatedSystemProperty | cdktn.IResolvable | undefined);
        private _systemArn?;
        get systemArn(): string;
        set systemArn(value: string);
        get systemArnInput(): string | undefined;
        private _userJourneyIds?;
        get userJourneyIds(): string[];
        set userJourneyIds(value: string[]);
        resetUserJourneyIds(): void;
        get userJourneyIdsInput(): string[] | undefined;
    }
    class AssociatedSystemPropertyList extends cdktn.ComplexList {
        internalValue?: AssociatedSystemProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AssociatedSystemPropertyOutputReference;
    }
    interface CrossAccountRoleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_service#cross_account_role_arn AwsResiliencehubv2Service#cross_account_role_arn}
        */
        readonly crossAccountRoleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_service#external_id AwsResiliencehubv2Service#external_id}
        */
        readonly externalId?: string;
    }
    class CrossAccountRolePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CrossAccountRoleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CrossAccountRoleProperty | cdktn.IResolvable | undefined);
        private _crossAccountRoleArn?;
        get crossAccountRoleArn(): string;
        set crossAccountRoleArn(value: string);
        get crossAccountRoleArnInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
    }
    class CrossAccountRolePropertyList extends cdktn.ComplexList {
        internalValue?: CrossAccountRoleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CrossAccountRolePropertyOutputReference;
    }
    interface PermissionModelProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_service#invoker_role_name AwsResiliencehubv2Service#invoker_role_name}
        */
        readonly invokerRoleName: string;
        /**
        * cross_account_role block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_service#cross_account_role AwsResiliencehubv2Service#cross_account_role}
        */
        readonly crossAccountRole?: CrossAccountRoleProperty[] | cdktn.IResolvable;
    }
    class PermissionModelPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PermissionModelProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PermissionModelProperty | cdktn.IResolvable | undefined);
        private _invokerRoleName?;
        get invokerRoleName(): string;
        set invokerRoleName(value: string);
        get invokerRoleNameInput(): string | undefined;
        private _crossAccountRole;
        get crossAccountRole(): CrossAccountRolePropertyList;
        putCrossAccountRole(value: CrossAccountRoleProperty[] | cdktn.IResolvable): void;
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): cdktn.IResolvable | CrossAccountRoleProperty[] | undefined;
    }
    class PermissionModelPropertyList extends cdktn.ComplexList {
        internalValue?: PermissionModelProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PermissionModelPropertyOutputReference;
    }
}
