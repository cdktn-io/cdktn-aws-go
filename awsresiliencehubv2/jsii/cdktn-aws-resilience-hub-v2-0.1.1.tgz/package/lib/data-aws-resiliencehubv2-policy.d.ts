import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsResiliencehubv2PolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/resiliencehubv2_policy#arn DataAwsResiliencehubv2Policy#arn}
    */
    readonly arn: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/resiliencehubv2_policy#region DataAwsResiliencehubv2Policy#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/resiliencehubv2_policy aws_resiliencehubv2_policy}
*/
export declare class DataAwsResiliencehubv2Policy extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_resiliencehubv2_policy";
    /**
    * Generates CDKTN code for importing a DataAwsResiliencehubv2Policy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsResiliencehubv2Policy to import
    * @param importFromId The id of the existing DataAwsResiliencehubv2Policy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/resiliencehubv2_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsResiliencehubv2Policy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/resiliencehubv2_policy aws_resiliencehubv2_policy} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsResiliencehubv2PolicyConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsResiliencehubv2PolicyConfig);
    private _arn?;
    get arn(): string;
    set arn(value: string);
    get arnInput(): string | undefined;
    private _availabilitySlo;
    get availabilitySlo(): DataAwsResiliencehubv2Policy.AvailabilitySloPropertyList;
    private _dataRecovery;
    get dataRecovery(): DataAwsResiliencehubv2Policy.DataRecoveryPropertyList;
    get description(): string;
    get kmsKeyId(): string;
    private _multiAz;
    get multiAz(): DataAwsResiliencehubv2Policy.MultiAzPropertyList;
    private _multiRegion;
    get multiRegion(): DataAwsResiliencehubv2Policy.MultiRegionPropertyList;
    get name(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags;
    get tags(): cdktn.StringMap;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsResiliencehubv2PolicyAvailabilitySloPropertyToTerraform(struct?: DataAwsResiliencehubv2Policy.AvailabilitySloProperty): any;
export declare function dataAwsResiliencehubv2PolicyAvailabilitySloPropertyToHclTerraform(struct?: DataAwsResiliencehubv2Policy.AvailabilitySloProperty): any;
export declare function dataAwsResiliencehubv2PolicyDataRecoveryPropertyToTerraform(struct?: DataAwsResiliencehubv2Policy.DataRecoveryProperty): any;
export declare function dataAwsResiliencehubv2PolicyDataRecoveryPropertyToHclTerraform(struct?: DataAwsResiliencehubv2Policy.DataRecoveryProperty): any;
export declare function dataAwsResiliencehubv2PolicyMultiAzPropertyToTerraform(struct?: DataAwsResiliencehubv2Policy.MultiAzProperty): any;
export declare function dataAwsResiliencehubv2PolicyMultiAzPropertyToHclTerraform(struct?: DataAwsResiliencehubv2Policy.MultiAzProperty): any;
export declare function dataAwsResiliencehubv2PolicyMultiRegionPropertyToTerraform(struct?: DataAwsResiliencehubv2Policy.MultiRegionProperty): any;
export declare function dataAwsResiliencehubv2PolicyMultiRegionPropertyToHclTerraform(struct?: DataAwsResiliencehubv2Policy.MultiRegionProperty): any;
export declare namespace DataAwsResiliencehubv2Policy {
    interface AvailabilitySloProperty {
    }
    class AvailabilitySloPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AvailabilitySloProperty | undefined;
        set internalValue(value: AvailabilitySloProperty | undefined);
        get target(): number;
    }
    class AvailabilitySloPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AvailabilitySloPropertyOutputReference;
    }
    interface DataRecoveryProperty {
    }
    class DataRecoveryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataRecoveryProperty | undefined;
        set internalValue(value: DataRecoveryProperty | undefined);
        get timeBetweenBackupsInMinutes(): number;
    }
    class DataRecoveryPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataRecoveryPropertyOutputReference;
    }
    interface MultiAzProperty {
    }
    class MultiAzPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MultiAzProperty | undefined;
        set internalValue(value: MultiAzProperty | undefined);
        get disasterRecoveryApproach(): string;
        get rpoInMinutes(): number;
        get rtoInMinutes(): number;
    }
    class MultiAzPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MultiAzPropertyOutputReference;
    }
    interface MultiRegionProperty {
    }
    class MultiRegionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MultiRegionProperty | undefined;
        set internalValue(value: MultiRegionProperty | undefined);
        get disasterRecoveryApproach(): string;
        get rpoInMinutes(): number;
        get rtoInMinutes(): number;
    }
    class MultiRegionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MultiRegionPropertyOutputReference;
    }
}
