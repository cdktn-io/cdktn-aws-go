import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfServiceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/resiliencehubv2_service#arn DataTfService#arn}
    */
    readonly arn: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/resiliencehubv2_service#region DataTfService#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/resiliencehubv2_service aws_resiliencehubv2_service}
*/
export declare class DataTfService extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_resiliencehubv2_service";
    /**
    * Generates CDKTN code for importing a DataTfService resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfService to import
    * @param importFromId The id of the existing DataTfService that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/resiliencehubv2_service#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfService to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/resiliencehubv2_service aws_resiliencehubv2_service} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfServiceConfig
    */
    constructor(scope: Construct, id: string, config: DataTfServiceConfig);
    private _arn?;
    get arn(): string;
    set arn(value: string);
    get arnInput(): string | undefined;
    private _associatedSystem;
    get associatedSystem(): DataTfService.AssociatedSystemPropertyList;
    get description(): string;
    get kmsKeyId(): string;
    get name(): string;
    private _permissionModel;
    get permissionModel(): DataTfService.PermissionModelPropertyList;
    get policyArn(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get regions(): string[];
    private _tags;
    get tags(): cdktn.StringMap;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfServiceAssociatedSystemPropertyToTerraform(struct?: DataTfService.AssociatedSystemProperty): any;
export declare function dataTfServiceAssociatedSystemPropertyToHclTerraform(struct?: DataTfService.AssociatedSystemProperty): any;
export declare function dataTfServiceCrossAccountRolePropertyToTerraform(struct?: DataTfService.CrossAccountRoleProperty): any;
export declare function dataTfServiceCrossAccountRolePropertyToHclTerraform(struct?: DataTfService.CrossAccountRoleProperty): any;
export declare function dataTfServicePermissionModelPropertyToTerraform(struct?: DataTfService.PermissionModelProperty): any;
export declare function dataTfServicePermissionModelPropertyToHclTerraform(struct?: DataTfService.PermissionModelProperty): any;
export declare namespace DataTfService {
    interface AssociatedSystemProperty {
    }
    class AssociatedSystemPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AssociatedSystemProperty | undefined;
        set internalValue(value: AssociatedSystemProperty | undefined);
        get systemArn(): string;
        get userJourneyIds(): string[];
    }
    class AssociatedSystemPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AssociatedSystemPropertyOutputReference;
    }
    interface CrossAccountRoleProperty {
    }
    class CrossAccountRolePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CrossAccountRoleProperty | undefined;
        set internalValue(value: CrossAccountRoleProperty | undefined);
        get crossAccountRoleArn(): string;
        get externalId(): string;
    }
    class CrossAccountRolePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CrossAccountRolePropertyOutputReference;
    }
    interface PermissionModelProperty {
    }
    class PermissionModelPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PermissionModelProperty | undefined;
        set internalValue(value: PermissionModelProperty | undefined);
        private _crossAccountRole;
        get crossAccountRole(): CrossAccountRolePropertyList;
        get invokerRoleName(): string;
    }
    class PermissionModelPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PermissionModelPropertyOutputReference;
    }
}
