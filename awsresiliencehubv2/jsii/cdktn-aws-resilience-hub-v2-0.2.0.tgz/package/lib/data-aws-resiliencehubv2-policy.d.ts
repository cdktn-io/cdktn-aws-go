import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/resiliencehubv2_policy#arn DataTfPolicy#arn}
    */
    readonly arn: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/resiliencehubv2_policy#region DataTfPolicy#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/resiliencehubv2_policy aws_resiliencehubv2_policy}
*/
export declare class DataTfPolicy extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_resiliencehubv2_policy";
    /**
    * Generates CDKTN code for importing a DataTfPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfPolicy to import
    * @param importFromId The id of the existing DataTfPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/resiliencehubv2_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/resiliencehubv2_policy aws_resiliencehubv2_policy} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfPolicyConfig
    */
    constructor(scope: Construct, id: string, config: DataTfPolicyConfig);
    private _arn?;
    get arn(): string;
    set arn(value: string);
    get arnInput(): string | undefined;
    private _availabilitySlo;
    get availabilitySlo(): DataTfPolicy.AvailabilitySloPropertyList;
    private _dataRecovery;
    get dataRecovery(): DataTfPolicy.DataRecoveryPropertyList;
    get description(): string;
    get kmsKeyId(): string;
    private _multiAz;
    get multiAz(): DataTfPolicy.MultiAzPropertyList;
    private _multiRegion;
    get multiRegion(): DataTfPolicy.MultiRegionPropertyList;
    get name(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags;
    get tags(): cdktn.StringMap;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfPolicyAvailabilitySloPropertyToTerraform(struct?: DataTfPolicy.AvailabilitySloProperty): any;
export declare function dataTfPolicyAvailabilitySloPropertyToHclTerraform(struct?: DataTfPolicy.AvailabilitySloProperty): any;
export declare function dataTfPolicyDataRecoveryPropertyToTerraform(struct?: DataTfPolicy.DataRecoveryProperty): any;
export declare function dataTfPolicyDataRecoveryPropertyToHclTerraform(struct?: DataTfPolicy.DataRecoveryProperty): any;
export declare function dataTfPolicyMultiAzPropertyToTerraform(struct?: DataTfPolicy.MultiAzProperty): any;
export declare function dataTfPolicyMultiAzPropertyToHclTerraform(struct?: DataTfPolicy.MultiAzProperty): any;
export declare function dataTfPolicyMultiRegionPropertyToTerraform(struct?: DataTfPolicy.MultiRegionProperty): any;
export declare function dataTfPolicyMultiRegionPropertyToHclTerraform(struct?: DataTfPolicy.MultiRegionProperty): any;
export declare namespace DataTfPolicy {
    interface AvailabilitySloProperty {
    }
    class AvailabilitySloPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AvailabilitySloProperty | undefined;
        set internalValue(value: AvailabilitySloProperty | undefined);
        get target(): number;
    }
    class AvailabilitySloPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AvailabilitySloPropertyOutputReference;
    }
    interface DataRecoveryProperty {
    }
    class DataRecoveryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataRecoveryProperty | undefined;
        set internalValue(value: DataRecoveryProperty | undefined);
        get timeBetweenBackupsInMinutes(): number;
    }
    class DataRecoveryPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataRecoveryPropertyOutputReference;
    }
    interface MultiAzProperty {
    }
    class MultiAzPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MultiAzProperty | undefined;
        set internalValue(value: MultiAzProperty | undefined);
        get disasterRecoveryApproach(): string;
        get rpoInMinutes(): number;
        get rtoInMinutes(): number;
    }
    class MultiAzPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MultiAzPropertyOutputReference;
    }
    interface MultiRegionProperty {
    }
    class MultiRegionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MultiRegionProperty | undefined;
        set internalValue(value: MultiRegionProperty | undefined);
        get disasterRecoveryApproach(): string;
        get rpoInMinutes(): number;
        get rtoInMinutes(): number;
    }
    class MultiRegionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MultiRegionPropertyOutputReference;
    }
}
