import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfInputSourceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_input_source#region TfInputSource#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_input_source#service_arn TfInputSource#service_arn}
    */
    readonly serviceArn: string;
    /**
    * resource_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_input_source#resource_configuration TfInputSource#resource_configuration}
    */
    readonly resourceConfiguration?: TfInputSource.ResourceConfigurationProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_input_source aws_resiliencehubv2_input_source}
*/
export declare class TfInputSource extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_resiliencehubv2_input_source";
    /**
    * Generates CDKTN code for importing a TfInputSource resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfInputSource to import
    * @param importFromId The id of the existing TfInputSource that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_input_source#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfInputSource to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_input_source aws_resiliencehubv2_input_source} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfInputSourceConfig
    */
    constructor(scope: Construct, id: string, config: TfInputSourceConfig);
    get inputSourceId(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _serviceArn?;
    get serviceArn(): string;
    set serviceArn(value: string);
    get serviceArnInput(): string | undefined;
    private _resourceConfiguration;
    get resourceConfiguration(): TfInputSource.ResourceConfigurationPropertyList;
    putResourceConfiguration(value: TfInputSource.ResourceConfigurationProperty[] | cdktn.IResolvable): void;
    resetResourceConfiguration(): void;
    get resourceConfigurationInput(): cdktn.IResolvable | TfInputSource.ResourceConfigurationProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfInputSourceEksPropertyToTerraform(struct?: TfInputSource.EksProperty | cdktn.IResolvable): any;
export declare function tfInputSourceEksPropertyToHclTerraform(struct?: TfInputSource.EksProperty | cdktn.IResolvable): any;
export declare function tfInputSourceResourceTagPropertyToTerraform(struct?: TfInputSource.ResourceTagProperty | cdktn.IResolvable): any;
export declare function tfInputSourceResourceTagPropertyToHclTerraform(struct?: TfInputSource.ResourceTagProperty | cdktn.IResolvable): any;
export declare function tfInputSourceResourceConfigurationPropertyToTerraform(struct?: TfInputSource.ResourceConfigurationProperty | cdktn.IResolvable): any;
export declare function tfInputSourceResourceConfigurationPropertyToHclTerraform(struct?: TfInputSource.ResourceConfigurationProperty | cdktn.IResolvable): any;
export declare namespace TfInputSource {
    interface EksProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_input_source#cluster_arn TfInputSource#cluster_arn}
        */
        readonly clusterArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_input_source#namespaces TfInputSource#namespaces}
        */
        readonly namespaces: string[];
    }
    class EksPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EksProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EksProperty | cdktn.IResolvable | undefined);
        private _clusterArn?;
        get clusterArn(): string;
        set clusterArn(value: string);
        get clusterArnInput(): string | undefined;
        private _namespaces?;
        get namespaces(): string[];
        set namespaces(value: string[]);
        get namespacesInput(): string[] | undefined;
    }
    class EksPropertyList extends cdktn.ComplexList {
        internalValue?: EksProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EksPropertyOutputReference;
    }
    interface ResourceTagProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_input_source#key TfInputSource#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_input_source#values TfInputSource#values}
        */
        readonly values: string[];
    }
    class ResourceTagPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceTagProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceTagProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class ResourceTagPropertyList extends cdktn.ComplexList {
        internalValue?: ResourceTagProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceTagPropertyOutputReference;
    }
    interface ResourceConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_input_source#cfn_stack_arn TfInputSource#cfn_stack_arn}
        */
        readonly cfnStackArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_input_source#design_file_s3_url TfInputSource#design_file_s3_url}
        */
        readonly designFileS3Url?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_input_source#tf_state_file_url TfInputSource#tf_state_file_url}
        */
        readonly tfStateFileUrl?: string;
        /**
        * eks block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_input_source#eks TfInputSource#eks}
        */
        readonly eks?: EksProperty[] | cdktn.IResolvable;
        /**
        * resource_tag block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_input_source#resource_tag TfInputSource#resource_tag}
        */
        readonly resourceTag?: ResourceTagProperty[] | cdktn.IResolvable;
    }
    class ResourceConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceConfigurationProperty | cdktn.IResolvable | undefined);
        private _cfnStackArn?;
        get cfnStackArn(): string;
        set cfnStackArn(value: string);
        resetCfnStackArn(): void;
        get cfnStackArnInput(): string | undefined;
        private _designFileS3Url?;
        get designFileS3Url(): string;
        set designFileS3Url(value: string);
        resetDesignFileS3Url(): void;
        get designFileS3UrlInput(): string | undefined;
        private _tfStateFileUrl?;
        get tfStateFileUrl(): string;
        set tfStateFileUrl(value: string);
        resetTfStateFileUrl(): void;
        get tfStateFileUrlInput(): string | undefined;
        private _eks;
        get eks(): EksPropertyList;
        putEks(value: EksProperty[] | cdktn.IResolvable): void;
        resetEks(): void;
        get eksInput(): cdktn.IResolvable | EksProperty[] | undefined;
        private _resourceTag;
        get resourceTag(): ResourceTagPropertyList;
        putResourceTag(value: ResourceTagProperty[] | cdktn.IResolvable): void;
        resetResourceTag(): void;
        get resourceTagInput(): cdktn.IResolvable | ResourceTagProperty[] | undefined;
    }
    class ResourceConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: ResourceConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceConfigurationPropertyOutputReference;
    }
}
