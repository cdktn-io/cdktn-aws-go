import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#description TfPolicy#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#kms_key_id TfPolicy#kms_key_id}
    */
    readonly kmsKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#name TfPolicy#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#region TfPolicy#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#tags TfPolicy#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * availability_slo block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#availability_slo TfPolicy#availability_slo}
    */
    readonly availabilitySlo?: TfPolicy.AvailabilitySloProperty[] | cdktn.IResolvable;
    /**
    * data_recovery block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#data_recovery TfPolicy#data_recovery}
    */
    readonly dataRecovery?: TfPolicy.DataRecoveryProperty[] | cdktn.IResolvable;
    /**
    * multi_az block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#multi_az TfPolicy#multi_az}
    */
    readonly multiAz?: TfPolicy.MultiAzProperty[] | cdktn.IResolvable;
    /**
    * multi_region block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#multi_region TfPolicy#multi_region}
    */
    readonly multiRegion?: TfPolicy.MultiRegionProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy aws_resiliencehubv2_policy}
*/
export declare class TfPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_resiliencehubv2_policy";
    /**
    * Generates CDKTN code for importing a TfPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfPolicy to import
    * @param importFromId The id of the existing TfPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy aws_resiliencehubv2_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfPolicyConfig
    */
    constructor(scope: Construct, id: string, config: TfPolicyConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _kmsKeyId?;
    get kmsKeyId(): string;
    set kmsKeyId(value: string);
    resetKmsKeyId(): void;
    get kmsKeyIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _availabilitySlo;
    get availabilitySlo(): TfPolicy.AvailabilitySloPropertyList;
    putAvailabilitySlo(value: TfPolicy.AvailabilitySloProperty[] | cdktn.IResolvable): void;
    resetAvailabilitySlo(): void;
    get availabilitySloInput(): cdktn.IResolvable | TfPolicy.AvailabilitySloProperty[] | undefined;
    private _dataRecovery;
    get dataRecovery(): TfPolicy.DataRecoveryPropertyList;
    putDataRecovery(value: TfPolicy.DataRecoveryProperty[] | cdktn.IResolvable): void;
    resetDataRecovery(): void;
    get dataRecoveryInput(): cdktn.IResolvable | TfPolicy.DataRecoveryProperty[] | undefined;
    private _multiAz;
    get multiAz(): TfPolicy.MultiAzPropertyList;
    putMultiAz(value: TfPolicy.MultiAzProperty[] | cdktn.IResolvable): void;
    resetMultiAz(): void;
    get multiAzInput(): cdktn.IResolvable | TfPolicy.MultiAzProperty[] | undefined;
    private _multiRegion;
    get multiRegion(): TfPolicy.MultiRegionPropertyList;
    putMultiRegion(value: TfPolicy.MultiRegionProperty[] | cdktn.IResolvable): void;
    resetMultiRegion(): void;
    get multiRegionInput(): cdktn.IResolvable | TfPolicy.MultiRegionProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfPolicyAvailabilitySloPropertyToTerraform(struct?: TfPolicy.AvailabilitySloProperty | cdktn.IResolvable): any;
export declare function tfPolicyAvailabilitySloPropertyToHclTerraform(struct?: TfPolicy.AvailabilitySloProperty | cdktn.IResolvable): any;
export declare function tfPolicyDataRecoveryPropertyToTerraform(struct?: TfPolicy.DataRecoveryProperty | cdktn.IResolvable): any;
export declare function tfPolicyDataRecoveryPropertyToHclTerraform(struct?: TfPolicy.DataRecoveryProperty | cdktn.IResolvable): any;
export declare function tfPolicyMultiAzPropertyToTerraform(struct?: TfPolicy.MultiAzProperty | cdktn.IResolvable): any;
export declare function tfPolicyMultiAzPropertyToHclTerraform(struct?: TfPolicy.MultiAzProperty | cdktn.IResolvable): any;
export declare function tfPolicyMultiRegionPropertyToTerraform(struct?: TfPolicy.MultiRegionProperty | cdktn.IResolvable): any;
export declare function tfPolicyMultiRegionPropertyToHclTerraform(struct?: TfPolicy.MultiRegionProperty | cdktn.IResolvable): any;
export declare namespace TfPolicy {
    interface AvailabilitySloProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#target TfPolicy#target}
        */
        readonly target: number;
    }
    class AvailabilitySloPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AvailabilitySloProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AvailabilitySloProperty | cdktn.IResolvable | undefined);
        private _target?;
        get target(): number;
        set target(value: number);
        get targetInput(): number | undefined;
    }
    class AvailabilitySloPropertyList extends cdktn.ComplexList {
        internalValue?: AvailabilitySloProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AvailabilitySloPropertyOutputReference;
    }
    interface DataRecoveryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#time_between_backups_in_minutes TfPolicy#time_between_backups_in_minutes}
        */
        readonly timeBetweenBackupsInMinutes: number;
    }
    class DataRecoveryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataRecoveryProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DataRecoveryProperty | cdktn.IResolvable | undefined);
        private _timeBetweenBackupsInMinutes?;
        get timeBetweenBackupsInMinutes(): number;
        set timeBetweenBackupsInMinutes(value: number);
        get timeBetweenBackupsInMinutesInput(): number | undefined;
    }
    class DataRecoveryPropertyList extends cdktn.ComplexList {
        internalValue?: DataRecoveryProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataRecoveryPropertyOutputReference;
    }
    interface MultiAzProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#disaster_recovery_approach TfPolicy#disaster_recovery_approach}
        */
        readonly disasterRecoveryApproach: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#rpo_in_minutes TfPolicy#rpo_in_minutes}
        */
        readonly rpoInMinutes?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#rto_in_minutes TfPolicy#rto_in_minutes}
        */
        readonly rtoInMinutes?: number;
    }
    class MultiAzPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MultiAzProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MultiAzProperty | cdktn.IResolvable | undefined);
        private _disasterRecoveryApproach?;
        get disasterRecoveryApproach(): string;
        set disasterRecoveryApproach(value: string);
        get disasterRecoveryApproachInput(): string | undefined;
        private _rpoInMinutes?;
        get rpoInMinutes(): number;
        set rpoInMinutes(value: number);
        resetRpoInMinutes(): void;
        get rpoInMinutesInput(): number | undefined;
        private _rtoInMinutes?;
        get rtoInMinutes(): number;
        set rtoInMinutes(value: number);
        resetRtoInMinutes(): void;
        get rtoInMinutesInput(): number | undefined;
    }
    class MultiAzPropertyList extends cdktn.ComplexList {
        internalValue?: MultiAzProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MultiAzPropertyOutputReference;
    }
    interface MultiRegionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#disaster_recovery_approach TfPolicy#disaster_recovery_approach}
        */
        readonly disasterRecoveryApproach: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#rpo_in_minutes TfPolicy#rpo_in_minutes}
        */
        readonly rpoInMinutes?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#rto_in_minutes TfPolicy#rto_in_minutes}
        */
        readonly rtoInMinutes?: number;
    }
    class MultiRegionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MultiRegionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MultiRegionProperty | cdktn.IResolvable | undefined);
        private _disasterRecoveryApproach?;
        get disasterRecoveryApproach(): string;
        set disasterRecoveryApproach(value: string);
        get disasterRecoveryApproachInput(): string | undefined;
        private _rpoInMinutes?;
        get rpoInMinutes(): number;
        set rpoInMinutes(value: number);
        resetRpoInMinutes(): void;
        get rpoInMinutesInput(): number | undefined;
        private _rtoInMinutes?;
        get rtoInMinutes(): number;
        set rtoInMinutes(value: number);
        resetRtoInMinutes(): void;
        get rtoInMinutesInput(): number | undefined;
    }
    class MultiRegionPropertyList extends cdktn.ComplexList {
        internalValue?: MultiRegionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MultiRegionPropertyOutputReference;
    }
}
