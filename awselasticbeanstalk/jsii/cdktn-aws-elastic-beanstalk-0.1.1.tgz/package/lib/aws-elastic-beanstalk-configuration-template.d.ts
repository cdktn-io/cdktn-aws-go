import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsElasticBeanstalkConfigurationTemplateConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_configuration_template#application AwsElasticBeanstalkConfigurationTemplate#application}
    */
    readonly application: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_configuration_template#description AwsElasticBeanstalkConfigurationTemplate#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_configuration_template#environment_id AwsElasticBeanstalkConfigurationTemplate#environment_id}
    */
    readonly environmentId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_configuration_template#id AwsElasticBeanstalkConfigurationTemplate#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_configuration_template#name AwsElasticBeanstalkConfigurationTemplate#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_configuration_template#region AwsElasticBeanstalkConfigurationTemplate#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_configuration_template#solution_stack_name AwsElasticBeanstalkConfigurationTemplate#solution_stack_name}
    */
    readonly solutionStackName?: string;
    /**
    * setting block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_configuration_template#setting AwsElasticBeanstalkConfigurationTemplate#setting}
    */
    readonly setting?: AwsElasticBeanstalkConfigurationTemplate.SettingProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_configuration_template aws_elastic_beanstalk_configuration_template}
*/
export declare class AwsElasticBeanstalkConfigurationTemplate extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_elastic_beanstalk_configuration_template";
    /**
    * Generates CDKTN code for importing a AwsElasticBeanstalkConfigurationTemplate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsElasticBeanstalkConfigurationTemplate to import
    * @param importFromId The id of the existing AwsElasticBeanstalkConfigurationTemplate that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_configuration_template#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsElasticBeanstalkConfigurationTemplate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_configuration_template aws_elastic_beanstalk_configuration_template} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsElasticBeanstalkConfigurationTemplateConfig
    */
    constructor(scope: Construct, id: string, config: AwsElasticBeanstalkConfigurationTemplateConfig);
    private _application?;
    get application(): string;
    set application(value: string);
    get applicationInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _environmentId?;
    get environmentId(): string;
    set environmentId(value: string);
    resetEnvironmentId(): void;
    get environmentIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _solutionStackName?;
    get solutionStackName(): string;
    set solutionStackName(value: string);
    resetSolutionStackName(): void;
    get solutionStackNameInput(): string | undefined;
    private _setting;
    get setting(): AwsElasticBeanstalkConfigurationTemplate.SettingPropertyList;
    putSetting(value: AwsElasticBeanstalkConfigurationTemplate.SettingProperty[] | cdktn.IResolvable): void;
    resetSetting(): void;
    get settingInput(): cdktn.IResolvable | AwsElasticBeanstalkConfigurationTemplate.SettingProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsElasticBeanstalkConfigurationTemplateSettingPropertyToTerraform(struct?: AwsElasticBeanstalkConfigurationTemplate.SettingProperty | cdktn.IResolvable): any;
export declare function awsElasticBeanstalkConfigurationTemplateSettingPropertyToHclTerraform(struct?: AwsElasticBeanstalkConfigurationTemplate.SettingProperty | cdktn.IResolvable): any;
export declare namespace AwsElasticBeanstalkConfigurationTemplate {
    interface SettingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_configuration_template#name AwsElasticBeanstalkConfigurationTemplate#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_configuration_template#namespace AwsElasticBeanstalkConfigurationTemplate#namespace}
        */
        readonly namespace: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_configuration_template#resource AwsElasticBeanstalkConfigurationTemplate#resource}
        */
        readonly resource?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_configuration_template#value AwsElasticBeanstalkConfigurationTemplate#value}
        */
        readonly value: string;
    }
    class SettingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SettingProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SettingProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _namespace?;
        get namespace(): string;
        set namespace(value: string);
        get namespaceInput(): string | undefined;
        private _resource?;
        get resource(): string;
        set resource(value: string);
        resetResource(): void;
        get resourceInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class SettingPropertyList extends cdktn.ComplexList {
        internalValue?: SettingProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SettingPropertyOutputReference;
    }
}
