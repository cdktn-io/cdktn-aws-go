import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfEnvironmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_environment#application TfEnvironment#application}
    */
    readonly application: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_environment#cname_prefix TfEnvironment#cname_prefix}
    */
    readonly cnamePrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_environment#description TfEnvironment#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_environment#id TfEnvironment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_environment#name TfEnvironment#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_environment#platform_arn TfEnvironment#platform_arn}
    */
    readonly platformArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_environment#poll_interval TfEnvironment#poll_interval}
    */
    readonly pollInterval?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_environment#region TfEnvironment#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_environment#solution_stack_name TfEnvironment#solution_stack_name}
    */
    readonly solutionStackName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_environment#tags TfEnvironment#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_environment#tags_all TfEnvironment#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_environment#template_name TfEnvironment#template_name}
    */
    readonly templateName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_environment#tier TfEnvironment#tier}
    */
    readonly tier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_environment#version_label TfEnvironment#version_label}
    */
    readonly versionLabel?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_environment#wait_for_ready_timeout TfEnvironment#wait_for_ready_timeout}
    */
    readonly waitForReadyTimeout?: string;
    /**
    * setting block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_environment#setting TfEnvironment#setting}
    */
    readonly setting?: TfEnvironment.SettingProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_environment aws_elastic_beanstalk_environment}
*/
export declare class TfEnvironment extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_elastic_beanstalk_environment";
    /**
    * Generates CDKTN code for importing a TfEnvironment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfEnvironment to import
    * @param importFromId The id of the existing TfEnvironment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_environment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfEnvironment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_environment aws_elastic_beanstalk_environment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfEnvironmentConfig
    */
    constructor(scope: Construct, id: string, config: TfEnvironmentConfig);
    private _allSettings;
    get allSettings(): TfEnvironment.AllSettingsPropertyList;
    private _application?;
    get application(): string;
    set application(value: string);
    get applicationInput(): string | undefined;
    get arn(): string;
    get autoscalingGroups(): string[];
    get cname(): string;
    private _cnamePrefix?;
    get cnamePrefix(): string;
    set cnamePrefix(value: string);
    resetCnamePrefix(): void;
    get cnamePrefixInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get endpointUrl(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get instances(): string[];
    get launchConfigurations(): string[];
    get loadBalancers(): string[];
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _platformArn?;
    get platformArn(): string;
    set platformArn(value: string);
    resetPlatformArn(): void;
    get platformArnInput(): string | undefined;
    private _pollInterval?;
    get pollInterval(): string;
    set pollInterval(value: string);
    resetPollInterval(): void;
    get pollIntervalInput(): string | undefined;
    get queues(): string[];
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _solutionStackName?;
    get solutionStackName(): string;
    set solutionStackName(value: string);
    resetSolutionStackName(): void;
    get solutionStackNameInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _templateName?;
    get templateName(): string;
    set templateName(value: string);
    resetTemplateName(): void;
    get templateNameInput(): string | undefined;
    private _tier?;
    get tier(): string;
    set tier(value: string);
    resetTier(): void;
    get tierInput(): string | undefined;
    get triggers(): string[];
    private _versionLabel?;
    get versionLabel(): string;
    set versionLabel(value: string);
    resetVersionLabel(): void;
    get versionLabelInput(): string | undefined;
    private _waitForReadyTimeout?;
    get waitForReadyTimeout(): string;
    set waitForReadyTimeout(value: string);
    resetWaitForReadyTimeout(): void;
    get waitForReadyTimeoutInput(): string | undefined;
    private _setting;
    get setting(): TfEnvironment.SettingPropertyList;
    putSetting(value: TfEnvironment.SettingProperty[] | cdktn.IResolvable): void;
    resetSetting(): void;
    get settingInput(): cdktn.IResolvable | TfEnvironment.SettingProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfEnvironmentAllSettingsPropertyToTerraform(struct?: TfEnvironment.AllSettingsProperty): any;
export declare function tfEnvironmentAllSettingsPropertyToHclTerraform(struct?: TfEnvironment.AllSettingsProperty): any;
export declare function tfEnvironmentSettingPropertyToTerraform(struct?: TfEnvironment.SettingProperty | cdktn.IResolvable): any;
export declare function tfEnvironmentSettingPropertyToHclTerraform(struct?: TfEnvironment.SettingProperty | cdktn.IResolvable): any;
export declare namespace TfEnvironment {
    interface AllSettingsProperty {
    }
    class AllSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AllSettingsProperty | undefined;
        set internalValue(value: AllSettingsProperty | undefined);
        get name(): string;
        get namespace(): string;
        get resource(): string;
        get value(): string;
    }
    class AllSettingsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AllSettingsPropertyOutputReference;
    }
    interface SettingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_environment#name TfEnvironment#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_environment#namespace TfEnvironment#namespace}
        */
        readonly namespace: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_environment#resource TfEnvironment#resource}
        */
        readonly resource?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_environment#value TfEnvironment#value}
        */
        readonly value: string;
    }
    class SettingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SettingProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SettingProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _namespace?;
        get namespace(): string;
        set namespace(value: string);
        get namespaceInput(): string | undefined;
        private _resource?;
        get resource(): string;
        set resource(value: string);
        resetResource(): void;
        get resourceInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class SettingPropertyList extends cdktn.ComplexList {
        internalValue?: SettingProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SettingPropertyOutputReference;
    }
}
