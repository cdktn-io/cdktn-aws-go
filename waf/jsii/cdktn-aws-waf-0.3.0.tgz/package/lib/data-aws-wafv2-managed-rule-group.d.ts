import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsManagedRuleGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/wafv2_managed_rule_group#name DataAwsManagedRuleGroup#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/wafv2_managed_rule_group#region DataAwsManagedRuleGroup#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/wafv2_managed_rule_group#scope DataAwsManagedRuleGroup#scope}
    */
    readonly scope: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/wafv2_managed_rule_group#vendor_name DataAwsManagedRuleGroup#vendor_name}
    */
    readonly vendorName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/wafv2_managed_rule_group#version_name DataAwsManagedRuleGroup#version_name}
    */
    readonly versionName?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/wafv2_managed_rule_group aws_wafv2_managed_rule_group}
*/
export declare class DataAwsManagedRuleGroup extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_wafv2_managed_rule_group";
    /**
    * Generates CDKTN code for importing a DataAwsManagedRuleGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsManagedRuleGroup to import
    * @param importFromId The id of the existing DataAwsManagedRuleGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/wafv2_managed_rule_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsManagedRuleGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/wafv2_managed_rule_group aws_wafv2_managed_rule_group} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsManagedRuleGroupConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsManagedRuleGroupConfig);
    private _availableLabels;
    get availableLabels(): DataAwsManagedRuleGroup.AvailableLabelsPropertyList;
    get capacity(): number;
    private _consumedLabels;
    get consumedLabels(): DataAwsManagedRuleGroup.ConsumedLabelsPropertyList;
    get labelNamespace(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _rules;
    get rules(): DataAwsManagedRuleGroup.RulesPropertyList;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    get scopeInput(): string | undefined;
    get snsTopicArn(): string;
    private _vendorName?;
    get vendorName(): string;
    set vendorName(value: string);
    get vendorNameInput(): string | undefined;
    private _versionName?;
    get versionName(): string;
    set versionName(value: string);
    resetVersionName(): void;
    get versionNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsManagedRuleGroupAvailableLabelsPropertyToTerraform(struct?: DataAwsManagedRuleGroup.AvailableLabelsProperty): any;
export declare function dataAwsManagedRuleGroupAvailableLabelsPropertyToHclTerraform(struct?: DataAwsManagedRuleGroup.AvailableLabelsProperty): any;
export declare function dataAwsManagedRuleGroupConsumedLabelsPropertyToTerraform(struct?: DataAwsManagedRuleGroup.ConsumedLabelsProperty): any;
export declare function dataAwsManagedRuleGroupConsumedLabelsPropertyToHclTerraform(struct?: DataAwsManagedRuleGroup.ConsumedLabelsProperty): any;
export declare function dataAwsManagedRuleGroupRulesActionAllowCustomRequestHandlingInsertHeaderPropertyToTerraform(struct?: DataAwsManagedRuleGroup.RulesActionAllowCustomRequestHandlingInsertHeaderProperty): any;
export declare function dataAwsManagedRuleGroupRulesActionAllowCustomRequestHandlingInsertHeaderPropertyToHclTerraform(struct?: DataAwsManagedRuleGroup.RulesActionAllowCustomRequestHandlingInsertHeaderProperty): any;
export declare function dataAwsManagedRuleGroupRulesActionAllowCustomRequestHandlingPropertyToTerraform(struct?: DataAwsManagedRuleGroup.RulesActionAllowCustomRequestHandlingProperty): any;
export declare function dataAwsManagedRuleGroupRulesActionAllowCustomRequestHandlingPropertyToHclTerraform(struct?: DataAwsManagedRuleGroup.RulesActionAllowCustomRequestHandlingProperty): any;
export declare function dataAwsManagedRuleGroupAllowPropertyToTerraform(struct?: DataAwsManagedRuleGroup.AllowProperty): any;
export declare function dataAwsManagedRuleGroupAllowPropertyToHclTerraform(struct?: DataAwsManagedRuleGroup.AllowProperty): any;
export declare function dataAwsManagedRuleGroupResponseHeaderPropertyToTerraform(struct?: DataAwsManagedRuleGroup.ResponseHeaderProperty): any;
export declare function dataAwsManagedRuleGroupResponseHeaderPropertyToHclTerraform(struct?: DataAwsManagedRuleGroup.ResponseHeaderProperty): any;
export declare function dataAwsManagedRuleGroupCustomResponsePropertyToTerraform(struct?: DataAwsManagedRuleGroup.CustomResponseProperty): any;
export declare function dataAwsManagedRuleGroupCustomResponsePropertyToHclTerraform(struct?: DataAwsManagedRuleGroup.CustomResponseProperty): any;
export declare function dataAwsManagedRuleGroupBlockPropertyToTerraform(struct?: DataAwsManagedRuleGroup.BlockProperty): any;
export declare function dataAwsManagedRuleGroupBlockPropertyToHclTerraform(struct?: DataAwsManagedRuleGroup.BlockProperty): any;
export declare function dataAwsManagedRuleGroupRulesActionCaptchaCustomRequestHandlingInsertHeaderPropertyToTerraform(struct?: DataAwsManagedRuleGroup.RulesActionCaptchaCustomRequestHandlingInsertHeaderProperty): any;
export declare function dataAwsManagedRuleGroupRulesActionCaptchaCustomRequestHandlingInsertHeaderPropertyToHclTerraform(struct?: DataAwsManagedRuleGroup.RulesActionCaptchaCustomRequestHandlingInsertHeaderProperty): any;
export declare function dataAwsManagedRuleGroupRulesActionCaptchaCustomRequestHandlingPropertyToTerraform(struct?: DataAwsManagedRuleGroup.RulesActionCaptchaCustomRequestHandlingProperty): any;
export declare function dataAwsManagedRuleGroupRulesActionCaptchaCustomRequestHandlingPropertyToHclTerraform(struct?: DataAwsManagedRuleGroup.RulesActionCaptchaCustomRequestHandlingProperty): any;
export declare function dataAwsManagedRuleGroupCaptchaPropertyToTerraform(struct?: DataAwsManagedRuleGroup.CaptchaProperty): any;
export declare function dataAwsManagedRuleGroupCaptchaPropertyToHclTerraform(struct?: DataAwsManagedRuleGroup.CaptchaProperty): any;
export declare function dataAwsManagedRuleGroupRulesActionChallengeCustomRequestHandlingInsertHeaderPropertyToTerraform(struct?: DataAwsManagedRuleGroup.RulesActionChallengeCustomRequestHandlingInsertHeaderProperty): any;
export declare function dataAwsManagedRuleGroupRulesActionChallengeCustomRequestHandlingInsertHeaderPropertyToHclTerraform(struct?: DataAwsManagedRuleGroup.RulesActionChallengeCustomRequestHandlingInsertHeaderProperty): any;
export declare function dataAwsManagedRuleGroupRulesActionChallengeCustomRequestHandlingPropertyToTerraform(struct?: DataAwsManagedRuleGroup.RulesActionChallengeCustomRequestHandlingProperty): any;
export declare function dataAwsManagedRuleGroupRulesActionChallengeCustomRequestHandlingPropertyToHclTerraform(struct?: DataAwsManagedRuleGroup.RulesActionChallengeCustomRequestHandlingProperty): any;
export declare function dataAwsManagedRuleGroupChallengePropertyToTerraform(struct?: DataAwsManagedRuleGroup.ChallengeProperty): any;
export declare function dataAwsManagedRuleGroupChallengePropertyToHclTerraform(struct?: DataAwsManagedRuleGroup.ChallengeProperty): any;
export declare function dataAwsManagedRuleGroupRulesActionCountCustomRequestHandlingInsertHeaderPropertyToTerraform(struct?: DataAwsManagedRuleGroup.RulesActionCountCustomRequestHandlingInsertHeaderProperty): any;
export declare function dataAwsManagedRuleGroupRulesActionCountCustomRequestHandlingInsertHeaderPropertyToHclTerraform(struct?: DataAwsManagedRuleGroup.RulesActionCountCustomRequestHandlingInsertHeaderProperty): any;
export declare function dataAwsManagedRuleGroupRulesActionCountCustomRequestHandlingPropertyToTerraform(struct?: DataAwsManagedRuleGroup.RulesActionCountCustomRequestHandlingProperty): any;
export declare function dataAwsManagedRuleGroupRulesActionCountCustomRequestHandlingPropertyToHclTerraform(struct?: DataAwsManagedRuleGroup.RulesActionCountCustomRequestHandlingProperty): any;
export declare function dataAwsManagedRuleGroupCountPropertyToTerraform(struct?: DataAwsManagedRuleGroup.CountProperty): any;
export declare function dataAwsManagedRuleGroupCountPropertyToHclTerraform(struct?: DataAwsManagedRuleGroup.CountProperty): any;
export declare function dataAwsManagedRuleGroupActionPropertyToTerraform(struct?: DataAwsManagedRuleGroup.ActionProperty): any;
export declare function dataAwsManagedRuleGroupActionPropertyToHclTerraform(struct?: DataAwsManagedRuleGroup.ActionProperty): any;
export declare function dataAwsManagedRuleGroupRulesPropertyToTerraform(struct?: DataAwsManagedRuleGroup.RulesProperty): any;
export declare function dataAwsManagedRuleGroupRulesPropertyToHclTerraform(struct?: DataAwsManagedRuleGroup.RulesProperty): any;
export declare namespace DataAwsManagedRuleGroup {
    interface AvailableLabelsProperty {
    }
    class AvailableLabelsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AvailableLabelsProperty | undefined;
        set internalValue(value: AvailableLabelsProperty | undefined);
        get name(): string;
    }
    class AvailableLabelsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AvailableLabelsPropertyOutputReference;
    }
    interface ConsumedLabelsProperty {
    }
    class ConsumedLabelsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConsumedLabelsProperty | undefined;
        set internalValue(value: ConsumedLabelsProperty | undefined);
        get name(): string;
    }
    class ConsumedLabelsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConsumedLabelsPropertyOutputReference;
    }
    interface RulesActionAllowCustomRequestHandlingInsertHeaderProperty {
    }
    class RulesActionAllowCustomRequestHandlingInsertHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RulesActionAllowCustomRequestHandlingInsertHeaderProperty | undefined;
        set internalValue(value: RulesActionAllowCustomRequestHandlingInsertHeaderProperty | undefined);
        get name(): string;
        get value(): string;
    }
    class RulesActionAllowCustomRequestHandlingInsertHeaderPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RulesActionAllowCustomRequestHandlingInsertHeaderPropertyOutputReference;
    }
    interface RulesActionAllowCustomRequestHandlingProperty {
    }
    class RulesActionAllowCustomRequestHandlingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RulesActionAllowCustomRequestHandlingProperty | undefined;
        set internalValue(value: RulesActionAllowCustomRequestHandlingProperty | undefined);
        private _insertHeader;
        get insertHeader(): RulesActionAllowCustomRequestHandlingInsertHeaderPropertyList;
    }
    class RulesActionAllowCustomRequestHandlingPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RulesActionAllowCustomRequestHandlingPropertyOutputReference;
    }
    interface AllowProperty {
    }
    class AllowPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AllowProperty | undefined;
        set internalValue(value: AllowProperty | undefined);
        private _customRequestHandling;
        get customRequestHandling(): RulesActionAllowCustomRequestHandlingPropertyList;
    }
    class AllowPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AllowPropertyOutputReference;
    }
    interface ResponseHeaderProperty {
    }
    class ResponseHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResponseHeaderProperty | undefined;
        set internalValue(value: ResponseHeaderProperty | undefined);
        get name(): string;
        get value(): string;
    }
    class ResponseHeaderPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResponseHeaderPropertyOutputReference;
    }
    interface CustomResponseProperty {
    }
    class CustomResponsePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomResponseProperty | undefined;
        set internalValue(value: CustomResponseProperty | undefined);
        get customResponseBodyKey(): string;
        get responseCode(): number;
        private _responseHeader;
        get responseHeader(): ResponseHeaderPropertyList;
    }
    class CustomResponsePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomResponsePropertyOutputReference;
    }
    interface BlockProperty {
    }
    class BlockPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BlockProperty | undefined;
        set internalValue(value: BlockProperty | undefined);
        private _customResponse;
        get customResponse(): CustomResponsePropertyList;
    }
    class BlockPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BlockPropertyOutputReference;
    }
    interface RulesActionCaptchaCustomRequestHandlingInsertHeaderProperty {
    }
    class RulesActionCaptchaCustomRequestHandlingInsertHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RulesActionCaptchaCustomRequestHandlingInsertHeaderProperty | undefined;
        set internalValue(value: RulesActionCaptchaCustomRequestHandlingInsertHeaderProperty | undefined);
        get name(): string;
        get value(): string;
    }
    class RulesActionCaptchaCustomRequestHandlingInsertHeaderPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RulesActionCaptchaCustomRequestHandlingInsertHeaderPropertyOutputReference;
    }
    interface RulesActionCaptchaCustomRequestHandlingProperty {
    }
    class RulesActionCaptchaCustomRequestHandlingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RulesActionCaptchaCustomRequestHandlingProperty | undefined;
        set internalValue(value: RulesActionCaptchaCustomRequestHandlingProperty | undefined);
        private _insertHeader;
        get insertHeader(): RulesActionCaptchaCustomRequestHandlingInsertHeaderPropertyList;
    }
    class RulesActionCaptchaCustomRequestHandlingPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RulesActionCaptchaCustomRequestHandlingPropertyOutputReference;
    }
    interface CaptchaProperty {
    }
    class CaptchaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CaptchaProperty | undefined;
        set internalValue(value: CaptchaProperty | undefined);
        private _customRequestHandling;
        get customRequestHandling(): RulesActionCaptchaCustomRequestHandlingPropertyList;
    }
    class CaptchaPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CaptchaPropertyOutputReference;
    }
    interface RulesActionChallengeCustomRequestHandlingInsertHeaderProperty {
    }
    class RulesActionChallengeCustomRequestHandlingInsertHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RulesActionChallengeCustomRequestHandlingInsertHeaderProperty | undefined;
        set internalValue(value: RulesActionChallengeCustomRequestHandlingInsertHeaderProperty | undefined);
        get name(): string;
        get value(): string;
    }
    class RulesActionChallengeCustomRequestHandlingInsertHeaderPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RulesActionChallengeCustomRequestHandlingInsertHeaderPropertyOutputReference;
    }
    interface RulesActionChallengeCustomRequestHandlingProperty {
    }
    class RulesActionChallengeCustomRequestHandlingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RulesActionChallengeCustomRequestHandlingProperty | undefined;
        set internalValue(value: RulesActionChallengeCustomRequestHandlingProperty | undefined);
        private _insertHeader;
        get insertHeader(): RulesActionChallengeCustomRequestHandlingInsertHeaderPropertyList;
    }
    class RulesActionChallengeCustomRequestHandlingPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RulesActionChallengeCustomRequestHandlingPropertyOutputReference;
    }
    interface ChallengeProperty {
    }
    class ChallengePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ChallengeProperty | undefined;
        set internalValue(value: ChallengeProperty | undefined);
        private _customRequestHandling;
        get customRequestHandling(): RulesActionChallengeCustomRequestHandlingPropertyList;
    }
    class ChallengePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ChallengePropertyOutputReference;
    }
    interface RulesActionCountCustomRequestHandlingInsertHeaderProperty {
    }
    class RulesActionCountCustomRequestHandlingInsertHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RulesActionCountCustomRequestHandlingInsertHeaderProperty | undefined;
        set internalValue(value: RulesActionCountCustomRequestHandlingInsertHeaderProperty | undefined);
        get name(): string;
        get value(): string;
    }
    class RulesActionCountCustomRequestHandlingInsertHeaderPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RulesActionCountCustomRequestHandlingInsertHeaderPropertyOutputReference;
    }
    interface RulesActionCountCustomRequestHandlingProperty {
    }
    class RulesActionCountCustomRequestHandlingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RulesActionCountCustomRequestHandlingProperty | undefined;
        set internalValue(value: RulesActionCountCustomRequestHandlingProperty | undefined);
        private _insertHeader;
        get insertHeader(): RulesActionCountCustomRequestHandlingInsertHeaderPropertyList;
    }
    class RulesActionCountCustomRequestHandlingPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RulesActionCountCustomRequestHandlingPropertyOutputReference;
    }
    interface CountProperty {
    }
    class CountPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CountProperty | undefined;
        set internalValue(value: CountProperty | undefined);
        private _customRequestHandling;
        get customRequestHandling(): RulesActionCountCustomRequestHandlingPropertyList;
    }
    class CountPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CountPropertyOutputReference;
    }
    interface ActionProperty {
    }
    class ActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ActionProperty | undefined;
        set internalValue(value: ActionProperty | undefined);
        private _allow;
        get allow(): AllowPropertyList;
        private _block;
        get block(): BlockPropertyList;
        private _captcha;
        get captcha(): CaptchaPropertyList;
        private _challenge;
        get challenge(): ChallengePropertyList;
        private _count;
        get count(): CountPropertyList;
    }
    class ActionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ActionPropertyOutputReference;
    }
    interface RulesProperty {
    }
    class RulesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RulesProperty | undefined;
        set internalValue(value: RulesProperty | undefined);
        private _action;
        get action(): ActionPropertyList;
        get name(): string;
    }
    class RulesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RulesPropertyOutputReference;
    }
}
