import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsThemeConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/quicksight_theme#aws_account_id DataAwsTheme#aws_account_id}
    */
    readonly awsAccountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/quicksight_theme#id DataAwsTheme#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/quicksight_theme#region DataAwsTheme#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/quicksight_theme#tags DataAwsTheme#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/quicksight_theme#theme_id DataAwsTheme#theme_id}
    */
    readonly themeId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/quicksight_theme aws_quicksight_theme}
*/
export declare class DataAwsTheme extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_quicksight_theme";
    /**
    * Generates CDKTN code for importing a DataAwsTheme resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsTheme to import
    * @param importFromId The id of the existing DataAwsTheme that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/quicksight_theme#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsTheme to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/quicksight_theme aws_quicksight_theme} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsThemeConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsThemeConfig);
    get arn(): string;
    private _awsAccountId?;
    get awsAccountId(): string;
    set awsAccountId(value: string);
    resetAwsAccountId(): void;
    get awsAccountIdInput(): string | undefined;
    get baseThemeId(): string;
    private _configuration;
    get configuration(): DataAwsTheme.ConfigurationPropertyList;
    get createdTime(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastUpdatedTime(): string;
    get name(): string;
    private _permissions;
    get permissions(): DataAwsTheme.PermissionsPropertyList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _themeId?;
    get themeId(): string;
    set themeId(value: string);
    get themeIdInput(): string | undefined;
    get versionDescription(): string;
    get versionNumber(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsThemeDataColorPalettePropertyToTerraform(struct?: DataAwsTheme.DataColorPaletteProperty): any;
export declare function dataAwsThemeDataColorPalettePropertyToHclTerraform(struct?: DataAwsTheme.DataColorPaletteProperty): any;
export declare function dataAwsThemeBorderPropertyToTerraform(struct?: DataAwsTheme.BorderProperty): any;
export declare function dataAwsThemeBorderPropertyToHclTerraform(struct?: DataAwsTheme.BorderProperty): any;
export declare function dataAwsThemeTilePropertyToTerraform(struct?: DataAwsTheme.TileProperty): any;
export declare function dataAwsThemeTilePropertyToHclTerraform(struct?: DataAwsTheme.TileProperty): any;
export declare function dataAwsThemeGutterPropertyToTerraform(struct?: DataAwsTheme.GutterProperty): any;
export declare function dataAwsThemeGutterPropertyToHclTerraform(struct?: DataAwsTheme.GutterProperty): any;
export declare function dataAwsThemeMarginPropertyToTerraform(struct?: DataAwsTheme.MarginProperty): any;
export declare function dataAwsThemeMarginPropertyToHclTerraform(struct?: DataAwsTheme.MarginProperty): any;
export declare function dataAwsThemeTileLayoutPropertyToTerraform(struct?: DataAwsTheme.TileLayoutProperty): any;
export declare function dataAwsThemeTileLayoutPropertyToHclTerraform(struct?: DataAwsTheme.TileLayoutProperty): any;
export declare function dataAwsThemeSheetPropertyToTerraform(struct?: DataAwsTheme.SheetProperty): any;
export declare function dataAwsThemeSheetPropertyToHclTerraform(struct?: DataAwsTheme.SheetProperty): any;
export declare function dataAwsThemeFontFamiliesPropertyToTerraform(struct?: DataAwsTheme.FontFamiliesProperty): any;
export declare function dataAwsThemeFontFamiliesPropertyToHclTerraform(struct?: DataAwsTheme.FontFamiliesProperty): any;
export declare function dataAwsThemeTypographyPropertyToTerraform(struct?: DataAwsTheme.TypographyProperty): any;
export declare function dataAwsThemeTypographyPropertyToHclTerraform(struct?: DataAwsTheme.TypographyProperty): any;
export declare function dataAwsThemeUiColorPalettePropertyToTerraform(struct?: DataAwsTheme.UiColorPaletteProperty): any;
export declare function dataAwsThemeUiColorPalettePropertyToHclTerraform(struct?: DataAwsTheme.UiColorPaletteProperty): any;
export declare function dataAwsThemeConfigurationPropertyToTerraform(struct?: DataAwsTheme.ConfigurationProperty): any;
export declare function dataAwsThemeConfigurationPropertyToHclTerraform(struct?: DataAwsTheme.ConfigurationProperty): any;
export declare function dataAwsThemePermissionsPropertyToTerraform(struct?: DataAwsTheme.PermissionsProperty): any;
export declare function dataAwsThemePermissionsPropertyToHclTerraform(struct?: DataAwsTheme.PermissionsProperty): any;
export declare namespace DataAwsTheme {
    interface DataColorPaletteProperty {
    }
    class DataColorPalettePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataColorPaletteProperty | undefined;
        set internalValue(value: DataColorPaletteProperty | undefined);
        get colors(): string[];
        get emptyFillColor(): string;
        get minMaxGradient(): string[];
    }
    class DataColorPalettePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataColorPalettePropertyOutputReference;
    }
    interface BorderProperty {
    }
    class BorderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BorderProperty | undefined;
        set internalValue(value: BorderProperty | undefined);
        get show(): cdktn.IResolvable;
    }
    class BorderPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BorderPropertyOutputReference;
    }
    interface TileProperty {
    }
    class TilePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TileProperty | undefined;
        set internalValue(value: TileProperty | undefined);
        private _border;
        get border(): BorderPropertyList;
    }
    class TilePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TilePropertyOutputReference;
    }
    interface GutterProperty {
    }
    class GutterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GutterProperty | undefined;
        set internalValue(value: GutterProperty | undefined);
        get show(): cdktn.IResolvable;
    }
    class GutterPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GutterPropertyOutputReference;
    }
    interface MarginProperty {
    }
    class MarginPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MarginProperty | undefined;
        set internalValue(value: MarginProperty | undefined);
        get show(): cdktn.IResolvable;
    }
    class MarginPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MarginPropertyOutputReference;
    }
    interface TileLayoutProperty {
    }
    class TileLayoutPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TileLayoutProperty | undefined;
        set internalValue(value: TileLayoutProperty | undefined);
        private _gutter;
        get gutter(): GutterPropertyList;
        private _margin;
        get margin(): MarginPropertyList;
    }
    class TileLayoutPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TileLayoutPropertyOutputReference;
    }
    interface SheetProperty {
    }
    class SheetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SheetProperty | undefined;
        set internalValue(value: SheetProperty | undefined);
        private _tile;
        get tile(): TilePropertyList;
        private _tileLayout;
        get tileLayout(): TileLayoutPropertyList;
    }
    class SheetPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SheetPropertyOutputReference;
    }
    interface FontFamiliesProperty {
    }
    class FontFamiliesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FontFamiliesProperty | undefined;
        set internalValue(value: FontFamiliesProperty | undefined);
        get fontFamily(): string;
    }
    class FontFamiliesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FontFamiliesPropertyOutputReference;
    }
    interface TypographyProperty {
    }
    class TypographyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TypographyProperty | undefined;
        set internalValue(value: TypographyProperty | undefined);
        private _fontFamilies;
        get fontFamilies(): FontFamiliesPropertyList;
    }
    class TypographyPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TypographyPropertyOutputReference;
    }
    interface UiColorPaletteProperty {
    }
    class UiColorPalettePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): UiColorPaletteProperty | undefined;
        set internalValue(value: UiColorPaletteProperty | undefined);
        get accent(): string;
        get accentForeground(): string;
        get danger(): string;
        get dangerForeground(): string;
        get dimension(): string;
        get dimensionForeground(): string;
        get measure(): string;
        get measureForeground(): string;
        get primaryBackground(): string;
        get primaryForeground(): string;
        get secondaryBackground(): string;
        get secondaryForeground(): string;
        get success(): string;
        get successForeground(): string;
        get warning(): string;
        get warningForeground(): string;
    }
    class UiColorPalettePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): UiColorPalettePropertyOutputReference;
    }
    interface ConfigurationProperty {
    }
    class ConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConfigurationProperty | undefined;
        set internalValue(value: ConfigurationProperty | undefined);
        private _dataColorPalette;
        get dataColorPalette(): DataColorPalettePropertyList;
        private _sheet;
        get sheet(): SheetPropertyList;
        private _typography;
        get typography(): TypographyPropertyList;
        private _uiColorPalette;
        get uiColorPalette(): UiColorPalettePropertyList;
    }
    class ConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConfigurationPropertyOutputReference;
    }
    interface PermissionsProperty {
    }
    class PermissionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PermissionsProperty | undefined;
        set internalValue(value: PermissionsProperty | undefined);
        get actions(): string[];
        get principal(): string;
    }
    class PermissionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PermissionsPropertyOutputReference;
    }
}
