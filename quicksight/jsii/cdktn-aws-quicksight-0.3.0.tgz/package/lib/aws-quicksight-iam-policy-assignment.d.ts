import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsIamPolicyAssignmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_iam_policy_assignment#assignment_name AwsIamPolicyAssignment#assignment_name}
    */
    readonly assignmentName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_iam_policy_assignment#assignment_status AwsIamPolicyAssignment#assignment_status}
    */
    readonly assignmentStatus: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_iam_policy_assignment#aws_account_id AwsIamPolicyAssignment#aws_account_id}
    */
    readonly awsAccountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_iam_policy_assignment#namespace AwsIamPolicyAssignment#namespace}
    */
    readonly namespace?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_iam_policy_assignment#policy_arn AwsIamPolicyAssignment#policy_arn}
    */
    readonly policyArn?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_iam_policy_assignment#region AwsIamPolicyAssignment#region}
    */
    readonly region?: string;
    /**
    * identities block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_iam_policy_assignment#identities AwsIamPolicyAssignment#identities}
    */
    readonly identities?: AwsIamPolicyAssignment.IdentitiesProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_iam_policy_assignment aws_quicksight_iam_policy_assignment}
*/
export declare class AwsIamPolicyAssignment extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_quicksight_iam_policy_assignment";
    /**
    * Generates CDKTN code for importing a AwsIamPolicyAssignment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsIamPolicyAssignment to import
    * @param importFromId The id of the existing AwsIamPolicyAssignment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_iam_policy_assignment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsIamPolicyAssignment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_iam_policy_assignment aws_quicksight_iam_policy_assignment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsIamPolicyAssignmentConfig
    */
    constructor(scope: Construct, id: string, config: AwsIamPolicyAssignmentConfig);
    get assignmentId(): string;
    private _assignmentName?;
    get assignmentName(): string;
    set assignmentName(value: string);
    get assignmentNameInput(): string | undefined;
    private _assignmentStatus?;
    get assignmentStatus(): string;
    set assignmentStatus(value: string);
    get assignmentStatusInput(): string | undefined;
    private _awsAccountId?;
    get awsAccountId(): string;
    set awsAccountId(value: string);
    resetAwsAccountId(): void;
    get awsAccountIdInput(): string | undefined;
    get id(): string;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _policyArn?;
    get policyArn(): string;
    set policyArn(value: string);
    resetPolicyArn(): void;
    get policyArnInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _identities;
    get identities(): AwsIamPolicyAssignment.IdentitiesPropertyList;
    putIdentities(value: AwsIamPolicyAssignment.IdentitiesProperty[] | cdktn.IResolvable): void;
    resetIdentities(): void;
    get identitiesInput(): cdktn.IResolvable | AwsIamPolicyAssignment.IdentitiesProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsIamPolicyAssignmentIdentitiesPropertyToTerraform(struct?: AwsIamPolicyAssignment.IdentitiesProperty | cdktn.IResolvable): any;
export declare function awsIamPolicyAssignmentIdentitiesPropertyToHclTerraform(struct?: AwsIamPolicyAssignment.IdentitiesProperty | cdktn.IResolvable): any;
export declare namespace AwsIamPolicyAssignment {
    interface IdentitiesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_iam_policy_assignment#group AwsIamPolicyAssignment#group}
        */
        readonly group?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_iam_policy_assignment#user AwsIamPolicyAssignment#user}
        */
        readonly user?: string[];
    }
    class IdentitiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IdentitiesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IdentitiesProperty | cdktn.IResolvable | undefined);
        private _group?;
        get group(): string[];
        set group(value: string[]);
        resetGroup(): void;
        get groupInput(): string[] | undefined;
        private _user?;
        get user(): string[];
        set user(value: string[]);
        resetUser(): void;
        get userInput(): string[] | undefined;
    }
    class IdentitiesPropertyList extends cdktn.ComplexList {
        internalValue?: IdentitiesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IdentitiesPropertyOutputReference;
    }
}
