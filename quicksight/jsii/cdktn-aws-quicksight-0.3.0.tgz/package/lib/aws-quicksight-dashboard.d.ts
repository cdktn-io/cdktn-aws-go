import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDashboardConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#aws_account_id AwsDashboard#aws_account_id}
    */
    readonly awsAccountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#dashboard_id AwsDashboard#dashboard_id}
    */
    readonly dashboardId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#id AwsDashboard#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#name AwsDashboard#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#region AwsDashboard#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#tags AwsDashboard#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#tags_all AwsDashboard#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#theme_arn AwsDashboard#theme_arn}
    */
    readonly themeArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#version_description AwsDashboard#version_description}
    */
    readonly versionDescription: string;
    /**
    * dashboard_publish_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#dashboard_publish_options AwsDashboard#dashboard_publish_options}
    */
    readonly dashboardPublishOptions?: AwsDashboard.DashboardPublishOptionsProperty;
    /**
    * definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#definition AwsDashboard#definition}
    */
    readonly definition?: any;
    /**
    * parameters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#parameters AwsDashboard#parameters}
    */
    readonly parameters?: AwsDashboard.ParametersProperty;
    /**
    * permissions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#permissions AwsDashboard#permissions}
    */
    readonly permissions?: AwsDashboard.PermissionsProperty[] | cdktn.IResolvable;
    /**
    * source_entity block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#source_entity AwsDashboard#source_entity}
    */
    readonly sourceEntity?: AwsDashboard.SourceEntityProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#timeouts AwsDashboard#timeouts}
    */
    readonly timeouts?: AwsDashboard.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard aws_quicksight_dashboard}
*/
export declare class AwsDashboard extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_quicksight_dashboard";
    /**
    * Generates CDKTN code for importing a AwsDashboard resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDashboard to import
    * @param importFromId The id of the existing AwsDashboard that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDashboard to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard aws_quicksight_dashboard} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDashboardConfig
    */
    constructor(scope: Construct, id: string, config: AwsDashboardConfig);
    get arn(): string;
    private _awsAccountId?;
    get awsAccountId(): string;
    set awsAccountId(value: string);
    resetAwsAccountId(): void;
    get awsAccountIdInput(): string | undefined;
    get createdTime(): string;
    private _dashboardId?;
    get dashboardId(): string;
    set dashboardId(value: string);
    get dashboardIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastPublishedTime(): string;
    get lastUpdatedTime(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get sourceEntityArn(): string;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _themeArn?;
    get themeArn(): string;
    set themeArn(value: string);
    resetThemeArn(): void;
    get themeArnInput(): string | undefined;
    private _versionDescription?;
    get versionDescription(): string;
    set versionDescription(value: string);
    get versionDescriptionInput(): string | undefined;
    get versionNumber(): number;
    private _dashboardPublishOptions;
    get dashboardPublishOptions(): AwsDashboard.DashboardPublishOptionsPropertyOutputReference;
    putDashboardPublishOptions(value: AwsDashboard.DashboardPublishOptionsProperty): void;
    resetDashboardPublishOptions(): void;
    get dashboardPublishOptionsInput(): AwsDashboard.DashboardPublishOptionsProperty | undefined;
    private _definition?;
    get definition(): any;
    set definition(value: any);
    resetDefinition(): void;
    get definitionInput(): any;
    private _parameters;
    get parameters(): AwsDashboard.ParametersPropertyOutputReference;
    putParameters(value: AwsDashboard.ParametersProperty): void;
    resetParameters(): void;
    get parametersInput(): AwsDashboard.ParametersProperty | undefined;
    private _permissions;
    get permissions(): AwsDashboard.PermissionsPropertyList;
    putPermissions(value: AwsDashboard.PermissionsProperty[] | cdktn.IResolvable): void;
    resetPermissions(): void;
    get permissionsInput(): cdktn.IResolvable | AwsDashboard.PermissionsProperty[] | undefined;
    private _sourceEntity;
    get sourceEntity(): AwsDashboard.SourceEntityPropertyOutputReference;
    putSourceEntity(value: AwsDashboard.SourceEntityProperty): void;
    resetSourceEntity(): void;
    get sourceEntityInput(): AwsDashboard.SourceEntityProperty | undefined;
    private _timeouts;
    get timeouts(): AwsDashboard.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsDashboard.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsDashboard.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsDashboardAdHocFilteringOptionPropertyToTerraform(struct?: AwsDashboard.AdHocFilteringOptionPropertyOutputReference | AwsDashboard.AdHocFilteringOptionProperty): any;
export declare function awsDashboardAdHocFilteringOptionPropertyToHclTerraform(struct?: AwsDashboard.AdHocFilteringOptionPropertyOutputReference | AwsDashboard.AdHocFilteringOptionProperty): any;
export declare function awsDashboardDataPointDrillUpDownOptionPropertyToTerraform(struct?: AwsDashboard.DataPointDrillUpDownOptionPropertyOutputReference | AwsDashboard.DataPointDrillUpDownOptionProperty): any;
export declare function awsDashboardDataPointDrillUpDownOptionPropertyToHclTerraform(struct?: AwsDashboard.DataPointDrillUpDownOptionPropertyOutputReference | AwsDashboard.DataPointDrillUpDownOptionProperty): any;
export declare function awsDashboardDataPointMenuLabelOptionPropertyToTerraform(struct?: AwsDashboard.DataPointMenuLabelOptionPropertyOutputReference | AwsDashboard.DataPointMenuLabelOptionProperty): any;
export declare function awsDashboardDataPointMenuLabelOptionPropertyToHclTerraform(struct?: AwsDashboard.DataPointMenuLabelOptionPropertyOutputReference | AwsDashboard.DataPointMenuLabelOptionProperty): any;
export declare function awsDashboardDataPointTooltipOptionPropertyToTerraform(struct?: AwsDashboard.DataPointTooltipOptionPropertyOutputReference | AwsDashboard.DataPointTooltipOptionProperty): any;
export declare function awsDashboardDataPointTooltipOptionPropertyToHclTerraform(struct?: AwsDashboard.DataPointTooltipOptionPropertyOutputReference | AwsDashboard.DataPointTooltipOptionProperty): any;
export declare function awsDashboardExportToCsvOptionPropertyToTerraform(struct?: AwsDashboard.ExportToCsvOptionPropertyOutputReference | AwsDashboard.ExportToCsvOptionProperty): any;
export declare function awsDashboardExportToCsvOptionPropertyToHclTerraform(struct?: AwsDashboard.ExportToCsvOptionPropertyOutputReference | AwsDashboard.ExportToCsvOptionProperty): any;
export declare function awsDashboardExportWithHiddenFieldsOptionPropertyToTerraform(struct?: AwsDashboard.ExportWithHiddenFieldsOptionPropertyOutputReference | AwsDashboard.ExportWithHiddenFieldsOptionProperty): any;
export declare function awsDashboardExportWithHiddenFieldsOptionPropertyToHclTerraform(struct?: AwsDashboard.ExportWithHiddenFieldsOptionPropertyOutputReference | AwsDashboard.ExportWithHiddenFieldsOptionProperty): any;
export declare function awsDashboardSheetControlsOptionPropertyToTerraform(struct?: AwsDashboard.SheetControlsOptionPropertyOutputReference | AwsDashboard.SheetControlsOptionProperty): any;
export declare function awsDashboardSheetControlsOptionPropertyToHclTerraform(struct?: AwsDashboard.SheetControlsOptionPropertyOutputReference | AwsDashboard.SheetControlsOptionProperty): any;
export declare function awsDashboardSheetLayoutElementMaximizationOptionPropertyToTerraform(struct?: AwsDashboard.SheetLayoutElementMaximizationOptionPropertyOutputReference | AwsDashboard.SheetLayoutElementMaximizationOptionProperty): any;
export declare function awsDashboardSheetLayoutElementMaximizationOptionPropertyToHclTerraform(struct?: AwsDashboard.SheetLayoutElementMaximizationOptionPropertyOutputReference | AwsDashboard.SheetLayoutElementMaximizationOptionProperty): any;
export declare function awsDashboardVisualAxisSortOptionPropertyToTerraform(struct?: AwsDashboard.VisualAxisSortOptionPropertyOutputReference | AwsDashboard.VisualAxisSortOptionProperty): any;
export declare function awsDashboardVisualAxisSortOptionPropertyToHclTerraform(struct?: AwsDashboard.VisualAxisSortOptionPropertyOutputReference | AwsDashboard.VisualAxisSortOptionProperty): any;
export declare function awsDashboardVisualMenuOptionPropertyToTerraform(struct?: AwsDashboard.VisualMenuOptionPropertyOutputReference | AwsDashboard.VisualMenuOptionProperty): any;
export declare function awsDashboardVisualMenuOptionPropertyToHclTerraform(struct?: AwsDashboard.VisualMenuOptionPropertyOutputReference | AwsDashboard.VisualMenuOptionProperty): any;
export declare function awsDashboardDashboardPublishOptionsPropertyToTerraform(struct?: AwsDashboard.DashboardPublishOptionsPropertyOutputReference | AwsDashboard.DashboardPublishOptionsProperty): any;
export declare function awsDashboardDashboardPublishOptionsPropertyToHclTerraform(struct?: AwsDashboard.DashboardPublishOptionsPropertyOutputReference | AwsDashboard.DashboardPublishOptionsProperty): any;
export declare function awsDashboardDateTimeParametersPropertyToTerraform(struct?: AwsDashboard.DateTimeParametersProperty | cdktn.IResolvable): any;
export declare function awsDashboardDateTimeParametersPropertyToHclTerraform(struct?: AwsDashboard.DateTimeParametersProperty | cdktn.IResolvable): any;
export declare function awsDashboardDecimalParametersPropertyToTerraform(struct?: AwsDashboard.DecimalParametersProperty | cdktn.IResolvable): any;
export declare function awsDashboardDecimalParametersPropertyToHclTerraform(struct?: AwsDashboard.DecimalParametersProperty | cdktn.IResolvable): any;
export declare function awsDashboardIntegerParametersPropertyToTerraform(struct?: AwsDashboard.IntegerParametersProperty | cdktn.IResolvable): any;
export declare function awsDashboardIntegerParametersPropertyToHclTerraform(struct?: AwsDashboard.IntegerParametersProperty | cdktn.IResolvable): any;
export declare function awsDashboardStringParametersPropertyToTerraform(struct?: AwsDashboard.StringParametersProperty | cdktn.IResolvable): any;
export declare function awsDashboardStringParametersPropertyToHclTerraform(struct?: AwsDashboard.StringParametersProperty | cdktn.IResolvable): any;
export declare function awsDashboardParametersPropertyToTerraform(struct?: AwsDashboard.ParametersPropertyOutputReference | AwsDashboard.ParametersProperty): any;
export declare function awsDashboardParametersPropertyToHclTerraform(struct?: AwsDashboard.ParametersPropertyOutputReference | AwsDashboard.ParametersProperty): any;
export declare function awsDashboardPermissionsPropertyToTerraform(struct?: AwsDashboard.PermissionsProperty | cdktn.IResolvable): any;
export declare function awsDashboardPermissionsPropertyToHclTerraform(struct?: AwsDashboard.PermissionsProperty | cdktn.IResolvable): any;
export declare function awsDashboardDataSetReferencesPropertyToTerraform(struct?: AwsDashboard.DataSetReferencesProperty | cdktn.IResolvable): any;
export declare function awsDashboardDataSetReferencesPropertyToHclTerraform(struct?: AwsDashboard.DataSetReferencesProperty | cdktn.IResolvable): any;
export declare function awsDashboardSourceTemplatePropertyToTerraform(struct?: AwsDashboard.SourceTemplatePropertyOutputReference | AwsDashboard.SourceTemplateProperty): any;
export declare function awsDashboardSourceTemplatePropertyToHclTerraform(struct?: AwsDashboard.SourceTemplatePropertyOutputReference | AwsDashboard.SourceTemplateProperty): any;
export declare function awsDashboardSourceEntityPropertyToTerraform(struct?: AwsDashboard.SourceEntityPropertyOutputReference | AwsDashboard.SourceEntityProperty): any;
export declare function awsDashboardSourceEntityPropertyToHclTerraform(struct?: AwsDashboard.SourceEntityPropertyOutputReference | AwsDashboard.SourceEntityProperty): any;
export declare function awsDashboardTimeoutsPropertyToTerraform(struct?: AwsDashboard.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsDashboardTimeoutsPropertyToHclTerraform(struct?: AwsDashboard.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsDashboard {
    interface AdHocFilteringOptionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#availability_status AwsDashboard#availability_status}
        */
        readonly availabilityStatus?: string;
    }
    class AdHocFilteringOptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AdHocFilteringOptionProperty | undefined;
        set internalValue(value: AdHocFilteringOptionProperty | undefined);
        private _availabilityStatus?;
        get availabilityStatus(): string;
        set availabilityStatus(value: string);
        resetAvailabilityStatus(): void;
        get availabilityStatusInput(): string | undefined;
    }
    interface DataPointDrillUpDownOptionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#availability_status AwsDashboard#availability_status}
        */
        readonly availabilityStatus?: string;
    }
    class DataPointDrillUpDownOptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DataPointDrillUpDownOptionProperty | undefined;
        set internalValue(value: DataPointDrillUpDownOptionProperty | undefined);
        private _availabilityStatus?;
        get availabilityStatus(): string;
        set availabilityStatus(value: string);
        resetAvailabilityStatus(): void;
        get availabilityStatusInput(): string | undefined;
    }
    interface DataPointMenuLabelOptionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#availability_status AwsDashboard#availability_status}
        */
        readonly availabilityStatus?: string;
    }
    class DataPointMenuLabelOptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DataPointMenuLabelOptionProperty | undefined;
        set internalValue(value: DataPointMenuLabelOptionProperty | undefined);
        private _availabilityStatus?;
        get availabilityStatus(): string;
        set availabilityStatus(value: string);
        resetAvailabilityStatus(): void;
        get availabilityStatusInput(): string | undefined;
    }
    interface DataPointTooltipOptionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#availability_status AwsDashboard#availability_status}
        */
        readonly availabilityStatus?: string;
    }
    class DataPointTooltipOptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DataPointTooltipOptionProperty | undefined;
        set internalValue(value: DataPointTooltipOptionProperty | undefined);
        private _availabilityStatus?;
        get availabilityStatus(): string;
        set availabilityStatus(value: string);
        resetAvailabilityStatus(): void;
        get availabilityStatusInput(): string | undefined;
    }
    interface ExportToCsvOptionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#availability_status AwsDashboard#availability_status}
        */
        readonly availabilityStatus?: string;
    }
    class ExportToCsvOptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ExportToCsvOptionProperty | undefined;
        set internalValue(value: ExportToCsvOptionProperty | undefined);
        private _availabilityStatus?;
        get availabilityStatus(): string;
        set availabilityStatus(value: string);
        resetAvailabilityStatus(): void;
        get availabilityStatusInput(): string | undefined;
    }
    interface ExportWithHiddenFieldsOptionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#availability_status AwsDashboard#availability_status}
        */
        readonly availabilityStatus?: string;
    }
    class ExportWithHiddenFieldsOptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ExportWithHiddenFieldsOptionProperty | undefined;
        set internalValue(value: ExportWithHiddenFieldsOptionProperty | undefined);
        private _availabilityStatus?;
        get availabilityStatus(): string;
        set availabilityStatus(value: string);
        resetAvailabilityStatus(): void;
        get availabilityStatusInput(): string | undefined;
    }
    interface SheetControlsOptionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#visibility_state AwsDashboard#visibility_state}
        */
        readonly visibilityState?: string;
    }
    class SheetControlsOptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SheetControlsOptionProperty | undefined;
        set internalValue(value: SheetControlsOptionProperty | undefined);
        private _visibilityState?;
        get visibilityState(): string;
        set visibilityState(value: string);
        resetVisibilityState(): void;
        get visibilityStateInput(): string | undefined;
    }
    interface SheetLayoutElementMaximizationOptionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#availability_status AwsDashboard#availability_status}
        */
        readonly availabilityStatus?: string;
    }
    class SheetLayoutElementMaximizationOptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SheetLayoutElementMaximizationOptionProperty | undefined;
        set internalValue(value: SheetLayoutElementMaximizationOptionProperty | undefined);
        private _availabilityStatus?;
        get availabilityStatus(): string;
        set availabilityStatus(value: string);
        resetAvailabilityStatus(): void;
        get availabilityStatusInput(): string | undefined;
    }
    interface VisualAxisSortOptionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#availability_status AwsDashboard#availability_status}
        */
        readonly availabilityStatus?: string;
    }
    class VisualAxisSortOptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VisualAxisSortOptionProperty | undefined;
        set internalValue(value: VisualAxisSortOptionProperty | undefined);
        private _availabilityStatus?;
        get availabilityStatus(): string;
        set availabilityStatus(value: string);
        resetAvailabilityStatus(): void;
        get availabilityStatusInput(): string | undefined;
    }
    interface VisualMenuOptionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#availability_status AwsDashboard#availability_status}
        */
        readonly availabilityStatus?: string;
    }
    class VisualMenuOptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VisualMenuOptionProperty | undefined;
        set internalValue(value: VisualMenuOptionProperty | undefined);
        private _availabilityStatus?;
        get availabilityStatus(): string;
        set availabilityStatus(value: string);
        resetAvailabilityStatus(): void;
        get availabilityStatusInput(): string | undefined;
    }
    interface DashboardPublishOptionsProperty {
        /**
        * ad_hoc_filtering_option block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#ad_hoc_filtering_option AwsDashboard#ad_hoc_filtering_option}
        */
        readonly adHocFilteringOption?: AdHocFilteringOptionProperty;
        /**
        * data_point_drill_up_down_option block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#data_point_drill_up_down_option AwsDashboard#data_point_drill_up_down_option}
        */
        readonly dataPointDrillUpDownOption?: DataPointDrillUpDownOptionProperty;
        /**
        * data_point_menu_label_option block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#data_point_menu_label_option AwsDashboard#data_point_menu_label_option}
        */
        readonly dataPointMenuLabelOption?: DataPointMenuLabelOptionProperty;
        /**
        * data_point_tooltip_option block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#data_point_tooltip_option AwsDashboard#data_point_tooltip_option}
        */
        readonly dataPointTooltipOption?: DataPointTooltipOptionProperty;
        /**
        * export_to_csv_option block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#export_to_csv_option AwsDashboard#export_to_csv_option}
        */
        readonly exportToCsvOption?: ExportToCsvOptionProperty;
        /**
        * export_with_hidden_fields_option block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#export_with_hidden_fields_option AwsDashboard#export_with_hidden_fields_option}
        */
        readonly exportWithHiddenFieldsOption?: ExportWithHiddenFieldsOptionProperty;
        /**
        * sheet_controls_option block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#sheet_controls_option AwsDashboard#sheet_controls_option}
        */
        readonly sheetControlsOption?: SheetControlsOptionProperty;
        /**
        * sheet_layout_element_maximization_option block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#sheet_layout_element_maximization_option AwsDashboard#sheet_layout_element_maximization_option}
        */
        readonly sheetLayoutElementMaximizationOption?: SheetLayoutElementMaximizationOptionProperty;
        /**
        * visual_axis_sort_option block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#visual_axis_sort_option AwsDashboard#visual_axis_sort_option}
        */
        readonly visualAxisSortOption?: VisualAxisSortOptionProperty;
        /**
        * visual_menu_option block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#visual_menu_option AwsDashboard#visual_menu_option}
        */
        readonly visualMenuOption?: VisualMenuOptionProperty;
    }
    class DashboardPublishOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DashboardPublishOptionsProperty | undefined;
        set internalValue(value: DashboardPublishOptionsProperty | undefined);
        private _adHocFilteringOption;
        get adHocFilteringOption(): AdHocFilteringOptionPropertyOutputReference;
        putAdHocFilteringOption(value: AdHocFilteringOptionProperty): void;
        resetAdHocFilteringOption(): void;
        get adHocFilteringOptionInput(): AdHocFilteringOptionProperty | undefined;
        private _dataPointDrillUpDownOption;
        get dataPointDrillUpDownOption(): DataPointDrillUpDownOptionPropertyOutputReference;
        putDataPointDrillUpDownOption(value: DataPointDrillUpDownOptionProperty): void;
        resetDataPointDrillUpDownOption(): void;
        get dataPointDrillUpDownOptionInput(): DataPointDrillUpDownOptionProperty | undefined;
        private _dataPointMenuLabelOption;
        get dataPointMenuLabelOption(): DataPointMenuLabelOptionPropertyOutputReference;
        putDataPointMenuLabelOption(value: DataPointMenuLabelOptionProperty): void;
        resetDataPointMenuLabelOption(): void;
        get dataPointMenuLabelOptionInput(): DataPointMenuLabelOptionProperty | undefined;
        private _dataPointTooltipOption;
        get dataPointTooltipOption(): DataPointTooltipOptionPropertyOutputReference;
        putDataPointTooltipOption(value: DataPointTooltipOptionProperty): void;
        resetDataPointTooltipOption(): void;
        get dataPointTooltipOptionInput(): DataPointTooltipOptionProperty | undefined;
        private _exportToCsvOption;
        get exportToCsvOption(): ExportToCsvOptionPropertyOutputReference;
        putExportToCsvOption(value: ExportToCsvOptionProperty): void;
        resetExportToCsvOption(): void;
        get exportToCsvOptionInput(): ExportToCsvOptionProperty | undefined;
        private _exportWithHiddenFieldsOption;
        get exportWithHiddenFieldsOption(): ExportWithHiddenFieldsOptionPropertyOutputReference;
        putExportWithHiddenFieldsOption(value: ExportWithHiddenFieldsOptionProperty): void;
        resetExportWithHiddenFieldsOption(): void;
        get exportWithHiddenFieldsOptionInput(): ExportWithHiddenFieldsOptionProperty | undefined;
        private _sheetControlsOption;
        get sheetControlsOption(): SheetControlsOptionPropertyOutputReference;
        putSheetControlsOption(value: SheetControlsOptionProperty): void;
        resetSheetControlsOption(): void;
        get sheetControlsOptionInput(): SheetControlsOptionProperty | undefined;
        private _sheetLayoutElementMaximizationOption;
        get sheetLayoutElementMaximizationOption(): SheetLayoutElementMaximizationOptionPropertyOutputReference;
        putSheetLayoutElementMaximizationOption(value: SheetLayoutElementMaximizationOptionProperty): void;
        resetSheetLayoutElementMaximizationOption(): void;
        get sheetLayoutElementMaximizationOptionInput(): SheetLayoutElementMaximizationOptionProperty | undefined;
        private _visualAxisSortOption;
        get visualAxisSortOption(): VisualAxisSortOptionPropertyOutputReference;
        putVisualAxisSortOption(value: VisualAxisSortOptionProperty): void;
        resetVisualAxisSortOption(): void;
        get visualAxisSortOptionInput(): VisualAxisSortOptionProperty | undefined;
        private _visualMenuOption;
        get visualMenuOption(): VisualMenuOptionPropertyOutputReference;
        putVisualMenuOption(value: VisualMenuOptionProperty): void;
        resetVisualMenuOption(): void;
        get visualMenuOptionInput(): VisualMenuOptionProperty | undefined;
    }
    interface DateTimeParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#name AwsDashboard#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#values AwsDashboard#values}
        */
        readonly values: string[];
    }
    class DateTimeParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DateTimeParametersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DateTimeParametersProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class DateTimeParametersPropertyList extends cdktn.ComplexList {
        internalValue?: DateTimeParametersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DateTimeParametersPropertyOutputReference;
    }
    interface DecimalParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#name AwsDashboard#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#values AwsDashboard#values}
        */
        readonly values: number[];
    }
    class DecimalParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DecimalParametersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DecimalParametersProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _values?;
        get values(): number[];
        set values(value: number[]);
        get valuesInput(): number[] | undefined;
    }
    class DecimalParametersPropertyList extends cdktn.ComplexList {
        internalValue?: DecimalParametersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DecimalParametersPropertyOutputReference;
    }
    interface IntegerParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#name AwsDashboard#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#values AwsDashboard#values}
        */
        readonly values: number[];
    }
    class IntegerParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IntegerParametersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IntegerParametersProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _values?;
        get values(): number[];
        set values(value: number[]);
        get valuesInput(): number[] | undefined;
    }
    class IntegerParametersPropertyList extends cdktn.ComplexList {
        internalValue?: IntegerParametersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IntegerParametersPropertyOutputReference;
    }
    interface StringParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#name AwsDashboard#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#values AwsDashboard#values}
        */
        readonly values: string[];
    }
    class StringParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StringParametersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StringParametersProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class StringParametersPropertyList extends cdktn.ComplexList {
        internalValue?: StringParametersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StringParametersPropertyOutputReference;
    }
    interface ParametersProperty {
        /**
        * date_time_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#date_time_parameters AwsDashboard#date_time_parameters}
        */
        readonly dateTimeParameters?: DateTimeParametersProperty[] | cdktn.IResolvable;
        /**
        * decimal_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#decimal_parameters AwsDashboard#decimal_parameters}
        */
        readonly decimalParameters?: DecimalParametersProperty[] | cdktn.IResolvable;
        /**
        * integer_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#integer_parameters AwsDashboard#integer_parameters}
        */
        readonly integerParameters?: IntegerParametersProperty[] | cdktn.IResolvable;
        /**
        * string_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#string_parameters AwsDashboard#string_parameters}
        */
        readonly stringParameters?: StringParametersProperty[] | cdktn.IResolvable;
    }
    class ParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ParametersProperty | undefined;
        set internalValue(value: ParametersProperty | undefined);
        private _dateTimeParameters;
        get dateTimeParameters(): DateTimeParametersPropertyList;
        putDateTimeParameters(value: DateTimeParametersProperty[] | cdktn.IResolvable): void;
        resetDateTimeParameters(): void;
        get dateTimeParametersInput(): cdktn.IResolvable | DateTimeParametersProperty[] | undefined;
        private _decimalParameters;
        get decimalParameters(): DecimalParametersPropertyList;
        putDecimalParameters(value: DecimalParametersProperty[] | cdktn.IResolvable): void;
        resetDecimalParameters(): void;
        get decimalParametersInput(): cdktn.IResolvable | DecimalParametersProperty[] | undefined;
        private _integerParameters;
        get integerParameters(): IntegerParametersPropertyList;
        putIntegerParameters(value: IntegerParametersProperty[] | cdktn.IResolvable): void;
        resetIntegerParameters(): void;
        get integerParametersInput(): cdktn.IResolvable | IntegerParametersProperty[] | undefined;
        private _stringParameters;
        get stringParameters(): StringParametersPropertyList;
        putStringParameters(value: StringParametersProperty[] | cdktn.IResolvable): void;
        resetStringParameters(): void;
        get stringParametersInput(): cdktn.IResolvable | StringParametersProperty[] | undefined;
    }
    interface PermissionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#actions AwsDashboard#actions}
        */
        readonly actions: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#principal AwsDashboard#principal}
        */
        readonly principal: string;
    }
    class PermissionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PermissionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PermissionsProperty | cdktn.IResolvable | undefined);
        private _actions?;
        get actions(): string[];
        set actions(value: string[]);
        get actionsInput(): string[] | undefined;
        private _principal?;
        get principal(): string;
        set principal(value: string);
        get principalInput(): string | undefined;
    }
    class PermissionsPropertyList extends cdktn.ComplexList {
        internalValue?: PermissionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PermissionsPropertyOutputReference;
    }
    interface DataSetReferencesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#data_set_arn AwsDashboard#data_set_arn}
        */
        readonly dataSetArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#data_set_placeholder AwsDashboard#data_set_placeholder}
        */
        readonly dataSetPlaceholder: string;
    }
    class DataSetReferencesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataSetReferencesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DataSetReferencesProperty | cdktn.IResolvable | undefined);
        private _dataSetArn?;
        get dataSetArn(): string;
        set dataSetArn(value: string);
        get dataSetArnInput(): string | undefined;
        private _dataSetPlaceholder?;
        get dataSetPlaceholder(): string;
        set dataSetPlaceholder(value: string);
        get dataSetPlaceholderInput(): string | undefined;
    }
    class DataSetReferencesPropertyList extends cdktn.ComplexList {
        internalValue?: DataSetReferencesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataSetReferencesPropertyOutputReference;
    }
    interface SourceTemplateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#arn AwsDashboard#arn}
        */
        readonly arn: string;
        /**
        * data_set_references block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#data_set_references AwsDashboard#data_set_references}
        */
        readonly dataSetReferences: DataSetReferencesProperty[] | cdktn.IResolvable;
    }
    class SourceTemplatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceTemplateProperty | undefined;
        set internalValue(value: SourceTemplateProperty | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
        private _dataSetReferences;
        get dataSetReferences(): DataSetReferencesPropertyList;
        putDataSetReferences(value: DataSetReferencesProperty[] | cdktn.IResolvable): void;
        get dataSetReferencesInput(): cdktn.IResolvable | DataSetReferencesProperty[] | undefined;
    }
    interface SourceEntityProperty {
        /**
        * source_template block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#source_template AwsDashboard#source_template}
        */
        readonly sourceTemplate?: SourceTemplateProperty;
    }
    class SourceEntityPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceEntityProperty | undefined;
        set internalValue(value: SourceEntityProperty | undefined);
        private _sourceTemplate;
        get sourceTemplate(): SourceTemplatePropertyOutputReference;
        putSourceTemplate(value: SourceTemplateProperty): void;
        resetSourceTemplate(): void;
        get sourceTemplateInput(): SourceTemplateProperty | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#create AwsDashboard#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#delete AwsDashboard#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_dashboard#update AwsDashboard#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
