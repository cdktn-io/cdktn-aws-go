import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsTemplateAliasConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_template_alias#alias_name AwsTemplateAlias#alias_name}
    */
    readonly aliasName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_template_alias#aws_account_id AwsTemplateAlias#aws_account_id}
    */
    readonly awsAccountId?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_template_alias#region AwsTemplateAlias#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_template_alias#template_id AwsTemplateAlias#template_id}
    */
    readonly templateId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_template_alias#template_version_number AwsTemplateAlias#template_version_number}
    */
    readonly templateVersionNumber: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_template_alias aws_quicksight_template_alias}
*/
export declare class AwsTemplateAlias extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_quicksight_template_alias";
    /**
    * Generates CDKTN code for importing a AwsTemplateAlias resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsTemplateAlias to import
    * @param importFromId The id of the existing AwsTemplateAlias that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_template_alias#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsTemplateAlias to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_template_alias aws_quicksight_template_alias} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsTemplateAliasConfig
    */
    constructor(scope: Construct, id: string, config: AwsTemplateAliasConfig);
    private _aliasName?;
    get aliasName(): string;
    set aliasName(value: string);
    get aliasNameInput(): string | undefined;
    get arn(): string;
    private _awsAccountId?;
    get awsAccountId(): string;
    set awsAccountId(value: string);
    resetAwsAccountId(): void;
    get awsAccountIdInput(): string | undefined;
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _templateId?;
    get templateId(): string;
    set templateId(value: string);
    get templateIdInput(): string | undefined;
    private _templateVersionNumber?;
    get templateVersionNumber(): number;
    set templateVersionNumber(value: number);
    get templateVersionNumberInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
