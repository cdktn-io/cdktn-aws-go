import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsRefreshScheduleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_refresh_schedule#aws_account_id AwsRefreshSchedule#aws_account_id}
    */
    readonly awsAccountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_refresh_schedule#data_set_id AwsRefreshSchedule#data_set_id}
    */
    readonly dataSetId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_refresh_schedule#region AwsRefreshSchedule#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_refresh_schedule#schedule_id AwsRefreshSchedule#schedule_id}
    */
    readonly scheduleId: string;
    /**
    * schedule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_refresh_schedule#schedule AwsRefreshSchedule#schedule}
    */
    readonly schedule?: AwsRefreshSchedule.ScheduleProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_refresh_schedule aws_quicksight_refresh_schedule}
*/
export declare class AwsRefreshSchedule extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_quicksight_refresh_schedule";
    /**
    * Generates CDKTN code for importing a AwsRefreshSchedule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsRefreshSchedule to import
    * @param importFromId The id of the existing AwsRefreshSchedule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_refresh_schedule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsRefreshSchedule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_refresh_schedule aws_quicksight_refresh_schedule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsRefreshScheduleConfig
    */
    constructor(scope: Construct, id: string, config: AwsRefreshScheduleConfig);
    get arn(): string;
    private _awsAccountId?;
    get awsAccountId(): string;
    set awsAccountId(value: string);
    resetAwsAccountId(): void;
    get awsAccountIdInput(): string | undefined;
    private _dataSetId?;
    get dataSetId(): string;
    set dataSetId(value: string);
    get dataSetIdInput(): string | undefined;
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _scheduleId?;
    get scheduleId(): string;
    set scheduleId(value: string);
    get scheduleIdInput(): string | undefined;
    private _schedule;
    get schedule(): AwsRefreshSchedule.SchedulePropertyList;
    putSchedule(value: AwsRefreshSchedule.ScheduleProperty[] | cdktn.IResolvable): void;
    resetSchedule(): void;
    get scheduleInput(): cdktn.IResolvable | AwsRefreshSchedule.ScheduleProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsRefreshScheduleRefreshOnDayPropertyToTerraform(struct?: AwsRefreshSchedule.RefreshOnDayProperty | cdktn.IResolvable): any;
export declare function awsRefreshScheduleRefreshOnDayPropertyToHclTerraform(struct?: AwsRefreshSchedule.RefreshOnDayProperty | cdktn.IResolvable): any;
export declare function awsRefreshScheduleScheduleFrequencyPropertyToTerraform(struct?: AwsRefreshSchedule.ScheduleFrequencyProperty | cdktn.IResolvable): any;
export declare function awsRefreshScheduleScheduleFrequencyPropertyToHclTerraform(struct?: AwsRefreshSchedule.ScheduleFrequencyProperty | cdktn.IResolvable): any;
export declare function awsRefreshScheduleSchedulePropertyToTerraform(struct?: AwsRefreshSchedule.ScheduleProperty | cdktn.IResolvable): any;
export declare function awsRefreshScheduleSchedulePropertyToHclTerraform(struct?: AwsRefreshSchedule.ScheduleProperty | cdktn.IResolvable): any;
export declare namespace AwsRefreshSchedule {
    interface RefreshOnDayProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_refresh_schedule#day_of_month AwsRefreshSchedule#day_of_month}
        */
        readonly dayOfMonth?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_refresh_schedule#day_of_week AwsRefreshSchedule#day_of_week}
        */
        readonly dayOfWeek?: string;
    }
    class RefreshOnDayPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RefreshOnDayProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RefreshOnDayProperty | cdktn.IResolvable | undefined);
        private _dayOfMonth?;
        get dayOfMonth(): string;
        set dayOfMonth(value: string);
        resetDayOfMonth(): void;
        get dayOfMonthInput(): string | undefined;
        private _dayOfWeek?;
        get dayOfWeek(): string;
        set dayOfWeek(value: string);
        resetDayOfWeek(): void;
        get dayOfWeekInput(): string | undefined;
    }
    class RefreshOnDayPropertyList extends cdktn.ComplexList {
        internalValue?: RefreshOnDayProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RefreshOnDayPropertyOutputReference;
    }
    interface ScheduleFrequencyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_refresh_schedule#interval AwsRefreshSchedule#interval}
        */
        readonly interval: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_refresh_schedule#time_of_the_day AwsRefreshSchedule#time_of_the_day}
        */
        readonly timeOfTheDay?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_refresh_schedule#timezone AwsRefreshSchedule#timezone}
        */
        readonly timezone?: string;
        /**
        * refresh_on_day block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_refresh_schedule#refresh_on_day AwsRefreshSchedule#refresh_on_day}
        */
        readonly refreshOnDay?: RefreshOnDayProperty[] | cdktn.IResolvable;
    }
    class ScheduleFrequencyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ScheduleFrequencyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ScheduleFrequencyProperty | cdktn.IResolvable | undefined);
        private _interval?;
        get interval(): string;
        set interval(value: string);
        get intervalInput(): string | undefined;
        private _timeOfTheDay?;
        get timeOfTheDay(): string;
        set timeOfTheDay(value: string);
        resetTimeOfTheDay(): void;
        get timeOfTheDayInput(): string | undefined;
        private _timezone?;
        get timezone(): string;
        set timezone(value: string);
        resetTimezone(): void;
        get timezoneInput(): string | undefined;
        private _refreshOnDay;
        get refreshOnDay(): RefreshOnDayPropertyList;
        putRefreshOnDay(value: RefreshOnDayProperty[] | cdktn.IResolvable): void;
        resetRefreshOnDay(): void;
        get refreshOnDayInput(): cdktn.IResolvable | RefreshOnDayProperty[] | undefined;
    }
    class ScheduleFrequencyPropertyList extends cdktn.ComplexList {
        internalValue?: ScheduleFrequencyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ScheduleFrequencyPropertyOutputReference;
    }
    interface ScheduleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_refresh_schedule#refresh_type AwsRefreshSchedule#refresh_type}
        */
        readonly refreshType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_refresh_schedule#start_after_date_time AwsRefreshSchedule#start_after_date_time}
        */
        readonly startAfterDateTime?: string;
        /**
        * schedule_frequency block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_refresh_schedule#schedule_frequency AwsRefreshSchedule#schedule_frequency}
        */
        readonly scheduleFrequency?: ScheduleFrequencyProperty[] | cdktn.IResolvable;
    }
    class SchedulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ScheduleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ScheduleProperty | cdktn.IResolvable | undefined);
        private _refreshType?;
        get refreshType(): string;
        set refreshType(value: string);
        get refreshTypeInput(): string | undefined;
        private _startAfterDateTime?;
        get startAfterDateTime(): string;
        set startAfterDateTime(value: string);
        resetStartAfterDateTime(): void;
        get startAfterDateTimeInput(): string | undefined;
        private _scheduleFrequency;
        get scheduleFrequency(): ScheduleFrequencyPropertyList;
        putScheduleFrequency(value: ScheduleFrequencyProperty[] | cdktn.IResolvable): void;
        resetScheduleFrequency(): void;
        get scheduleFrequencyInput(): cdktn.IResolvable | ScheduleFrequencyProperty[] | undefined;
    }
    class SchedulePropertyList extends cdktn.ComplexList {
        internalValue?: ScheduleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SchedulePropertyOutputReference;
    }
}
