import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsTemplateConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_template#aws_account_id AwsTemplate#aws_account_id}
    */
    readonly awsAccountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_template#id AwsTemplate#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_template#name AwsTemplate#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_template#region AwsTemplate#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_template#tags AwsTemplate#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_template#tags_all AwsTemplate#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_template#template_id AwsTemplate#template_id}
    */
    readonly templateId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_template#version_description AwsTemplate#version_description}
    */
    readonly versionDescription: string;
    /**
    * definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_template#definition AwsTemplate#definition}
    */
    readonly definition?: any;
    /**
    * permissions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_template#permissions AwsTemplate#permissions}
    */
    readonly permissions?: AwsTemplate.PermissionsProperty[] | cdktn.IResolvable;
    /**
    * source_entity block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_template#source_entity AwsTemplate#source_entity}
    */
    readonly sourceEntity?: AwsTemplate.SourceEntityProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_template#timeouts AwsTemplate#timeouts}
    */
    readonly timeouts?: AwsTemplate.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_template aws_quicksight_template}
*/
export declare class AwsTemplate extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_quicksight_template";
    /**
    * Generates CDKTN code for importing a AwsTemplate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsTemplate to import
    * @param importFromId The id of the existing AwsTemplate that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_template#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsTemplate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_template aws_quicksight_template} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsTemplateConfig
    */
    constructor(scope: Construct, id: string, config: AwsTemplateConfig);
    get arn(): string;
    private _awsAccountId?;
    get awsAccountId(): string;
    set awsAccountId(value: string);
    resetAwsAccountId(): void;
    get awsAccountIdInput(): string | undefined;
    get createdTime(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastUpdatedTime(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get sourceEntityArn(): string;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _templateId?;
    get templateId(): string;
    set templateId(value: string);
    get templateIdInput(): string | undefined;
    private _versionDescription?;
    get versionDescription(): string;
    set versionDescription(value: string);
    get versionDescriptionInput(): string | undefined;
    get versionNumber(): number;
    private _definition?;
    get definition(): any;
    set definition(value: any);
    resetDefinition(): void;
    get definitionInput(): any;
    private _permissions;
    get permissions(): AwsTemplate.PermissionsPropertyList;
    putPermissions(value: AwsTemplate.PermissionsProperty[] | cdktn.IResolvable): void;
    resetPermissions(): void;
    get permissionsInput(): cdktn.IResolvable | AwsTemplate.PermissionsProperty[] | undefined;
    private _sourceEntity;
    get sourceEntity(): AwsTemplate.SourceEntityPropertyOutputReference;
    putSourceEntity(value: AwsTemplate.SourceEntityProperty): void;
    resetSourceEntity(): void;
    get sourceEntityInput(): AwsTemplate.SourceEntityProperty | undefined;
    private _timeouts;
    get timeouts(): AwsTemplate.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsTemplate.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsTemplate.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsTemplatePermissionsPropertyToTerraform(struct?: AwsTemplate.PermissionsProperty | cdktn.IResolvable): any;
export declare function awsTemplatePermissionsPropertyToHclTerraform(struct?: AwsTemplate.PermissionsProperty | cdktn.IResolvable): any;
export declare function awsTemplateDataSetReferencesPropertyToTerraform(struct?: AwsTemplate.DataSetReferencesProperty | cdktn.IResolvable): any;
export declare function awsTemplateDataSetReferencesPropertyToHclTerraform(struct?: AwsTemplate.DataSetReferencesProperty | cdktn.IResolvable): any;
export declare function awsTemplateSourceAnalysisPropertyToTerraform(struct?: AwsTemplate.SourceAnalysisPropertyOutputReference | AwsTemplate.SourceAnalysisProperty): any;
export declare function awsTemplateSourceAnalysisPropertyToHclTerraform(struct?: AwsTemplate.SourceAnalysisPropertyOutputReference | AwsTemplate.SourceAnalysisProperty): any;
export declare function awsTemplateSourceTemplatePropertyToTerraform(struct?: AwsTemplate.SourceTemplatePropertyOutputReference | AwsTemplate.SourceTemplateProperty): any;
export declare function awsTemplateSourceTemplatePropertyToHclTerraform(struct?: AwsTemplate.SourceTemplatePropertyOutputReference | AwsTemplate.SourceTemplateProperty): any;
export declare function awsTemplateSourceEntityPropertyToTerraform(struct?: AwsTemplate.SourceEntityPropertyOutputReference | AwsTemplate.SourceEntityProperty): any;
export declare function awsTemplateSourceEntityPropertyToHclTerraform(struct?: AwsTemplate.SourceEntityPropertyOutputReference | AwsTemplate.SourceEntityProperty): any;
export declare function awsTemplateTimeoutsPropertyToTerraform(struct?: AwsTemplate.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsTemplateTimeoutsPropertyToHclTerraform(struct?: AwsTemplate.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsTemplate {
    interface PermissionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_template#actions AwsTemplate#actions}
        */
        readonly actions: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_template#principal AwsTemplate#principal}
        */
        readonly principal: string;
    }
    class PermissionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PermissionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PermissionsProperty | cdktn.IResolvable | undefined);
        private _actions?;
        get actions(): string[];
        set actions(value: string[]);
        get actionsInput(): string[] | undefined;
        private _principal?;
        get principal(): string;
        set principal(value: string);
        get principalInput(): string | undefined;
    }
    class PermissionsPropertyList extends cdktn.ComplexList {
        internalValue?: PermissionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PermissionsPropertyOutputReference;
    }
    interface DataSetReferencesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_template#data_set_arn AwsTemplate#data_set_arn}
        */
        readonly dataSetArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_template#data_set_placeholder AwsTemplate#data_set_placeholder}
        */
        readonly dataSetPlaceholder: string;
    }
    class DataSetReferencesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataSetReferencesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DataSetReferencesProperty | cdktn.IResolvable | undefined);
        private _dataSetArn?;
        get dataSetArn(): string;
        set dataSetArn(value: string);
        get dataSetArnInput(): string | undefined;
        private _dataSetPlaceholder?;
        get dataSetPlaceholder(): string;
        set dataSetPlaceholder(value: string);
        get dataSetPlaceholderInput(): string | undefined;
    }
    class DataSetReferencesPropertyList extends cdktn.ComplexList {
        internalValue?: DataSetReferencesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataSetReferencesPropertyOutputReference;
    }
    interface SourceAnalysisProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_template#arn AwsTemplate#arn}
        */
        readonly arn: string;
        /**
        * data_set_references block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_template#data_set_references AwsTemplate#data_set_references}
        */
        readonly dataSetReferences: DataSetReferencesProperty[] | cdktn.IResolvable;
    }
    class SourceAnalysisPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceAnalysisProperty | undefined;
        set internalValue(value: SourceAnalysisProperty | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
        private _dataSetReferences;
        get dataSetReferences(): DataSetReferencesPropertyList;
        putDataSetReferences(value: DataSetReferencesProperty[] | cdktn.IResolvable): void;
        get dataSetReferencesInput(): cdktn.IResolvable | DataSetReferencesProperty[] | undefined;
    }
    interface SourceTemplateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_template#arn AwsTemplate#arn}
        */
        readonly arn: string;
    }
    class SourceTemplatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceTemplateProperty | undefined;
        set internalValue(value: SourceTemplateProperty | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
    }
    interface SourceEntityProperty {
        /**
        * source_analysis block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_template#source_analysis AwsTemplate#source_analysis}
        */
        readonly sourceAnalysis?: SourceAnalysisProperty;
        /**
        * source_template block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_template#source_template AwsTemplate#source_template}
        */
        readonly sourceTemplate?: SourceTemplateProperty;
    }
    class SourceEntityPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceEntityProperty | undefined;
        set internalValue(value: SourceEntityProperty | undefined);
        private _sourceAnalysis;
        get sourceAnalysis(): SourceAnalysisPropertyOutputReference;
        putSourceAnalysis(value: SourceAnalysisProperty): void;
        resetSourceAnalysis(): void;
        get sourceAnalysisInput(): SourceAnalysisProperty | undefined;
        private _sourceTemplate;
        get sourceTemplate(): SourceTemplatePropertyOutputReference;
        putSourceTemplate(value: SourceTemplateProperty): void;
        resetSourceTemplate(): void;
        get sourceTemplateInput(): SourceTemplateProperty | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_template#create AwsTemplate#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_template#delete AwsTemplate#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_template#update AwsTemplate#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
