import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsKeyRegistrationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_key_registration#aws_account_id AwsKeyRegistration#aws_account_id}
    */
    readonly awsAccountId?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_key_registration#region AwsKeyRegistration#region}
    */
    readonly region?: string;
    /**
    * key_registration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_key_registration#key_registration AwsKeyRegistration#key_registration}
    */
    readonly keyRegistration?: AwsKeyRegistration.KeyRegistrationProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_key_registration aws_quicksight_key_registration}
*/
export declare class AwsKeyRegistration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_quicksight_key_registration";
    /**
    * Generates CDKTN code for importing a AwsKeyRegistration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsKeyRegistration to import
    * @param importFromId The id of the existing AwsKeyRegistration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_key_registration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsKeyRegistration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_key_registration aws_quicksight_key_registration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsKeyRegistrationConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AwsKeyRegistrationConfig);
    private _awsAccountId?;
    get awsAccountId(): string;
    set awsAccountId(value: string);
    resetAwsAccountId(): void;
    get awsAccountIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _keyRegistration;
    get keyRegistration(): AwsKeyRegistration.KeyRegistrationPropertyList;
    putKeyRegistration(value: AwsKeyRegistration.KeyRegistrationProperty[] | cdktn.IResolvable): void;
    resetKeyRegistration(): void;
    get keyRegistrationInput(): cdktn.IResolvable | AwsKeyRegistration.KeyRegistrationProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsKeyRegistrationKeyRegistrationPropertyToTerraform(struct?: AwsKeyRegistration.KeyRegistrationProperty | cdktn.IResolvable): any;
export declare function awsKeyRegistrationKeyRegistrationPropertyToHclTerraform(struct?: AwsKeyRegistration.KeyRegistrationProperty | cdktn.IResolvable): any;
export declare namespace AwsKeyRegistration {
    interface KeyRegistrationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_key_registration#default_key AwsKeyRegistration#default_key}
        */
        readonly defaultKey?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_key_registration#key_arn AwsKeyRegistration#key_arn}
        */
        readonly keyArn: string;
    }
    class KeyRegistrationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KeyRegistrationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: KeyRegistrationProperty | cdktn.IResolvable | undefined);
        private _defaultKey?;
        get defaultKey(): boolean | cdktn.IResolvable;
        set defaultKey(value: boolean | cdktn.IResolvable);
        resetDefaultKey(): void;
        get defaultKeyInput(): boolean | cdktn.IResolvable | undefined;
        private _keyArn?;
        get keyArn(): string;
        set keyArn(value: string);
        get keyArnInput(): string | undefined;
    }
    class KeyRegistrationPropertyList extends cdktn.ComplexList {
        internalValue?: KeyRegistrationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KeyRegistrationPropertyOutputReference;
    }
}
