import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfScheduledQueryConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#execution_role_arn TfScheduledQuery#execution_role_arn}
    */
    readonly executionRoleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#kms_key_id TfScheduledQuery#kms_key_id}
    */
    readonly kmsKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#name TfScheduledQuery#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#query_string TfScheduledQuery#query_string}
    */
    readonly queryString: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#region TfScheduledQuery#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#tags TfScheduledQuery#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * error_report_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#error_report_configuration TfScheduledQuery#error_report_configuration}
    */
    readonly errorReportConfiguration?: TfScheduledQuery.ErrorReportConfigurationProperty[] | cdktn.IResolvable;
    /**
    * last_run_summary block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#last_run_summary TfScheduledQuery#last_run_summary}
    */
    readonly lastRunSummary?: TfScheduledQuery.LastRunSummaryProperty[] | cdktn.IResolvable;
    /**
    * notification_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#notification_configuration TfScheduledQuery#notification_configuration}
    */
    readonly notificationConfiguration?: TfScheduledQuery.NotificationConfigurationProperty[] | cdktn.IResolvable;
    /**
    * recently_failed_runs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#recently_failed_runs TfScheduledQuery#recently_failed_runs}
    */
    readonly recentlyFailedRuns?: TfScheduledQuery.RecentlyFailedRunsProperty[] | cdktn.IResolvable;
    /**
    * schedule_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#schedule_configuration TfScheduledQuery#schedule_configuration}
    */
    readonly scheduleConfiguration?: TfScheduledQuery.ScheduleConfigurationProperty[] | cdktn.IResolvable;
    /**
    * target_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#target_configuration TfScheduledQuery#target_configuration}
    */
    readonly targetConfiguration?: TfScheduledQuery.TargetConfigurationProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#timeouts TfScheduledQuery#timeouts}
    */
    readonly timeouts?: TfScheduledQuery.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query aws_timestreamquery_scheduled_query}
*/
export declare class TfScheduledQuery extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_timestreamquery_scheduled_query";
    /**
    * Generates CDKTN code for importing a TfScheduledQuery resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfScheduledQuery to import
    * @param importFromId The id of the existing TfScheduledQuery that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfScheduledQuery to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query aws_timestreamquery_scheduled_query} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfScheduledQueryConfig
    */
    constructor(scope: Construct, id: string, config: TfScheduledQueryConfig);
    get arn(): string;
    get creationTime(): string;
    private _executionRoleArn?;
    get executionRoleArn(): string;
    set executionRoleArn(value: string);
    get executionRoleArnInput(): string | undefined;
    private _kmsKeyId?;
    get kmsKeyId(): string;
    set kmsKeyId(value: string);
    resetKmsKeyId(): void;
    get kmsKeyIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get nextInvocationTime(): string;
    get previousInvocationTime(): string;
    private _queryString?;
    get queryString(): string;
    set queryString(value: string);
    get queryStringInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get state(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _errorReportConfiguration;
    get errorReportConfiguration(): TfScheduledQuery.ErrorReportConfigurationPropertyList;
    putErrorReportConfiguration(value: TfScheduledQuery.ErrorReportConfigurationProperty[] | cdktn.IResolvable): void;
    resetErrorReportConfiguration(): void;
    get errorReportConfigurationInput(): cdktn.IResolvable | TfScheduledQuery.ErrorReportConfigurationProperty[] | undefined;
    private _lastRunSummary;
    get lastRunSummary(): TfScheduledQuery.LastRunSummaryPropertyList;
    putLastRunSummary(value: TfScheduledQuery.LastRunSummaryProperty[] | cdktn.IResolvable): void;
    resetLastRunSummary(): void;
    get lastRunSummaryInput(): cdktn.IResolvable | TfScheduledQuery.LastRunSummaryProperty[] | undefined;
    private _notificationConfiguration;
    get notificationConfiguration(): TfScheduledQuery.NotificationConfigurationPropertyList;
    putNotificationConfiguration(value: TfScheduledQuery.NotificationConfigurationProperty[] | cdktn.IResolvable): void;
    resetNotificationConfiguration(): void;
    get notificationConfigurationInput(): cdktn.IResolvable | TfScheduledQuery.NotificationConfigurationProperty[] | undefined;
    private _recentlyFailedRuns;
    get recentlyFailedRuns(): TfScheduledQuery.RecentlyFailedRunsPropertyList;
    putRecentlyFailedRuns(value: TfScheduledQuery.RecentlyFailedRunsProperty[] | cdktn.IResolvable): void;
    resetRecentlyFailedRuns(): void;
    get recentlyFailedRunsInput(): cdktn.IResolvable | TfScheduledQuery.RecentlyFailedRunsProperty[] | undefined;
    private _scheduleConfiguration;
    get scheduleConfiguration(): TfScheduledQuery.ScheduleConfigurationPropertyList;
    putScheduleConfiguration(value: TfScheduledQuery.ScheduleConfigurationProperty[] | cdktn.IResolvable): void;
    resetScheduleConfiguration(): void;
    get scheduleConfigurationInput(): cdktn.IResolvable | TfScheduledQuery.ScheduleConfigurationProperty[] | undefined;
    private _targetConfiguration;
    get targetConfiguration(): TfScheduledQuery.TargetConfigurationPropertyList;
    putTargetConfiguration(value: TfScheduledQuery.TargetConfigurationProperty[] | cdktn.IResolvable): void;
    resetTargetConfiguration(): void;
    get targetConfigurationInput(): cdktn.IResolvable | TfScheduledQuery.TargetConfigurationProperty[] | undefined;
    private _timeouts;
    get timeouts(): TfScheduledQuery.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfScheduledQuery.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfScheduledQuery.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfScheduledQueryS3ConfigurationPropertyToTerraform(struct?: TfScheduledQuery.S3ConfigurationProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryS3ConfigurationPropertyToHclTerraform(struct?: TfScheduledQuery.S3ConfigurationProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryErrorReportConfigurationPropertyToTerraform(struct?: TfScheduledQuery.ErrorReportConfigurationProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryErrorReportConfigurationPropertyToHclTerraform(struct?: TfScheduledQuery.ErrorReportConfigurationProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryLastRunSummaryErrorReportLocationS3ReportLocationPropertyToTerraform(struct?: TfScheduledQuery.LastRunSummaryErrorReportLocationS3ReportLocationProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryLastRunSummaryErrorReportLocationS3ReportLocationPropertyToHclTerraform(struct?: TfScheduledQuery.LastRunSummaryErrorReportLocationS3ReportLocationProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryLastRunSummaryErrorReportLocationPropertyToTerraform(struct?: TfScheduledQuery.LastRunSummaryErrorReportLocationProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryLastRunSummaryErrorReportLocationPropertyToHclTerraform(struct?: TfScheduledQuery.LastRunSummaryErrorReportLocationProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryLastRunSummaryExecutionStatsPropertyToTerraform(struct?: TfScheduledQuery.LastRunSummaryExecutionStatsProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryLastRunSummaryExecutionStatsPropertyToHclTerraform(struct?: TfScheduledQuery.LastRunSummaryExecutionStatsProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryLastRunSummaryQueryInsightsResponseQuerySpatialCoverageMaxPropertyToTerraform(struct?: TfScheduledQuery.LastRunSummaryQueryInsightsResponseQuerySpatialCoverageMaxProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryLastRunSummaryQueryInsightsResponseQuerySpatialCoverageMaxPropertyToHclTerraform(struct?: TfScheduledQuery.LastRunSummaryQueryInsightsResponseQuerySpatialCoverageMaxProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryLastRunSummaryQueryInsightsResponseQuerySpatialCoveragePropertyToTerraform(struct?: TfScheduledQuery.LastRunSummaryQueryInsightsResponseQuerySpatialCoverageProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryLastRunSummaryQueryInsightsResponseQuerySpatialCoveragePropertyToHclTerraform(struct?: TfScheduledQuery.LastRunSummaryQueryInsightsResponseQuerySpatialCoverageProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryLastRunSummaryQueryInsightsResponseQueryTemporalRangeMaxPropertyToTerraform(struct?: TfScheduledQuery.LastRunSummaryQueryInsightsResponseQueryTemporalRangeMaxProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryLastRunSummaryQueryInsightsResponseQueryTemporalRangeMaxPropertyToHclTerraform(struct?: TfScheduledQuery.LastRunSummaryQueryInsightsResponseQueryTemporalRangeMaxProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryLastRunSummaryQueryInsightsResponseQueryTemporalRangePropertyToTerraform(struct?: TfScheduledQuery.LastRunSummaryQueryInsightsResponseQueryTemporalRangeProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryLastRunSummaryQueryInsightsResponseQueryTemporalRangePropertyToHclTerraform(struct?: TfScheduledQuery.LastRunSummaryQueryInsightsResponseQueryTemporalRangeProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryLastRunSummaryQueryInsightsResponsePropertyToTerraform(struct?: TfScheduledQuery.LastRunSummaryQueryInsightsResponseProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryLastRunSummaryQueryInsightsResponsePropertyToHclTerraform(struct?: TfScheduledQuery.LastRunSummaryQueryInsightsResponseProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryLastRunSummaryPropertyToTerraform(struct?: TfScheduledQuery.LastRunSummaryProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryLastRunSummaryPropertyToHclTerraform(struct?: TfScheduledQuery.LastRunSummaryProperty | cdktn.IResolvable): any;
export declare function tfScheduledQuerySnsConfigurationPropertyToTerraform(struct?: TfScheduledQuery.SnsConfigurationProperty | cdktn.IResolvable): any;
export declare function tfScheduledQuerySnsConfigurationPropertyToHclTerraform(struct?: TfScheduledQuery.SnsConfigurationProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryNotificationConfigurationPropertyToTerraform(struct?: TfScheduledQuery.NotificationConfigurationProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryNotificationConfigurationPropertyToHclTerraform(struct?: TfScheduledQuery.NotificationConfigurationProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryRecentlyFailedRunsErrorReportLocationS3ReportLocationPropertyToTerraform(struct?: TfScheduledQuery.RecentlyFailedRunsErrorReportLocationS3ReportLocationProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryRecentlyFailedRunsErrorReportLocationS3ReportLocationPropertyToHclTerraform(struct?: TfScheduledQuery.RecentlyFailedRunsErrorReportLocationS3ReportLocationProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryRecentlyFailedRunsErrorReportLocationPropertyToTerraform(struct?: TfScheduledQuery.RecentlyFailedRunsErrorReportLocationProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryRecentlyFailedRunsErrorReportLocationPropertyToHclTerraform(struct?: TfScheduledQuery.RecentlyFailedRunsErrorReportLocationProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryRecentlyFailedRunsExecutionStatsPropertyToTerraform(struct?: TfScheduledQuery.RecentlyFailedRunsExecutionStatsProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryRecentlyFailedRunsExecutionStatsPropertyToHclTerraform(struct?: TfScheduledQuery.RecentlyFailedRunsExecutionStatsProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryRecentlyFailedRunsQueryInsightsResponseQuerySpatialCoverageMaxPropertyToTerraform(struct?: TfScheduledQuery.RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoverageMaxProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryRecentlyFailedRunsQueryInsightsResponseQuerySpatialCoverageMaxPropertyToHclTerraform(struct?: TfScheduledQuery.RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoverageMaxProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryRecentlyFailedRunsQueryInsightsResponseQuerySpatialCoveragePropertyToTerraform(struct?: TfScheduledQuery.RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoverageProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryRecentlyFailedRunsQueryInsightsResponseQuerySpatialCoveragePropertyToHclTerraform(struct?: TfScheduledQuery.RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoverageProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryRecentlyFailedRunsQueryInsightsResponseQueryTemporalRangeMaxPropertyToTerraform(struct?: TfScheduledQuery.RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangeMaxProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryRecentlyFailedRunsQueryInsightsResponseQueryTemporalRangeMaxPropertyToHclTerraform(struct?: TfScheduledQuery.RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangeMaxProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryRecentlyFailedRunsQueryInsightsResponseQueryTemporalRangePropertyToTerraform(struct?: TfScheduledQuery.RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangeProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryRecentlyFailedRunsQueryInsightsResponseQueryTemporalRangePropertyToHclTerraform(struct?: TfScheduledQuery.RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangeProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryRecentlyFailedRunsQueryInsightsResponsePropertyToTerraform(struct?: TfScheduledQuery.RecentlyFailedRunsQueryInsightsResponseProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryRecentlyFailedRunsQueryInsightsResponsePropertyToHclTerraform(struct?: TfScheduledQuery.RecentlyFailedRunsQueryInsightsResponseProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryRecentlyFailedRunsPropertyToTerraform(struct?: TfScheduledQuery.RecentlyFailedRunsProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryRecentlyFailedRunsPropertyToHclTerraform(struct?: TfScheduledQuery.RecentlyFailedRunsProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryScheduleConfigurationPropertyToTerraform(struct?: TfScheduledQuery.ScheduleConfigurationProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryScheduleConfigurationPropertyToHclTerraform(struct?: TfScheduledQuery.ScheduleConfigurationProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryDimensionMappingPropertyToTerraform(struct?: TfScheduledQuery.DimensionMappingProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryDimensionMappingPropertyToHclTerraform(struct?: TfScheduledQuery.DimensionMappingProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryTargetConfigurationTimestreamConfigurationMixedMeasureMappingMultiMeasureAttributeMappingPropertyToTerraform(struct?: TfScheduledQuery.TargetConfigurationTimestreamConfigurationMixedMeasureMappingMultiMeasureAttributeMappingProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryTargetConfigurationTimestreamConfigurationMixedMeasureMappingMultiMeasureAttributeMappingPropertyToHclTerraform(struct?: TfScheduledQuery.TargetConfigurationTimestreamConfigurationMixedMeasureMappingMultiMeasureAttributeMappingProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryMixedMeasureMappingPropertyToTerraform(struct?: TfScheduledQuery.MixedMeasureMappingProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryMixedMeasureMappingPropertyToHclTerraform(struct?: TfScheduledQuery.MixedMeasureMappingProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryTargetConfigurationTimestreamConfigurationMultiMeasureMappingsMultiMeasureAttributeMappingPropertyToTerraform(struct?: TfScheduledQuery.TargetConfigurationTimestreamConfigurationMultiMeasureMappingsMultiMeasureAttributeMappingProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryTargetConfigurationTimestreamConfigurationMultiMeasureMappingsMultiMeasureAttributeMappingPropertyToHclTerraform(struct?: TfScheduledQuery.TargetConfigurationTimestreamConfigurationMultiMeasureMappingsMultiMeasureAttributeMappingProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryMultiMeasureMappingsPropertyToTerraform(struct?: TfScheduledQuery.MultiMeasureMappingsProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryMultiMeasureMappingsPropertyToHclTerraform(struct?: TfScheduledQuery.MultiMeasureMappingsProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryTimestreamConfigurationPropertyToTerraform(struct?: TfScheduledQuery.TimestreamConfigurationProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryTimestreamConfigurationPropertyToHclTerraform(struct?: TfScheduledQuery.TimestreamConfigurationProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryTargetConfigurationPropertyToTerraform(struct?: TfScheduledQuery.TargetConfigurationProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryTargetConfigurationPropertyToHclTerraform(struct?: TfScheduledQuery.TargetConfigurationProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryTimeoutsPropertyToTerraform(struct?: TfScheduledQuery.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfScheduledQueryTimeoutsPropertyToHclTerraform(struct?: TfScheduledQuery.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfScheduledQuery {
    interface S3ConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#bucket_name TfScheduledQuery#bucket_name}
        */
        readonly bucketName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#encryption_option TfScheduledQuery#encryption_option}
        */
        readonly encryptionOption?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#object_key_prefix TfScheduledQuery#object_key_prefix}
        */
        readonly objectKeyPrefix?: string;
    }
    class S3ConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3ConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: S3ConfigurationProperty | cdktn.IResolvable | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        get bucketNameInput(): string | undefined;
        private _encryptionOption?;
        get encryptionOption(): string;
        set encryptionOption(value: string);
        resetEncryptionOption(): void;
        get encryptionOptionInput(): string | undefined;
        private _objectKeyPrefix?;
        get objectKeyPrefix(): string;
        set objectKeyPrefix(value: string);
        resetObjectKeyPrefix(): void;
        get objectKeyPrefixInput(): string | undefined;
    }
    class S3ConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: S3ConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3ConfigurationPropertyOutputReference;
    }
    interface ErrorReportConfigurationProperty {
        /**
        * s3_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#s3_configuration TfScheduledQuery#s3_configuration}
        */
        readonly s3Configuration?: S3ConfigurationProperty[] | cdktn.IResolvable;
    }
    class ErrorReportConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ErrorReportConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ErrorReportConfigurationProperty | cdktn.IResolvable | undefined);
        private _s3Configuration;
        get s3Configuration(): S3ConfigurationPropertyList;
        putS3Configuration(value: S3ConfigurationProperty[] | cdktn.IResolvable): void;
        resetS3Configuration(): void;
        get s3ConfigurationInput(): cdktn.IResolvable | S3ConfigurationProperty[] | undefined;
    }
    class ErrorReportConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: ErrorReportConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ErrorReportConfigurationPropertyOutputReference;
    }
    interface LastRunSummaryErrorReportLocationS3ReportLocationProperty {
    }
    class LastRunSummaryErrorReportLocationS3ReportLocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LastRunSummaryErrorReportLocationS3ReportLocationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LastRunSummaryErrorReportLocationS3ReportLocationProperty | cdktn.IResolvable | undefined);
        get bucketName(): string;
        get objectKey(): string;
    }
    class LastRunSummaryErrorReportLocationS3ReportLocationPropertyList extends cdktn.ComplexList {
        internalValue?: LastRunSummaryErrorReportLocationS3ReportLocationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LastRunSummaryErrorReportLocationS3ReportLocationPropertyOutputReference;
    }
    interface LastRunSummaryErrorReportLocationProperty {
        /**
        * s3_report_location block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#s3_report_location TfScheduledQuery#s3_report_location}
        */
        readonly s3ReportLocation?: LastRunSummaryErrorReportLocationS3ReportLocationProperty[] | cdktn.IResolvable;
    }
    class LastRunSummaryErrorReportLocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LastRunSummaryErrorReportLocationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LastRunSummaryErrorReportLocationProperty | cdktn.IResolvable | undefined);
        private _s3ReportLocation;
        get s3ReportLocation(): LastRunSummaryErrorReportLocationS3ReportLocationPropertyList;
        putS3ReportLocation(value: LastRunSummaryErrorReportLocationS3ReportLocationProperty[] | cdktn.IResolvable): void;
        resetS3ReportLocation(): void;
        get s3ReportLocationInput(): cdktn.IResolvable | LastRunSummaryErrorReportLocationS3ReportLocationProperty[] | undefined;
    }
    class LastRunSummaryErrorReportLocationPropertyList extends cdktn.ComplexList {
        internalValue?: LastRunSummaryErrorReportLocationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LastRunSummaryErrorReportLocationPropertyOutputReference;
    }
    interface LastRunSummaryExecutionStatsProperty {
    }
    class LastRunSummaryExecutionStatsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LastRunSummaryExecutionStatsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LastRunSummaryExecutionStatsProperty | cdktn.IResolvable | undefined);
        get bytesMetered(): number;
        get cumulativeBytesScanned(): number;
        get dataWrites(): number;
        get executionTimeInMillis(): number;
        get queryResultRows(): number;
        get recordsIngested(): number;
    }
    class LastRunSummaryExecutionStatsPropertyList extends cdktn.ComplexList {
        internalValue?: LastRunSummaryExecutionStatsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LastRunSummaryExecutionStatsPropertyOutputReference;
    }
    interface LastRunSummaryQueryInsightsResponseQuerySpatialCoverageMaxProperty {
    }
    class LastRunSummaryQueryInsightsResponseQuerySpatialCoverageMaxPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LastRunSummaryQueryInsightsResponseQuerySpatialCoverageMaxProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LastRunSummaryQueryInsightsResponseQuerySpatialCoverageMaxProperty | cdktn.IResolvable | undefined);
        get partitionKey(): string[];
        get tableArn(): string;
        get value(): number;
    }
    class LastRunSummaryQueryInsightsResponseQuerySpatialCoverageMaxPropertyList extends cdktn.ComplexList {
        internalValue?: LastRunSummaryQueryInsightsResponseQuerySpatialCoverageMaxProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LastRunSummaryQueryInsightsResponseQuerySpatialCoverageMaxPropertyOutputReference;
    }
    interface LastRunSummaryQueryInsightsResponseQuerySpatialCoverageProperty {
        /**
        * max block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#max TfScheduledQuery#max}
        */
        readonly max?: LastRunSummaryQueryInsightsResponseQuerySpatialCoverageMaxProperty[] | cdktn.IResolvable;
    }
    class LastRunSummaryQueryInsightsResponseQuerySpatialCoveragePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LastRunSummaryQueryInsightsResponseQuerySpatialCoverageProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LastRunSummaryQueryInsightsResponseQuerySpatialCoverageProperty | cdktn.IResolvable | undefined);
        private _max;
        get max(): LastRunSummaryQueryInsightsResponseQuerySpatialCoverageMaxPropertyList;
        putMax(value: LastRunSummaryQueryInsightsResponseQuerySpatialCoverageMaxProperty[] | cdktn.IResolvable): void;
        resetMax(): void;
        get maxInput(): cdktn.IResolvable | LastRunSummaryQueryInsightsResponseQuerySpatialCoverageMaxProperty[] | undefined;
    }
    class LastRunSummaryQueryInsightsResponseQuerySpatialCoveragePropertyList extends cdktn.ComplexList {
        internalValue?: LastRunSummaryQueryInsightsResponseQuerySpatialCoverageProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LastRunSummaryQueryInsightsResponseQuerySpatialCoveragePropertyOutputReference;
    }
    interface LastRunSummaryQueryInsightsResponseQueryTemporalRangeMaxProperty {
    }
    class LastRunSummaryQueryInsightsResponseQueryTemporalRangeMaxPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LastRunSummaryQueryInsightsResponseQueryTemporalRangeMaxProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LastRunSummaryQueryInsightsResponseQueryTemporalRangeMaxProperty | cdktn.IResolvable | undefined);
        get tableArn(): string;
        get value(): number;
    }
    class LastRunSummaryQueryInsightsResponseQueryTemporalRangeMaxPropertyList extends cdktn.ComplexList {
        internalValue?: LastRunSummaryQueryInsightsResponseQueryTemporalRangeMaxProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LastRunSummaryQueryInsightsResponseQueryTemporalRangeMaxPropertyOutputReference;
    }
    interface LastRunSummaryQueryInsightsResponseQueryTemporalRangeProperty {
        /**
        * max block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#max TfScheduledQuery#max}
        */
        readonly max?: LastRunSummaryQueryInsightsResponseQueryTemporalRangeMaxProperty[] | cdktn.IResolvable;
    }
    class LastRunSummaryQueryInsightsResponseQueryTemporalRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LastRunSummaryQueryInsightsResponseQueryTemporalRangeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LastRunSummaryQueryInsightsResponseQueryTemporalRangeProperty | cdktn.IResolvable | undefined);
        private _max;
        get max(): LastRunSummaryQueryInsightsResponseQueryTemporalRangeMaxPropertyList;
        putMax(value: LastRunSummaryQueryInsightsResponseQueryTemporalRangeMaxProperty[] | cdktn.IResolvable): void;
        resetMax(): void;
        get maxInput(): cdktn.IResolvable | LastRunSummaryQueryInsightsResponseQueryTemporalRangeMaxProperty[] | undefined;
    }
    class LastRunSummaryQueryInsightsResponseQueryTemporalRangePropertyList extends cdktn.ComplexList {
        internalValue?: LastRunSummaryQueryInsightsResponseQueryTemporalRangeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LastRunSummaryQueryInsightsResponseQueryTemporalRangePropertyOutputReference;
    }
    interface LastRunSummaryQueryInsightsResponseProperty {
        /**
        * query_spatial_coverage block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#query_spatial_coverage TfScheduledQuery#query_spatial_coverage}
        */
        readonly querySpatialCoverage?: LastRunSummaryQueryInsightsResponseQuerySpatialCoverageProperty[] | cdktn.IResolvable;
        /**
        * query_temporal_range block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#query_temporal_range TfScheduledQuery#query_temporal_range}
        */
        readonly queryTemporalRange?: LastRunSummaryQueryInsightsResponseQueryTemporalRangeProperty[] | cdktn.IResolvable;
    }
    class LastRunSummaryQueryInsightsResponsePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LastRunSummaryQueryInsightsResponseProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LastRunSummaryQueryInsightsResponseProperty | cdktn.IResolvable | undefined);
        get outputBytes(): number;
        get outputRows(): number;
        get queryTableCount(): number;
        private _querySpatialCoverage;
        get querySpatialCoverage(): LastRunSummaryQueryInsightsResponseQuerySpatialCoveragePropertyList;
        putQuerySpatialCoverage(value: LastRunSummaryQueryInsightsResponseQuerySpatialCoverageProperty[] | cdktn.IResolvable): void;
        resetQuerySpatialCoverage(): void;
        get querySpatialCoverageInput(): cdktn.IResolvable | LastRunSummaryQueryInsightsResponseQuerySpatialCoverageProperty[] | undefined;
        private _queryTemporalRange;
        get queryTemporalRange(): LastRunSummaryQueryInsightsResponseQueryTemporalRangePropertyList;
        putQueryTemporalRange(value: LastRunSummaryQueryInsightsResponseQueryTemporalRangeProperty[] | cdktn.IResolvable): void;
        resetQueryTemporalRange(): void;
        get queryTemporalRangeInput(): cdktn.IResolvable | LastRunSummaryQueryInsightsResponseQueryTemporalRangeProperty[] | undefined;
    }
    class LastRunSummaryQueryInsightsResponsePropertyList extends cdktn.ComplexList {
        internalValue?: LastRunSummaryQueryInsightsResponseProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LastRunSummaryQueryInsightsResponsePropertyOutputReference;
    }
    interface LastRunSummaryProperty {
        /**
        * error_report_location block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#error_report_location TfScheduledQuery#error_report_location}
        */
        readonly errorReportLocation?: LastRunSummaryErrorReportLocationProperty[] | cdktn.IResolvable;
        /**
        * execution_stats block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#execution_stats TfScheduledQuery#execution_stats}
        */
        readonly executionStats?: LastRunSummaryExecutionStatsProperty[] | cdktn.IResolvable;
        /**
        * query_insights_response block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#query_insights_response TfScheduledQuery#query_insights_response}
        */
        readonly queryInsightsResponse?: LastRunSummaryQueryInsightsResponseProperty[] | cdktn.IResolvable;
    }
    class LastRunSummaryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LastRunSummaryProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LastRunSummaryProperty | cdktn.IResolvable | undefined);
        get failureReason(): string;
        get invocationTime(): string;
        get runStatus(): string;
        get triggerTime(): string;
        private _errorReportLocation;
        get errorReportLocation(): LastRunSummaryErrorReportLocationPropertyList;
        putErrorReportLocation(value: LastRunSummaryErrorReportLocationProperty[] | cdktn.IResolvable): void;
        resetErrorReportLocation(): void;
        get errorReportLocationInput(): cdktn.IResolvable | LastRunSummaryErrorReportLocationProperty[] | undefined;
        private _executionStats;
        get executionStats(): LastRunSummaryExecutionStatsPropertyList;
        putExecutionStats(value: LastRunSummaryExecutionStatsProperty[] | cdktn.IResolvable): void;
        resetExecutionStats(): void;
        get executionStatsInput(): cdktn.IResolvable | LastRunSummaryExecutionStatsProperty[] | undefined;
        private _queryInsightsResponse;
        get queryInsightsResponse(): LastRunSummaryQueryInsightsResponsePropertyList;
        putQueryInsightsResponse(value: LastRunSummaryQueryInsightsResponseProperty[] | cdktn.IResolvable): void;
        resetQueryInsightsResponse(): void;
        get queryInsightsResponseInput(): cdktn.IResolvable | LastRunSummaryQueryInsightsResponseProperty[] | undefined;
    }
    class LastRunSummaryPropertyList extends cdktn.ComplexList {
        internalValue?: LastRunSummaryProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LastRunSummaryPropertyOutputReference;
    }
    interface SnsConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#topic_arn TfScheduledQuery#topic_arn}
        */
        readonly topicArn: string;
    }
    class SnsConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SnsConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SnsConfigurationProperty | cdktn.IResolvable | undefined);
        private _topicArn?;
        get topicArn(): string;
        set topicArn(value: string);
        get topicArnInput(): string | undefined;
    }
    class SnsConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: SnsConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SnsConfigurationPropertyOutputReference;
    }
    interface NotificationConfigurationProperty {
        /**
        * sns_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#sns_configuration TfScheduledQuery#sns_configuration}
        */
        readonly snsConfiguration?: SnsConfigurationProperty[] | cdktn.IResolvable;
    }
    class NotificationConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NotificationConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NotificationConfigurationProperty | cdktn.IResolvable | undefined);
        private _snsConfiguration;
        get snsConfiguration(): SnsConfigurationPropertyList;
        putSnsConfiguration(value: SnsConfigurationProperty[] | cdktn.IResolvable): void;
        resetSnsConfiguration(): void;
        get snsConfigurationInput(): cdktn.IResolvable | SnsConfigurationProperty[] | undefined;
    }
    class NotificationConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: NotificationConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NotificationConfigurationPropertyOutputReference;
    }
    interface RecentlyFailedRunsErrorReportLocationS3ReportLocationProperty {
    }
    class RecentlyFailedRunsErrorReportLocationS3ReportLocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RecentlyFailedRunsErrorReportLocationS3ReportLocationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RecentlyFailedRunsErrorReportLocationS3ReportLocationProperty | cdktn.IResolvable | undefined);
        get bucketName(): string;
        get objectKey(): string;
    }
    class RecentlyFailedRunsErrorReportLocationS3ReportLocationPropertyList extends cdktn.ComplexList {
        internalValue?: RecentlyFailedRunsErrorReportLocationS3ReportLocationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RecentlyFailedRunsErrorReportLocationS3ReportLocationPropertyOutputReference;
    }
    interface RecentlyFailedRunsErrorReportLocationProperty {
        /**
        * s3_report_location block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#s3_report_location TfScheduledQuery#s3_report_location}
        */
        readonly s3ReportLocation?: RecentlyFailedRunsErrorReportLocationS3ReportLocationProperty[] | cdktn.IResolvable;
    }
    class RecentlyFailedRunsErrorReportLocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RecentlyFailedRunsErrorReportLocationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RecentlyFailedRunsErrorReportLocationProperty | cdktn.IResolvable | undefined);
        private _s3ReportLocation;
        get s3ReportLocation(): RecentlyFailedRunsErrorReportLocationS3ReportLocationPropertyList;
        putS3ReportLocation(value: RecentlyFailedRunsErrorReportLocationS3ReportLocationProperty[] | cdktn.IResolvable): void;
        resetS3ReportLocation(): void;
        get s3ReportLocationInput(): cdktn.IResolvable | RecentlyFailedRunsErrorReportLocationS3ReportLocationProperty[] | undefined;
    }
    class RecentlyFailedRunsErrorReportLocationPropertyList extends cdktn.ComplexList {
        internalValue?: RecentlyFailedRunsErrorReportLocationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RecentlyFailedRunsErrorReportLocationPropertyOutputReference;
    }
    interface RecentlyFailedRunsExecutionStatsProperty {
    }
    class RecentlyFailedRunsExecutionStatsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RecentlyFailedRunsExecutionStatsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RecentlyFailedRunsExecutionStatsProperty | cdktn.IResolvable | undefined);
        get bytesMetered(): number;
        get cumulativeBytesScanned(): number;
        get dataWrites(): number;
        get executionTimeInMillis(): number;
        get queryResultRows(): number;
        get recordsIngested(): number;
    }
    class RecentlyFailedRunsExecutionStatsPropertyList extends cdktn.ComplexList {
        internalValue?: RecentlyFailedRunsExecutionStatsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RecentlyFailedRunsExecutionStatsPropertyOutputReference;
    }
    interface RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoverageMaxProperty {
    }
    class RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoverageMaxPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoverageMaxProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoverageMaxProperty | cdktn.IResolvable | undefined);
        get partitionKey(): string[];
        get tableArn(): string;
        get value(): number;
    }
    class RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoverageMaxPropertyList extends cdktn.ComplexList {
        internalValue?: RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoverageMaxProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoverageMaxPropertyOutputReference;
    }
    interface RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoverageProperty {
        /**
        * max block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#max TfScheduledQuery#max}
        */
        readonly max?: RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoverageMaxProperty[] | cdktn.IResolvable;
    }
    class RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoveragePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoverageProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoverageProperty | cdktn.IResolvable | undefined);
        private _max;
        get max(): RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoverageMaxPropertyList;
        putMax(value: RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoverageMaxProperty[] | cdktn.IResolvable): void;
        resetMax(): void;
        get maxInput(): cdktn.IResolvable | RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoverageMaxProperty[] | undefined;
    }
    class RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoveragePropertyList extends cdktn.ComplexList {
        internalValue?: RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoverageProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoveragePropertyOutputReference;
    }
    interface RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangeMaxProperty {
    }
    class RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangeMaxPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangeMaxProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangeMaxProperty | cdktn.IResolvable | undefined);
        get tableArn(): string;
        get value(): number;
    }
    class RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangeMaxPropertyList extends cdktn.ComplexList {
        internalValue?: RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangeMaxProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangeMaxPropertyOutputReference;
    }
    interface RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangeProperty {
        /**
        * max block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#max TfScheduledQuery#max}
        */
        readonly max?: RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangeMaxProperty[] | cdktn.IResolvable;
    }
    class RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangeProperty | cdktn.IResolvable | undefined);
        private _max;
        get max(): RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangeMaxPropertyList;
        putMax(value: RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangeMaxProperty[] | cdktn.IResolvable): void;
        resetMax(): void;
        get maxInput(): cdktn.IResolvable | RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangeMaxProperty[] | undefined;
    }
    class RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangePropertyList extends cdktn.ComplexList {
        internalValue?: RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangePropertyOutputReference;
    }
    interface RecentlyFailedRunsQueryInsightsResponseProperty {
        /**
        * query_spatial_coverage block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#query_spatial_coverage TfScheduledQuery#query_spatial_coverage}
        */
        readonly querySpatialCoverage?: RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoverageProperty[] | cdktn.IResolvable;
        /**
        * query_temporal_range block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#query_temporal_range TfScheduledQuery#query_temporal_range}
        */
        readonly queryTemporalRange?: RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangeProperty[] | cdktn.IResolvable;
    }
    class RecentlyFailedRunsQueryInsightsResponsePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RecentlyFailedRunsQueryInsightsResponseProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RecentlyFailedRunsQueryInsightsResponseProperty | cdktn.IResolvable | undefined);
        get outputBytes(): number;
        get outputRows(): number;
        get queryTableCount(): number;
        private _querySpatialCoverage;
        get querySpatialCoverage(): RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoveragePropertyList;
        putQuerySpatialCoverage(value: RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoverageProperty[] | cdktn.IResolvable): void;
        resetQuerySpatialCoverage(): void;
        get querySpatialCoverageInput(): cdktn.IResolvable | RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoverageProperty[] | undefined;
        private _queryTemporalRange;
        get queryTemporalRange(): RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangePropertyList;
        putQueryTemporalRange(value: RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangeProperty[] | cdktn.IResolvable): void;
        resetQueryTemporalRange(): void;
        get queryTemporalRangeInput(): cdktn.IResolvable | RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangeProperty[] | undefined;
    }
    class RecentlyFailedRunsQueryInsightsResponsePropertyList extends cdktn.ComplexList {
        internalValue?: RecentlyFailedRunsQueryInsightsResponseProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RecentlyFailedRunsQueryInsightsResponsePropertyOutputReference;
    }
    interface RecentlyFailedRunsProperty {
        /**
        * error_report_location block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#error_report_location TfScheduledQuery#error_report_location}
        */
        readonly errorReportLocation?: RecentlyFailedRunsErrorReportLocationProperty[] | cdktn.IResolvable;
        /**
        * execution_stats block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#execution_stats TfScheduledQuery#execution_stats}
        */
        readonly executionStats?: RecentlyFailedRunsExecutionStatsProperty[] | cdktn.IResolvable;
        /**
        * query_insights_response block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#query_insights_response TfScheduledQuery#query_insights_response}
        */
        readonly queryInsightsResponse?: RecentlyFailedRunsQueryInsightsResponseProperty[] | cdktn.IResolvable;
    }
    class RecentlyFailedRunsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RecentlyFailedRunsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RecentlyFailedRunsProperty | cdktn.IResolvable | undefined);
        get failureReason(): string;
        get invocationTime(): string;
        get runStatus(): string;
        get triggerTime(): string;
        private _errorReportLocation;
        get errorReportLocation(): RecentlyFailedRunsErrorReportLocationPropertyList;
        putErrorReportLocation(value: RecentlyFailedRunsErrorReportLocationProperty[] | cdktn.IResolvable): void;
        resetErrorReportLocation(): void;
        get errorReportLocationInput(): cdktn.IResolvable | RecentlyFailedRunsErrorReportLocationProperty[] | undefined;
        private _executionStats;
        get executionStats(): RecentlyFailedRunsExecutionStatsPropertyList;
        putExecutionStats(value: RecentlyFailedRunsExecutionStatsProperty[] | cdktn.IResolvable): void;
        resetExecutionStats(): void;
        get executionStatsInput(): cdktn.IResolvable | RecentlyFailedRunsExecutionStatsProperty[] | undefined;
        private _queryInsightsResponse;
        get queryInsightsResponse(): RecentlyFailedRunsQueryInsightsResponsePropertyList;
        putQueryInsightsResponse(value: RecentlyFailedRunsQueryInsightsResponseProperty[] | cdktn.IResolvable): void;
        resetQueryInsightsResponse(): void;
        get queryInsightsResponseInput(): cdktn.IResolvable | RecentlyFailedRunsQueryInsightsResponseProperty[] | undefined;
    }
    class RecentlyFailedRunsPropertyList extends cdktn.ComplexList {
        internalValue?: RecentlyFailedRunsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RecentlyFailedRunsPropertyOutputReference;
    }
    interface ScheduleConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#schedule_expression TfScheduledQuery#schedule_expression}
        */
        readonly scheduleExpression: string;
    }
    class ScheduleConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ScheduleConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ScheduleConfigurationProperty | cdktn.IResolvable | undefined);
        private _scheduleExpression?;
        get scheduleExpression(): string;
        set scheduleExpression(value: string);
        get scheduleExpressionInput(): string | undefined;
    }
    class ScheduleConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: ScheduleConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ScheduleConfigurationPropertyOutputReference;
    }
    interface DimensionMappingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#dimension_value_type TfScheduledQuery#dimension_value_type}
        */
        readonly dimensionValueType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#name TfScheduledQuery#name}
        */
        readonly name: string;
    }
    class DimensionMappingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DimensionMappingProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DimensionMappingProperty | cdktn.IResolvable | undefined);
        private _dimensionValueType?;
        get dimensionValueType(): string;
        set dimensionValueType(value: string);
        get dimensionValueTypeInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    class DimensionMappingPropertyList extends cdktn.ComplexList {
        internalValue?: DimensionMappingProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DimensionMappingPropertyOutputReference;
    }
    interface TargetConfigurationTimestreamConfigurationMixedMeasureMappingMultiMeasureAttributeMappingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#measure_value_type TfScheduledQuery#measure_value_type}
        */
        readonly measureValueType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#source_column TfScheduledQuery#source_column}
        */
        readonly sourceColumn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#target_multi_measure_attribute_name TfScheduledQuery#target_multi_measure_attribute_name}
        */
        readonly targetMultiMeasureAttributeName?: string;
    }
    class TargetConfigurationTimestreamConfigurationMixedMeasureMappingMultiMeasureAttributeMappingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetConfigurationTimestreamConfigurationMixedMeasureMappingMultiMeasureAttributeMappingProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetConfigurationTimestreamConfigurationMixedMeasureMappingMultiMeasureAttributeMappingProperty | cdktn.IResolvable | undefined);
        private _measureValueType?;
        get measureValueType(): string;
        set measureValueType(value: string);
        get measureValueTypeInput(): string | undefined;
        private _sourceColumn?;
        get sourceColumn(): string;
        set sourceColumn(value: string);
        get sourceColumnInput(): string | undefined;
        private _targetMultiMeasureAttributeName?;
        get targetMultiMeasureAttributeName(): string;
        set targetMultiMeasureAttributeName(value: string);
        resetTargetMultiMeasureAttributeName(): void;
        get targetMultiMeasureAttributeNameInput(): string | undefined;
    }
    class TargetConfigurationTimestreamConfigurationMixedMeasureMappingMultiMeasureAttributeMappingPropertyList extends cdktn.ComplexList {
        internalValue?: TargetConfigurationTimestreamConfigurationMixedMeasureMappingMultiMeasureAttributeMappingProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetConfigurationTimestreamConfigurationMixedMeasureMappingMultiMeasureAttributeMappingPropertyOutputReference;
    }
    interface MixedMeasureMappingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#measure_name TfScheduledQuery#measure_name}
        */
        readonly measureName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#measure_value_type TfScheduledQuery#measure_value_type}
        */
        readonly measureValueType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#source_column TfScheduledQuery#source_column}
        */
        readonly sourceColumn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#target_measure_name TfScheduledQuery#target_measure_name}
        */
        readonly targetMeasureName?: string;
        /**
        * multi_measure_attribute_mapping block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#multi_measure_attribute_mapping TfScheduledQuery#multi_measure_attribute_mapping}
        */
        readonly multiMeasureAttributeMapping?: TargetConfigurationTimestreamConfigurationMixedMeasureMappingMultiMeasureAttributeMappingProperty[] | cdktn.IResolvable;
    }
    class MixedMeasureMappingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MixedMeasureMappingProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MixedMeasureMappingProperty | cdktn.IResolvable | undefined);
        private _measureName?;
        get measureName(): string;
        set measureName(value: string);
        resetMeasureName(): void;
        get measureNameInput(): string | undefined;
        private _measureValueType?;
        get measureValueType(): string;
        set measureValueType(value: string);
        get measureValueTypeInput(): string | undefined;
        private _sourceColumn?;
        get sourceColumn(): string;
        set sourceColumn(value: string);
        resetSourceColumn(): void;
        get sourceColumnInput(): string | undefined;
        private _targetMeasureName?;
        get targetMeasureName(): string;
        set targetMeasureName(value: string);
        resetTargetMeasureName(): void;
        get targetMeasureNameInput(): string | undefined;
        private _multiMeasureAttributeMapping;
        get multiMeasureAttributeMapping(): TargetConfigurationTimestreamConfigurationMixedMeasureMappingMultiMeasureAttributeMappingPropertyList;
        putMultiMeasureAttributeMapping(value: TargetConfigurationTimestreamConfigurationMixedMeasureMappingMultiMeasureAttributeMappingProperty[] | cdktn.IResolvable): void;
        resetMultiMeasureAttributeMapping(): void;
        get multiMeasureAttributeMappingInput(): cdktn.IResolvable | TargetConfigurationTimestreamConfigurationMixedMeasureMappingMultiMeasureAttributeMappingProperty[] | undefined;
    }
    class MixedMeasureMappingPropertyList extends cdktn.ComplexList {
        internalValue?: MixedMeasureMappingProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MixedMeasureMappingPropertyOutputReference;
    }
    interface TargetConfigurationTimestreamConfigurationMultiMeasureMappingsMultiMeasureAttributeMappingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#measure_value_type TfScheduledQuery#measure_value_type}
        */
        readonly measureValueType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#source_column TfScheduledQuery#source_column}
        */
        readonly sourceColumn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#target_multi_measure_attribute_name TfScheduledQuery#target_multi_measure_attribute_name}
        */
        readonly targetMultiMeasureAttributeName?: string;
    }
    class TargetConfigurationTimestreamConfigurationMultiMeasureMappingsMultiMeasureAttributeMappingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetConfigurationTimestreamConfigurationMultiMeasureMappingsMultiMeasureAttributeMappingProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetConfigurationTimestreamConfigurationMultiMeasureMappingsMultiMeasureAttributeMappingProperty | cdktn.IResolvable | undefined);
        private _measureValueType?;
        get measureValueType(): string;
        set measureValueType(value: string);
        get measureValueTypeInput(): string | undefined;
        private _sourceColumn?;
        get sourceColumn(): string;
        set sourceColumn(value: string);
        get sourceColumnInput(): string | undefined;
        private _targetMultiMeasureAttributeName?;
        get targetMultiMeasureAttributeName(): string;
        set targetMultiMeasureAttributeName(value: string);
        resetTargetMultiMeasureAttributeName(): void;
        get targetMultiMeasureAttributeNameInput(): string | undefined;
    }
    class TargetConfigurationTimestreamConfigurationMultiMeasureMappingsMultiMeasureAttributeMappingPropertyList extends cdktn.ComplexList {
        internalValue?: TargetConfigurationTimestreamConfigurationMultiMeasureMappingsMultiMeasureAttributeMappingProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetConfigurationTimestreamConfigurationMultiMeasureMappingsMultiMeasureAttributeMappingPropertyOutputReference;
    }
    interface MultiMeasureMappingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#target_multi_measure_name TfScheduledQuery#target_multi_measure_name}
        */
        readonly targetMultiMeasureName?: string;
        /**
        * multi_measure_attribute_mapping block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#multi_measure_attribute_mapping TfScheduledQuery#multi_measure_attribute_mapping}
        */
        readonly multiMeasureAttributeMapping?: TargetConfigurationTimestreamConfigurationMultiMeasureMappingsMultiMeasureAttributeMappingProperty[] | cdktn.IResolvable;
    }
    class MultiMeasureMappingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MultiMeasureMappingsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MultiMeasureMappingsProperty | cdktn.IResolvable | undefined);
        private _targetMultiMeasureName?;
        get targetMultiMeasureName(): string;
        set targetMultiMeasureName(value: string);
        resetTargetMultiMeasureName(): void;
        get targetMultiMeasureNameInput(): string | undefined;
        private _multiMeasureAttributeMapping;
        get multiMeasureAttributeMapping(): TargetConfigurationTimestreamConfigurationMultiMeasureMappingsMultiMeasureAttributeMappingPropertyList;
        putMultiMeasureAttributeMapping(value: TargetConfigurationTimestreamConfigurationMultiMeasureMappingsMultiMeasureAttributeMappingProperty[] | cdktn.IResolvable): void;
        resetMultiMeasureAttributeMapping(): void;
        get multiMeasureAttributeMappingInput(): cdktn.IResolvable | TargetConfigurationTimestreamConfigurationMultiMeasureMappingsMultiMeasureAttributeMappingProperty[] | undefined;
    }
    class MultiMeasureMappingsPropertyList extends cdktn.ComplexList {
        internalValue?: MultiMeasureMappingsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MultiMeasureMappingsPropertyOutputReference;
    }
    interface TimestreamConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#database_name TfScheduledQuery#database_name}
        */
        readonly databaseName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#measure_name_column TfScheduledQuery#measure_name_column}
        */
        readonly measureNameColumn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#table_name TfScheduledQuery#table_name}
        */
        readonly tableName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#time_column TfScheduledQuery#time_column}
        */
        readonly timeColumn: string;
        /**
        * dimension_mapping block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#dimension_mapping TfScheduledQuery#dimension_mapping}
        */
        readonly dimensionMapping?: DimensionMappingProperty[] | cdktn.IResolvable;
        /**
        * mixed_measure_mapping block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#mixed_measure_mapping TfScheduledQuery#mixed_measure_mapping}
        */
        readonly mixedMeasureMapping?: MixedMeasureMappingProperty[] | cdktn.IResolvable;
        /**
        * multi_measure_mappings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#multi_measure_mappings TfScheduledQuery#multi_measure_mappings}
        */
        readonly multiMeasureMappings?: MultiMeasureMappingsProperty[] | cdktn.IResolvable;
    }
    class TimestreamConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TimestreamConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimestreamConfigurationProperty | cdktn.IResolvable | undefined);
        private _databaseName?;
        get databaseName(): string;
        set databaseName(value: string);
        get databaseNameInput(): string | undefined;
        private _measureNameColumn?;
        get measureNameColumn(): string;
        set measureNameColumn(value: string);
        resetMeasureNameColumn(): void;
        get measureNameColumnInput(): string | undefined;
        private _tableName?;
        get tableName(): string;
        set tableName(value: string);
        get tableNameInput(): string | undefined;
        private _timeColumn?;
        get timeColumn(): string;
        set timeColumn(value: string);
        get timeColumnInput(): string | undefined;
        private _dimensionMapping;
        get dimensionMapping(): DimensionMappingPropertyList;
        putDimensionMapping(value: DimensionMappingProperty[] | cdktn.IResolvable): void;
        resetDimensionMapping(): void;
        get dimensionMappingInput(): cdktn.IResolvable | DimensionMappingProperty[] | undefined;
        private _mixedMeasureMapping;
        get mixedMeasureMapping(): MixedMeasureMappingPropertyList;
        putMixedMeasureMapping(value: MixedMeasureMappingProperty[] | cdktn.IResolvable): void;
        resetMixedMeasureMapping(): void;
        get mixedMeasureMappingInput(): cdktn.IResolvable | MixedMeasureMappingProperty[] | undefined;
        private _multiMeasureMappings;
        get multiMeasureMappings(): MultiMeasureMappingsPropertyList;
        putMultiMeasureMappings(value: MultiMeasureMappingsProperty[] | cdktn.IResolvable): void;
        resetMultiMeasureMappings(): void;
        get multiMeasureMappingsInput(): cdktn.IResolvable | MultiMeasureMappingsProperty[] | undefined;
    }
    class TimestreamConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: TimestreamConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TimestreamConfigurationPropertyOutputReference;
    }
    interface TargetConfigurationProperty {
        /**
        * timestream_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#timestream_configuration TfScheduledQuery#timestream_configuration}
        */
        readonly timestreamConfiguration?: TimestreamConfigurationProperty[] | cdktn.IResolvable;
    }
    class TargetConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetConfigurationProperty | cdktn.IResolvable | undefined);
        private _timestreamConfiguration;
        get timestreamConfiguration(): TimestreamConfigurationPropertyList;
        putTimestreamConfiguration(value: TimestreamConfigurationProperty[] | cdktn.IResolvable): void;
        resetTimestreamConfiguration(): void;
        get timestreamConfigurationInput(): cdktn.IResolvable | TimestreamConfigurationProperty[] | undefined;
    }
    class TargetConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: TargetConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetConfigurationPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#create TfScheduledQuery#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#delete TfScheduledQuery#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#update TfScheduledQuery#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
