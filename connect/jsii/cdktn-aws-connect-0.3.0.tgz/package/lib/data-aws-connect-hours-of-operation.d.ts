import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsHoursOfOperationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_hours_of_operation#hours_of_operation_id DataAwsHoursOfOperation#hours_of_operation_id}
    */
    readonly hoursOfOperationId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_hours_of_operation#id DataAwsHoursOfOperation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_hours_of_operation#instance_id DataAwsHoursOfOperation#instance_id}
    */
    readonly instanceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_hours_of_operation#name DataAwsHoursOfOperation#name}
    */
    readonly name?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_hours_of_operation#region DataAwsHoursOfOperation#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_hours_of_operation#tags DataAwsHoursOfOperation#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_hours_of_operation aws_connect_hours_of_operation}
*/
export declare class DataAwsHoursOfOperation extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_connect_hours_of_operation";
    /**
    * Generates CDKTN code for importing a DataAwsHoursOfOperation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsHoursOfOperation to import
    * @param importFromId The id of the existing DataAwsHoursOfOperation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_hours_of_operation#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsHoursOfOperation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_hours_of_operation aws_connect_hours_of_operation} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsHoursOfOperationConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsHoursOfOperationConfig);
    get arn(): string;
    private _config;
    get config(): DataAwsHoursOfOperation.ConfigPropertyList;
    get description(): string;
    private _hoursOfOperationId?;
    get hoursOfOperationId(): string;
    set hoursOfOperationId(value: string);
    resetHoursOfOperationId(): void;
    get hoursOfOperationIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    get timeZone(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsHoursOfOperationEndTimePropertyToTerraform(struct?: DataAwsHoursOfOperation.EndTimeProperty): any;
export declare function dataAwsHoursOfOperationEndTimePropertyToHclTerraform(struct?: DataAwsHoursOfOperation.EndTimeProperty): any;
export declare function dataAwsHoursOfOperationStartTimePropertyToTerraform(struct?: DataAwsHoursOfOperation.StartTimeProperty): any;
export declare function dataAwsHoursOfOperationStartTimePropertyToHclTerraform(struct?: DataAwsHoursOfOperation.StartTimeProperty): any;
export declare function dataAwsHoursOfOperationConfigPropertyToTerraform(struct?: DataAwsHoursOfOperation.ConfigProperty): any;
export declare function dataAwsHoursOfOperationConfigPropertyToHclTerraform(struct?: DataAwsHoursOfOperation.ConfigProperty): any;
export declare namespace DataAwsHoursOfOperation {
    interface EndTimeProperty {
    }
    class EndTimePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EndTimeProperty | undefined;
        set internalValue(value: EndTimeProperty | undefined);
        get hours(): number;
        get minutes(): number;
    }
    class EndTimePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EndTimePropertyOutputReference;
    }
    interface StartTimeProperty {
    }
    class StartTimePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StartTimeProperty | undefined;
        set internalValue(value: StartTimeProperty | undefined);
        get hours(): number;
        get minutes(): number;
    }
    class StartTimePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StartTimePropertyOutputReference;
    }
    interface ConfigProperty {
    }
    class ConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConfigProperty | undefined;
        set internalValue(value: ConfigProperty | undefined);
        get day(): string;
        private _endTime;
        get endTime(): EndTimePropertyList;
        private _startTime;
        get startTime(): StartTimePropertyList;
    }
    class ConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConfigPropertyOutputReference;
    }
}
