import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsPhoneNumberContactFlowAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_phone_number_contact_flow_association#contact_flow_id AwsPhoneNumberContactFlowAssociation#contact_flow_id}
    */
    readonly contactFlowId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_phone_number_contact_flow_association#instance_id AwsPhoneNumberContactFlowAssociation#instance_id}
    */
    readonly instanceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_phone_number_contact_flow_association#phone_number_id AwsPhoneNumberContactFlowAssociation#phone_number_id}
    */
    readonly phoneNumberId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_phone_number_contact_flow_association#region AwsPhoneNumberContactFlowAssociation#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_phone_number_contact_flow_association aws_connect_phone_number_contact_flow_association}
*/
export declare class AwsPhoneNumberContactFlowAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_connect_phone_number_contact_flow_association";
    /**
    * Generates CDKTN code for importing a AwsPhoneNumberContactFlowAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsPhoneNumberContactFlowAssociation to import
    * @param importFromId The id of the existing AwsPhoneNumberContactFlowAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_phone_number_contact_flow_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsPhoneNumberContactFlowAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_phone_number_contact_flow_association aws_connect_phone_number_contact_flow_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsPhoneNumberContactFlowAssociationConfig
    */
    constructor(scope: Construct, id: string, config: AwsPhoneNumberContactFlowAssociationConfig);
    private _contactFlowId?;
    get contactFlowId(): string;
    set contactFlowId(value: string);
    get contactFlowIdInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _phoneNumberId?;
    get phoneNumberId(): string;
    set phoneNumberId(value: string);
    get phoneNumberIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
