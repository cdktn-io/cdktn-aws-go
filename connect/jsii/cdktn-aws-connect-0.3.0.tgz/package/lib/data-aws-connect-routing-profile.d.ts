import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsRoutingProfileConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_routing_profile#id DataAwsRoutingProfile#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_routing_profile#instance_id DataAwsRoutingProfile#instance_id}
    */
    readonly instanceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_routing_profile#name DataAwsRoutingProfile#name}
    */
    readonly name?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_routing_profile#region DataAwsRoutingProfile#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_routing_profile#routing_profile_id DataAwsRoutingProfile#routing_profile_id}
    */
    readonly routingProfileId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_routing_profile#tags DataAwsRoutingProfile#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_routing_profile aws_connect_routing_profile}
*/
export declare class DataAwsRoutingProfile extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_connect_routing_profile";
    /**
    * Generates CDKTN code for importing a DataAwsRoutingProfile resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsRoutingProfile to import
    * @param importFromId The id of the existing DataAwsRoutingProfile that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_routing_profile#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsRoutingProfile to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_routing_profile aws_connect_routing_profile} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsRoutingProfileConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsRoutingProfileConfig);
    get arn(): string;
    get defaultOutboundQueueId(): string;
    get description(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _mediaConcurrencies;
    get mediaConcurrencies(): DataAwsRoutingProfile.MediaConcurrenciesPropertyList;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _queueConfigs;
    get queueConfigs(): DataAwsRoutingProfile.QueueConfigsPropertyList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _routingProfileId?;
    get routingProfileId(): string;
    set routingProfileId(value: string);
    resetRoutingProfileId(): void;
    get routingProfileIdInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsRoutingProfileCrossChannelBehaviorPropertyToTerraform(struct?: DataAwsRoutingProfile.CrossChannelBehaviorProperty): any;
export declare function dataAwsRoutingProfileCrossChannelBehaviorPropertyToHclTerraform(struct?: DataAwsRoutingProfile.CrossChannelBehaviorProperty): any;
export declare function dataAwsRoutingProfileMediaConcurrenciesPropertyToTerraform(struct?: DataAwsRoutingProfile.MediaConcurrenciesProperty): any;
export declare function dataAwsRoutingProfileMediaConcurrenciesPropertyToHclTerraform(struct?: DataAwsRoutingProfile.MediaConcurrenciesProperty): any;
export declare function dataAwsRoutingProfileQueueConfigsPropertyToTerraform(struct?: DataAwsRoutingProfile.QueueConfigsProperty): any;
export declare function dataAwsRoutingProfileQueueConfigsPropertyToHclTerraform(struct?: DataAwsRoutingProfile.QueueConfigsProperty): any;
export declare namespace DataAwsRoutingProfile {
    interface CrossChannelBehaviorProperty {
    }
    class CrossChannelBehaviorPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CrossChannelBehaviorProperty | undefined;
        set internalValue(value: CrossChannelBehaviorProperty | undefined);
        get behaviorType(): string;
    }
    class CrossChannelBehaviorPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CrossChannelBehaviorPropertyOutputReference;
    }
    interface MediaConcurrenciesProperty {
    }
    class MediaConcurrenciesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MediaConcurrenciesProperty | undefined;
        set internalValue(value: MediaConcurrenciesProperty | undefined);
        get channel(): string;
        get concurrency(): number;
        private _crossChannelBehavior;
        get crossChannelBehavior(): CrossChannelBehaviorPropertyList;
    }
    class MediaConcurrenciesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MediaConcurrenciesPropertyOutputReference;
    }
    interface QueueConfigsProperty {
    }
    class QueueConfigsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): QueueConfigsProperty | undefined;
        set internalValue(value: QueueConfigsProperty | undefined);
        get channel(): string;
        get delay(): number;
        get priority(): number;
        get queueArn(): string;
        get queueId(): string;
        get queueName(): string;
    }
    class QueueConfigsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): QueueConfigsPropertyOutputReference;
    }
}
