import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsUserHierarchyGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_user_hierarchy_group#hierarchy_group_id DataAwsUserHierarchyGroup#hierarchy_group_id}
    */
    readonly hierarchyGroupId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_user_hierarchy_group#id DataAwsUserHierarchyGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_user_hierarchy_group#instance_id DataAwsUserHierarchyGroup#instance_id}
    */
    readonly instanceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_user_hierarchy_group#name DataAwsUserHierarchyGroup#name}
    */
    readonly name?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_user_hierarchy_group#region DataAwsUserHierarchyGroup#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_user_hierarchy_group#tags DataAwsUserHierarchyGroup#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_user_hierarchy_group aws_connect_user_hierarchy_group}
*/
export declare class DataAwsUserHierarchyGroup extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_connect_user_hierarchy_group";
    /**
    * Generates CDKTN code for importing a DataAwsUserHierarchyGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsUserHierarchyGroup to import
    * @param importFromId The id of the existing DataAwsUserHierarchyGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_user_hierarchy_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsUserHierarchyGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_user_hierarchy_group aws_connect_user_hierarchy_group} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsUserHierarchyGroupConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsUserHierarchyGroupConfig);
    get arn(): string;
    private _hierarchyGroupId?;
    get hierarchyGroupId(): string;
    set hierarchyGroupId(value: string);
    resetHierarchyGroupId(): void;
    get hierarchyGroupIdInput(): string | undefined;
    private _hierarchyPath;
    get hierarchyPath(): DataAwsUserHierarchyGroup.HierarchyPathPropertyList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    get levelId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsUserHierarchyGroupLevelFivePropertyToTerraform(struct?: DataAwsUserHierarchyGroup.LevelFiveProperty): any;
export declare function dataAwsUserHierarchyGroupLevelFivePropertyToHclTerraform(struct?: DataAwsUserHierarchyGroup.LevelFiveProperty): any;
export declare function dataAwsUserHierarchyGroupLevelFourPropertyToTerraform(struct?: DataAwsUserHierarchyGroup.LevelFourProperty): any;
export declare function dataAwsUserHierarchyGroupLevelFourPropertyToHclTerraform(struct?: DataAwsUserHierarchyGroup.LevelFourProperty): any;
export declare function dataAwsUserHierarchyGroupLevelOnePropertyToTerraform(struct?: DataAwsUserHierarchyGroup.LevelOneProperty): any;
export declare function dataAwsUserHierarchyGroupLevelOnePropertyToHclTerraform(struct?: DataAwsUserHierarchyGroup.LevelOneProperty): any;
export declare function dataAwsUserHierarchyGroupLevelThreePropertyToTerraform(struct?: DataAwsUserHierarchyGroup.LevelThreeProperty): any;
export declare function dataAwsUserHierarchyGroupLevelThreePropertyToHclTerraform(struct?: DataAwsUserHierarchyGroup.LevelThreeProperty): any;
export declare function dataAwsUserHierarchyGroupLevelTwoPropertyToTerraform(struct?: DataAwsUserHierarchyGroup.LevelTwoProperty): any;
export declare function dataAwsUserHierarchyGroupLevelTwoPropertyToHclTerraform(struct?: DataAwsUserHierarchyGroup.LevelTwoProperty): any;
export declare function dataAwsUserHierarchyGroupHierarchyPathPropertyToTerraform(struct?: DataAwsUserHierarchyGroup.HierarchyPathProperty): any;
export declare function dataAwsUserHierarchyGroupHierarchyPathPropertyToHclTerraform(struct?: DataAwsUserHierarchyGroup.HierarchyPathProperty): any;
export declare namespace DataAwsUserHierarchyGroup {
    interface LevelFiveProperty {
    }
    class LevelFivePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LevelFiveProperty | undefined;
        set internalValue(value: LevelFiveProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class LevelFivePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LevelFivePropertyOutputReference;
    }
    interface LevelFourProperty {
    }
    class LevelFourPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LevelFourProperty | undefined;
        set internalValue(value: LevelFourProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class LevelFourPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LevelFourPropertyOutputReference;
    }
    interface LevelOneProperty {
    }
    class LevelOnePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LevelOneProperty | undefined;
        set internalValue(value: LevelOneProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class LevelOnePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LevelOnePropertyOutputReference;
    }
    interface LevelThreeProperty {
    }
    class LevelThreePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LevelThreeProperty | undefined;
        set internalValue(value: LevelThreeProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class LevelThreePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LevelThreePropertyOutputReference;
    }
    interface LevelTwoProperty {
    }
    class LevelTwoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LevelTwoProperty | undefined;
        set internalValue(value: LevelTwoProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class LevelTwoPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LevelTwoPropertyOutputReference;
    }
    interface HierarchyPathProperty {
    }
    class HierarchyPathPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HierarchyPathProperty | undefined;
        set internalValue(value: HierarchyPathProperty | undefined);
        private _levelFive;
        get levelFive(): LevelFivePropertyList;
        private _levelFour;
        get levelFour(): LevelFourPropertyList;
        private _levelOne;
        get levelOne(): LevelOnePropertyList;
        private _levelThree;
        get levelThree(): LevelThreePropertyList;
        private _levelTwo;
        get levelTwo(): LevelTwoPropertyList;
    }
    class HierarchyPathPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HierarchyPathPropertyOutputReference;
    }
}
