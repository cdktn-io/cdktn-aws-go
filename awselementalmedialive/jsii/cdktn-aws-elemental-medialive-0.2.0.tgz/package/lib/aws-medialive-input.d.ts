import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfInputConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#id TfInput#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#input_security_groups TfInput#input_security_groups}
    */
    readonly inputSecurityGroups?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#name TfInput#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#region TfInput#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#role_arn TfInput#role_arn}
    */
    readonly roleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#tags TfInput#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#tags_all TfInput#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#type TfInput#type}
    */
    readonly type: string;
    /**
    * destinations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#destinations TfInput#destinations}
    */
    readonly destinations?: TfInput.DestinationsProperty[] | cdktn.IResolvable;
    /**
    * input_devices block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#input_devices TfInput#input_devices}
    */
    readonly inputDevices?: TfInput.InputDevicesProperty[] | cdktn.IResolvable;
    /**
    * media_connect_flows block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#media_connect_flows TfInput#media_connect_flows}
    */
    readonly mediaConnectFlows?: TfInput.MediaConnectFlowsProperty[] | cdktn.IResolvable;
    /**
    * sources block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#sources TfInput#sources}
    */
    readonly sources?: TfInput.SourcesProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#timeouts TfInput#timeouts}
    */
    readonly timeouts?: TfInput.TimeoutsProperty;
    /**
    * vpc block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#vpc TfInput#vpc}
    */
    readonly vpc?: TfInput.VpcProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input aws_medialive_input}
*/
export declare class TfInput extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_medialive_input";
    /**
    * Generates CDKTN code for importing a TfInput resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfInput to import
    * @param importFromId The id of the existing TfInput that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfInput to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input aws_medialive_input} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfInputConfig
    */
    constructor(scope: Construct, id: string, config: TfInputConfig);
    get arn(): string;
    get attachedChannels(): string[];
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get inputClass(): string;
    get inputPartnerIds(): string[];
    private _inputSecurityGroups?;
    get inputSecurityGroups(): string[];
    set inputSecurityGroups(value: string[]);
    resetInputSecurityGroups(): void;
    get inputSecurityGroupsInput(): string[] | undefined;
    get inputSourceType(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    resetRoleArn(): void;
    get roleArnInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _destinations;
    get destinations(): TfInput.DestinationsPropertyList;
    putDestinations(value: TfInput.DestinationsProperty[] | cdktn.IResolvable): void;
    resetDestinations(): void;
    get destinationsInput(): cdktn.IResolvable | TfInput.DestinationsProperty[] | undefined;
    private _inputDevices;
    get inputDevices(): TfInput.InputDevicesPropertyList;
    putInputDevices(value: TfInput.InputDevicesProperty[] | cdktn.IResolvable): void;
    resetInputDevices(): void;
    get inputDevicesInput(): cdktn.IResolvable | TfInput.InputDevicesProperty[] | undefined;
    private _mediaConnectFlows;
    get mediaConnectFlows(): TfInput.MediaConnectFlowsPropertyList;
    putMediaConnectFlows(value: TfInput.MediaConnectFlowsProperty[] | cdktn.IResolvable): void;
    resetMediaConnectFlows(): void;
    get mediaConnectFlowsInput(): cdktn.IResolvable | TfInput.MediaConnectFlowsProperty[] | undefined;
    private _sources;
    get sources(): TfInput.SourcesPropertyList;
    putSources(value: TfInput.SourcesProperty[] | cdktn.IResolvable): void;
    resetSources(): void;
    get sourcesInput(): cdktn.IResolvable | TfInput.SourcesProperty[] | undefined;
    private _timeouts;
    get timeouts(): TfInput.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfInput.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfInput.TimeoutsProperty | undefined;
    private _vpc;
    get vpc(): TfInput.VpcPropertyOutputReference;
    putVpc(value: TfInput.VpcProperty): void;
    resetVpc(): void;
    get vpcInput(): TfInput.VpcProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfInputDestinationsPropertyToTerraform(struct?: TfInput.DestinationsProperty | cdktn.IResolvable): any;
export declare function tfInputDestinationsPropertyToHclTerraform(struct?: TfInput.DestinationsProperty | cdktn.IResolvable): any;
export declare function tfInputInputDevicesPropertyToTerraform(struct?: TfInput.InputDevicesProperty | cdktn.IResolvable): any;
export declare function tfInputInputDevicesPropertyToHclTerraform(struct?: TfInput.InputDevicesProperty | cdktn.IResolvable): any;
export declare function tfInputMediaConnectFlowsPropertyToTerraform(struct?: TfInput.MediaConnectFlowsProperty | cdktn.IResolvable): any;
export declare function tfInputMediaConnectFlowsPropertyToHclTerraform(struct?: TfInput.MediaConnectFlowsProperty | cdktn.IResolvable): any;
export declare function tfInputSourcesPropertyToTerraform(struct?: TfInput.SourcesProperty | cdktn.IResolvable): any;
export declare function tfInputSourcesPropertyToHclTerraform(struct?: TfInput.SourcesProperty | cdktn.IResolvable): any;
export declare function tfInputTimeoutsPropertyToTerraform(struct?: TfInput.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfInputTimeoutsPropertyToHclTerraform(struct?: TfInput.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfInputVpcPropertyToTerraform(struct?: TfInput.VpcPropertyOutputReference | TfInput.VpcProperty): any;
export declare function tfInputVpcPropertyToHclTerraform(struct?: TfInput.VpcPropertyOutputReference | TfInput.VpcProperty): any;
export declare namespace TfInput {
    interface DestinationsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#stream_name TfInput#stream_name}
        */
        readonly streamName: string;
    }
    class DestinationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DestinationsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DestinationsProperty | cdktn.IResolvable | undefined);
        private _streamName?;
        get streamName(): string;
        set streamName(value: string);
        get streamNameInput(): string | undefined;
    }
    class DestinationsPropertyList extends cdktn.ComplexList {
        internalValue?: DestinationsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DestinationsPropertyOutputReference;
    }
    interface InputDevicesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#id TfInput#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id: string;
    }
    class InputDevicesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InputDevicesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InputDevicesProperty | cdktn.IResolvable | undefined);
        private _id?;
        get id(): string;
        set id(value: string);
        get idInput(): string | undefined;
    }
    class InputDevicesPropertyList extends cdktn.ComplexList {
        internalValue?: InputDevicesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InputDevicesPropertyOutputReference;
    }
    interface MediaConnectFlowsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#flow_arn TfInput#flow_arn}
        */
        readonly flowArn: string;
    }
    class MediaConnectFlowsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MediaConnectFlowsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MediaConnectFlowsProperty | cdktn.IResolvable | undefined);
        private _flowArn?;
        get flowArn(): string;
        set flowArn(value: string);
        get flowArnInput(): string | undefined;
    }
    class MediaConnectFlowsPropertyList extends cdktn.ComplexList {
        internalValue?: MediaConnectFlowsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MediaConnectFlowsPropertyOutputReference;
    }
    interface SourcesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#password_param TfInput#password_param}
        */
        readonly passwordParam: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#url TfInput#url}
        */
        readonly url: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#username TfInput#username}
        */
        readonly username: string;
    }
    class SourcesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SourcesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SourcesProperty | cdktn.IResolvable | undefined);
        private _passwordParam?;
        get passwordParam(): string;
        set passwordParam(value: string);
        get passwordParamInput(): string | undefined;
        private _url?;
        get url(): string;
        set url(value: string);
        get urlInput(): string | undefined;
        private _username?;
        get username(): string;
        set username(value: string);
        get usernameInput(): string | undefined;
    }
    class SourcesPropertyList extends cdktn.ComplexList {
        internalValue?: SourcesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SourcesPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#create TfInput#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#delete TfInput#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#update TfInput#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface VpcProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#security_group_ids TfInput#security_group_ids}
        */
        readonly securityGroupIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#subnet_ids TfInput#subnet_ids}
        */
        readonly subnetIds: string[];
    }
    class VpcPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VpcProperty | undefined;
        set internalValue(value: VpcProperty | undefined);
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        resetSecurityGroupIds(): void;
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        get subnetIdsInput(): string[] | undefined;
    }
}
