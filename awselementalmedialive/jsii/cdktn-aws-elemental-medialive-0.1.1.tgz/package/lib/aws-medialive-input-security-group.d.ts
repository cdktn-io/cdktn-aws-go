import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsMedialiveInputSecurityGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input_security_group#id AwsMedialiveInputSecurityGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input_security_group#region AwsMedialiveInputSecurityGroup#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input_security_group#tags AwsMedialiveInputSecurityGroup#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input_security_group#tags_all AwsMedialiveInputSecurityGroup#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input_security_group#timeouts AwsMedialiveInputSecurityGroup#timeouts}
    */
    readonly timeouts?: AwsMedialiveInputSecurityGroup.TimeoutsProperty;
    /**
    * whitelist_rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input_security_group#whitelist_rules AwsMedialiveInputSecurityGroup#whitelist_rules}
    */
    readonly whitelistRules: AwsMedialiveInputSecurityGroup.WhitelistRulesProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input_security_group aws_medialive_input_security_group}
*/
export declare class AwsMedialiveInputSecurityGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_medialive_input_security_group";
    /**
    * Generates CDKTN code for importing a AwsMedialiveInputSecurityGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsMedialiveInputSecurityGroup to import
    * @param importFromId The id of the existing AwsMedialiveInputSecurityGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input_security_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsMedialiveInputSecurityGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input_security_group aws_medialive_input_security_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsMedialiveInputSecurityGroupConfig
    */
    constructor(scope: Construct, id: string, config: AwsMedialiveInputSecurityGroupConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get inputs(): string[];
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _timeouts;
    get timeouts(): AwsMedialiveInputSecurityGroup.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsMedialiveInputSecurityGroup.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsMedialiveInputSecurityGroup.TimeoutsProperty | undefined;
    private _whitelistRules;
    get whitelistRules(): AwsMedialiveInputSecurityGroup.WhitelistRulesPropertyList;
    putWhitelistRules(value: AwsMedialiveInputSecurityGroup.WhitelistRulesProperty[] | cdktn.IResolvable): void;
    get whitelistRulesInput(): cdktn.IResolvable | AwsMedialiveInputSecurityGroup.WhitelistRulesProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsMedialiveInputSecurityGroupTimeoutsPropertyToTerraform(struct?: AwsMedialiveInputSecurityGroup.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsMedialiveInputSecurityGroupTimeoutsPropertyToHclTerraform(struct?: AwsMedialiveInputSecurityGroup.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsMedialiveInputSecurityGroupWhitelistRulesPropertyToTerraform(struct?: AwsMedialiveInputSecurityGroup.WhitelistRulesProperty | cdktn.IResolvable): any;
export declare function awsMedialiveInputSecurityGroupWhitelistRulesPropertyToHclTerraform(struct?: AwsMedialiveInputSecurityGroup.WhitelistRulesProperty | cdktn.IResolvable): any;
export declare namespace AwsMedialiveInputSecurityGroup {
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input_security_group#create AwsMedialiveInputSecurityGroup#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input_security_group#delete AwsMedialiveInputSecurityGroup#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input_security_group#update AwsMedialiveInputSecurityGroup#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface WhitelistRulesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input_security_group#cidr AwsMedialiveInputSecurityGroup#cidr}
        */
        readonly cidr: string;
    }
    class WhitelistRulesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WhitelistRulesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WhitelistRulesProperty | cdktn.IResolvable | undefined);
        private _cidr?;
        get cidr(): string;
        set cidr(value: string);
        get cidrInput(): string | undefined;
    }
    class WhitelistRulesPropertyList extends cdktn.ComplexList {
        internalValue?: WhitelistRulesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WhitelistRulesPropertyOutputReference;
    }
}
