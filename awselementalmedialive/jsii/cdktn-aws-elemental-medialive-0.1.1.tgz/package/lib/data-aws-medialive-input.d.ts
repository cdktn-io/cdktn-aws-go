import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsMedialiveInputConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/medialive_input#id DataAwsMedialiveInput#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/medialive_input#region DataAwsMedialiveInput#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/medialive_input aws_medialive_input}
*/
export declare class DataAwsMedialiveInput extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_medialive_input";
    /**
    * Generates CDKTN code for importing a DataAwsMedialiveInput resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsMedialiveInput to import
    * @param importFromId The id of the existing DataAwsMedialiveInput that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/medialive_input#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsMedialiveInput to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/medialive_input aws_medialive_input} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsMedialiveInputConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsMedialiveInputConfig);
    get arn(): string;
    get attachedChannels(): string[];
    private _destinations;
    get destinations(): DataAwsMedialiveInput.DestinationsPropertyList;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get inputClass(): string;
    private _inputDevices;
    get inputDevices(): DataAwsMedialiveInput.InputDevicesPropertyList;
    get inputPartnerIds(): string[];
    get inputSourceType(): string;
    private _mediaConnectFlows;
    get mediaConnectFlows(): DataAwsMedialiveInput.MediaConnectFlowsPropertyList;
    get name(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get roleArn(): string;
    get securityGroups(): string[];
    private _sources;
    get sources(): DataAwsMedialiveInput.SourcesPropertyList;
    get state(): string;
    private _tags;
    get tags(): cdktn.StringMap;
    get type(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsMedialiveInputVpcPropertyToTerraform(struct?: DataAwsMedialiveInput.VpcProperty): any;
export declare function dataAwsMedialiveInputVpcPropertyToHclTerraform(struct?: DataAwsMedialiveInput.VpcProperty): any;
export declare function dataAwsMedialiveInputDestinationsPropertyToTerraform(struct?: DataAwsMedialiveInput.DestinationsProperty): any;
export declare function dataAwsMedialiveInputDestinationsPropertyToHclTerraform(struct?: DataAwsMedialiveInput.DestinationsProperty): any;
export declare function dataAwsMedialiveInputInputDevicesPropertyToTerraform(struct?: DataAwsMedialiveInput.InputDevicesProperty): any;
export declare function dataAwsMedialiveInputInputDevicesPropertyToHclTerraform(struct?: DataAwsMedialiveInput.InputDevicesProperty): any;
export declare function dataAwsMedialiveInputMediaConnectFlowsPropertyToTerraform(struct?: DataAwsMedialiveInput.MediaConnectFlowsProperty): any;
export declare function dataAwsMedialiveInputMediaConnectFlowsPropertyToHclTerraform(struct?: DataAwsMedialiveInput.MediaConnectFlowsProperty): any;
export declare function dataAwsMedialiveInputSourcesPropertyToTerraform(struct?: DataAwsMedialiveInput.SourcesProperty): any;
export declare function dataAwsMedialiveInputSourcesPropertyToHclTerraform(struct?: DataAwsMedialiveInput.SourcesProperty): any;
export declare namespace DataAwsMedialiveInput {
    interface VpcProperty {
    }
    class VpcPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VpcProperty | undefined;
        set internalValue(value: VpcProperty | undefined);
        get availabilityZone(): string;
        get networkInterfaceId(): string;
    }
    class VpcPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VpcPropertyOutputReference;
    }
    interface DestinationsProperty {
    }
    class DestinationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DestinationsProperty | undefined;
        set internalValue(value: DestinationsProperty | undefined);
        get ip(): string;
        get port(): string;
        get url(): string;
        private _vpc;
        get vpc(): VpcPropertyList;
    }
    class DestinationsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DestinationsPropertyOutputReference;
    }
    interface InputDevicesProperty {
    }
    class InputDevicesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InputDevicesProperty | undefined;
        set internalValue(value: InputDevicesProperty | undefined);
        get id(): string;
    }
    class InputDevicesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InputDevicesPropertyOutputReference;
    }
    interface MediaConnectFlowsProperty {
    }
    class MediaConnectFlowsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MediaConnectFlowsProperty | undefined;
        set internalValue(value: MediaConnectFlowsProperty | undefined);
        get flowArn(): string;
    }
    class MediaConnectFlowsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MediaConnectFlowsPropertyOutputReference;
    }
    interface SourcesProperty {
    }
    class SourcesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SourcesProperty | undefined;
        set internalValue(value: SourcesProperty | undefined);
        get passwordParam(): string;
        get url(): string;
        get username(): string;
    }
    class SourcesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SourcesPropertyOutputReference;
    }
}
