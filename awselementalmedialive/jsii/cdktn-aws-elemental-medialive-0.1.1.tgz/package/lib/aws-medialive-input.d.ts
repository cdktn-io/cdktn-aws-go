import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsMedialiveInputConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#id AwsMedialiveInput#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#input_security_groups AwsMedialiveInput#input_security_groups}
    */
    readonly inputSecurityGroups?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#name AwsMedialiveInput#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#region AwsMedialiveInput#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#role_arn AwsMedialiveInput#role_arn}
    */
    readonly roleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#tags AwsMedialiveInput#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#tags_all AwsMedialiveInput#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#type AwsMedialiveInput#type}
    */
    readonly type: string;
    /**
    * destinations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#destinations AwsMedialiveInput#destinations}
    */
    readonly destinations?: AwsMedialiveInput.DestinationsProperty[] | cdktn.IResolvable;
    /**
    * input_devices block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#input_devices AwsMedialiveInput#input_devices}
    */
    readonly inputDevices?: AwsMedialiveInput.InputDevicesProperty[] | cdktn.IResolvable;
    /**
    * media_connect_flows block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#media_connect_flows AwsMedialiveInput#media_connect_flows}
    */
    readonly mediaConnectFlows?: AwsMedialiveInput.MediaConnectFlowsProperty[] | cdktn.IResolvable;
    /**
    * sources block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#sources AwsMedialiveInput#sources}
    */
    readonly sources?: AwsMedialiveInput.SourcesProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#timeouts AwsMedialiveInput#timeouts}
    */
    readonly timeouts?: AwsMedialiveInput.TimeoutsProperty;
    /**
    * vpc block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#vpc AwsMedialiveInput#vpc}
    */
    readonly vpc?: AwsMedialiveInput.VpcProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input aws_medialive_input}
*/
export declare class AwsMedialiveInput extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_medialive_input";
    /**
    * Generates CDKTN code for importing a AwsMedialiveInput resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsMedialiveInput to import
    * @param importFromId The id of the existing AwsMedialiveInput that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsMedialiveInput to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input aws_medialive_input} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsMedialiveInputConfig
    */
    constructor(scope: Construct, id: string, config: AwsMedialiveInputConfig);
    get arn(): string;
    get attachedChannels(): string[];
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get inputClass(): string;
    get inputPartnerIds(): string[];
    private _inputSecurityGroups?;
    get inputSecurityGroups(): string[];
    set inputSecurityGroups(value: string[]);
    resetInputSecurityGroups(): void;
    get inputSecurityGroupsInput(): string[] | undefined;
    get inputSourceType(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    resetRoleArn(): void;
    get roleArnInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _destinations;
    get destinations(): AwsMedialiveInput.DestinationsPropertyList;
    putDestinations(value: AwsMedialiveInput.DestinationsProperty[] | cdktn.IResolvable): void;
    resetDestinations(): void;
    get destinationsInput(): cdktn.IResolvable | AwsMedialiveInput.DestinationsProperty[] | undefined;
    private _inputDevices;
    get inputDevices(): AwsMedialiveInput.InputDevicesPropertyList;
    putInputDevices(value: AwsMedialiveInput.InputDevicesProperty[] | cdktn.IResolvable): void;
    resetInputDevices(): void;
    get inputDevicesInput(): cdktn.IResolvable | AwsMedialiveInput.InputDevicesProperty[] | undefined;
    private _mediaConnectFlows;
    get mediaConnectFlows(): AwsMedialiveInput.MediaConnectFlowsPropertyList;
    putMediaConnectFlows(value: AwsMedialiveInput.MediaConnectFlowsProperty[] | cdktn.IResolvable): void;
    resetMediaConnectFlows(): void;
    get mediaConnectFlowsInput(): cdktn.IResolvable | AwsMedialiveInput.MediaConnectFlowsProperty[] | undefined;
    private _sources;
    get sources(): AwsMedialiveInput.SourcesPropertyList;
    putSources(value: AwsMedialiveInput.SourcesProperty[] | cdktn.IResolvable): void;
    resetSources(): void;
    get sourcesInput(): cdktn.IResolvable | AwsMedialiveInput.SourcesProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsMedialiveInput.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsMedialiveInput.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsMedialiveInput.TimeoutsProperty | undefined;
    private _vpc;
    get vpc(): AwsMedialiveInput.VpcPropertyOutputReference;
    putVpc(value: AwsMedialiveInput.VpcProperty): void;
    resetVpc(): void;
    get vpcInput(): AwsMedialiveInput.VpcProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsMedialiveInputDestinationsPropertyToTerraform(struct?: AwsMedialiveInput.DestinationsProperty | cdktn.IResolvable): any;
export declare function awsMedialiveInputDestinationsPropertyToHclTerraform(struct?: AwsMedialiveInput.DestinationsProperty | cdktn.IResolvable): any;
export declare function awsMedialiveInputInputDevicesPropertyToTerraform(struct?: AwsMedialiveInput.InputDevicesProperty | cdktn.IResolvable): any;
export declare function awsMedialiveInputInputDevicesPropertyToHclTerraform(struct?: AwsMedialiveInput.InputDevicesProperty | cdktn.IResolvable): any;
export declare function awsMedialiveInputMediaConnectFlowsPropertyToTerraform(struct?: AwsMedialiveInput.MediaConnectFlowsProperty | cdktn.IResolvable): any;
export declare function awsMedialiveInputMediaConnectFlowsPropertyToHclTerraform(struct?: AwsMedialiveInput.MediaConnectFlowsProperty | cdktn.IResolvable): any;
export declare function awsMedialiveInputSourcesPropertyToTerraform(struct?: AwsMedialiveInput.SourcesProperty | cdktn.IResolvable): any;
export declare function awsMedialiveInputSourcesPropertyToHclTerraform(struct?: AwsMedialiveInput.SourcesProperty | cdktn.IResolvable): any;
export declare function awsMedialiveInputTimeoutsPropertyToTerraform(struct?: AwsMedialiveInput.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsMedialiveInputTimeoutsPropertyToHclTerraform(struct?: AwsMedialiveInput.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsMedialiveInputVpcPropertyToTerraform(struct?: AwsMedialiveInput.VpcPropertyOutputReference | AwsMedialiveInput.VpcProperty): any;
export declare function awsMedialiveInputVpcPropertyToHclTerraform(struct?: AwsMedialiveInput.VpcPropertyOutputReference | AwsMedialiveInput.VpcProperty): any;
export declare namespace AwsMedialiveInput {
    interface DestinationsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#stream_name AwsMedialiveInput#stream_name}
        */
        readonly streamName: string;
    }
    class DestinationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DestinationsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DestinationsProperty | cdktn.IResolvable | undefined);
        private _streamName?;
        get streamName(): string;
        set streamName(value: string);
        get streamNameInput(): string | undefined;
    }
    class DestinationsPropertyList extends cdktn.ComplexList {
        internalValue?: DestinationsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DestinationsPropertyOutputReference;
    }
    interface InputDevicesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#id AwsMedialiveInput#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id: string;
    }
    class InputDevicesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InputDevicesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InputDevicesProperty | cdktn.IResolvable | undefined);
        private _id?;
        get id(): string;
        set id(value: string);
        get idInput(): string | undefined;
    }
    class InputDevicesPropertyList extends cdktn.ComplexList {
        internalValue?: InputDevicesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InputDevicesPropertyOutputReference;
    }
    interface MediaConnectFlowsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#flow_arn AwsMedialiveInput#flow_arn}
        */
        readonly flowArn: string;
    }
    class MediaConnectFlowsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MediaConnectFlowsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MediaConnectFlowsProperty | cdktn.IResolvable | undefined);
        private _flowArn?;
        get flowArn(): string;
        set flowArn(value: string);
        get flowArnInput(): string | undefined;
    }
    class MediaConnectFlowsPropertyList extends cdktn.ComplexList {
        internalValue?: MediaConnectFlowsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MediaConnectFlowsPropertyOutputReference;
    }
    interface SourcesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#password_param AwsMedialiveInput#password_param}
        */
        readonly passwordParam: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#url AwsMedialiveInput#url}
        */
        readonly url: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#username AwsMedialiveInput#username}
        */
        readonly username: string;
    }
    class SourcesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SourcesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SourcesProperty | cdktn.IResolvable | undefined);
        private _passwordParam?;
        get passwordParam(): string;
        set passwordParam(value: string);
        get passwordParamInput(): string | undefined;
        private _url?;
        get url(): string;
        set url(value: string);
        get urlInput(): string | undefined;
        private _username?;
        get username(): string;
        set username(value: string);
        get usernameInput(): string | undefined;
    }
    class SourcesPropertyList extends cdktn.ComplexList {
        internalValue?: SourcesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SourcesPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#create AwsMedialiveInput#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#delete AwsMedialiveInput#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#update AwsMedialiveInput#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface VpcProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#security_group_ids AwsMedialiveInput#security_group_ids}
        */
        readonly securityGroupIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#subnet_ids AwsMedialiveInput#subnet_ids}
        */
        readonly subnetIds: string[];
    }
    class VpcPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VpcProperty | undefined;
        set internalValue(value: VpcProperty | undefined);
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        resetSecurityGroupIds(): void;
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        get subnetIdsInput(): string[] | undefined;
    }
}
