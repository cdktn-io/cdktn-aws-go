import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAccessPointConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_access_point#account_id AwsAccessPoint#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_access_point#bucket AwsAccessPoint#bucket}
    */
    readonly bucket: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_access_point#bucket_account_id AwsAccessPoint#bucket_account_id}
    */
    readonly bucketAccountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_access_point#id AwsAccessPoint#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_access_point#name AwsAccessPoint#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_access_point#policy AwsAccessPoint#policy}
    */
    readonly policy?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_access_point#region AwsAccessPoint#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_access_point#tags AwsAccessPoint#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_access_point#tags_all AwsAccessPoint#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * public_access_block_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_access_point#public_access_block_configuration AwsAccessPoint#public_access_block_configuration}
    */
    readonly publicAccessBlockConfiguration?: AwsAccessPoint.PublicAccessBlockConfigurationProperty;
    /**
    * vpc_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_access_point#vpc_configuration AwsAccessPoint#vpc_configuration}
    */
    readonly vpcConfiguration?: AwsAccessPoint.VpcConfigurationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_access_point aws_s3_access_point}
*/
export declare class AwsAccessPoint extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_s3_access_point";
    /**
    * Generates CDKTN code for importing a AwsAccessPoint resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsAccessPoint to import
    * @param importFromId The id of the existing AwsAccessPoint that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_access_point#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsAccessPoint to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_access_point aws_s3_access_point} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAccessPointConfig
    */
    constructor(scope: Construct, id: string, config: AwsAccessPointConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get alias(): string;
    get arn(): string;
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _bucketAccountId?;
    get bucketAccountId(): string;
    set bucketAccountId(value: string);
    resetBucketAccountId(): void;
    get bucketAccountIdInput(): string | undefined;
    get domainName(): string;
    private _endpoints;
    get endpoints(): cdktn.StringMap;
    get hasPublicAccessPolicy(): cdktn.IResolvable;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get networkOrigin(): string;
    private _policy?;
    get policy(): string;
    set policy(value: string);
    resetPolicy(): void;
    get policyInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _publicAccessBlockConfiguration;
    get publicAccessBlockConfiguration(): AwsAccessPoint.PublicAccessBlockConfigurationPropertyOutputReference;
    putPublicAccessBlockConfiguration(value: AwsAccessPoint.PublicAccessBlockConfigurationProperty): void;
    resetPublicAccessBlockConfiguration(): void;
    get publicAccessBlockConfigurationInput(): AwsAccessPoint.PublicAccessBlockConfigurationProperty | undefined;
    private _vpcConfiguration;
    get vpcConfiguration(): AwsAccessPoint.VpcConfigurationPropertyOutputReference;
    putVpcConfiguration(value: AwsAccessPoint.VpcConfigurationProperty): void;
    resetVpcConfiguration(): void;
    get vpcConfigurationInput(): AwsAccessPoint.VpcConfigurationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsAccessPointPublicAccessBlockConfigurationPropertyToTerraform(struct?: AwsAccessPoint.PublicAccessBlockConfigurationPropertyOutputReference | AwsAccessPoint.PublicAccessBlockConfigurationProperty): any;
export declare function awsAccessPointPublicAccessBlockConfigurationPropertyToHclTerraform(struct?: AwsAccessPoint.PublicAccessBlockConfigurationPropertyOutputReference | AwsAccessPoint.PublicAccessBlockConfigurationProperty): any;
export declare function awsAccessPointVpcConfigurationPropertyToTerraform(struct?: AwsAccessPoint.VpcConfigurationPropertyOutputReference | AwsAccessPoint.VpcConfigurationProperty): any;
export declare function awsAccessPointVpcConfigurationPropertyToHclTerraform(struct?: AwsAccessPoint.VpcConfigurationPropertyOutputReference | AwsAccessPoint.VpcConfigurationProperty): any;
export declare namespace AwsAccessPoint {
    interface PublicAccessBlockConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_access_point#block_public_acls AwsAccessPoint#block_public_acls}
        */
        readonly blockPublicAcls?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_access_point#block_public_policy AwsAccessPoint#block_public_policy}
        */
        readonly blockPublicPolicy?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_access_point#ignore_public_acls AwsAccessPoint#ignore_public_acls}
        */
        readonly ignorePublicAcls?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_access_point#restrict_public_buckets AwsAccessPoint#restrict_public_buckets}
        */
        readonly restrictPublicBuckets?: boolean | cdktn.IResolvable;
    }
    class PublicAccessBlockConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PublicAccessBlockConfigurationProperty | undefined;
        set internalValue(value: PublicAccessBlockConfigurationProperty | undefined);
        private _blockPublicAcls?;
        get blockPublicAcls(): boolean | cdktn.IResolvable;
        set blockPublicAcls(value: boolean | cdktn.IResolvable);
        resetBlockPublicAcls(): void;
        get blockPublicAclsInput(): boolean | cdktn.IResolvable | undefined;
        private _blockPublicPolicy?;
        get blockPublicPolicy(): boolean | cdktn.IResolvable;
        set blockPublicPolicy(value: boolean | cdktn.IResolvable);
        resetBlockPublicPolicy(): void;
        get blockPublicPolicyInput(): boolean | cdktn.IResolvable | undefined;
        private _ignorePublicAcls?;
        get ignorePublicAcls(): boolean | cdktn.IResolvable;
        set ignorePublicAcls(value: boolean | cdktn.IResolvable);
        resetIgnorePublicAcls(): void;
        get ignorePublicAclsInput(): boolean | cdktn.IResolvable | undefined;
        private _restrictPublicBuckets?;
        get restrictPublicBuckets(): boolean | cdktn.IResolvable;
        set restrictPublicBuckets(value: boolean | cdktn.IResolvable);
        resetRestrictPublicBuckets(): void;
        get restrictPublicBucketsInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface VpcConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_access_point#vpc_id AwsAccessPoint#vpc_id}
        */
        readonly vpcId: string;
    }
    class VpcConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VpcConfigurationProperty | undefined;
        set internalValue(value: VpcConfigurationProperty | undefined);
        private _vpcId?;
        get vpcId(): string;
        set vpcId(value: string);
        get vpcIdInput(): string | undefined;
    }
}
