import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsMultiRegionAccessPointPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point_policy#account_id AwsMultiRegionAccessPointPolicy#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point_policy#id AwsMultiRegionAccessPointPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point_policy#region AwsMultiRegionAccessPointPolicy#region}
    */
    readonly region?: string;
    /**
    * details block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point_policy#details AwsMultiRegionAccessPointPolicy#details}
    */
    readonly details: AwsMultiRegionAccessPointPolicy.DetailsProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point_policy#timeouts AwsMultiRegionAccessPointPolicy#timeouts}
    */
    readonly timeouts?: AwsMultiRegionAccessPointPolicy.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point_policy aws_s3control_multi_region_access_point_policy}
*/
export declare class AwsMultiRegionAccessPointPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_s3control_multi_region_access_point_policy";
    /**
    * Generates CDKTN code for importing a AwsMultiRegionAccessPointPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsMultiRegionAccessPointPolicy to import
    * @param importFromId The id of the existing AwsMultiRegionAccessPointPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsMultiRegionAccessPointPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point_policy aws_s3control_multi_region_access_point_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsMultiRegionAccessPointPolicyConfig
    */
    constructor(scope: Construct, id: string, config: AwsMultiRegionAccessPointPolicyConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get established(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get proposed(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _details;
    get details(): AwsMultiRegionAccessPointPolicy.DetailsPropertyOutputReference;
    putDetails(value: AwsMultiRegionAccessPointPolicy.DetailsProperty): void;
    get detailsInput(): AwsMultiRegionAccessPointPolicy.DetailsProperty | undefined;
    private _timeouts;
    get timeouts(): AwsMultiRegionAccessPointPolicy.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsMultiRegionAccessPointPolicy.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsMultiRegionAccessPointPolicy.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsMultiRegionAccessPointPolicyDetailsPropertyToTerraform(struct?: AwsMultiRegionAccessPointPolicy.DetailsPropertyOutputReference | AwsMultiRegionAccessPointPolicy.DetailsProperty): any;
export declare function awsMultiRegionAccessPointPolicyDetailsPropertyToHclTerraform(struct?: AwsMultiRegionAccessPointPolicy.DetailsPropertyOutputReference | AwsMultiRegionAccessPointPolicy.DetailsProperty): any;
export declare function awsMultiRegionAccessPointPolicyTimeoutsPropertyToTerraform(struct?: AwsMultiRegionAccessPointPolicy.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsMultiRegionAccessPointPolicyTimeoutsPropertyToHclTerraform(struct?: AwsMultiRegionAccessPointPolicy.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsMultiRegionAccessPointPolicy {
    interface DetailsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point_policy#name AwsMultiRegionAccessPointPolicy#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point_policy#policy AwsMultiRegionAccessPointPolicy#policy}
        */
        readonly policy: string;
    }
    class DetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DetailsProperty | undefined;
        set internalValue(value: DetailsProperty | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _policy?;
        get policy(): string;
        set policy(value: string);
        get policyInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point_policy#create AwsMultiRegionAccessPointPolicy#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point_policy#update AwsMultiRegionAccessPointPolicy#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
