import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDirectoryBucketAccessPointScopeConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_directory_bucket_access_point_scope#account_id AwsDirectoryBucketAccessPointScope#account_id}
    */
    readonly accountId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_directory_bucket_access_point_scope#name AwsDirectoryBucketAccessPointScope#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_directory_bucket_access_point_scope#region AwsDirectoryBucketAccessPointScope#region}
    */
    readonly region?: string;
    /**
    * scope block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_directory_bucket_access_point_scope#scope AwsDirectoryBucketAccessPointScope#scope}
    */
    readonly scope?: AwsDirectoryBucketAccessPointScope.ScopeProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_directory_bucket_access_point_scope aws_s3control_directory_bucket_access_point_scope}
*/
export declare class AwsDirectoryBucketAccessPointScope extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_s3control_directory_bucket_access_point_scope";
    /**
    * Generates CDKTN code for importing a AwsDirectoryBucketAccessPointScope resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDirectoryBucketAccessPointScope to import
    * @param importFromId The id of the existing AwsDirectoryBucketAccessPointScope that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_directory_bucket_access_point_scope#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDirectoryBucketAccessPointScope to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_directory_bucket_access_point_scope aws_s3control_directory_bucket_access_point_scope} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDirectoryBucketAccessPointScopeConfig
    */
    constructor(scope: Construct, id: string, config: AwsDirectoryBucketAccessPointScopeConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _scope;
    get scope(): AwsDirectoryBucketAccessPointScope.ScopePropertyList;
    putScope(value: AwsDirectoryBucketAccessPointScope.ScopeProperty[] | cdktn.IResolvable): void;
    resetScope(): void;
    get scopeInput(): cdktn.IResolvable | AwsDirectoryBucketAccessPointScope.ScopeProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsDirectoryBucketAccessPointScopeScopePropertyToTerraform(struct?: AwsDirectoryBucketAccessPointScope.ScopeProperty | cdktn.IResolvable): any;
export declare function awsDirectoryBucketAccessPointScopeScopePropertyToHclTerraform(struct?: AwsDirectoryBucketAccessPointScope.ScopeProperty | cdktn.IResolvable): any;
export declare namespace AwsDirectoryBucketAccessPointScope {
    interface ScopeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_directory_bucket_access_point_scope#permissions AwsDirectoryBucketAccessPointScope#permissions}
        */
        readonly permissions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_directory_bucket_access_point_scope#prefixes AwsDirectoryBucketAccessPointScope#prefixes}
        */
        readonly prefixes?: string[];
    }
    class ScopePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ScopeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ScopeProperty | cdktn.IResolvable | undefined);
        private _permissions?;
        get permissions(): string[];
        set permissions(value: string[]);
        resetPermissions(): void;
        get permissionsInput(): string[] | undefined;
        private _prefixes?;
        get prefixes(): string[];
        set prefixes(value: string[]);
        resetPrefixes(): void;
        get prefixesInput(): string[] | undefined;
    }
    class ScopePropertyList extends cdktn.ComplexList {
        internalValue?: ScopeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ScopePropertyOutputReference;
    }
}
