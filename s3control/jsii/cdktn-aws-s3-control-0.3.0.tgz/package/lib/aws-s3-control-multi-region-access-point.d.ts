import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsMultiRegionAccessPointConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point#account_id AwsMultiRegionAccessPoint#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point#id AwsMultiRegionAccessPoint#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point#region AwsMultiRegionAccessPoint#region}
    */
    readonly region?: string;
    /**
    * details block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point#details AwsMultiRegionAccessPoint#details}
    */
    readonly details: AwsMultiRegionAccessPoint.DetailsProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point#timeouts AwsMultiRegionAccessPoint#timeouts}
    */
    readonly timeouts?: AwsMultiRegionAccessPoint.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point aws_s3control_multi_region_access_point}
*/
export declare class AwsMultiRegionAccessPoint extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_s3control_multi_region_access_point";
    /**
    * Generates CDKTN code for importing a AwsMultiRegionAccessPoint resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsMultiRegionAccessPoint to import
    * @param importFromId The id of the existing AwsMultiRegionAccessPoint that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsMultiRegionAccessPoint to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point aws_s3control_multi_region_access_point} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsMultiRegionAccessPointConfig
    */
    constructor(scope: Construct, id: string, config: AwsMultiRegionAccessPointConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get alias(): string;
    get arn(): string;
    get domainName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get name(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    private _details;
    get details(): AwsMultiRegionAccessPoint.DetailsPropertyOutputReference;
    putDetails(value: AwsMultiRegionAccessPoint.DetailsProperty): void;
    get detailsInput(): AwsMultiRegionAccessPoint.DetailsProperty | undefined;
    private _timeouts;
    get timeouts(): AwsMultiRegionAccessPoint.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsMultiRegionAccessPoint.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsMultiRegionAccessPoint.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsMultiRegionAccessPointPublicAccessBlockPropertyToTerraform(struct?: AwsMultiRegionAccessPoint.PublicAccessBlockPropertyOutputReference | AwsMultiRegionAccessPoint.PublicAccessBlockProperty): any;
export declare function awsMultiRegionAccessPointPublicAccessBlockPropertyToHclTerraform(struct?: AwsMultiRegionAccessPoint.PublicAccessBlockPropertyOutputReference | AwsMultiRegionAccessPoint.PublicAccessBlockProperty): any;
export declare function awsMultiRegionAccessPointRegionPropertyToTerraform(struct?: AwsMultiRegionAccessPoint.RegionProperty | cdktn.IResolvable): any;
export declare function awsMultiRegionAccessPointRegionPropertyToHclTerraform(struct?: AwsMultiRegionAccessPoint.RegionProperty | cdktn.IResolvable): any;
export declare function awsMultiRegionAccessPointDetailsPropertyToTerraform(struct?: AwsMultiRegionAccessPoint.DetailsPropertyOutputReference | AwsMultiRegionAccessPoint.DetailsProperty): any;
export declare function awsMultiRegionAccessPointDetailsPropertyToHclTerraform(struct?: AwsMultiRegionAccessPoint.DetailsPropertyOutputReference | AwsMultiRegionAccessPoint.DetailsProperty): any;
export declare function awsMultiRegionAccessPointTimeoutsPropertyToTerraform(struct?: AwsMultiRegionAccessPoint.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsMultiRegionAccessPointTimeoutsPropertyToHclTerraform(struct?: AwsMultiRegionAccessPoint.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsMultiRegionAccessPoint {
    interface PublicAccessBlockProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point#block_public_acls AwsMultiRegionAccessPoint#block_public_acls}
        */
        readonly blockPublicAcls?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point#block_public_policy AwsMultiRegionAccessPoint#block_public_policy}
        */
        readonly blockPublicPolicy?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point#ignore_public_acls AwsMultiRegionAccessPoint#ignore_public_acls}
        */
        readonly ignorePublicAcls?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point#restrict_public_buckets AwsMultiRegionAccessPoint#restrict_public_buckets}
        */
        readonly restrictPublicBuckets?: boolean | cdktn.IResolvable;
    }
    class PublicAccessBlockPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PublicAccessBlockProperty | undefined;
        set internalValue(value: PublicAccessBlockProperty | undefined);
        private _blockPublicAcls?;
        get blockPublicAcls(): boolean | cdktn.IResolvable;
        set blockPublicAcls(value: boolean | cdktn.IResolvable);
        resetBlockPublicAcls(): void;
        get blockPublicAclsInput(): boolean | cdktn.IResolvable | undefined;
        private _blockPublicPolicy?;
        get blockPublicPolicy(): boolean | cdktn.IResolvable;
        set blockPublicPolicy(value: boolean | cdktn.IResolvable);
        resetBlockPublicPolicy(): void;
        get blockPublicPolicyInput(): boolean | cdktn.IResolvable | undefined;
        private _ignorePublicAcls?;
        get ignorePublicAcls(): boolean | cdktn.IResolvable;
        set ignorePublicAcls(value: boolean | cdktn.IResolvable);
        resetIgnorePublicAcls(): void;
        get ignorePublicAclsInput(): boolean | cdktn.IResolvable | undefined;
        private _restrictPublicBuckets?;
        get restrictPublicBuckets(): boolean | cdktn.IResolvable;
        set restrictPublicBuckets(value: boolean | cdktn.IResolvable);
        resetRestrictPublicBuckets(): void;
        get restrictPublicBucketsInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface RegionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point#bucket AwsMultiRegionAccessPoint#bucket}
        */
        readonly bucket: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point#bucket_account_id AwsMultiRegionAccessPoint#bucket_account_id}
        */
        readonly bucketAccountId?: string;
    }
    class RegionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RegionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RegionProperty | cdktn.IResolvable | undefined);
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        get bucketInput(): string | undefined;
        private _bucketAccountId?;
        get bucketAccountId(): string;
        set bucketAccountId(value: string);
        resetBucketAccountId(): void;
        get bucketAccountIdInput(): string | undefined;
        get region(): string;
    }
    class RegionPropertyList extends cdktn.ComplexList {
        internalValue?: RegionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RegionPropertyOutputReference;
    }
    interface DetailsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point#name AwsMultiRegionAccessPoint#name}
        */
        readonly name: string;
        /**
        * public_access_block block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point#public_access_block AwsMultiRegionAccessPoint#public_access_block}
        */
        readonly publicAccessBlock?: PublicAccessBlockProperty;
        /**
        * region block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point#region AwsMultiRegionAccessPoint#region}
        */
        readonly region: RegionProperty[] | cdktn.IResolvable;
    }
    class DetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DetailsProperty | undefined;
        set internalValue(value: DetailsProperty | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _publicAccessBlock;
        get publicAccessBlock(): PublicAccessBlockPropertyOutputReference;
        putPublicAccessBlock(value: PublicAccessBlockProperty): void;
        resetPublicAccessBlock(): void;
        get publicAccessBlockInput(): PublicAccessBlockProperty | undefined;
        private _region;
        get region(): RegionPropertyList;
        putRegion(value: RegionProperty[] | cdktn.IResolvable): void;
        get regionInput(): cdktn.IResolvable | RegionProperty[] | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point#create AwsMultiRegionAccessPoint#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point#delete AwsMultiRegionAccessPoint#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
