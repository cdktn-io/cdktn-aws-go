import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAccountPublicAccessBlockConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_account_public_access_block#account_id AwsAccountPublicAccessBlock#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_account_public_access_block#block_public_acls AwsAccountPublicAccessBlock#block_public_acls}
    */
    readonly blockPublicAcls?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_account_public_access_block#block_public_policy AwsAccountPublicAccessBlock#block_public_policy}
    */
    readonly blockPublicPolicy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_account_public_access_block#id AwsAccountPublicAccessBlock#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_account_public_access_block#ignore_public_acls AwsAccountPublicAccessBlock#ignore_public_acls}
    */
    readonly ignorePublicAcls?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_account_public_access_block#restrict_public_buckets AwsAccountPublicAccessBlock#restrict_public_buckets}
    */
    readonly restrictPublicBuckets?: boolean | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_account_public_access_block aws_s3_account_public_access_block}
*/
export declare class AwsAccountPublicAccessBlock extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_s3_account_public_access_block";
    /**
    * Generates CDKTN code for importing a AwsAccountPublicAccessBlock resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsAccountPublicAccessBlock to import
    * @param importFromId The id of the existing AwsAccountPublicAccessBlock that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_account_public_access_block#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsAccountPublicAccessBlock to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_account_public_access_block aws_s3_account_public_access_block} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAccountPublicAccessBlockConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AwsAccountPublicAccessBlockConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _blockPublicAcls?;
    get blockPublicAcls(): boolean | cdktn.IResolvable;
    set blockPublicAcls(value: boolean | cdktn.IResolvable);
    resetBlockPublicAcls(): void;
    get blockPublicAclsInput(): boolean | cdktn.IResolvable | undefined;
    private _blockPublicPolicy?;
    get blockPublicPolicy(): boolean | cdktn.IResolvable;
    set blockPublicPolicy(value: boolean | cdktn.IResolvable);
    resetBlockPublicPolicy(): void;
    get blockPublicPolicyInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ignorePublicAcls?;
    get ignorePublicAcls(): boolean | cdktn.IResolvable;
    set ignorePublicAcls(value: boolean | cdktn.IResolvable);
    resetIgnorePublicAcls(): void;
    get ignorePublicAclsInput(): boolean | cdktn.IResolvable | undefined;
    private _restrictPublicBuckets?;
    get restrictPublicBuckets(): boolean | cdktn.IResolvable;
    set restrictPublicBuckets(value: boolean | cdktn.IResolvable);
    resetRestrictPublicBuckets(): void;
    get restrictPublicBucketsInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
