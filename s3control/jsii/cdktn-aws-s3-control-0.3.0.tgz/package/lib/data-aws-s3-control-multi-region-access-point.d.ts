import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsMultiRegionAccessPointConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3control_multi_region_access_point#account_id DataAwsMultiRegionAccessPoint#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3control_multi_region_access_point#id DataAwsMultiRegionAccessPoint#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3control_multi_region_access_point#name DataAwsMultiRegionAccessPoint#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3control_multi_region_access_point#region DataAwsMultiRegionAccessPoint#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3control_multi_region_access_point aws_s3control_multi_region_access_point}
*/
export declare class DataAwsMultiRegionAccessPoint extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_s3control_multi_region_access_point";
    /**
    * Generates CDKTN code for importing a DataAwsMultiRegionAccessPoint resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsMultiRegionAccessPoint to import
    * @param importFromId The id of the existing DataAwsMultiRegionAccessPoint that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3control_multi_region_access_point#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsMultiRegionAccessPoint to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3control_multi_region_access_point aws_s3control_multi_region_access_point} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsMultiRegionAccessPointConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsMultiRegionAccessPointConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get alias(): string;
    get arn(): string;
    get createdAt(): string;
    get domainName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _publicAccessBlock;
    get publicAccessBlock(): DataAwsMultiRegionAccessPoint.PublicAccessBlockPropertyList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _regions;
    get regions(): DataAwsMultiRegionAccessPoint.RegionsPropertyList;
    get status(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsMultiRegionAccessPointPublicAccessBlockPropertyToTerraform(struct?: DataAwsMultiRegionAccessPoint.PublicAccessBlockProperty): any;
export declare function dataAwsMultiRegionAccessPointPublicAccessBlockPropertyToHclTerraform(struct?: DataAwsMultiRegionAccessPoint.PublicAccessBlockProperty): any;
export declare function dataAwsMultiRegionAccessPointRegionsPropertyToTerraform(struct?: DataAwsMultiRegionAccessPoint.RegionsProperty): any;
export declare function dataAwsMultiRegionAccessPointRegionsPropertyToHclTerraform(struct?: DataAwsMultiRegionAccessPoint.RegionsProperty): any;
export declare namespace DataAwsMultiRegionAccessPoint {
    interface PublicAccessBlockProperty {
    }
    class PublicAccessBlockPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PublicAccessBlockProperty | undefined;
        set internalValue(value: PublicAccessBlockProperty | undefined);
        get blockPublicAcls(): cdktn.IResolvable;
        get blockPublicPolicy(): cdktn.IResolvable;
        get ignorePublicAcls(): cdktn.IResolvable;
        get restrictPublicBuckets(): cdktn.IResolvable;
    }
    class PublicAccessBlockPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PublicAccessBlockPropertyOutputReference;
    }
    interface RegionsProperty {
    }
    class RegionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RegionsProperty | undefined;
        set internalValue(value: RegionsProperty | undefined);
        get bucket(): string;
        get bucketAccountId(): string;
        get region(): string;
    }
    class RegionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RegionsPropertyOutputReference;
    }
}
