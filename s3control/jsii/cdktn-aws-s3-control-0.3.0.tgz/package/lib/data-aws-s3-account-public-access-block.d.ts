import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsAccountPublicAccessBlockConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3_account_public_access_block#account_id DataAwsAccountPublicAccessBlock#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3_account_public_access_block#id DataAwsAccountPublicAccessBlock#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3_account_public_access_block aws_s3_account_public_access_block}
*/
export declare class DataAwsAccountPublicAccessBlock extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_s3_account_public_access_block";
    /**
    * Generates CDKTN code for importing a DataAwsAccountPublicAccessBlock resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsAccountPublicAccessBlock to import
    * @param importFromId The id of the existing DataAwsAccountPublicAccessBlock that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3_account_public_access_block#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsAccountPublicAccessBlock to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3_account_public_access_block aws_s3_account_public_access_block} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsAccountPublicAccessBlockConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsAccountPublicAccessBlockConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get blockPublicAcls(): cdktn.IResolvable;
    get blockPublicPolicy(): cdktn.IResolvable;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get ignorePublicAcls(): cdktn.IResolvable;
    get restrictPublicBuckets(): cdktn.IResolvable;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
