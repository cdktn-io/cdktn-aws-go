import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsMultiRegionAccessPointsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3control_multi_region_access_points#account_id DataAwsMultiRegionAccessPoints#account_id}
    */
    readonly accountId?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3control_multi_region_access_points#region DataAwsMultiRegionAccessPoints#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3control_multi_region_access_points aws_s3control_multi_region_access_points}
*/
export declare class DataAwsMultiRegionAccessPoints extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_s3control_multi_region_access_points";
    /**
    * Generates CDKTN code for importing a DataAwsMultiRegionAccessPoints resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsMultiRegionAccessPoints to import
    * @param importFromId The id of the existing DataAwsMultiRegionAccessPoints that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3control_multi_region_access_points#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsMultiRegionAccessPoints to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3control_multi_region_access_points aws_s3control_multi_region_access_points} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsMultiRegionAccessPointsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsMultiRegionAccessPointsConfig);
    private _accessPoints;
    get accessPoints(): DataAwsMultiRegionAccessPoints.AccessPointsPropertyList;
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsMultiRegionAccessPointsPublicAccessBlockPropertyToTerraform(struct?: DataAwsMultiRegionAccessPoints.PublicAccessBlockProperty): any;
export declare function dataAwsMultiRegionAccessPointsPublicAccessBlockPropertyToHclTerraform(struct?: DataAwsMultiRegionAccessPoints.PublicAccessBlockProperty): any;
export declare function dataAwsMultiRegionAccessPointsRegionsPropertyToTerraform(struct?: DataAwsMultiRegionAccessPoints.RegionsProperty): any;
export declare function dataAwsMultiRegionAccessPointsRegionsPropertyToHclTerraform(struct?: DataAwsMultiRegionAccessPoints.RegionsProperty): any;
export declare function dataAwsMultiRegionAccessPointsAccessPointsPropertyToTerraform(struct?: DataAwsMultiRegionAccessPoints.AccessPointsProperty): any;
export declare function dataAwsMultiRegionAccessPointsAccessPointsPropertyToHclTerraform(struct?: DataAwsMultiRegionAccessPoints.AccessPointsProperty): any;
export declare namespace DataAwsMultiRegionAccessPoints {
    interface PublicAccessBlockProperty {
    }
    class PublicAccessBlockPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PublicAccessBlockProperty | undefined;
        set internalValue(value: PublicAccessBlockProperty | undefined);
        get blockPublicAcls(): cdktn.IResolvable;
        get blockPublicPolicy(): cdktn.IResolvable;
        get ignorePublicAcls(): cdktn.IResolvable;
        get restrictPublicBuckets(): cdktn.IResolvable;
    }
    class PublicAccessBlockPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PublicAccessBlockPropertyOutputReference;
    }
    interface RegionsProperty {
    }
    class RegionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RegionsProperty | undefined;
        set internalValue(value: RegionsProperty | undefined);
        get bucket(): string;
        get bucketAccountId(): string;
        get region(): string;
    }
    class RegionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RegionsPropertyOutputReference;
    }
    interface AccessPointsProperty {
    }
    class AccessPointsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AccessPointsProperty | undefined;
        set internalValue(value: AccessPointsProperty | undefined);
        get alias(): string;
        get createdAt(): string;
        get name(): string;
        private _publicAccessBlock;
        get publicAccessBlock(): PublicAccessBlockPropertyList;
        private _regions;
        get regions(): RegionsPropertyList;
        get status(): string;
    }
    class AccessPointsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AccessPointsPropertyOutputReference;
    }
}
