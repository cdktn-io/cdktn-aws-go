import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSlackChannelConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chatbot_slack_channel_configuration#configuration_name AwsSlackChannelConfiguration#configuration_name}
    */
    readonly configurationName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chatbot_slack_channel_configuration#guardrail_policy_arns AwsSlackChannelConfiguration#guardrail_policy_arns}
    */
    readonly guardrailPolicyArns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chatbot_slack_channel_configuration#iam_role_arn AwsSlackChannelConfiguration#iam_role_arn}
    */
    readonly iamRoleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chatbot_slack_channel_configuration#logging_level AwsSlackChannelConfiguration#logging_level}
    */
    readonly loggingLevel?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chatbot_slack_channel_configuration#region AwsSlackChannelConfiguration#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chatbot_slack_channel_configuration#slack_channel_id AwsSlackChannelConfiguration#slack_channel_id}
    */
    readonly slackChannelId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chatbot_slack_channel_configuration#slack_team_id AwsSlackChannelConfiguration#slack_team_id}
    */
    readonly slackTeamId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chatbot_slack_channel_configuration#sns_topic_arns AwsSlackChannelConfiguration#sns_topic_arns}
    */
    readonly snsTopicArns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chatbot_slack_channel_configuration#tags AwsSlackChannelConfiguration#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chatbot_slack_channel_configuration#user_authorization_required AwsSlackChannelConfiguration#user_authorization_required}
    */
    readonly userAuthorizationRequired?: boolean | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chatbot_slack_channel_configuration#timeouts AwsSlackChannelConfiguration#timeouts}
    */
    readonly timeouts?: AwsSlackChannelConfiguration.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chatbot_slack_channel_configuration aws_chatbot_slack_channel_configuration}
*/
export declare class AwsSlackChannelConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_chatbot_slack_channel_configuration";
    /**
    * Generates CDKTN code for importing a AwsSlackChannelConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSlackChannelConfiguration to import
    * @param importFromId The id of the existing AwsSlackChannelConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chatbot_slack_channel_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSlackChannelConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chatbot_slack_channel_configuration aws_chatbot_slack_channel_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSlackChannelConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AwsSlackChannelConfigurationConfig);
    get chatConfigurationArn(): string;
    private _configurationName?;
    get configurationName(): string;
    set configurationName(value: string);
    get configurationNameInput(): string | undefined;
    private _guardrailPolicyArns?;
    get guardrailPolicyArns(): string[];
    set guardrailPolicyArns(value: string[]);
    resetGuardrailPolicyArns(): void;
    get guardrailPolicyArnsInput(): string[] | undefined;
    private _iamRoleArn?;
    get iamRoleArn(): string;
    set iamRoleArn(value: string);
    get iamRoleArnInput(): string | undefined;
    private _loggingLevel?;
    get loggingLevel(): string;
    set loggingLevel(value: string);
    resetLoggingLevel(): void;
    get loggingLevelInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _slackChannelId?;
    get slackChannelId(): string;
    set slackChannelId(value: string);
    get slackChannelIdInput(): string | undefined;
    get slackChannelName(): string;
    private _slackTeamId?;
    get slackTeamId(): string;
    set slackTeamId(value: string);
    get slackTeamIdInput(): string | undefined;
    get slackTeamName(): string;
    private _snsTopicArns?;
    get snsTopicArns(): string[];
    set snsTopicArns(value: string[]);
    resetSnsTopicArns(): void;
    get snsTopicArnsInput(): string[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _userAuthorizationRequired?;
    get userAuthorizationRequired(): boolean | cdktn.IResolvable;
    set userAuthorizationRequired(value: boolean | cdktn.IResolvable);
    resetUserAuthorizationRequired(): void;
    get userAuthorizationRequiredInput(): boolean | cdktn.IResolvable | undefined;
    private _timeouts;
    get timeouts(): AwsSlackChannelConfiguration.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsSlackChannelConfiguration.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsSlackChannelConfiguration.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsSlackChannelConfigurationTimeoutsPropertyToTerraform(struct?: AwsSlackChannelConfiguration.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsSlackChannelConfigurationTimeoutsPropertyToHclTerraform(struct?: AwsSlackChannelConfiguration.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsSlackChannelConfiguration {
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chatbot_slack_channel_configuration#create AwsSlackChannelConfiguration#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chatbot_slack_channel_configuration#delete AwsSlackChannelConfiguration#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chatbot_slack_channel_configuration#update AwsSlackChannelConfiguration#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
