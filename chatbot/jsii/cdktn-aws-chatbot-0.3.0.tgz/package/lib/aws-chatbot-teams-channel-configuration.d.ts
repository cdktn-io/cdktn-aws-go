import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsTeamsChannelConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chatbot_teams_channel_configuration#channel_id AwsTeamsChannelConfiguration#channel_id}
    */
    readonly channelId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chatbot_teams_channel_configuration#channel_name AwsTeamsChannelConfiguration#channel_name}
    */
    readonly channelName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chatbot_teams_channel_configuration#configuration_name AwsTeamsChannelConfiguration#configuration_name}
    */
    readonly configurationName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chatbot_teams_channel_configuration#guardrail_policy_arns AwsTeamsChannelConfiguration#guardrail_policy_arns}
    */
    readonly guardrailPolicyArns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chatbot_teams_channel_configuration#iam_role_arn AwsTeamsChannelConfiguration#iam_role_arn}
    */
    readonly iamRoleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chatbot_teams_channel_configuration#logging_level AwsTeamsChannelConfiguration#logging_level}
    */
    readonly loggingLevel?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chatbot_teams_channel_configuration#region AwsTeamsChannelConfiguration#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chatbot_teams_channel_configuration#sns_topic_arns AwsTeamsChannelConfiguration#sns_topic_arns}
    */
    readonly snsTopicArns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chatbot_teams_channel_configuration#tags AwsTeamsChannelConfiguration#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chatbot_teams_channel_configuration#team_id AwsTeamsChannelConfiguration#team_id}
    */
    readonly teamId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chatbot_teams_channel_configuration#team_name AwsTeamsChannelConfiguration#team_name}
    */
    readonly teamName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chatbot_teams_channel_configuration#tenant_id AwsTeamsChannelConfiguration#tenant_id}
    */
    readonly tenantId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chatbot_teams_channel_configuration#user_authorization_required AwsTeamsChannelConfiguration#user_authorization_required}
    */
    readonly userAuthorizationRequired?: boolean | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chatbot_teams_channel_configuration#timeouts AwsTeamsChannelConfiguration#timeouts}
    */
    readonly timeouts?: AwsTeamsChannelConfiguration.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chatbot_teams_channel_configuration aws_chatbot_teams_channel_configuration}
*/
export declare class AwsTeamsChannelConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_chatbot_teams_channel_configuration";
    /**
    * Generates CDKTN code for importing a AwsTeamsChannelConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsTeamsChannelConfiguration to import
    * @param importFromId The id of the existing AwsTeamsChannelConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chatbot_teams_channel_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsTeamsChannelConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chatbot_teams_channel_configuration aws_chatbot_teams_channel_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsTeamsChannelConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AwsTeamsChannelConfigurationConfig);
    private _channelId?;
    get channelId(): string;
    set channelId(value: string);
    get channelIdInput(): string | undefined;
    private _channelName?;
    get channelName(): string;
    set channelName(value: string);
    resetChannelName(): void;
    get channelNameInput(): string | undefined;
    get chatConfigurationArn(): string;
    private _configurationName?;
    get configurationName(): string;
    set configurationName(value: string);
    get configurationNameInput(): string | undefined;
    private _guardrailPolicyArns?;
    get guardrailPolicyArns(): string[];
    set guardrailPolicyArns(value: string[]);
    resetGuardrailPolicyArns(): void;
    get guardrailPolicyArnsInput(): string[] | undefined;
    private _iamRoleArn?;
    get iamRoleArn(): string;
    set iamRoleArn(value: string);
    get iamRoleArnInput(): string | undefined;
    private _loggingLevel?;
    get loggingLevel(): string;
    set loggingLevel(value: string);
    resetLoggingLevel(): void;
    get loggingLevelInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _snsTopicArns?;
    get snsTopicArns(): string[];
    set snsTopicArns(value: string[]);
    resetSnsTopicArns(): void;
    get snsTopicArnsInput(): string[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _teamId?;
    get teamId(): string;
    set teamId(value: string);
    get teamIdInput(): string | undefined;
    private _teamName?;
    get teamName(): string;
    set teamName(value: string);
    resetTeamName(): void;
    get teamNameInput(): string | undefined;
    private _tenantId?;
    get tenantId(): string;
    set tenantId(value: string);
    get tenantIdInput(): string | undefined;
    private _userAuthorizationRequired?;
    get userAuthorizationRequired(): boolean | cdktn.IResolvable;
    set userAuthorizationRequired(value: boolean | cdktn.IResolvable);
    resetUserAuthorizationRequired(): void;
    get userAuthorizationRequiredInput(): boolean | cdktn.IResolvable | undefined;
    private _timeouts;
    get timeouts(): AwsTeamsChannelConfiguration.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsTeamsChannelConfiguration.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsTeamsChannelConfiguration.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsTeamsChannelConfigurationTimeoutsPropertyToTerraform(struct?: AwsTeamsChannelConfiguration.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsTeamsChannelConfigurationTimeoutsPropertyToHclTerraform(struct?: AwsTeamsChannelConfiguration.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsTeamsChannelConfiguration {
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chatbot_teams_channel_configuration#create AwsTeamsChannelConfiguration#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chatbot_teams_channel_configuration#delete AwsTeamsChannelConfiguration#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chatbot_teams_channel_configuration#update AwsTeamsChannelConfiguration#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
