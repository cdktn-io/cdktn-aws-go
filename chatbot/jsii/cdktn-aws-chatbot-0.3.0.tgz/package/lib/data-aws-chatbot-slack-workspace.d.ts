import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsSlackWorkspaceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/chatbot_slack_workspace#region DataAwsSlackWorkspace#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/chatbot_slack_workspace#slack_team_name DataAwsSlackWorkspace#slack_team_name}
    */
    readonly slackTeamName: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/chatbot_slack_workspace aws_chatbot_slack_workspace}
*/
export declare class DataAwsSlackWorkspace extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_chatbot_slack_workspace";
    /**
    * Generates CDKTN code for importing a DataAwsSlackWorkspace resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsSlackWorkspace to import
    * @param importFromId The id of the existing DataAwsSlackWorkspace that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/chatbot_slack_workspace#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsSlackWorkspace to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/chatbot_slack_workspace aws_chatbot_slack_workspace} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsSlackWorkspaceConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsSlackWorkspaceConfig);
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get slackTeamId(): string;
    private _slackTeamName?;
    get slackTeamName(): string;
    set slackTeamName(value: string);
    get slackTeamNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
