import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsConfiguredTableConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_configured_table#allowed_columns AwsConfiguredTable#allowed_columns}
    */
    readonly allowedColumns: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_configured_table#analysis_method AwsConfiguredTable#analysis_method}
    */
    readonly analysisMethod: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_configured_table#description AwsConfiguredTable#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_configured_table#id AwsConfiguredTable#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_configured_table#name AwsConfiguredTable#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_configured_table#region AwsConfiguredTable#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_configured_table#tags AwsConfiguredTable#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_configured_table#tags_all AwsConfiguredTable#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * table_reference block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_configured_table#table_reference AwsConfiguredTable#table_reference}
    */
    readonly tableReference: AwsConfiguredTable.TableReferenceProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_configured_table#timeouts AwsConfiguredTable#timeouts}
    */
    readonly timeouts?: AwsConfiguredTable.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_configured_table aws_cleanrooms_configured_table}
*/
export declare class AwsConfiguredTable extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cleanrooms_configured_table";
    /**
    * Generates CDKTN code for importing a AwsConfiguredTable resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsConfiguredTable to import
    * @param importFromId The id of the existing AwsConfiguredTable that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_configured_table#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsConfiguredTable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_configured_table aws_cleanrooms_configured_table} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsConfiguredTableConfig
    */
    constructor(scope: Construct, id: string, config: AwsConfiguredTableConfig);
    private _allowedColumns?;
    get allowedColumns(): string[];
    set allowedColumns(value: string[]);
    get allowedColumnsInput(): string[] | undefined;
    private _analysisMethod?;
    get analysisMethod(): string;
    set analysisMethod(value: string);
    get analysisMethodInput(): string | undefined;
    get arn(): string;
    get createTime(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get updateTime(): string;
    private _tableReference;
    get tableReference(): AwsConfiguredTable.TableReferencePropertyOutputReference;
    putTableReference(value: AwsConfiguredTable.TableReferenceProperty): void;
    get tableReferenceInput(): AwsConfiguredTable.TableReferenceProperty | undefined;
    private _timeouts;
    get timeouts(): AwsConfiguredTable.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsConfiguredTable.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsConfiguredTable.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsConfiguredTableTableReferencePropertyToTerraform(struct?: AwsConfiguredTable.TableReferencePropertyOutputReference | AwsConfiguredTable.TableReferenceProperty): any;
export declare function awsConfiguredTableTableReferencePropertyToHclTerraform(struct?: AwsConfiguredTable.TableReferencePropertyOutputReference | AwsConfiguredTable.TableReferenceProperty): any;
export declare function awsConfiguredTableTimeoutsPropertyToTerraform(struct?: AwsConfiguredTable.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsConfiguredTableTimeoutsPropertyToHclTerraform(struct?: AwsConfiguredTable.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsConfiguredTable {
    interface TableReferenceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_configured_table#database_name AwsConfiguredTable#database_name}
        */
        readonly databaseName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_configured_table#table_name AwsConfiguredTable#table_name}
        */
        readonly tableName: string;
    }
    class TableReferencePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TableReferenceProperty | undefined;
        set internalValue(value: TableReferenceProperty | undefined);
        private _databaseName?;
        get databaseName(): string;
        set databaseName(value: string);
        get databaseNameInput(): string | undefined;
        private _tableName?;
        get tableName(): string;
        set tableName(value: string);
        get tableNameInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_configured_table#create AwsConfiguredTable#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_configured_table#delete AwsConfiguredTable#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_configured_table#update AwsConfiguredTable#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
