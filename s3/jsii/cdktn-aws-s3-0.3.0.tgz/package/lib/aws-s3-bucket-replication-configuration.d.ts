import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsBucketReplicationConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_replication_configuration#bucket AwsBucketReplicationConfiguration#bucket}
    */
    readonly bucket: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_replication_configuration#id AwsBucketReplicationConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_replication_configuration#region AwsBucketReplicationConfiguration#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_replication_configuration#role AwsBucketReplicationConfiguration#role}
    */
    readonly role: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_replication_configuration#token AwsBucketReplicationConfiguration#token}
    */
    readonly token?: string;
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_replication_configuration#rule AwsBucketReplicationConfiguration#rule}
    */
    readonly rule: AwsBucketReplicationConfiguration.RuleProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_replication_configuration aws_s3_bucket_replication_configuration}
*/
export declare class AwsBucketReplicationConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_s3_bucket_replication_configuration";
    /**
    * Generates CDKTN code for importing a AwsBucketReplicationConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsBucketReplicationConfiguration to import
    * @param importFromId The id of the existing AwsBucketReplicationConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_replication_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsBucketReplicationConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_replication_configuration aws_s3_bucket_replication_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsBucketReplicationConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AwsBucketReplicationConfigurationConfig);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _role?;
    get role(): string;
    set role(value: string);
    get roleInput(): string | undefined;
    private _token?;
    get token(): string;
    set token(value: string);
    resetToken(): void;
    get tokenInput(): string | undefined;
    private _rule;
    get rule(): AwsBucketReplicationConfiguration.RulePropertyList;
    putRule(value: AwsBucketReplicationConfiguration.RuleProperty[] | cdktn.IResolvable): void;
    get ruleInput(): cdktn.IResolvable | AwsBucketReplicationConfiguration.RuleProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsBucketReplicationConfigurationDeleteMarkerReplicationPropertyToTerraform(struct?: AwsBucketReplicationConfiguration.DeleteMarkerReplicationPropertyOutputReference | AwsBucketReplicationConfiguration.DeleteMarkerReplicationProperty): any;
export declare function awsBucketReplicationConfigurationDeleteMarkerReplicationPropertyToHclTerraform(struct?: AwsBucketReplicationConfiguration.DeleteMarkerReplicationPropertyOutputReference | AwsBucketReplicationConfiguration.DeleteMarkerReplicationProperty): any;
export declare function awsBucketReplicationConfigurationAccessControlTranslationPropertyToTerraform(struct?: AwsBucketReplicationConfiguration.AccessControlTranslationPropertyOutputReference | AwsBucketReplicationConfiguration.AccessControlTranslationProperty): any;
export declare function awsBucketReplicationConfigurationAccessControlTranslationPropertyToHclTerraform(struct?: AwsBucketReplicationConfiguration.AccessControlTranslationPropertyOutputReference | AwsBucketReplicationConfiguration.AccessControlTranslationProperty): any;
export declare function awsBucketReplicationConfigurationEncryptionConfigurationPropertyToTerraform(struct?: AwsBucketReplicationConfiguration.EncryptionConfigurationPropertyOutputReference | AwsBucketReplicationConfiguration.EncryptionConfigurationProperty): any;
export declare function awsBucketReplicationConfigurationEncryptionConfigurationPropertyToHclTerraform(struct?: AwsBucketReplicationConfiguration.EncryptionConfigurationPropertyOutputReference | AwsBucketReplicationConfiguration.EncryptionConfigurationProperty): any;
export declare function awsBucketReplicationConfigurationEventThresholdPropertyToTerraform(struct?: AwsBucketReplicationConfiguration.EventThresholdPropertyOutputReference | AwsBucketReplicationConfiguration.EventThresholdProperty): any;
export declare function awsBucketReplicationConfigurationEventThresholdPropertyToHclTerraform(struct?: AwsBucketReplicationConfiguration.EventThresholdPropertyOutputReference | AwsBucketReplicationConfiguration.EventThresholdProperty): any;
export declare function awsBucketReplicationConfigurationMetricsPropertyToTerraform(struct?: AwsBucketReplicationConfiguration.MetricsPropertyOutputReference | AwsBucketReplicationConfiguration.MetricsProperty): any;
export declare function awsBucketReplicationConfigurationMetricsPropertyToHclTerraform(struct?: AwsBucketReplicationConfiguration.MetricsPropertyOutputReference | AwsBucketReplicationConfiguration.MetricsProperty): any;
export declare function awsBucketReplicationConfigurationTimePropertyToTerraform(struct?: AwsBucketReplicationConfiguration.TimePropertyOutputReference | AwsBucketReplicationConfiguration.TimeProperty): any;
export declare function awsBucketReplicationConfigurationTimePropertyToHclTerraform(struct?: AwsBucketReplicationConfiguration.TimePropertyOutputReference | AwsBucketReplicationConfiguration.TimeProperty): any;
export declare function awsBucketReplicationConfigurationReplicationTimePropertyToTerraform(struct?: AwsBucketReplicationConfiguration.ReplicationTimePropertyOutputReference | AwsBucketReplicationConfiguration.ReplicationTimeProperty): any;
export declare function awsBucketReplicationConfigurationReplicationTimePropertyToHclTerraform(struct?: AwsBucketReplicationConfiguration.ReplicationTimePropertyOutputReference | AwsBucketReplicationConfiguration.ReplicationTimeProperty): any;
export declare function awsBucketReplicationConfigurationDestinationPropertyToTerraform(struct?: AwsBucketReplicationConfiguration.DestinationPropertyOutputReference | AwsBucketReplicationConfiguration.DestinationProperty): any;
export declare function awsBucketReplicationConfigurationDestinationPropertyToHclTerraform(struct?: AwsBucketReplicationConfiguration.DestinationPropertyOutputReference | AwsBucketReplicationConfiguration.DestinationProperty): any;
export declare function awsBucketReplicationConfigurationExistingObjectReplicationPropertyToTerraform(struct?: AwsBucketReplicationConfiguration.ExistingObjectReplicationPropertyOutputReference | AwsBucketReplicationConfiguration.ExistingObjectReplicationProperty): any;
export declare function awsBucketReplicationConfigurationExistingObjectReplicationPropertyToHclTerraform(struct?: AwsBucketReplicationConfiguration.ExistingObjectReplicationPropertyOutputReference | AwsBucketReplicationConfiguration.ExistingObjectReplicationProperty): any;
export declare function awsBucketReplicationConfigurationAndPropertyToTerraform(struct?: AwsBucketReplicationConfiguration.AndPropertyOutputReference | AwsBucketReplicationConfiguration.AndProperty): any;
export declare function awsBucketReplicationConfigurationAndPropertyToHclTerraform(struct?: AwsBucketReplicationConfiguration.AndPropertyOutputReference | AwsBucketReplicationConfiguration.AndProperty): any;
export declare function awsBucketReplicationConfigurationTagPropertyToTerraform(struct?: AwsBucketReplicationConfiguration.TagPropertyOutputReference | AwsBucketReplicationConfiguration.TagProperty): any;
export declare function awsBucketReplicationConfigurationTagPropertyToHclTerraform(struct?: AwsBucketReplicationConfiguration.TagPropertyOutputReference | AwsBucketReplicationConfiguration.TagProperty): any;
export declare function awsBucketReplicationConfigurationFilterPropertyToTerraform(struct?: AwsBucketReplicationConfiguration.FilterPropertyOutputReference | AwsBucketReplicationConfiguration.FilterProperty): any;
export declare function awsBucketReplicationConfigurationFilterPropertyToHclTerraform(struct?: AwsBucketReplicationConfiguration.FilterPropertyOutputReference | AwsBucketReplicationConfiguration.FilterProperty): any;
export declare function awsBucketReplicationConfigurationReplicaModificationsPropertyToTerraform(struct?: AwsBucketReplicationConfiguration.ReplicaModificationsPropertyOutputReference | AwsBucketReplicationConfiguration.ReplicaModificationsProperty): any;
export declare function awsBucketReplicationConfigurationReplicaModificationsPropertyToHclTerraform(struct?: AwsBucketReplicationConfiguration.ReplicaModificationsPropertyOutputReference | AwsBucketReplicationConfiguration.ReplicaModificationsProperty): any;
export declare function awsBucketReplicationConfigurationSseKmsEncryptedObjectsPropertyToTerraform(struct?: AwsBucketReplicationConfiguration.SseKmsEncryptedObjectsPropertyOutputReference | AwsBucketReplicationConfiguration.SseKmsEncryptedObjectsProperty): any;
export declare function awsBucketReplicationConfigurationSseKmsEncryptedObjectsPropertyToHclTerraform(struct?: AwsBucketReplicationConfiguration.SseKmsEncryptedObjectsPropertyOutputReference | AwsBucketReplicationConfiguration.SseKmsEncryptedObjectsProperty): any;
export declare function awsBucketReplicationConfigurationSourceSelectionCriteriaPropertyToTerraform(struct?: AwsBucketReplicationConfiguration.SourceSelectionCriteriaPropertyOutputReference | AwsBucketReplicationConfiguration.SourceSelectionCriteriaProperty): any;
export declare function awsBucketReplicationConfigurationSourceSelectionCriteriaPropertyToHclTerraform(struct?: AwsBucketReplicationConfiguration.SourceSelectionCriteriaPropertyOutputReference | AwsBucketReplicationConfiguration.SourceSelectionCriteriaProperty): any;
export declare function awsBucketReplicationConfigurationRulePropertyToTerraform(struct?: AwsBucketReplicationConfiguration.RuleProperty | cdktn.IResolvable): any;
export declare function awsBucketReplicationConfigurationRulePropertyToHclTerraform(struct?: AwsBucketReplicationConfiguration.RuleProperty | cdktn.IResolvable): any;
export declare namespace AwsBucketReplicationConfiguration {
    interface DeleteMarkerReplicationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_replication_configuration#status AwsBucketReplicationConfiguration#status}
        */
        readonly status: string;
    }
    class DeleteMarkerReplicationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DeleteMarkerReplicationProperty | undefined;
        set internalValue(value: DeleteMarkerReplicationProperty | undefined);
        private _status?;
        get status(): string;
        set status(value: string);
        get statusInput(): string | undefined;
    }
    interface AccessControlTranslationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_replication_configuration#owner AwsBucketReplicationConfiguration#owner}
        */
        readonly owner: string;
    }
    class AccessControlTranslationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AccessControlTranslationProperty | undefined;
        set internalValue(value: AccessControlTranslationProperty | undefined);
        private _owner?;
        get owner(): string;
        set owner(value: string);
        get ownerInput(): string | undefined;
    }
    interface EncryptionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_replication_configuration#replica_kms_key_id AwsBucketReplicationConfiguration#replica_kms_key_id}
        */
        readonly replicaKmsKeyId: string;
    }
    class EncryptionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncryptionConfigurationProperty | undefined;
        set internalValue(value: EncryptionConfigurationProperty | undefined);
        private _replicaKmsKeyId?;
        get replicaKmsKeyId(): string;
        set replicaKmsKeyId(value: string);
        get replicaKmsKeyIdInput(): string | undefined;
    }
    interface EventThresholdProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_replication_configuration#minutes AwsBucketReplicationConfiguration#minutes}
        */
        readonly minutes: number;
    }
    class EventThresholdPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EventThresholdProperty | undefined;
        set internalValue(value: EventThresholdProperty | undefined);
        private _minutes?;
        get minutes(): number;
        set minutes(value: number);
        get minutesInput(): number | undefined;
    }
    interface MetricsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_replication_configuration#status AwsBucketReplicationConfiguration#status}
        */
        readonly status: string;
        /**
        * event_threshold block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_replication_configuration#event_threshold AwsBucketReplicationConfiguration#event_threshold}
        */
        readonly eventThreshold?: EventThresholdProperty;
    }
    class MetricsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MetricsProperty | undefined;
        set internalValue(value: MetricsProperty | undefined);
        private _status?;
        get status(): string;
        set status(value: string);
        get statusInput(): string | undefined;
        private _eventThreshold;
        get eventThreshold(): EventThresholdPropertyOutputReference;
        putEventThreshold(value: EventThresholdProperty): void;
        resetEventThreshold(): void;
        get eventThresholdInput(): EventThresholdProperty | undefined;
    }
    interface TimeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_replication_configuration#minutes AwsBucketReplicationConfiguration#minutes}
        */
        readonly minutes: number;
    }
    class TimePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeProperty | undefined;
        set internalValue(value: TimeProperty | undefined);
        private _minutes?;
        get minutes(): number;
        set minutes(value: number);
        get minutesInput(): number | undefined;
    }
    interface ReplicationTimeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_replication_configuration#status AwsBucketReplicationConfiguration#status}
        */
        readonly status: string;
        /**
        * time block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_replication_configuration#time AwsBucketReplicationConfiguration#time}
        */
        readonly time: TimeProperty;
    }
    class ReplicationTimePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ReplicationTimeProperty | undefined;
        set internalValue(value: ReplicationTimeProperty | undefined);
        private _status?;
        get status(): string;
        set status(value: string);
        get statusInput(): string | undefined;
        private _time;
        get time(): TimePropertyOutputReference;
        putTime(value: TimeProperty): void;
        get timeInput(): TimeProperty | undefined;
    }
    interface DestinationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_replication_configuration#account AwsBucketReplicationConfiguration#account}
        */
        readonly account?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_replication_configuration#bucket AwsBucketReplicationConfiguration#bucket}
        */
        readonly bucket: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_replication_configuration#storage_class AwsBucketReplicationConfiguration#storage_class}
        */
        readonly storageClass?: string;
        /**
        * access_control_translation block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_replication_configuration#access_control_translation AwsBucketReplicationConfiguration#access_control_translation}
        */
        readonly accessControlTranslation?: AccessControlTranslationProperty;
        /**
        * encryption_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_replication_configuration#encryption_configuration AwsBucketReplicationConfiguration#encryption_configuration}
        */
        readonly encryptionConfiguration?: EncryptionConfigurationProperty;
        /**
        * metrics block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_replication_configuration#metrics AwsBucketReplicationConfiguration#metrics}
        */
        readonly metrics?: MetricsProperty;
        /**
        * replication_time block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_replication_configuration#replication_time AwsBucketReplicationConfiguration#replication_time}
        */
        readonly replicationTime?: ReplicationTimeProperty;
    }
    class DestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationProperty | undefined;
        set internalValue(value: DestinationProperty | undefined);
        private _account?;
        get account(): string;
        set account(value: string);
        resetAccount(): void;
        get accountInput(): string | undefined;
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        get bucketInput(): string | undefined;
        private _storageClass?;
        get storageClass(): string;
        set storageClass(value: string);
        resetStorageClass(): void;
        get storageClassInput(): string | undefined;
        private _accessControlTranslation;
        get accessControlTranslation(): AccessControlTranslationPropertyOutputReference;
        putAccessControlTranslation(value: AccessControlTranslationProperty): void;
        resetAccessControlTranslation(): void;
        get accessControlTranslationInput(): AccessControlTranslationProperty | undefined;
        private _encryptionConfiguration;
        get encryptionConfiguration(): EncryptionConfigurationPropertyOutputReference;
        putEncryptionConfiguration(value: EncryptionConfigurationProperty): void;
        resetEncryptionConfiguration(): void;
        get encryptionConfigurationInput(): EncryptionConfigurationProperty | undefined;
        private _metrics;
        get metrics(): MetricsPropertyOutputReference;
        putMetrics(value: MetricsProperty): void;
        resetMetrics(): void;
        get metricsInput(): MetricsProperty | undefined;
        private _replicationTime;
        get replicationTime(): ReplicationTimePropertyOutputReference;
        putReplicationTime(value: ReplicationTimeProperty): void;
        resetReplicationTime(): void;
        get replicationTimeInput(): ReplicationTimeProperty | undefined;
    }
    interface ExistingObjectReplicationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_replication_configuration#status AwsBucketReplicationConfiguration#status}
        */
        readonly status: string;
    }
    class ExistingObjectReplicationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ExistingObjectReplicationProperty | undefined;
        set internalValue(value: ExistingObjectReplicationProperty | undefined);
        private _status?;
        get status(): string;
        set status(value: string);
        get statusInput(): string | undefined;
    }
    interface AndProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_replication_configuration#prefix AwsBucketReplicationConfiguration#prefix}
        */
        readonly prefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_replication_configuration#tags AwsBucketReplicationConfiguration#tags}
        */
        readonly tags?: {
            [key: string]: string;
        };
    }
    class AndPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AndProperty | undefined;
        set internalValue(value: AndProperty | undefined);
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _tags?;
        get tags(): {
            [key: string]: string;
        };
        set tags(value: {
            [key: string]: string;
        });
        resetTags(): void;
        get tagsInput(): {
            [key: string]: string;
        } | undefined;
    }
    interface TagProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_replication_configuration#key AwsBucketReplicationConfiguration#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_replication_configuration#value AwsBucketReplicationConfiguration#value}
        */
        readonly value: string;
    }
    class TagPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TagProperty | undefined;
        set internalValue(value: TagProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    interface FilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_replication_configuration#prefix AwsBucketReplicationConfiguration#prefix}
        */
        readonly prefix?: string;
        /**
        * and block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_replication_configuration#and AwsBucketReplicationConfiguration#and}
        */
        readonly and?: AndProperty;
        /**
        * tag block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_replication_configuration#tag AwsBucketReplicationConfiguration#tag}
        */
        readonly tag?: TagProperty;
    }
    class FilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterProperty | undefined;
        set internalValue(value: FilterProperty | undefined);
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _and;
        get and(): AndPropertyOutputReference;
        putAnd(value: AndProperty): void;
        resetAnd(): void;
        get andInput(): AndProperty | undefined;
        private _tag;
        get tag(): TagPropertyOutputReference;
        putTag(value: TagProperty): void;
        resetTag(): void;
        get tagInput(): TagProperty | undefined;
    }
    interface ReplicaModificationsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_replication_configuration#status AwsBucketReplicationConfiguration#status}
        */
        readonly status: string;
    }
    class ReplicaModificationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ReplicaModificationsProperty | undefined;
        set internalValue(value: ReplicaModificationsProperty | undefined);
        private _status?;
        get status(): string;
        set status(value: string);
        get statusInput(): string | undefined;
    }
    interface SseKmsEncryptedObjectsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_replication_configuration#status AwsBucketReplicationConfiguration#status}
        */
        readonly status: string;
    }
    class SseKmsEncryptedObjectsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SseKmsEncryptedObjectsProperty | undefined;
        set internalValue(value: SseKmsEncryptedObjectsProperty | undefined);
        private _status?;
        get status(): string;
        set status(value: string);
        get statusInput(): string | undefined;
    }
    interface SourceSelectionCriteriaProperty {
        /**
        * replica_modifications block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_replication_configuration#replica_modifications AwsBucketReplicationConfiguration#replica_modifications}
        */
        readonly replicaModifications?: ReplicaModificationsProperty;
        /**
        * sse_kms_encrypted_objects block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_replication_configuration#sse_kms_encrypted_objects AwsBucketReplicationConfiguration#sse_kms_encrypted_objects}
        */
        readonly sseKmsEncryptedObjects?: SseKmsEncryptedObjectsProperty;
    }
    class SourceSelectionCriteriaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceSelectionCriteriaProperty | undefined;
        set internalValue(value: SourceSelectionCriteriaProperty | undefined);
        private _replicaModifications;
        get replicaModifications(): ReplicaModificationsPropertyOutputReference;
        putReplicaModifications(value: ReplicaModificationsProperty): void;
        resetReplicaModifications(): void;
        get replicaModificationsInput(): ReplicaModificationsProperty | undefined;
        private _sseKmsEncryptedObjects;
        get sseKmsEncryptedObjects(): SseKmsEncryptedObjectsPropertyOutputReference;
        putSseKmsEncryptedObjects(value: SseKmsEncryptedObjectsProperty): void;
        resetSseKmsEncryptedObjects(): void;
        get sseKmsEncryptedObjectsInput(): SseKmsEncryptedObjectsProperty | undefined;
    }
    interface RuleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_replication_configuration#id AwsBucketReplicationConfiguration#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_replication_configuration#prefix AwsBucketReplicationConfiguration#prefix}
        */
        readonly prefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_replication_configuration#priority AwsBucketReplicationConfiguration#priority}
        */
        readonly priority?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_replication_configuration#status AwsBucketReplicationConfiguration#status}
        */
        readonly status: string;
        /**
        * delete_marker_replication block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_replication_configuration#delete_marker_replication AwsBucketReplicationConfiguration#delete_marker_replication}
        */
        readonly deleteMarkerReplication?: DeleteMarkerReplicationProperty;
        /**
        * destination block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_replication_configuration#destination AwsBucketReplicationConfiguration#destination}
        */
        readonly destination: DestinationProperty;
        /**
        * existing_object_replication block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_replication_configuration#existing_object_replication AwsBucketReplicationConfiguration#existing_object_replication}
        */
        readonly existingObjectReplication?: ExistingObjectReplicationProperty;
        /**
        * filter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_replication_configuration#filter AwsBucketReplicationConfiguration#filter}
        */
        readonly filter?: FilterProperty;
        /**
        * source_selection_criteria block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_replication_configuration#source_selection_criteria AwsBucketReplicationConfiguration#source_selection_criteria}
        */
        readonly sourceSelectionCriteria?: SourceSelectionCriteriaProperty;
    }
    class RulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleProperty | cdktn.IResolvable | undefined);
        private _id?;
        get id(): string;
        set id(value: string);
        resetId(): void;
        get idInput(): string | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _priority?;
        get priority(): number;
        set priority(value: number);
        resetPriority(): void;
        get priorityInput(): number | undefined;
        private _status?;
        get status(): string;
        set status(value: string);
        get statusInput(): string | undefined;
        private _deleteMarkerReplication;
        get deleteMarkerReplication(): DeleteMarkerReplicationPropertyOutputReference;
        putDeleteMarkerReplication(value: DeleteMarkerReplicationProperty): void;
        resetDeleteMarkerReplication(): void;
        get deleteMarkerReplicationInput(): DeleteMarkerReplicationProperty | undefined;
        private _destination;
        get destination(): DestinationPropertyOutputReference;
        putDestination(value: DestinationProperty): void;
        get destinationInput(): DestinationProperty | undefined;
        private _existingObjectReplication;
        get existingObjectReplication(): ExistingObjectReplicationPropertyOutputReference;
        putExistingObjectReplication(value: ExistingObjectReplicationProperty): void;
        resetExistingObjectReplication(): void;
        get existingObjectReplicationInput(): ExistingObjectReplicationProperty | undefined;
        private _filter;
        get filter(): FilterPropertyOutputReference;
        putFilter(value: FilterProperty): void;
        resetFilter(): void;
        get filterInput(): FilterProperty | undefined;
        private _sourceSelectionCriteria;
        get sourceSelectionCriteria(): SourceSelectionCriteriaPropertyOutputReference;
        putSourceSelectionCriteria(value: SourceSelectionCriteriaProperty): void;
        resetSourceSelectionCriteria(): void;
        get sourceSelectionCriteriaInput(): SourceSelectionCriteriaProperty | undefined;
    }
    class RulePropertyList extends cdktn.ComplexList {
        internalValue?: RuleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RulePropertyOutputReference;
    }
}
