import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsDirectoryBucketsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3_directory_buckets#region DataAwsDirectoryBuckets#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3_directory_buckets aws_s3_directory_buckets}
*/
export declare class DataAwsDirectoryBuckets extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_s3_directory_buckets";
    /**
    * Generates CDKTN code for importing a DataAwsDirectoryBuckets resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsDirectoryBuckets to import
    * @param importFromId The id of the existing DataAwsDirectoryBuckets that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3_directory_buckets#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsDirectoryBuckets to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3_directory_buckets aws_s3_directory_buckets} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsDirectoryBucketsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsDirectoryBucketsConfig);
    get arns(): string[];
    get buckets(): string[];
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
