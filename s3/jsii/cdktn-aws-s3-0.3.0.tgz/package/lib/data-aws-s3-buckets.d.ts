import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsBucketsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3_buckets#bucket_region DataAwsBuckets#bucket_region}
    */
    readonly bucketRegion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3_buckets#max_buckets DataAwsBuckets#max_buckets}
    */
    readonly maxBuckets?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3_buckets#prefix DataAwsBuckets#prefix}
    */
    readonly prefix?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3_buckets#region DataAwsBuckets#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3_buckets aws_s3_buckets}
*/
export declare class DataAwsBuckets extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_s3_buckets";
    /**
    * Generates CDKTN code for importing a DataAwsBuckets resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsBuckets to import
    * @param importFromId The id of the existing DataAwsBuckets that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3_buckets#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsBuckets to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3_buckets aws_s3_buckets} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsBucketsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsBucketsConfig);
    private _bucketRegion?;
    get bucketRegion(): string;
    set bucketRegion(value: string);
    resetBucketRegion(): void;
    get bucketRegionInput(): string | undefined;
    private _buckets;
    get buckets(): DataAwsBuckets.BucketsPropertyList;
    private _maxBuckets?;
    get maxBuckets(): number;
    set maxBuckets(value: number);
    resetMaxBuckets(): void;
    get maxBucketsInput(): number | undefined;
    private _prefix?;
    get prefix(): string;
    set prefix(value: string);
    resetPrefix(): void;
    get prefixInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsBucketsBucketsPropertyToTerraform(struct?: DataAwsBuckets.BucketsProperty): any;
export declare function dataAwsBucketsBucketsPropertyToHclTerraform(struct?: DataAwsBuckets.BucketsProperty): any;
export declare namespace DataAwsBuckets {
    interface BucketsProperty {
    }
    class BucketsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BucketsProperty | undefined;
        set internalValue(value: BucketsProperty | undefined);
        get bucketArn(): string;
        get bucketRegion(): string;
        get creationDate(): string;
        get name(): string;
    }
    class BucketsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BucketsPropertyOutputReference;
    }
}
