import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsBucketInventoryConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_inventory#bucket AwsBucketInventory#bucket}
    */
    readonly bucket: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_inventory#enabled AwsBucketInventory#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_inventory#id AwsBucketInventory#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_inventory#included_object_versions AwsBucketInventory#included_object_versions}
    */
    readonly includedObjectVersions: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_inventory#name AwsBucketInventory#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_inventory#optional_fields AwsBucketInventory#optional_fields}
    */
    readonly optionalFields?: string[];
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_inventory#region AwsBucketInventory#region}
    */
    readonly region?: string;
    /**
    * destination block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_inventory#destination AwsBucketInventory#destination}
    */
    readonly destination: AwsBucketInventory.DestinationProperty;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_inventory#filter AwsBucketInventory#filter}
    */
    readonly filter?: AwsBucketInventory.FilterProperty;
    /**
    * schedule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_inventory#schedule AwsBucketInventory#schedule}
    */
    readonly schedule: AwsBucketInventory.ScheduleProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_inventory aws_s3_bucket_inventory}
*/
export declare class AwsBucketInventory extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_s3_bucket_inventory";
    /**
    * Generates CDKTN code for importing a AwsBucketInventory resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsBucketInventory to import
    * @param importFromId The id of the existing AwsBucketInventory that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_inventory#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsBucketInventory to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_inventory aws_s3_bucket_inventory} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsBucketInventoryConfig
    */
    constructor(scope: Construct, id: string, config: AwsBucketInventoryConfig);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _includedObjectVersions?;
    get includedObjectVersions(): string;
    set includedObjectVersions(value: string);
    get includedObjectVersionsInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _optionalFields?;
    get optionalFields(): string[];
    set optionalFields(value: string[]);
    resetOptionalFields(): void;
    get optionalFieldsInput(): string[] | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _destination;
    get destination(): AwsBucketInventory.DestinationPropertyOutputReference;
    putDestination(value: AwsBucketInventory.DestinationProperty): void;
    get destinationInput(): AwsBucketInventory.DestinationProperty | undefined;
    private _filter;
    get filter(): AwsBucketInventory.FilterPropertyOutputReference;
    putFilter(value: AwsBucketInventory.FilterProperty): void;
    resetFilter(): void;
    get filterInput(): AwsBucketInventory.FilterProperty | undefined;
    private _schedule;
    get schedule(): AwsBucketInventory.SchedulePropertyOutputReference;
    putSchedule(value: AwsBucketInventory.ScheduleProperty): void;
    get scheduleInput(): AwsBucketInventory.ScheduleProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsBucketInventorySseKmsPropertyToTerraform(struct?: AwsBucketInventory.SseKmsPropertyOutputReference | AwsBucketInventory.SseKmsProperty): any;
export declare function awsBucketInventorySseKmsPropertyToHclTerraform(struct?: AwsBucketInventory.SseKmsPropertyOutputReference | AwsBucketInventory.SseKmsProperty): any;
export declare function awsBucketInventorySseS3PropertyToTerraform(struct?: AwsBucketInventory.SseS3PropertyOutputReference | AwsBucketInventory.SseS3Property): any;
export declare function awsBucketInventorySseS3PropertyToHclTerraform(struct?: AwsBucketInventory.SseS3PropertyOutputReference | AwsBucketInventory.SseS3Property): any;
export declare function awsBucketInventoryEncryptionPropertyToTerraform(struct?: AwsBucketInventory.EncryptionPropertyOutputReference | AwsBucketInventory.EncryptionProperty): any;
export declare function awsBucketInventoryEncryptionPropertyToHclTerraform(struct?: AwsBucketInventory.EncryptionPropertyOutputReference | AwsBucketInventory.EncryptionProperty): any;
export declare function awsBucketInventoryBucketPropertyToTerraform(struct?: AwsBucketInventory.BucketPropertyOutputReference | AwsBucketInventory.BucketProperty): any;
export declare function awsBucketInventoryBucketPropertyToHclTerraform(struct?: AwsBucketInventory.BucketPropertyOutputReference | AwsBucketInventory.BucketProperty): any;
export declare function awsBucketInventoryDestinationPropertyToTerraform(struct?: AwsBucketInventory.DestinationPropertyOutputReference | AwsBucketInventory.DestinationProperty): any;
export declare function awsBucketInventoryDestinationPropertyToHclTerraform(struct?: AwsBucketInventory.DestinationPropertyOutputReference | AwsBucketInventory.DestinationProperty): any;
export declare function awsBucketInventoryFilterPropertyToTerraform(struct?: AwsBucketInventory.FilterPropertyOutputReference | AwsBucketInventory.FilterProperty): any;
export declare function awsBucketInventoryFilterPropertyToHclTerraform(struct?: AwsBucketInventory.FilterPropertyOutputReference | AwsBucketInventory.FilterProperty): any;
export declare function awsBucketInventorySchedulePropertyToTerraform(struct?: AwsBucketInventory.SchedulePropertyOutputReference | AwsBucketInventory.ScheduleProperty): any;
export declare function awsBucketInventorySchedulePropertyToHclTerraform(struct?: AwsBucketInventory.SchedulePropertyOutputReference | AwsBucketInventory.ScheduleProperty): any;
export declare namespace AwsBucketInventory {
    interface SseKmsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_inventory#key_id AwsBucketInventory#key_id}
        */
        readonly keyId: string;
    }
    class SseKmsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SseKmsProperty | undefined;
        set internalValue(value: SseKmsProperty | undefined);
        private _keyId?;
        get keyId(): string;
        set keyId(value: string);
        get keyIdInput(): string | undefined;
    }
    interface SseS3Property {
    }
    class SseS3PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SseS3Property | undefined;
        set internalValue(value: SseS3Property | undefined);
    }
    interface EncryptionProperty {
        /**
        * sse_kms block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_inventory#sse_kms AwsBucketInventory#sse_kms}
        */
        readonly sseKms?: SseKmsProperty;
        /**
        * sse_s3 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_inventory#sse_s3 AwsBucketInventory#sse_s3}
        */
        readonly sseS3?: SseS3Property;
    }
    class EncryptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncryptionProperty | undefined;
        set internalValue(value: EncryptionProperty | undefined);
        private _sseKms;
        get sseKms(): SseKmsPropertyOutputReference;
        putSseKms(value: SseKmsProperty): void;
        resetSseKms(): void;
        get sseKmsInput(): SseKmsProperty | undefined;
        private _sseS3;
        get sseS3(): SseS3PropertyOutputReference;
        putSseS3(value: SseS3Property): void;
        resetSseS3(): void;
        get sseS3Input(): SseS3Property | undefined;
    }
    interface BucketProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_inventory#account_id AwsBucketInventory#account_id}
        */
        readonly accountId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_inventory#bucket_arn AwsBucketInventory#bucket_arn}
        */
        readonly bucketArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_inventory#format AwsBucketInventory#format}
        */
        readonly format: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_inventory#prefix AwsBucketInventory#prefix}
        */
        readonly prefix?: string;
        /**
        * encryption block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_inventory#encryption AwsBucketInventory#encryption}
        */
        readonly encryption?: EncryptionProperty;
    }
    class BucketPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BucketProperty | undefined;
        set internalValue(value: BucketProperty | undefined);
        private _accountId?;
        get accountId(): string;
        set accountId(value: string);
        resetAccountId(): void;
        get accountIdInput(): string | undefined;
        private _bucketArn?;
        get bucketArn(): string;
        set bucketArn(value: string);
        get bucketArnInput(): string | undefined;
        private _format?;
        get format(): string;
        set format(value: string);
        get formatInput(): string | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _encryption;
        get encryption(): EncryptionPropertyOutputReference;
        putEncryption(value: EncryptionProperty): void;
        resetEncryption(): void;
        get encryptionInput(): EncryptionProperty | undefined;
    }
    interface DestinationProperty {
        /**
        * bucket block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_inventory#bucket AwsBucketInventory#bucket}
        */
        readonly bucket: BucketProperty;
    }
    class DestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationProperty | undefined;
        set internalValue(value: DestinationProperty | undefined);
        private _bucket;
        get bucket(): BucketPropertyOutputReference;
        putBucket(value: BucketProperty): void;
        get bucketInput(): BucketProperty | undefined;
    }
    interface FilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_inventory#prefix AwsBucketInventory#prefix}
        */
        readonly prefix?: string;
    }
    class FilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterProperty | undefined;
        set internalValue(value: FilterProperty | undefined);
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
    }
    interface ScheduleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_inventory#frequency AwsBucketInventory#frequency}
        */
        readonly frequency: string;
    }
    class SchedulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ScheduleProperty | undefined;
        set internalValue(value: ScheduleProperty | undefined);
        private _frequency?;
        get frequency(): string;
        set frequency(value: string);
        get frequencyInput(): string | undefined;
    }
}
