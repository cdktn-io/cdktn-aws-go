import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsBucketVersioningConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_versioning#bucket AwsBucketVersioning#bucket}
    */
    readonly bucket: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_versioning#expected_bucket_owner AwsBucketVersioning#expected_bucket_owner}
    */
    readonly expectedBucketOwner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_versioning#id AwsBucketVersioning#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_versioning#mfa AwsBucketVersioning#mfa}
    */
    readonly mfa?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_versioning#region AwsBucketVersioning#region}
    */
    readonly region?: string;
    /**
    * versioning_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_versioning#versioning_configuration AwsBucketVersioning#versioning_configuration}
    */
    readonly versioningConfiguration: AwsBucketVersioning.VersioningConfigurationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_versioning aws_s3_bucket_versioning}
*/
export declare class AwsBucketVersioning extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_s3_bucket_versioning";
    /**
    * Generates CDKTN code for importing a AwsBucketVersioning resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsBucketVersioning to import
    * @param importFromId The id of the existing AwsBucketVersioning that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_versioning#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsBucketVersioning to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_versioning aws_s3_bucket_versioning} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsBucketVersioningConfig
    */
    constructor(scope: Construct, id: string, config: AwsBucketVersioningConfig);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _expectedBucketOwner?;
    get expectedBucketOwner(): string;
    set expectedBucketOwner(value: string);
    resetExpectedBucketOwner(): void;
    get expectedBucketOwnerInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _mfa?;
    get mfa(): string;
    set mfa(value: string);
    resetMfa(): void;
    get mfaInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _versioningConfiguration;
    get versioningConfiguration(): AwsBucketVersioning.VersioningConfigurationPropertyOutputReference;
    putVersioningConfiguration(value: AwsBucketVersioning.VersioningConfigurationProperty): void;
    get versioningConfigurationInput(): AwsBucketVersioning.VersioningConfigurationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsBucketVersioningVersioningConfigurationPropertyToTerraform(struct?: AwsBucketVersioning.VersioningConfigurationPropertyOutputReference | AwsBucketVersioning.VersioningConfigurationProperty): any;
export declare function awsBucketVersioningVersioningConfigurationPropertyToHclTerraform(struct?: AwsBucketVersioning.VersioningConfigurationPropertyOutputReference | AwsBucketVersioning.VersioningConfigurationProperty): any;
export declare namespace AwsBucketVersioning {
    interface VersioningConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_versioning#mfa_delete AwsBucketVersioning#mfa_delete}
        */
        readonly mfaDelete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_versioning#status AwsBucketVersioning#status}
        */
        readonly status: string;
    }
    class VersioningConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VersioningConfigurationProperty | undefined;
        set internalValue(value: VersioningConfigurationProperty | undefined);
        private _mfaDelete?;
        get mfaDelete(): string;
        set mfaDelete(value: string);
        resetMfaDelete(): void;
        get mfaDeleteInput(): string | undefined;
        private _status?;
        get status(): string;
        set status(value: string);
        get statusInput(): string | undefined;
    }
}
