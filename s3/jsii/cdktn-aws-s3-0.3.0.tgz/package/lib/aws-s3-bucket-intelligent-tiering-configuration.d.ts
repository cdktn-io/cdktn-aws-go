import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsBucketIntelligentTieringConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_intelligent_tiering_configuration#bucket AwsBucketIntelligentTieringConfiguration#bucket}
    */
    readonly bucket: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_intelligent_tiering_configuration#id AwsBucketIntelligentTieringConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_intelligent_tiering_configuration#name AwsBucketIntelligentTieringConfiguration#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_intelligent_tiering_configuration#region AwsBucketIntelligentTieringConfiguration#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_intelligent_tiering_configuration#status AwsBucketIntelligentTieringConfiguration#status}
    */
    readonly status?: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_intelligent_tiering_configuration#filter AwsBucketIntelligentTieringConfiguration#filter}
    */
    readonly filter?: AwsBucketIntelligentTieringConfiguration.FilterProperty;
    /**
    * tiering block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_intelligent_tiering_configuration#tiering AwsBucketIntelligentTieringConfiguration#tiering}
    */
    readonly tiering: AwsBucketIntelligentTieringConfiguration.TieringProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_intelligent_tiering_configuration aws_s3_bucket_intelligent_tiering_configuration}
*/
export declare class AwsBucketIntelligentTieringConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_s3_bucket_intelligent_tiering_configuration";
    /**
    * Generates CDKTN code for importing a AwsBucketIntelligentTieringConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsBucketIntelligentTieringConfiguration to import
    * @param importFromId The id of the existing AwsBucketIntelligentTieringConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_intelligent_tiering_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsBucketIntelligentTieringConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_intelligent_tiering_configuration aws_s3_bucket_intelligent_tiering_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsBucketIntelligentTieringConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AwsBucketIntelligentTieringConfigurationConfig);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _filter;
    get filter(): AwsBucketIntelligentTieringConfiguration.FilterPropertyOutputReference;
    putFilter(value: AwsBucketIntelligentTieringConfiguration.FilterProperty): void;
    resetFilter(): void;
    get filterInput(): AwsBucketIntelligentTieringConfiguration.FilterProperty | undefined;
    private _tiering;
    get tiering(): AwsBucketIntelligentTieringConfiguration.TieringPropertyList;
    putTiering(value: AwsBucketIntelligentTieringConfiguration.TieringProperty[] | cdktn.IResolvable): void;
    get tieringInput(): cdktn.IResolvable | AwsBucketIntelligentTieringConfiguration.TieringProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsBucketIntelligentTieringConfigurationFilterPropertyToTerraform(struct?: AwsBucketIntelligentTieringConfiguration.FilterPropertyOutputReference | AwsBucketIntelligentTieringConfiguration.FilterProperty): any;
export declare function awsBucketIntelligentTieringConfigurationFilterPropertyToHclTerraform(struct?: AwsBucketIntelligentTieringConfiguration.FilterPropertyOutputReference | AwsBucketIntelligentTieringConfiguration.FilterProperty): any;
export declare function awsBucketIntelligentTieringConfigurationTieringPropertyToTerraform(struct?: AwsBucketIntelligentTieringConfiguration.TieringProperty | cdktn.IResolvable): any;
export declare function awsBucketIntelligentTieringConfigurationTieringPropertyToHclTerraform(struct?: AwsBucketIntelligentTieringConfiguration.TieringProperty | cdktn.IResolvable): any;
export declare namespace AwsBucketIntelligentTieringConfiguration {
    interface FilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_intelligent_tiering_configuration#prefix AwsBucketIntelligentTieringConfiguration#prefix}
        */
        readonly prefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_intelligent_tiering_configuration#tags AwsBucketIntelligentTieringConfiguration#tags}
        */
        readonly tags?: {
            [key: string]: string;
        };
    }
    class FilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterProperty | undefined;
        set internalValue(value: FilterProperty | undefined);
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _tags?;
        get tags(): {
            [key: string]: string;
        };
        set tags(value: {
            [key: string]: string;
        });
        resetTags(): void;
        get tagsInput(): {
            [key: string]: string;
        } | undefined;
    }
    interface TieringProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_intelligent_tiering_configuration#access_tier AwsBucketIntelligentTieringConfiguration#access_tier}
        */
        readonly accessTier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_intelligent_tiering_configuration#days AwsBucketIntelligentTieringConfiguration#days}
        */
        readonly days: number;
    }
    class TieringPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TieringProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TieringProperty | cdktn.IResolvable | undefined);
        private _accessTier?;
        get accessTier(): string;
        set accessTier(value: string);
        get accessTierInput(): string | undefined;
        private _days?;
        get days(): number;
        set days(value: number);
        get daysInput(): number | undefined;
    }
    class TieringPropertyList extends cdktn.ComplexList {
        internalValue?: TieringProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TieringPropertyOutputReference;
    }
}
