import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsBucketAclConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_acl#acl AwsBucketAcl#acl}
    */
    readonly acl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_acl#bucket AwsBucketAcl#bucket}
    */
    readonly bucket: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_acl#expected_bucket_owner AwsBucketAcl#expected_bucket_owner}
    */
    readonly expectedBucketOwner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_acl#id AwsBucketAcl#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_acl#region AwsBucketAcl#region}
    */
    readonly region?: string;
    /**
    * access_control_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_acl#access_control_policy AwsBucketAcl#access_control_policy}
    */
    readonly accessControlPolicy?: AwsBucketAcl.AccessControlPolicyProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_acl aws_s3_bucket_acl}
*/
export declare class AwsBucketAcl extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_s3_bucket_acl";
    /**
    * Generates CDKTN code for importing a AwsBucketAcl resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsBucketAcl to import
    * @param importFromId The id of the existing AwsBucketAcl that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_acl#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsBucketAcl to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_acl aws_s3_bucket_acl} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsBucketAclConfig
    */
    constructor(scope: Construct, id: string, config: AwsBucketAclConfig);
    private _acl?;
    get acl(): string;
    set acl(value: string);
    resetAcl(): void;
    get aclInput(): string | undefined;
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _expectedBucketOwner?;
    get expectedBucketOwner(): string;
    set expectedBucketOwner(value: string);
    resetExpectedBucketOwner(): void;
    get expectedBucketOwnerInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _accessControlPolicy;
    get accessControlPolicy(): AwsBucketAcl.AccessControlPolicyPropertyOutputReference;
    putAccessControlPolicy(value: AwsBucketAcl.AccessControlPolicyProperty): void;
    resetAccessControlPolicy(): void;
    get accessControlPolicyInput(): AwsBucketAcl.AccessControlPolicyProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsBucketAclGranteePropertyToTerraform(struct?: AwsBucketAcl.GranteePropertyOutputReference | AwsBucketAcl.GranteeProperty): any;
export declare function awsBucketAclGranteePropertyToHclTerraform(struct?: AwsBucketAcl.GranteePropertyOutputReference | AwsBucketAcl.GranteeProperty): any;
export declare function awsBucketAclGrantPropertyToTerraform(struct?: AwsBucketAcl.GrantProperty | cdktn.IResolvable): any;
export declare function awsBucketAclGrantPropertyToHclTerraform(struct?: AwsBucketAcl.GrantProperty | cdktn.IResolvable): any;
export declare function awsBucketAclOwnerPropertyToTerraform(struct?: AwsBucketAcl.OwnerPropertyOutputReference | AwsBucketAcl.OwnerProperty): any;
export declare function awsBucketAclOwnerPropertyToHclTerraform(struct?: AwsBucketAcl.OwnerPropertyOutputReference | AwsBucketAcl.OwnerProperty): any;
export declare function awsBucketAclAccessControlPolicyPropertyToTerraform(struct?: AwsBucketAcl.AccessControlPolicyPropertyOutputReference | AwsBucketAcl.AccessControlPolicyProperty): any;
export declare function awsBucketAclAccessControlPolicyPropertyToHclTerraform(struct?: AwsBucketAcl.AccessControlPolicyPropertyOutputReference | AwsBucketAcl.AccessControlPolicyProperty): any;
export declare namespace AwsBucketAcl {
    interface GranteeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_acl#email_address AwsBucketAcl#email_address}
        */
        readonly emailAddress?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_acl#id AwsBucketAcl#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_acl#type AwsBucketAcl#type}
        */
        readonly type: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_acl#uri AwsBucketAcl#uri}
        */
        readonly uri?: string;
    }
    class GranteePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): GranteeProperty | undefined;
        set internalValue(value: GranteeProperty | undefined);
        get displayName(): string;
        private _emailAddress?;
        get emailAddress(): string;
        set emailAddress(value: string);
        resetEmailAddress(): void;
        get emailAddressInput(): string | undefined;
        private _id?;
        get id(): string;
        set id(value: string);
        resetId(): void;
        get idInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _uri?;
        get uri(): string;
        set uri(value: string);
        resetUri(): void;
        get uriInput(): string | undefined;
    }
    interface GrantProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_acl#permission AwsBucketAcl#permission}
        */
        readonly permission: string;
        /**
        * grantee block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_acl#grantee AwsBucketAcl#grantee}
        */
        readonly grantee?: GranteeProperty;
    }
    class GrantPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GrantProperty | cdktn.IResolvable | undefined;
        set internalValue(value: GrantProperty | cdktn.IResolvable | undefined);
        private _permission?;
        get permission(): string;
        set permission(value: string);
        get permissionInput(): string | undefined;
        private _grantee;
        get grantee(): GranteePropertyOutputReference;
        putGrantee(value: GranteeProperty): void;
        resetGrantee(): void;
        get granteeInput(): GranteeProperty | undefined;
    }
    class GrantPropertyList extends cdktn.ComplexList {
        internalValue?: GrantProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GrantPropertyOutputReference;
    }
    interface OwnerProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_acl#display_name AwsBucketAcl#display_name}
        */
        readonly displayName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_acl#id AwsBucketAcl#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id: string;
    }
    class OwnerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OwnerProperty | undefined;
        set internalValue(value: OwnerProperty | undefined);
        private _displayName?;
        get displayName(): string;
        set displayName(value: string);
        resetDisplayName(): void;
        get displayNameInput(): string | undefined;
        private _id?;
        get id(): string;
        set id(value: string);
        get idInput(): string | undefined;
    }
    interface AccessControlPolicyProperty {
        /**
        * grant block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_acl#grant AwsBucketAcl#grant}
        */
        readonly grant?: GrantProperty[] | cdktn.IResolvable;
        /**
        * owner block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_acl#owner AwsBucketAcl#owner}
        */
        readonly owner: OwnerProperty;
    }
    class AccessControlPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AccessControlPolicyProperty | undefined;
        set internalValue(value: AccessControlPolicyProperty | undefined);
        private _grant;
        get grant(): GrantPropertyList;
        putGrant(value: GrantProperty[] | cdktn.IResolvable): void;
        resetGrant(): void;
        get grantInput(): cdktn.IResolvable | GrantProperty[] | undefined;
        private _owner;
        get owner(): OwnerPropertyOutputReference;
        putOwner(value: OwnerProperty): void;
        get ownerInput(): OwnerProperty | undefined;
    }
}
