import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsBucketOwnershipControlsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_ownership_controls#bucket AwsBucketOwnershipControls#bucket}
    */
    readonly bucket: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_ownership_controls#id AwsBucketOwnershipControls#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_ownership_controls#region AwsBucketOwnershipControls#region}
    */
    readonly region?: string;
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_ownership_controls#rule AwsBucketOwnershipControls#rule}
    */
    readonly rule: AwsBucketOwnershipControls.RuleProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_ownership_controls aws_s3_bucket_ownership_controls}
*/
export declare class AwsBucketOwnershipControls extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_s3_bucket_ownership_controls";
    /**
    * Generates CDKTN code for importing a AwsBucketOwnershipControls resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsBucketOwnershipControls to import
    * @param importFromId The id of the existing AwsBucketOwnershipControls that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_ownership_controls#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsBucketOwnershipControls to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_ownership_controls aws_s3_bucket_ownership_controls} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsBucketOwnershipControlsConfig
    */
    constructor(scope: Construct, id: string, config: AwsBucketOwnershipControlsConfig);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _rule;
    get rule(): AwsBucketOwnershipControls.RulePropertyOutputReference;
    putRule(value: AwsBucketOwnershipControls.RuleProperty): void;
    get ruleInput(): AwsBucketOwnershipControls.RuleProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsBucketOwnershipControlsRulePropertyToTerraform(struct?: AwsBucketOwnershipControls.RulePropertyOutputReference | AwsBucketOwnershipControls.RuleProperty): any;
export declare function awsBucketOwnershipControlsRulePropertyToHclTerraform(struct?: AwsBucketOwnershipControls.RulePropertyOutputReference | AwsBucketOwnershipControls.RuleProperty): any;
export declare namespace AwsBucketOwnershipControls {
    interface RuleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_ownership_controls#object_ownership AwsBucketOwnershipControls#object_ownership}
        */
        readonly objectOwnership: string;
    }
    class RulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleProperty | undefined;
        set internalValue(value: RuleProperty | undefined);
        private _objectOwnership?;
        get objectOwnership(): string;
        set objectOwnership(value: string);
        get objectOwnershipInput(): string | undefined;
    }
}
