import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsBucketAnalyticsConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_analytics_configuration#bucket AwsBucketAnalyticsConfiguration#bucket}
    */
    readonly bucket: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_analytics_configuration#id AwsBucketAnalyticsConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_analytics_configuration#name AwsBucketAnalyticsConfiguration#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_analytics_configuration#region AwsBucketAnalyticsConfiguration#region}
    */
    readonly region?: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_analytics_configuration#filter AwsBucketAnalyticsConfiguration#filter}
    */
    readonly filter?: AwsBucketAnalyticsConfiguration.FilterProperty;
    /**
    * storage_class_analysis block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_analytics_configuration#storage_class_analysis AwsBucketAnalyticsConfiguration#storage_class_analysis}
    */
    readonly storageClassAnalysis?: AwsBucketAnalyticsConfiguration.StorageClassAnalysisProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_analytics_configuration aws_s3_bucket_analytics_configuration}
*/
export declare class AwsBucketAnalyticsConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_s3_bucket_analytics_configuration";
    /**
    * Generates CDKTN code for importing a AwsBucketAnalyticsConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsBucketAnalyticsConfiguration to import
    * @param importFromId The id of the existing AwsBucketAnalyticsConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_analytics_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsBucketAnalyticsConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_analytics_configuration aws_s3_bucket_analytics_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsBucketAnalyticsConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AwsBucketAnalyticsConfigurationConfig);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _filter;
    get filter(): AwsBucketAnalyticsConfiguration.FilterPropertyOutputReference;
    putFilter(value: AwsBucketAnalyticsConfiguration.FilterProperty): void;
    resetFilter(): void;
    get filterInput(): AwsBucketAnalyticsConfiguration.FilterProperty | undefined;
    private _storageClassAnalysis;
    get storageClassAnalysis(): AwsBucketAnalyticsConfiguration.StorageClassAnalysisPropertyOutputReference;
    putStorageClassAnalysis(value: AwsBucketAnalyticsConfiguration.StorageClassAnalysisProperty): void;
    resetStorageClassAnalysis(): void;
    get storageClassAnalysisInput(): AwsBucketAnalyticsConfiguration.StorageClassAnalysisProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsBucketAnalyticsConfigurationFilterPropertyToTerraform(struct?: AwsBucketAnalyticsConfiguration.FilterPropertyOutputReference | AwsBucketAnalyticsConfiguration.FilterProperty): any;
export declare function awsBucketAnalyticsConfigurationFilterPropertyToHclTerraform(struct?: AwsBucketAnalyticsConfiguration.FilterPropertyOutputReference | AwsBucketAnalyticsConfiguration.FilterProperty): any;
export declare function awsBucketAnalyticsConfigurationS3BucketDestinationPropertyToTerraform(struct?: AwsBucketAnalyticsConfiguration.S3BucketDestinationPropertyOutputReference | AwsBucketAnalyticsConfiguration.S3BucketDestinationProperty): any;
export declare function awsBucketAnalyticsConfigurationS3BucketDestinationPropertyToHclTerraform(struct?: AwsBucketAnalyticsConfiguration.S3BucketDestinationPropertyOutputReference | AwsBucketAnalyticsConfiguration.S3BucketDestinationProperty): any;
export declare function awsBucketAnalyticsConfigurationDestinationPropertyToTerraform(struct?: AwsBucketAnalyticsConfiguration.DestinationPropertyOutputReference | AwsBucketAnalyticsConfiguration.DestinationProperty): any;
export declare function awsBucketAnalyticsConfigurationDestinationPropertyToHclTerraform(struct?: AwsBucketAnalyticsConfiguration.DestinationPropertyOutputReference | AwsBucketAnalyticsConfiguration.DestinationProperty): any;
export declare function awsBucketAnalyticsConfigurationDataExportPropertyToTerraform(struct?: AwsBucketAnalyticsConfiguration.DataExportPropertyOutputReference | AwsBucketAnalyticsConfiguration.DataExportProperty): any;
export declare function awsBucketAnalyticsConfigurationDataExportPropertyToHclTerraform(struct?: AwsBucketAnalyticsConfiguration.DataExportPropertyOutputReference | AwsBucketAnalyticsConfiguration.DataExportProperty): any;
export declare function awsBucketAnalyticsConfigurationStorageClassAnalysisPropertyToTerraform(struct?: AwsBucketAnalyticsConfiguration.StorageClassAnalysisPropertyOutputReference | AwsBucketAnalyticsConfiguration.StorageClassAnalysisProperty): any;
export declare function awsBucketAnalyticsConfigurationStorageClassAnalysisPropertyToHclTerraform(struct?: AwsBucketAnalyticsConfiguration.StorageClassAnalysisPropertyOutputReference | AwsBucketAnalyticsConfiguration.StorageClassAnalysisProperty): any;
export declare namespace AwsBucketAnalyticsConfiguration {
    interface FilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_analytics_configuration#prefix AwsBucketAnalyticsConfiguration#prefix}
        */
        readonly prefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_analytics_configuration#tags AwsBucketAnalyticsConfiguration#tags}
        */
        readonly tags?: {
            [key: string]: string;
        };
    }
    class FilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterProperty | undefined;
        set internalValue(value: FilterProperty | undefined);
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _tags?;
        get tags(): {
            [key: string]: string;
        };
        set tags(value: {
            [key: string]: string;
        });
        resetTags(): void;
        get tagsInput(): {
            [key: string]: string;
        } | undefined;
    }
    interface S3BucketDestinationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_analytics_configuration#bucket_account_id AwsBucketAnalyticsConfiguration#bucket_account_id}
        */
        readonly bucketAccountId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_analytics_configuration#bucket_arn AwsBucketAnalyticsConfiguration#bucket_arn}
        */
        readonly bucketArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_analytics_configuration#format AwsBucketAnalyticsConfiguration#format}
        */
        readonly format?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_analytics_configuration#prefix AwsBucketAnalyticsConfiguration#prefix}
        */
        readonly prefix?: string;
    }
    class S3BucketDestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3BucketDestinationProperty | undefined;
        set internalValue(value: S3BucketDestinationProperty | undefined);
        private _bucketAccountId?;
        get bucketAccountId(): string;
        set bucketAccountId(value: string);
        resetBucketAccountId(): void;
        get bucketAccountIdInput(): string | undefined;
        private _bucketArn?;
        get bucketArn(): string;
        set bucketArn(value: string);
        get bucketArnInput(): string | undefined;
        private _format?;
        get format(): string;
        set format(value: string);
        resetFormat(): void;
        get formatInput(): string | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
    }
    interface DestinationProperty {
        /**
        * s3_bucket_destination block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_analytics_configuration#s3_bucket_destination AwsBucketAnalyticsConfiguration#s3_bucket_destination}
        */
        readonly s3BucketDestination: S3BucketDestinationProperty;
    }
    class DestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationProperty | undefined;
        set internalValue(value: DestinationProperty | undefined);
        private _s3BucketDestination;
        get s3BucketDestination(): S3BucketDestinationPropertyOutputReference;
        putS3BucketDestination(value: S3BucketDestinationProperty): void;
        get s3BucketDestinationInput(): S3BucketDestinationProperty | undefined;
    }
    interface DataExportProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_analytics_configuration#output_schema_version AwsBucketAnalyticsConfiguration#output_schema_version}
        */
        readonly outputSchemaVersion?: string;
        /**
        * destination block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_analytics_configuration#destination AwsBucketAnalyticsConfiguration#destination}
        */
        readonly destination: DestinationProperty;
    }
    class DataExportPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DataExportProperty | undefined;
        set internalValue(value: DataExportProperty | undefined);
        private _outputSchemaVersion?;
        get outputSchemaVersion(): string;
        set outputSchemaVersion(value: string);
        resetOutputSchemaVersion(): void;
        get outputSchemaVersionInput(): string | undefined;
        private _destination;
        get destination(): DestinationPropertyOutputReference;
        putDestination(value: DestinationProperty): void;
        get destinationInput(): DestinationProperty | undefined;
    }
    interface StorageClassAnalysisProperty {
        /**
        * data_export block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_analytics_configuration#data_export AwsBucketAnalyticsConfiguration#data_export}
        */
        readonly dataExport: DataExportProperty;
    }
    class StorageClassAnalysisPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StorageClassAnalysisProperty | undefined;
        set internalValue(value: StorageClassAnalysisProperty | undefined);
        private _dataExport;
        get dataExport(): DataExportPropertyOutputReference;
        putDataExport(value: DataExportProperty): void;
        get dataExportInput(): DataExportProperty | undefined;
    }
}
