import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsClusterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#additional_info AwsCluster#additional_info}
    */
    readonly additionalInfo?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#applications AwsCluster#applications}
    */
    readonly applications?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#autoscaling_role AwsCluster#autoscaling_role}
    */
    readonly autoscalingRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#configurations AwsCluster#configurations}
    */
    readonly configurations?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#configurations_json AwsCluster#configurations_json}
    */
    readonly configurationsJson?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#custom_ami_id AwsCluster#custom_ami_id}
    */
    readonly customAmiId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#ebs_root_volume_size AwsCluster#ebs_root_volume_size}
    */
    readonly ebsRootVolumeSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#id AwsCluster#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#keep_job_flow_alive_when_no_steps AwsCluster#keep_job_flow_alive_when_no_steps}
    */
    readonly keepJobFlowAliveWhenNoSteps?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#list_steps_states AwsCluster#list_steps_states}
    */
    readonly listStepsStates?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#log_encryption_kms_key_id AwsCluster#log_encryption_kms_key_id}
    */
    readonly logEncryptionKmsKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#log_uri AwsCluster#log_uri}
    */
    readonly logUri?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#name AwsCluster#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#os_release_label AwsCluster#os_release_label}
    */
    readonly osReleaseLabel?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#placement_group_config AwsCluster#placement_group_config}
    */
    readonly placementGroupConfig?: AwsCluster.PlacementGroupConfigProperty[] | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#region AwsCluster#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#release_label AwsCluster#release_label}
    */
    readonly releaseLabel: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#scale_down_behavior AwsCluster#scale_down_behavior}
    */
    readonly scaleDownBehavior?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#security_configuration AwsCluster#security_configuration}
    */
    readonly securityConfiguration?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#service_role AwsCluster#service_role}
    */
    readonly serviceRole: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#step AwsCluster#step}
    */
    readonly step?: AwsCluster.StepProperty[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#step_concurrency_level AwsCluster#step_concurrency_level}
    */
    readonly stepConcurrencyLevel?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#tags AwsCluster#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#tags_all AwsCluster#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#termination_protection AwsCluster#termination_protection}
    */
    readonly terminationProtection?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#unhealthy_node_replacement AwsCluster#unhealthy_node_replacement}
    */
    readonly unhealthyNodeReplacement?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#visible_to_all_users AwsCluster#visible_to_all_users}
    */
    readonly visibleToAllUsers?: boolean | cdktn.IResolvable;
    /**
    * auto_termination_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#auto_termination_policy AwsCluster#auto_termination_policy}
    */
    readonly autoTerminationPolicy?: AwsCluster.AutoTerminationPolicyProperty;
    /**
    * bootstrap_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#bootstrap_action AwsCluster#bootstrap_action}
    */
    readonly bootstrapAction?: AwsCluster.BootstrapActionProperty[] | cdktn.IResolvable;
    /**
    * core_instance_fleet block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#core_instance_fleet AwsCluster#core_instance_fleet}
    */
    readonly coreInstanceFleet?: AwsCluster.CoreInstanceFleetProperty;
    /**
    * core_instance_group block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#core_instance_group AwsCluster#core_instance_group}
    */
    readonly coreInstanceGroup?: AwsCluster.CoreInstanceGroupProperty;
    /**
    * ec2_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#ec2_attributes AwsCluster#ec2_attributes}
    */
    readonly ec2Attributes?: AwsCluster.Ec2AttributesProperty;
    /**
    * kerberos_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#kerberos_attributes AwsCluster#kerberos_attributes}
    */
    readonly kerberosAttributes?: AwsCluster.KerberosAttributesProperty;
    /**
    * master_instance_fleet block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#master_instance_fleet AwsCluster#master_instance_fleet}
    */
    readonly masterInstanceFleet?: AwsCluster.MasterInstanceFleetProperty;
    /**
    * master_instance_group block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#master_instance_group AwsCluster#master_instance_group}
    */
    readonly masterInstanceGroup?: AwsCluster.MasterInstanceGroupProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster aws_emr_cluster}
*/
export declare class AwsCluster extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_emr_cluster";
    /**
    * Generates CDKTN code for importing a AwsCluster resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsCluster to import
    * @param importFromId The id of the existing AwsCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster aws_emr_cluster} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsClusterConfig
    */
    constructor(scope: Construct, id: string, config: AwsClusterConfig);
    private _additionalInfo?;
    get additionalInfo(): string;
    set additionalInfo(value: string);
    resetAdditionalInfo(): void;
    get additionalInfoInput(): string | undefined;
    private _applications?;
    get applications(): string[];
    set applications(value: string[]);
    resetApplications(): void;
    get applicationsInput(): string[] | undefined;
    get arn(): string;
    private _autoscalingRole?;
    get autoscalingRole(): string;
    set autoscalingRole(value: string);
    resetAutoscalingRole(): void;
    get autoscalingRoleInput(): string | undefined;
    get clusterState(): string;
    private _configurations?;
    get configurations(): string;
    set configurations(value: string);
    resetConfigurations(): void;
    get configurationsInput(): string | undefined;
    private _configurationsJson?;
    get configurationsJson(): string;
    set configurationsJson(value: string);
    resetConfigurationsJson(): void;
    get configurationsJsonInput(): string | undefined;
    private _customAmiId?;
    get customAmiId(): string;
    set customAmiId(value: string);
    resetCustomAmiId(): void;
    get customAmiIdInput(): string | undefined;
    private _ebsRootVolumeSize?;
    get ebsRootVolumeSize(): number;
    set ebsRootVolumeSize(value: number);
    resetEbsRootVolumeSize(): void;
    get ebsRootVolumeSizeInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _keepJobFlowAliveWhenNoSteps?;
    get keepJobFlowAliveWhenNoSteps(): boolean | cdktn.IResolvable;
    set keepJobFlowAliveWhenNoSteps(value: boolean | cdktn.IResolvable);
    resetKeepJobFlowAliveWhenNoSteps(): void;
    get keepJobFlowAliveWhenNoStepsInput(): boolean | cdktn.IResolvable | undefined;
    private _listStepsStates?;
    get listStepsStates(): string[];
    set listStepsStates(value: string[]);
    resetListStepsStates(): void;
    get listStepsStatesInput(): string[] | undefined;
    private _logEncryptionKmsKeyId?;
    get logEncryptionKmsKeyId(): string;
    set logEncryptionKmsKeyId(value: string);
    resetLogEncryptionKmsKeyId(): void;
    get logEncryptionKmsKeyIdInput(): string | undefined;
    private _logUri?;
    get logUri(): string;
    set logUri(value: string);
    resetLogUri(): void;
    get logUriInput(): string | undefined;
    get masterPublicDns(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _osReleaseLabel?;
    get osReleaseLabel(): string;
    set osReleaseLabel(value: string);
    resetOsReleaseLabel(): void;
    get osReleaseLabelInput(): string | undefined;
    private _placementGroupConfig;
    get placementGroupConfig(): AwsCluster.PlacementGroupConfigPropertyList;
    putPlacementGroupConfig(value: AwsCluster.PlacementGroupConfigProperty[] | cdktn.IResolvable): void;
    resetPlacementGroupConfig(): void;
    get placementGroupConfigInput(): cdktn.IResolvable | AwsCluster.PlacementGroupConfigProperty[] | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _releaseLabel?;
    get releaseLabel(): string;
    set releaseLabel(value: string);
    get releaseLabelInput(): string | undefined;
    private _scaleDownBehavior?;
    get scaleDownBehavior(): string;
    set scaleDownBehavior(value: string);
    resetScaleDownBehavior(): void;
    get scaleDownBehaviorInput(): string | undefined;
    private _securityConfiguration?;
    get securityConfiguration(): string;
    set securityConfiguration(value: string);
    resetSecurityConfiguration(): void;
    get securityConfigurationInput(): string | undefined;
    private _serviceRole?;
    get serviceRole(): string;
    set serviceRole(value: string);
    get serviceRoleInput(): string | undefined;
    private _step;
    get step(): AwsCluster.StepPropertyList;
    putStep(value: AwsCluster.StepProperty[] | cdktn.IResolvable): void;
    resetStep(): void;
    get stepInput(): cdktn.IResolvable | AwsCluster.StepProperty[] | undefined;
    private _stepConcurrencyLevel?;
    get stepConcurrencyLevel(): number;
    set stepConcurrencyLevel(value: number);
    resetStepConcurrencyLevel(): void;
    get stepConcurrencyLevelInput(): number | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _terminationProtection?;
    get terminationProtection(): boolean | cdktn.IResolvable;
    set terminationProtection(value: boolean | cdktn.IResolvable);
    resetTerminationProtection(): void;
    get terminationProtectionInput(): boolean | cdktn.IResolvable | undefined;
    private _unhealthyNodeReplacement?;
    get unhealthyNodeReplacement(): boolean | cdktn.IResolvable;
    set unhealthyNodeReplacement(value: boolean | cdktn.IResolvable);
    resetUnhealthyNodeReplacement(): void;
    get unhealthyNodeReplacementInput(): boolean | cdktn.IResolvable | undefined;
    private _visibleToAllUsers?;
    get visibleToAllUsers(): boolean | cdktn.IResolvable;
    set visibleToAllUsers(value: boolean | cdktn.IResolvable);
    resetVisibleToAllUsers(): void;
    get visibleToAllUsersInput(): boolean | cdktn.IResolvable | undefined;
    private _autoTerminationPolicy;
    get autoTerminationPolicy(): AwsCluster.AutoTerminationPolicyPropertyOutputReference;
    putAutoTerminationPolicy(value: AwsCluster.AutoTerminationPolicyProperty): void;
    resetAutoTerminationPolicy(): void;
    get autoTerminationPolicyInput(): AwsCluster.AutoTerminationPolicyProperty | undefined;
    private _bootstrapAction;
    get bootstrapAction(): AwsCluster.BootstrapActionPropertyList;
    putBootstrapAction(value: AwsCluster.BootstrapActionProperty[] | cdktn.IResolvable): void;
    resetBootstrapAction(): void;
    get bootstrapActionInput(): cdktn.IResolvable | AwsCluster.BootstrapActionProperty[] | undefined;
    private _coreInstanceFleet;
    get coreInstanceFleet(): AwsCluster.CoreInstanceFleetPropertyOutputReference;
    putCoreInstanceFleet(value: AwsCluster.CoreInstanceFleetProperty): void;
    resetCoreInstanceFleet(): void;
    get coreInstanceFleetInput(): AwsCluster.CoreInstanceFleetProperty | undefined;
    private _coreInstanceGroup;
    get coreInstanceGroup(): AwsCluster.CoreInstanceGroupPropertyOutputReference;
    putCoreInstanceGroup(value: AwsCluster.CoreInstanceGroupProperty): void;
    resetCoreInstanceGroup(): void;
    get coreInstanceGroupInput(): AwsCluster.CoreInstanceGroupProperty | undefined;
    private _ec2Attributes;
    get ec2Attributes(): AwsCluster.Ec2AttributesPropertyOutputReference;
    putEc2Attributes(value: AwsCluster.Ec2AttributesProperty): void;
    resetEc2Attributes(): void;
    get ec2AttributesInput(): AwsCluster.Ec2AttributesProperty | undefined;
    private _kerberosAttributes;
    get kerberosAttributes(): AwsCluster.KerberosAttributesPropertyOutputReference;
    putKerberosAttributes(value: AwsCluster.KerberosAttributesProperty): void;
    resetKerberosAttributes(): void;
    get kerberosAttributesInput(): AwsCluster.KerberosAttributesProperty | undefined;
    private _masterInstanceFleet;
    get masterInstanceFleet(): AwsCluster.MasterInstanceFleetPropertyOutputReference;
    putMasterInstanceFleet(value: AwsCluster.MasterInstanceFleetProperty): void;
    resetMasterInstanceFleet(): void;
    get masterInstanceFleetInput(): AwsCluster.MasterInstanceFleetProperty | undefined;
    private _masterInstanceGroup;
    get masterInstanceGroup(): AwsCluster.MasterInstanceGroupPropertyOutputReference;
    putMasterInstanceGroup(value: AwsCluster.MasterInstanceGroupProperty): void;
    resetMasterInstanceGroup(): void;
    get masterInstanceGroupInput(): AwsCluster.MasterInstanceGroupProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsClusterPlacementGroupConfigPropertyToTerraform(struct?: AwsCluster.PlacementGroupConfigProperty | cdktn.IResolvable): any;
export declare function awsClusterPlacementGroupConfigPropertyToHclTerraform(struct?: AwsCluster.PlacementGroupConfigProperty | cdktn.IResolvable): any;
export declare function awsClusterHadoopJarStepPropertyToTerraform(struct?: AwsCluster.HadoopJarStepProperty | cdktn.IResolvable): any;
export declare function awsClusterHadoopJarStepPropertyToHclTerraform(struct?: AwsCluster.HadoopJarStepProperty | cdktn.IResolvable): any;
export declare function awsClusterStepPropertyToTerraform(struct?: AwsCluster.StepProperty | cdktn.IResolvable): any;
export declare function awsClusterStepPropertyToHclTerraform(struct?: AwsCluster.StepProperty | cdktn.IResolvable): any;
export declare function awsClusterAutoTerminationPolicyPropertyToTerraform(struct?: AwsCluster.AutoTerminationPolicyPropertyOutputReference | AwsCluster.AutoTerminationPolicyProperty): any;
export declare function awsClusterAutoTerminationPolicyPropertyToHclTerraform(struct?: AwsCluster.AutoTerminationPolicyPropertyOutputReference | AwsCluster.AutoTerminationPolicyProperty): any;
export declare function awsClusterBootstrapActionPropertyToTerraform(struct?: AwsCluster.BootstrapActionProperty | cdktn.IResolvable): any;
export declare function awsClusterBootstrapActionPropertyToHclTerraform(struct?: AwsCluster.BootstrapActionProperty | cdktn.IResolvable): any;
export declare function awsClusterCoreInstanceFleetInstanceTypeConfigsConfigurationsPropertyToTerraform(struct?: AwsCluster.CoreInstanceFleetInstanceTypeConfigsConfigurationsProperty | cdktn.IResolvable): any;
export declare function awsClusterCoreInstanceFleetInstanceTypeConfigsConfigurationsPropertyToHclTerraform(struct?: AwsCluster.CoreInstanceFleetInstanceTypeConfigsConfigurationsProperty | cdktn.IResolvable): any;
export declare function awsClusterCoreInstanceFleetInstanceTypeConfigsEbsConfigPropertyToTerraform(struct?: AwsCluster.CoreInstanceFleetInstanceTypeConfigsEbsConfigProperty | cdktn.IResolvable): any;
export declare function awsClusterCoreInstanceFleetInstanceTypeConfigsEbsConfigPropertyToHclTerraform(struct?: AwsCluster.CoreInstanceFleetInstanceTypeConfigsEbsConfigProperty | cdktn.IResolvable): any;
export declare function awsClusterCoreInstanceFleetInstanceTypeConfigsPropertyToTerraform(struct?: AwsCluster.CoreInstanceFleetInstanceTypeConfigsProperty | cdktn.IResolvable): any;
export declare function awsClusterCoreInstanceFleetInstanceTypeConfigsPropertyToHclTerraform(struct?: AwsCluster.CoreInstanceFleetInstanceTypeConfigsProperty | cdktn.IResolvable): any;
export declare function awsClusterCoreInstanceFleetLaunchSpecificationsOnDemandSpecificationPropertyToTerraform(struct?: AwsCluster.CoreInstanceFleetLaunchSpecificationsOnDemandSpecificationProperty | cdktn.IResolvable): any;
export declare function awsClusterCoreInstanceFleetLaunchSpecificationsOnDemandSpecificationPropertyToHclTerraform(struct?: AwsCluster.CoreInstanceFleetLaunchSpecificationsOnDemandSpecificationProperty | cdktn.IResolvable): any;
export declare function awsClusterCoreInstanceFleetLaunchSpecificationsSpotSpecificationPropertyToTerraform(struct?: AwsCluster.CoreInstanceFleetLaunchSpecificationsSpotSpecificationProperty | cdktn.IResolvable): any;
export declare function awsClusterCoreInstanceFleetLaunchSpecificationsSpotSpecificationPropertyToHclTerraform(struct?: AwsCluster.CoreInstanceFleetLaunchSpecificationsSpotSpecificationProperty | cdktn.IResolvable): any;
export declare function awsClusterCoreInstanceFleetLaunchSpecificationsPropertyToTerraform(struct?: AwsCluster.CoreInstanceFleetLaunchSpecificationsPropertyOutputReference | AwsCluster.CoreInstanceFleetLaunchSpecificationsProperty): any;
export declare function awsClusterCoreInstanceFleetLaunchSpecificationsPropertyToHclTerraform(struct?: AwsCluster.CoreInstanceFleetLaunchSpecificationsPropertyOutputReference | AwsCluster.CoreInstanceFleetLaunchSpecificationsProperty): any;
export declare function awsClusterCoreInstanceFleetPropertyToTerraform(struct?: AwsCluster.CoreInstanceFleetPropertyOutputReference | AwsCluster.CoreInstanceFleetProperty): any;
export declare function awsClusterCoreInstanceFleetPropertyToHclTerraform(struct?: AwsCluster.CoreInstanceFleetPropertyOutputReference | AwsCluster.CoreInstanceFleetProperty): any;
export declare function awsClusterCoreInstanceGroupEbsConfigPropertyToTerraform(struct?: AwsCluster.CoreInstanceGroupEbsConfigProperty | cdktn.IResolvable): any;
export declare function awsClusterCoreInstanceGroupEbsConfigPropertyToHclTerraform(struct?: AwsCluster.CoreInstanceGroupEbsConfigProperty | cdktn.IResolvable): any;
export declare function awsClusterCoreInstanceGroupPropertyToTerraform(struct?: AwsCluster.CoreInstanceGroupPropertyOutputReference | AwsCluster.CoreInstanceGroupProperty): any;
export declare function awsClusterCoreInstanceGroupPropertyToHclTerraform(struct?: AwsCluster.CoreInstanceGroupPropertyOutputReference | AwsCluster.CoreInstanceGroupProperty): any;
export declare function awsClusterEc2AttributesPropertyToTerraform(struct?: AwsCluster.Ec2AttributesPropertyOutputReference | AwsCluster.Ec2AttributesProperty): any;
export declare function awsClusterEc2AttributesPropertyToHclTerraform(struct?: AwsCluster.Ec2AttributesPropertyOutputReference | AwsCluster.Ec2AttributesProperty): any;
export declare function awsClusterKerberosAttributesPropertyToTerraform(struct?: AwsCluster.KerberosAttributesPropertyOutputReference | AwsCluster.KerberosAttributesProperty): any;
export declare function awsClusterKerberosAttributesPropertyToHclTerraform(struct?: AwsCluster.KerberosAttributesPropertyOutputReference | AwsCluster.KerberosAttributesProperty): any;
export declare function awsClusterMasterInstanceFleetInstanceTypeConfigsConfigurationsPropertyToTerraform(struct?: AwsCluster.MasterInstanceFleetInstanceTypeConfigsConfigurationsProperty | cdktn.IResolvable): any;
export declare function awsClusterMasterInstanceFleetInstanceTypeConfigsConfigurationsPropertyToHclTerraform(struct?: AwsCluster.MasterInstanceFleetInstanceTypeConfigsConfigurationsProperty | cdktn.IResolvable): any;
export declare function awsClusterMasterInstanceFleetInstanceTypeConfigsEbsConfigPropertyToTerraform(struct?: AwsCluster.MasterInstanceFleetInstanceTypeConfigsEbsConfigProperty | cdktn.IResolvable): any;
export declare function awsClusterMasterInstanceFleetInstanceTypeConfigsEbsConfigPropertyToHclTerraform(struct?: AwsCluster.MasterInstanceFleetInstanceTypeConfigsEbsConfigProperty | cdktn.IResolvable): any;
export declare function awsClusterMasterInstanceFleetInstanceTypeConfigsPropertyToTerraform(struct?: AwsCluster.MasterInstanceFleetInstanceTypeConfigsProperty | cdktn.IResolvable): any;
export declare function awsClusterMasterInstanceFleetInstanceTypeConfigsPropertyToHclTerraform(struct?: AwsCluster.MasterInstanceFleetInstanceTypeConfigsProperty | cdktn.IResolvable): any;
export declare function awsClusterMasterInstanceFleetLaunchSpecificationsOnDemandSpecificationPropertyToTerraform(struct?: AwsCluster.MasterInstanceFleetLaunchSpecificationsOnDemandSpecificationProperty | cdktn.IResolvable): any;
export declare function awsClusterMasterInstanceFleetLaunchSpecificationsOnDemandSpecificationPropertyToHclTerraform(struct?: AwsCluster.MasterInstanceFleetLaunchSpecificationsOnDemandSpecificationProperty | cdktn.IResolvable): any;
export declare function awsClusterMasterInstanceFleetLaunchSpecificationsSpotSpecificationPropertyToTerraform(struct?: AwsCluster.MasterInstanceFleetLaunchSpecificationsSpotSpecificationProperty | cdktn.IResolvable): any;
export declare function awsClusterMasterInstanceFleetLaunchSpecificationsSpotSpecificationPropertyToHclTerraform(struct?: AwsCluster.MasterInstanceFleetLaunchSpecificationsSpotSpecificationProperty | cdktn.IResolvable): any;
export declare function awsClusterMasterInstanceFleetLaunchSpecificationsPropertyToTerraform(struct?: AwsCluster.MasterInstanceFleetLaunchSpecificationsPropertyOutputReference | AwsCluster.MasterInstanceFleetLaunchSpecificationsProperty): any;
export declare function awsClusterMasterInstanceFleetLaunchSpecificationsPropertyToHclTerraform(struct?: AwsCluster.MasterInstanceFleetLaunchSpecificationsPropertyOutputReference | AwsCluster.MasterInstanceFleetLaunchSpecificationsProperty): any;
export declare function awsClusterMasterInstanceFleetPropertyToTerraform(struct?: AwsCluster.MasterInstanceFleetPropertyOutputReference | AwsCluster.MasterInstanceFleetProperty): any;
export declare function awsClusterMasterInstanceFleetPropertyToHclTerraform(struct?: AwsCluster.MasterInstanceFleetPropertyOutputReference | AwsCluster.MasterInstanceFleetProperty): any;
export declare function awsClusterMasterInstanceGroupEbsConfigPropertyToTerraform(struct?: AwsCluster.MasterInstanceGroupEbsConfigProperty | cdktn.IResolvable): any;
export declare function awsClusterMasterInstanceGroupEbsConfigPropertyToHclTerraform(struct?: AwsCluster.MasterInstanceGroupEbsConfigProperty | cdktn.IResolvable): any;
export declare function awsClusterMasterInstanceGroupPropertyToTerraform(struct?: AwsCluster.MasterInstanceGroupPropertyOutputReference | AwsCluster.MasterInstanceGroupProperty): any;
export declare function awsClusterMasterInstanceGroupPropertyToHclTerraform(struct?: AwsCluster.MasterInstanceGroupPropertyOutputReference | AwsCluster.MasterInstanceGroupProperty): any;
export declare namespace AwsCluster {
    interface PlacementGroupConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#instance_role AwsCluster#instance_role}
        */
        readonly instanceRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#placement_strategy AwsCluster#placement_strategy}
        */
        readonly placementStrategy?: string;
    }
    class PlacementGroupConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PlacementGroupConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PlacementGroupConfigProperty | cdktn.IResolvable | undefined);
        private _instanceRole?;
        get instanceRole(): string;
        set instanceRole(value: string);
        resetInstanceRole(): void;
        get instanceRoleInput(): string | undefined;
        private _placementStrategy?;
        get placementStrategy(): string;
        set placementStrategy(value: string);
        resetPlacementStrategy(): void;
        get placementStrategyInput(): string | undefined;
    }
    class PlacementGroupConfigPropertyList extends cdktn.ComplexList {
        internalValue?: PlacementGroupConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PlacementGroupConfigPropertyOutputReference;
    }
    interface HadoopJarStepProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#args AwsCluster#args}
        */
        readonly args?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#jar AwsCluster#jar}
        */
        readonly jar?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#main_class AwsCluster#main_class}
        */
        readonly mainClass?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#properties AwsCluster#properties}
        */
        readonly properties?: {
            [key: string]: string;
        };
    }
    class HadoopJarStepPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HadoopJarStepProperty | cdktn.IResolvable | undefined;
        set internalValue(value: HadoopJarStepProperty | cdktn.IResolvable | undefined);
        private _args?;
        get args(): string[];
        set args(value: string[]);
        resetArgs(): void;
        get argsInput(): string[] | undefined;
        private _jar?;
        get jar(): string;
        set jar(value: string);
        resetJar(): void;
        get jarInput(): string | undefined;
        private _mainClass?;
        get mainClass(): string;
        set mainClass(value: string);
        resetMainClass(): void;
        get mainClassInput(): string | undefined;
        private _properties?;
        get properties(): {
            [key: string]: string;
        };
        set properties(value: {
            [key: string]: string;
        });
        resetProperties(): void;
        get propertiesInput(): {
            [key: string]: string;
        } | undefined;
    }
    class HadoopJarStepPropertyList extends cdktn.ComplexList {
        internalValue?: HadoopJarStepProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HadoopJarStepPropertyOutputReference;
    }
    interface StepProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#action_on_failure AwsCluster#action_on_failure}
        */
        readonly actionOnFailure?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#hadoop_jar_step AwsCluster#hadoop_jar_step}
        */
        readonly hadoopJarStep?: HadoopJarStepProperty[] | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#name AwsCluster#name}
        */
        readonly name?: string;
    }
    class StepPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StepProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StepProperty | cdktn.IResolvable | undefined);
        private _actionOnFailure?;
        get actionOnFailure(): string;
        set actionOnFailure(value: string);
        resetActionOnFailure(): void;
        get actionOnFailureInput(): string | undefined;
        private _hadoopJarStep;
        get hadoopJarStep(): HadoopJarStepPropertyList;
        putHadoopJarStep(value: HadoopJarStepProperty[] | cdktn.IResolvable): void;
        resetHadoopJarStep(): void;
        get hadoopJarStepInput(): cdktn.IResolvable | HadoopJarStepProperty[] | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
    }
    class StepPropertyList extends cdktn.ComplexList {
        internalValue?: StepProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StepPropertyOutputReference;
    }
    interface AutoTerminationPolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#idle_timeout AwsCluster#idle_timeout}
        */
        readonly idleTimeout?: number;
    }
    class AutoTerminationPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AutoTerminationPolicyProperty | undefined;
        set internalValue(value: AutoTerminationPolicyProperty | undefined);
        private _idleTimeout?;
        get idleTimeout(): number;
        set idleTimeout(value: number);
        resetIdleTimeout(): void;
        get idleTimeoutInput(): number | undefined;
    }
    interface BootstrapActionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#args AwsCluster#args}
        */
        readonly args?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#name AwsCluster#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#path AwsCluster#path}
        */
        readonly path: string;
    }
    class BootstrapActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BootstrapActionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: BootstrapActionProperty | cdktn.IResolvable | undefined);
        private _args?;
        get args(): string[];
        set args(value: string[]);
        resetArgs(): void;
        get argsInput(): string[] | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _path?;
        get path(): string;
        set path(value: string);
        get pathInput(): string | undefined;
    }
    class BootstrapActionPropertyList extends cdktn.ComplexList {
        internalValue?: BootstrapActionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BootstrapActionPropertyOutputReference;
    }
    interface CoreInstanceFleetInstanceTypeConfigsConfigurationsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#classification AwsCluster#classification}
        */
        readonly classification?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#properties AwsCluster#properties}
        */
        readonly properties?: {
            [key: string]: string;
        };
    }
    class CoreInstanceFleetInstanceTypeConfigsConfigurationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CoreInstanceFleetInstanceTypeConfigsConfigurationsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CoreInstanceFleetInstanceTypeConfigsConfigurationsProperty | cdktn.IResolvable | undefined);
        private _classification?;
        get classification(): string;
        set classification(value: string);
        resetClassification(): void;
        get classificationInput(): string | undefined;
        private _properties?;
        get properties(): {
            [key: string]: string;
        };
        set properties(value: {
            [key: string]: string;
        });
        resetProperties(): void;
        get propertiesInput(): {
            [key: string]: string;
        } | undefined;
    }
    class CoreInstanceFleetInstanceTypeConfigsConfigurationsPropertyList extends cdktn.ComplexList {
        internalValue?: CoreInstanceFleetInstanceTypeConfigsConfigurationsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CoreInstanceFleetInstanceTypeConfigsConfigurationsPropertyOutputReference;
    }
    interface CoreInstanceFleetInstanceTypeConfigsEbsConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#iops AwsCluster#iops}
        */
        readonly iops?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#size AwsCluster#size}
        */
        readonly size: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#type AwsCluster#type}
        */
        readonly type: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#volumes_per_instance AwsCluster#volumes_per_instance}
        */
        readonly volumesPerInstance?: number;
    }
    class CoreInstanceFleetInstanceTypeConfigsEbsConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CoreInstanceFleetInstanceTypeConfigsEbsConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CoreInstanceFleetInstanceTypeConfigsEbsConfigProperty | cdktn.IResolvable | undefined);
        private _iops?;
        get iops(): number;
        set iops(value: number);
        resetIops(): void;
        get iopsInput(): number | undefined;
        private _size?;
        get size(): number;
        set size(value: number);
        get sizeInput(): number | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _volumesPerInstance?;
        get volumesPerInstance(): number;
        set volumesPerInstance(value: number);
        resetVolumesPerInstance(): void;
        get volumesPerInstanceInput(): number | undefined;
    }
    class CoreInstanceFleetInstanceTypeConfigsEbsConfigPropertyList extends cdktn.ComplexList {
        internalValue?: CoreInstanceFleetInstanceTypeConfigsEbsConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CoreInstanceFleetInstanceTypeConfigsEbsConfigPropertyOutputReference;
    }
    interface CoreInstanceFleetInstanceTypeConfigsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#bid_price AwsCluster#bid_price}
        */
        readonly bidPrice?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#bid_price_as_percentage_of_on_demand_price AwsCluster#bid_price_as_percentage_of_on_demand_price}
        */
        readonly bidPriceAsPercentageOfOnDemandPrice?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#instance_type AwsCluster#instance_type}
        */
        readonly instanceType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#weighted_capacity AwsCluster#weighted_capacity}
        */
        readonly weightedCapacity?: number;
        /**
        * configurations block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#configurations AwsCluster#configurations}
        */
        readonly configurations?: CoreInstanceFleetInstanceTypeConfigsConfigurationsProperty[] | cdktn.IResolvable;
        /**
        * ebs_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#ebs_config AwsCluster#ebs_config}
        */
        readonly ebsConfig?: CoreInstanceFleetInstanceTypeConfigsEbsConfigProperty[] | cdktn.IResolvable;
    }
    class CoreInstanceFleetInstanceTypeConfigsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CoreInstanceFleetInstanceTypeConfigsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CoreInstanceFleetInstanceTypeConfigsProperty | cdktn.IResolvable | undefined);
        private _bidPrice?;
        get bidPrice(): string;
        set bidPrice(value: string);
        resetBidPrice(): void;
        get bidPriceInput(): string | undefined;
        private _bidPriceAsPercentageOfOnDemandPrice?;
        get bidPriceAsPercentageOfOnDemandPrice(): number;
        set bidPriceAsPercentageOfOnDemandPrice(value: number);
        resetBidPriceAsPercentageOfOnDemandPrice(): void;
        get bidPriceAsPercentageOfOnDemandPriceInput(): number | undefined;
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        get instanceTypeInput(): string | undefined;
        private _weightedCapacity?;
        get weightedCapacity(): number;
        set weightedCapacity(value: number);
        resetWeightedCapacity(): void;
        get weightedCapacityInput(): number | undefined;
        private _configurations;
        get configurations(): CoreInstanceFleetInstanceTypeConfigsConfigurationsPropertyList;
        putConfigurations(value: CoreInstanceFleetInstanceTypeConfigsConfigurationsProperty[] | cdktn.IResolvable): void;
        resetConfigurations(): void;
        get configurationsInput(): cdktn.IResolvable | CoreInstanceFleetInstanceTypeConfigsConfigurationsProperty[] | undefined;
        private _ebsConfig;
        get ebsConfig(): CoreInstanceFleetInstanceTypeConfigsEbsConfigPropertyList;
        putEbsConfig(value: CoreInstanceFleetInstanceTypeConfigsEbsConfigProperty[] | cdktn.IResolvable): void;
        resetEbsConfig(): void;
        get ebsConfigInput(): cdktn.IResolvable | CoreInstanceFleetInstanceTypeConfigsEbsConfigProperty[] | undefined;
    }
    class CoreInstanceFleetInstanceTypeConfigsPropertyList extends cdktn.ComplexList {
        internalValue?: CoreInstanceFleetInstanceTypeConfigsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CoreInstanceFleetInstanceTypeConfigsPropertyOutputReference;
    }
    interface CoreInstanceFleetLaunchSpecificationsOnDemandSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#allocation_strategy AwsCluster#allocation_strategy}
        */
        readonly allocationStrategy: string;
    }
    class CoreInstanceFleetLaunchSpecificationsOnDemandSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CoreInstanceFleetLaunchSpecificationsOnDemandSpecificationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CoreInstanceFleetLaunchSpecificationsOnDemandSpecificationProperty | cdktn.IResolvable | undefined);
        private _allocationStrategy?;
        get allocationStrategy(): string;
        set allocationStrategy(value: string);
        get allocationStrategyInput(): string | undefined;
    }
    class CoreInstanceFleetLaunchSpecificationsOnDemandSpecificationPropertyList extends cdktn.ComplexList {
        internalValue?: CoreInstanceFleetLaunchSpecificationsOnDemandSpecificationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CoreInstanceFleetLaunchSpecificationsOnDemandSpecificationPropertyOutputReference;
    }
    interface CoreInstanceFleetLaunchSpecificationsSpotSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#allocation_strategy AwsCluster#allocation_strategy}
        */
        readonly allocationStrategy: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#block_duration_minutes AwsCluster#block_duration_minutes}
        */
        readonly blockDurationMinutes?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#timeout_action AwsCluster#timeout_action}
        */
        readonly timeoutAction: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#timeout_duration_minutes AwsCluster#timeout_duration_minutes}
        */
        readonly timeoutDurationMinutes: number;
    }
    class CoreInstanceFleetLaunchSpecificationsSpotSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CoreInstanceFleetLaunchSpecificationsSpotSpecificationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CoreInstanceFleetLaunchSpecificationsSpotSpecificationProperty | cdktn.IResolvable | undefined);
        private _allocationStrategy?;
        get allocationStrategy(): string;
        set allocationStrategy(value: string);
        get allocationStrategyInput(): string | undefined;
        private _blockDurationMinutes?;
        get blockDurationMinutes(): number;
        set blockDurationMinutes(value: number);
        resetBlockDurationMinutes(): void;
        get blockDurationMinutesInput(): number | undefined;
        private _timeoutAction?;
        get timeoutAction(): string;
        set timeoutAction(value: string);
        get timeoutActionInput(): string | undefined;
        private _timeoutDurationMinutes?;
        get timeoutDurationMinutes(): number;
        set timeoutDurationMinutes(value: number);
        get timeoutDurationMinutesInput(): number | undefined;
    }
    class CoreInstanceFleetLaunchSpecificationsSpotSpecificationPropertyList extends cdktn.ComplexList {
        internalValue?: CoreInstanceFleetLaunchSpecificationsSpotSpecificationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CoreInstanceFleetLaunchSpecificationsSpotSpecificationPropertyOutputReference;
    }
    interface CoreInstanceFleetLaunchSpecificationsProperty {
        /**
        * on_demand_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#on_demand_specification AwsCluster#on_demand_specification}
        */
        readonly onDemandSpecification?: CoreInstanceFleetLaunchSpecificationsOnDemandSpecificationProperty[] | cdktn.IResolvable;
        /**
        * spot_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#spot_specification AwsCluster#spot_specification}
        */
        readonly spotSpecification?: CoreInstanceFleetLaunchSpecificationsSpotSpecificationProperty[] | cdktn.IResolvable;
    }
    class CoreInstanceFleetLaunchSpecificationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CoreInstanceFleetLaunchSpecificationsProperty | undefined;
        set internalValue(value: CoreInstanceFleetLaunchSpecificationsProperty | undefined);
        private _onDemandSpecification;
        get onDemandSpecification(): CoreInstanceFleetLaunchSpecificationsOnDemandSpecificationPropertyList;
        putOnDemandSpecification(value: CoreInstanceFleetLaunchSpecificationsOnDemandSpecificationProperty[] | cdktn.IResolvable): void;
        resetOnDemandSpecification(): void;
        get onDemandSpecificationInput(): cdktn.IResolvable | CoreInstanceFleetLaunchSpecificationsOnDemandSpecificationProperty[] | undefined;
        private _spotSpecification;
        get spotSpecification(): CoreInstanceFleetLaunchSpecificationsSpotSpecificationPropertyList;
        putSpotSpecification(value: CoreInstanceFleetLaunchSpecificationsSpotSpecificationProperty[] | cdktn.IResolvable): void;
        resetSpotSpecification(): void;
        get spotSpecificationInput(): cdktn.IResolvable | CoreInstanceFleetLaunchSpecificationsSpotSpecificationProperty[] | undefined;
    }
    interface CoreInstanceFleetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#name AwsCluster#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#target_on_demand_capacity AwsCluster#target_on_demand_capacity}
        */
        readonly targetOnDemandCapacity?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#target_spot_capacity AwsCluster#target_spot_capacity}
        */
        readonly targetSpotCapacity?: number;
        /**
        * instance_type_configs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#instance_type_configs AwsCluster#instance_type_configs}
        */
        readonly instanceTypeConfigs?: CoreInstanceFleetInstanceTypeConfigsProperty[] | cdktn.IResolvable;
        /**
        * launch_specifications block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#launch_specifications AwsCluster#launch_specifications}
        */
        readonly launchSpecifications?: CoreInstanceFleetLaunchSpecificationsProperty;
    }
    class CoreInstanceFleetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CoreInstanceFleetProperty | undefined;
        set internalValue(value: CoreInstanceFleetProperty | undefined);
        get id(): string;
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        get provisionedOnDemandCapacity(): number;
        get provisionedSpotCapacity(): number;
        private _targetOnDemandCapacity?;
        get targetOnDemandCapacity(): number;
        set targetOnDemandCapacity(value: number);
        resetTargetOnDemandCapacity(): void;
        get targetOnDemandCapacityInput(): number | undefined;
        private _targetSpotCapacity?;
        get targetSpotCapacity(): number;
        set targetSpotCapacity(value: number);
        resetTargetSpotCapacity(): void;
        get targetSpotCapacityInput(): number | undefined;
        private _instanceTypeConfigs;
        get instanceTypeConfigs(): CoreInstanceFleetInstanceTypeConfigsPropertyList;
        putInstanceTypeConfigs(value: CoreInstanceFleetInstanceTypeConfigsProperty[] | cdktn.IResolvable): void;
        resetInstanceTypeConfigs(): void;
        get instanceTypeConfigsInput(): cdktn.IResolvable | CoreInstanceFleetInstanceTypeConfigsProperty[] | undefined;
        private _launchSpecifications;
        get launchSpecifications(): CoreInstanceFleetLaunchSpecificationsPropertyOutputReference;
        putLaunchSpecifications(value: CoreInstanceFleetLaunchSpecificationsProperty): void;
        resetLaunchSpecifications(): void;
        get launchSpecificationsInput(): CoreInstanceFleetLaunchSpecificationsProperty | undefined;
    }
    interface CoreInstanceGroupEbsConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#iops AwsCluster#iops}
        */
        readonly iops?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#size AwsCluster#size}
        */
        readonly size: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#throughput AwsCluster#throughput}
        */
        readonly throughput?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#type AwsCluster#type}
        */
        readonly type: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#volumes_per_instance AwsCluster#volumes_per_instance}
        */
        readonly volumesPerInstance?: number;
    }
    class CoreInstanceGroupEbsConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CoreInstanceGroupEbsConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CoreInstanceGroupEbsConfigProperty | cdktn.IResolvable | undefined);
        private _iops?;
        get iops(): number;
        set iops(value: number);
        resetIops(): void;
        get iopsInput(): number | undefined;
        private _size?;
        get size(): number;
        set size(value: number);
        get sizeInput(): number | undefined;
        private _throughput?;
        get throughput(): number;
        set throughput(value: number);
        resetThroughput(): void;
        get throughputInput(): number | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _volumesPerInstance?;
        get volumesPerInstance(): number;
        set volumesPerInstance(value: number);
        resetVolumesPerInstance(): void;
        get volumesPerInstanceInput(): number | undefined;
    }
    class CoreInstanceGroupEbsConfigPropertyList extends cdktn.ComplexList {
        internalValue?: CoreInstanceGroupEbsConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CoreInstanceGroupEbsConfigPropertyOutputReference;
    }
    interface CoreInstanceGroupProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#autoscaling_policy AwsCluster#autoscaling_policy}
        */
        readonly autoscalingPolicy?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#bid_price AwsCluster#bid_price}
        */
        readonly bidPrice?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#instance_count AwsCluster#instance_count}
        */
        readonly instanceCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#instance_type AwsCluster#instance_type}
        */
        readonly instanceType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#name AwsCluster#name}
        */
        readonly name?: string;
        /**
        * ebs_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#ebs_config AwsCluster#ebs_config}
        */
        readonly ebsConfig?: CoreInstanceGroupEbsConfigProperty[] | cdktn.IResolvable;
    }
    class CoreInstanceGroupPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CoreInstanceGroupProperty | undefined;
        set internalValue(value: CoreInstanceGroupProperty | undefined);
        private _autoscalingPolicy?;
        get autoscalingPolicy(): string;
        set autoscalingPolicy(value: string);
        resetAutoscalingPolicy(): void;
        get autoscalingPolicyInput(): string | undefined;
        private _bidPrice?;
        get bidPrice(): string;
        set bidPrice(value: string);
        resetBidPrice(): void;
        get bidPriceInput(): string | undefined;
        get id(): string;
        private _instanceCount?;
        get instanceCount(): number;
        set instanceCount(value: number);
        resetInstanceCount(): void;
        get instanceCountInput(): number | undefined;
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        get instanceTypeInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _ebsConfig;
        get ebsConfig(): CoreInstanceGroupEbsConfigPropertyList;
        putEbsConfig(value: CoreInstanceGroupEbsConfigProperty[] | cdktn.IResolvable): void;
        resetEbsConfig(): void;
        get ebsConfigInput(): cdktn.IResolvable | CoreInstanceGroupEbsConfigProperty[] | undefined;
    }
    interface Ec2AttributesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#additional_master_security_groups AwsCluster#additional_master_security_groups}
        */
        readonly additionalMasterSecurityGroups?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#additional_slave_security_groups AwsCluster#additional_slave_security_groups}
        */
        readonly additionalSlaveSecurityGroups?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#emr_managed_master_security_group AwsCluster#emr_managed_master_security_group}
        */
        readonly emrManagedMasterSecurityGroup?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#emr_managed_slave_security_group AwsCluster#emr_managed_slave_security_group}
        */
        readonly emrManagedSlaveSecurityGroup?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#instance_profile AwsCluster#instance_profile}
        */
        readonly instanceProfile: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#key_name AwsCluster#key_name}
        */
        readonly keyName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#service_access_security_group AwsCluster#service_access_security_group}
        */
        readonly serviceAccessSecurityGroup?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#subnet_id AwsCluster#subnet_id}
        */
        readonly subnetId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#subnet_ids AwsCluster#subnet_ids}
        */
        readonly subnetIds?: string[];
    }
    class Ec2AttributesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): Ec2AttributesProperty | undefined;
        set internalValue(value: Ec2AttributesProperty | undefined);
        private _additionalMasterSecurityGroups?;
        get additionalMasterSecurityGroups(): string;
        set additionalMasterSecurityGroups(value: string);
        resetAdditionalMasterSecurityGroups(): void;
        get additionalMasterSecurityGroupsInput(): string | undefined;
        private _additionalSlaveSecurityGroups?;
        get additionalSlaveSecurityGroups(): string;
        set additionalSlaveSecurityGroups(value: string);
        resetAdditionalSlaveSecurityGroups(): void;
        get additionalSlaveSecurityGroupsInput(): string | undefined;
        private _emrManagedMasterSecurityGroup?;
        get emrManagedMasterSecurityGroup(): string;
        set emrManagedMasterSecurityGroup(value: string);
        resetEmrManagedMasterSecurityGroup(): void;
        get emrManagedMasterSecurityGroupInput(): string | undefined;
        private _emrManagedSlaveSecurityGroup?;
        get emrManagedSlaveSecurityGroup(): string;
        set emrManagedSlaveSecurityGroup(value: string);
        resetEmrManagedSlaveSecurityGroup(): void;
        get emrManagedSlaveSecurityGroupInput(): string | undefined;
        private _instanceProfile?;
        get instanceProfile(): string;
        set instanceProfile(value: string);
        get instanceProfileInput(): string | undefined;
        private _keyName?;
        get keyName(): string;
        set keyName(value: string);
        resetKeyName(): void;
        get keyNameInput(): string | undefined;
        private _serviceAccessSecurityGroup?;
        get serviceAccessSecurityGroup(): string;
        set serviceAccessSecurityGroup(value: string);
        resetServiceAccessSecurityGroup(): void;
        get serviceAccessSecurityGroupInput(): string | undefined;
        private _subnetId?;
        get subnetId(): string;
        set subnetId(value: string);
        resetSubnetId(): void;
        get subnetIdInput(): string | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        resetSubnetIds(): void;
        get subnetIdsInput(): string[] | undefined;
    }
    interface KerberosAttributesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#ad_domain_join_password AwsCluster#ad_domain_join_password}
        */
        readonly adDomainJoinPassword?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#ad_domain_join_user AwsCluster#ad_domain_join_user}
        */
        readonly adDomainJoinUser?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#cross_realm_trust_principal_password AwsCluster#cross_realm_trust_principal_password}
        */
        readonly crossRealmTrustPrincipalPassword?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#kdc_admin_password AwsCluster#kdc_admin_password}
        */
        readonly kdcAdminPassword: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#realm AwsCluster#realm}
        */
        readonly realm: string;
    }
    class KerberosAttributesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): KerberosAttributesProperty | undefined;
        set internalValue(value: KerberosAttributesProperty | undefined);
        private _adDomainJoinPassword?;
        get adDomainJoinPassword(): string;
        set adDomainJoinPassword(value: string);
        resetAdDomainJoinPassword(): void;
        get adDomainJoinPasswordInput(): string | undefined;
        private _adDomainJoinUser?;
        get adDomainJoinUser(): string;
        set adDomainJoinUser(value: string);
        resetAdDomainJoinUser(): void;
        get adDomainJoinUserInput(): string | undefined;
        private _crossRealmTrustPrincipalPassword?;
        get crossRealmTrustPrincipalPassword(): string;
        set crossRealmTrustPrincipalPassword(value: string);
        resetCrossRealmTrustPrincipalPassword(): void;
        get crossRealmTrustPrincipalPasswordInput(): string | undefined;
        private _kdcAdminPassword?;
        get kdcAdminPassword(): string;
        set kdcAdminPassword(value: string);
        get kdcAdminPasswordInput(): string | undefined;
        private _realm?;
        get realm(): string;
        set realm(value: string);
        get realmInput(): string | undefined;
    }
    interface MasterInstanceFleetInstanceTypeConfigsConfigurationsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#classification AwsCluster#classification}
        */
        readonly classification?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#properties AwsCluster#properties}
        */
        readonly properties?: {
            [key: string]: string;
        };
    }
    class MasterInstanceFleetInstanceTypeConfigsConfigurationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MasterInstanceFleetInstanceTypeConfigsConfigurationsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MasterInstanceFleetInstanceTypeConfigsConfigurationsProperty | cdktn.IResolvable | undefined);
        private _classification?;
        get classification(): string;
        set classification(value: string);
        resetClassification(): void;
        get classificationInput(): string | undefined;
        private _properties?;
        get properties(): {
            [key: string]: string;
        };
        set properties(value: {
            [key: string]: string;
        });
        resetProperties(): void;
        get propertiesInput(): {
            [key: string]: string;
        } | undefined;
    }
    class MasterInstanceFleetInstanceTypeConfigsConfigurationsPropertyList extends cdktn.ComplexList {
        internalValue?: MasterInstanceFleetInstanceTypeConfigsConfigurationsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MasterInstanceFleetInstanceTypeConfigsConfigurationsPropertyOutputReference;
    }
    interface MasterInstanceFleetInstanceTypeConfigsEbsConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#iops AwsCluster#iops}
        */
        readonly iops?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#size AwsCluster#size}
        */
        readonly size: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#type AwsCluster#type}
        */
        readonly type: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#volumes_per_instance AwsCluster#volumes_per_instance}
        */
        readonly volumesPerInstance?: number;
    }
    class MasterInstanceFleetInstanceTypeConfigsEbsConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MasterInstanceFleetInstanceTypeConfigsEbsConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MasterInstanceFleetInstanceTypeConfigsEbsConfigProperty | cdktn.IResolvable | undefined);
        private _iops?;
        get iops(): number;
        set iops(value: number);
        resetIops(): void;
        get iopsInput(): number | undefined;
        private _size?;
        get size(): number;
        set size(value: number);
        get sizeInput(): number | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _volumesPerInstance?;
        get volumesPerInstance(): number;
        set volumesPerInstance(value: number);
        resetVolumesPerInstance(): void;
        get volumesPerInstanceInput(): number | undefined;
    }
    class MasterInstanceFleetInstanceTypeConfigsEbsConfigPropertyList extends cdktn.ComplexList {
        internalValue?: MasterInstanceFleetInstanceTypeConfigsEbsConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MasterInstanceFleetInstanceTypeConfigsEbsConfigPropertyOutputReference;
    }
    interface MasterInstanceFleetInstanceTypeConfigsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#bid_price AwsCluster#bid_price}
        */
        readonly bidPrice?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#bid_price_as_percentage_of_on_demand_price AwsCluster#bid_price_as_percentage_of_on_demand_price}
        */
        readonly bidPriceAsPercentageOfOnDemandPrice?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#instance_type AwsCluster#instance_type}
        */
        readonly instanceType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#weighted_capacity AwsCluster#weighted_capacity}
        */
        readonly weightedCapacity?: number;
        /**
        * configurations block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#configurations AwsCluster#configurations}
        */
        readonly configurations?: MasterInstanceFleetInstanceTypeConfigsConfigurationsProperty[] | cdktn.IResolvable;
        /**
        * ebs_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#ebs_config AwsCluster#ebs_config}
        */
        readonly ebsConfig?: MasterInstanceFleetInstanceTypeConfigsEbsConfigProperty[] | cdktn.IResolvable;
    }
    class MasterInstanceFleetInstanceTypeConfigsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MasterInstanceFleetInstanceTypeConfigsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MasterInstanceFleetInstanceTypeConfigsProperty | cdktn.IResolvable | undefined);
        private _bidPrice?;
        get bidPrice(): string;
        set bidPrice(value: string);
        resetBidPrice(): void;
        get bidPriceInput(): string | undefined;
        private _bidPriceAsPercentageOfOnDemandPrice?;
        get bidPriceAsPercentageOfOnDemandPrice(): number;
        set bidPriceAsPercentageOfOnDemandPrice(value: number);
        resetBidPriceAsPercentageOfOnDemandPrice(): void;
        get bidPriceAsPercentageOfOnDemandPriceInput(): number | undefined;
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        get instanceTypeInput(): string | undefined;
        private _weightedCapacity?;
        get weightedCapacity(): number;
        set weightedCapacity(value: number);
        resetWeightedCapacity(): void;
        get weightedCapacityInput(): number | undefined;
        private _configurations;
        get configurations(): MasterInstanceFleetInstanceTypeConfigsConfigurationsPropertyList;
        putConfigurations(value: MasterInstanceFleetInstanceTypeConfigsConfigurationsProperty[] | cdktn.IResolvable): void;
        resetConfigurations(): void;
        get configurationsInput(): cdktn.IResolvable | MasterInstanceFleetInstanceTypeConfigsConfigurationsProperty[] | undefined;
        private _ebsConfig;
        get ebsConfig(): MasterInstanceFleetInstanceTypeConfigsEbsConfigPropertyList;
        putEbsConfig(value: MasterInstanceFleetInstanceTypeConfigsEbsConfigProperty[] | cdktn.IResolvable): void;
        resetEbsConfig(): void;
        get ebsConfigInput(): cdktn.IResolvable | MasterInstanceFleetInstanceTypeConfigsEbsConfigProperty[] | undefined;
    }
    class MasterInstanceFleetInstanceTypeConfigsPropertyList extends cdktn.ComplexList {
        internalValue?: MasterInstanceFleetInstanceTypeConfigsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MasterInstanceFleetInstanceTypeConfigsPropertyOutputReference;
    }
    interface MasterInstanceFleetLaunchSpecificationsOnDemandSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#allocation_strategy AwsCluster#allocation_strategy}
        */
        readonly allocationStrategy: string;
    }
    class MasterInstanceFleetLaunchSpecificationsOnDemandSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MasterInstanceFleetLaunchSpecificationsOnDemandSpecificationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MasterInstanceFleetLaunchSpecificationsOnDemandSpecificationProperty | cdktn.IResolvable | undefined);
        private _allocationStrategy?;
        get allocationStrategy(): string;
        set allocationStrategy(value: string);
        get allocationStrategyInput(): string | undefined;
    }
    class MasterInstanceFleetLaunchSpecificationsOnDemandSpecificationPropertyList extends cdktn.ComplexList {
        internalValue?: MasterInstanceFleetLaunchSpecificationsOnDemandSpecificationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MasterInstanceFleetLaunchSpecificationsOnDemandSpecificationPropertyOutputReference;
    }
    interface MasterInstanceFleetLaunchSpecificationsSpotSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#allocation_strategy AwsCluster#allocation_strategy}
        */
        readonly allocationStrategy: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#block_duration_minutes AwsCluster#block_duration_minutes}
        */
        readonly blockDurationMinutes?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#timeout_action AwsCluster#timeout_action}
        */
        readonly timeoutAction: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#timeout_duration_minutes AwsCluster#timeout_duration_minutes}
        */
        readonly timeoutDurationMinutes: number;
    }
    class MasterInstanceFleetLaunchSpecificationsSpotSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MasterInstanceFleetLaunchSpecificationsSpotSpecificationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MasterInstanceFleetLaunchSpecificationsSpotSpecificationProperty | cdktn.IResolvable | undefined);
        private _allocationStrategy?;
        get allocationStrategy(): string;
        set allocationStrategy(value: string);
        get allocationStrategyInput(): string | undefined;
        private _blockDurationMinutes?;
        get blockDurationMinutes(): number;
        set blockDurationMinutes(value: number);
        resetBlockDurationMinutes(): void;
        get blockDurationMinutesInput(): number | undefined;
        private _timeoutAction?;
        get timeoutAction(): string;
        set timeoutAction(value: string);
        get timeoutActionInput(): string | undefined;
        private _timeoutDurationMinutes?;
        get timeoutDurationMinutes(): number;
        set timeoutDurationMinutes(value: number);
        get timeoutDurationMinutesInput(): number | undefined;
    }
    class MasterInstanceFleetLaunchSpecificationsSpotSpecificationPropertyList extends cdktn.ComplexList {
        internalValue?: MasterInstanceFleetLaunchSpecificationsSpotSpecificationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MasterInstanceFleetLaunchSpecificationsSpotSpecificationPropertyOutputReference;
    }
    interface MasterInstanceFleetLaunchSpecificationsProperty {
        /**
        * on_demand_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#on_demand_specification AwsCluster#on_demand_specification}
        */
        readonly onDemandSpecification?: MasterInstanceFleetLaunchSpecificationsOnDemandSpecificationProperty[] | cdktn.IResolvable;
        /**
        * spot_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#spot_specification AwsCluster#spot_specification}
        */
        readonly spotSpecification?: MasterInstanceFleetLaunchSpecificationsSpotSpecificationProperty[] | cdktn.IResolvable;
    }
    class MasterInstanceFleetLaunchSpecificationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MasterInstanceFleetLaunchSpecificationsProperty | undefined;
        set internalValue(value: MasterInstanceFleetLaunchSpecificationsProperty | undefined);
        private _onDemandSpecification;
        get onDemandSpecification(): MasterInstanceFleetLaunchSpecificationsOnDemandSpecificationPropertyList;
        putOnDemandSpecification(value: MasterInstanceFleetLaunchSpecificationsOnDemandSpecificationProperty[] | cdktn.IResolvable): void;
        resetOnDemandSpecification(): void;
        get onDemandSpecificationInput(): cdktn.IResolvable | MasterInstanceFleetLaunchSpecificationsOnDemandSpecificationProperty[] | undefined;
        private _spotSpecification;
        get spotSpecification(): MasterInstanceFleetLaunchSpecificationsSpotSpecificationPropertyList;
        putSpotSpecification(value: MasterInstanceFleetLaunchSpecificationsSpotSpecificationProperty[] | cdktn.IResolvable): void;
        resetSpotSpecification(): void;
        get spotSpecificationInput(): cdktn.IResolvable | MasterInstanceFleetLaunchSpecificationsSpotSpecificationProperty[] | undefined;
    }
    interface MasterInstanceFleetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#name AwsCluster#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#target_on_demand_capacity AwsCluster#target_on_demand_capacity}
        */
        readonly targetOnDemandCapacity?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#target_spot_capacity AwsCluster#target_spot_capacity}
        */
        readonly targetSpotCapacity?: number;
        /**
        * instance_type_configs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#instance_type_configs AwsCluster#instance_type_configs}
        */
        readonly instanceTypeConfigs?: MasterInstanceFleetInstanceTypeConfigsProperty[] | cdktn.IResolvable;
        /**
        * launch_specifications block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#launch_specifications AwsCluster#launch_specifications}
        */
        readonly launchSpecifications?: MasterInstanceFleetLaunchSpecificationsProperty;
    }
    class MasterInstanceFleetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MasterInstanceFleetProperty | undefined;
        set internalValue(value: MasterInstanceFleetProperty | undefined);
        get id(): string;
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        get provisionedOnDemandCapacity(): number;
        get provisionedSpotCapacity(): number;
        private _targetOnDemandCapacity?;
        get targetOnDemandCapacity(): number;
        set targetOnDemandCapacity(value: number);
        resetTargetOnDemandCapacity(): void;
        get targetOnDemandCapacityInput(): number | undefined;
        private _targetSpotCapacity?;
        get targetSpotCapacity(): number;
        set targetSpotCapacity(value: number);
        resetTargetSpotCapacity(): void;
        get targetSpotCapacityInput(): number | undefined;
        private _instanceTypeConfigs;
        get instanceTypeConfigs(): MasterInstanceFleetInstanceTypeConfigsPropertyList;
        putInstanceTypeConfigs(value: MasterInstanceFleetInstanceTypeConfigsProperty[] | cdktn.IResolvable): void;
        resetInstanceTypeConfigs(): void;
        get instanceTypeConfigsInput(): cdktn.IResolvable | MasterInstanceFleetInstanceTypeConfigsProperty[] | undefined;
        private _launchSpecifications;
        get launchSpecifications(): MasterInstanceFleetLaunchSpecificationsPropertyOutputReference;
        putLaunchSpecifications(value: MasterInstanceFleetLaunchSpecificationsProperty): void;
        resetLaunchSpecifications(): void;
        get launchSpecificationsInput(): MasterInstanceFleetLaunchSpecificationsProperty | undefined;
    }
    interface MasterInstanceGroupEbsConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#iops AwsCluster#iops}
        */
        readonly iops?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#size AwsCluster#size}
        */
        readonly size: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#throughput AwsCluster#throughput}
        */
        readonly throughput?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#type AwsCluster#type}
        */
        readonly type: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#volumes_per_instance AwsCluster#volumes_per_instance}
        */
        readonly volumesPerInstance?: number;
    }
    class MasterInstanceGroupEbsConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MasterInstanceGroupEbsConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MasterInstanceGroupEbsConfigProperty | cdktn.IResolvable | undefined);
        private _iops?;
        get iops(): number;
        set iops(value: number);
        resetIops(): void;
        get iopsInput(): number | undefined;
        private _size?;
        get size(): number;
        set size(value: number);
        get sizeInput(): number | undefined;
        private _throughput?;
        get throughput(): number;
        set throughput(value: number);
        resetThroughput(): void;
        get throughputInput(): number | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _volumesPerInstance?;
        get volumesPerInstance(): number;
        set volumesPerInstance(value: number);
        resetVolumesPerInstance(): void;
        get volumesPerInstanceInput(): number | undefined;
    }
    class MasterInstanceGroupEbsConfigPropertyList extends cdktn.ComplexList {
        internalValue?: MasterInstanceGroupEbsConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MasterInstanceGroupEbsConfigPropertyOutputReference;
    }
    interface MasterInstanceGroupProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#bid_price AwsCluster#bid_price}
        */
        readonly bidPrice?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#instance_count AwsCluster#instance_count}
        */
        readonly instanceCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#instance_type AwsCluster#instance_type}
        */
        readonly instanceType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#name AwsCluster#name}
        */
        readonly name?: string;
        /**
        * ebs_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#ebs_config AwsCluster#ebs_config}
        */
        readonly ebsConfig?: MasterInstanceGroupEbsConfigProperty[] | cdktn.IResolvable;
    }
    class MasterInstanceGroupPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MasterInstanceGroupProperty | undefined;
        set internalValue(value: MasterInstanceGroupProperty | undefined);
        private _bidPrice?;
        get bidPrice(): string;
        set bidPrice(value: string);
        resetBidPrice(): void;
        get bidPriceInput(): string | undefined;
        get id(): string;
        private _instanceCount?;
        get instanceCount(): number;
        set instanceCount(value: number);
        resetInstanceCount(): void;
        get instanceCountInput(): number | undefined;
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        get instanceTypeInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _ebsConfig;
        get ebsConfig(): MasterInstanceGroupEbsConfigPropertyList;
        putEbsConfig(value: MasterInstanceGroupEbsConfigProperty[] | cdktn.IResolvable): void;
        resetEbsConfig(): void;
        get ebsConfigInput(): cdktn.IResolvable | MasterInstanceGroupEbsConfigProperty[] | undefined;
    }
}
