import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsSupportedInstanceTypesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/emr_supported_instance_types#region DataAwsSupportedInstanceTypes#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/emr_supported_instance_types#release_label DataAwsSupportedInstanceTypes#release_label}
    */
    readonly releaseLabel: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/emr_supported_instance_types aws_emr_supported_instance_types}
*/
export declare class DataAwsSupportedInstanceTypes extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_emr_supported_instance_types";
    /**
    * Generates CDKTN code for importing a DataAwsSupportedInstanceTypes resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsSupportedInstanceTypes to import
    * @param importFromId The id of the existing DataAwsSupportedInstanceTypes that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/emr_supported_instance_types#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsSupportedInstanceTypes to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/emr_supported_instance_types aws_emr_supported_instance_types} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsSupportedInstanceTypesConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsSupportedInstanceTypesConfig);
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _releaseLabel?;
    get releaseLabel(): string;
    set releaseLabel(value: string);
    get releaseLabelInput(): string | undefined;
    private _supportedInstanceTypes;
    get supportedInstanceTypes(): DataAwsSupportedInstanceTypes.SupportedInstanceTypesPropertyList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsSupportedInstanceTypesSupportedInstanceTypesPropertyToTerraform(struct?: DataAwsSupportedInstanceTypes.SupportedInstanceTypesProperty): any;
export declare function dataAwsSupportedInstanceTypesSupportedInstanceTypesPropertyToHclTerraform(struct?: DataAwsSupportedInstanceTypes.SupportedInstanceTypesProperty): any;
export declare namespace DataAwsSupportedInstanceTypes {
    interface SupportedInstanceTypesProperty {
    }
    class SupportedInstanceTypesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SupportedInstanceTypesProperty | undefined;
        set internalValue(value: SupportedInstanceTypesProperty | undefined);
        get architecture(): string;
        get ebsOptimizedAvailable(): cdktn.IResolvable;
        get ebsOptimizedByDefault(): cdktn.IResolvable;
        get ebsStorageOnly(): cdktn.IResolvable;
        get instanceFamilyId(): string;
        get is64BitsOnly(): cdktn.IResolvable;
        get memoryGb(): number;
        get numberOfDisks(): number;
        get storageGb(): number;
        get type(): string;
        get vcpu(): number;
    }
    class SupportedInstanceTypesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SupportedInstanceTypesPropertyOutputReference;
    }
}
