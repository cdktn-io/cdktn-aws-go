import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsStudioSessionMappingConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_studio_session_mapping#id AwsStudioSessionMapping#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_studio_session_mapping#identity_id AwsStudioSessionMapping#identity_id}
    */
    readonly identityId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_studio_session_mapping#identity_name AwsStudioSessionMapping#identity_name}
    */
    readonly identityName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_studio_session_mapping#identity_type AwsStudioSessionMapping#identity_type}
    */
    readonly identityType: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_studio_session_mapping#region AwsStudioSessionMapping#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_studio_session_mapping#session_policy_arn AwsStudioSessionMapping#session_policy_arn}
    */
    readonly sessionPolicyArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_studio_session_mapping#studio_id AwsStudioSessionMapping#studio_id}
    */
    readonly studioId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_studio_session_mapping aws_emr_studio_session_mapping}
*/
export declare class AwsStudioSessionMapping extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_emr_studio_session_mapping";
    /**
    * Generates CDKTN code for importing a AwsStudioSessionMapping resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsStudioSessionMapping to import
    * @param importFromId The id of the existing AwsStudioSessionMapping that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_studio_session_mapping#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsStudioSessionMapping to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_studio_session_mapping aws_emr_studio_session_mapping} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsStudioSessionMappingConfig
    */
    constructor(scope: Construct, id: string, config: AwsStudioSessionMappingConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _identityId?;
    get identityId(): string;
    set identityId(value: string);
    resetIdentityId(): void;
    get identityIdInput(): string | undefined;
    private _identityName?;
    get identityName(): string;
    set identityName(value: string);
    resetIdentityName(): void;
    get identityNameInput(): string | undefined;
    private _identityType?;
    get identityType(): string;
    set identityType(value: string);
    get identityTypeInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _sessionPolicyArn?;
    get sessionPolicyArn(): string;
    set sessionPolicyArn(value: string);
    get sessionPolicyArnInput(): string | undefined;
    private _studioId?;
    get studioId(): string;
    set studioId(value: string);
    get studioIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
