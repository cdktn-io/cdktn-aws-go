import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsInstanceFleetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_instance_fleet#cluster_id AwsInstanceFleet#cluster_id}
    */
    readonly clusterId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_instance_fleet#id AwsInstanceFleet#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_instance_fleet#name AwsInstanceFleet#name}
    */
    readonly name?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_instance_fleet#region AwsInstanceFleet#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_instance_fleet#target_on_demand_capacity AwsInstanceFleet#target_on_demand_capacity}
    */
    readonly targetOnDemandCapacity?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_instance_fleet#target_spot_capacity AwsInstanceFleet#target_spot_capacity}
    */
    readonly targetSpotCapacity?: number;
    /**
    * instance_type_configs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_instance_fleet#instance_type_configs AwsInstanceFleet#instance_type_configs}
    */
    readonly instanceTypeConfigs?: AwsInstanceFleet.InstanceTypeConfigsProperty[] | cdktn.IResolvable;
    /**
    * launch_specifications block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_instance_fleet#launch_specifications AwsInstanceFleet#launch_specifications}
    */
    readonly launchSpecifications?: AwsInstanceFleet.LaunchSpecificationsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_instance_fleet aws_emr_instance_fleet}
*/
export declare class AwsInstanceFleet extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_emr_instance_fleet";
    /**
    * Generates CDKTN code for importing a AwsInstanceFleet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsInstanceFleet to import
    * @param importFromId The id of the existing AwsInstanceFleet that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_instance_fleet#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsInstanceFleet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_instance_fleet aws_emr_instance_fleet} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsInstanceFleetConfig
    */
    constructor(scope: Construct, id: string, config: AwsInstanceFleetConfig);
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    get clusterIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get provisionedOnDemandCapacity(): number;
    get provisionedSpotCapacity(): number;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _targetOnDemandCapacity?;
    get targetOnDemandCapacity(): number;
    set targetOnDemandCapacity(value: number);
    resetTargetOnDemandCapacity(): void;
    get targetOnDemandCapacityInput(): number | undefined;
    private _targetSpotCapacity?;
    get targetSpotCapacity(): number;
    set targetSpotCapacity(value: number);
    resetTargetSpotCapacity(): void;
    get targetSpotCapacityInput(): number | undefined;
    private _instanceTypeConfigs;
    get instanceTypeConfigs(): AwsInstanceFleet.InstanceTypeConfigsPropertyList;
    putInstanceTypeConfigs(value: AwsInstanceFleet.InstanceTypeConfigsProperty[] | cdktn.IResolvable): void;
    resetInstanceTypeConfigs(): void;
    get instanceTypeConfigsInput(): cdktn.IResolvable | AwsInstanceFleet.InstanceTypeConfigsProperty[] | undefined;
    private _launchSpecifications;
    get launchSpecifications(): AwsInstanceFleet.LaunchSpecificationsPropertyOutputReference;
    putLaunchSpecifications(value: AwsInstanceFleet.LaunchSpecificationsProperty): void;
    resetLaunchSpecifications(): void;
    get launchSpecificationsInput(): AwsInstanceFleet.LaunchSpecificationsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsInstanceFleetConfigurationsPropertyToTerraform(struct?: AwsInstanceFleet.ConfigurationsProperty | cdktn.IResolvable): any;
export declare function awsInstanceFleetConfigurationsPropertyToHclTerraform(struct?: AwsInstanceFleet.ConfigurationsProperty | cdktn.IResolvable): any;
export declare function awsInstanceFleetEbsConfigPropertyToTerraform(struct?: AwsInstanceFleet.EbsConfigProperty | cdktn.IResolvable): any;
export declare function awsInstanceFleetEbsConfigPropertyToHclTerraform(struct?: AwsInstanceFleet.EbsConfigProperty | cdktn.IResolvable): any;
export declare function awsInstanceFleetInstanceTypeConfigsPropertyToTerraform(struct?: AwsInstanceFleet.InstanceTypeConfigsProperty | cdktn.IResolvable): any;
export declare function awsInstanceFleetInstanceTypeConfigsPropertyToHclTerraform(struct?: AwsInstanceFleet.InstanceTypeConfigsProperty | cdktn.IResolvable): any;
export declare function awsInstanceFleetOnDemandSpecificationPropertyToTerraform(struct?: AwsInstanceFleet.OnDemandSpecificationProperty | cdktn.IResolvable): any;
export declare function awsInstanceFleetOnDemandSpecificationPropertyToHclTerraform(struct?: AwsInstanceFleet.OnDemandSpecificationProperty | cdktn.IResolvable): any;
export declare function awsInstanceFleetSpotSpecificationPropertyToTerraform(struct?: AwsInstanceFleet.SpotSpecificationProperty | cdktn.IResolvable): any;
export declare function awsInstanceFleetSpotSpecificationPropertyToHclTerraform(struct?: AwsInstanceFleet.SpotSpecificationProperty | cdktn.IResolvable): any;
export declare function awsInstanceFleetLaunchSpecificationsPropertyToTerraform(struct?: AwsInstanceFleet.LaunchSpecificationsPropertyOutputReference | AwsInstanceFleet.LaunchSpecificationsProperty): any;
export declare function awsInstanceFleetLaunchSpecificationsPropertyToHclTerraform(struct?: AwsInstanceFleet.LaunchSpecificationsPropertyOutputReference | AwsInstanceFleet.LaunchSpecificationsProperty): any;
export declare namespace AwsInstanceFleet {
    interface ConfigurationsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_instance_fleet#classification AwsInstanceFleet#classification}
        */
        readonly classification?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_instance_fleet#properties AwsInstanceFleet#properties}
        */
        readonly properties?: {
            [key: string]: string;
        };
    }
    class ConfigurationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConfigurationsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConfigurationsProperty | cdktn.IResolvable | undefined);
        private _classification?;
        get classification(): string;
        set classification(value: string);
        resetClassification(): void;
        get classificationInput(): string | undefined;
        private _properties?;
        get properties(): {
            [key: string]: string;
        };
        set properties(value: {
            [key: string]: string;
        });
        resetProperties(): void;
        get propertiesInput(): {
            [key: string]: string;
        } | undefined;
    }
    class ConfigurationsPropertyList extends cdktn.ComplexList {
        internalValue?: ConfigurationsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConfigurationsPropertyOutputReference;
    }
    interface EbsConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_instance_fleet#iops AwsInstanceFleet#iops}
        */
        readonly iops?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_instance_fleet#size AwsInstanceFleet#size}
        */
        readonly size: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_instance_fleet#type AwsInstanceFleet#type}
        */
        readonly type: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_instance_fleet#volumes_per_instance AwsInstanceFleet#volumes_per_instance}
        */
        readonly volumesPerInstance?: number;
    }
    class EbsConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EbsConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EbsConfigProperty | cdktn.IResolvable | undefined);
        private _iops?;
        get iops(): number;
        set iops(value: number);
        resetIops(): void;
        get iopsInput(): number | undefined;
        private _size?;
        get size(): number;
        set size(value: number);
        get sizeInput(): number | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _volumesPerInstance?;
        get volumesPerInstance(): number;
        set volumesPerInstance(value: number);
        resetVolumesPerInstance(): void;
        get volumesPerInstanceInput(): number | undefined;
    }
    class EbsConfigPropertyList extends cdktn.ComplexList {
        internalValue?: EbsConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EbsConfigPropertyOutputReference;
    }
    interface InstanceTypeConfigsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_instance_fleet#bid_price AwsInstanceFleet#bid_price}
        */
        readonly bidPrice?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_instance_fleet#bid_price_as_percentage_of_on_demand_price AwsInstanceFleet#bid_price_as_percentage_of_on_demand_price}
        */
        readonly bidPriceAsPercentageOfOnDemandPrice?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_instance_fleet#instance_type AwsInstanceFleet#instance_type}
        */
        readonly instanceType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_instance_fleet#weighted_capacity AwsInstanceFleet#weighted_capacity}
        */
        readonly weightedCapacity?: number;
        /**
        * configurations block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_instance_fleet#configurations AwsInstanceFleet#configurations}
        */
        readonly configurations?: ConfigurationsProperty[] | cdktn.IResolvable;
        /**
        * ebs_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_instance_fleet#ebs_config AwsInstanceFleet#ebs_config}
        */
        readonly ebsConfig?: EbsConfigProperty[] | cdktn.IResolvable;
    }
    class InstanceTypeConfigsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InstanceTypeConfigsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InstanceTypeConfigsProperty | cdktn.IResolvable | undefined);
        private _bidPrice?;
        get bidPrice(): string;
        set bidPrice(value: string);
        resetBidPrice(): void;
        get bidPriceInput(): string | undefined;
        private _bidPriceAsPercentageOfOnDemandPrice?;
        get bidPriceAsPercentageOfOnDemandPrice(): number;
        set bidPriceAsPercentageOfOnDemandPrice(value: number);
        resetBidPriceAsPercentageOfOnDemandPrice(): void;
        get bidPriceAsPercentageOfOnDemandPriceInput(): number | undefined;
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        get instanceTypeInput(): string | undefined;
        private _weightedCapacity?;
        get weightedCapacity(): number;
        set weightedCapacity(value: number);
        resetWeightedCapacity(): void;
        get weightedCapacityInput(): number | undefined;
        private _configurations;
        get configurations(): ConfigurationsPropertyList;
        putConfigurations(value: ConfigurationsProperty[] | cdktn.IResolvable): void;
        resetConfigurations(): void;
        get configurationsInput(): cdktn.IResolvable | ConfigurationsProperty[] | undefined;
        private _ebsConfig;
        get ebsConfig(): EbsConfigPropertyList;
        putEbsConfig(value: EbsConfigProperty[] | cdktn.IResolvable): void;
        resetEbsConfig(): void;
        get ebsConfigInput(): cdktn.IResolvable | EbsConfigProperty[] | undefined;
    }
    class InstanceTypeConfigsPropertyList extends cdktn.ComplexList {
        internalValue?: InstanceTypeConfigsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InstanceTypeConfigsPropertyOutputReference;
    }
    interface OnDemandSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_instance_fleet#allocation_strategy AwsInstanceFleet#allocation_strategy}
        */
        readonly allocationStrategy: string;
    }
    class OnDemandSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OnDemandSpecificationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OnDemandSpecificationProperty | cdktn.IResolvable | undefined);
        private _allocationStrategy?;
        get allocationStrategy(): string;
        set allocationStrategy(value: string);
        get allocationStrategyInput(): string | undefined;
    }
    class OnDemandSpecificationPropertyList extends cdktn.ComplexList {
        internalValue?: OnDemandSpecificationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OnDemandSpecificationPropertyOutputReference;
    }
    interface SpotSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_instance_fleet#allocation_strategy AwsInstanceFleet#allocation_strategy}
        */
        readonly allocationStrategy: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_instance_fleet#block_duration_minutes AwsInstanceFleet#block_duration_minutes}
        */
        readonly blockDurationMinutes?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_instance_fleet#timeout_action AwsInstanceFleet#timeout_action}
        */
        readonly timeoutAction: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_instance_fleet#timeout_duration_minutes AwsInstanceFleet#timeout_duration_minutes}
        */
        readonly timeoutDurationMinutes: number;
    }
    class SpotSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpotSpecificationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SpotSpecificationProperty | cdktn.IResolvable | undefined);
        private _allocationStrategy?;
        get allocationStrategy(): string;
        set allocationStrategy(value: string);
        get allocationStrategyInput(): string | undefined;
        private _blockDurationMinutes?;
        get blockDurationMinutes(): number;
        set blockDurationMinutes(value: number);
        resetBlockDurationMinutes(): void;
        get blockDurationMinutesInput(): number | undefined;
        private _timeoutAction?;
        get timeoutAction(): string;
        set timeoutAction(value: string);
        get timeoutActionInput(): string | undefined;
        private _timeoutDurationMinutes?;
        get timeoutDurationMinutes(): number;
        set timeoutDurationMinutes(value: number);
        get timeoutDurationMinutesInput(): number | undefined;
    }
    class SpotSpecificationPropertyList extends cdktn.ComplexList {
        internalValue?: SpotSpecificationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpotSpecificationPropertyOutputReference;
    }
    interface LaunchSpecificationsProperty {
        /**
        * on_demand_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_instance_fleet#on_demand_specification AwsInstanceFleet#on_demand_specification}
        */
        readonly onDemandSpecification?: OnDemandSpecificationProperty[] | cdktn.IResolvable;
        /**
        * spot_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_instance_fleet#spot_specification AwsInstanceFleet#spot_specification}
        */
        readonly spotSpecification?: SpotSpecificationProperty[] | cdktn.IResolvable;
    }
    class LaunchSpecificationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LaunchSpecificationsProperty | undefined;
        set internalValue(value: LaunchSpecificationsProperty | undefined);
        private _onDemandSpecification;
        get onDemandSpecification(): OnDemandSpecificationPropertyList;
        putOnDemandSpecification(value: OnDemandSpecificationProperty[] | cdktn.IResolvable): void;
        resetOnDemandSpecification(): void;
        get onDemandSpecificationInput(): cdktn.IResolvable | OnDemandSpecificationProperty[] | undefined;
        private _spotSpecification;
        get spotSpecification(): SpotSpecificationPropertyList;
        putSpotSpecification(value: SpotSpecificationProperty[] | cdktn.IResolvable): void;
        resetSpotSpecification(): void;
        get spotSpecificationInput(): cdktn.IResolvable | SpotSpecificationProperty[] | undefined;
    }
}
