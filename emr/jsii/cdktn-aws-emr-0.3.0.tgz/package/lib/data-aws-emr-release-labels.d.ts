import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsReleaseLabelsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/emr_release_labels#id DataAwsReleaseLabels#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/emr_release_labels#region DataAwsReleaseLabels#region}
    */
    readonly region?: string;
    /**
    * filters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/emr_release_labels#filters DataAwsReleaseLabels#filters}
    */
    readonly filters?: DataAwsReleaseLabels.FiltersProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/emr_release_labels aws_emr_release_labels}
*/
export declare class DataAwsReleaseLabels extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_emr_release_labels";
    /**
    * Generates CDKTN code for importing a DataAwsReleaseLabels resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsReleaseLabels to import
    * @param importFromId The id of the existing DataAwsReleaseLabels that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/emr_release_labels#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsReleaseLabels to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/emr_release_labels aws_emr_release_labels} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsReleaseLabelsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsReleaseLabelsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get releaseLabels(): string[];
    private _filters;
    get filters(): DataAwsReleaseLabels.FiltersPropertyOutputReference;
    putFilters(value: DataAwsReleaseLabels.FiltersProperty): void;
    resetFilters(): void;
    get filtersInput(): DataAwsReleaseLabels.FiltersProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsReleaseLabelsFiltersPropertyToTerraform(struct?: DataAwsReleaseLabels.FiltersPropertyOutputReference | DataAwsReleaseLabels.FiltersProperty): any;
export declare function dataAwsReleaseLabelsFiltersPropertyToHclTerraform(struct?: DataAwsReleaseLabels.FiltersPropertyOutputReference | DataAwsReleaseLabels.FiltersProperty): any;
export declare namespace DataAwsReleaseLabels {
    interface FiltersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/emr_release_labels#application DataAwsReleaseLabels#application}
        */
        readonly application?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/emr_release_labels#prefix DataAwsReleaseLabels#prefix}
        */
        readonly prefix?: string;
    }
    class FiltersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FiltersProperty | undefined;
        set internalValue(value: FiltersProperty | undefined);
        private _application?;
        get application(): string;
        set application(value: string);
        resetApplication(): void;
        get applicationInput(): string | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
    }
}
