import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsImagesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecrpublic_images#region DataAwsImages#region}
    */
    readonly region?: string;
    /**
    * AWS account ID associated with the public registry that contains the repository. If not specified, the default public registry is assumed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecrpublic_images#registry_id DataAwsImages#registry_id}
    */
    readonly registryId?: string;
    /**
    * Name of the public repository.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecrpublic_images#repository_name DataAwsImages#repository_name}
    */
    readonly repositoryName: string;
    /**
    * image_ids block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecrpublic_images#image_ids DataAwsImages#image_ids}
    */
    readonly imageIds?: DataAwsImages.ImageIdsProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecrpublic_images aws_ecrpublic_images}
*/
export declare class DataAwsImages extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_ecrpublic_images";
    /**
    * Generates CDKTN code for importing a DataAwsImages resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsImages to import
    * @param importFromId The id of the existing DataAwsImages that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecrpublic_images#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsImages to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecrpublic_images aws_ecrpublic_images} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsImagesConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsImagesConfig);
    private _images;
    get images(): DataAwsImages.ImagesPropertyList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _registryId?;
    get registryId(): string;
    set registryId(value: string);
    resetRegistryId(): void;
    get registryIdInput(): string | undefined;
    private _repositoryName?;
    get repositoryName(): string;
    set repositoryName(value: string);
    get repositoryNameInput(): string | undefined;
    private _imageIds;
    get imageIds(): DataAwsImages.ImageIdsPropertyList;
    putImageIds(value: DataAwsImages.ImageIdsProperty[] | cdktn.IResolvable): void;
    resetImageIds(): void;
    get imageIdsInput(): cdktn.IResolvable | DataAwsImages.ImageIdsProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsImagesImagesPropertyToTerraform(struct?: DataAwsImages.ImagesProperty): any;
export declare function dataAwsImagesImagesPropertyToHclTerraform(struct?: DataAwsImages.ImagesProperty): any;
export declare function dataAwsImagesImageIdsPropertyToTerraform(struct?: DataAwsImages.ImageIdsProperty | cdktn.IResolvable): any;
export declare function dataAwsImagesImageIdsPropertyToHclTerraform(struct?: DataAwsImages.ImageIdsProperty | cdktn.IResolvable): any;
export declare namespace DataAwsImages {
    interface ImagesProperty {
    }
    class ImagesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ImagesProperty | undefined;
        set internalValue(value: ImagesProperty | undefined);
        get artifactMediaType(): string;
        get imageDigest(): string;
        get imageManifestMediaType(): string;
        get imagePushedAt(): string;
        get imageSizeInBytes(): number;
        get imageTags(): string[];
        get registryId(): string;
        get repositoryName(): string;
    }
    class ImagesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ImagesPropertyOutputReference;
    }
    interface ImageIdsProperty {
        /**
        * Image digest.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecrpublic_images#image_digest DataAwsImages#image_digest}
        */
        readonly imageDigest?: string;
        /**
        * Image tag.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecrpublic_images#image_tag DataAwsImages#image_tag}
        */
        readonly imageTag?: string;
    }
    class ImageIdsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ImageIdsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ImageIdsProperty | cdktn.IResolvable | undefined);
        private _imageDigest?;
        get imageDigest(): string;
        set imageDigest(value: string);
        resetImageDigest(): void;
        get imageDigestInput(): string | undefined;
        private _imageTag?;
        get imageTag(): string;
        set imageTag(value: string);
        resetImageTag(): void;
        get imageTagInput(): string | undefined;
    }
    class ImageIdsPropertyList extends cdktn.ComplexList {
        internalValue?: ImageIdsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ImageIdsPropertyOutputReference;
    }
}
