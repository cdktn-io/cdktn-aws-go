export * from './data-aws-pricing-product';
