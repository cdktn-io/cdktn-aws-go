import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfProductConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/pricing_product#id DataTfProduct#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/pricing_product#service_code DataTfProduct#service_code}
    */
    readonly serviceCode: string;
    /**
    * filters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/pricing_product#filters DataTfProduct#filters}
    */
    readonly filters: DataTfProduct.FiltersProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/pricing_product aws_pricing_product}
*/
export declare class DataTfProduct extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_pricing_product";
    /**
    * Generates CDKTN code for importing a DataTfProduct resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfProduct to import
    * @param importFromId The id of the existing DataTfProduct that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/pricing_product#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfProduct to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/pricing_product aws_pricing_product} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfProductConfig
    */
    constructor(scope: Construct, id: string, config: DataTfProductConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get result(): string;
    private _serviceCode?;
    get serviceCode(): string;
    set serviceCode(value: string);
    get serviceCodeInput(): string | undefined;
    private _filters;
    get filters(): DataTfProduct.FiltersPropertyList;
    putFilters(value: DataTfProduct.FiltersProperty[] | cdktn.IResolvable): void;
    get filtersInput(): cdktn.IResolvable | DataTfProduct.FiltersProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfProductFiltersPropertyToTerraform(struct?: DataTfProduct.FiltersProperty | cdktn.IResolvable): any;
export declare function dataTfProductFiltersPropertyToHclTerraform(struct?: DataTfProduct.FiltersProperty | cdktn.IResolvable): any;
export declare namespace DataTfProduct {
    interface FiltersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/pricing_product#field DataTfProduct#field}
        */
        readonly field: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/pricing_product#value DataTfProduct#value}
        */
        readonly value: string;
    }
    class FiltersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FiltersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FiltersProperty | cdktn.IResolvable | undefined);
        private _field?;
        get field(): string;
        set field(value: string);
        get fieldInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class FiltersPropertyList extends cdktn.ComplexList {
        internalValue?: FiltersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FiltersPropertyOutputReference;
    }
}
