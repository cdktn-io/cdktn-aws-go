import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSesDomainIdentityVerificationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_domain_identity_verification#domain AwsSesDomainIdentityVerification#domain}
    */
    readonly domain: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_domain_identity_verification#id AwsSesDomainIdentityVerification#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_domain_identity_verification#region AwsSesDomainIdentityVerification#region}
    */
    readonly region?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_domain_identity_verification#timeouts AwsSesDomainIdentityVerification#timeouts}
    */
    readonly timeouts?: AwsSesDomainIdentityVerification.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_domain_identity_verification aws_ses_domain_identity_verification}
*/
export declare class AwsSesDomainIdentityVerification extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ses_domain_identity_verification";
    /**
    * Generates CDKTN code for importing a AwsSesDomainIdentityVerification resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSesDomainIdentityVerification to import
    * @param importFromId The id of the existing AwsSesDomainIdentityVerification that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_domain_identity_verification#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSesDomainIdentityVerification to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_domain_identity_verification aws_ses_domain_identity_verification} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSesDomainIdentityVerificationConfig
    */
    constructor(scope: Construct, id: string, config: AwsSesDomainIdentityVerificationConfig);
    get arn(): string;
    private _domain?;
    get domain(): string;
    set domain(value: string);
    get domainInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _timeouts;
    get timeouts(): AwsSesDomainIdentityVerification.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsSesDomainIdentityVerification.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsSesDomainIdentityVerification.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsSesDomainIdentityVerificationTimeoutsPropertyToTerraform(struct?: AwsSesDomainIdentityVerification.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsSesDomainIdentityVerificationTimeoutsPropertyToHclTerraform(struct?: AwsSesDomainIdentityVerification.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsSesDomainIdentityVerification {
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_domain_identity_verification#create AwsSesDomainIdentityVerification#create}
        */
        readonly create?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
    }
}
