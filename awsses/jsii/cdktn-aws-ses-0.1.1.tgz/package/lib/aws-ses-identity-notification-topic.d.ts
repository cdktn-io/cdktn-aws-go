import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSesIdentityNotificationTopicConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_identity_notification_topic#id AwsSesIdentityNotificationTopic#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_identity_notification_topic#identity AwsSesIdentityNotificationTopic#identity}
    */
    readonly identity: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_identity_notification_topic#include_original_headers AwsSesIdentityNotificationTopic#include_original_headers}
    */
    readonly includeOriginalHeaders?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_identity_notification_topic#notification_type AwsSesIdentityNotificationTopic#notification_type}
    */
    readonly notificationType: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_identity_notification_topic#region AwsSesIdentityNotificationTopic#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_identity_notification_topic#topic_arn AwsSesIdentityNotificationTopic#topic_arn}
    */
    readonly topicArn?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_identity_notification_topic aws_ses_identity_notification_topic}
*/
export declare class AwsSesIdentityNotificationTopic extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ses_identity_notification_topic";
    /**
    * Generates CDKTN code for importing a AwsSesIdentityNotificationTopic resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSesIdentityNotificationTopic to import
    * @param importFromId The id of the existing AwsSesIdentityNotificationTopic that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_identity_notification_topic#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSesIdentityNotificationTopic to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_identity_notification_topic aws_ses_identity_notification_topic} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSesIdentityNotificationTopicConfig
    */
    constructor(scope: Construct, id: string, config: AwsSesIdentityNotificationTopicConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _identity?;
    get identity(): string;
    set identity(value: string);
    get identityInput(): string | undefined;
    private _includeOriginalHeaders?;
    get includeOriginalHeaders(): boolean | cdktn.IResolvable;
    set includeOriginalHeaders(value: boolean | cdktn.IResolvable);
    resetIncludeOriginalHeaders(): void;
    get includeOriginalHeadersInput(): boolean | cdktn.IResolvable | undefined;
    private _notificationType?;
    get notificationType(): string;
    set notificationType(value: string);
    get notificationTypeInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _topicArn?;
    get topicArn(): string;
    set topicArn(value: string);
    resetTopicArn(): void;
    get topicArnInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
