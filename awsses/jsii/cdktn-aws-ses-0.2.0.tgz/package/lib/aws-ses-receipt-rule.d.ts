import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfReceiptRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#after TfReceiptRule#after}
    */
    readonly after?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#enabled TfReceiptRule#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#id TfReceiptRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#name TfReceiptRule#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#recipients TfReceiptRule#recipients}
    */
    readonly recipients?: string[];
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#region TfReceiptRule#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#rule_set_name TfReceiptRule#rule_set_name}
    */
    readonly ruleSetName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#scan_enabled TfReceiptRule#scan_enabled}
    */
    readonly scanEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#tls_policy TfReceiptRule#tls_policy}
    */
    readonly tlsPolicy?: string;
    /**
    * add_header_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#add_header_action TfReceiptRule#add_header_action}
    */
    readonly addHeaderAction?: TfReceiptRule.AddHeaderActionProperty[] | cdktn.IResolvable;
    /**
    * bounce_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#bounce_action TfReceiptRule#bounce_action}
    */
    readonly bounceAction?: TfReceiptRule.BounceActionProperty[] | cdktn.IResolvable;
    /**
    * lambda_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#lambda_action TfReceiptRule#lambda_action}
    */
    readonly lambdaAction?: TfReceiptRule.LambdaActionProperty[] | cdktn.IResolvable;
    /**
    * s3_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#s3_action TfReceiptRule#s3_action}
    */
    readonly s3Action?: TfReceiptRule.S3ActionProperty[] | cdktn.IResolvable;
    /**
    * sns_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#sns_action TfReceiptRule#sns_action}
    */
    readonly snsAction?: TfReceiptRule.SnsActionProperty[] | cdktn.IResolvable;
    /**
    * stop_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#stop_action TfReceiptRule#stop_action}
    */
    readonly stopAction?: TfReceiptRule.StopActionProperty[] | cdktn.IResolvable;
    /**
    * workmail_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#workmail_action TfReceiptRule#workmail_action}
    */
    readonly workmailAction?: TfReceiptRule.WorkmailActionProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule aws_ses_receipt_rule}
*/
export declare class TfReceiptRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ses_receipt_rule";
    /**
    * Generates CDKTN code for importing a TfReceiptRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfReceiptRule to import
    * @param importFromId The id of the existing TfReceiptRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfReceiptRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule aws_ses_receipt_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfReceiptRuleConfig
    */
    constructor(scope: Construct, id: string, config: TfReceiptRuleConfig);
    private _after?;
    get after(): string;
    set after(value: string);
    resetAfter(): void;
    get afterInput(): string | undefined;
    get arn(): string;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _recipients?;
    get recipients(): string[];
    set recipients(value: string[]);
    resetRecipients(): void;
    get recipientsInput(): string[] | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _ruleSetName?;
    get ruleSetName(): string;
    set ruleSetName(value: string);
    get ruleSetNameInput(): string | undefined;
    private _scanEnabled?;
    get scanEnabled(): boolean | cdktn.IResolvable;
    set scanEnabled(value: boolean | cdktn.IResolvable);
    resetScanEnabled(): void;
    get scanEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _tlsPolicy?;
    get tlsPolicy(): string;
    set tlsPolicy(value: string);
    resetTlsPolicy(): void;
    get tlsPolicyInput(): string | undefined;
    private _addHeaderAction;
    get addHeaderAction(): TfReceiptRule.AddHeaderActionPropertyList;
    putAddHeaderAction(value: TfReceiptRule.AddHeaderActionProperty[] | cdktn.IResolvable): void;
    resetAddHeaderAction(): void;
    get addHeaderActionInput(): cdktn.IResolvable | TfReceiptRule.AddHeaderActionProperty[] | undefined;
    private _bounceAction;
    get bounceAction(): TfReceiptRule.BounceActionPropertyList;
    putBounceAction(value: TfReceiptRule.BounceActionProperty[] | cdktn.IResolvable): void;
    resetBounceAction(): void;
    get bounceActionInput(): cdktn.IResolvable | TfReceiptRule.BounceActionProperty[] | undefined;
    private _lambdaAction;
    get lambdaAction(): TfReceiptRule.LambdaActionPropertyList;
    putLambdaAction(value: TfReceiptRule.LambdaActionProperty[] | cdktn.IResolvable): void;
    resetLambdaAction(): void;
    get lambdaActionInput(): cdktn.IResolvable | TfReceiptRule.LambdaActionProperty[] | undefined;
    private _s3Action;
    get s3Action(): TfReceiptRule.S3ActionPropertyList;
    putS3Action(value: TfReceiptRule.S3ActionProperty[] | cdktn.IResolvable): void;
    resetS3Action(): void;
    get s3ActionInput(): cdktn.IResolvable | TfReceiptRule.S3ActionProperty[] | undefined;
    private _snsAction;
    get snsAction(): TfReceiptRule.SnsActionPropertyList;
    putSnsAction(value: TfReceiptRule.SnsActionProperty[] | cdktn.IResolvable): void;
    resetSnsAction(): void;
    get snsActionInput(): cdktn.IResolvable | TfReceiptRule.SnsActionProperty[] | undefined;
    private _stopAction;
    get stopAction(): TfReceiptRule.StopActionPropertyList;
    putStopAction(value: TfReceiptRule.StopActionProperty[] | cdktn.IResolvable): void;
    resetStopAction(): void;
    get stopActionInput(): cdktn.IResolvable | TfReceiptRule.StopActionProperty[] | undefined;
    private _workmailAction;
    get workmailAction(): TfReceiptRule.WorkmailActionPropertyList;
    putWorkmailAction(value: TfReceiptRule.WorkmailActionProperty[] | cdktn.IResolvable): void;
    resetWorkmailAction(): void;
    get workmailActionInput(): cdktn.IResolvable | TfReceiptRule.WorkmailActionProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfReceiptRuleAddHeaderActionPropertyToTerraform(struct?: TfReceiptRule.AddHeaderActionProperty | cdktn.IResolvable): any;
export declare function tfReceiptRuleAddHeaderActionPropertyToHclTerraform(struct?: TfReceiptRule.AddHeaderActionProperty | cdktn.IResolvable): any;
export declare function tfReceiptRuleBounceActionPropertyToTerraform(struct?: TfReceiptRule.BounceActionProperty | cdktn.IResolvable): any;
export declare function tfReceiptRuleBounceActionPropertyToHclTerraform(struct?: TfReceiptRule.BounceActionProperty | cdktn.IResolvable): any;
export declare function tfReceiptRuleLambdaActionPropertyToTerraform(struct?: TfReceiptRule.LambdaActionProperty | cdktn.IResolvable): any;
export declare function tfReceiptRuleLambdaActionPropertyToHclTerraform(struct?: TfReceiptRule.LambdaActionProperty | cdktn.IResolvable): any;
export declare function tfReceiptRuleS3ActionPropertyToTerraform(struct?: TfReceiptRule.S3ActionProperty | cdktn.IResolvable): any;
export declare function tfReceiptRuleS3ActionPropertyToHclTerraform(struct?: TfReceiptRule.S3ActionProperty | cdktn.IResolvable): any;
export declare function tfReceiptRuleSnsActionPropertyToTerraform(struct?: TfReceiptRule.SnsActionProperty | cdktn.IResolvable): any;
export declare function tfReceiptRuleSnsActionPropertyToHclTerraform(struct?: TfReceiptRule.SnsActionProperty | cdktn.IResolvable): any;
export declare function tfReceiptRuleStopActionPropertyToTerraform(struct?: TfReceiptRule.StopActionProperty | cdktn.IResolvable): any;
export declare function tfReceiptRuleStopActionPropertyToHclTerraform(struct?: TfReceiptRule.StopActionProperty | cdktn.IResolvable): any;
export declare function tfReceiptRuleWorkmailActionPropertyToTerraform(struct?: TfReceiptRule.WorkmailActionProperty | cdktn.IResolvable): any;
export declare function tfReceiptRuleWorkmailActionPropertyToHclTerraform(struct?: TfReceiptRule.WorkmailActionProperty | cdktn.IResolvable): any;
export declare namespace TfReceiptRule {
    interface AddHeaderActionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#header_name TfReceiptRule#header_name}
        */
        readonly headerName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#header_value TfReceiptRule#header_value}
        */
        readonly headerValue: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#position TfReceiptRule#position}
        */
        readonly position: number;
    }
    class AddHeaderActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AddHeaderActionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AddHeaderActionProperty | cdktn.IResolvable | undefined);
        private _headerName?;
        get headerName(): string;
        set headerName(value: string);
        get headerNameInput(): string | undefined;
        private _headerValue?;
        get headerValue(): string;
        set headerValue(value: string);
        get headerValueInput(): string | undefined;
        private _position?;
        get position(): number;
        set position(value: number);
        get positionInput(): number | undefined;
    }
    class AddHeaderActionPropertyList extends cdktn.ComplexList {
        internalValue?: AddHeaderActionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AddHeaderActionPropertyOutputReference;
    }
    interface BounceActionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#message TfReceiptRule#message}
        */
        readonly message: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#position TfReceiptRule#position}
        */
        readonly position: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#sender TfReceiptRule#sender}
        */
        readonly sender: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#smtp_reply_code TfReceiptRule#smtp_reply_code}
        */
        readonly smtpReplyCode: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#status_code TfReceiptRule#status_code}
        */
        readonly statusCode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#topic_arn TfReceiptRule#topic_arn}
        */
        readonly topicArn?: string;
    }
    class BounceActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BounceActionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: BounceActionProperty | cdktn.IResolvable | undefined);
        private _message?;
        get message(): string;
        set message(value: string);
        get messageInput(): string | undefined;
        private _position?;
        get position(): number;
        set position(value: number);
        get positionInput(): number | undefined;
        private _sender?;
        get sender(): string;
        set sender(value: string);
        get senderInput(): string | undefined;
        private _smtpReplyCode?;
        get smtpReplyCode(): string;
        set smtpReplyCode(value: string);
        get smtpReplyCodeInput(): string | undefined;
        private _statusCode?;
        get statusCode(): string;
        set statusCode(value: string);
        resetStatusCode(): void;
        get statusCodeInput(): string | undefined;
        private _topicArn?;
        get topicArn(): string;
        set topicArn(value: string);
        resetTopicArn(): void;
        get topicArnInput(): string | undefined;
    }
    class BounceActionPropertyList extends cdktn.ComplexList {
        internalValue?: BounceActionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BounceActionPropertyOutputReference;
    }
    interface LambdaActionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#function_arn TfReceiptRule#function_arn}
        */
        readonly functionArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#invocation_type TfReceiptRule#invocation_type}
        */
        readonly invocationType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#position TfReceiptRule#position}
        */
        readonly position: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#topic_arn TfReceiptRule#topic_arn}
        */
        readonly topicArn?: string;
    }
    class LambdaActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LambdaActionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LambdaActionProperty | cdktn.IResolvable | undefined);
        private _functionArn?;
        get functionArn(): string;
        set functionArn(value: string);
        get functionArnInput(): string | undefined;
        private _invocationType?;
        get invocationType(): string;
        set invocationType(value: string);
        resetInvocationType(): void;
        get invocationTypeInput(): string | undefined;
        private _position?;
        get position(): number;
        set position(value: number);
        get positionInput(): number | undefined;
        private _topicArn?;
        get topicArn(): string;
        set topicArn(value: string);
        resetTopicArn(): void;
        get topicArnInput(): string | undefined;
    }
    class LambdaActionPropertyList extends cdktn.ComplexList {
        internalValue?: LambdaActionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LambdaActionPropertyOutputReference;
    }
    interface S3ActionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#bucket_name TfReceiptRule#bucket_name}
        */
        readonly bucketName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#iam_role_arn TfReceiptRule#iam_role_arn}
        */
        readonly iamRoleArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#kms_key_arn TfReceiptRule#kms_key_arn}
        */
        readonly kmsKeyArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#object_key_prefix TfReceiptRule#object_key_prefix}
        */
        readonly objectKeyPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#position TfReceiptRule#position}
        */
        readonly position: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#topic_arn TfReceiptRule#topic_arn}
        */
        readonly topicArn?: string;
    }
    class S3ActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3ActionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: S3ActionProperty | cdktn.IResolvable | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        get bucketNameInput(): string | undefined;
        private _iamRoleArn?;
        get iamRoleArn(): string;
        set iamRoleArn(value: string);
        resetIamRoleArn(): void;
        get iamRoleArnInput(): string | undefined;
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        resetKmsKeyArn(): void;
        get kmsKeyArnInput(): string | undefined;
        private _objectKeyPrefix?;
        get objectKeyPrefix(): string;
        set objectKeyPrefix(value: string);
        resetObjectKeyPrefix(): void;
        get objectKeyPrefixInput(): string | undefined;
        private _position?;
        get position(): number;
        set position(value: number);
        get positionInput(): number | undefined;
        private _topicArn?;
        get topicArn(): string;
        set topicArn(value: string);
        resetTopicArn(): void;
        get topicArnInput(): string | undefined;
    }
    class S3ActionPropertyList extends cdktn.ComplexList {
        internalValue?: S3ActionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3ActionPropertyOutputReference;
    }
    interface SnsActionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#encoding TfReceiptRule#encoding}
        */
        readonly encoding?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#position TfReceiptRule#position}
        */
        readonly position: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#topic_arn TfReceiptRule#topic_arn}
        */
        readonly topicArn: string;
    }
    class SnsActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SnsActionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SnsActionProperty | cdktn.IResolvable | undefined);
        private _encoding?;
        get encoding(): string;
        set encoding(value: string);
        resetEncoding(): void;
        get encodingInput(): string | undefined;
        private _position?;
        get position(): number;
        set position(value: number);
        get positionInput(): number | undefined;
        private _topicArn?;
        get topicArn(): string;
        set topicArn(value: string);
        get topicArnInput(): string | undefined;
    }
    class SnsActionPropertyList extends cdktn.ComplexList {
        internalValue?: SnsActionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SnsActionPropertyOutputReference;
    }
    interface StopActionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#position TfReceiptRule#position}
        */
        readonly position: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#scope TfReceiptRule#scope}
        */
        readonly scope: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#topic_arn TfReceiptRule#topic_arn}
        */
        readonly topicArn?: string;
    }
    class StopActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StopActionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StopActionProperty | cdktn.IResolvable | undefined);
        private _position?;
        get position(): number;
        set position(value: number);
        get positionInput(): number | undefined;
        private _scope?;
        get scope(): string;
        set scope(value: string);
        get scopeInput(): string | undefined;
        private _topicArn?;
        get topicArn(): string;
        set topicArn(value: string);
        resetTopicArn(): void;
        get topicArnInput(): string | undefined;
    }
    class StopActionPropertyList extends cdktn.ComplexList {
        internalValue?: StopActionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StopActionPropertyOutputReference;
    }
    interface WorkmailActionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#organization_arn TfReceiptRule#organization_arn}
        */
        readonly organizationArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#position TfReceiptRule#position}
        */
        readonly position: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#topic_arn TfReceiptRule#topic_arn}
        */
        readonly topicArn?: string;
    }
    class WorkmailActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkmailActionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkmailActionProperty | cdktn.IResolvable | undefined);
        private _organizationArn?;
        get organizationArn(): string;
        set organizationArn(value: string);
        get organizationArnInput(): string | undefined;
        private _position?;
        get position(): number;
        set position(value: number);
        get positionInput(): number | undefined;
        private _topicArn?;
        get topicArn(): string;
        set topicArn(value: string);
        resetTopicArn(): void;
        get topicArnInput(): string | undefined;
    }
    class WorkmailActionPropertyList extends cdktn.ComplexList {
        internalValue?: WorkmailActionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkmailActionPropertyOutputReference;
    }
}
