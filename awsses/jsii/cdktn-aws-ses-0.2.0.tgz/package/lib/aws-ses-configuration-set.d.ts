import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfConfigurationSetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_configuration_set#id TfConfigurationSet#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_configuration_set#name TfConfigurationSet#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_configuration_set#region TfConfigurationSet#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_configuration_set#reputation_metrics_enabled TfConfigurationSet#reputation_metrics_enabled}
    */
    readonly reputationMetricsEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_configuration_set#sending_enabled TfConfigurationSet#sending_enabled}
    */
    readonly sendingEnabled?: boolean | cdktn.IResolvable;
    /**
    * delivery_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_configuration_set#delivery_options TfConfigurationSet#delivery_options}
    */
    readonly deliveryOptions?: TfConfigurationSet.DeliveryOptionsProperty;
    /**
    * tracking_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_configuration_set#tracking_options TfConfigurationSet#tracking_options}
    */
    readonly trackingOptions?: TfConfigurationSet.TrackingOptionsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_configuration_set aws_ses_configuration_set}
*/
export declare class TfConfigurationSet extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ses_configuration_set";
    /**
    * Generates CDKTN code for importing a TfConfigurationSet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfConfigurationSet to import
    * @param importFromId The id of the existing TfConfigurationSet that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_configuration_set#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfConfigurationSet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_configuration_set aws_ses_configuration_set} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfConfigurationSetConfig
    */
    constructor(scope: Construct, id: string, config: TfConfigurationSetConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastFreshStart(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _reputationMetricsEnabled?;
    get reputationMetricsEnabled(): boolean | cdktn.IResolvable;
    set reputationMetricsEnabled(value: boolean | cdktn.IResolvable);
    resetReputationMetricsEnabled(): void;
    get reputationMetricsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _sendingEnabled?;
    get sendingEnabled(): boolean | cdktn.IResolvable;
    set sendingEnabled(value: boolean | cdktn.IResolvable);
    resetSendingEnabled(): void;
    get sendingEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _deliveryOptions;
    get deliveryOptions(): TfConfigurationSet.DeliveryOptionsPropertyOutputReference;
    putDeliveryOptions(value: TfConfigurationSet.DeliveryOptionsProperty): void;
    resetDeliveryOptions(): void;
    get deliveryOptionsInput(): TfConfigurationSet.DeliveryOptionsProperty | undefined;
    private _trackingOptions;
    get trackingOptions(): TfConfigurationSet.TrackingOptionsPropertyOutputReference;
    putTrackingOptions(value: TfConfigurationSet.TrackingOptionsProperty): void;
    resetTrackingOptions(): void;
    get trackingOptionsInput(): TfConfigurationSet.TrackingOptionsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfConfigurationSetDeliveryOptionsPropertyToTerraform(struct?: TfConfigurationSet.DeliveryOptionsPropertyOutputReference | TfConfigurationSet.DeliveryOptionsProperty): any;
export declare function tfConfigurationSetDeliveryOptionsPropertyToHclTerraform(struct?: TfConfigurationSet.DeliveryOptionsPropertyOutputReference | TfConfigurationSet.DeliveryOptionsProperty): any;
export declare function tfConfigurationSetTrackingOptionsPropertyToTerraform(struct?: TfConfigurationSet.TrackingOptionsPropertyOutputReference | TfConfigurationSet.TrackingOptionsProperty): any;
export declare function tfConfigurationSetTrackingOptionsPropertyToHclTerraform(struct?: TfConfigurationSet.TrackingOptionsPropertyOutputReference | TfConfigurationSet.TrackingOptionsProperty): any;
export declare namespace TfConfigurationSet {
    interface DeliveryOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_configuration_set#tls_policy TfConfigurationSet#tls_policy}
        */
        readonly tlsPolicy?: string;
    }
    class DeliveryOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DeliveryOptionsProperty | undefined;
        set internalValue(value: DeliveryOptionsProperty | undefined);
        private _tlsPolicy?;
        get tlsPolicy(): string;
        set tlsPolicy(value: string);
        resetTlsPolicy(): void;
        get tlsPolicyInput(): string | undefined;
    }
    interface TrackingOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_configuration_set#custom_redirect_domain TfConfigurationSet#custom_redirect_domain}
        */
        readonly customRedirectDomain?: string;
    }
    class TrackingOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TrackingOptionsProperty | undefined;
        set internalValue(value: TrackingOptionsProperty | undefined);
        private _customRedirectDomain?;
        get customRedirectDomain(): string;
        set customRedirectDomain(value: string);
        resetCustomRedirectDomain(): void;
        get customRedirectDomainInput(): string | undefined;
    }
}
