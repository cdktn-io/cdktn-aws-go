import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsOpensearchserverlessCollectionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Name of the collection group to associate with this collection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_collection#collection_group_name AwsOpensearchserverlessCollection#collection_group_name}
    */
    readonly collectionGroupName?: string;
    /**
    * Description of the collection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_collection#description AwsOpensearchserverlessCollection#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_collection#encryption_config AwsOpensearchserverlessCollection#encryption_config}
    */
    readonly encryptionConfig?: AwsOpensearchserverlessCollection.EncryptionConfigProperty[] | cdktn.IResolvable;
    /**
    * Name of the collection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_collection#name AwsOpensearchserverlessCollection#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_collection#region AwsOpensearchserverlessCollection#region}
    */
    readonly region?: string;
    /**
    * Indicates whether standby replicas should be used for a collection. One of `ENABLED` or `DISABLED`. Defaults to `ENABLED`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_collection#standby_replicas AwsOpensearchserverlessCollection#standby_replicas}
    */
    readonly standbyReplicas?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_collection#tags AwsOpensearchserverlessCollection#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Type of collection. One of `SEARCH`, `TIMESERIES`, or `VECTORSEARCH`. Defaults to `TIMESERIES`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_collection#type AwsOpensearchserverlessCollection#type}
    */
    readonly type?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_collection#vector_options AwsOpensearchserverlessCollection#vector_options}
    */
    readonly vectorOptions?: AwsOpensearchserverlessCollection.VectorOptionsProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_collection#timeouts AwsOpensearchserverlessCollection#timeouts}
    */
    readonly timeouts?: AwsOpensearchserverlessCollection.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_collection aws_opensearchserverless_collection}
*/
export declare class AwsOpensearchserverlessCollection extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_opensearchserverless_collection";
    /**
    * Generates CDKTN code for importing a AwsOpensearchserverlessCollection resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsOpensearchserverlessCollection to import
    * @param importFromId The id of the existing AwsOpensearchserverlessCollection that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_collection#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsOpensearchserverlessCollection to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_collection aws_opensearchserverless_collection} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsOpensearchserverlessCollectionConfig
    */
    constructor(scope: Construct, id: string, config: AwsOpensearchserverlessCollectionConfig);
    get arn(): string;
    get collectionEndpoint(): string;
    private _collectionGroupName?;
    get collectionGroupName(): string;
    set collectionGroupName(value: string);
    resetCollectionGroupName(): void;
    get collectionGroupNameInput(): string | undefined;
    get dashboardEndpoint(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _encryptionConfig;
    get encryptionConfig(): AwsOpensearchserverlessCollection.EncryptionConfigPropertyList;
    putEncryptionConfig(value: AwsOpensearchserverlessCollection.EncryptionConfigProperty[] | cdktn.IResolvable): void;
    resetEncryptionConfig(): void;
    get encryptionConfigInput(): cdktn.IResolvable | AwsOpensearchserverlessCollection.EncryptionConfigProperty[] | undefined;
    get id(): string;
    get kmsKeyArn(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _standbyReplicas?;
    get standbyReplicas(): string;
    set standbyReplicas(value: string);
    resetStandbyReplicas(): void;
    get standbyReplicasInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _vectorOptions;
    get vectorOptions(): AwsOpensearchserverlessCollection.VectorOptionsPropertyList;
    putVectorOptions(value: AwsOpensearchserverlessCollection.VectorOptionsProperty[] | cdktn.IResolvable): void;
    resetVectorOptions(): void;
    get vectorOptionsInput(): cdktn.IResolvable | AwsOpensearchserverlessCollection.VectorOptionsProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsOpensearchserverlessCollection.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsOpensearchserverlessCollection.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsOpensearchserverlessCollection.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsOpensearchserverlessCollectionEncryptionConfigPropertyToTerraform(struct?: AwsOpensearchserverlessCollection.EncryptionConfigProperty | cdktn.IResolvable): any;
export declare function awsOpensearchserverlessCollectionEncryptionConfigPropertyToHclTerraform(struct?: AwsOpensearchserverlessCollection.EncryptionConfigProperty | cdktn.IResolvable): any;
export declare function awsOpensearchserverlessCollectionVectorOptionsPropertyToTerraform(struct?: AwsOpensearchserverlessCollection.VectorOptionsProperty | cdktn.IResolvable): any;
export declare function awsOpensearchserverlessCollectionVectorOptionsPropertyToHclTerraform(struct?: AwsOpensearchserverlessCollection.VectorOptionsProperty | cdktn.IResolvable): any;
export declare function awsOpensearchserverlessCollectionTimeoutsPropertyToTerraform(struct?: AwsOpensearchserverlessCollection.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsOpensearchserverlessCollectionTimeoutsPropertyToHclTerraform(struct?: AwsOpensearchserverlessCollection.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsOpensearchserverlessCollection {
    interface EncryptionConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_collection#aws_owned_key AwsOpensearchserverlessCollection#aws_owned_key}
        */
        readonly awsOwnedKey?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_collection#kms_key_arn AwsOpensearchserverlessCollection#kms_key_arn}
        */
        readonly kmsKeyArn?: string;
    }
    class EncryptionConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EncryptionConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EncryptionConfigProperty | cdktn.IResolvable | undefined);
        private _awsOwnedKey?;
        get awsOwnedKey(): boolean | cdktn.IResolvable;
        set awsOwnedKey(value: boolean | cdktn.IResolvable);
        resetAwsOwnedKey(): void;
        get awsOwnedKeyInput(): boolean | cdktn.IResolvable | undefined;
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        resetKmsKeyArn(): void;
        get kmsKeyArnInput(): string | undefined;
    }
    class EncryptionConfigPropertyList extends cdktn.ComplexList {
        internalValue?: EncryptionConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EncryptionConfigPropertyOutputReference;
    }
    interface VectorOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_collection#serverless_vector_acceleration AwsOpensearchserverlessCollection#serverless_vector_acceleration}
        */
        readonly serverlessVectorAcceleration?: string;
    }
    class VectorOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VectorOptionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VectorOptionsProperty | cdktn.IResolvable | undefined);
        private _serverlessVectorAcceleration?;
        get serverlessVectorAcceleration(): string;
        set serverlessVectorAcceleration(value: string);
        resetServerlessVectorAcceleration(): void;
        get serverlessVectorAccelerationInput(): string | undefined;
    }
    class VectorOptionsPropertyList extends cdktn.ComplexList {
        internalValue?: VectorOptionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VectorOptionsPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_collection#create AwsOpensearchserverlessCollection#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_collection#delete AwsOpensearchserverlessCollection#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
