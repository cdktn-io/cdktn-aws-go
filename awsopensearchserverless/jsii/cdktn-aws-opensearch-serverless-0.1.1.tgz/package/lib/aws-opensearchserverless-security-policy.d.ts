import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsOpensearchserverlessSecurityPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Description of the policy. Typically used to store information about the permissions defined in the policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_security_policy#description AwsOpensearchserverlessSecurityPolicy#description}
    */
    readonly description?: string;
    /**
    * Name of the policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_security_policy#name AwsOpensearchserverlessSecurityPolicy#name}
    */
    readonly name: string;
    /**
    * JSON policy document to use as the content for the new policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_security_policy#policy AwsOpensearchserverlessSecurityPolicy#policy}
    */
    readonly policy: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_security_policy#region AwsOpensearchserverlessSecurityPolicy#region}
    */
    readonly region?: string;
    /**
    * Type of security policy. One of `encryption` or `network`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_security_policy#type AwsOpensearchserverlessSecurityPolicy#type}
    */
    readonly type: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_security_policy aws_opensearchserverless_security_policy}
*/
export declare class AwsOpensearchserverlessSecurityPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_opensearchserverless_security_policy";
    /**
    * Generates CDKTN code for importing a AwsOpensearchserverlessSecurityPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsOpensearchserverlessSecurityPolicy to import
    * @param importFromId The id of the existing AwsOpensearchserverlessSecurityPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_security_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsOpensearchserverlessSecurityPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_security_policy aws_opensearchserverless_security_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsOpensearchserverlessSecurityPolicyConfig
    */
    constructor(scope: Construct, id: string, config: AwsOpensearchserverlessSecurityPolicyConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _policy?;
    get policy(): string;
    set policy(value: string);
    get policyInput(): string | undefined;
    get policyVersion(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
