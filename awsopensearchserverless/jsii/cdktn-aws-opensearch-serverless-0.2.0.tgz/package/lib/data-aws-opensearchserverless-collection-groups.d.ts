import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfCollectionGroupsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/opensearchserverless_collection_groups#region DataTfCollectionGroups#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/opensearchserverless_collection_groups aws_opensearchserverless_collection_groups}
*/
export declare class DataTfCollectionGroups extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_opensearchserverless_collection_groups";
    /**
    * Generates CDKTN code for importing a DataTfCollectionGroups resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfCollectionGroups to import
    * @param importFromId The id of the existing DataTfCollectionGroups that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/opensearchserverless_collection_groups#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfCollectionGroups to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/opensearchserverless_collection_groups aws_opensearchserverless_collection_groups} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfCollectionGroupsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataTfCollectionGroupsConfig);
    private _collectionGroupSummaries;
    get collectionGroupSummaries(): DataTfCollectionGroups.CollectionGroupSummariesPropertyList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfCollectionGroupsCapacityLimitsPropertyToTerraform(struct?: DataTfCollectionGroups.CapacityLimitsProperty): any;
export declare function dataTfCollectionGroupsCapacityLimitsPropertyToHclTerraform(struct?: DataTfCollectionGroups.CapacityLimitsProperty): any;
export declare function dataTfCollectionGroupsCollectionGroupSummariesPropertyToTerraform(struct?: DataTfCollectionGroups.CollectionGroupSummariesProperty): any;
export declare function dataTfCollectionGroupsCollectionGroupSummariesPropertyToHclTerraform(struct?: DataTfCollectionGroups.CollectionGroupSummariesProperty): any;
export declare namespace DataTfCollectionGroups {
    interface CapacityLimitsProperty {
    }
    class CapacityLimitsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CapacityLimitsProperty | undefined;
        set internalValue(value: CapacityLimitsProperty | undefined);
        get maxIndexingCapacityInOcu(): number;
        get maxSearchCapacityInOcu(): number;
        get minIndexingCapacityInOcu(): number;
        get minSearchCapacityInOcu(): number;
    }
    class CapacityLimitsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CapacityLimitsPropertyOutputReference;
    }
    interface CollectionGroupSummariesProperty {
    }
    class CollectionGroupSummariesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CollectionGroupSummariesProperty | undefined;
        set internalValue(value: CollectionGroupSummariesProperty | undefined);
        get arn(): string;
        private _capacityLimits;
        get capacityLimits(): CapacityLimitsPropertyList;
        get createdDate(): string;
        get id(): string;
        get name(): string;
        get numberOfCollections(): number;
        get standbyReplicas(): string;
    }
    class CollectionGroupSummariesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CollectionGroupSummariesPropertyOutputReference;
    }
}
