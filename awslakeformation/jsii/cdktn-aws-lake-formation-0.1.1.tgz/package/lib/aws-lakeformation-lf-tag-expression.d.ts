import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsLakeformationLfTagExpressionConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the Data Catalog.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_lf_tag_expression#catalog_id AwsLakeformationLfTagExpression#catalog_id}
    */
    readonly catalogId?: string;
    /**
    * A description of the LF-Tag Expression.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_lf_tag_expression#description AwsLakeformationLfTagExpression#description}
    */
    readonly description?: string;
    /**
    * The name of the LF-Tag Expression.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_lf_tag_expression#name AwsLakeformationLfTagExpression#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_lf_tag_expression#region AwsLakeformationLfTagExpression#region}
    */
    readonly region?: string;
    /**
    * expression block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_lf_tag_expression#expression AwsLakeformationLfTagExpression#expression}
    */
    readonly expression?: AwsLakeformationLfTagExpression.ExpressionProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_lf_tag_expression aws_lakeformation_lf_tag_expression}
*/
export declare class AwsLakeformationLfTagExpression extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_lakeformation_lf_tag_expression";
    /**
    * Generates CDKTN code for importing a AwsLakeformationLfTagExpression resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsLakeformationLfTagExpression to import
    * @param importFromId The id of the existing AwsLakeformationLfTagExpression that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_lf_tag_expression#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsLakeformationLfTagExpression to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_lf_tag_expression aws_lakeformation_lf_tag_expression} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsLakeformationLfTagExpressionConfig
    */
    constructor(scope: Construct, id: string, config: AwsLakeformationLfTagExpressionConfig);
    private _catalogId?;
    get catalogId(): string;
    set catalogId(value: string);
    resetCatalogId(): void;
    get catalogIdInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _expression;
    get expression(): AwsLakeformationLfTagExpression.ExpressionPropertyList;
    putExpression(value: AwsLakeformationLfTagExpression.ExpressionProperty[] | cdktn.IResolvable): void;
    resetExpression(): void;
    get expressionInput(): cdktn.IResolvable | AwsLakeformationLfTagExpression.ExpressionProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsLakeformationLfTagExpressionExpressionPropertyToTerraform(struct?: AwsLakeformationLfTagExpression.ExpressionProperty | cdktn.IResolvable): any;
export declare function awsLakeformationLfTagExpressionExpressionPropertyToHclTerraform(struct?: AwsLakeformationLfTagExpression.ExpressionProperty | cdktn.IResolvable): any;
export declare namespace AwsLakeformationLfTagExpression {
    interface ExpressionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_lf_tag_expression#tag_key AwsLakeformationLfTagExpression#tag_key}
        */
        readonly tagKey: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_lf_tag_expression#tag_values AwsLakeformationLfTagExpression#tag_values}
        */
        readonly tagValues: string[];
    }
    class ExpressionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExpressionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ExpressionProperty | cdktn.IResolvable | undefined);
        private _tagKey?;
        get tagKey(): string;
        set tagKey(value: string);
        get tagKeyInput(): string | undefined;
        private _tagValues?;
        get tagValues(): string[];
        set tagValues(value: string[]);
        get tagValuesInput(): string[] | undefined;
    }
    class ExpressionPropertyList extends cdktn.ComplexList {
        internalValue?: ExpressionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExpressionPropertyOutputReference;
    }
}
