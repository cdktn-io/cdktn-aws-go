import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsLakeformationOptInConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#region AwsLakeformationOptIn#region}
    */
    readonly region?: string;
    /**
    * condition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#condition AwsLakeformationOptIn#condition}
    */
    readonly condition?: AwsLakeformationOptIn.ConditionProperty[] | cdktn.IResolvable;
    /**
    * principal block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#principal AwsLakeformationOptIn#principal}
    */
    readonly principal?: AwsLakeformationOptIn.PrincipalProperty[] | cdktn.IResolvable;
    /**
    * resource_data block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#resource_data AwsLakeformationOptIn#resource_data}
    */
    readonly resourceData?: AwsLakeformationOptIn.ResourceDataProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in aws_lakeformation_opt_in}
*/
export declare class AwsLakeformationOptIn extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_lakeformation_opt_in";
    /**
    * Generates CDKTN code for importing a AwsLakeformationOptIn resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsLakeformationOptIn to import
    * @param importFromId The id of the existing AwsLakeformationOptIn that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsLakeformationOptIn to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in aws_lakeformation_opt_in} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsLakeformationOptInConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AwsLakeformationOptInConfig);
    get lastModified(): string;
    get lastUpdatedBy(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _condition;
    get condition(): AwsLakeformationOptIn.ConditionPropertyList;
    putCondition(value: AwsLakeformationOptIn.ConditionProperty[] | cdktn.IResolvable): void;
    resetCondition(): void;
    get conditionInput(): cdktn.IResolvable | AwsLakeformationOptIn.ConditionProperty[] | undefined;
    private _principal;
    get principal(): AwsLakeformationOptIn.PrincipalPropertyList;
    putPrincipal(value: AwsLakeformationOptIn.PrincipalProperty[] | cdktn.IResolvable): void;
    resetPrincipal(): void;
    get principalInput(): cdktn.IResolvable | AwsLakeformationOptIn.PrincipalProperty[] | undefined;
    private _resourceData;
    get resourceData(): AwsLakeformationOptIn.ResourceDataPropertyList;
    putResourceData(value: AwsLakeformationOptIn.ResourceDataProperty[] | cdktn.IResolvable): void;
    resetResourceData(): void;
    get resourceDataInput(): cdktn.IResolvable | AwsLakeformationOptIn.ResourceDataProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsLakeformationOptInConditionPropertyToTerraform(struct?: AwsLakeformationOptIn.ConditionProperty | cdktn.IResolvable): any;
export declare function awsLakeformationOptInConditionPropertyToHclTerraform(struct?: AwsLakeformationOptIn.ConditionProperty | cdktn.IResolvable): any;
export declare function awsLakeformationOptInPrincipalPropertyToTerraform(struct?: AwsLakeformationOptIn.PrincipalProperty | cdktn.IResolvable): any;
export declare function awsLakeformationOptInPrincipalPropertyToHclTerraform(struct?: AwsLakeformationOptIn.PrincipalProperty | cdktn.IResolvable): any;
export declare function awsLakeformationOptInCatalogPropertyToTerraform(struct?: AwsLakeformationOptIn.CatalogProperty | cdktn.IResolvable): any;
export declare function awsLakeformationOptInCatalogPropertyToHclTerraform(struct?: AwsLakeformationOptIn.CatalogProperty | cdktn.IResolvable): any;
export declare function awsLakeformationOptInDataCellsFilterPropertyToTerraform(struct?: AwsLakeformationOptIn.DataCellsFilterProperty | cdktn.IResolvable): any;
export declare function awsLakeformationOptInDataCellsFilterPropertyToHclTerraform(struct?: AwsLakeformationOptIn.DataCellsFilterProperty | cdktn.IResolvable): any;
export declare function awsLakeformationOptInDataLocationPropertyToTerraform(struct?: AwsLakeformationOptIn.DataLocationProperty | cdktn.IResolvable): any;
export declare function awsLakeformationOptInDataLocationPropertyToHclTerraform(struct?: AwsLakeformationOptIn.DataLocationProperty | cdktn.IResolvable): any;
export declare function awsLakeformationOptInDatabasePropertyToTerraform(struct?: AwsLakeformationOptIn.DatabaseProperty | cdktn.IResolvable): any;
export declare function awsLakeformationOptInDatabasePropertyToHclTerraform(struct?: AwsLakeformationOptIn.DatabaseProperty | cdktn.IResolvable): any;
export declare function awsLakeformationOptInLfTagPropertyToTerraform(struct?: AwsLakeformationOptIn.LfTagProperty | cdktn.IResolvable): any;
export declare function awsLakeformationOptInLfTagPropertyToHclTerraform(struct?: AwsLakeformationOptIn.LfTagProperty | cdktn.IResolvable): any;
export declare function awsLakeformationOptInLfTagExpressionPropertyToTerraform(struct?: AwsLakeformationOptIn.LfTagExpressionProperty | cdktn.IResolvable): any;
export declare function awsLakeformationOptInLfTagExpressionPropertyToHclTerraform(struct?: AwsLakeformationOptIn.LfTagExpressionProperty | cdktn.IResolvable): any;
export declare function awsLakeformationOptInLfTagPolicyPropertyToTerraform(struct?: AwsLakeformationOptIn.LfTagPolicyProperty | cdktn.IResolvable): any;
export declare function awsLakeformationOptInLfTagPolicyPropertyToHclTerraform(struct?: AwsLakeformationOptIn.LfTagPolicyProperty | cdktn.IResolvable): any;
export declare function awsLakeformationOptInTablePropertyToTerraform(struct?: AwsLakeformationOptIn.TableProperty | cdktn.IResolvable): any;
export declare function awsLakeformationOptInTablePropertyToHclTerraform(struct?: AwsLakeformationOptIn.TableProperty | cdktn.IResolvable): any;
export declare function awsLakeformationOptInColumnWildcardPropertyToTerraform(struct?: AwsLakeformationOptIn.ColumnWildcardProperty | cdktn.IResolvable): any;
export declare function awsLakeformationOptInColumnWildcardPropertyToHclTerraform(struct?: AwsLakeformationOptIn.ColumnWildcardProperty | cdktn.IResolvable): any;
export declare function awsLakeformationOptInTableWithColumnsPropertyToTerraform(struct?: AwsLakeformationOptIn.TableWithColumnsProperty | cdktn.IResolvable): any;
export declare function awsLakeformationOptInTableWithColumnsPropertyToHclTerraform(struct?: AwsLakeformationOptIn.TableWithColumnsProperty | cdktn.IResolvable): any;
export declare function awsLakeformationOptInResourceDataPropertyToTerraform(struct?: AwsLakeformationOptIn.ResourceDataProperty | cdktn.IResolvable): any;
export declare function awsLakeformationOptInResourceDataPropertyToHclTerraform(struct?: AwsLakeformationOptIn.ResourceDataProperty | cdktn.IResolvable): any;
export declare namespace AwsLakeformationOptIn {
    interface ConditionProperty {
    }
    class ConditionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConditionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConditionProperty | cdktn.IResolvable | undefined);
        get expression(): string;
    }
    class ConditionPropertyList extends cdktn.ComplexList {
        internalValue?: ConditionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConditionPropertyOutputReference;
    }
    interface PrincipalProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#data_lake_principal_identifier AwsLakeformationOptIn#data_lake_principal_identifier}
        */
        readonly dataLakePrincipalIdentifier: string;
    }
    class PrincipalPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PrincipalProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PrincipalProperty | cdktn.IResolvable | undefined);
        private _dataLakePrincipalIdentifier?;
        get dataLakePrincipalIdentifier(): string;
        set dataLakePrincipalIdentifier(value: string);
        get dataLakePrincipalIdentifierInput(): string | undefined;
    }
    class PrincipalPropertyList extends cdktn.ComplexList {
        internalValue?: PrincipalProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PrincipalPropertyOutputReference;
    }
    interface CatalogProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#id AwsLakeformationOptIn#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id?: string;
    }
    class CatalogPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CatalogProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CatalogProperty | cdktn.IResolvable | undefined);
        private _id?;
        get id(): string;
        set id(value: string);
        resetId(): void;
        get idInput(): string | undefined;
    }
    class CatalogPropertyList extends cdktn.ComplexList {
        internalValue?: CatalogProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CatalogPropertyOutputReference;
    }
    interface DataCellsFilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#database_name AwsLakeformationOptIn#database_name}
        */
        readonly databaseName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#name AwsLakeformationOptIn#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#table_catalog_id AwsLakeformationOptIn#table_catalog_id}
        */
        readonly tableCatalogId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#table_name AwsLakeformationOptIn#table_name}
        */
        readonly tableName?: string;
    }
    class DataCellsFilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataCellsFilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DataCellsFilterProperty | cdktn.IResolvable | undefined);
        private _databaseName?;
        get databaseName(): string;
        set databaseName(value: string);
        resetDatabaseName(): void;
        get databaseNameInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _tableCatalogId?;
        get tableCatalogId(): string;
        set tableCatalogId(value: string);
        resetTableCatalogId(): void;
        get tableCatalogIdInput(): string | undefined;
        private _tableName?;
        get tableName(): string;
        set tableName(value: string);
        resetTableName(): void;
        get tableNameInput(): string | undefined;
    }
    class DataCellsFilterPropertyList extends cdktn.ComplexList {
        internalValue?: DataCellsFilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataCellsFilterPropertyOutputReference;
    }
    interface DataLocationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#catalog_id AwsLakeformationOptIn#catalog_id}
        */
        readonly catalogId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#resource_arn AwsLakeformationOptIn#resource_arn}
        */
        readonly resourceArn: string;
    }
    class DataLocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataLocationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DataLocationProperty | cdktn.IResolvable | undefined);
        private _catalogId?;
        get catalogId(): string;
        set catalogId(value: string);
        resetCatalogId(): void;
        get catalogIdInput(): string | undefined;
        private _resourceArn?;
        get resourceArn(): string;
        set resourceArn(value: string);
        get resourceArnInput(): string | undefined;
    }
    class DataLocationPropertyList extends cdktn.ComplexList {
        internalValue?: DataLocationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataLocationPropertyOutputReference;
    }
    interface DatabaseProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#catalog_id AwsLakeformationOptIn#catalog_id}
        */
        readonly catalogId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#name AwsLakeformationOptIn#name}
        */
        readonly name: string;
    }
    class DatabasePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DatabaseProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DatabaseProperty | cdktn.IResolvable | undefined);
        private _catalogId?;
        get catalogId(): string;
        set catalogId(value: string);
        resetCatalogId(): void;
        get catalogIdInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    class DatabasePropertyList extends cdktn.ComplexList {
        internalValue?: DatabaseProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DatabasePropertyOutputReference;
    }
    interface LfTagProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#catalog_id AwsLakeformationOptIn#catalog_id}
        */
        readonly catalogId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#key AwsLakeformationOptIn#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#values AwsLakeformationOptIn#values}
        */
        readonly values: string[];
    }
    class LfTagPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LfTagProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LfTagProperty | cdktn.IResolvable | undefined);
        private _catalogId?;
        get catalogId(): string;
        set catalogId(value: string);
        resetCatalogId(): void;
        get catalogIdInput(): string | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class LfTagPropertyList extends cdktn.ComplexList {
        internalValue?: LfTagProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LfTagPropertyOutputReference;
    }
    interface LfTagExpressionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#catalog_id AwsLakeformationOptIn#catalog_id}
        */
        readonly catalogId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#name AwsLakeformationOptIn#name}
        */
        readonly name: string;
    }
    class LfTagExpressionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LfTagExpressionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LfTagExpressionProperty | cdktn.IResolvable | undefined);
        private _catalogId?;
        get catalogId(): string;
        set catalogId(value: string);
        resetCatalogId(): void;
        get catalogIdInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    class LfTagExpressionPropertyList extends cdktn.ComplexList {
        internalValue?: LfTagExpressionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LfTagExpressionPropertyOutputReference;
    }
    interface LfTagPolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#catalog_id AwsLakeformationOptIn#catalog_id}
        */
        readonly catalogId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#expression AwsLakeformationOptIn#expression}
        */
        readonly expression?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#expression_name AwsLakeformationOptIn#expression_name}
        */
        readonly expressionName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#resource_type AwsLakeformationOptIn#resource_type}
        */
        readonly resourceType: string;
    }
    class LfTagPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LfTagPolicyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LfTagPolicyProperty | cdktn.IResolvable | undefined);
        private _catalogId?;
        get catalogId(): string;
        set catalogId(value: string);
        resetCatalogId(): void;
        get catalogIdInput(): string | undefined;
        private _expression?;
        get expression(): string[];
        set expression(value: string[]);
        resetExpression(): void;
        get expressionInput(): string[] | undefined;
        private _expressionName?;
        get expressionName(): string;
        set expressionName(value: string);
        resetExpressionName(): void;
        get expressionNameInput(): string | undefined;
        private _resourceType?;
        get resourceType(): string;
        set resourceType(value: string);
        get resourceTypeInput(): string | undefined;
    }
    class LfTagPolicyPropertyList extends cdktn.ComplexList {
        internalValue?: LfTagPolicyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LfTagPolicyPropertyOutputReference;
    }
    interface TableProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#catalog_id AwsLakeformationOptIn#catalog_id}
        */
        readonly catalogId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#database_name AwsLakeformationOptIn#database_name}
        */
        readonly databaseName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#name AwsLakeformationOptIn#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#wildcard AwsLakeformationOptIn#wildcard}
        */
        readonly wildcard?: boolean | cdktn.IResolvable;
    }
    class TablePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TableProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TableProperty | cdktn.IResolvable | undefined);
        private _catalogId?;
        get catalogId(): string;
        set catalogId(value: string);
        resetCatalogId(): void;
        get catalogIdInput(): string | undefined;
        private _databaseName?;
        get databaseName(): string;
        set databaseName(value: string);
        get databaseNameInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _wildcard?;
        get wildcard(): boolean | cdktn.IResolvable;
        set wildcard(value: boolean | cdktn.IResolvable);
        resetWildcard(): void;
        get wildcardInput(): boolean | cdktn.IResolvable | undefined;
    }
    class TablePropertyList extends cdktn.ComplexList {
        internalValue?: TableProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TablePropertyOutputReference;
    }
    interface ColumnWildcardProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#excluded_column_names AwsLakeformationOptIn#excluded_column_names}
        */
        readonly excludedColumnNames?: string[];
    }
    class ColumnWildcardPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ColumnWildcardProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ColumnWildcardProperty | cdktn.IResolvable | undefined);
        private _excludedColumnNames?;
        get excludedColumnNames(): string[];
        set excludedColumnNames(value: string[]);
        resetExcludedColumnNames(): void;
        get excludedColumnNamesInput(): string[] | undefined;
    }
    class ColumnWildcardPropertyList extends cdktn.ComplexList {
        internalValue?: ColumnWildcardProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ColumnWildcardPropertyOutputReference;
    }
    interface TableWithColumnsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#catalog_id AwsLakeformationOptIn#catalog_id}
        */
        readonly catalogId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#column_names AwsLakeformationOptIn#column_names}
        */
        readonly columnNames?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#database_name AwsLakeformationOptIn#database_name}
        */
        readonly databaseName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#name AwsLakeformationOptIn#name}
        */
        readonly name: string;
        /**
        * column_wildcard block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#column_wildcard AwsLakeformationOptIn#column_wildcard}
        */
        readonly columnWildcard?: ColumnWildcardProperty[] | cdktn.IResolvable;
    }
    class TableWithColumnsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TableWithColumnsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TableWithColumnsProperty | cdktn.IResolvable | undefined);
        private _catalogId?;
        get catalogId(): string;
        set catalogId(value: string);
        resetCatalogId(): void;
        get catalogIdInput(): string | undefined;
        private _columnNames?;
        get columnNames(): string[];
        set columnNames(value: string[]);
        resetColumnNames(): void;
        get columnNamesInput(): string[] | undefined;
        private _databaseName?;
        get databaseName(): string;
        set databaseName(value: string);
        get databaseNameInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _columnWildcard;
        get columnWildcard(): ColumnWildcardPropertyList;
        putColumnWildcard(value: ColumnWildcardProperty[] | cdktn.IResolvable): void;
        resetColumnWildcard(): void;
        get columnWildcardInput(): cdktn.IResolvable | ColumnWildcardProperty[] | undefined;
    }
    class TableWithColumnsPropertyList extends cdktn.ComplexList {
        internalValue?: TableWithColumnsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TableWithColumnsPropertyOutputReference;
    }
    interface ResourceDataProperty {
        /**
        * catalog block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#catalog AwsLakeformationOptIn#catalog}
        */
        readonly catalog?: CatalogProperty[] | cdktn.IResolvable;
        /**
        * data_cells_filter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#data_cells_filter AwsLakeformationOptIn#data_cells_filter}
        */
        readonly dataCellsFilter?: DataCellsFilterProperty[] | cdktn.IResolvable;
        /**
        * data_location block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#data_location AwsLakeformationOptIn#data_location}
        */
        readonly dataLocation?: DataLocationProperty[] | cdktn.IResolvable;
        /**
        * database block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#database AwsLakeformationOptIn#database}
        */
        readonly database?: DatabaseProperty[] | cdktn.IResolvable;
        /**
        * lf_tag block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#lf_tag AwsLakeformationOptIn#lf_tag}
        */
        readonly lfTag?: LfTagProperty[] | cdktn.IResolvable;
        /**
        * lf_tag_expression block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#lf_tag_expression AwsLakeformationOptIn#lf_tag_expression}
        */
        readonly lfTagExpression?: LfTagExpressionProperty[] | cdktn.IResolvable;
        /**
        * lf_tag_policy block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#lf_tag_policy AwsLakeformationOptIn#lf_tag_policy}
        */
        readonly lfTagPolicy?: LfTagPolicyProperty[] | cdktn.IResolvable;
        /**
        * table block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#table AwsLakeformationOptIn#table}
        */
        readonly table?: TableProperty[] | cdktn.IResolvable;
        /**
        * table_with_columns block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#table_with_columns AwsLakeformationOptIn#table_with_columns}
        */
        readonly tableWithColumns?: TableWithColumnsProperty[] | cdktn.IResolvable;
    }
    class ResourceDataPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceDataProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceDataProperty | cdktn.IResolvable | undefined);
        private _catalog;
        get catalog(): CatalogPropertyList;
        putCatalog(value: CatalogProperty[] | cdktn.IResolvable): void;
        resetCatalog(): void;
        get catalogInput(): cdktn.IResolvable | CatalogProperty[] | undefined;
        private _dataCellsFilter;
        get dataCellsFilter(): DataCellsFilterPropertyList;
        putDataCellsFilter(value: DataCellsFilterProperty[] | cdktn.IResolvable): void;
        resetDataCellsFilter(): void;
        get dataCellsFilterInput(): cdktn.IResolvable | DataCellsFilterProperty[] | undefined;
        private _dataLocation;
        get dataLocation(): DataLocationPropertyList;
        putDataLocation(value: DataLocationProperty[] | cdktn.IResolvable): void;
        resetDataLocation(): void;
        get dataLocationInput(): cdktn.IResolvable | DataLocationProperty[] | undefined;
        private _database;
        get database(): DatabasePropertyList;
        putDatabase(value: DatabaseProperty[] | cdktn.IResolvable): void;
        resetDatabase(): void;
        get databaseInput(): cdktn.IResolvable | DatabaseProperty[] | undefined;
        private _lfTag;
        get lfTag(): LfTagPropertyList;
        putLfTag(value: LfTagProperty[] | cdktn.IResolvable): void;
        resetLfTag(): void;
        get lfTagInput(): cdktn.IResolvable | LfTagProperty[] | undefined;
        private _lfTagExpression;
        get lfTagExpression(): LfTagExpressionPropertyList;
        putLfTagExpression(value: LfTagExpressionProperty[] | cdktn.IResolvable): void;
        resetLfTagExpression(): void;
        get lfTagExpressionInput(): cdktn.IResolvable | LfTagExpressionProperty[] | undefined;
        private _lfTagPolicy;
        get lfTagPolicy(): LfTagPolicyPropertyList;
        putLfTagPolicy(value: LfTagPolicyProperty[] | cdktn.IResolvable): void;
        resetLfTagPolicy(): void;
        get lfTagPolicyInput(): cdktn.IResolvable | LfTagPolicyProperty[] | undefined;
        private _table;
        get table(): TablePropertyList;
        putTable(value: TableProperty[] | cdktn.IResolvable): void;
        resetTable(): void;
        get tableInput(): cdktn.IResolvable | TableProperty[] | undefined;
        private _tableWithColumns;
        get tableWithColumns(): TableWithColumnsPropertyList;
        putTableWithColumns(value: TableWithColumnsProperty[] | cdktn.IResolvable): void;
        resetTableWithColumns(): void;
        get tableWithColumnsInput(): cdktn.IResolvable | TableWithColumnsProperty[] | undefined;
    }
    class ResourceDataPropertyList extends cdktn.ComplexList {
        internalValue?: ResourceDataProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceDataPropertyOutputReference;
    }
}
