import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsLakeformationDataLakeSettingsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_lake_settings#admins AwsLakeformationDataLakeSettings#admins}
    */
    readonly admins?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_lake_settings#allow_external_data_filtering AwsLakeformationDataLakeSettings#allow_external_data_filtering}
    */
    readonly allowExternalDataFiltering?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_lake_settings#allow_full_table_external_data_access AwsLakeformationDataLakeSettings#allow_full_table_external_data_access}
    */
    readonly allowFullTableExternalDataAccess?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_lake_settings#authorized_session_tag_value_list AwsLakeformationDataLakeSettings#authorized_session_tag_value_list}
    */
    readonly authorizedSessionTagValueList?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_lake_settings#catalog_id AwsLakeformationDataLakeSettings#catalog_id}
    */
    readonly catalogId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_lake_settings#external_data_filtering_allow_list AwsLakeformationDataLakeSettings#external_data_filtering_allow_list}
    */
    readonly externalDataFilteringAllowList?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_lake_settings#id AwsLakeformationDataLakeSettings#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_lake_settings#parameters AwsLakeformationDataLakeSettings#parameters}
    */
    readonly parameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_lake_settings#read_only_admins AwsLakeformationDataLakeSettings#read_only_admins}
    */
    readonly readOnlyAdmins?: string[];
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_lake_settings#region AwsLakeformationDataLakeSettings#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_lake_settings#trusted_resource_owners AwsLakeformationDataLakeSettings#trusted_resource_owners}
    */
    readonly trustedResourceOwners?: string[];
    /**
    * create_database_default_permissions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_lake_settings#create_database_default_permissions AwsLakeformationDataLakeSettings#create_database_default_permissions}
    */
    readonly createDatabaseDefaultPermissions?: AwsLakeformationDataLakeSettings.CreateDatabaseDefaultPermissionsProperty[] | cdktn.IResolvable;
    /**
    * create_table_default_permissions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_lake_settings#create_table_default_permissions AwsLakeformationDataLakeSettings#create_table_default_permissions}
    */
    readonly createTableDefaultPermissions?: AwsLakeformationDataLakeSettings.CreateTableDefaultPermissionsProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_lake_settings aws_lakeformation_data_lake_settings}
*/
export declare class AwsLakeformationDataLakeSettings extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_lakeformation_data_lake_settings";
    /**
    * Generates CDKTN code for importing a AwsLakeformationDataLakeSettings resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsLakeformationDataLakeSettings to import
    * @param importFromId The id of the existing AwsLakeformationDataLakeSettings that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_lake_settings#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsLakeformationDataLakeSettings to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_lake_settings aws_lakeformation_data_lake_settings} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsLakeformationDataLakeSettingsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AwsLakeformationDataLakeSettingsConfig);
    private _admins?;
    get admins(): string[];
    set admins(value: string[]);
    resetAdmins(): void;
    get adminsInput(): string[] | undefined;
    private _allowExternalDataFiltering?;
    get allowExternalDataFiltering(): boolean | cdktn.IResolvable;
    set allowExternalDataFiltering(value: boolean | cdktn.IResolvable);
    resetAllowExternalDataFiltering(): void;
    get allowExternalDataFilteringInput(): boolean | cdktn.IResolvable | undefined;
    private _allowFullTableExternalDataAccess?;
    get allowFullTableExternalDataAccess(): boolean | cdktn.IResolvable;
    set allowFullTableExternalDataAccess(value: boolean | cdktn.IResolvable);
    resetAllowFullTableExternalDataAccess(): void;
    get allowFullTableExternalDataAccessInput(): boolean | cdktn.IResolvable | undefined;
    private _authorizedSessionTagValueList?;
    get authorizedSessionTagValueList(): string[];
    set authorizedSessionTagValueList(value: string[]);
    resetAuthorizedSessionTagValueList(): void;
    get authorizedSessionTagValueListInput(): string[] | undefined;
    private _catalogId?;
    get catalogId(): string;
    set catalogId(value: string);
    resetCatalogId(): void;
    get catalogIdInput(): string | undefined;
    private _externalDataFilteringAllowList?;
    get externalDataFilteringAllowList(): string[];
    set externalDataFilteringAllowList(value: string[]);
    resetExternalDataFilteringAllowList(): void;
    get externalDataFilteringAllowListInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _parameters?;
    get parameters(): {
        [key: string]: string;
    };
    set parameters(value: {
        [key: string]: string;
    });
    resetParameters(): void;
    get parametersInput(): {
        [key: string]: string;
    } | undefined;
    private _readOnlyAdmins?;
    get readOnlyAdmins(): string[];
    set readOnlyAdmins(value: string[]);
    resetReadOnlyAdmins(): void;
    get readOnlyAdminsInput(): string[] | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _trustedResourceOwners?;
    get trustedResourceOwners(): string[];
    set trustedResourceOwners(value: string[]);
    resetTrustedResourceOwners(): void;
    get trustedResourceOwnersInput(): string[] | undefined;
    private _createDatabaseDefaultPermissions;
    get createDatabaseDefaultPermissions(): AwsLakeformationDataLakeSettings.CreateDatabaseDefaultPermissionsPropertyList;
    putCreateDatabaseDefaultPermissions(value: AwsLakeformationDataLakeSettings.CreateDatabaseDefaultPermissionsProperty[] | cdktn.IResolvable): void;
    resetCreateDatabaseDefaultPermissions(): void;
    get createDatabaseDefaultPermissionsInput(): cdktn.IResolvable | AwsLakeformationDataLakeSettings.CreateDatabaseDefaultPermissionsProperty[] | undefined;
    private _createTableDefaultPermissions;
    get createTableDefaultPermissions(): AwsLakeformationDataLakeSettings.CreateTableDefaultPermissionsPropertyList;
    putCreateTableDefaultPermissions(value: AwsLakeformationDataLakeSettings.CreateTableDefaultPermissionsProperty[] | cdktn.IResolvable): void;
    resetCreateTableDefaultPermissions(): void;
    get createTableDefaultPermissionsInput(): cdktn.IResolvable | AwsLakeformationDataLakeSettings.CreateTableDefaultPermissionsProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsLakeformationDataLakeSettingsCreateDatabaseDefaultPermissionsPropertyToTerraform(struct?: AwsLakeformationDataLakeSettings.CreateDatabaseDefaultPermissionsProperty | cdktn.IResolvable): any;
export declare function awsLakeformationDataLakeSettingsCreateDatabaseDefaultPermissionsPropertyToHclTerraform(struct?: AwsLakeformationDataLakeSettings.CreateDatabaseDefaultPermissionsProperty | cdktn.IResolvable): any;
export declare function awsLakeformationDataLakeSettingsCreateTableDefaultPermissionsPropertyToTerraform(struct?: AwsLakeformationDataLakeSettings.CreateTableDefaultPermissionsProperty | cdktn.IResolvable): any;
export declare function awsLakeformationDataLakeSettingsCreateTableDefaultPermissionsPropertyToHclTerraform(struct?: AwsLakeformationDataLakeSettings.CreateTableDefaultPermissionsProperty | cdktn.IResolvable): any;
export declare namespace AwsLakeformationDataLakeSettings {
    interface CreateDatabaseDefaultPermissionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_lake_settings#permissions AwsLakeformationDataLakeSettings#permissions}
        */
        readonly permissions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_lake_settings#principal AwsLakeformationDataLakeSettings#principal}
        */
        readonly principal?: string;
    }
    class CreateDatabaseDefaultPermissionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CreateDatabaseDefaultPermissionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CreateDatabaseDefaultPermissionsProperty | cdktn.IResolvable | undefined);
        private _permissions?;
        get permissions(): string[];
        set permissions(value: string[]);
        resetPermissions(): void;
        get permissionsInput(): string[] | undefined;
        private _principal?;
        get principal(): string;
        set principal(value: string);
        resetPrincipal(): void;
        get principalInput(): string | undefined;
    }
    class CreateDatabaseDefaultPermissionsPropertyList extends cdktn.ComplexList {
        internalValue?: CreateDatabaseDefaultPermissionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CreateDatabaseDefaultPermissionsPropertyOutputReference;
    }
    interface CreateTableDefaultPermissionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_lake_settings#permissions AwsLakeformationDataLakeSettings#permissions}
        */
        readonly permissions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_lake_settings#principal AwsLakeformationDataLakeSettings#principal}
        */
        readonly principal?: string;
    }
    class CreateTableDefaultPermissionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CreateTableDefaultPermissionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CreateTableDefaultPermissionsProperty | cdktn.IResolvable | undefined);
        private _permissions?;
        get permissions(): string[];
        set permissions(value: string[]);
        resetPermissions(): void;
        get permissionsInput(): string[] | undefined;
        private _principal?;
        get principal(): string;
        set principal(value: string);
        resetPrincipal(): void;
        get principalInput(): string | undefined;
    }
    class CreateTableDefaultPermissionsPropertyList extends cdktn.ComplexList {
        internalValue?: CreateTableDefaultPermissionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CreateTableDefaultPermissionsPropertyOutputReference;
    }
}
