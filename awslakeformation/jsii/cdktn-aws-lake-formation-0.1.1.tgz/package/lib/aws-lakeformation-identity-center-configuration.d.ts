import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsLakeformationIdentityCenterConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the Data Catalog.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_identity_center_configuration#catalog_id AwsLakeformationIdentityCenterConfiguration#catalog_id}
    */
    readonly catalogId?: string;
    /**
    * The ARN of the Identity Center instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_identity_center_configuration#instance_arn AwsLakeformationIdentityCenterConfiguration#instance_arn}
    */
    readonly instanceArn: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_identity_center_configuration#region AwsLakeformationIdentityCenterConfiguration#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_identity_center_configuration aws_lakeformation_identity_center_configuration}
*/
export declare class AwsLakeformationIdentityCenterConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_lakeformation_identity_center_configuration";
    /**
    * Generates CDKTN code for importing a AwsLakeformationIdentityCenterConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsLakeformationIdentityCenterConfiguration to import
    * @param importFromId The id of the existing AwsLakeformationIdentityCenterConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_identity_center_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsLakeformationIdentityCenterConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_identity_center_configuration aws_lakeformation_identity_center_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsLakeformationIdentityCenterConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AwsLakeformationIdentityCenterConfigurationConfig);
    get applicationArn(): string;
    private _catalogId?;
    get catalogId(): string;
    set catalogId(value: string);
    resetCatalogId(): void;
    get catalogIdInput(): string | undefined;
    private _instanceArn?;
    get instanceArn(): string;
    set instanceArn(value: string);
    get instanceArnInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get resourceShare(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
