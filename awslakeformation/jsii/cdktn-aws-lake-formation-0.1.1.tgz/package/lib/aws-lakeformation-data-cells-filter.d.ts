import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsLakeformationDataCellsFilterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_cells_filter#region AwsLakeformationDataCellsFilter#region}
    */
    readonly region?: string;
    /**
    * table_data block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_cells_filter#table_data AwsLakeformationDataCellsFilter#table_data}
    */
    readonly tableData?: AwsLakeformationDataCellsFilter.TableDataProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_cells_filter#timeouts AwsLakeformationDataCellsFilter#timeouts}
    */
    readonly timeouts?: AwsLakeformationDataCellsFilter.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_cells_filter aws_lakeformation_data_cells_filter}
*/
export declare class AwsLakeformationDataCellsFilter extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_lakeformation_data_cells_filter";
    /**
    * Generates CDKTN code for importing a AwsLakeformationDataCellsFilter resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsLakeformationDataCellsFilter to import
    * @param importFromId The id of the existing AwsLakeformationDataCellsFilter that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_cells_filter#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsLakeformationDataCellsFilter to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_cells_filter aws_lakeformation_data_cells_filter} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsLakeformationDataCellsFilterConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AwsLakeformationDataCellsFilterConfig);
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tableData;
    get tableData(): AwsLakeformationDataCellsFilter.TableDataPropertyList;
    putTableData(value: AwsLakeformationDataCellsFilter.TableDataProperty[] | cdktn.IResolvable): void;
    resetTableData(): void;
    get tableDataInput(): cdktn.IResolvable | AwsLakeformationDataCellsFilter.TableDataProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsLakeformationDataCellsFilter.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsLakeformationDataCellsFilter.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsLakeformationDataCellsFilter.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsLakeformationDataCellsFilterColumnWildcardPropertyToTerraform(struct?: AwsLakeformationDataCellsFilter.ColumnWildcardProperty | cdktn.IResolvable): any;
export declare function awsLakeformationDataCellsFilterColumnWildcardPropertyToHclTerraform(struct?: AwsLakeformationDataCellsFilter.ColumnWildcardProperty | cdktn.IResolvable): any;
export declare function awsLakeformationDataCellsFilterAllRowsWildcardPropertyToTerraform(struct?: AwsLakeformationDataCellsFilter.AllRowsWildcardProperty | cdktn.IResolvable): any;
export declare function awsLakeformationDataCellsFilterAllRowsWildcardPropertyToHclTerraform(struct?: AwsLakeformationDataCellsFilter.AllRowsWildcardProperty | cdktn.IResolvable): any;
export declare function awsLakeformationDataCellsFilterRowFilterPropertyToTerraform(struct?: AwsLakeformationDataCellsFilter.RowFilterProperty | cdktn.IResolvable): any;
export declare function awsLakeformationDataCellsFilterRowFilterPropertyToHclTerraform(struct?: AwsLakeformationDataCellsFilter.RowFilterProperty | cdktn.IResolvable): any;
export declare function awsLakeformationDataCellsFilterTableDataPropertyToTerraform(struct?: AwsLakeformationDataCellsFilter.TableDataProperty | cdktn.IResolvable): any;
export declare function awsLakeformationDataCellsFilterTableDataPropertyToHclTerraform(struct?: AwsLakeformationDataCellsFilter.TableDataProperty | cdktn.IResolvable): any;
export declare function awsLakeformationDataCellsFilterTimeoutsPropertyToTerraform(struct?: AwsLakeformationDataCellsFilter.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsLakeformationDataCellsFilterTimeoutsPropertyToHclTerraform(struct?: AwsLakeformationDataCellsFilter.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsLakeformationDataCellsFilter {
    interface ColumnWildcardProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_cells_filter#excluded_column_names AwsLakeformationDataCellsFilter#excluded_column_names}
        */
        readonly excludedColumnNames?: string[];
    }
    class ColumnWildcardPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ColumnWildcardProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ColumnWildcardProperty | cdktn.IResolvable | undefined);
        private _excludedColumnNames?;
        get excludedColumnNames(): string[];
        set excludedColumnNames(value: string[]);
        resetExcludedColumnNames(): void;
        get excludedColumnNamesInput(): string[] | undefined;
    }
    class ColumnWildcardPropertyList extends cdktn.ComplexList {
        internalValue?: ColumnWildcardProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ColumnWildcardPropertyOutputReference;
    }
    interface AllRowsWildcardProperty {
    }
    class AllRowsWildcardPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AllRowsWildcardProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AllRowsWildcardProperty | cdktn.IResolvable | undefined);
    }
    class AllRowsWildcardPropertyList extends cdktn.ComplexList {
        internalValue?: AllRowsWildcardProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AllRowsWildcardPropertyOutputReference;
    }
    interface RowFilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_cells_filter#filter_expression AwsLakeformationDataCellsFilter#filter_expression}
        */
        readonly filterExpression?: string;
        /**
        * all_rows_wildcard block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_cells_filter#all_rows_wildcard AwsLakeformationDataCellsFilter#all_rows_wildcard}
        */
        readonly allRowsWildcard?: AllRowsWildcardProperty[] | cdktn.IResolvable;
    }
    class RowFilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RowFilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RowFilterProperty | cdktn.IResolvable | undefined);
        private _filterExpression?;
        get filterExpression(): string;
        set filterExpression(value: string);
        resetFilterExpression(): void;
        get filterExpressionInput(): string | undefined;
        private _allRowsWildcard;
        get allRowsWildcard(): AllRowsWildcardPropertyList;
        putAllRowsWildcard(value: AllRowsWildcardProperty[] | cdktn.IResolvable): void;
        resetAllRowsWildcard(): void;
        get allRowsWildcardInput(): cdktn.IResolvable | AllRowsWildcardProperty[] | undefined;
    }
    class RowFilterPropertyList extends cdktn.ComplexList {
        internalValue?: RowFilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RowFilterPropertyOutputReference;
    }
    interface TableDataProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_cells_filter#column_names AwsLakeformationDataCellsFilter#column_names}
        */
        readonly columnNames?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_cells_filter#database_name AwsLakeformationDataCellsFilter#database_name}
        */
        readonly databaseName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_cells_filter#name AwsLakeformationDataCellsFilter#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_cells_filter#table_catalog_id AwsLakeformationDataCellsFilter#table_catalog_id}
        */
        readonly tableCatalogId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_cells_filter#table_name AwsLakeformationDataCellsFilter#table_name}
        */
        readonly tableName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_cells_filter#version_id AwsLakeformationDataCellsFilter#version_id}
        */
        readonly versionId?: string;
        /**
        * column_wildcard block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_cells_filter#column_wildcard AwsLakeformationDataCellsFilter#column_wildcard}
        */
        readonly columnWildcard?: ColumnWildcardProperty[] | cdktn.IResolvable;
        /**
        * row_filter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_cells_filter#row_filter AwsLakeformationDataCellsFilter#row_filter}
        */
        readonly rowFilter?: RowFilterProperty[] | cdktn.IResolvable;
    }
    class TableDataPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TableDataProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TableDataProperty | cdktn.IResolvable | undefined);
        private _columnNames?;
        get columnNames(): string[];
        set columnNames(value: string[]);
        resetColumnNames(): void;
        get columnNamesInput(): string[] | undefined;
        private _databaseName?;
        get databaseName(): string;
        set databaseName(value: string);
        get databaseNameInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _tableCatalogId?;
        get tableCatalogId(): string;
        set tableCatalogId(value: string);
        get tableCatalogIdInput(): string | undefined;
        private _tableName?;
        get tableName(): string;
        set tableName(value: string);
        get tableNameInput(): string | undefined;
        private _versionId?;
        get versionId(): string;
        set versionId(value: string);
        resetVersionId(): void;
        get versionIdInput(): string | undefined;
        private _columnWildcard;
        get columnWildcard(): ColumnWildcardPropertyList;
        putColumnWildcard(value: ColumnWildcardProperty[] | cdktn.IResolvable): void;
        resetColumnWildcard(): void;
        get columnWildcardInput(): cdktn.IResolvable | ColumnWildcardProperty[] | undefined;
        private _rowFilter;
        get rowFilter(): RowFilterPropertyList;
        putRowFilter(value: RowFilterProperty[] | cdktn.IResolvable): void;
        resetRowFilter(): void;
        get rowFilterInput(): cdktn.IResolvable | RowFilterProperty[] | undefined;
    }
    class TableDataPropertyList extends cdktn.ComplexList {
        internalValue?: TableDataProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TableDataPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_cells_filter#create AwsLakeformationDataCellsFilter#create}
        */
        readonly create?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
    }
}
