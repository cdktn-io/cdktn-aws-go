import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsLakeformationDataLakeSettingsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_data_lake_settings#catalog_id DataAwsLakeformationDataLakeSettings#catalog_id}
    */
    readonly catalogId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_data_lake_settings#id DataAwsLakeformationDataLakeSettings#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_data_lake_settings#region DataAwsLakeformationDataLakeSettings#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_data_lake_settings aws_lakeformation_data_lake_settings}
*/
export declare class DataAwsLakeformationDataLakeSettings extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_lakeformation_data_lake_settings";
    /**
    * Generates CDKTN code for importing a DataAwsLakeformationDataLakeSettings resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsLakeformationDataLakeSettings to import
    * @param importFromId The id of the existing DataAwsLakeformationDataLakeSettings that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_data_lake_settings#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsLakeformationDataLakeSettings to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_data_lake_settings aws_lakeformation_data_lake_settings} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsLakeformationDataLakeSettingsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsLakeformationDataLakeSettingsConfig);
    get admins(): string[];
    get allowExternalDataFiltering(): cdktn.IResolvable;
    get allowFullTableExternalDataAccess(): cdktn.IResolvable;
    get authorizedSessionTagValueList(): string[];
    private _catalogId?;
    get catalogId(): string;
    set catalogId(value: string);
    resetCatalogId(): void;
    get catalogIdInput(): string | undefined;
    private _createDatabaseDefaultPermissions;
    get createDatabaseDefaultPermissions(): DataAwsLakeformationDataLakeSettings.CreateDatabaseDefaultPermissionsPropertyList;
    private _createTableDefaultPermissions;
    get createTableDefaultPermissions(): DataAwsLakeformationDataLakeSettings.CreateTableDefaultPermissionsPropertyList;
    get externalDataFilteringAllowList(): string[];
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _parameters;
    get parameters(): cdktn.StringMap;
    get readOnlyAdmins(): string[];
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get trustedResourceOwners(): string[];
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsLakeformationDataLakeSettingsCreateDatabaseDefaultPermissionsPropertyToTerraform(struct?: DataAwsLakeformationDataLakeSettings.CreateDatabaseDefaultPermissionsProperty): any;
export declare function dataAwsLakeformationDataLakeSettingsCreateDatabaseDefaultPermissionsPropertyToHclTerraform(struct?: DataAwsLakeformationDataLakeSettings.CreateDatabaseDefaultPermissionsProperty): any;
export declare function dataAwsLakeformationDataLakeSettingsCreateTableDefaultPermissionsPropertyToTerraform(struct?: DataAwsLakeformationDataLakeSettings.CreateTableDefaultPermissionsProperty): any;
export declare function dataAwsLakeformationDataLakeSettingsCreateTableDefaultPermissionsPropertyToHclTerraform(struct?: DataAwsLakeformationDataLakeSettings.CreateTableDefaultPermissionsProperty): any;
export declare namespace DataAwsLakeformationDataLakeSettings {
    interface CreateDatabaseDefaultPermissionsProperty {
    }
    class CreateDatabaseDefaultPermissionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CreateDatabaseDefaultPermissionsProperty | undefined;
        set internalValue(value: CreateDatabaseDefaultPermissionsProperty | undefined);
        get permissions(): string[];
        get principal(): string;
    }
    class CreateDatabaseDefaultPermissionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CreateDatabaseDefaultPermissionsPropertyOutputReference;
    }
    interface CreateTableDefaultPermissionsProperty {
    }
    class CreateTableDefaultPermissionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CreateTableDefaultPermissionsProperty | undefined;
        set internalValue(value: CreateTableDefaultPermissionsProperty | undefined);
        get permissions(): string[];
        get principal(): string;
    }
    class CreateTableDefaultPermissionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CreateTableDefaultPermissionsPropertyOutputReference;
    }
}
