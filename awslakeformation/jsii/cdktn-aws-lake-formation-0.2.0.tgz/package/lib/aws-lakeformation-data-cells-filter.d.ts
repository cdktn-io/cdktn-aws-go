import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfDataCellsFilterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_cells_filter#region TfDataCellsFilter#region}
    */
    readonly region?: string;
    /**
    * table_data block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_cells_filter#table_data TfDataCellsFilter#table_data}
    */
    readonly tableData?: TfDataCellsFilter.TableDataProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_cells_filter#timeouts TfDataCellsFilter#timeouts}
    */
    readonly timeouts?: TfDataCellsFilter.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_cells_filter aws_lakeformation_data_cells_filter}
*/
export declare class TfDataCellsFilter extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_lakeformation_data_cells_filter";
    /**
    * Generates CDKTN code for importing a TfDataCellsFilter resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfDataCellsFilter to import
    * @param importFromId The id of the existing TfDataCellsFilter that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_cells_filter#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfDataCellsFilter to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_cells_filter aws_lakeformation_data_cells_filter} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfDataCellsFilterConfig = {}
    */
    constructor(scope: Construct, id: string, config?: TfDataCellsFilterConfig);
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tableData;
    get tableData(): TfDataCellsFilter.TableDataPropertyList;
    putTableData(value: TfDataCellsFilter.TableDataProperty[] | cdktn.IResolvable): void;
    resetTableData(): void;
    get tableDataInput(): cdktn.IResolvable | TfDataCellsFilter.TableDataProperty[] | undefined;
    private _timeouts;
    get timeouts(): TfDataCellsFilter.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfDataCellsFilter.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfDataCellsFilter.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfDataCellsFilterColumnWildcardPropertyToTerraform(struct?: TfDataCellsFilter.ColumnWildcardProperty | cdktn.IResolvable): any;
export declare function tfDataCellsFilterColumnWildcardPropertyToHclTerraform(struct?: TfDataCellsFilter.ColumnWildcardProperty | cdktn.IResolvable): any;
export declare function tfDataCellsFilterAllRowsWildcardPropertyToTerraform(struct?: TfDataCellsFilter.AllRowsWildcardProperty | cdktn.IResolvable): any;
export declare function tfDataCellsFilterAllRowsWildcardPropertyToHclTerraform(struct?: TfDataCellsFilter.AllRowsWildcardProperty | cdktn.IResolvable): any;
export declare function tfDataCellsFilterRowFilterPropertyToTerraform(struct?: TfDataCellsFilter.RowFilterProperty | cdktn.IResolvable): any;
export declare function tfDataCellsFilterRowFilterPropertyToHclTerraform(struct?: TfDataCellsFilter.RowFilterProperty | cdktn.IResolvable): any;
export declare function tfDataCellsFilterTableDataPropertyToTerraform(struct?: TfDataCellsFilter.TableDataProperty | cdktn.IResolvable): any;
export declare function tfDataCellsFilterTableDataPropertyToHclTerraform(struct?: TfDataCellsFilter.TableDataProperty | cdktn.IResolvable): any;
export declare function tfDataCellsFilterTimeoutsPropertyToTerraform(struct?: TfDataCellsFilter.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfDataCellsFilterTimeoutsPropertyToHclTerraform(struct?: TfDataCellsFilter.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfDataCellsFilter {
    interface ColumnWildcardProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_cells_filter#excluded_column_names TfDataCellsFilter#excluded_column_names}
        */
        readonly excludedColumnNames?: string[];
    }
    class ColumnWildcardPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ColumnWildcardProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ColumnWildcardProperty | cdktn.IResolvable | undefined);
        private _excludedColumnNames?;
        get excludedColumnNames(): string[];
        set excludedColumnNames(value: string[]);
        resetExcludedColumnNames(): void;
        get excludedColumnNamesInput(): string[] | undefined;
    }
    class ColumnWildcardPropertyList extends cdktn.ComplexList {
        internalValue?: ColumnWildcardProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ColumnWildcardPropertyOutputReference;
    }
    interface AllRowsWildcardProperty {
    }
    class AllRowsWildcardPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AllRowsWildcardProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AllRowsWildcardProperty | cdktn.IResolvable | undefined);
    }
    class AllRowsWildcardPropertyList extends cdktn.ComplexList {
        internalValue?: AllRowsWildcardProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AllRowsWildcardPropertyOutputReference;
    }
    interface RowFilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_cells_filter#filter_expression TfDataCellsFilter#filter_expression}
        */
        readonly filterExpression?: string;
        /**
        * all_rows_wildcard block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_cells_filter#all_rows_wildcard TfDataCellsFilter#all_rows_wildcard}
        */
        readonly allRowsWildcard?: AllRowsWildcardProperty[] | cdktn.IResolvable;
    }
    class RowFilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RowFilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RowFilterProperty | cdktn.IResolvable | undefined);
        private _filterExpression?;
        get filterExpression(): string;
        set filterExpression(value: string);
        resetFilterExpression(): void;
        get filterExpressionInput(): string | undefined;
        private _allRowsWildcard;
        get allRowsWildcard(): AllRowsWildcardPropertyList;
        putAllRowsWildcard(value: AllRowsWildcardProperty[] | cdktn.IResolvable): void;
        resetAllRowsWildcard(): void;
        get allRowsWildcardInput(): cdktn.IResolvable | AllRowsWildcardProperty[] | undefined;
    }
    class RowFilterPropertyList extends cdktn.ComplexList {
        internalValue?: RowFilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RowFilterPropertyOutputReference;
    }
    interface TableDataProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_cells_filter#column_names TfDataCellsFilter#column_names}
        */
        readonly columnNames?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_cells_filter#database_name TfDataCellsFilter#database_name}
        */
        readonly databaseName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_cells_filter#name TfDataCellsFilter#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_cells_filter#table_catalog_id TfDataCellsFilter#table_catalog_id}
        */
        readonly tableCatalogId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_cells_filter#table_name TfDataCellsFilter#table_name}
        */
        readonly tableName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_cells_filter#version_id TfDataCellsFilter#version_id}
        */
        readonly versionId?: string;
        /**
        * column_wildcard block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_cells_filter#column_wildcard TfDataCellsFilter#column_wildcard}
        */
        readonly columnWildcard?: ColumnWildcardProperty[] | cdktn.IResolvable;
        /**
        * row_filter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_cells_filter#row_filter TfDataCellsFilter#row_filter}
        */
        readonly rowFilter?: RowFilterProperty[] | cdktn.IResolvable;
    }
    class TableDataPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TableDataProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TableDataProperty | cdktn.IResolvable | undefined);
        private _columnNames?;
        get columnNames(): string[];
        set columnNames(value: string[]);
        resetColumnNames(): void;
        get columnNamesInput(): string[] | undefined;
        private _databaseName?;
        get databaseName(): string;
        set databaseName(value: string);
        get databaseNameInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _tableCatalogId?;
        get tableCatalogId(): string;
        set tableCatalogId(value: string);
        get tableCatalogIdInput(): string | undefined;
        private _tableName?;
        get tableName(): string;
        set tableName(value: string);
        get tableNameInput(): string | undefined;
        private _versionId?;
        get versionId(): string;
        set versionId(value: string);
        resetVersionId(): void;
        get versionIdInput(): string | undefined;
        private _columnWildcard;
        get columnWildcard(): ColumnWildcardPropertyList;
        putColumnWildcard(value: ColumnWildcardProperty[] | cdktn.IResolvable): void;
        resetColumnWildcard(): void;
        get columnWildcardInput(): cdktn.IResolvable | ColumnWildcardProperty[] | undefined;
        private _rowFilter;
        get rowFilter(): RowFilterPropertyList;
        putRowFilter(value: RowFilterProperty[] | cdktn.IResolvable): void;
        resetRowFilter(): void;
        get rowFilterInput(): cdktn.IResolvable | RowFilterProperty[] | undefined;
    }
    class TableDataPropertyList extends cdktn.ComplexList {
        internalValue?: TableDataProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TableDataPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_data_cells_filter#create TfDataCellsFilter#create}
        */
        readonly create?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
    }
}
