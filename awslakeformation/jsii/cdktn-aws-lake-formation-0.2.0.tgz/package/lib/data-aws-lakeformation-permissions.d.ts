import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfPermissionsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#catalog_id DataTfPermissions#catalog_id}
    */
    readonly catalogId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#catalog_resource DataTfPermissions#catalog_resource}
    */
    readonly catalogResource?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#id DataTfPermissions#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#principal DataTfPermissions#principal}
    */
    readonly principal: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#region DataTfPermissions#region}
    */
    readonly region?: string;
    /**
    * data_cells_filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#data_cells_filter DataTfPermissions#data_cells_filter}
    */
    readonly dataCellsFilter?: DataTfPermissions.DataCellsFilterProperty;
    /**
    * data_location block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#data_location DataTfPermissions#data_location}
    */
    readonly dataLocation?: DataTfPermissions.DataLocationProperty;
    /**
    * database block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#database DataTfPermissions#database}
    */
    readonly database?: DataTfPermissions.DatabaseProperty;
    /**
    * lf_tag block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#lf_tag DataTfPermissions#lf_tag}
    */
    readonly lfTag?: DataTfPermissions.LfTagProperty;
    /**
    * lf_tag_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#lf_tag_policy DataTfPermissions#lf_tag_policy}
    */
    readonly lfTagPolicy?: DataTfPermissions.LfTagPolicyProperty;
    /**
    * table block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#table DataTfPermissions#table}
    */
    readonly table?: DataTfPermissions.TableProperty;
    /**
    * table_with_columns block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#table_with_columns DataTfPermissions#table_with_columns}
    */
    readonly tableWithColumns?: DataTfPermissions.TableWithColumnsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions aws_lakeformation_permissions}
*/
export declare class DataTfPermissions extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_lakeformation_permissions";
    /**
    * Generates CDKTN code for importing a DataTfPermissions resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfPermissions to import
    * @param importFromId The id of the existing DataTfPermissions that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfPermissions to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions aws_lakeformation_permissions} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfPermissionsConfig
    */
    constructor(scope: Construct, id: string, config: DataTfPermissionsConfig);
    private _catalogId?;
    get catalogId(): string;
    set catalogId(value: string);
    resetCatalogId(): void;
    get catalogIdInput(): string | undefined;
    private _catalogResource?;
    get catalogResource(): boolean | cdktn.IResolvable;
    set catalogResource(value: boolean | cdktn.IResolvable);
    resetCatalogResource(): void;
    get catalogResourceInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get permissions(): string[];
    get permissionsWithGrantOption(): string[];
    private _principal?;
    get principal(): string;
    set principal(value: string);
    get principalInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _dataCellsFilter;
    get dataCellsFilter(): DataTfPermissions.DataCellsFilterPropertyOutputReference;
    putDataCellsFilter(value: DataTfPermissions.DataCellsFilterProperty): void;
    resetDataCellsFilter(): void;
    get dataCellsFilterInput(): DataTfPermissions.DataCellsFilterProperty | undefined;
    private _dataLocation;
    get dataLocation(): DataTfPermissions.DataLocationPropertyOutputReference;
    putDataLocation(value: DataTfPermissions.DataLocationProperty): void;
    resetDataLocation(): void;
    get dataLocationInput(): DataTfPermissions.DataLocationProperty | undefined;
    private _database;
    get database(): DataTfPermissions.DatabasePropertyOutputReference;
    putDatabase(value: DataTfPermissions.DatabaseProperty): void;
    resetDatabase(): void;
    get databaseInput(): DataTfPermissions.DatabaseProperty | undefined;
    private _lfTag;
    get lfTag(): DataTfPermissions.LfTagPropertyOutputReference;
    putLfTag(value: DataTfPermissions.LfTagProperty): void;
    resetLfTag(): void;
    get lfTagInput(): DataTfPermissions.LfTagProperty | undefined;
    private _lfTagPolicy;
    get lfTagPolicy(): DataTfPermissions.LfTagPolicyPropertyOutputReference;
    putLfTagPolicy(value: DataTfPermissions.LfTagPolicyProperty): void;
    resetLfTagPolicy(): void;
    get lfTagPolicyInput(): DataTfPermissions.LfTagPolicyProperty | undefined;
    private _table;
    get table(): DataTfPermissions.TablePropertyOutputReference;
    putTable(value: DataTfPermissions.TableProperty): void;
    resetTable(): void;
    get tableInput(): DataTfPermissions.TableProperty | undefined;
    private _tableWithColumns;
    get tableWithColumns(): DataTfPermissions.TableWithColumnsPropertyOutputReference;
    putTableWithColumns(value: DataTfPermissions.TableWithColumnsProperty): void;
    resetTableWithColumns(): void;
    get tableWithColumnsInput(): DataTfPermissions.TableWithColumnsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfPermissionsDataCellsFilterPropertyToTerraform(struct?: DataTfPermissions.DataCellsFilterPropertyOutputReference | DataTfPermissions.DataCellsFilterProperty): any;
export declare function dataTfPermissionsDataCellsFilterPropertyToHclTerraform(struct?: DataTfPermissions.DataCellsFilterPropertyOutputReference | DataTfPermissions.DataCellsFilterProperty): any;
export declare function dataTfPermissionsDataLocationPropertyToTerraform(struct?: DataTfPermissions.DataLocationPropertyOutputReference | DataTfPermissions.DataLocationProperty): any;
export declare function dataTfPermissionsDataLocationPropertyToHclTerraform(struct?: DataTfPermissions.DataLocationPropertyOutputReference | DataTfPermissions.DataLocationProperty): any;
export declare function dataTfPermissionsDatabasePropertyToTerraform(struct?: DataTfPermissions.DatabasePropertyOutputReference | DataTfPermissions.DatabaseProperty): any;
export declare function dataTfPermissionsDatabasePropertyToHclTerraform(struct?: DataTfPermissions.DatabasePropertyOutputReference | DataTfPermissions.DatabaseProperty): any;
export declare function dataTfPermissionsLfTagPropertyToTerraform(struct?: DataTfPermissions.LfTagPropertyOutputReference | DataTfPermissions.LfTagProperty): any;
export declare function dataTfPermissionsLfTagPropertyToHclTerraform(struct?: DataTfPermissions.LfTagPropertyOutputReference | DataTfPermissions.LfTagProperty): any;
export declare function dataTfPermissionsExpressionPropertyToTerraform(struct?: DataTfPermissions.ExpressionProperty | cdktn.IResolvable): any;
export declare function dataTfPermissionsExpressionPropertyToHclTerraform(struct?: DataTfPermissions.ExpressionProperty | cdktn.IResolvable): any;
export declare function dataTfPermissionsLfTagPolicyPropertyToTerraform(struct?: DataTfPermissions.LfTagPolicyPropertyOutputReference | DataTfPermissions.LfTagPolicyProperty): any;
export declare function dataTfPermissionsLfTagPolicyPropertyToHclTerraform(struct?: DataTfPermissions.LfTagPolicyPropertyOutputReference | DataTfPermissions.LfTagPolicyProperty): any;
export declare function dataTfPermissionsTablePropertyToTerraform(struct?: DataTfPermissions.TablePropertyOutputReference | DataTfPermissions.TableProperty): any;
export declare function dataTfPermissionsTablePropertyToHclTerraform(struct?: DataTfPermissions.TablePropertyOutputReference | DataTfPermissions.TableProperty): any;
export declare function dataTfPermissionsTableWithColumnsPropertyToTerraform(struct?: DataTfPermissions.TableWithColumnsPropertyOutputReference | DataTfPermissions.TableWithColumnsProperty): any;
export declare function dataTfPermissionsTableWithColumnsPropertyToHclTerraform(struct?: DataTfPermissions.TableWithColumnsPropertyOutputReference | DataTfPermissions.TableWithColumnsProperty): any;
export declare namespace DataTfPermissions {
    interface DataCellsFilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#database_name DataTfPermissions#database_name}
        */
        readonly databaseName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#name DataTfPermissions#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#table_catalog_id DataTfPermissions#table_catalog_id}
        */
        readonly tableCatalogId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#table_name DataTfPermissions#table_name}
        */
        readonly tableName: string;
    }
    class DataCellsFilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DataCellsFilterProperty | undefined;
        set internalValue(value: DataCellsFilterProperty | undefined);
        private _databaseName?;
        get databaseName(): string;
        set databaseName(value: string);
        get databaseNameInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _tableCatalogId?;
        get tableCatalogId(): string;
        set tableCatalogId(value: string);
        get tableCatalogIdInput(): string | undefined;
        private _tableName?;
        get tableName(): string;
        set tableName(value: string);
        get tableNameInput(): string | undefined;
    }
    interface DataLocationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#arn DataTfPermissions#arn}
        */
        readonly arn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#catalog_id DataTfPermissions#catalog_id}
        */
        readonly catalogId?: string;
    }
    class DataLocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DataLocationProperty | undefined;
        set internalValue(value: DataLocationProperty | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
        private _catalogId?;
        get catalogId(): string;
        set catalogId(value: string);
        resetCatalogId(): void;
        get catalogIdInput(): string | undefined;
    }
    interface DatabaseProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#catalog_id DataTfPermissions#catalog_id}
        */
        readonly catalogId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#name DataTfPermissions#name}
        */
        readonly name: string;
    }
    class DatabasePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DatabaseProperty | undefined;
        set internalValue(value: DatabaseProperty | undefined);
        private _catalogId?;
        get catalogId(): string;
        set catalogId(value: string);
        resetCatalogId(): void;
        get catalogIdInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    interface LfTagProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#catalog_id DataTfPermissions#catalog_id}
        */
        readonly catalogId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#key DataTfPermissions#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#values DataTfPermissions#values}
        */
        readonly values: string[];
    }
    class LfTagPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LfTagProperty | undefined;
        set internalValue(value: LfTagProperty | undefined);
        private _catalogId?;
        get catalogId(): string;
        set catalogId(value: string);
        resetCatalogId(): void;
        get catalogIdInput(): string | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    interface ExpressionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#key DataTfPermissions#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#values DataTfPermissions#values}
        */
        readonly values: string[];
    }
    class ExpressionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExpressionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ExpressionProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class ExpressionPropertyList extends cdktn.ComplexList {
        internalValue?: ExpressionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExpressionPropertyOutputReference;
    }
    interface LfTagPolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#catalog_id DataTfPermissions#catalog_id}
        */
        readonly catalogId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#resource_type DataTfPermissions#resource_type}
        */
        readonly resourceType: string;
        /**
        * expression block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#expression DataTfPermissions#expression}
        */
        readonly expression: ExpressionProperty[] | cdktn.IResolvable;
    }
    class LfTagPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LfTagPolicyProperty | undefined;
        set internalValue(value: LfTagPolicyProperty | undefined);
        private _catalogId?;
        get catalogId(): string;
        set catalogId(value: string);
        resetCatalogId(): void;
        get catalogIdInput(): string | undefined;
        private _resourceType?;
        get resourceType(): string;
        set resourceType(value: string);
        get resourceTypeInput(): string | undefined;
        private _expression;
        get expression(): ExpressionPropertyList;
        putExpression(value: ExpressionProperty[] | cdktn.IResolvable): void;
        get expressionInput(): cdktn.IResolvable | ExpressionProperty[] | undefined;
    }
    interface TableProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#catalog_id DataTfPermissions#catalog_id}
        */
        readonly catalogId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#database_name DataTfPermissions#database_name}
        */
        readonly databaseName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#name DataTfPermissions#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#wildcard DataTfPermissions#wildcard}
        */
        readonly wildcard?: boolean | cdktn.IResolvable;
    }
    class TablePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TableProperty | undefined;
        set internalValue(value: TableProperty | undefined);
        private _catalogId?;
        get catalogId(): string;
        set catalogId(value: string);
        resetCatalogId(): void;
        get catalogIdInput(): string | undefined;
        private _databaseName?;
        get databaseName(): string;
        set databaseName(value: string);
        get databaseNameInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _wildcard?;
        get wildcard(): boolean | cdktn.IResolvable;
        set wildcard(value: boolean | cdktn.IResolvable);
        resetWildcard(): void;
        get wildcardInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface TableWithColumnsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#catalog_id DataTfPermissions#catalog_id}
        */
        readonly catalogId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#column_names DataTfPermissions#column_names}
        */
        readonly columnNames?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#database_name DataTfPermissions#database_name}
        */
        readonly databaseName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#excluded_column_names DataTfPermissions#excluded_column_names}
        */
        readonly excludedColumnNames?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#name DataTfPermissions#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#wildcard DataTfPermissions#wildcard}
        */
        readonly wildcard?: boolean | cdktn.IResolvable;
    }
    class TableWithColumnsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TableWithColumnsProperty | undefined;
        set internalValue(value: TableWithColumnsProperty | undefined);
        private _catalogId?;
        get catalogId(): string;
        set catalogId(value: string);
        resetCatalogId(): void;
        get catalogIdInput(): string | undefined;
        private _columnNames?;
        get columnNames(): string[];
        set columnNames(value: string[]);
        resetColumnNames(): void;
        get columnNamesInput(): string[] | undefined;
        private _databaseName?;
        get databaseName(): string;
        set databaseName(value: string);
        get databaseNameInput(): string | undefined;
        private _excludedColumnNames?;
        get excludedColumnNames(): string[];
        set excludedColumnNames(value: string[]);
        resetExcludedColumnNames(): void;
        get excludedColumnNamesInput(): string[] | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _wildcard?;
        get wildcard(): boolean | cdktn.IResolvable;
        set wildcard(value: boolean | cdktn.IResolvable);
        resetWildcard(): void;
        get wildcardInput(): boolean | cdktn.IResolvable | undefined;
    }
}
