import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfResourceLfTagConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tag#catalog_id TfResourceLfTag#catalog_id}
    */
    readonly catalogId?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tag#region TfResourceLfTag#region}
    */
    readonly region?: string;
    /**
    * database block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tag#database TfResourceLfTag#database}
    */
    readonly database?: TfResourceLfTag.DatabaseProperty[] | cdktn.IResolvable;
    /**
    * lf_tag block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tag#lf_tag TfResourceLfTag#lf_tag}
    */
    readonly lfTag?: TfResourceLfTag.LfTagProperty[] | cdktn.IResolvable;
    /**
    * table block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tag#table TfResourceLfTag#table}
    */
    readonly table?: TfResourceLfTag.TableProperty[] | cdktn.IResolvable;
    /**
    * table_with_columns block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tag#table_with_columns TfResourceLfTag#table_with_columns}
    */
    readonly tableWithColumns?: TfResourceLfTag.TableWithColumnsProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tag#timeouts TfResourceLfTag#timeouts}
    */
    readonly timeouts?: TfResourceLfTag.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tag aws_lakeformation_resource_lf_tag}
*/
export declare class TfResourceLfTag extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_lakeformation_resource_lf_tag";
    /**
    * Generates CDKTN code for importing a TfResourceLfTag resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfResourceLfTag to import
    * @param importFromId The id of the existing TfResourceLfTag that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tag#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfResourceLfTag to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tag aws_lakeformation_resource_lf_tag} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfResourceLfTagConfig = {}
    */
    constructor(scope: Construct, id: string, config?: TfResourceLfTagConfig);
    private _catalogId?;
    get catalogId(): string;
    set catalogId(value: string);
    resetCatalogId(): void;
    get catalogIdInput(): string | undefined;
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _database;
    get database(): TfResourceLfTag.DatabasePropertyList;
    putDatabase(value: TfResourceLfTag.DatabaseProperty[] | cdktn.IResolvable): void;
    resetDatabase(): void;
    get databaseInput(): cdktn.IResolvable | TfResourceLfTag.DatabaseProperty[] | undefined;
    private _lfTag;
    get lfTag(): TfResourceLfTag.LfTagPropertyList;
    putLfTag(value: TfResourceLfTag.LfTagProperty[] | cdktn.IResolvable): void;
    resetLfTag(): void;
    get lfTagInput(): cdktn.IResolvable | TfResourceLfTag.LfTagProperty[] | undefined;
    private _table;
    get table(): TfResourceLfTag.TablePropertyList;
    putTable(value: TfResourceLfTag.TableProperty[] | cdktn.IResolvable): void;
    resetTable(): void;
    get tableInput(): cdktn.IResolvable | TfResourceLfTag.TableProperty[] | undefined;
    private _tableWithColumns;
    get tableWithColumns(): TfResourceLfTag.TableWithColumnsPropertyList;
    putTableWithColumns(value: TfResourceLfTag.TableWithColumnsProperty[] | cdktn.IResolvable): void;
    resetTableWithColumns(): void;
    get tableWithColumnsInput(): cdktn.IResolvable | TfResourceLfTag.TableWithColumnsProperty[] | undefined;
    private _timeouts;
    get timeouts(): TfResourceLfTag.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfResourceLfTag.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfResourceLfTag.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfResourceLfTagDatabasePropertyToTerraform(struct?: TfResourceLfTag.DatabaseProperty | cdktn.IResolvable): any;
export declare function tfResourceLfTagDatabasePropertyToHclTerraform(struct?: TfResourceLfTag.DatabaseProperty | cdktn.IResolvable): any;
export declare function tfResourceLfTagLfTagPropertyToTerraform(struct?: TfResourceLfTag.LfTagProperty | cdktn.IResolvable): any;
export declare function tfResourceLfTagLfTagPropertyToHclTerraform(struct?: TfResourceLfTag.LfTagProperty | cdktn.IResolvable): any;
export declare function tfResourceLfTagTablePropertyToTerraform(struct?: TfResourceLfTag.TableProperty | cdktn.IResolvable): any;
export declare function tfResourceLfTagTablePropertyToHclTerraform(struct?: TfResourceLfTag.TableProperty | cdktn.IResolvable): any;
export declare function tfResourceLfTagColumnWildcardPropertyToTerraform(struct?: TfResourceLfTag.ColumnWildcardProperty | cdktn.IResolvable): any;
export declare function tfResourceLfTagColumnWildcardPropertyToHclTerraform(struct?: TfResourceLfTag.ColumnWildcardProperty | cdktn.IResolvable): any;
export declare function tfResourceLfTagTableWithColumnsPropertyToTerraform(struct?: TfResourceLfTag.TableWithColumnsProperty | cdktn.IResolvable): any;
export declare function tfResourceLfTagTableWithColumnsPropertyToHclTerraform(struct?: TfResourceLfTag.TableWithColumnsProperty | cdktn.IResolvable): any;
export declare function tfResourceLfTagTimeoutsPropertyToTerraform(struct?: TfResourceLfTag.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfResourceLfTagTimeoutsPropertyToHclTerraform(struct?: TfResourceLfTag.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfResourceLfTag {
    interface DatabaseProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tag#catalog_id TfResourceLfTag#catalog_id}
        */
        readonly catalogId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tag#name TfResourceLfTag#name}
        */
        readonly name: string;
    }
    class DatabasePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DatabaseProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DatabaseProperty | cdktn.IResolvable | undefined);
        private _catalogId?;
        get catalogId(): string;
        set catalogId(value: string);
        resetCatalogId(): void;
        get catalogIdInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    class DatabasePropertyList extends cdktn.ComplexList {
        internalValue?: DatabaseProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DatabasePropertyOutputReference;
    }
    interface LfTagProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tag#catalog_id TfResourceLfTag#catalog_id}
        */
        readonly catalogId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tag#key TfResourceLfTag#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tag#value TfResourceLfTag#value}
        */
        readonly value: string;
    }
    class LfTagPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LfTagProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LfTagProperty | cdktn.IResolvable | undefined);
        private _catalogId?;
        get catalogId(): string;
        set catalogId(value: string);
        resetCatalogId(): void;
        get catalogIdInput(): string | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class LfTagPropertyList extends cdktn.ComplexList {
        internalValue?: LfTagProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LfTagPropertyOutputReference;
    }
    interface TableProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tag#catalog_id TfResourceLfTag#catalog_id}
        */
        readonly catalogId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tag#database_name TfResourceLfTag#database_name}
        */
        readonly databaseName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tag#name TfResourceLfTag#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tag#wildcard TfResourceLfTag#wildcard}
        */
        readonly wildcard?: boolean | cdktn.IResolvable;
    }
    class TablePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TableProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TableProperty | cdktn.IResolvable | undefined);
        private _catalogId?;
        get catalogId(): string;
        set catalogId(value: string);
        resetCatalogId(): void;
        get catalogIdInput(): string | undefined;
        private _databaseName?;
        get databaseName(): string;
        set databaseName(value: string);
        get databaseNameInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _wildcard?;
        get wildcard(): boolean | cdktn.IResolvable;
        set wildcard(value: boolean | cdktn.IResolvable);
        resetWildcard(): void;
        get wildcardInput(): boolean | cdktn.IResolvable | undefined;
    }
    class TablePropertyList extends cdktn.ComplexList {
        internalValue?: TableProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TablePropertyOutputReference;
    }
    interface ColumnWildcardProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tag#excluded_column_names TfResourceLfTag#excluded_column_names}
        */
        readonly excludedColumnNames?: string[];
    }
    class ColumnWildcardPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ColumnWildcardProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ColumnWildcardProperty | cdktn.IResolvable | undefined);
        private _excludedColumnNames?;
        get excludedColumnNames(): string[];
        set excludedColumnNames(value: string[]);
        resetExcludedColumnNames(): void;
        get excludedColumnNamesInput(): string[] | undefined;
    }
    class ColumnWildcardPropertyList extends cdktn.ComplexList {
        internalValue?: ColumnWildcardProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ColumnWildcardPropertyOutputReference;
    }
    interface TableWithColumnsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tag#catalog_id TfResourceLfTag#catalog_id}
        */
        readonly catalogId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tag#column_names TfResourceLfTag#column_names}
        */
        readonly columnNames?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tag#database_name TfResourceLfTag#database_name}
        */
        readonly databaseName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tag#name TfResourceLfTag#name}
        */
        readonly name: string;
        /**
        * column_wildcard block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tag#column_wildcard TfResourceLfTag#column_wildcard}
        */
        readonly columnWildcard?: ColumnWildcardProperty[] | cdktn.IResolvable;
    }
    class TableWithColumnsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TableWithColumnsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TableWithColumnsProperty | cdktn.IResolvable | undefined);
        private _catalogId?;
        get catalogId(): string;
        set catalogId(value: string);
        resetCatalogId(): void;
        get catalogIdInput(): string | undefined;
        private _columnNames?;
        get columnNames(): string[];
        set columnNames(value: string[]);
        resetColumnNames(): void;
        get columnNamesInput(): string[] | undefined;
        private _databaseName?;
        get databaseName(): string;
        set databaseName(value: string);
        get databaseNameInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _columnWildcard;
        get columnWildcard(): ColumnWildcardPropertyList;
        putColumnWildcard(value: ColumnWildcardProperty[] | cdktn.IResolvable): void;
        resetColumnWildcard(): void;
        get columnWildcardInput(): cdktn.IResolvable | ColumnWildcardProperty[] | undefined;
    }
    class TableWithColumnsPropertyList extends cdktn.ComplexList {
        internalValue?: TableWithColumnsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TableWithColumnsPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tag#create TfResourceLfTag#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tag#delete TfResourceLfTag#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
