import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfOptInConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#region TfOptIn#region}
    */
    readonly region?: string;
    /**
    * condition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#condition TfOptIn#condition}
    */
    readonly condition?: TfOptIn.ConditionProperty[] | cdktn.IResolvable;
    /**
    * principal block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#principal TfOptIn#principal}
    */
    readonly principal?: TfOptIn.PrincipalProperty[] | cdktn.IResolvable;
    /**
    * resource_data block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#resource_data TfOptIn#resource_data}
    */
    readonly resourceData?: TfOptIn.ResourceDataProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in aws_lakeformation_opt_in}
*/
export declare class TfOptIn extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_lakeformation_opt_in";
    /**
    * Generates CDKTN code for importing a TfOptIn resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfOptIn to import
    * @param importFromId The id of the existing TfOptIn that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfOptIn to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in aws_lakeformation_opt_in} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfOptInConfig = {}
    */
    constructor(scope: Construct, id: string, config?: TfOptInConfig);
    get lastModified(): string;
    get lastUpdatedBy(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _condition;
    get condition(): TfOptIn.ConditionPropertyList;
    putCondition(value: TfOptIn.ConditionProperty[] | cdktn.IResolvable): void;
    resetCondition(): void;
    get conditionInput(): cdktn.IResolvable | TfOptIn.ConditionProperty[] | undefined;
    private _principal;
    get principal(): TfOptIn.PrincipalPropertyList;
    putPrincipal(value: TfOptIn.PrincipalProperty[] | cdktn.IResolvable): void;
    resetPrincipal(): void;
    get principalInput(): cdktn.IResolvable | TfOptIn.PrincipalProperty[] | undefined;
    private _resourceData;
    get resourceData(): TfOptIn.ResourceDataPropertyList;
    putResourceData(value: TfOptIn.ResourceDataProperty[] | cdktn.IResolvable): void;
    resetResourceData(): void;
    get resourceDataInput(): cdktn.IResolvable | TfOptIn.ResourceDataProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfOptInConditionPropertyToTerraform(struct?: TfOptIn.ConditionProperty | cdktn.IResolvable): any;
export declare function tfOptInConditionPropertyToHclTerraform(struct?: TfOptIn.ConditionProperty | cdktn.IResolvable): any;
export declare function tfOptInPrincipalPropertyToTerraform(struct?: TfOptIn.PrincipalProperty | cdktn.IResolvable): any;
export declare function tfOptInPrincipalPropertyToHclTerraform(struct?: TfOptIn.PrincipalProperty | cdktn.IResolvable): any;
export declare function tfOptInCatalogPropertyToTerraform(struct?: TfOptIn.CatalogProperty | cdktn.IResolvable): any;
export declare function tfOptInCatalogPropertyToHclTerraform(struct?: TfOptIn.CatalogProperty | cdktn.IResolvable): any;
export declare function tfOptInDataCellsFilterPropertyToTerraform(struct?: TfOptIn.DataCellsFilterProperty | cdktn.IResolvable): any;
export declare function tfOptInDataCellsFilterPropertyToHclTerraform(struct?: TfOptIn.DataCellsFilterProperty | cdktn.IResolvable): any;
export declare function tfOptInDataLocationPropertyToTerraform(struct?: TfOptIn.DataLocationProperty | cdktn.IResolvable): any;
export declare function tfOptInDataLocationPropertyToHclTerraform(struct?: TfOptIn.DataLocationProperty | cdktn.IResolvable): any;
export declare function tfOptInDatabasePropertyToTerraform(struct?: TfOptIn.DatabaseProperty | cdktn.IResolvable): any;
export declare function tfOptInDatabasePropertyToHclTerraform(struct?: TfOptIn.DatabaseProperty | cdktn.IResolvable): any;
export declare function tfOptInLfTagPropertyToTerraform(struct?: TfOptIn.LfTagProperty | cdktn.IResolvable): any;
export declare function tfOptInLfTagPropertyToHclTerraform(struct?: TfOptIn.LfTagProperty | cdktn.IResolvable): any;
export declare function tfOptInLfTagExpressionPropertyToTerraform(struct?: TfOptIn.LfTagExpressionProperty | cdktn.IResolvable): any;
export declare function tfOptInLfTagExpressionPropertyToHclTerraform(struct?: TfOptIn.LfTagExpressionProperty | cdktn.IResolvable): any;
export declare function tfOptInLfTagPolicyPropertyToTerraform(struct?: TfOptIn.LfTagPolicyProperty | cdktn.IResolvable): any;
export declare function tfOptInLfTagPolicyPropertyToHclTerraform(struct?: TfOptIn.LfTagPolicyProperty | cdktn.IResolvable): any;
export declare function tfOptInTablePropertyToTerraform(struct?: TfOptIn.TableProperty | cdktn.IResolvable): any;
export declare function tfOptInTablePropertyToHclTerraform(struct?: TfOptIn.TableProperty | cdktn.IResolvable): any;
export declare function tfOptInColumnWildcardPropertyToTerraform(struct?: TfOptIn.ColumnWildcardProperty | cdktn.IResolvable): any;
export declare function tfOptInColumnWildcardPropertyToHclTerraform(struct?: TfOptIn.ColumnWildcardProperty | cdktn.IResolvable): any;
export declare function tfOptInTableWithColumnsPropertyToTerraform(struct?: TfOptIn.TableWithColumnsProperty | cdktn.IResolvable): any;
export declare function tfOptInTableWithColumnsPropertyToHclTerraform(struct?: TfOptIn.TableWithColumnsProperty | cdktn.IResolvable): any;
export declare function tfOptInResourceDataPropertyToTerraform(struct?: TfOptIn.ResourceDataProperty | cdktn.IResolvable): any;
export declare function tfOptInResourceDataPropertyToHclTerraform(struct?: TfOptIn.ResourceDataProperty | cdktn.IResolvable): any;
export declare namespace TfOptIn {
    interface ConditionProperty {
    }
    class ConditionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConditionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConditionProperty | cdktn.IResolvable | undefined);
        get expression(): string;
    }
    class ConditionPropertyList extends cdktn.ComplexList {
        internalValue?: ConditionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConditionPropertyOutputReference;
    }
    interface PrincipalProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#data_lake_principal_identifier TfOptIn#data_lake_principal_identifier}
        */
        readonly dataLakePrincipalIdentifier: string;
    }
    class PrincipalPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PrincipalProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PrincipalProperty | cdktn.IResolvable | undefined);
        private _dataLakePrincipalIdentifier?;
        get dataLakePrincipalIdentifier(): string;
        set dataLakePrincipalIdentifier(value: string);
        get dataLakePrincipalIdentifierInput(): string | undefined;
    }
    class PrincipalPropertyList extends cdktn.ComplexList {
        internalValue?: PrincipalProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PrincipalPropertyOutputReference;
    }
    interface CatalogProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#id TfOptIn#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id?: string;
    }
    class CatalogPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CatalogProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CatalogProperty | cdktn.IResolvable | undefined);
        private _id?;
        get id(): string;
        set id(value: string);
        resetId(): void;
        get idInput(): string | undefined;
    }
    class CatalogPropertyList extends cdktn.ComplexList {
        internalValue?: CatalogProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CatalogPropertyOutputReference;
    }
    interface DataCellsFilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#database_name TfOptIn#database_name}
        */
        readonly databaseName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#name TfOptIn#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#table_catalog_id TfOptIn#table_catalog_id}
        */
        readonly tableCatalogId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#table_name TfOptIn#table_name}
        */
        readonly tableName?: string;
    }
    class DataCellsFilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataCellsFilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DataCellsFilterProperty | cdktn.IResolvable | undefined);
        private _databaseName?;
        get databaseName(): string;
        set databaseName(value: string);
        resetDatabaseName(): void;
        get databaseNameInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _tableCatalogId?;
        get tableCatalogId(): string;
        set tableCatalogId(value: string);
        resetTableCatalogId(): void;
        get tableCatalogIdInput(): string | undefined;
        private _tableName?;
        get tableName(): string;
        set tableName(value: string);
        resetTableName(): void;
        get tableNameInput(): string | undefined;
    }
    class DataCellsFilterPropertyList extends cdktn.ComplexList {
        internalValue?: DataCellsFilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataCellsFilterPropertyOutputReference;
    }
    interface DataLocationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#catalog_id TfOptIn#catalog_id}
        */
        readonly catalogId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#resource_arn TfOptIn#resource_arn}
        */
        readonly resourceArn: string;
    }
    class DataLocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataLocationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DataLocationProperty | cdktn.IResolvable | undefined);
        private _catalogId?;
        get catalogId(): string;
        set catalogId(value: string);
        resetCatalogId(): void;
        get catalogIdInput(): string | undefined;
        private _resourceArn?;
        get resourceArn(): string;
        set resourceArn(value: string);
        get resourceArnInput(): string | undefined;
    }
    class DataLocationPropertyList extends cdktn.ComplexList {
        internalValue?: DataLocationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataLocationPropertyOutputReference;
    }
    interface DatabaseProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#catalog_id TfOptIn#catalog_id}
        */
        readonly catalogId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#name TfOptIn#name}
        */
        readonly name: string;
    }
    class DatabasePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DatabaseProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DatabaseProperty | cdktn.IResolvable | undefined);
        private _catalogId?;
        get catalogId(): string;
        set catalogId(value: string);
        resetCatalogId(): void;
        get catalogIdInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    class DatabasePropertyList extends cdktn.ComplexList {
        internalValue?: DatabaseProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DatabasePropertyOutputReference;
    }
    interface LfTagProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#catalog_id TfOptIn#catalog_id}
        */
        readonly catalogId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#key TfOptIn#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#values TfOptIn#values}
        */
        readonly values: string[];
    }
    class LfTagPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LfTagProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LfTagProperty | cdktn.IResolvable | undefined);
        private _catalogId?;
        get catalogId(): string;
        set catalogId(value: string);
        resetCatalogId(): void;
        get catalogIdInput(): string | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class LfTagPropertyList extends cdktn.ComplexList {
        internalValue?: LfTagProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LfTagPropertyOutputReference;
    }
    interface LfTagExpressionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#catalog_id TfOptIn#catalog_id}
        */
        readonly catalogId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#name TfOptIn#name}
        */
        readonly name: string;
    }
    class LfTagExpressionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LfTagExpressionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LfTagExpressionProperty | cdktn.IResolvable | undefined);
        private _catalogId?;
        get catalogId(): string;
        set catalogId(value: string);
        resetCatalogId(): void;
        get catalogIdInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    class LfTagExpressionPropertyList extends cdktn.ComplexList {
        internalValue?: LfTagExpressionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LfTagExpressionPropertyOutputReference;
    }
    interface LfTagPolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#catalog_id TfOptIn#catalog_id}
        */
        readonly catalogId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#expression TfOptIn#expression}
        */
        readonly expression?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#expression_name TfOptIn#expression_name}
        */
        readonly expressionName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#resource_type TfOptIn#resource_type}
        */
        readonly resourceType: string;
    }
    class LfTagPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LfTagPolicyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LfTagPolicyProperty | cdktn.IResolvable | undefined);
        private _catalogId?;
        get catalogId(): string;
        set catalogId(value: string);
        resetCatalogId(): void;
        get catalogIdInput(): string | undefined;
        private _expression?;
        get expression(): string[];
        set expression(value: string[]);
        resetExpression(): void;
        get expressionInput(): string[] | undefined;
        private _expressionName?;
        get expressionName(): string;
        set expressionName(value: string);
        resetExpressionName(): void;
        get expressionNameInput(): string | undefined;
        private _resourceType?;
        get resourceType(): string;
        set resourceType(value: string);
        get resourceTypeInput(): string | undefined;
    }
    class LfTagPolicyPropertyList extends cdktn.ComplexList {
        internalValue?: LfTagPolicyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LfTagPolicyPropertyOutputReference;
    }
    interface TableProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#catalog_id TfOptIn#catalog_id}
        */
        readonly catalogId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#database_name TfOptIn#database_name}
        */
        readonly databaseName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#name TfOptIn#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#wildcard TfOptIn#wildcard}
        */
        readonly wildcard?: boolean | cdktn.IResolvable;
    }
    class TablePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TableProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TableProperty | cdktn.IResolvable | undefined);
        private _catalogId?;
        get catalogId(): string;
        set catalogId(value: string);
        resetCatalogId(): void;
        get catalogIdInput(): string | undefined;
        private _databaseName?;
        get databaseName(): string;
        set databaseName(value: string);
        get databaseNameInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _wildcard?;
        get wildcard(): boolean | cdktn.IResolvable;
        set wildcard(value: boolean | cdktn.IResolvable);
        resetWildcard(): void;
        get wildcardInput(): boolean | cdktn.IResolvable | undefined;
    }
    class TablePropertyList extends cdktn.ComplexList {
        internalValue?: TableProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TablePropertyOutputReference;
    }
    interface ColumnWildcardProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#excluded_column_names TfOptIn#excluded_column_names}
        */
        readonly excludedColumnNames?: string[];
    }
    class ColumnWildcardPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ColumnWildcardProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ColumnWildcardProperty | cdktn.IResolvable | undefined);
        private _excludedColumnNames?;
        get excludedColumnNames(): string[];
        set excludedColumnNames(value: string[]);
        resetExcludedColumnNames(): void;
        get excludedColumnNamesInput(): string[] | undefined;
    }
    class ColumnWildcardPropertyList extends cdktn.ComplexList {
        internalValue?: ColumnWildcardProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ColumnWildcardPropertyOutputReference;
    }
    interface TableWithColumnsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#catalog_id TfOptIn#catalog_id}
        */
        readonly catalogId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#column_names TfOptIn#column_names}
        */
        readonly columnNames?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#database_name TfOptIn#database_name}
        */
        readonly databaseName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#name TfOptIn#name}
        */
        readonly name: string;
        /**
        * column_wildcard block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#column_wildcard TfOptIn#column_wildcard}
        */
        readonly columnWildcard?: ColumnWildcardProperty[] | cdktn.IResolvable;
    }
    class TableWithColumnsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TableWithColumnsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TableWithColumnsProperty | cdktn.IResolvable | undefined);
        private _catalogId?;
        get catalogId(): string;
        set catalogId(value: string);
        resetCatalogId(): void;
        get catalogIdInput(): string | undefined;
        private _columnNames?;
        get columnNames(): string[];
        set columnNames(value: string[]);
        resetColumnNames(): void;
        get columnNamesInput(): string[] | undefined;
        private _databaseName?;
        get databaseName(): string;
        set databaseName(value: string);
        get databaseNameInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _columnWildcard;
        get columnWildcard(): ColumnWildcardPropertyList;
        putColumnWildcard(value: ColumnWildcardProperty[] | cdktn.IResolvable): void;
        resetColumnWildcard(): void;
        get columnWildcardInput(): cdktn.IResolvable | ColumnWildcardProperty[] | undefined;
    }
    class TableWithColumnsPropertyList extends cdktn.ComplexList {
        internalValue?: TableWithColumnsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TableWithColumnsPropertyOutputReference;
    }
    interface ResourceDataProperty {
        /**
        * catalog block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#catalog TfOptIn#catalog}
        */
        readonly catalog?: CatalogProperty[] | cdktn.IResolvable;
        /**
        * data_cells_filter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#data_cells_filter TfOptIn#data_cells_filter}
        */
        readonly dataCellsFilter?: DataCellsFilterProperty[] | cdktn.IResolvable;
        /**
        * data_location block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#data_location TfOptIn#data_location}
        */
        readonly dataLocation?: DataLocationProperty[] | cdktn.IResolvable;
        /**
        * database block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#database TfOptIn#database}
        */
        readonly database?: DatabaseProperty[] | cdktn.IResolvable;
        /**
        * lf_tag block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#lf_tag TfOptIn#lf_tag}
        */
        readonly lfTag?: LfTagProperty[] | cdktn.IResolvable;
        /**
        * lf_tag_expression block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#lf_tag_expression TfOptIn#lf_tag_expression}
        */
        readonly lfTagExpression?: LfTagExpressionProperty[] | cdktn.IResolvable;
        /**
        * lf_tag_policy block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#lf_tag_policy TfOptIn#lf_tag_policy}
        */
        readonly lfTagPolicy?: LfTagPolicyProperty[] | cdktn.IResolvable;
        /**
        * table block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#table TfOptIn#table}
        */
        readonly table?: TableProperty[] | cdktn.IResolvable;
        /**
        * table_with_columns block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_opt_in#table_with_columns TfOptIn#table_with_columns}
        */
        readonly tableWithColumns?: TableWithColumnsProperty[] | cdktn.IResolvable;
    }
    class ResourceDataPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceDataProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceDataProperty | cdktn.IResolvable | undefined);
        private _catalog;
        get catalog(): CatalogPropertyList;
        putCatalog(value: CatalogProperty[] | cdktn.IResolvable): void;
        resetCatalog(): void;
        get catalogInput(): cdktn.IResolvable | CatalogProperty[] | undefined;
        private _dataCellsFilter;
        get dataCellsFilter(): DataCellsFilterPropertyList;
        putDataCellsFilter(value: DataCellsFilterProperty[] | cdktn.IResolvable): void;
        resetDataCellsFilter(): void;
        get dataCellsFilterInput(): cdktn.IResolvable | DataCellsFilterProperty[] | undefined;
        private _dataLocation;
        get dataLocation(): DataLocationPropertyList;
        putDataLocation(value: DataLocationProperty[] | cdktn.IResolvable): void;
        resetDataLocation(): void;
        get dataLocationInput(): cdktn.IResolvable | DataLocationProperty[] | undefined;
        private _database;
        get database(): DatabasePropertyList;
        putDatabase(value: DatabaseProperty[] | cdktn.IResolvable): void;
        resetDatabase(): void;
        get databaseInput(): cdktn.IResolvable | DatabaseProperty[] | undefined;
        private _lfTag;
        get lfTag(): LfTagPropertyList;
        putLfTag(value: LfTagProperty[] | cdktn.IResolvable): void;
        resetLfTag(): void;
        get lfTagInput(): cdktn.IResolvable | LfTagProperty[] | undefined;
        private _lfTagExpression;
        get lfTagExpression(): LfTagExpressionPropertyList;
        putLfTagExpression(value: LfTagExpressionProperty[] | cdktn.IResolvable): void;
        resetLfTagExpression(): void;
        get lfTagExpressionInput(): cdktn.IResolvable | LfTagExpressionProperty[] | undefined;
        private _lfTagPolicy;
        get lfTagPolicy(): LfTagPolicyPropertyList;
        putLfTagPolicy(value: LfTagPolicyProperty[] | cdktn.IResolvable): void;
        resetLfTagPolicy(): void;
        get lfTagPolicyInput(): cdktn.IResolvable | LfTagPolicyProperty[] | undefined;
        private _table;
        get table(): TablePropertyList;
        putTable(value: TableProperty[] | cdktn.IResolvable): void;
        resetTable(): void;
        get tableInput(): cdktn.IResolvable | TableProperty[] | undefined;
        private _tableWithColumns;
        get tableWithColumns(): TableWithColumnsPropertyList;
        putTableWithColumns(value: TableWithColumnsProperty[] | cdktn.IResolvable): void;
        resetTableWithColumns(): void;
        get tableWithColumnsInput(): cdktn.IResolvable | TableWithColumnsProperty[] | undefined;
    }
    class ResourceDataPropertyList extends cdktn.ComplexList {
        internalValue?: ResourceDataProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceDataPropertyOutputReference;
    }
}
