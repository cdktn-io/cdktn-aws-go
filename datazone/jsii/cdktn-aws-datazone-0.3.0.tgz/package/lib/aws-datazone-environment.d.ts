import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsEnvironmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_environment#account_identifier AwsEnvironment#account_identifier}
    */
    readonly accountIdentifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_environment#account_region AwsEnvironment#account_region}
    */
    readonly accountRegion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_environment#blueprint_identifier AwsEnvironment#blueprint_identifier}
    */
    readonly blueprintIdentifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_environment#description AwsEnvironment#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_environment#domain_identifier AwsEnvironment#domain_identifier}
    */
    readonly domainIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_environment#glossary_terms AwsEnvironment#glossary_terms}
    */
    readonly glossaryTerms?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_environment#name AwsEnvironment#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_environment#profile_identifier AwsEnvironment#profile_identifier}
    */
    readonly profileIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_environment#project_identifier AwsEnvironment#project_identifier}
    */
    readonly projectIdentifier: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_environment#region AwsEnvironment#region}
    */
    readonly region?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_environment#timeouts AwsEnvironment#timeouts}
    */
    readonly timeouts?: AwsEnvironment.TimeoutsProperty;
    /**
    * user_parameters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_environment#user_parameters AwsEnvironment#user_parameters}
    */
    readonly userParameters?: AwsEnvironment.UserParametersProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_environment aws_datazone_environment}
*/
export declare class AwsEnvironment extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_datazone_environment";
    /**
    * Generates CDKTN code for importing a AwsEnvironment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsEnvironment to import
    * @param importFromId The id of the existing AwsEnvironment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_environment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsEnvironment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_environment aws_datazone_environment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsEnvironmentConfig
    */
    constructor(scope: Construct, id: string, config: AwsEnvironmentConfig);
    private _accountIdentifier?;
    get accountIdentifier(): string;
    set accountIdentifier(value: string);
    resetAccountIdentifier(): void;
    get accountIdentifierInput(): string | undefined;
    private _accountRegion?;
    get accountRegion(): string;
    set accountRegion(value: string);
    resetAccountRegion(): void;
    get accountRegionInput(): string | undefined;
    private _blueprintIdentifier?;
    get blueprintIdentifier(): string;
    set blueprintIdentifier(value: string);
    resetBlueprintIdentifier(): void;
    get blueprintIdentifierInput(): string | undefined;
    get createdAt(): string;
    get createdBy(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _domainIdentifier?;
    get domainIdentifier(): string;
    set domainIdentifier(value: string);
    get domainIdentifierInput(): string | undefined;
    private _glossaryTerms?;
    get glossaryTerms(): string[];
    set glossaryTerms(value: string[]);
    resetGlossaryTerms(): void;
    get glossaryTermsInput(): string[] | undefined;
    get id(): string;
    private _lastDeployment;
    get lastDeployment(): AwsEnvironment.LastDeploymentPropertyList;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _profileIdentifier?;
    get profileIdentifier(): string;
    set profileIdentifier(value: string);
    get profileIdentifierInput(): string | undefined;
    private _projectIdentifier?;
    get projectIdentifier(): string;
    set projectIdentifier(value: string);
    get projectIdentifierInput(): string | undefined;
    get providerEnvironment(): string;
    private _provisionedResources;
    get provisionedResources(): AwsEnvironment.ProvisionedResourcesPropertyList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _timeouts;
    get timeouts(): AwsEnvironment.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsEnvironment.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsEnvironment.TimeoutsProperty | undefined;
    private _userParameters;
    get userParameters(): AwsEnvironment.UserParametersPropertyList;
    putUserParameters(value: AwsEnvironment.UserParametersProperty[] | cdktn.IResolvable): void;
    resetUserParameters(): void;
    get userParametersInput(): cdktn.IResolvable | AwsEnvironment.UserParametersProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsEnvironmentFailureReasonsPropertyToTerraform(struct?: AwsEnvironment.FailureReasonsProperty): any;
export declare function awsEnvironmentFailureReasonsPropertyToHclTerraform(struct?: AwsEnvironment.FailureReasonsProperty): any;
export declare function awsEnvironmentLastDeploymentPropertyToTerraform(struct?: AwsEnvironment.LastDeploymentProperty): any;
export declare function awsEnvironmentLastDeploymentPropertyToHclTerraform(struct?: AwsEnvironment.LastDeploymentProperty): any;
export declare function awsEnvironmentProvisionedResourcesPropertyToTerraform(struct?: AwsEnvironment.ProvisionedResourcesProperty): any;
export declare function awsEnvironmentProvisionedResourcesPropertyToHclTerraform(struct?: AwsEnvironment.ProvisionedResourcesProperty): any;
export declare function awsEnvironmentTimeoutsPropertyToTerraform(struct?: AwsEnvironment.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsEnvironmentTimeoutsPropertyToHclTerraform(struct?: AwsEnvironment.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsEnvironmentUserParametersPropertyToTerraform(struct?: AwsEnvironment.UserParametersProperty | cdktn.IResolvable): any;
export declare function awsEnvironmentUserParametersPropertyToHclTerraform(struct?: AwsEnvironment.UserParametersProperty | cdktn.IResolvable): any;
export declare namespace AwsEnvironment {
    interface FailureReasonsProperty {
    }
    class FailureReasonsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FailureReasonsProperty | undefined;
        set internalValue(value: FailureReasonsProperty | undefined);
        get code(): string;
        get message(): string;
    }
    class FailureReasonsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FailureReasonsPropertyOutputReference;
    }
    interface LastDeploymentProperty {
    }
    class LastDeploymentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LastDeploymentProperty | undefined;
        set internalValue(value: LastDeploymentProperty | undefined);
        get deploymentId(): string;
        get deploymentStatus(): string;
        get deploymentType(): string;
        private _failureReasons;
        get failureReasons(): FailureReasonsPropertyList;
        get isDeploymentComplete(): cdktn.IResolvable;
        get messages(): string[];
    }
    class LastDeploymentPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LastDeploymentPropertyOutputReference;
    }
    interface ProvisionedResourcesProperty {
    }
    class ProvisionedResourcesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ProvisionedResourcesProperty | undefined;
        set internalValue(value: ProvisionedResourcesProperty | undefined);
        get name(): string;
        get provider(): string;
        get type(): string;
        get value(): string;
    }
    class ProvisionedResourcesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ProvisionedResourcesPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_environment#create AwsEnvironment#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_environment#delete AwsEnvironment#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_environment#update AwsEnvironment#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface UserParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_environment#name AwsEnvironment#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_environment#value AwsEnvironment#value}
        */
        readonly value?: string;
    }
    class UserParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): UserParametersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: UserParametersProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        resetValue(): void;
        get valueInput(): string | undefined;
    }
    class UserParametersPropertyList extends cdktn.ComplexList {
        internalValue?: UserParametersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): UserParametersPropertyOutputReference;
    }
}
