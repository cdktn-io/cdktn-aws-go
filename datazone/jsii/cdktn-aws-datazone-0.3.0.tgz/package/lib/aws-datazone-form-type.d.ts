import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsFormTypeConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_form_type#description AwsFormType#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_form_type#domain_identifier AwsFormType#domain_identifier}
    */
    readonly domainIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_form_type#name AwsFormType#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_form_type#owning_project_identifier AwsFormType#owning_project_identifier}
    */
    readonly owningProjectIdentifier: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_form_type#region AwsFormType#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_form_type#status AwsFormType#status}
    */
    readonly status?: string;
    /**
    * model block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_form_type#model AwsFormType#model}
    */
    readonly model?: AwsFormType.ModelProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_form_type#timeouts AwsFormType#timeouts}
    */
    readonly timeouts?: AwsFormType.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_form_type aws_datazone_form_type}
*/
export declare class AwsFormType extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_datazone_form_type";
    /**
    * Generates CDKTN code for importing a AwsFormType resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsFormType to import
    * @param importFromId The id of the existing AwsFormType that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_form_type#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsFormType to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_form_type aws_datazone_form_type} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsFormTypeConfig
    */
    constructor(scope: Construct, id: string, config: AwsFormTypeConfig);
    get createdAt(): string;
    get createdBy(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _domainIdentifier?;
    get domainIdentifier(): string;
    set domainIdentifier(value: string);
    get domainIdentifierInput(): string | undefined;
    private _imports;
    get imports(): AwsFormType.ImportsPropertyList;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get originDomainId(): string;
    get originProjectId(): string;
    private _owningProjectIdentifier?;
    get owningProjectIdentifier(): string;
    set owningProjectIdentifier(value: string);
    get owningProjectIdentifierInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get revision(): string;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _model;
    get model(): AwsFormType.ModelPropertyList;
    putModel(value: AwsFormType.ModelProperty[] | cdktn.IResolvable): void;
    resetModel(): void;
    get modelInput(): cdktn.IResolvable | AwsFormType.ModelProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsFormType.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsFormType.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsFormType.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsFormTypeImportsPropertyToTerraform(struct?: AwsFormType.ImportsProperty): any;
export declare function awsFormTypeImportsPropertyToHclTerraform(struct?: AwsFormType.ImportsProperty): any;
export declare function awsFormTypeModelPropertyToTerraform(struct?: AwsFormType.ModelProperty | cdktn.IResolvable): any;
export declare function awsFormTypeModelPropertyToHclTerraform(struct?: AwsFormType.ModelProperty | cdktn.IResolvable): any;
export declare function awsFormTypeTimeoutsPropertyToTerraform(struct?: AwsFormType.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsFormTypeTimeoutsPropertyToHclTerraform(struct?: AwsFormType.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsFormType {
    interface ImportsProperty {
    }
    class ImportsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ImportsProperty | undefined;
        set internalValue(value: ImportsProperty | undefined);
        get name(): string;
        get revision(): string;
    }
    class ImportsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ImportsPropertyOutputReference;
    }
    interface ModelProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_form_type#smithy AwsFormType#smithy}
        */
        readonly smithy: string;
    }
    class ModelPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ModelProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ModelProperty | cdktn.IResolvable | undefined);
        private _smithy?;
        get smithy(): string;
        set smithy(value: string);
        get smithyInput(): string | undefined;
    }
    class ModelPropertyList extends cdktn.ComplexList {
        internalValue?: ModelProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ModelPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_form_type#create AwsFormType#create}
        */
        readonly create?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
    }
}
