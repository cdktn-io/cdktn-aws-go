import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsEnvironmentBlueprintConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_environment_blueprint_configuration#domain_id AwsEnvironmentBlueprintConfiguration#domain_id}
    */
    readonly domainId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_environment_blueprint_configuration#enabled_regions AwsEnvironmentBlueprintConfiguration#enabled_regions}
    */
    readonly enabledRegions: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_environment_blueprint_configuration#environment_blueprint_id AwsEnvironmentBlueprintConfiguration#environment_blueprint_id}
    */
    readonly environmentBlueprintId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_environment_blueprint_configuration#global_parameters AwsEnvironmentBlueprintConfiguration#global_parameters}
    */
    readonly globalParameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_environment_blueprint_configuration#manage_access_role_arn AwsEnvironmentBlueprintConfiguration#manage_access_role_arn}
    */
    readonly manageAccessRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_environment_blueprint_configuration#provisioning_role_arn AwsEnvironmentBlueprintConfiguration#provisioning_role_arn}
    */
    readonly provisioningRoleArn?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_environment_blueprint_configuration#region AwsEnvironmentBlueprintConfiguration#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_environment_blueprint_configuration#regional_parameters AwsEnvironmentBlueprintConfiguration#regional_parameters}
    */
    readonly regionalParameters?: {
        [key: string]: {
            [key: string]: string;
        };
    } | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_environment_blueprint_configuration aws_datazone_environment_blueprint_configuration}
*/
export declare class AwsEnvironmentBlueprintConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_datazone_environment_blueprint_configuration";
    /**
    * Generates CDKTN code for importing a AwsEnvironmentBlueprintConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsEnvironmentBlueprintConfiguration to import
    * @param importFromId The id of the existing AwsEnvironmentBlueprintConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_environment_blueprint_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsEnvironmentBlueprintConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_environment_blueprint_configuration aws_datazone_environment_blueprint_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsEnvironmentBlueprintConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AwsEnvironmentBlueprintConfigurationConfig);
    private _domainId?;
    get domainId(): string;
    set domainId(value: string);
    get domainIdInput(): string | undefined;
    private _enabledRegions?;
    get enabledRegions(): string[];
    set enabledRegions(value: string[]);
    get enabledRegionsInput(): string[] | undefined;
    private _environmentBlueprintId?;
    get environmentBlueprintId(): string;
    set environmentBlueprintId(value: string);
    get environmentBlueprintIdInput(): string | undefined;
    private _globalParameters?;
    get globalParameters(): {
        [key: string]: string;
    };
    set globalParameters(value: {
        [key: string]: string;
    });
    resetGlobalParameters(): void;
    get globalParametersInput(): {
        [key: string]: string;
    } | undefined;
    private _manageAccessRoleArn?;
    get manageAccessRoleArn(): string;
    set manageAccessRoleArn(value: string);
    resetManageAccessRoleArn(): void;
    get manageAccessRoleArnInput(): string | undefined;
    private _provisioningRoleArn?;
    get provisioningRoleArn(): string;
    set provisioningRoleArn(value: string);
    resetProvisioningRoleArn(): void;
    get provisioningRoleArnInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _regionalParameters?;
    get regionalParameters(): {
        [key: string]: {
            [key: string]: string;
        };
    } | cdktn.IResolvable;
    set regionalParameters(value: {
        [key: string]: {
            [key: string]: string;
        };
    } | cdktn.IResolvable);
    resetRegionalParameters(): void;
    get regionalParametersInput(): cdktn.IResolvable | {
        [key: string]: {
            [key: string]: string;
        };
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
