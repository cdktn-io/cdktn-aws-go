import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsEvidentlyFeatureConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_feature#default_variation AwsEvidentlyFeature#default_variation}
    */
    readonly defaultVariation?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_feature#description AwsEvidentlyFeature#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_feature#entity_overrides AwsEvidentlyFeature#entity_overrides}
    */
    readonly entityOverrides?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_feature#evaluation_strategy AwsEvidentlyFeature#evaluation_strategy}
    */
    readonly evaluationStrategy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_feature#id AwsEvidentlyFeature#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_feature#name AwsEvidentlyFeature#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_feature#project AwsEvidentlyFeature#project}
    */
    readonly project: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_feature#region AwsEvidentlyFeature#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_feature#tags AwsEvidentlyFeature#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_feature#tags_all AwsEvidentlyFeature#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_feature#timeouts AwsEvidentlyFeature#timeouts}
    */
    readonly timeouts?: AwsEvidentlyFeature.TimeoutsProperty;
    /**
    * variations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_feature#variations AwsEvidentlyFeature#variations}
    */
    readonly variations: AwsEvidentlyFeature.VariationsProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_feature aws_evidently_feature}
*/
export declare class AwsEvidentlyFeature extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_evidently_feature";
    /**
    * Generates CDKTN code for importing a AwsEvidentlyFeature resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsEvidentlyFeature to import
    * @param importFromId The id of the existing AwsEvidentlyFeature that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_feature#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsEvidentlyFeature to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_feature aws_evidently_feature} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsEvidentlyFeatureConfig
    */
    constructor(scope: Construct, id: string, config: AwsEvidentlyFeatureConfig);
    get arn(): string;
    get createdTime(): string;
    private _defaultVariation?;
    get defaultVariation(): string;
    set defaultVariation(value: string);
    resetDefaultVariation(): void;
    get defaultVariationInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _entityOverrides?;
    get entityOverrides(): {
        [key: string]: string;
    };
    set entityOverrides(value: {
        [key: string]: string;
    });
    resetEntityOverrides(): void;
    get entityOverridesInput(): {
        [key: string]: string;
    } | undefined;
    private _evaluationRules;
    get evaluationRules(): AwsEvidentlyFeature.EvaluationRulesPropertyList;
    private _evaluationStrategy?;
    get evaluationStrategy(): string;
    set evaluationStrategy(value: string);
    resetEvaluationStrategy(): void;
    get evaluationStrategyInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastUpdatedTime(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get valueType(): string;
    private _timeouts;
    get timeouts(): AwsEvidentlyFeature.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsEvidentlyFeature.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): AwsEvidentlyFeature.TimeoutsProperty | cdktn.IResolvable | undefined;
    private _variations;
    get variations(): AwsEvidentlyFeature.VariationsPropertyList;
    putVariations(value: AwsEvidentlyFeature.VariationsProperty[] | cdktn.IResolvable): void;
    get variationsInput(): cdktn.IResolvable | AwsEvidentlyFeature.VariationsProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsEvidentlyFeatureEvaluationRulesPropertyToTerraform(struct?: AwsEvidentlyFeature.EvaluationRulesProperty): any;
export declare function awsEvidentlyFeatureEvaluationRulesPropertyToHclTerraform(struct?: AwsEvidentlyFeature.EvaluationRulesProperty): any;
export declare function awsEvidentlyFeatureTimeoutsPropertyToTerraform(struct?: AwsEvidentlyFeature.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsEvidentlyFeatureTimeoutsPropertyToHclTerraform(struct?: AwsEvidentlyFeature.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsEvidentlyFeatureValuePropertyToTerraform(struct?: AwsEvidentlyFeature.ValuePropertyOutputReference | AwsEvidentlyFeature.ValueProperty): any;
export declare function awsEvidentlyFeatureValuePropertyToHclTerraform(struct?: AwsEvidentlyFeature.ValuePropertyOutputReference | AwsEvidentlyFeature.ValueProperty): any;
export declare function awsEvidentlyFeatureVariationsPropertyToTerraform(struct?: AwsEvidentlyFeature.VariationsProperty | cdktn.IResolvable): any;
export declare function awsEvidentlyFeatureVariationsPropertyToHclTerraform(struct?: AwsEvidentlyFeature.VariationsProperty | cdktn.IResolvable): any;
export declare namespace AwsEvidentlyFeature {
    interface EvaluationRulesProperty {
    }
    class EvaluationRulesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EvaluationRulesProperty | undefined;
        set internalValue(value: EvaluationRulesProperty | undefined);
        get name(): string;
        get type(): string;
    }
    class EvaluationRulesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EvaluationRulesPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_feature#create AwsEvidentlyFeature#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_feature#delete AwsEvidentlyFeature#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_feature#update AwsEvidentlyFeature#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface ValueProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_feature#bool_value AwsEvidentlyFeature#bool_value}
        */
        readonly boolValue?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_feature#double_value AwsEvidentlyFeature#double_value}
        */
        readonly doubleValue?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_feature#long_value AwsEvidentlyFeature#long_value}
        */
        readonly longValue?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_feature#string_value AwsEvidentlyFeature#string_value}
        */
        readonly stringValue?: string;
    }
    class ValuePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ValueProperty | undefined;
        set internalValue(value: ValueProperty | undefined);
        private _boolValue?;
        get boolValue(): string;
        set boolValue(value: string);
        resetBoolValue(): void;
        get boolValueInput(): string | undefined;
        private _doubleValue?;
        get doubleValue(): string;
        set doubleValue(value: string);
        resetDoubleValue(): void;
        get doubleValueInput(): string | undefined;
        private _longValue?;
        get longValue(): string;
        set longValue(value: string);
        resetLongValue(): void;
        get longValueInput(): string | undefined;
        private _stringValue?;
        get stringValue(): string;
        set stringValue(value: string);
        resetStringValue(): void;
        get stringValueInput(): string | undefined;
    }
    interface VariationsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_feature#name AwsEvidentlyFeature#name}
        */
        readonly name: string;
        /**
        * value block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_feature#value AwsEvidentlyFeature#value}
        */
        readonly value: ValueProperty;
    }
    class VariationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VariationsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VariationsProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value;
        get value(): ValuePropertyOutputReference;
        putValue(value: ValueProperty): void;
        get valueInput(): ValueProperty | undefined;
    }
    class VariationsPropertyList extends cdktn.ComplexList {
        internalValue?: VariationsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VariationsPropertyOutputReference;
    }
}
