import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsEvidentlyLaunchConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#description AwsEvidentlyLaunch#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#id AwsEvidentlyLaunch#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#name AwsEvidentlyLaunch#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#project AwsEvidentlyLaunch#project}
    */
    readonly project: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#randomization_salt AwsEvidentlyLaunch#randomization_salt}
    */
    readonly randomizationSalt?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#region AwsEvidentlyLaunch#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#tags AwsEvidentlyLaunch#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#tags_all AwsEvidentlyLaunch#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * groups block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#groups AwsEvidentlyLaunch#groups}
    */
    readonly groups: AwsEvidentlyLaunch.GroupsProperty[] | cdktn.IResolvable;
    /**
    * metric_monitors block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#metric_monitors AwsEvidentlyLaunch#metric_monitors}
    */
    readonly metricMonitors?: AwsEvidentlyLaunch.MetricMonitorsProperty[] | cdktn.IResolvable;
    /**
    * scheduled_splits_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#scheduled_splits_config AwsEvidentlyLaunch#scheduled_splits_config}
    */
    readonly scheduledSplitsConfig?: AwsEvidentlyLaunch.ScheduledSplitsConfigProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#timeouts AwsEvidentlyLaunch#timeouts}
    */
    readonly timeouts?: AwsEvidentlyLaunch.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch aws_evidently_launch}
*/
export declare class AwsEvidentlyLaunch extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_evidently_launch";
    /**
    * Generates CDKTN code for importing a AwsEvidentlyLaunch resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsEvidentlyLaunch to import
    * @param importFromId The id of the existing AwsEvidentlyLaunch that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsEvidentlyLaunch to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch aws_evidently_launch} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsEvidentlyLaunchConfig
    */
    constructor(scope: Construct, id: string, config: AwsEvidentlyLaunchConfig);
    get arn(): string;
    get createdTime(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _execution;
    get execution(): AwsEvidentlyLaunch.ExecutionPropertyList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastUpdatedTime(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _randomizationSalt?;
    get randomizationSalt(): string;
    set randomizationSalt(value: string);
    resetRandomizationSalt(): void;
    get randomizationSaltInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    get statusReason(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get type(): string;
    private _groups;
    get groups(): AwsEvidentlyLaunch.GroupsPropertyList;
    putGroups(value: AwsEvidentlyLaunch.GroupsProperty[] | cdktn.IResolvable): void;
    get groupsInput(): cdktn.IResolvable | AwsEvidentlyLaunch.GroupsProperty[] | undefined;
    private _metricMonitors;
    get metricMonitors(): AwsEvidentlyLaunch.MetricMonitorsPropertyList;
    putMetricMonitors(value: AwsEvidentlyLaunch.MetricMonitorsProperty[] | cdktn.IResolvable): void;
    resetMetricMonitors(): void;
    get metricMonitorsInput(): cdktn.IResolvable | AwsEvidentlyLaunch.MetricMonitorsProperty[] | undefined;
    private _scheduledSplitsConfig;
    get scheduledSplitsConfig(): AwsEvidentlyLaunch.ScheduledSplitsConfigPropertyOutputReference;
    putScheduledSplitsConfig(value: AwsEvidentlyLaunch.ScheduledSplitsConfigProperty): void;
    resetScheduledSplitsConfig(): void;
    get scheduledSplitsConfigInput(): AwsEvidentlyLaunch.ScheduledSplitsConfigProperty | undefined;
    private _timeouts;
    get timeouts(): AwsEvidentlyLaunch.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsEvidentlyLaunch.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsEvidentlyLaunch.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsEvidentlyLaunchExecutionPropertyToTerraform(struct?: AwsEvidentlyLaunch.ExecutionProperty): any;
export declare function awsEvidentlyLaunchExecutionPropertyToHclTerraform(struct?: AwsEvidentlyLaunch.ExecutionProperty): any;
export declare function awsEvidentlyLaunchGroupsPropertyToTerraform(struct?: AwsEvidentlyLaunch.GroupsProperty | cdktn.IResolvable): any;
export declare function awsEvidentlyLaunchGroupsPropertyToHclTerraform(struct?: AwsEvidentlyLaunch.GroupsProperty | cdktn.IResolvable): any;
export declare function awsEvidentlyLaunchMetricDefinitionPropertyToTerraform(struct?: AwsEvidentlyLaunch.MetricDefinitionPropertyOutputReference | AwsEvidentlyLaunch.MetricDefinitionProperty): any;
export declare function awsEvidentlyLaunchMetricDefinitionPropertyToHclTerraform(struct?: AwsEvidentlyLaunch.MetricDefinitionPropertyOutputReference | AwsEvidentlyLaunch.MetricDefinitionProperty): any;
export declare function awsEvidentlyLaunchMetricMonitorsPropertyToTerraform(struct?: AwsEvidentlyLaunch.MetricMonitorsProperty | cdktn.IResolvable): any;
export declare function awsEvidentlyLaunchMetricMonitorsPropertyToHclTerraform(struct?: AwsEvidentlyLaunch.MetricMonitorsProperty | cdktn.IResolvable): any;
export declare function awsEvidentlyLaunchSegmentOverridesPropertyToTerraform(struct?: AwsEvidentlyLaunch.SegmentOverridesProperty | cdktn.IResolvable): any;
export declare function awsEvidentlyLaunchSegmentOverridesPropertyToHclTerraform(struct?: AwsEvidentlyLaunch.SegmentOverridesProperty | cdktn.IResolvable): any;
export declare function awsEvidentlyLaunchStepsPropertyToTerraform(struct?: AwsEvidentlyLaunch.StepsProperty | cdktn.IResolvable): any;
export declare function awsEvidentlyLaunchStepsPropertyToHclTerraform(struct?: AwsEvidentlyLaunch.StepsProperty | cdktn.IResolvable): any;
export declare function awsEvidentlyLaunchScheduledSplitsConfigPropertyToTerraform(struct?: AwsEvidentlyLaunch.ScheduledSplitsConfigPropertyOutputReference | AwsEvidentlyLaunch.ScheduledSplitsConfigProperty): any;
export declare function awsEvidentlyLaunchScheduledSplitsConfigPropertyToHclTerraform(struct?: AwsEvidentlyLaunch.ScheduledSplitsConfigPropertyOutputReference | AwsEvidentlyLaunch.ScheduledSplitsConfigProperty): any;
export declare function awsEvidentlyLaunchTimeoutsPropertyToTerraform(struct?: AwsEvidentlyLaunch.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsEvidentlyLaunchTimeoutsPropertyToHclTerraform(struct?: AwsEvidentlyLaunch.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsEvidentlyLaunch {
    interface ExecutionProperty {
    }
    class ExecutionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExecutionProperty | undefined;
        set internalValue(value: ExecutionProperty | undefined);
        get endedTime(): string;
        get startedTime(): string;
    }
    class ExecutionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExecutionPropertyOutputReference;
    }
    interface GroupsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#description AwsEvidentlyLaunch#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#feature AwsEvidentlyLaunch#feature}
        */
        readonly feature: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#name AwsEvidentlyLaunch#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#variation AwsEvidentlyLaunch#variation}
        */
        readonly variation: string;
    }
    class GroupsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GroupsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: GroupsProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _feature?;
        get feature(): string;
        set feature(value: string);
        get featureInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _variation?;
        get variation(): string;
        set variation(value: string);
        get variationInput(): string | undefined;
    }
    class GroupsPropertyList extends cdktn.ComplexList {
        internalValue?: GroupsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GroupsPropertyOutputReference;
    }
    interface MetricDefinitionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#entity_id_key AwsEvidentlyLaunch#entity_id_key}
        */
        readonly entityIdKey: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#event_pattern AwsEvidentlyLaunch#event_pattern}
        */
        readonly eventPattern?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#name AwsEvidentlyLaunch#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#unit_label AwsEvidentlyLaunch#unit_label}
        */
        readonly unitLabel?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#value_key AwsEvidentlyLaunch#value_key}
        */
        readonly valueKey: string;
    }
    class MetricDefinitionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MetricDefinitionProperty | undefined;
        set internalValue(value: MetricDefinitionProperty | undefined);
        private _entityIdKey?;
        get entityIdKey(): string;
        set entityIdKey(value: string);
        get entityIdKeyInput(): string | undefined;
        private _eventPattern?;
        get eventPattern(): string;
        set eventPattern(value: string);
        resetEventPattern(): void;
        get eventPatternInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _unitLabel?;
        get unitLabel(): string;
        set unitLabel(value: string);
        resetUnitLabel(): void;
        get unitLabelInput(): string | undefined;
        private _valueKey?;
        get valueKey(): string;
        set valueKey(value: string);
        get valueKeyInput(): string | undefined;
    }
    interface MetricMonitorsProperty {
        /**
        * metric_definition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#metric_definition AwsEvidentlyLaunch#metric_definition}
        */
        readonly metricDefinition: MetricDefinitionProperty;
    }
    class MetricMonitorsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MetricMonitorsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MetricMonitorsProperty | cdktn.IResolvable | undefined);
        private _metricDefinition;
        get metricDefinition(): MetricDefinitionPropertyOutputReference;
        putMetricDefinition(value: MetricDefinitionProperty): void;
        get metricDefinitionInput(): MetricDefinitionProperty | undefined;
    }
    class MetricMonitorsPropertyList extends cdktn.ComplexList {
        internalValue?: MetricMonitorsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MetricMonitorsPropertyOutputReference;
    }
    interface SegmentOverridesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#evaluation_order AwsEvidentlyLaunch#evaluation_order}
        */
        readonly evaluationOrder: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#segment AwsEvidentlyLaunch#segment}
        */
        readonly segment: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#weights AwsEvidentlyLaunch#weights}
        */
        readonly weights: {
            [key: string]: number;
        };
    }
    class SegmentOverridesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SegmentOverridesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SegmentOverridesProperty | cdktn.IResolvable | undefined);
        private _evaluationOrder?;
        get evaluationOrder(): number;
        set evaluationOrder(value: number);
        get evaluationOrderInput(): number | undefined;
        private _segment?;
        get segment(): string;
        set segment(value: string);
        get segmentInput(): string | undefined;
        private _weights?;
        get weights(): {
            [key: string]: number;
        };
        set weights(value: {
            [key: string]: number;
        });
        get weightsInput(): {
            [key: string]: number;
        } | undefined;
    }
    class SegmentOverridesPropertyList extends cdktn.ComplexList {
        internalValue?: SegmentOverridesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SegmentOverridesPropertyOutputReference;
    }
    interface StepsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#group_weights AwsEvidentlyLaunch#group_weights}
        */
        readonly groupWeights: {
            [key: string]: number;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#start_time AwsEvidentlyLaunch#start_time}
        */
        readonly startTime: string;
        /**
        * segment_overrides block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#segment_overrides AwsEvidentlyLaunch#segment_overrides}
        */
        readonly segmentOverrides?: SegmentOverridesProperty[] | cdktn.IResolvable;
    }
    class StepsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StepsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StepsProperty | cdktn.IResolvable | undefined);
        private _groupWeights?;
        get groupWeights(): {
            [key: string]: number;
        };
        set groupWeights(value: {
            [key: string]: number;
        });
        get groupWeightsInput(): {
            [key: string]: number;
        } | undefined;
        private _startTime?;
        get startTime(): string;
        set startTime(value: string);
        get startTimeInput(): string | undefined;
        private _segmentOverrides;
        get segmentOverrides(): SegmentOverridesPropertyList;
        putSegmentOverrides(value: SegmentOverridesProperty[] | cdktn.IResolvable): void;
        resetSegmentOverrides(): void;
        get segmentOverridesInput(): cdktn.IResolvable | SegmentOverridesProperty[] | undefined;
    }
    class StepsPropertyList extends cdktn.ComplexList {
        internalValue?: StepsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StepsPropertyOutputReference;
    }
    interface ScheduledSplitsConfigProperty {
        /**
        * steps block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#steps AwsEvidentlyLaunch#steps}
        */
        readonly steps: StepsProperty[] | cdktn.IResolvable;
    }
    class ScheduledSplitsConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ScheduledSplitsConfigProperty | undefined;
        set internalValue(value: ScheduledSplitsConfigProperty | undefined);
        private _steps;
        get steps(): StepsPropertyList;
        putSteps(value: StepsProperty[] | cdktn.IResolvable): void;
        get stepsInput(): cdktn.IResolvable | StepsProperty[] | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#create AwsEvidentlyLaunch#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#delete AwsEvidentlyLaunch#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#update AwsEvidentlyLaunch#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
