import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsEvidentlyProjectConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_project#description AwsEvidentlyProject#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_project#id AwsEvidentlyProject#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_project#name AwsEvidentlyProject#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_project#region AwsEvidentlyProject#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_project#tags AwsEvidentlyProject#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_project#tags_all AwsEvidentlyProject#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * data_delivery block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_project#data_delivery AwsEvidentlyProject#data_delivery}
    */
    readonly dataDelivery?: AwsEvidentlyProject.DataDeliveryProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_project#timeouts AwsEvidentlyProject#timeouts}
    */
    readonly timeouts?: AwsEvidentlyProject.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_project aws_evidently_project}
*/
export declare class AwsEvidentlyProject extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_evidently_project";
    /**
    * Generates CDKTN code for importing a AwsEvidentlyProject resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsEvidentlyProject to import
    * @param importFromId The id of the existing AwsEvidentlyProject that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_project#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsEvidentlyProject to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_project aws_evidently_project} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsEvidentlyProjectConfig
    */
    constructor(scope: Construct, id: string, config: AwsEvidentlyProjectConfig);
    get activeExperimentCount(): number;
    get activeLaunchCount(): number;
    get arn(): string;
    get createdTime(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get experimentCount(): number;
    get featureCount(): number;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastUpdatedTime(): string;
    get launchCount(): number;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _dataDelivery;
    get dataDelivery(): AwsEvidentlyProject.DataDeliveryPropertyOutputReference;
    putDataDelivery(value: AwsEvidentlyProject.DataDeliveryProperty): void;
    resetDataDelivery(): void;
    get dataDeliveryInput(): AwsEvidentlyProject.DataDeliveryProperty | undefined;
    private _timeouts;
    get timeouts(): AwsEvidentlyProject.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsEvidentlyProject.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsEvidentlyProject.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsEvidentlyProjectCloudwatchLogsPropertyToTerraform(struct?: AwsEvidentlyProject.CloudwatchLogsPropertyOutputReference | AwsEvidentlyProject.CloudwatchLogsProperty): any;
export declare function awsEvidentlyProjectCloudwatchLogsPropertyToHclTerraform(struct?: AwsEvidentlyProject.CloudwatchLogsPropertyOutputReference | AwsEvidentlyProject.CloudwatchLogsProperty): any;
export declare function awsEvidentlyProjectS3DestinationPropertyToTerraform(struct?: AwsEvidentlyProject.S3DestinationPropertyOutputReference | AwsEvidentlyProject.S3DestinationProperty): any;
export declare function awsEvidentlyProjectS3DestinationPropertyToHclTerraform(struct?: AwsEvidentlyProject.S3DestinationPropertyOutputReference | AwsEvidentlyProject.S3DestinationProperty): any;
export declare function awsEvidentlyProjectDataDeliveryPropertyToTerraform(struct?: AwsEvidentlyProject.DataDeliveryPropertyOutputReference | AwsEvidentlyProject.DataDeliveryProperty): any;
export declare function awsEvidentlyProjectDataDeliveryPropertyToHclTerraform(struct?: AwsEvidentlyProject.DataDeliveryPropertyOutputReference | AwsEvidentlyProject.DataDeliveryProperty): any;
export declare function awsEvidentlyProjectTimeoutsPropertyToTerraform(struct?: AwsEvidentlyProject.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsEvidentlyProjectTimeoutsPropertyToHclTerraform(struct?: AwsEvidentlyProject.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsEvidentlyProject {
    interface CloudwatchLogsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_project#log_group AwsEvidentlyProject#log_group}
        */
        readonly logGroup?: string;
    }
    class CloudwatchLogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CloudwatchLogsProperty | undefined;
        set internalValue(value: CloudwatchLogsProperty | undefined);
        private _logGroup?;
        get logGroup(): string;
        set logGroup(value: string);
        resetLogGroup(): void;
        get logGroupInput(): string | undefined;
    }
    interface S3DestinationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_project#bucket AwsEvidentlyProject#bucket}
        */
        readonly bucket?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_project#prefix AwsEvidentlyProject#prefix}
        */
        readonly prefix?: string;
    }
    class S3DestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3DestinationProperty | undefined;
        set internalValue(value: S3DestinationProperty | undefined);
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        resetBucket(): void;
        get bucketInput(): string | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
    }
    interface DataDeliveryProperty {
        /**
        * cloudwatch_logs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_project#cloudwatch_logs AwsEvidentlyProject#cloudwatch_logs}
        */
        readonly cloudwatchLogs?: CloudwatchLogsProperty;
        /**
        * s3_destination block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_project#s3_destination AwsEvidentlyProject#s3_destination}
        */
        readonly s3Destination?: S3DestinationProperty;
    }
    class DataDeliveryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DataDeliveryProperty | undefined;
        set internalValue(value: DataDeliveryProperty | undefined);
        private _cloudwatchLogs;
        get cloudwatchLogs(): CloudwatchLogsPropertyOutputReference;
        putCloudwatchLogs(value: CloudwatchLogsProperty): void;
        resetCloudwatchLogs(): void;
        get cloudwatchLogsInput(): CloudwatchLogsProperty | undefined;
        private _s3Destination;
        get s3Destination(): S3DestinationPropertyOutputReference;
        putS3Destination(value: S3DestinationProperty): void;
        resetS3Destination(): void;
        get s3DestinationInput(): S3DestinationProperty | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_project#create AwsEvidentlyProject#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_project#delete AwsEvidentlyProject#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_project#update AwsEvidentlyProject#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
