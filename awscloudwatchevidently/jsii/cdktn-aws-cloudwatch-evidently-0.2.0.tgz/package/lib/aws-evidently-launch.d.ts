import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfLaunchConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#description TfLaunch#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#id TfLaunch#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#name TfLaunch#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#project TfLaunch#project}
    */
    readonly project: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#randomization_salt TfLaunch#randomization_salt}
    */
    readonly randomizationSalt?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#region TfLaunch#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#tags TfLaunch#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#tags_all TfLaunch#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * groups block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#groups TfLaunch#groups}
    */
    readonly groups: TfLaunch.GroupsProperty[] | cdktn.IResolvable;
    /**
    * metric_monitors block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#metric_monitors TfLaunch#metric_monitors}
    */
    readonly metricMonitors?: TfLaunch.MetricMonitorsProperty[] | cdktn.IResolvable;
    /**
    * scheduled_splits_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#scheduled_splits_config TfLaunch#scheduled_splits_config}
    */
    readonly scheduledSplitsConfig?: TfLaunch.ScheduledSplitsConfigProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#timeouts TfLaunch#timeouts}
    */
    readonly timeouts?: TfLaunch.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch aws_evidently_launch}
*/
export declare class TfLaunch extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_evidently_launch";
    /**
    * Generates CDKTN code for importing a TfLaunch resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfLaunch to import
    * @param importFromId The id of the existing TfLaunch that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfLaunch to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch aws_evidently_launch} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfLaunchConfig
    */
    constructor(scope: Construct, id: string, config: TfLaunchConfig);
    get arn(): string;
    get createdTime(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _execution;
    get execution(): TfLaunch.ExecutionPropertyList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastUpdatedTime(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _randomizationSalt?;
    get randomizationSalt(): string;
    set randomizationSalt(value: string);
    resetRandomizationSalt(): void;
    get randomizationSaltInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    get statusReason(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get type(): string;
    private _groups;
    get groups(): TfLaunch.GroupsPropertyList;
    putGroups(value: TfLaunch.GroupsProperty[] | cdktn.IResolvable): void;
    get groupsInput(): cdktn.IResolvable | TfLaunch.GroupsProperty[] | undefined;
    private _metricMonitors;
    get metricMonitors(): TfLaunch.MetricMonitorsPropertyList;
    putMetricMonitors(value: TfLaunch.MetricMonitorsProperty[] | cdktn.IResolvable): void;
    resetMetricMonitors(): void;
    get metricMonitorsInput(): cdktn.IResolvable | TfLaunch.MetricMonitorsProperty[] | undefined;
    private _scheduledSplitsConfig;
    get scheduledSplitsConfig(): TfLaunch.ScheduledSplitsConfigPropertyOutputReference;
    putScheduledSplitsConfig(value: TfLaunch.ScheduledSplitsConfigProperty): void;
    resetScheduledSplitsConfig(): void;
    get scheduledSplitsConfigInput(): TfLaunch.ScheduledSplitsConfigProperty | undefined;
    private _timeouts;
    get timeouts(): TfLaunch.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfLaunch.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfLaunch.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfLaunchExecutionPropertyToTerraform(struct?: TfLaunch.ExecutionProperty): any;
export declare function tfLaunchExecutionPropertyToHclTerraform(struct?: TfLaunch.ExecutionProperty): any;
export declare function tfLaunchGroupsPropertyToTerraform(struct?: TfLaunch.GroupsProperty | cdktn.IResolvable): any;
export declare function tfLaunchGroupsPropertyToHclTerraform(struct?: TfLaunch.GroupsProperty | cdktn.IResolvable): any;
export declare function tfLaunchMetricDefinitionPropertyToTerraform(struct?: TfLaunch.MetricDefinitionPropertyOutputReference | TfLaunch.MetricDefinitionProperty): any;
export declare function tfLaunchMetricDefinitionPropertyToHclTerraform(struct?: TfLaunch.MetricDefinitionPropertyOutputReference | TfLaunch.MetricDefinitionProperty): any;
export declare function tfLaunchMetricMonitorsPropertyToTerraform(struct?: TfLaunch.MetricMonitorsProperty | cdktn.IResolvable): any;
export declare function tfLaunchMetricMonitorsPropertyToHclTerraform(struct?: TfLaunch.MetricMonitorsProperty | cdktn.IResolvable): any;
export declare function tfLaunchSegmentOverridesPropertyToTerraform(struct?: TfLaunch.SegmentOverridesProperty | cdktn.IResolvable): any;
export declare function tfLaunchSegmentOverridesPropertyToHclTerraform(struct?: TfLaunch.SegmentOverridesProperty | cdktn.IResolvable): any;
export declare function tfLaunchStepsPropertyToTerraform(struct?: TfLaunch.StepsProperty | cdktn.IResolvable): any;
export declare function tfLaunchStepsPropertyToHclTerraform(struct?: TfLaunch.StepsProperty | cdktn.IResolvable): any;
export declare function tfLaunchScheduledSplitsConfigPropertyToTerraform(struct?: TfLaunch.ScheduledSplitsConfigPropertyOutputReference | TfLaunch.ScheduledSplitsConfigProperty): any;
export declare function tfLaunchScheduledSplitsConfigPropertyToHclTerraform(struct?: TfLaunch.ScheduledSplitsConfigPropertyOutputReference | TfLaunch.ScheduledSplitsConfigProperty): any;
export declare function tfLaunchTimeoutsPropertyToTerraform(struct?: TfLaunch.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfLaunchTimeoutsPropertyToHclTerraform(struct?: TfLaunch.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfLaunch {
    interface ExecutionProperty {
    }
    class ExecutionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExecutionProperty | undefined;
        set internalValue(value: ExecutionProperty | undefined);
        get endedTime(): string;
        get startedTime(): string;
    }
    class ExecutionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExecutionPropertyOutputReference;
    }
    interface GroupsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#description TfLaunch#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#feature TfLaunch#feature}
        */
        readonly feature: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#name TfLaunch#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#variation TfLaunch#variation}
        */
        readonly variation: string;
    }
    class GroupsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GroupsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: GroupsProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _feature?;
        get feature(): string;
        set feature(value: string);
        get featureInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _variation?;
        get variation(): string;
        set variation(value: string);
        get variationInput(): string | undefined;
    }
    class GroupsPropertyList extends cdktn.ComplexList {
        internalValue?: GroupsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GroupsPropertyOutputReference;
    }
    interface MetricDefinitionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#entity_id_key TfLaunch#entity_id_key}
        */
        readonly entityIdKey: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#event_pattern TfLaunch#event_pattern}
        */
        readonly eventPattern?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#name TfLaunch#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#unit_label TfLaunch#unit_label}
        */
        readonly unitLabel?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#value_key TfLaunch#value_key}
        */
        readonly valueKey: string;
    }
    class MetricDefinitionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MetricDefinitionProperty | undefined;
        set internalValue(value: MetricDefinitionProperty | undefined);
        private _entityIdKey?;
        get entityIdKey(): string;
        set entityIdKey(value: string);
        get entityIdKeyInput(): string | undefined;
        private _eventPattern?;
        get eventPattern(): string;
        set eventPattern(value: string);
        resetEventPattern(): void;
        get eventPatternInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _unitLabel?;
        get unitLabel(): string;
        set unitLabel(value: string);
        resetUnitLabel(): void;
        get unitLabelInput(): string | undefined;
        private _valueKey?;
        get valueKey(): string;
        set valueKey(value: string);
        get valueKeyInput(): string | undefined;
    }
    interface MetricMonitorsProperty {
        /**
        * metric_definition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#metric_definition TfLaunch#metric_definition}
        */
        readonly metricDefinition: MetricDefinitionProperty;
    }
    class MetricMonitorsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MetricMonitorsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MetricMonitorsProperty | cdktn.IResolvable | undefined);
        private _metricDefinition;
        get metricDefinition(): MetricDefinitionPropertyOutputReference;
        putMetricDefinition(value: MetricDefinitionProperty): void;
        get metricDefinitionInput(): MetricDefinitionProperty | undefined;
    }
    class MetricMonitorsPropertyList extends cdktn.ComplexList {
        internalValue?: MetricMonitorsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MetricMonitorsPropertyOutputReference;
    }
    interface SegmentOverridesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#evaluation_order TfLaunch#evaluation_order}
        */
        readonly evaluationOrder: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#segment TfLaunch#segment}
        */
        readonly segment: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#weights TfLaunch#weights}
        */
        readonly weights: {
            [key: string]: number;
        };
    }
    class SegmentOverridesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SegmentOverridesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SegmentOverridesProperty | cdktn.IResolvable | undefined);
        private _evaluationOrder?;
        get evaluationOrder(): number;
        set evaluationOrder(value: number);
        get evaluationOrderInput(): number | undefined;
        private _segment?;
        get segment(): string;
        set segment(value: string);
        get segmentInput(): string | undefined;
        private _weights?;
        get weights(): {
            [key: string]: number;
        };
        set weights(value: {
            [key: string]: number;
        });
        get weightsInput(): {
            [key: string]: number;
        } | undefined;
    }
    class SegmentOverridesPropertyList extends cdktn.ComplexList {
        internalValue?: SegmentOverridesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SegmentOverridesPropertyOutputReference;
    }
    interface StepsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#group_weights TfLaunch#group_weights}
        */
        readonly groupWeights: {
            [key: string]: number;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#start_time TfLaunch#start_time}
        */
        readonly startTime: string;
        /**
        * segment_overrides block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#segment_overrides TfLaunch#segment_overrides}
        */
        readonly segmentOverrides?: SegmentOverridesProperty[] | cdktn.IResolvable;
    }
    class StepsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StepsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StepsProperty | cdktn.IResolvable | undefined);
        private _groupWeights?;
        get groupWeights(): {
            [key: string]: number;
        };
        set groupWeights(value: {
            [key: string]: number;
        });
        get groupWeightsInput(): {
            [key: string]: number;
        } | undefined;
        private _startTime?;
        get startTime(): string;
        set startTime(value: string);
        get startTimeInput(): string | undefined;
        private _segmentOverrides;
        get segmentOverrides(): SegmentOverridesPropertyList;
        putSegmentOverrides(value: SegmentOverridesProperty[] | cdktn.IResolvable): void;
        resetSegmentOverrides(): void;
        get segmentOverridesInput(): cdktn.IResolvable | SegmentOverridesProperty[] | undefined;
    }
    class StepsPropertyList extends cdktn.ComplexList {
        internalValue?: StepsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StepsPropertyOutputReference;
    }
    interface ScheduledSplitsConfigProperty {
        /**
        * steps block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#steps TfLaunch#steps}
        */
        readonly steps: StepsProperty[] | cdktn.IResolvable;
    }
    class ScheduledSplitsConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ScheduledSplitsConfigProperty | undefined;
        set internalValue(value: ScheduledSplitsConfigProperty | undefined);
        private _steps;
        get steps(): StepsPropertyList;
        putSteps(value: StepsProperty[] | cdktn.IResolvable): void;
        get stepsInput(): cdktn.IResolvable | StepsProperty[] | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#create TfLaunch#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#delete TfLaunch#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#update TfLaunch#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
