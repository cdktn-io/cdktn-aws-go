import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfTableConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamwrite_table#database_name TfTable#database_name}
    */
    readonly databaseName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamwrite_table#id TfTable#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamwrite_table#region TfTable#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamwrite_table#table_name TfTable#table_name}
    */
    readonly tableName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamwrite_table#tags TfTable#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamwrite_table#tags_all TfTable#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * magnetic_store_write_properties block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamwrite_table#magnetic_store_write_properties TfTable#magnetic_store_write_properties}
    */
    readonly magneticStoreWriteProperties?: TfTable.MagneticStoreWritePropertiesProperty;
    /**
    * retention_properties block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamwrite_table#retention_properties TfTable#retention_properties}
    */
    readonly retentionProperties?: TfTable.RetentionPropertiesProperty;
    /**
    * schema block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamwrite_table#schema TfTable#schema}
    */
    readonly schema?: TfTable.SchemaProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamwrite_table aws_timestreamwrite_table}
*/
export declare class TfTable extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_timestreamwrite_table";
    /**
    * Generates CDKTN code for importing a TfTable resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfTable to import
    * @param importFromId The id of the existing TfTable that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamwrite_table#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfTable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamwrite_table aws_timestreamwrite_table} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfTableConfig
    */
    constructor(scope: Construct, id: string, config: TfTableConfig);
    get arn(): string;
    private _databaseName?;
    get databaseName(): string;
    set databaseName(value: string);
    get databaseNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tableName?;
    get tableName(): string;
    set tableName(value: string);
    get tableNameInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _magneticStoreWriteProperties;
    get magneticStoreWriteProperties(): TfTable.MagneticStoreWritePropertiesPropertyOutputReference;
    putMagneticStoreWriteProperties(value: TfTable.MagneticStoreWritePropertiesProperty): void;
    resetMagneticStoreWriteProperties(): void;
    get magneticStoreWritePropertiesInput(): TfTable.MagneticStoreWritePropertiesProperty | undefined;
    private _retentionProperties;
    get retentionProperties(): TfTable.RetentionPropertiesPropertyOutputReference;
    putRetentionProperties(value: TfTable.RetentionPropertiesProperty): void;
    resetRetentionProperties(): void;
    get retentionPropertiesInput(): TfTable.RetentionPropertiesProperty | undefined;
    private _schema;
    get schema(): TfTable.SchemaPropertyOutputReference;
    putSchema(value: TfTable.SchemaProperty): void;
    resetSchema(): void;
    get schemaInput(): TfTable.SchemaProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfTableS3ConfigurationPropertyToTerraform(struct?: TfTable.S3ConfigurationPropertyOutputReference | TfTable.S3ConfigurationProperty): any;
export declare function tfTableS3ConfigurationPropertyToHclTerraform(struct?: TfTable.S3ConfigurationPropertyOutputReference | TfTable.S3ConfigurationProperty): any;
export declare function tfTableMagneticStoreRejectedDataLocationPropertyToTerraform(struct?: TfTable.MagneticStoreRejectedDataLocationPropertyOutputReference | TfTable.MagneticStoreRejectedDataLocationProperty): any;
export declare function tfTableMagneticStoreRejectedDataLocationPropertyToHclTerraform(struct?: TfTable.MagneticStoreRejectedDataLocationPropertyOutputReference | TfTable.MagneticStoreRejectedDataLocationProperty): any;
export declare function tfTableMagneticStoreWritePropertiesPropertyToTerraform(struct?: TfTable.MagneticStoreWritePropertiesPropertyOutputReference | TfTable.MagneticStoreWritePropertiesProperty): any;
export declare function tfTableMagneticStoreWritePropertiesPropertyToHclTerraform(struct?: TfTable.MagneticStoreWritePropertiesPropertyOutputReference | TfTable.MagneticStoreWritePropertiesProperty): any;
export declare function tfTableRetentionPropertiesPropertyToTerraform(struct?: TfTable.RetentionPropertiesPropertyOutputReference | TfTable.RetentionPropertiesProperty): any;
export declare function tfTableRetentionPropertiesPropertyToHclTerraform(struct?: TfTable.RetentionPropertiesPropertyOutputReference | TfTable.RetentionPropertiesProperty): any;
export declare function tfTableCompositePartitionKeyPropertyToTerraform(struct?: TfTable.CompositePartitionKeyPropertyOutputReference | TfTable.CompositePartitionKeyProperty): any;
export declare function tfTableCompositePartitionKeyPropertyToHclTerraform(struct?: TfTable.CompositePartitionKeyPropertyOutputReference | TfTable.CompositePartitionKeyProperty): any;
export declare function tfTableSchemaPropertyToTerraform(struct?: TfTable.SchemaPropertyOutputReference | TfTable.SchemaProperty): any;
export declare function tfTableSchemaPropertyToHclTerraform(struct?: TfTable.SchemaPropertyOutputReference | TfTable.SchemaProperty): any;
export declare namespace TfTable {
    interface S3ConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamwrite_table#bucket_name TfTable#bucket_name}
        */
        readonly bucketName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamwrite_table#encryption_option TfTable#encryption_option}
        */
        readonly encryptionOption?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamwrite_table#kms_key_id TfTable#kms_key_id}
        */
        readonly kmsKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamwrite_table#object_key_prefix TfTable#object_key_prefix}
        */
        readonly objectKeyPrefix?: string;
    }
    class S3ConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3ConfigurationProperty | undefined;
        set internalValue(value: S3ConfigurationProperty | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        resetBucketName(): void;
        get bucketNameInput(): string | undefined;
        private _encryptionOption?;
        get encryptionOption(): string;
        set encryptionOption(value: string);
        resetEncryptionOption(): void;
        get encryptionOptionInput(): string | undefined;
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        resetKmsKeyId(): void;
        get kmsKeyIdInput(): string | undefined;
        private _objectKeyPrefix?;
        get objectKeyPrefix(): string;
        set objectKeyPrefix(value: string);
        resetObjectKeyPrefix(): void;
        get objectKeyPrefixInput(): string | undefined;
    }
    interface MagneticStoreRejectedDataLocationProperty {
        /**
        * s3_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamwrite_table#s3_configuration TfTable#s3_configuration}
        */
        readonly s3Configuration?: S3ConfigurationProperty;
    }
    class MagneticStoreRejectedDataLocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MagneticStoreRejectedDataLocationProperty | undefined;
        set internalValue(value: MagneticStoreRejectedDataLocationProperty | undefined);
        private _s3Configuration;
        get s3Configuration(): S3ConfigurationPropertyOutputReference;
        putS3Configuration(value: S3ConfigurationProperty): void;
        resetS3Configuration(): void;
        get s3ConfigurationInput(): S3ConfigurationProperty | undefined;
    }
    interface MagneticStoreWritePropertiesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamwrite_table#enable_magnetic_store_writes TfTable#enable_magnetic_store_writes}
        */
        readonly enableMagneticStoreWrites?: boolean | cdktn.IResolvable;
        /**
        * magnetic_store_rejected_data_location block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamwrite_table#magnetic_store_rejected_data_location TfTable#magnetic_store_rejected_data_location}
        */
        readonly magneticStoreRejectedDataLocation?: MagneticStoreRejectedDataLocationProperty;
    }
    class MagneticStoreWritePropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MagneticStoreWritePropertiesProperty | undefined;
        set internalValue(value: MagneticStoreWritePropertiesProperty | undefined);
        private _enableMagneticStoreWrites?;
        get enableMagneticStoreWrites(): boolean | cdktn.IResolvable;
        set enableMagneticStoreWrites(value: boolean | cdktn.IResolvable);
        resetEnableMagneticStoreWrites(): void;
        get enableMagneticStoreWritesInput(): boolean | cdktn.IResolvable | undefined;
        private _magneticStoreRejectedDataLocation;
        get magneticStoreRejectedDataLocation(): MagneticStoreRejectedDataLocationPropertyOutputReference;
        putMagneticStoreRejectedDataLocation(value: MagneticStoreRejectedDataLocationProperty): void;
        resetMagneticStoreRejectedDataLocation(): void;
        get magneticStoreRejectedDataLocationInput(): MagneticStoreRejectedDataLocationProperty | undefined;
    }
    interface RetentionPropertiesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamwrite_table#magnetic_store_retention_period_in_days TfTable#magnetic_store_retention_period_in_days}
        */
        readonly magneticStoreRetentionPeriodInDays: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamwrite_table#memory_store_retention_period_in_hours TfTable#memory_store_retention_period_in_hours}
        */
        readonly memoryStoreRetentionPeriodInHours: number;
    }
    class RetentionPropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RetentionPropertiesProperty | undefined;
        set internalValue(value: RetentionPropertiesProperty | undefined);
        private _magneticStoreRetentionPeriodInDays?;
        get magneticStoreRetentionPeriodInDays(): number;
        set magneticStoreRetentionPeriodInDays(value: number);
        get magneticStoreRetentionPeriodInDaysInput(): number | undefined;
        private _memoryStoreRetentionPeriodInHours?;
        get memoryStoreRetentionPeriodInHours(): number;
        set memoryStoreRetentionPeriodInHours(value: number);
        get memoryStoreRetentionPeriodInHoursInput(): number | undefined;
    }
    interface CompositePartitionKeyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamwrite_table#enforcement_in_record TfTable#enforcement_in_record}
        */
        readonly enforcementInRecord?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamwrite_table#name TfTable#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamwrite_table#type TfTable#type}
        */
        readonly type: string;
    }
    class CompositePartitionKeyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CompositePartitionKeyProperty | undefined;
        set internalValue(value: CompositePartitionKeyProperty | undefined);
        private _enforcementInRecord?;
        get enforcementInRecord(): string;
        set enforcementInRecord(value: string);
        resetEnforcementInRecord(): void;
        get enforcementInRecordInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    interface SchemaProperty {
        /**
        * composite_partition_key block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamwrite_table#composite_partition_key TfTable#composite_partition_key}
        */
        readonly compositePartitionKey?: CompositePartitionKeyProperty;
    }
    class SchemaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SchemaProperty | undefined;
        set internalValue(value: SchemaProperty | undefined);
        private _compositePartitionKey;
        get compositePartitionKey(): CompositePartitionKeyPropertyOutputReference;
        putCompositePartitionKey(value: CompositePartitionKeyProperty): void;
        resetCompositePartitionKey(): void;
        get compositePartitionKeyInput(): CompositePartitionKeyProperty | undefined;
    }
}
