import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsTimestreamwriteTableConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/timestreamwrite_table#database_name DataAwsTimestreamwriteTable#database_name}
    */
    readonly databaseName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/timestreamwrite_table#name DataAwsTimestreamwriteTable#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/timestreamwrite_table#region DataAwsTimestreamwriteTable#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/timestreamwrite_table aws_timestreamwrite_table}
*/
export declare class DataAwsTimestreamwriteTable extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_timestreamwrite_table";
    /**
    * Generates CDKTN code for importing a DataAwsTimestreamwriteTable resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsTimestreamwriteTable to import
    * @param importFromId The id of the existing DataAwsTimestreamwriteTable that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/timestreamwrite_table#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsTimestreamwriteTable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/timestreamwrite_table aws_timestreamwrite_table} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsTimestreamwriteTableConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsTimestreamwriteTableConfig);
    get arn(): string;
    get creationTime(): string;
    private _databaseName?;
    get databaseName(): string;
    set databaseName(value: string);
    get databaseNameInput(): string | undefined;
    get lastUpdatedTime(): string;
    private _magneticStoreWriteProperties;
    get magneticStoreWriteProperties(): DataAwsTimestreamwriteTable.MagneticStoreWritePropertiesPropertyList;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _retentionProperties;
    get retentionProperties(): DataAwsTimestreamwriteTable.RetentionPropertiesPropertyList;
    private _schema;
    get schema(): DataAwsTimestreamwriteTable.SchemaPropertyList;
    get tableStatus(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsTimestreamwriteTableS3ConfigurationPropertyToTerraform(struct?: DataAwsTimestreamwriteTable.S3ConfigurationProperty): any;
export declare function dataAwsTimestreamwriteTableS3ConfigurationPropertyToHclTerraform(struct?: DataAwsTimestreamwriteTable.S3ConfigurationProperty): any;
export declare function dataAwsTimestreamwriteTableMagneticStoreRejectedDataLocationPropertyToTerraform(struct?: DataAwsTimestreamwriteTable.MagneticStoreRejectedDataLocationProperty): any;
export declare function dataAwsTimestreamwriteTableMagneticStoreRejectedDataLocationPropertyToHclTerraform(struct?: DataAwsTimestreamwriteTable.MagneticStoreRejectedDataLocationProperty): any;
export declare function dataAwsTimestreamwriteTableMagneticStoreWritePropertiesPropertyToTerraform(struct?: DataAwsTimestreamwriteTable.MagneticStoreWritePropertiesProperty): any;
export declare function dataAwsTimestreamwriteTableMagneticStoreWritePropertiesPropertyToHclTerraform(struct?: DataAwsTimestreamwriteTable.MagneticStoreWritePropertiesProperty): any;
export declare function dataAwsTimestreamwriteTableRetentionPropertiesPropertyToTerraform(struct?: DataAwsTimestreamwriteTable.RetentionPropertiesProperty): any;
export declare function dataAwsTimestreamwriteTableRetentionPropertiesPropertyToHclTerraform(struct?: DataAwsTimestreamwriteTable.RetentionPropertiesProperty): any;
export declare function dataAwsTimestreamwriteTableCompositePartitionKeyPropertyToTerraform(struct?: DataAwsTimestreamwriteTable.CompositePartitionKeyProperty): any;
export declare function dataAwsTimestreamwriteTableCompositePartitionKeyPropertyToHclTerraform(struct?: DataAwsTimestreamwriteTable.CompositePartitionKeyProperty): any;
export declare function dataAwsTimestreamwriteTableSchemaPropertyToTerraform(struct?: DataAwsTimestreamwriteTable.SchemaProperty): any;
export declare function dataAwsTimestreamwriteTableSchemaPropertyToHclTerraform(struct?: DataAwsTimestreamwriteTable.SchemaProperty): any;
export declare namespace DataAwsTimestreamwriteTable {
    interface S3ConfigurationProperty {
    }
    class S3ConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3ConfigurationProperty | undefined;
        set internalValue(value: S3ConfigurationProperty | undefined);
        get bucketName(): string;
        get encryptionOption(): string;
        get kmsKeyId(): string;
        get objectKeyPrefix(): string;
    }
    class S3ConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3ConfigurationPropertyOutputReference;
    }
    interface MagneticStoreRejectedDataLocationProperty {
    }
    class MagneticStoreRejectedDataLocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MagneticStoreRejectedDataLocationProperty | undefined;
        set internalValue(value: MagneticStoreRejectedDataLocationProperty | undefined);
        private _s3Configuration;
        get s3Configuration(): S3ConfigurationPropertyList;
    }
    class MagneticStoreRejectedDataLocationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MagneticStoreRejectedDataLocationPropertyOutputReference;
    }
    interface MagneticStoreWritePropertiesProperty {
    }
    class MagneticStoreWritePropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MagneticStoreWritePropertiesProperty | undefined;
        set internalValue(value: MagneticStoreWritePropertiesProperty | undefined);
        get enableMagneticStoreWrites(): cdktn.IResolvable;
        private _magneticStoreRejectedDataLocation;
        get magneticStoreRejectedDataLocation(): MagneticStoreRejectedDataLocationPropertyList;
    }
    class MagneticStoreWritePropertiesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MagneticStoreWritePropertiesPropertyOutputReference;
    }
    interface RetentionPropertiesProperty {
    }
    class RetentionPropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RetentionPropertiesProperty | undefined;
        set internalValue(value: RetentionPropertiesProperty | undefined);
        get magneticStoreRetentionPeriodInDays(): number;
        get memoryStoreRetentionPeriodInHours(): number;
    }
    class RetentionPropertiesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RetentionPropertiesPropertyOutputReference;
    }
    interface CompositePartitionKeyProperty {
    }
    class CompositePartitionKeyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CompositePartitionKeyProperty | undefined;
        set internalValue(value: CompositePartitionKeyProperty | undefined);
        get enforcementInRecord(): string;
        get name(): string;
        get type(): string;
    }
    class CompositePartitionKeyPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CompositePartitionKeyPropertyOutputReference;
    }
    interface SchemaProperty {
    }
    class SchemaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SchemaProperty | undefined;
        set internalValue(value: SchemaProperty | undefined);
        private _compositePartitionKey;
        get compositePartitionKey(): CompositePartitionKeyPropertyList;
    }
    class SchemaPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SchemaPropertyOutputReference;
    }
}
