import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAppautoscalingTargetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appautoscaling_target#id AwsAppautoscalingTarget#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appautoscaling_target#max_capacity AwsAppautoscalingTarget#max_capacity}
    */
    readonly maxCapacity: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appautoscaling_target#min_capacity AwsAppautoscalingTarget#min_capacity}
    */
    readonly minCapacity: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appautoscaling_target#region AwsAppautoscalingTarget#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appautoscaling_target#resource_id AwsAppautoscalingTarget#resource_id}
    */
    readonly resourceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appautoscaling_target#role_arn AwsAppautoscalingTarget#role_arn}
    */
    readonly roleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appautoscaling_target#scalable_dimension AwsAppautoscalingTarget#scalable_dimension}
    */
    readonly scalableDimension: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appautoscaling_target#service_namespace AwsAppautoscalingTarget#service_namespace}
    */
    readonly serviceNamespace: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appautoscaling_target#tags AwsAppautoscalingTarget#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appautoscaling_target#tags_all AwsAppautoscalingTarget#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * suspended_state block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appautoscaling_target#suspended_state AwsAppautoscalingTarget#suspended_state}
    */
    readonly suspendedState?: AwsAppautoscalingTarget.SuspendedStateProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appautoscaling_target aws_appautoscaling_target}
*/
export declare class AwsAppautoscalingTarget extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_appautoscaling_target";
    /**
    * Generates CDKTN code for importing a AwsAppautoscalingTarget resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsAppautoscalingTarget to import
    * @param importFromId The id of the existing AwsAppautoscalingTarget that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appautoscaling_target#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsAppautoscalingTarget to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appautoscaling_target aws_appautoscaling_target} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAppautoscalingTargetConfig
    */
    constructor(scope: Construct, id: string, config: AwsAppautoscalingTargetConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _maxCapacity?;
    get maxCapacity(): number;
    set maxCapacity(value: number);
    get maxCapacityInput(): number | undefined;
    private _minCapacity?;
    get minCapacity(): number;
    set minCapacity(value: number);
    get minCapacityInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resourceId?;
    get resourceId(): string;
    set resourceId(value: string);
    get resourceIdInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    resetRoleArn(): void;
    get roleArnInput(): string | undefined;
    private _scalableDimension?;
    get scalableDimension(): string;
    set scalableDimension(value: string);
    get scalableDimensionInput(): string | undefined;
    private _serviceNamespace?;
    get serviceNamespace(): string;
    set serviceNamespace(value: string);
    get serviceNamespaceInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _suspendedState;
    get suspendedState(): AwsAppautoscalingTarget.SuspendedStatePropertyOutputReference;
    putSuspendedState(value: AwsAppautoscalingTarget.SuspendedStateProperty): void;
    resetSuspendedState(): void;
    get suspendedStateInput(): AwsAppautoscalingTarget.SuspendedStateProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsAppautoscalingTargetSuspendedStatePropertyToTerraform(struct?: AwsAppautoscalingTarget.SuspendedStatePropertyOutputReference | AwsAppautoscalingTarget.SuspendedStateProperty): any;
export declare function awsAppautoscalingTargetSuspendedStatePropertyToHclTerraform(struct?: AwsAppautoscalingTarget.SuspendedStatePropertyOutputReference | AwsAppautoscalingTarget.SuspendedStateProperty): any;
export declare namespace AwsAppautoscalingTarget {
    interface SuspendedStateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appautoscaling_target#dynamic_scaling_in_suspended AwsAppautoscalingTarget#dynamic_scaling_in_suspended}
        */
        readonly dynamicScalingInSuspended?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appautoscaling_target#dynamic_scaling_out_suspended AwsAppautoscalingTarget#dynamic_scaling_out_suspended}
        */
        readonly dynamicScalingOutSuspended?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appautoscaling_target#scheduled_scaling_suspended AwsAppautoscalingTarget#scheduled_scaling_suspended}
        */
        readonly scheduledScalingSuspended?: boolean | cdktn.IResolvable;
    }
    class SuspendedStatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SuspendedStateProperty | undefined;
        set internalValue(value: SuspendedStateProperty | undefined);
        private _dynamicScalingInSuspended?;
        get dynamicScalingInSuspended(): boolean | cdktn.IResolvable;
        set dynamicScalingInSuspended(value: boolean | cdktn.IResolvable);
        resetDynamicScalingInSuspended(): void;
        get dynamicScalingInSuspendedInput(): boolean | cdktn.IResolvable | undefined;
        private _dynamicScalingOutSuspended?;
        get dynamicScalingOutSuspended(): boolean | cdktn.IResolvable;
        set dynamicScalingOutSuspended(value: boolean | cdktn.IResolvable);
        resetDynamicScalingOutSuspended(): void;
        get dynamicScalingOutSuspendedInput(): boolean | cdktn.IResolvable | undefined;
        private _scheduledScalingSuspended?;
        get scheduledScalingSuspended(): boolean | cdktn.IResolvable;
        set scheduledScalingSuspended(value: boolean | cdktn.IResolvable);
        resetScheduledScalingSuspended(): void;
        get scheduledScalingSuspendedInput(): boolean | cdktn.IResolvable | undefined;
    }
}
