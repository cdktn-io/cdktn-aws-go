import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfGameServerGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_game_server_group#balancing_strategy TfGameServerGroup#balancing_strategy}
    */
    readonly balancingStrategy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_game_server_group#game_server_group_name TfGameServerGroup#game_server_group_name}
    */
    readonly gameServerGroupName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_game_server_group#game_server_protection_policy TfGameServerGroup#game_server_protection_policy}
    */
    readonly gameServerProtectionPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_game_server_group#id TfGameServerGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_game_server_group#max_size TfGameServerGroup#max_size}
    */
    readonly maxSize: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_game_server_group#min_size TfGameServerGroup#min_size}
    */
    readonly minSize: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_game_server_group#region TfGameServerGroup#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_game_server_group#role_arn TfGameServerGroup#role_arn}
    */
    readonly roleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_game_server_group#tags TfGameServerGroup#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_game_server_group#tags_all TfGameServerGroup#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_game_server_group#vpc_subnets TfGameServerGroup#vpc_subnets}
    */
    readonly vpcSubnets?: string[];
    /**
    * auto_scaling_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_game_server_group#auto_scaling_policy TfGameServerGroup#auto_scaling_policy}
    */
    readonly autoScalingPolicy?: TfGameServerGroup.AutoScalingPolicyProperty;
    /**
    * instance_definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_game_server_group#instance_definition TfGameServerGroup#instance_definition}
    */
    readonly instanceDefinition: TfGameServerGroup.InstanceDefinitionProperty[] | cdktn.IResolvable;
    /**
    * launch_template block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_game_server_group#launch_template TfGameServerGroup#launch_template}
    */
    readonly launchTemplate: TfGameServerGroup.LaunchTemplateProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_game_server_group#timeouts TfGameServerGroup#timeouts}
    */
    readonly timeouts?: TfGameServerGroup.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_game_server_group aws_gamelift_game_server_group}
*/
export declare class TfGameServerGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_gamelift_game_server_group";
    /**
    * Generates CDKTN code for importing a TfGameServerGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfGameServerGroup to import
    * @param importFromId The id of the existing TfGameServerGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_game_server_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfGameServerGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_game_server_group aws_gamelift_game_server_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfGameServerGroupConfig
    */
    constructor(scope: Construct, id: string, config: TfGameServerGroupConfig);
    get arn(): string;
    get autoScalingGroupArn(): string;
    private _balancingStrategy?;
    get balancingStrategy(): string;
    set balancingStrategy(value: string);
    resetBalancingStrategy(): void;
    get balancingStrategyInput(): string | undefined;
    private _gameServerGroupName?;
    get gameServerGroupName(): string;
    set gameServerGroupName(value: string);
    get gameServerGroupNameInput(): string | undefined;
    private _gameServerProtectionPolicy?;
    get gameServerProtectionPolicy(): string;
    set gameServerProtectionPolicy(value: string);
    resetGameServerProtectionPolicy(): void;
    get gameServerProtectionPolicyInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _maxSize?;
    get maxSize(): number;
    set maxSize(value: number);
    get maxSizeInput(): number | undefined;
    private _minSize?;
    get minSize(): number;
    set minSize(value: number);
    get minSizeInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _vpcSubnets?;
    get vpcSubnets(): string[];
    set vpcSubnets(value: string[]);
    resetVpcSubnets(): void;
    get vpcSubnetsInput(): string[] | undefined;
    private _autoScalingPolicy;
    get autoScalingPolicy(): TfGameServerGroup.AutoScalingPolicyPropertyOutputReference;
    putAutoScalingPolicy(value: TfGameServerGroup.AutoScalingPolicyProperty): void;
    resetAutoScalingPolicy(): void;
    get autoScalingPolicyInput(): TfGameServerGroup.AutoScalingPolicyProperty | undefined;
    private _instanceDefinition;
    get instanceDefinition(): TfGameServerGroup.InstanceDefinitionPropertyList;
    putInstanceDefinition(value: TfGameServerGroup.InstanceDefinitionProperty[] | cdktn.IResolvable): void;
    get instanceDefinitionInput(): cdktn.IResolvable | TfGameServerGroup.InstanceDefinitionProperty[] | undefined;
    private _launchTemplate;
    get launchTemplate(): TfGameServerGroup.LaunchTemplatePropertyOutputReference;
    putLaunchTemplate(value: TfGameServerGroup.LaunchTemplateProperty): void;
    get launchTemplateInput(): TfGameServerGroup.LaunchTemplateProperty | undefined;
    private _timeouts;
    get timeouts(): TfGameServerGroup.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfGameServerGroup.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfGameServerGroup.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfGameServerGroupTargetTrackingConfigurationPropertyToTerraform(struct?: TfGameServerGroup.TargetTrackingConfigurationPropertyOutputReference | TfGameServerGroup.TargetTrackingConfigurationProperty): any;
export declare function tfGameServerGroupTargetTrackingConfigurationPropertyToHclTerraform(struct?: TfGameServerGroup.TargetTrackingConfigurationPropertyOutputReference | TfGameServerGroup.TargetTrackingConfigurationProperty): any;
export declare function tfGameServerGroupAutoScalingPolicyPropertyToTerraform(struct?: TfGameServerGroup.AutoScalingPolicyPropertyOutputReference | TfGameServerGroup.AutoScalingPolicyProperty): any;
export declare function tfGameServerGroupAutoScalingPolicyPropertyToHclTerraform(struct?: TfGameServerGroup.AutoScalingPolicyPropertyOutputReference | TfGameServerGroup.AutoScalingPolicyProperty): any;
export declare function tfGameServerGroupInstanceDefinitionPropertyToTerraform(struct?: TfGameServerGroup.InstanceDefinitionProperty | cdktn.IResolvable): any;
export declare function tfGameServerGroupInstanceDefinitionPropertyToHclTerraform(struct?: TfGameServerGroup.InstanceDefinitionProperty | cdktn.IResolvable): any;
export declare function tfGameServerGroupLaunchTemplatePropertyToTerraform(struct?: TfGameServerGroup.LaunchTemplatePropertyOutputReference | TfGameServerGroup.LaunchTemplateProperty): any;
export declare function tfGameServerGroupLaunchTemplatePropertyToHclTerraform(struct?: TfGameServerGroup.LaunchTemplatePropertyOutputReference | TfGameServerGroup.LaunchTemplateProperty): any;
export declare function tfGameServerGroupTimeoutsPropertyToTerraform(struct?: TfGameServerGroup.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfGameServerGroupTimeoutsPropertyToHclTerraform(struct?: TfGameServerGroup.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfGameServerGroup {
    interface TargetTrackingConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_game_server_group#target_value TfGameServerGroup#target_value}
        */
        readonly targetValue: number;
    }
    class TargetTrackingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TargetTrackingConfigurationProperty | undefined;
        set internalValue(value: TargetTrackingConfigurationProperty | undefined);
        private _targetValue?;
        get targetValue(): number;
        set targetValue(value: number);
        get targetValueInput(): number | undefined;
    }
    interface AutoScalingPolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_game_server_group#estimated_instance_warmup TfGameServerGroup#estimated_instance_warmup}
        */
        readonly estimatedInstanceWarmup?: number;
        /**
        * target_tracking_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_game_server_group#target_tracking_configuration TfGameServerGroup#target_tracking_configuration}
        */
        readonly targetTrackingConfiguration: TargetTrackingConfigurationProperty;
    }
    class AutoScalingPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AutoScalingPolicyProperty | undefined;
        set internalValue(value: AutoScalingPolicyProperty | undefined);
        private _estimatedInstanceWarmup?;
        get estimatedInstanceWarmup(): number;
        set estimatedInstanceWarmup(value: number);
        resetEstimatedInstanceWarmup(): void;
        get estimatedInstanceWarmupInput(): number | undefined;
        private _targetTrackingConfiguration;
        get targetTrackingConfiguration(): TargetTrackingConfigurationPropertyOutputReference;
        putTargetTrackingConfiguration(value: TargetTrackingConfigurationProperty): void;
        get targetTrackingConfigurationInput(): TargetTrackingConfigurationProperty | undefined;
    }
    interface InstanceDefinitionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_game_server_group#instance_type TfGameServerGroup#instance_type}
        */
        readonly instanceType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_game_server_group#weighted_capacity TfGameServerGroup#weighted_capacity}
        */
        readonly weightedCapacity?: string;
    }
    class InstanceDefinitionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InstanceDefinitionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InstanceDefinitionProperty | cdktn.IResolvable | undefined);
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        get instanceTypeInput(): string | undefined;
        private _weightedCapacity?;
        get weightedCapacity(): string;
        set weightedCapacity(value: string);
        resetWeightedCapacity(): void;
        get weightedCapacityInput(): string | undefined;
    }
    class InstanceDefinitionPropertyList extends cdktn.ComplexList {
        internalValue?: InstanceDefinitionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InstanceDefinitionPropertyOutputReference;
    }
    interface LaunchTemplateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_game_server_group#id TfGameServerGroup#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_game_server_group#name TfGameServerGroup#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_game_server_group#version TfGameServerGroup#version}
        */
        readonly version?: string;
    }
    class LaunchTemplatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LaunchTemplateProperty | undefined;
        set internalValue(value: LaunchTemplateProperty | undefined);
        private _id?;
        get id(): string;
        set id(value: string);
        resetId(): void;
        get idInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _version?;
        get version(): string;
        set version(value: string);
        resetVersion(): void;
        get versionInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_game_server_group#create TfGameServerGroup#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/gamelift_game_server_group#delete TfGameServerGroup#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
