import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsMacsecKeyAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dx_macsec_key_association#cak AwsMacsecKeyAssociation#cak}
    */
    readonly cak?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dx_macsec_key_association#ckn AwsMacsecKeyAssociation#ckn}
    */
    readonly ckn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dx_macsec_key_association#connection_id AwsMacsecKeyAssociation#connection_id}
    */
    readonly connectionId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dx_macsec_key_association#id AwsMacsecKeyAssociation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dx_macsec_key_association#region AwsMacsecKeyAssociation#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dx_macsec_key_association#secret_arn AwsMacsecKeyAssociation#secret_arn}
    */
    readonly secretArn?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dx_macsec_key_association aws_dx_macsec_key_association}
*/
export declare class AwsMacsecKeyAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_dx_macsec_key_association";
    /**
    * Generates CDKTN code for importing a AwsMacsecKeyAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsMacsecKeyAssociation to import
    * @param importFromId The id of the existing AwsMacsecKeyAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dx_macsec_key_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsMacsecKeyAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dx_macsec_key_association aws_dx_macsec_key_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsMacsecKeyAssociationConfig
    */
    constructor(scope: Construct, id: string, config: AwsMacsecKeyAssociationConfig);
    private _cak?;
    get cak(): string;
    set cak(value: string);
    resetCak(): void;
    get cakInput(): string | undefined;
    private _ckn?;
    get ckn(): string;
    set ckn(value: string);
    resetCkn(): void;
    get cknInput(): string | undefined;
    private _connectionId?;
    get connectionId(): string;
    set connectionId(value: string);
    get connectionIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _secretArn?;
    get secretArn(): string;
    set secretArn(value: string);
    resetSecretArn(): void;
    get secretArnInput(): string | undefined;
    get startOn(): string;
    get state(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
