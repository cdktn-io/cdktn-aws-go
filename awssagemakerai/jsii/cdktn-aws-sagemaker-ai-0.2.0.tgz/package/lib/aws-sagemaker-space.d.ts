import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfSpaceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#domain_id TfSpace#domain_id}
    */
    readonly domainId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#id TfSpace#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#region TfSpace#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#space_display_name TfSpace#space_display_name}
    */
    readonly spaceDisplayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#space_name TfSpace#space_name}
    */
    readonly spaceName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#tags TfSpace#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#tags_all TfSpace#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * ownership_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#ownership_settings TfSpace#ownership_settings}
    */
    readonly ownershipSettings?: TfSpace.OwnershipSettingsProperty;
    /**
    * space_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#space_settings TfSpace#space_settings}
    */
    readonly spaceSettings?: TfSpace.SpaceSettingsProperty;
    /**
    * space_sharing_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#space_sharing_settings TfSpace#space_sharing_settings}
    */
    readonly spaceSharingSettings?: TfSpace.SpaceSharingSettingsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space aws_sagemaker_space}
*/
export declare class TfSpace extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_sagemaker_space";
    /**
    * Generates CDKTN code for importing a TfSpace resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfSpace to import
    * @param importFromId The id of the existing TfSpace that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfSpace to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space aws_sagemaker_space} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfSpaceConfig
    */
    constructor(scope: Construct, id: string, config: TfSpaceConfig);
    get arn(): string;
    private _domainId?;
    get domainId(): string;
    set domainId(value: string);
    get domainIdInput(): string | undefined;
    get homeEfsFileSystemUid(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _spaceDisplayName?;
    get spaceDisplayName(): string;
    set spaceDisplayName(value: string);
    resetSpaceDisplayName(): void;
    get spaceDisplayNameInput(): string | undefined;
    private _spaceName?;
    get spaceName(): string;
    set spaceName(value: string);
    get spaceNameInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get url(): string;
    private _ownershipSettings;
    get ownershipSettings(): TfSpace.OwnershipSettingsPropertyOutputReference;
    putOwnershipSettings(value: TfSpace.OwnershipSettingsProperty): void;
    resetOwnershipSettings(): void;
    get ownershipSettingsInput(): TfSpace.OwnershipSettingsProperty | undefined;
    private _spaceSettings;
    get spaceSettings(): TfSpace.SpaceSettingsPropertyOutputReference;
    putSpaceSettings(value: TfSpace.SpaceSettingsProperty): void;
    resetSpaceSettings(): void;
    get spaceSettingsInput(): TfSpace.SpaceSettingsProperty | undefined;
    private _spaceSharingSettings;
    get spaceSharingSettings(): TfSpace.SpaceSharingSettingsPropertyOutputReference;
    putSpaceSharingSettings(value: TfSpace.SpaceSharingSettingsProperty): void;
    resetSpaceSharingSettings(): void;
    get spaceSharingSettingsInput(): TfSpace.SpaceSharingSettingsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfSpaceOwnershipSettingsPropertyToTerraform(struct?: TfSpace.OwnershipSettingsPropertyOutputReference | TfSpace.OwnershipSettingsProperty): any;
export declare function tfSpaceOwnershipSettingsPropertyToHclTerraform(struct?: TfSpace.OwnershipSettingsPropertyOutputReference | TfSpace.OwnershipSettingsProperty): any;
export declare function tfSpaceSpaceSettingsCodeEditorAppSettingsAppLifecycleManagementIdleSettingsPropertyToTerraform(struct?: TfSpace.SpaceSettingsCodeEditorAppSettingsAppLifecycleManagementIdleSettingsPropertyOutputReference | TfSpace.SpaceSettingsCodeEditorAppSettingsAppLifecycleManagementIdleSettingsProperty): any;
export declare function tfSpaceSpaceSettingsCodeEditorAppSettingsAppLifecycleManagementIdleSettingsPropertyToHclTerraform(struct?: TfSpace.SpaceSettingsCodeEditorAppSettingsAppLifecycleManagementIdleSettingsPropertyOutputReference | TfSpace.SpaceSettingsCodeEditorAppSettingsAppLifecycleManagementIdleSettingsProperty): any;
export declare function tfSpaceSpaceSettingsCodeEditorAppSettingsAppLifecycleManagementPropertyToTerraform(struct?: TfSpace.SpaceSettingsCodeEditorAppSettingsAppLifecycleManagementPropertyOutputReference | TfSpace.SpaceSettingsCodeEditorAppSettingsAppLifecycleManagementProperty): any;
export declare function tfSpaceSpaceSettingsCodeEditorAppSettingsAppLifecycleManagementPropertyToHclTerraform(struct?: TfSpace.SpaceSettingsCodeEditorAppSettingsAppLifecycleManagementPropertyOutputReference | TfSpace.SpaceSettingsCodeEditorAppSettingsAppLifecycleManagementProperty): any;
export declare function tfSpaceSpaceSettingsCodeEditorAppSettingsDefaultResourceSpecPropertyToTerraform(struct?: TfSpace.SpaceSettingsCodeEditorAppSettingsDefaultResourceSpecPropertyOutputReference | TfSpace.SpaceSettingsCodeEditorAppSettingsDefaultResourceSpecProperty): any;
export declare function tfSpaceSpaceSettingsCodeEditorAppSettingsDefaultResourceSpecPropertyToHclTerraform(struct?: TfSpace.SpaceSettingsCodeEditorAppSettingsDefaultResourceSpecPropertyOutputReference | TfSpace.SpaceSettingsCodeEditorAppSettingsDefaultResourceSpecProperty): any;
export declare function tfSpaceCodeEditorAppSettingsPropertyToTerraform(struct?: TfSpace.CodeEditorAppSettingsPropertyOutputReference | TfSpace.CodeEditorAppSettingsProperty): any;
export declare function tfSpaceCodeEditorAppSettingsPropertyToHclTerraform(struct?: TfSpace.CodeEditorAppSettingsPropertyOutputReference | TfSpace.CodeEditorAppSettingsProperty): any;
export declare function tfSpaceEfsFileSystemPropertyToTerraform(struct?: TfSpace.EfsFileSystemPropertyOutputReference | TfSpace.EfsFileSystemProperty): any;
export declare function tfSpaceEfsFileSystemPropertyToHclTerraform(struct?: TfSpace.EfsFileSystemPropertyOutputReference | TfSpace.EfsFileSystemProperty): any;
export declare function tfSpaceCustomFileSystemPropertyToTerraform(struct?: TfSpace.CustomFileSystemProperty | cdktn.IResolvable): any;
export declare function tfSpaceCustomFileSystemPropertyToHclTerraform(struct?: TfSpace.CustomFileSystemProperty | cdktn.IResolvable): any;
export declare function tfSpaceSpaceSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsPropertyToTerraform(struct?: TfSpace.SpaceSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsPropertyOutputReference | TfSpace.SpaceSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsProperty): any;
export declare function tfSpaceSpaceSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsPropertyToHclTerraform(struct?: TfSpace.SpaceSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsPropertyOutputReference | TfSpace.SpaceSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsProperty): any;
export declare function tfSpaceSpaceSettingsJupyterLabAppSettingsAppLifecycleManagementPropertyToTerraform(struct?: TfSpace.SpaceSettingsJupyterLabAppSettingsAppLifecycleManagementPropertyOutputReference | TfSpace.SpaceSettingsJupyterLabAppSettingsAppLifecycleManagementProperty): any;
export declare function tfSpaceSpaceSettingsJupyterLabAppSettingsAppLifecycleManagementPropertyToHclTerraform(struct?: TfSpace.SpaceSettingsJupyterLabAppSettingsAppLifecycleManagementPropertyOutputReference | TfSpace.SpaceSettingsJupyterLabAppSettingsAppLifecycleManagementProperty): any;
export declare function tfSpaceSpaceSettingsJupyterLabAppSettingsCodeRepositoryPropertyToTerraform(struct?: TfSpace.SpaceSettingsJupyterLabAppSettingsCodeRepositoryProperty | cdktn.IResolvable): any;
export declare function tfSpaceSpaceSettingsJupyterLabAppSettingsCodeRepositoryPropertyToHclTerraform(struct?: TfSpace.SpaceSettingsJupyterLabAppSettingsCodeRepositoryProperty | cdktn.IResolvable): any;
export declare function tfSpaceSpaceSettingsJupyterLabAppSettingsDefaultResourceSpecPropertyToTerraform(struct?: TfSpace.SpaceSettingsJupyterLabAppSettingsDefaultResourceSpecPropertyOutputReference | TfSpace.SpaceSettingsJupyterLabAppSettingsDefaultResourceSpecProperty): any;
export declare function tfSpaceSpaceSettingsJupyterLabAppSettingsDefaultResourceSpecPropertyToHclTerraform(struct?: TfSpace.SpaceSettingsJupyterLabAppSettingsDefaultResourceSpecPropertyOutputReference | TfSpace.SpaceSettingsJupyterLabAppSettingsDefaultResourceSpecProperty): any;
export declare function tfSpaceJupyterLabAppSettingsPropertyToTerraform(struct?: TfSpace.JupyterLabAppSettingsPropertyOutputReference | TfSpace.JupyterLabAppSettingsProperty): any;
export declare function tfSpaceJupyterLabAppSettingsPropertyToHclTerraform(struct?: TfSpace.JupyterLabAppSettingsPropertyOutputReference | TfSpace.JupyterLabAppSettingsProperty): any;
export declare function tfSpaceSpaceSettingsJupyterServerAppSettingsCodeRepositoryPropertyToTerraform(struct?: TfSpace.SpaceSettingsJupyterServerAppSettingsCodeRepositoryProperty | cdktn.IResolvable): any;
export declare function tfSpaceSpaceSettingsJupyterServerAppSettingsCodeRepositoryPropertyToHclTerraform(struct?: TfSpace.SpaceSettingsJupyterServerAppSettingsCodeRepositoryProperty | cdktn.IResolvable): any;
export declare function tfSpaceSpaceSettingsJupyterServerAppSettingsDefaultResourceSpecPropertyToTerraform(struct?: TfSpace.SpaceSettingsJupyterServerAppSettingsDefaultResourceSpecPropertyOutputReference | TfSpace.SpaceSettingsJupyterServerAppSettingsDefaultResourceSpecProperty): any;
export declare function tfSpaceSpaceSettingsJupyterServerAppSettingsDefaultResourceSpecPropertyToHclTerraform(struct?: TfSpace.SpaceSettingsJupyterServerAppSettingsDefaultResourceSpecPropertyOutputReference | TfSpace.SpaceSettingsJupyterServerAppSettingsDefaultResourceSpecProperty): any;
export declare function tfSpaceJupyterServerAppSettingsPropertyToTerraform(struct?: TfSpace.JupyterServerAppSettingsPropertyOutputReference | TfSpace.JupyterServerAppSettingsProperty): any;
export declare function tfSpaceJupyterServerAppSettingsPropertyToHclTerraform(struct?: TfSpace.JupyterServerAppSettingsPropertyOutputReference | TfSpace.JupyterServerAppSettingsProperty): any;
export declare function tfSpaceCustomImagePropertyToTerraform(struct?: TfSpace.CustomImageProperty | cdktn.IResolvable): any;
export declare function tfSpaceCustomImagePropertyToHclTerraform(struct?: TfSpace.CustomImageProperty | cdktn.IResolvable): any;
export declare function tfSpaceSpaceSettingsKernelGatewayAppSettingsDefaultResourceSpecPropertyToTerraform(struct?: TfSpace.SpaceSettingsKernelGatewayAppSettingsDefaultResourceSpecPropertyOutputReference | TfSpace.SpaceSettingsKernelGatewayAppSettingsDefaultResourceSpecProperty): any;
export declare function tfSpaceSpaceSettingsKernelGatewayAppSettingsDefaultResourceSpecPropertyToHclTerraform(struct?: TfSpace.SpaceSettingsKernelGatewayAppSettingsDefaultResourceSpecPropertyOutputReference | TfSpace.SpaceSettingsKernelGatewayAppSettingsDefaultResourceSpecProperty): any;
export declare function tfSpaceKernelGatewayAppSettingsPropertyToTerraform(struct?: TfSpace.KernelGatewayAppSettingsPropertyOutputReference | TfSpace.KernelGatewayAppSettingsProperty): any;
export declare function tfSpaceKernelGatewayAppSettingsPropertyToHclTerraform(struct?: TfSpace.KernelGatewayAppSettingsPropertyOutputReference | TfSpace.KernelGatewayAppSettingsProperty): any;
export declare function tfSpaceEbsStorageSettingsPropertyToTerraform(struct?: TfSpace.EbsStorageSettingsPropertyOutputReference | TfSpace.EbsStorageSettingsProperty): any;
export declare function tfSpaceEbsStorageSettingsPropertyToHclTerraform(struct?: TfSpace.EbsStorageSettingsPropertyOutputReference | TfSpace.EbsStorageSettingsProperty): any;
export declare function tfSpaceSpaceStorageSettingsPropertyToTerraform(struct?: TfSpace.SpaceStorageSettingsPropertyOutputReference | TfSpace.SpaceStorageSettingsProperty): any;
export declare function tfSpaceSpaceStorageSettingsPropertyToHclTerraform(struct?: TfSpace.SpaceStorageSettingsPropertyOutputReference | TfSpace.SpaceStorageSettingsProperty): any;
export declare function tfSpaceSpaceSettingsPropertyToTerraform(struct?: TfSpace.SpaceSettingsPropertyOutputReference | TfSpace.SpaceSettingsProperty): any;
export declare function tfSpaceSpaceSettingsPropertyToHclTerraform(struct?: TfSpace.SpaceSettingsPropertyOutputReference | TfSpace.SpaceSettingsProperty): any;
export declare function tfSpaceSpaceSharingSettingsPropertyToTerraform(struct?: TfSpace.SpaceSharingSettingsPropertyOutputReference | TfSpace.SpaceSharingSettingsProperty): any;
export declare function tfSpaceSpaceSharingSettingsPropertyToHclTerraform(struct?: TfSpace.SpaceSharingSettingsPropertyOutputReference | TfSpace.SpaceSharingSettingsProperty): any;
export declare namespace TfSpace {
    interface OwnershipSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#owner_user_profile_name TfSpace#owner_user_profile_name}
        */
        readonly ownerUserProfileName: string;
    }
    class OwnershipSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OwnershipSettingsProperty | undefined;
        set internalValue(value: OwnershipSettingsProperty | undefined);
        private _ownerUserProfileName?;
        get ownerUserProfileName(): string;
        set ownerUserProfileName(value: string);
        get ownerUserProfileNameInput(): string | undefined;
    }
    interface SpaceSettingsCodeEditorAppSettingsAppLifecycleManagementIdleSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#idle_timeout_in_minutes TfSpace#idle_timeout_in_minutes}
        */
        readonly idleTimeoutInMinutes?: number;
    }
    class SpaceSettingsCodeEditorAppSettingsAppLifecycleManagementIdleSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpaceSettingsCodeEditorAppSettingsAppLifecycleManagementIdleSettingsProperty | undefined;
        set internalValue(value: SpaceSettingsCodeEditorAppSettingsAppLifecycleManagementIdleSettingsProperty | undefined);
        private _idleTimeoutInMinutes?;
        get idleTimeoutInMinutes(): number;
        set idleTimeoutInMinutes(value: number);
        resetIdleTimeoutInMinutes(): void;
        get idleTimeoutInMinutesInput(): number | undefined;
    }
    interface SpaceSettingsCodeEditorAppSettingsAppLifecycleManagementProperty {
        /**
        * idle_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#idle_settings TfSpace#idle_settings}
        */
        readonly idleSettings?: SpaceSettingsCodeEditorAppSettingsAppLifecycleManagementIdleSettingsProperty;
    }
    class SpaceSettingsCodeEditorAppSettingsAppLifecycleManagementPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpaceSettingsCodeEditorAppSettingsAppLifecycleManagementProperty | undefined;
        set internalValue(value: SpaceSettingsCodeEditorAppSettingsAppLifecycleManagementProperty | undefined);
        private _idleSettings;
        get idleSettings(): SpaceSettingsCodeEditorAppSettingsAppLifecycleManagementIdleSettingsPropertyOutputReference;
        putIdleSettings(value: SpaceSettingsCodeEditorAppSettingsAppLifecycleManagementIdleSettingsProperty): void;
        resetIdleSettings(): void;
        get idleSettingsInput(): SpaceSettingsCodeEditorAppSettingsAppLifecycleManagementIdleSettingsProperty | undefined;
    }
    interface SpaceSettingsCodeEditorAppSettingsDefaultResourceSpecProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#instance_type TfSpace#instance_type}
        */
        readonly instanceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#lifecycle_config_arn TfSpace#lifecycle_config_arn}
        */
        readonly lifecycleConfigArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#sagemaker_image_arn TfSpace#sagemaker_image_arn}
        */
        readonly sagemakerImageArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#sagemaker_image_version_alias TfSpace#sagemaker_image_version_alias}
        */
        readonly sagemakerImageVersionAlias?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#sagemaker_image_version_arn TfSpace#sagemaker_image_version_arn}
        */
        readonly sagemakerImageVersionArn?: string;
    }
    class SpaceSettingsCodeEditorAppSettingsDefaultResourceSpecPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpaceSettingsCodeEditorAppSettingsDefaultResourceSpecProperty | undefined;
        set internalValue(value: SpaceSettingsCodeEditorAppSettingsDefaultResourceSpecProperty | undefined);
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        resetInstanceType(): void;
        get instanceTypeInput(): string | undefined;
        private _lifecycleConfigArn?;
        get lifecycleConfigArn(): string;
        set lifecycleConfigArn(value: string);
        resetLifecycleConfigArn(): void;
        get lifecycleConfigArnInput(): string | undefined;
        private _sagemakerImageArn?;
        get sagemakerImageArn(): string;
        set sagemakerImageArn(value: string);
        resetSagemakerImageArn(): void;
        get sagemakerImageArnInput(): string | undefined;
        private _sagemakerImageVersionAlias?;
        get sagemakerImageVersionAlias(): string;
        set sagemakerImageVersionAlias(value: string);
        resetSagemakerImageVersionAlias(): void;
        get sagemakerImageVersionAliasInput(): string | undefined;
        private _sagemakerImageVersionArn?;
        get sagemakerImageVersionArn(): string;
        set sagemakerImageVersionArn(value: string);
        resetSagemakerImageVersionArn(): void;
        get sagemakerImageVersionArnInput(): string | undefined;
    }
    interface CodeEditorAppSettingsProperty {
        /**
        * app_lifecycle_management block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#app_lifecycle_management TfSpace#app_lifecycle_management}
        */
        readonly appLifecycleManagement?: SpaceSettingsCodeEditorAppSettingsAppLifecycleManagementProperty;
        /**
        * default_resource_spec block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#default_resource_spec TfSpace#default_resource_spec}
        */
        readonly defaultResourceSpec: SpaceSettingsCodeEditorAppSettingsDefaultResourceSpecProperty;
    }
    class CodeEditorAppSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CodeEditorAppSettingsProperty | undefined;
        set internalValue(value: CodeEditorAppSettingsProperty | undefined);
        private _appLifecycleManagement;
        get appLifecycleManagement(): SpaceSettingsCodeEditorAppSettingsAppLifecycleManagementPropertyOutputReference;
        putAppLifecycleManagement(value: SpaceSettingsCodeEditorAppSettingsAppLifecycleManagementProperty): void;
        resetAppLifecycleManagement(): void;
        get appLifecycleManagementInput(): SpaceSettingsCodeEditorAppSettingsAppLifecycleManagementProperty | undefined;
        private _defaultResourceSpec;
        get defaultResourceSpec(): SpaceSettingsCodeEditorAppSettingsDefaultResourceSpecPropertyOutputReference;
        putDefaultResourceSpec(value: SpaceSettingsCodeEditorAppSettingsDefaultResourceSpecProperty): void;
        get defaultResourceSpecInput(): SpaceSettingsCodeEditorAppSettingsDefaultResourceSpecProperty | undefined;
    }
    interface EfsFileSystemProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#file_system_id TfSpace#file_system_id}
        */
        readonly fileSystemId: string;
    }
    class EfsFileSystemPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EfsFileSystemProperty | undefined;
        set internalValue(value: EfsFileSystemProperty | undefined);
        private _fileSystemId?;
        get fileSystemId(): string;
        set fileSystemId(value: string);
        get fileSystemIdInput(): string | undefined;
    }
    interface CustomFileSystemProperty {
        /**
        * efs_file_system block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#efs_file_system TfSpace#efs_file_system}
        */
        readonly efsFileSystem: EfsFileSystemProperty;
    }
    class CustomFileSystemPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomFileSystemProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CustomFileSystemProperty | cdktn.IResolvable | undefined);
        private _efsFileSystem;
        get efsFileSystem(): EfsFileSystemPropertyOutputReference;
        putEfsFileSystem(value: EfsFileSystemProperty): void;
        get efsFileSystemInput(): EfsFileSystemProperty | undefined;
    }
    class CustomFileSystemPropertyList extends cdktn.ComplexList {
        internalValue?: CustomFileSystemProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomFileSystemPropertyOutputReference;
    }
    interface SpaceSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#idle_timeout_in_minutes TfSpace#idle_timeout_in_minutes}
        */
        readonly idleTimeoutInMinutes?: number;
    }
    class SpaceSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpaceSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsProperty | undefined;
        set internalValue(value: SpaceSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsProperty | undefined);
        private _idleTimeoutInMinutes?;
        get idleTimeoutInMinutes(): number;
        set idleTimeoutInMinutes(value: number);
        resetIdleTimeoutInMinutes(): void;
        get idleTimeoutInMinutesInput(): number | undefined;
    }
    interface SpaceSettingsJupyterLabAppSettingsAppLifecycleManagementProperty {
        /**
        * idle_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#idle_settings TfSpace#idle_settings}
        */
        readonly idleSettings?: SpaceSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsProperty;
    }
    class SpaceSettingsJupyterLabAppSettingsAppLifecycleManagementPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpaceSettingsJupyterLabAppSettingsAppLifecycleManagementProperty | undefined;
        set internalValue(value: SpaceSettingsJupyterLabAppSettingsAppLifecycleManagementProperty | undefined);
        private _idleSettings;
        get idleSettings(): SpaceSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsPropertyOutputReference;
        putIdleSettings(value: SpaceSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsProperty): void;
        resetIdleSettings(): void;
        get idleSettingsInput(): SpaceSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsProperty | undefined;
    }
    interface SpaceSettingsJupyterLabAppSettingsCodeRepositoryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#repository_url TfSpace#repository_url}
        */
        readonly repositoryUrl: string;
    }
    class SpaceSettingsJupyterLabAppSettingsCodeRepositoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpaceSettingsJupyterLabAppSettingsCodeRepositoryProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SpaceSettingsJupyterLabAppSettingsCodeRepositoryProperty | cdktn.IResolvable | undefined);
        private _repositoryUrl?;
        get repositoryUrl(): string;
        set repositoryUrl(value: string);
        get repositoryUrlInput(): string | undefined;
    }
    class SpaceSettingsJupyterLabAppSettingsCodeRepositoryPropertyList extends cdktn.ComplexList {
        internalValue?: SpaceSettingsJupyterLabAppSettingsCodeRepositoryProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpaceSettingsJupyterLabAppSettingsCodeRepositoryPropertyOutputReference;
    }
    interface SpaceSettingsJupyterLabAppSettingsDefaultResourceSpecProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#instance_type TfSpace#instance_type}
        */
        readonly instanceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#lifecycle_config_arn TfSpace#lifecycle_config_arn}
        */
        readonly lifecycleConfigArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#sagemaker_image_arn TfSpace#sagemaker_image_arn}
        */
        readonly sagemakerImageArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#sagemaker_image_version_alias TfSpace#sagemaker_image_version_alias}
        */
        readonly sagemakerImageVersionAlias?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#sagemaker_image_version_arn TfSpace#sagemaker_image_version_arn}
        */
        readonly sagemakerImageVersionArn?: string;
    }
    class SpaceSettingsJupyterLabAppSettingsDefaultResourceSpecPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpaceSettingsJupyterLabAppSettingsDefaultResourceSpecProperty | undefined;
        set internalValue(value: SpaceSettingsJupyterLabAppSettingsDefaultResourceSpecProperty | undefined);
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        resetInstanceType(): void;
        get instanceTypeInput(): string | undefined;
        private _lifecycleConfigArn?;
        get lifecycleConfigArn(): string;
        set lifecycleConfigArn(value: string);
        resetLifecycleConfigArn(): void;
        get lifecycleConfigArnInput(): string | undefined;
        private _sagemakerImageArn?;
        get sagemakerImageArn(): string;
        set sagemakerImageArn(value: string);
        resetSagemakerImageArn(): void;
        get sagemakerImageArnInput(): string | undefined;
        private _sagemakerImageVersionAlias?;
        get sagemakerImageVersionAlias(): string;
        set sagemakerImageVersionAlias(value: string);
        resetSagemakerImageVersionAlias(): void;
        get sagemakerImageVersionAliasInput(): string | undefined;
        private _sagemakerImageVersionArn?;
        get sagemakerImageVersionArn(): string;
        set sagemakerImageVersionArn(value: string);
        resetSagemakerImageVersionArn(): void;
        get sagemakerImageVersionArnInput(): string | undefined;
    }
    interface JupyterLabAppSettingsProperty {
        /**
        * app_lifecycle_management block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#app_lifecycle_management TfSpace#app_lifecycle_management}
        */
        readonly appLifecycleManagement?: SpaceSettingsJupyterLabAppSettingsAppLifecycleManagementProperty;
        /**
        * code_repository block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#code_repository TfSpace#code_repository}
        */
        readonly codeRepository?: SpaceSettingsJupyterLabAppSettingsCodeRepositoryProperty[] | cdktn.IResolvable;
        /**
        * default_resource_spec block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#default_resource_spec TfSpace#default_resource_spec}
        */
        readonly defaultResourceSpec: SpaceSettingsJupyterLabAppSettingsDefaultResourceSpecProperty;
    }
    class JupyterLabAppSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): JupyterLabAppSettingsProperty | undefined;
        set internalValue(value: JupyterLabAppSettingsProperty | undefined);
        private _appLifecycleManagement;
        get appLifecycleManagement(): SpaceSettingsJupyterLabAppSettingsAppLifecycleManagementPropertyOutputReference;
        putAppLifecycleManagement(value: SpaceSettingsJupyterLabAppSettingsAppLifecycleManagementProperty): void;
        resetAppLifecycleManagement(): void;
        get appLifecycleManagementInput(): SpaceSettingsJupyterLabAppSettingsAppLifecycleManagementProperty | undefined;
        private _codeRepository;
        get codeRepository(): SpaceSettingsJupyterLabAppSettingsCodeRepositoryPropertyList;
        putCodeRepository(value: SpaceSettingsJupyterLabAppSettingsCodeRepositoryProperty[] | cdktn.IResolvable): void;
        resetCodeRepository(): void;
        get codeRepositoryInput(): cdktn.IResolvable | SpaceSettingsJupyterLabAppSettingsCodeRepositoryProperty[] | undefined;
        private _defaultResourceSpec;
        get defaultResourceSpec(): SpaceSettingsJupyterLabAppSettingsDefaultResourceSpecPropertyOutputReference;
        putDefaultResourceSpec(value: SpaceSettingsJupyterLabAppSettingsDefaultResourceSpecProperty): void;
        get defaultResourceSpecInput(): SpaceSettingsJupyterLabAppSettingsDefaultResourceSpecProperty | undefined;
    }
    interface SpaceSettingsJupyterServerAppSettingsCodeRepositoryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#repository_url TfSpace#repository_url}
        */
        readonly repositoryUrl: string;
    }
    class SpaceSettingsJupyterServerAppSettingsCodeRepositoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpaceSettingsJupyterServerAppSettingsCodeRepositoryProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SpaceSettingsJupyterServerAppSettingsCodeRepositoryProperty | cdktn.IResolvable | undefined);
        private _repositoryUrl?;
        get repositoryUrl(): string;
        set repositoryUrl(value: string);
        get repositoryUrlInput(): string | undefined;
    }
    class SpaceSettingsJupyterServerAppSettingsCodeRepositoryPropertyList extends cdktn.ComplexList {
        internalValue?: SpaceSettingsJupyterServerAppSettingsCodeRepositoryProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpaceSettingsJupyterServerAppSettingsCodeRepositoryPropertyOutputReference;
    }
    interface SpaceSettingsJupyterServerAppSettingsDefaultResourceSpecProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#instance_type TfSpace#instance_type}
        */
        readonly instanceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#lifecycle_config_arn TfSpace#lifecycle_config_arn}
        */
        readonly lifecycleConfigArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#sagemaker_image_arn TfSpace#sagemaker_image_arn}
        */
        readonly sagemakerImageArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#sagemaker_image_version_alias TfSpace#sagemaker_image_version_alias}
        */
        readonly sagemakerImageVersionAlias?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#sagemaker_image_version_arn TfSpace#sagemaker_image_version_arn}
        */
        readonly sagemakerImageVersionArn?: string;
    }
    class SpaceSettingsJupyterServerAppSettingsDefaultResourceSpecPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpaceSettingsJupyterServerAppSettingsDefaultResourceSpecProperty | undefined;
        set internalValue(value: SpaceSettingsJupyterServerAppSettingsDefaultResourceSpecProperty | undefined);
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        resetInstanceType(): void;
        get instanceTypeInput(): string | undefined;
        private _lifecycleConfigArn?;
        get lifecycleConfigArn(): string;
        set lifecycleConfigArn(value: string);
        resetLifecycleConfigArn(): void;
        get lifecycleConfigArnInput(): string | undefined;
        private _sagemakerImageArn?;
        get sagemakerImageArn(): string;
        set sagemakerImageArn(value: string);
        resetSagemakerImageArn(): void;
        get sagemakerImageArnInput(): string | undefined;
        private _sagemakerImageVersionAlias?;
        get sagemakerImageVersionAlias(): string;
        set sagemakerImageVersionAlias(value: string);
        resetSagemakerImageVersionAlias(): void;
        get sagemakerImageVersionAliasInput(): string | undefined;
        private _sagemakerImageVersionArn?;
        get sagemakerImageVersionArn(): string;
        set sagemakerImageVersionArn(value: string);
        resetSagemakerImageVersionArn(): void;
        get sagemakerImageVersionArnInput(): string | undefined;
    }
    interface JupyterServerAppSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#lifecycle_config_arns TfSpace#lifecycle_config_arns}
        */
        readonly lifecycleConfigArns?: string[];
        /**
        * code_repository block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#code_repository TfSpace#code_repository}
        */
        readonly codeRepository?: SpaceSettingsJupyterServerAppSettingsCodeRepositoryProperty[] | cdktn.IResolvable;
        /**
        * default_resource_spec block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#default_resource_spec TfSpace#default_resource_spec}
        */
        readonly defaultResourceSpec: SpaceSettingsJupyterServerAppSettingsDefaultResourceSpecProperty;
    }
    class JupyterServerAppSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): JupyterServerAppSettingsProperty | undefined;
        set internalValue(value: JupyterServerAppSettingsProperty | undefined);
        private _lifecycleConfigArns?;
        get lifecycleConfigArns(): string[];
        set lifecycleConfigArns(value: string[]);
        resetLifecycleConfigArns(): void;
        get lifecycleConfigArnsInput(): string[] | undefined;
        private _codeRepository;
        get codeRepository(): SpaceSettingsJupyterServerAppSettingsCodeRepositoryPropertyList;
        putCodeRepository(value: SpaceSettingsJupyterServerAppSettingsCodeRepositoryProperty[] | cdktn.IResolvable): void;
        resetCodeRepository(): void;
        get codeRepositoryInput(): cdktn.IResolvable | SpaceSettingsJupyterServerAppSettingsCodeRepositoryProperty[] | undefined;
        private _defaultResourceSpec;
        get defaultResourceSpec(): SpaceSettingsJupyterServerAppSettingsDefaultResourceSpecPropertyOutputReference;
        putDefaultResourceSpec(value: SpaceSettingsJupyterServerAppSettingsDefaultResourceSpecProperty): void;
        get defaultResourceSpecInput(): SpaceSettingsJupyterServerAppSettingsDefaultResourceSpecProperty | undefined;
    }
    interface CustomImageProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#app_image_config_name TfSpace#app_image_config_name}
        */
        readonly appImageConfigName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#image_name TfSpace#image_name}
        */
        readonly imageName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#image_version_number TfSpace#image_version_number}
        */
        readonly imageVersionNumber?: number;
    }
    class CustomImagePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomImageProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CustomImageProperty | cdktn.IResolvable | undefined);
        private _appImageConfigName?;
        get appImageConfigName(): string;
        set appImageConfigName(value: string);
        get appImageConfigNameInput(): string | undefined;
        private _imageName?;
        get imageName(): string;
        set imageName(value: string);
        get imageNameInput(): string | undefined;
        private _imageVersionNumber?;
        get imageVersionNumber(): number;
        set imageVersionNumber(value: number);
        resetImageVersionNumber(): void;
        get imageVersionNumberInput(): number | undefined;
    }
    class CustomImagePropertyList extends cdktn.ComplexList {
        internalValue?: CustomImageProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomImagePropertyOutputReference;
    }
    interface SpaceSettingsKernelGatewayAppSettingsDefaultResourceSpecProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#instance_type TfSpace#instance_type}
        */
        readonly instanceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#lifecycle_config_arn TfSpace#lifecycle_config_arn}
        */
        readonly lifecycleConfigArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#sagemaker_image_arn TfSpace#sagemaker_image_arn}
        */
        readonly sagemakerImageArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#sagemaker_image_version_alias TfSpace#sagemaker_image_version_alias}
        */
        readonly sagemakerImageVersionAlias?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#sagemaker_image_version_arn TfSpace#sagemaker_image_version_arn}
        */
        readonly sagemakerImageVersionArn?: string;
    }
    class SpaceSettingsKernelGatewayAppSettingsDefaultResourceSpecPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpaceSettingsKernelGatewayAppSettingsDefaultResourceSpecProperty | undefined;
        set internalValue(value: SpaceSettingsKernelGatewayAppSettingsDefaultResourceSpecProperty | undefined);
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        resetInstanceType(): void;
        get instanceTypeInput(): string | undefined;
        private _lifecycleConfigArn?;
        get lifecycleConfigArn(): string;
        set lifecycleConfigArn(value: string);
        resetLifecycleConfigArn(): void;
        get lifecycleConfigArnInput(): string | undefined;
        private _sagemakerImageArn?;
        get sagemakerImageArn(): string;
        set sagemakerImageArn(value: string);
        resetSagemakerImageArn(): void;
        get sagemakerImageArnInput(): string | undefined;
        private _sagemakerImageVersionAlias?;
        get sagemakerImageVersionAlias(): string;
        set sagemakerImageVersionAlias(value: string);
        resetSagemakerImageVersionAlias(): void;
        get sagemakerImageVersionAliasInput(): string | undefined;
        private _sagemakerImageVersionArn?;
        get sagemakerImageVersionArn(): string;
        set sagemakerImageVersionArn(value: string);
        resetSagemakerImageVersionArn(): void;
        get sagemakerImageVersionArnInput(): string | undefined;
    }
    interface KernelGatewayAppSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#lifecycle_config_arns TfSpace#lifecycle_config_arns}
        */
        readonly lifecycleConfigArns?: string[];
        /**
        * custom_image block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#custom_image TfSpace#custom_image}
        */
        readonly customImage?: CustomImageProperty[] | cdktn.IResolvable;
        /**
        * default_resource_spec block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#default_resource_spec TfSpace#default_resource_spec}
        */
        readonly defaultResourceSpec: SpaceSettingsKernelGatewayAppSettingsDefaultResourceSpecProperty;
    }
    class KernelGatewayAppSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): KernelGatewayAppSettingsProperty | undefined;
        set internalValue(value: KernelGatewayAppSettingsProperty | undefined);
        private _lifecycleConfigArns?;
        get lifecycleConfigArns(): string[];
        set lifecycleConfigArns(value: string[]);
        resetLifecycleConfigArns(): void;
        get lifecycleConfigArnsInput(): string[] | undefined;
        private _customImage;
        get customImage(): CustomImagePropertyList;
        putCustomImage(value: CustomImageProperty[] | cdktn.IResolvable): void;
        resetCustomImage(): void;
        get customImageInput(): cdktn.IResolvable | CustomImageProperty[] | undefined;
        private _defaultResourceSpec;
        get defaultResourceSpec(): SpaceSettingsKernelGatewayAppSettingsDefaultResourceSpecPropertyOutputReference;
        putDefaultResourceSpec(value: SpaceSettingsKernelGatewayAppSettingsDefaultResourceSpecProperty): void;
        get defaultResourceSpecInput(): SpaceSettingsKernelGatewayAppSettingsDefaultResourceSpecProperty | undefined;
    }
    interface EbsStorageSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#ebs_volume_size_in_gb TfSpace#ebs_volume_size_in_gb}
        */
        readonly ebsVolumeSizeInGb: number;
    }
    class EbsStorageSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EbsStorageSettingsProperty | undefined;
        set internalValue(value: EbsStorageSettingsProperty | undefined);
        private _ebsVolumeSizeInGb?;
        get ebsVolumeSizeInGb(): number;
        set ebsVolumeSizeInGb(value: number);
        get ebsVolumeSizeInGbInput(): number | undefined;
    }
    interface SpaceStorageSettingsProperty {
        /**
        * ebs_storage_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#ebs_storage_settings TfSpace#ebs_storage_settings}
        */
        readonly ebsStorageSettings: EbsStorageSettingsProperty;
    }
    class SpaceStorageSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpaceStorageSettingsProperty | undefined;
        set internalValue(value: SpaceStorageSettingsProperty | undefined);
        private _ebsStorageSettings;
        get ebsStorageSettings(): EbsStorageSettingsPropertyOutputReference;
        putEbsStorageSettings(value: EbsStorageSettingsProperty): void;
        get ebsStorageSettingsInput(): EbsStorageSettingsProperty | undefined;
    }
    interface SpaceSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#app_type TfSpace#app_type}
        */
        readonly appType?: string;
        /**
        * code_editor_app_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#code_editor_app_settings TfSpace#code_editor_app_settings}
        */
        readonly codeEditorAppSettings?: CodeEditorAppSettingsProperty;
        /**
        * custom_file_system block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#custom_file_system TfSpace#custom_file_system}
        */
        readonly customFileSystem?: CustomFileSystemProperty[] | cdktn.IResolvable;
        /**
        * jupyter_lab_app_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#jupyter_lab_app_settings TfSpace#jupyter_lab_app_settings}
        */
        readonly jupyterLabAppSettings?: JupyterLabAppSettingsProperty;
        /**
        * jupyter_server_app_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#jupyter_server_app_settings TfSpace#jupyter_server_app_settings}
        */
        readonly jupyterServerAppSettings?: JupyterServerAppSettingsProperty;
        /**
        * kernel_gateway_app_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#kernel_gateway_app_settings TfSpace#kernel_gateway_app_settings}
        */
        readonly kernelGatewayAppSettings?: KernelGatewayAppSettingsProperty;
        /**
        * space_storage_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#space_storage_settings TfSpace#space_storage_settings}
        */
        readonly spaceStorageSettings?: SpaceStorageSettingsProperty;
    }
    class SpaceSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpaceSettingsProperty | undefined;
        set internalValue(value: SpaceSettingsProperty | undefined);
        private _appType?;
        get appType(): string;
        set appType(value: string);
        resetAppType(): void;
        get appTypeInput(): string | undefined;
        private _codeEditorAppSettings;
        get codeEditorAppSettings(): CodeEditorAppSettingsPropertyOutputReference;
        putCodeEditorAppSettings(value: CodeEditorAppSettingsProperty): void;
        resetCodeEditorAppSettings(): void;
        get codeEditorAppSettingsInput(): CodeEditorAppSettingsProperty | undefined;
        private _customFileSystem;
        get customFileSystem(): CustomFileSystemPropertyList;
        putCustomFileSystem(value: CustomFileSystemProperty[] | cdktn.IResolvable): void;
        resetCustomFileSystem(): void;
        get customFileSystemInput(): cdktn.IResolvable | CustomFileSystemProperty[] | undefined;
        private _jupyterLabAppSettings;
        get jupyterLabAppSettings(): JupyterLabAppSettingsPropertyOutputReference;
        putJupyterLabAppSettings(value: JupyterLabAppSettingsProperty): void;
        resetJupyterLabAppSettings(): void;
        get jupyterLabAppSettingsInput(): JupyterLabAppSettingsProperty | undefined;
        private _jupyterServerAppSettings;
        get jupyterServerAppSettings(): JupyterServerAppSettingsPropertyOutputReference;
        putJupyterServerAppSettings(value: JupyterServerAppSettingsProperty): void;
        resetJupyterServerAppSettings(): void;
        get jupyterServerAppSettingsInput(): JupyterServerAppSettingsProperty | undefined;
        private _kernelGatewayAppSettings;
        get kernelGatewayAppSettings(): KernelGatewayAppSettingsPropertyOutputReference;
        putKernelGatewayAppSettings(value: KernelGatewayAppSettingsProperty): void;
        resetKernelGatewayAppSettings(): void;
        get kernelGatewayAppSettingsInput(): KernelGatewayAppSettingsProperty | undefined;
        private _spaceStorageSettings;
        get spaceStorageSettings(): SpaceStorageSettingsPropertyOutputReference;
        putSpaceStorageSettings(value: SpaceStorageSettingsProperty): void;
        resetSpaceStorageSettings(): void;
        get spaceStorageSettingsInput(): SpaceStorageSettingsProperty | undefined;
    }
    interface SpaceSharingSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_space#sharing_type TfSpace#sharing_type}
        */
        readonly sharingType: string;
    }
    class SpaceSharingSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpaceSharingSettingsProperty | undefined;
        set internalValue(value: SpaceSharingSettingsProperty | undefined);
        private _sharingType?;
        get sharingType(): string;
        set sharingType(value: string);
        get sharingTypeInput(): string | undefined;
    }
}
