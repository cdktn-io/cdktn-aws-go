import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfProjectConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_project#id TfProject#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_project#project_description TfProject#project_description}
    */
    readonly projectDescription?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_project#project_name TfProject#project_name}
    */
    readonly projectName: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_project#region TfProject#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_project#tags TfProject#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_project#tags_all TfProject#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * service_catalog_provisioning_details block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_project#service_catalog_provisioning_details TfProject#service_catalog_provisioning_details}
    */
    readonly serviceCatalogProvisioningDetails: TfProject.ServiceCatalogProvisioningDetailsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_project aws_sagemaker_project}
*/
export declare class TfProject extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_sagemaker_project";
    /**
    * Generates CDKTN code for importing a TfProject resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfProject to import
    * @param importFromId The id of the existing TfProject that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_project#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfProject to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_project aws_sagemaker_project} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfProjectConfig
    */
    constructor(scope: Construct, id: string, config: TfProjectConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _projectDescription?;
    get projectDescription(): string;
    set projectDescription(value: string);
    resetProjectDescription(): void;
    get projectDescriptionInput(): string | undefined;
    get projectId(): string;
    private _projectName?;
    get projectName(): string;
    set projectName(value: string);
    get projectNameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _serviceCatalogProvisioningDetails;
    get serviceCatalogProvisioningDetails(): TfProject.ServiceCatalogProvisioningDetailsPropertyOutputReference;
    putServiceCatalogProvisioningDetails(value: TfProject.ServiceCatalogProvisioningDetailsProperty): void;
    get serviceCatalogProvisioningDetailsInput(): TfProject.ServiceCatalogProvisioningDetailsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfProjectProvisioningParameterPropertyToTerraform(struct?: TfProject.ProvisioningParameterProperty | cdktn.IResolvable): any;
export declare function tfProjectProvisioningParameterPropertyToHclTerraform(struct?: TfProject.ProvisioningParameterProperty | cdktn.IResolvable): any;
export declare function tfProjectServiceCatalogProvisioningDetailsPropertyToTerraform(struct?: TfProject.ServiceCatalogProvisioningDetailsPropertyOutputReference | TfProject.ServiceCatalogProvisioningDetailsProperty): any;
export declare function tfProjectServiceCatalogProvisioningDetailsPropertyToHclTerraform(struct?: TfProject.ServiceCatalogProvisioningDetailsPropertyOutputReference | TfProject.ServiceCatalogProvisioningDetailsProperty): any;
export declare namespace TfProject {
    interface ProvisioningParameterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_project#key TfProject#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_project#value TfProject#value}
        */
        readonly value?: string;
    }
    class ProvisioningParameterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ProvisioningParameterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ProvisioningParameterProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        resetValue(): void;
        get valueInput(): string | undefined;
    }
    class ProvisioningParameterPropertyList extends cdktn.ComplexList {
        internalValue?: ProvisioningParameterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ProvisioningParameterPropertyOutputReference;
    }
    interface ServiceCatalogProvisioningDetailsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_project#path_id TfProject#path_id}
        */
        readonly pathId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_project#product_id TfProject#product_id}
        */
        readonly productId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_project#provisioning_artifact_id TfProject#provisioning_artifact_id}
        */
        readonly provisioningArtifactId?: string;
        /**
        * provisioning_parameter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_project#provisioning_parameter TfProject#provisioning_parameter}
        */
        readonly provisioningParameter?: ProvisioningParameterProperty[] | cdktn.IResolvable;
    }
    class ServiceCatalogProvisioningDetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ServiceCatalogProvisioningDetailsProperty | undefined;
        set internalValue(value: ServiceCatalogProvisioningDetailsProperty | undefined);
        private _pathId?;
        get pathId(): string;
        set pathId(value: string);
        resetPathId(): void;
        get pathIdInput(): string | undefined;
        private _productId?;
        get productId(): string;
        set productId(value: string);
        get productIdInput(): string | undefined;
        private _provisioningArtifactId?;
        get provisioningArtifactId(): string;
        set provisioningArtifactId(value: string);
        resetProvisioningArtifactId(): void;
        get provisioningArtifactIdInput(): string | undefined;
        private _provisioningParameter;
        get provisioningParameter(): ProvisioningParameterPropertyList;
        putProvisioningParameter(value: ProvisioningParameterProperty[] | cdktn.IResolvable): void;
        resetProvisioningParameter(): void;
        get provisioningParameterInput(): cdktn.IResolvable | ProvisioningParameterProperty[] | undefined;
    }
}
