import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfFlowDefinitionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#flow_definition_name TfFlowDefinition#flow_definition_name}
    */
    readonly flowDefinitionName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#id TfFlowDefinition#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#region TfFlowDefinition#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#role_arn TfFlowDefinition#role_arn}
    */
    readonly roleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#tags TfFlowDefinition#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#tags_all TfFlowDefinition#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * human_loop_activation_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#human_loop_activation_config TfFlowDefinition#human_loop_activation_config}
    */
    readonly humanLoopActivationConfig?: TfFlowDefinition.HumanLoopActivationConfigProperty;
    /**
    * human_loop_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#human_loop_config TfFlowDefinition#human_loop_config}
    */
    readonly humanLoopConfig: TfFlowDefinition.HumanLoopConfigProperty;
    /**
    * human_loop_request_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#human_loop_request_source TfFlowDefinition#human_loop_request_source}
    */
    readonly humanLoopRequestSource?: TfFlowDefinition.HumanLoopRequestSourceProperty;
    /**
    * output_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#output_config TfFlowDefinition#output_config}
    */
    readonly outputConfig: TfFlowDefinition.OutputConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition aws_sagemaker_flow_definition}
*/
export declare class TfFlowDefinition extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_sagemaker_flow_definition";
    /**
    * Generates CDKTN code for importing a TfFlowDefinition resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfFlowDefinition to import
    * @param importFromId The id of the existing TfFlowDefinition that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfFlowDefinition to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition aws_sagemaker_flow_definition} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfFlowDefinitionConfig
    */
    constructor(scope: Construct, id: string, config: TfFlowDefinitionConfig);
    get arn(): string;
    private _flowDefinitionName?;
    get flowDefinitionName(): string;
    set flowDefinitionName(value: string);
    get flowDefinitionNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _humanLoopActivationConfig;
    get humanLoopActivationConfig(): TfFlowDefinition.HumanLoopActivationConfigPropertyOutputReference;
    putHumanLoopActivationConfig(value: TfFlowDefinition.HumanLoopActivationConfigProperty): void;
    resetHumanLoopActivationConfig(): void;
    get humanLoopActivationConfigInput(): TfFlowDefinition.HumanLoopActivationConfigProperty | undefined;
    private _humanLoopConfig;
    get humanLoopConfig(): TfFlowDefinition.HumanLoopConfigPropertyOutputReference;
    putHumanLoopConfig(value: TfFlowDefinition.HumanLoopConfigProperty): void;
    get humanLoopConfigInput(): TfFlowDefinition.HumanLoopConfigProperty | undefined;
    private _humanLoopRequestSource;
    get humanLoopRequestSource(): TfFlowDefinition.HumanLoopRequestSourcePropertyOutputReference;
    putHumanLoopRequestSource(value: TfFlowDefinition.HumanLoopRequestSourceProperty): void;
    resetHumanLoopRequestSource(): void;
    get humanLoopRequestSourceInput(): TfFlowDefinition.HumanLoopRequestSourceProperty | undefined;
    private _outputConfig;
    get outputConfig(): TfFlowDefinition.OutputConfigPropertyOutputReference;
    putOutputConfig(value: TfFlowDefinition.OutputConfigProperty): void;
    get outputConfigInput(): TfFlowDefinition.OutputConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfFlowDefinitionHumanLoopActivationConditionsConfigPropertyToTerraform(struct?: TfFlowDefinition.HumanLoopActivationConditionsConfigPropertyOutputReference | TfFlowDefinition.HumanLoopActivationConditionsConfigProperty): any;
export declare function tfFlowDefinitionHumanLoopActivationConditionsConfigPropertyToHclTerraform(struct?: TfFlowDefinition.HumanLoopActivationConditionsConfigPropertyOutputReference | TfFlowDefinition.HumanLoopActivationConditionsConfigProperty): any;
export declare function tfFlowDefinitionHumanLoopActivationConfigPropertyToTerraform(struct?: TfFlowDefinition.HumanLoopActivationConfigPropertyOutputReference | TfFlowDefinition.HumanLoopActivationConfigProperty): any;
export declare function tfFlowDefinitionHumanLoopActivationConfigPropertyToHclTerraform(struct?: TfFlowDefinition.HumanLoopActivationConfigPropertyOutputReference | TfFlowDefinition.HumanLoopActivationConfigProperty): any;
export declare function tfFlowDefinitionAmountInUsdPropertyToTerraform(struct?: TfFlowDefinition.AmountInUsdPropertyOutputReference | TfFlowDefinition.AmountInUsdProperty): any;
export declare function tfFlowDefinitionAmountInUsdPropertyToHclTerraform(struct?: TfFlowDefinition.AmountInUsdPropertyOutputReference | TfFlowDefinition.AmountInUsdProperty): any;
export declare function tfFlowDefinitionPublicWorkforceTaskPricePropertyToTerraform(struct?: TfFlowDefinition.PublicWorkforceTaskPricePropertyOutputReference | TfFlowDefinition.PublicWorkforceTaskPriceProperty): any;
export declare function tfFlowDefinitionPublicWorkforceTaskPricePropertyToHclTerraform(struct?: TfFlowDefinition.PublicWorkforceTaskPricePropertyOutputReference | TfFlowDefinition.PublicWorkforceTaskPriceProperty): any;
export declare function tfFlowDefinitionHumanLoopConfigPropertyToTerraform(struct?: TfFlowDefinition.HumanLoopConfigPropertyOutputReference | TfFlowDefinition.HumanLoopConfigProperty): any;
export declare function tfFlowDefinitionHumanLoopConfigPropertyToHclTerraform(struct?: TfFlowDefinition.HumanLoopConfigPropertyOutputReference | TfFlowDefinition.HumanLoopConfigProperty): any;
export declare function tfFlowDefinitionHumanLoopRequestSourcePropertyToTerraform(struct?: TfFlowDefinition.HumanLoopRequestSourcePropertyOutputReference | TfFlowDefinition.HumanLoopRequestSourceProperty): any;
export declare function tfFlowDefinitionHumanLoopRequestSourcePropertyToHclTerraform(struct?: TfFlowDefinition.HumanLoopRequestSourcePropertyOutputReference | TfFlowDefinition.HumanLoopRequestSourceProperty): any;
export declare function tfFlowDefinitionOutputConfigPropertyToTerraform(struct?: TfFlowDefinition.OutputConfigPropertyOutputReference | TfFlowDefinition.OutputConfigProperty): any;
export declare function tfFlowDefinitionOutputConfigPropertyToHclTerraform(struct?: TfFlowDefinition.OutputConfigPropertyOutputReference | TfFlowDefinition.OutputConfigProperty): any;
export declare namespace TfFlowDefinition {
    interface HumanLoopActivationConditionsConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#human_loop_activation_conditions TfFlowDefinition#human_loop_activation_conditions}
        */
        readonly humanLoopActivationConditions: string;
    }
    class HumanLoopActivationConditionsConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HumanLoopActivationConditionsConfigProperty | undefined;
        set internalValue(value: HumanLoopActivationConditionsConfigProperty | undefined);
        private _humanLoopActivationConditions?;
        get humanLoopActivationConditions(): string;
        set humanLoopActivationConditions(value: string);
        get humanLoopActivationConditionsInput(): string | undefined;
    }
    interface HumanLoopActivationConfigProperty {
        /**
        * human_loop_activation_conditions_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#human_loop_activation_conditions_config TfFlowDefinition#human_loop_activation_conditions_config}
        */
        readonly humanLoopActivationConditionsConfig?: HumanLoopActivationConditionsConfigProperty;
    }
    class HumanLoopActivationConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HumanLoopActivationConfigProperty | undefined;
        set internalValue(value: HumanLoopActivationConfigProperty | undefined);
        private _humanLoopActivationConditionsConfig;
        get humanLoopActivationConditionsConfig(): HumanLoopActivationConditionsConfigPropertyOutputReference;
        putHumanLoopActivationConditionsConfig(value: HumanLoopActivationConditionsConfigProperty): void;
        resetHumanLoopActivationConditionsConfig(): void;
        get humanLoopActivationConditionsConfigInput(): HumanLoopActivationConditionsConfigProperty | undefined;
    }
    interface AmountInUsdProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#cents TfFlowDefinition#cents}
        */
        readonly cents?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#dollars TfFlowDefinition#dollars}
        */
        readonly dollars?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#tenth_fractions_of_a_cent TfFlowDefinition#tenth_fractions_of_a_cent}
        */
        readonly tenthFractionsOfACent?: number;
    }
    class AmountInUsdPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AmountInUsdProperty | undefined;
        set internalValue(value: AmountInUsdProperty | undefined);
        private _cents?;
        get cents(): number;
        set cents(value: number);
        resetCents(): void;
        get centsInput(): number | undefined;
        private _dollars?;
        get dollars(): number;
        set dollars(value: number);
        resetDollars(): void;
        get dollarsInput(): number | undefined;
        private _tenthFractionsOfACent?;
        get tenthFractionsOfACent(): number;
        set tenthFractionsOfACent(value: number);
        resetTenthFractionsOfACent(): void;
        get tenthFractionsOfACentInput(): number | undefined;
    }
    interface PublicWorkforceTaskPriceProperty {
        /**
        * amount_in_usd block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#amount_in_usd TfFlowDefinition#amount_in_usd}
        */
        readonly amountInUsd?: AmountInUsdProperty;
    }
    class PublicWorkforceTaskPricePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PublicWorkforceTaskPriceProperty | undefined;
        set internalValue(value: PublicWorkforceTaskPriceProperty | undefined);
        private _amountInUsd;
        get amountInUsd(): AmountInUsdPropertyOutputReference;
        putAmountInUsd(value: AmountInUsdProperty): void;
        resetAmountInUsd(): void;
        get amountInUsdInput(): AmountInUsdProperty | undefined;
    }
    interface HumanLoopConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#human_task_ui_arn TfFlowDefinition#human_task_ui_arn}
        */
        readonly humanTaskUiArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#task_availability_lifetime_in_seconds TfFlowDefinition#task_availability_lifetime_in_seconds}
        */
        readonly taskAvailabilityLifetimeInSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#task_count TfFlowDefinition#task_count}
        */
        readonly taskCount: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#task_description TfFlowDefinition#task_description}
        */
        readonly taskDescription: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#task_keywords TfFlowDefinition#task_keywords}
        */
        readonly taskKeywords?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#task_time_limit_in_seconds TfFlowDefinition#task_time_limit_in_seconds}
        */
        readonly taskTimeLimitInSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#task_title TfFlowDefinition#task_title}
        */
        readonly taskTitle: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#workteam_arn TfFlowDefinition#workteam_arn}
        */
        readonly workteamArn: string;
        /**
        * public_workforce_task_price block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#public_workforce_task_price TfFlowDefinition#public_workforce_task_price}
        */
        readonly publicWorkforceTaskPrice?: PublicWorkforceTaskPriceProperty;
    }
    class HumanLoopConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HumanLoopConfigProperty | undefined;
        set internalValue(value: HumanLoopConfigProperty | undefined);
        private _humanTaskUiArn?;
        get humanTaskUiArn(): string;
        set humanTaskUiArn(value: string);
        get humanTaskUiArnInput(): string | undefined;
        private _taskAvailabilityLifetimeInSeconds?;
        get taskAvailabilityLifetimeInSeconds(): number;
        set taskAvailabilityLifetimeInSeconds(value: number);
        resetTaskAvailabilityLifetimeInSeconds(): void;
        get taskAvailabilityLifetimeInSecondsInput(): number | undefined;
        private _taskCount?;
        get taskCount(): number;
        set taskCount(value: number);
        get taskCountInput(): number | undefined;
        private _taskDescription?;
        get taskDescription(): string;
        set taskDescription(value: string);
        get taskDescriptionInput(): string | undefined;
        private _taskKeywords?;
        get taskKeywords(): string[];
        set taskKeywords(value: string[]);
        resetTaskKeywords(): void;
        get taskKeywordsInput(): string[] | undefined;
        private _taskTimeLimitInSeconds?;
        get taskTimeLimitInSeconds(): number;
        set taskTimeLimitInSeconds(value: number);
        resetTaskTimeLimitInSeconds(): void;
        get taskTimeLimitInSecondsInput(): number | undefined;
        private _taskTitle?;
        get taskTitle(): string;
        set taskTitle(value: string);
        get taskTitleInput(): string | undefined;
        private _workteamArn?;
        get workteamArn(): string;
        set workteamArn(value: string);
        get workteamArnInput(): string | undefined;
        private _publicWorkforceTaskPrice;
        get publicWorkforceTaskPrice(): PublicWorkforceTaskPricePropertyOutputReference;
        putPublicWorkforceTaskPrice(value: PublicWorkforceTaskPriceProperty): void;
        resetPublicWorkforceTaskPrice(): void;
        get publicWorkforceTaskPriceInput(): PublicWorkforceTaskPriceProperty | undefined;
    }
    interface HumanLoopRequestSourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#aws_managed_human_loop_request_source TfFlowDefinition#aws_managed_human_loop_request_source}
        */
        readonly awsManagedHumanLoopRequestSource: string;
    }
    class HumanLoopRequestSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HumanLoopRequestSourceProperty | undefined;
        set internalValue(value: HumanLoopRequestSourceProperty | undefined);
        private _awsManagedHumanLoopRequestSource?;
        get awsManagedHumanLoopRequestSource(): string;
        set awsManagedHumanLoopRequestSource(value: string);
        get awsManagedHumanLoopRequestSourceInput(): string | undefined;
    }
    interface OutputConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#kms_key_id TfFlowDefinition#kms_key_id}
        */
        readonly kmsKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#s3_output_path TfFlowDefinition#s3_output_path}
        */
        readonly s3OutputPath: string;
    }
    class OutputConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OutputConfigProperty | undefined;
        set internalValue(value: OutputConfigProperty | undefined);
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        resetKmsKeyId(): void;
        get kmsKeyIdInput(): string | undefined;
        private _s3OutputPath?;
        get s3OutputPath(): string;
        set s3OutputPath(value: string);
        get s3OutputPathInput(): string | undefined;
    }
}
