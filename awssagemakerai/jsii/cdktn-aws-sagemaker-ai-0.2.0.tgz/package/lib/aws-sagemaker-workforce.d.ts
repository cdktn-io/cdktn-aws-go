import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfWorkforceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce#id TfWorkforce#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce#region TfWorkforce#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce#workforce_name TfWorkforce#workforce_name}
    */
    readonly workforceName: string;
    /**
    * cognito_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce#cognito_config TfWorkforce#cognito_config}
    */
    readonly cognitoConfig?: TfWorkforce.CognitoConfigProperty;
    /**
    * oidc_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce#oidc_config TfWorkforce#oidc_config}
    */
    readonly oidcConfig?: TfWorkforce.OidcConfigProperty;
    /**
    * source_ip_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce#source_ip_config TfWorkforce#source_ip_config}
    */
    readonly sourceIpConfig?: TfWorkforce.SourceIpConfigProperty;
    /**
    * workforce_vpc_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce#workforce_vpc_config TfWorkforce#workforce_vpc_config}
    */
    readonly workforceVpcConfig?: TfWorkforce.WorkforceVpcConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce aws_sagemaker_workforce}
*/
export declare class TfWorkforce extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_sagemaker_workforce";
    /**
    * Generates CDKTN code for importing a TfWorkforce resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfWorkforce to import
    * @param importFromId The id of the existing TfWorkforce that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfWorkforce to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce aws_sagemaker_workforce} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfWorkforceConfig
    */
    constructor(scope: Construct, id: string, config: TfWorkforceConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get subdomain(): string;
    private _workforceName?;
    get workforceName(): string;
    set workforceName(value: string);
    get workforceNameInput(): string | undefined;
    private _cognitoConfig;
    get cognitoConfig(): TfWorkforce.CognitoConfigPropertyOutputReference;
    putCognitoConfig(value: TfWorkforce.CognitoConfigProperty): void;
    resetCognitoConfig(): void;
    get cognitoConfigInput(): TfWorkforce.CognitoConfigProperty | undefined;
    private _oidcConfig;
    get oidcConfig(): TfWorkforce.OidcConfigPropertyOutputReference;
    putOidcConfig(value: TfWorkforce.OidcConfigProperty): void;
    resetOidcConfig(): void;
    get oidcConfigInput(): TfWorkforce.OidcConfigProperty | undefined;
    private _sourceIpConfig;
    get sourceIpConfig(): TfWorkforce.SourceIpConfigPropertyOutputReference;
    putSourceIpConfig(value: TfWorkforce.SourceIpConfigProperty): void;
    resetSourceIpConfig(): void;
    get sourceIpConfigInput(): TfWorkforce.SourceIpConfigProperty | undefined;
    private _workforceVpcConfig;
    get workforceVpcConfig(): TfWorkforce.WorkforceVpcConfigPropertyOutputReference;
    putWorkforceVpcConfig(value: TfWorkforce.WorkforceVpcConfigProperty): void;
    resetWorkforceVpcConfig(): void;
    get workforceVpcConfigInput(): TfWorkforce.WorkforceVpcConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfWorkforceCognitoConfigPropertyToTerraform(struct?: TfWorkforce.CognitoConfigPropertyOutputReference | TfWorkforce.CognitoConfigProperty): any;
export declare function tfWorkforceCognitoConfigPropertyToHclTerraform(struct?: TfWorkforce.CognitoConfigPropertyOutputReference | TfWorkforce.CognitoConfigProperty): any;
export declare function tfWorkforceOidcConfigPropertyToTerraform(struct?: TfWorkforce.OidcConfigPropertyOutputReference | TfWorkforce.OidcConfigProperty): any;
export declare function tfWorkforceOidcConfigPropertyToHclTerraform(struct?: TfWorkforce.OidcConfigPropertyOutputReference | TfWorkforce.OidcConfigProperty): any;
export declare function tfWorkforceSourceIpConfigPropertyToTerraform(struct?: TfWorkforce.SourceIpConfigPropertyOutputReference | TfWorkforce.SourceIpConfigProperty): any;
export declare function tfWorkforceSourceIpConfigPropertyToHclTerraform(struct?: TfWorkforce.SourceIpConfigPropertyOutputReference | TfWorkforce.SourceIpConfigProperty): any;
export declare function tfWorkforceWorkforceVpcConfigPropertyToTerraform(struct?: TfWorkforce.WorkforceVpcConfigPropertyOutputReference | TfWorkforce.WorkforceVpcConfigProperty): any;
export declare function tfWorkforceWorkforceVpcConfigPropertyToHclTerraform(struct?: TfWorkforce.WorkforceVpcConfigPropertyOutputReference | TfWorkforce.WorkforceVpcConfigProperty): any;
export declare namespace TfWorkforce {
    interface CognitoConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce#client_id TfWorkforce#client_id}
        */
        readonly clientId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce#user_pool TfWorkforce#user_pool}
        */
        readonly userPool: string;
    }
    class CognitoConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CognitoConfigProperty | undefined;
        set internalValue(value: CognitoConfigProperty | undefined);
        private _clientId?;
        get clientId(): string;
        set clientId(value: string);
        get clientIdInput(): string | undefined;
        private _userPool?;
        get userPool(): string;
        set userPool(value: string);
        get userPoolInput(): string | undefined;
    }
    interface OidcConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce#authentication_request_extra_params TfWorkforce#authentication_request_extra_params}
        */
        readonly authenticationRequestExtraParams?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce#authorization_endpoint TfWorkforce#authorization_endpoint}
        */
        readonly authorizationEndpoint: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce#client_id TfWorkforce#client_id}
        */
        readonly clientId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce#client_secret TfWorkforce#client_secret}
        */
        readonly clientSecret: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce#issuer TfWorkforce#issuer}
        */
        readonly issuer: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce#jwks_uri TfWorkforce#jwks_uri}
        */
        readonly jwksUri: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce#logout_endpoint TfWorkforce#logout_endpoint}
        */
        readonly logoutEndpoint: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce#scope TfWorkforce#scope}
        */
        readonly scope?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce#token_endpoint TfWorkforce#token_endpoint}
        */
        readonly tokenEndpoint: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce#user_info_endpoint TfWorkforce#user_info_endpoint}
        */
        readonly userInfoEndpoint: string;
    }
    class OidcConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OidcConfigProperty | undefined;
        set internalValue(value: OidcConfigProperty | undefined);
        private _authenticationRequestExtraParams?;
        get authenticationRequestExtraParams(): {
            [key: string]: string;
        };
        set authenticationRequestExtraParams(value: {
            [key: string]: string;
        });
        resetAuthenticationRequestExtraParams(): void;
        get authenticationRequestExtraParamsInput(): {
            [key: string]: string;
        } | undefined;
        private _authorizationEndpoint?;
        get authorizationEndpoint(): string;
        set authorizationEndpoint(value: string);
        get authorizationEndpointInput(): string | undefined;
        private _clientId?;
        get clientId(): string;
        set clientId(value: string);
        get clientIdInput(): string | undefined;
        private _clientSecret?;
        get clientSecret(): string;
        set clientSecret(value: string);
        get clientSecretInput(): string | undefined;
        private _issuer?;
        get issuer(): string;
        set issuer(value: string);
        get issuerInput(): string | undefined;
        private _jwksUri?;
        get jwksUri(): string;
        set jwksUri(value: string);
        get jwksUriInput(): string | undefined;
        private _logoutEndpoint?;
        get logoutEndpoint(): string;
        set logoutEndpoint(value: string);
        get logoutEndpointInput(): string | undefined;
        private _scope?;
        get scope(): string;
        set scope(value: string);
        resetScope(): void;
        get scopeInput(): string | undefined;
        private _tokenEndpoint?;
        get tokenEndpoint(): string;
        set tokenEndpoint(value: string);
        get tokenEndpointInput(): string | undefined;
        private _userInfoEndpoint?;
        get userInfoEndpoint(): string;
        set userInfoEndpoint(value: string);
        get userInfoEndpointInput(): string | undefined;
    }
    interface SourceIpConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce#cidrs TfWorkforce#cidrs}
        */
        readonly cidrs: string[];
    }
    class SourceIpConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceIpConfigProperty | undefined;
        set internalValue(value: SourceIpConfigProperty | undefined);
        private _cidrs?;
        get cidrs(): string[];
        set cidrs(value: string[]);
        get cidrsInput(): string[] | undefined;
    }
    interface WorkforceVpcConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce#security_group_ids TfWorkforce#security_group_ids}
        */
        readonly securityGroupIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce#subnets TfWorkforce#subnets}
        */
        readonly subnets?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce#vpc_id TfWorkforce#vpc_id}
        */
        readonly vpcId?: string;
    }
    class WorkforceVpcConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): WorkforceVpcConfigProperty | undefined;
        set internalValue(value: WorkforceVpcConfigProperty | undefined);
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        resetSecurityGroupIds(): void;
        get securityGroupIdsInput(): string[] | undefined;
        private _subnets?;
        get subnets(): string[];
        set subnets(value: string[]);
        resetSubnets(): void;
        get subnetsInput(): string[] | undefined;
        get vpcEndpointId(): string;
        private _vpcId?;
        get vpcId(): string;
        set vpcId(value: string);
        resetVpcId(): void;
        get vpcIdInput(): string | undefined;
    }
}
