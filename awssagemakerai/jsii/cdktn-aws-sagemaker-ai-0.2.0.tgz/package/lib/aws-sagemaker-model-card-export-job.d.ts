import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfModelCardExportJobConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model_card_export_job#model_card_export_job_name TfModelCardExportJob#model_card_export_job_name}
    */
    readonly modelCardExportJobName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model_card_export_job#model_card_name TfModelCardExportJob#model_card_name}
    */
    readonly modelCardName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model_card_export_job#model_card_version TfModelCardExportJob#model_card_version}
    */
    readonly modelCardVersion?: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model_card_export_job#region TfModelCardExportJob#region}
    */
    readonly region?: string;
    /**
    * output_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model_card_export_job#output_config TfModelCardExportJob#output_config}
    */
    readonly outputConfig?: TfModelCardExportJob.OutputConfigProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model_card_export_job#timeouts TfModelCardExportJob#timeouts}
    */
    readonly timeouts?: TfModelCardExportJob.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model_card_export_job aws_sagemaker_model_card_export_job}
*/
export declare class TfModelCardExportJob extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_sagemaker_model_card_export_job";
    /**
    * Generates CDKTN code for importing a TfModelCardExportJob resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfModelCardExportJob to import
    * @param importFromId The id of the existing TfModelCardExportJob that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model_card_export_job#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfModelCardExportJob to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model_card_export_job aws_sagemaker_model_card_export_job} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfModelCardExportJobConfig
    */
    constructor(scope: Construct, id: string, config: TfModelCardExportJobConfig);
    private _exportArtifacts;
    get exportArtifacts(): TfModelCardExportJob.ExportArtifactsPropertyList;
    get modelCardExportJobArn(): string;
    private _modelCardExportJobName?;
    get modelCardExportJobName(): string;
    set modelCardExportJobName(value: string);
    get modelCardExportJobNameInput(): string | undefined;
    private _modelCardName?;
    get modelCardName(): string;
    set modelCardName(value: string);
    get modelCardNameInput(): string | undefined;
    private _modelCardVersion?;
    get modelCardVersion(): number;
    set modelCardVersion(value: number);
    resetModelCardVersion(): void;
    get modelCardVersionInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _outputConfig;
    get outputConfig(): TfModelCardExportJob.OutputConfigPropertyList;
    putOutputConfig(value: TfModelCardExportJob.OutputConfigProperty[] | cdktn.IResolvable): void;
    resetOutputConfig(): void;
    get outputConfigInput(): cdktn.IResolvable | TfModelCardExportJob.OutputConfigProperty[] | undefined;
    private _timeouts;
    get timeouts(): TfModelCardExportJob.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfModelCardExportJob.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfModelCardExportJob.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfModelCardExportJobExportArtifactsPropertyToTerraform(struct?: TfModelCardExportJob.ExportArtifactsProperty): any;
export declare function tfModelCardExportJobExportArtifactsPropertyToHclTerraform(struct?: TfModelCardExportJob.ExportArtifactsProperty): any;
export declare function tfModelCardExportJobOutputConfigPropertyToTerraform(struct?: TfModelCardExportJob.OutputConfigProperty | cdktn.IResolvable): any;
export declare function tfModelCardExportJobOutputConfigPropertyToHclTerraform(struct?: TfModelCardExportJob.OutputConfigProperty | cdktn.IResolvable): any;
export declare function tfModelCardExportJobTimeoutsPropertyToTerraform(struct?: TfModelCardExportJob.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfModelCardExportJobTimeoutsPropertyToHclTerraform(struct?: TfModelCardExportJob.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfModelCardExportJob {
    interface ExportArtifactsProperty {
    }
    class ExportArtifactsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExportArtifactsProperty | undefined;
        set internalValue(value: ExportArtifactsProperty | undefined);
        get s3ExportArtifacts(): string;
    }
    class ExportArtifactsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExportArtifactsPropertyOutputReference;
    }
    interface OutputConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model_card_export_job#s3_output_path TfModelCardExportJob#s3_output_path}
        */
        readonly s3OutputPath: string;
    }
    class OutputConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OutputConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OutputConfigProperty | cdktn.IResolvable | undefined);
        private _s3OutputPath?;
        get s3OutputPath(): string;
        set s3OutputPath(value: string);
        get s3OutputPathInput(): string | undefined;
    }
    class OutputConfigPropertyList extends cdktn.ComplexList {
        internalValue?: OutputConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OutputConfigPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model_card_export_job#create TfModelCardExportJob#create}
        */
        readonly create?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
    }
}
