import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfModelCardConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model_card#content TfModelCard#content}
    */
    readonly content: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model_card#model_card_name TfModelCard#model_card_name}
    */
    readonly modelCardName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model_card#model_card_status TfModelCard#model_card_status}
    */
    readonly modelCardStatus: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model_card#region TfModelCard#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model_card#tags TfModelCard#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * security_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model_card#security_config TfModelCard#security_config}
    */
    readonly securityConfig?: TfModelCard.SecurityConfigProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model_card#timeouts TfModelCard#timeouts}
    */
    readonly timeouts?: TfModelCard.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model_card aws_sagemaker_model_card}
*/
export declare class TfModelCard extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_sagemaker_model_card";
    /**
    * Generates CDKTN code for importing a TfModelCard resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfModelCard to import
    * @param importFromId The id of the existing TfModelCard that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model_card#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfModelCard to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model_card aws_sagemaker_model_card} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfModelCardConfig
    */
    constructor(scope: Construct, id: string, config: TfModelCardConfig);
    private _content?;
    get content(): string;
    set content(value: string);
    get contentInput(): string | undefined;
    get modelCardArn(): string;
    private _modelCardName?;
    get modelCardName(): string;
    set modelCardName(value: string);
    get modelCardNameInput(): string | undefined;
    private _modelCardStatus?;
    get modelCardStatus(): string;
    set modelCardStatus(value: string);
    get modelCardStatusInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _securityConfig;
    get securityConfig(): TfModelCard.SecurityConfigPropertyList;
    putSecurityConfig(value: TfModelCard.SecurityConfigProperty[] | cdktn.IResolvable): void;
    resetSecurityConfig(): void;
    get securityConfigInput(): cdktn.IResolvable | TfModelCard.SecurityConfigProperty[] | undefined;
    private _timeouts;
    get timeouts(): TfModelCard.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfModelCard.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfModelCard.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfModelCardSecurityConfigPropertyToTerraform(struct?: TfModelCard.SecurityConfigProperty | cdktn.IResolvable): any;
export declare function tfModelCardSecurityConfigPropertyToHclTerraform(struct?: TfModelCard.SecurityConfigProperty | cdktn.IResolvable): any;
export declare function tfModelCardTimeoutsPropertyToTerraform(struct?: TfModelCard.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfModelCardTimeoutsPropertyToHclTerraform(struct?: TfModelCard.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfModelCard {
    interface SecurityConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model_card#kms_key_id TfModelCard#kms_key_id}
        */
        readonly kmsKeyId: string;
    }
    class SecurityConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SecurityConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SecurityConfigProperty | cdktn.IResolvable | undefined);
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        get kmsKeyIdInput(): string | undefined;
    }
    class SecurityConfigPropertyList extends cdktn.ComplexList {
        internalValue?: SecurityConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SecurityConfigPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model_card#delete TfModelCard#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
