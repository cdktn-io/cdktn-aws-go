import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfMlflowTrackingServerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_mlflow_tracking_server#artifact_store_uri TfMlflowTrackingServer#artifact_store_uri}
    */
    readonly artifactStoreUri: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_mlflow_tracking_server#automatic_model_registration TfMlflowTrackingServer#automatic_model_registration}
    */
    readonly automaticModelRegistration?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_mlflow_tracking_server#id TfMlflowTrackingServer#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_mlflow_tracking_server#mlflow_version TfMlflowTrackingServer#mlflow_version}
    */
    readonly mlflowVersion?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_mlflow_tracking_server#region TfMlflowTrackingServer#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_mlflow_tracking_server#role_arn TfMlflowTrackingServer#role_arn}
    */
    readonly roleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_mlflow_tracking_server#tags TfMlflowTrackingServer#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_mlflow_tracking_server#tags_all TfMlflowTrackingServer#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_mlflow_tracking_server#tracking_server_name TfMlflowTrackingServer#tracking_server_name}
    */
    readonly trackingServerName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_mlflow_tracking_server#tracking_server_size TfMlflowTrackingServer#tracking_server_size}
    */
    readonly trackingServerSize?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_mlflow_tracking_server#weekly_maintenance_window_start TfMlflowTrackingServer#weekly_maintenance_window_start}
    */
    readonly weeklyMaintenanceWindowStart?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_mlflow_tracking_server aws_sagemaker_mlflow_tracking_server}
*/
export declare class TfMlflowTrackingServer extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_sagemaker_mlflow_tracking_server";
    /**
    * Generates CDKTN code for importing a TfMlflowTrackingServer resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfMlflowTrackingServer to import
    * @param importFromId The id of the existing TfMlflowTrackingServer that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_mlflow_tracking_server#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfMlflowTrackingServer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_mlflow_tracking_server aws_sagemaker_mlflow_tracking_server} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfMlflowTrackingServerConfig
    */
    constructor(scope: Construct, id: string, config: TfMlflowTrackingServerConfig);
    get arn(): string;
    private _artifactStoreUri?;
    get artifactStoreUri(): string;
    set artifactStoreUri(value: string);
    get artifactStoreUriInput(): string | undefined;
    private _automaticModelRegistration?;
    get automaticModelRegistration(): boolean | cdktn.IResolvable;
    set automaticModelRegistration(value: boolean | cdktn.IResolvable);
    resetAutomaticModelRegistration(): void;
    get automaticModelRegistrationInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _mlflowVersion?;
    get mlflowVersion(): string;
    set mlflowVersion(value: string);
    resetMlflowVersion(): void;
    get mlflowVersionInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _trackingServerName?;
    get trackingServerName(): string;
    set trackingServerName(value: string);
    get trackingServerNameInput(): string | undefined;
    private _trackingServerSize?;
    get trackingServerSize(): string;
    set trackingServerSize(value: string);
    resetTrackingServerSize(): void;
    get trackingServerSizeInput(): string | undefined;
    get trackingServerUrl(): string;
    private _weeklyMaintenanceWindowStart?;
    get weeklyMaintenanceWindowStart(): string;
    set weeklyMaintenanceWindowStart(value: string);
    resetWeeklyMaintenanceWindowStart(): void;
    get weeklyMaintenanceWindowStartInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
