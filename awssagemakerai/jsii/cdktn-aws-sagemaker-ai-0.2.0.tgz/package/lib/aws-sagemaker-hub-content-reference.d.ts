import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfHubContentReferenceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Name of the hub content reference.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hub_content_reference#hub_content_name TfHubContentReference#hub_content_name}
    */
    readonly hubContentName: string;
    /**
    * Name of the private SageMaker Hub to add the content reference to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hub_content_reference#hub_name TfHubContentReference#hub_name}
    */
    readonly hubName: string;
    /**
    * Minimum version of the hub content to reference. Use "1.0.0" to support all versions. Changing this value to an empty string forces replacement of the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hub_content_reference#min_version TfHubContentReference#min_version}
    */
    readonly minVersion?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hub_content_reference#region TfHubContentReference#region}
    */
    readonly region?: string;
    /**
    * ARN of the public SageMaker JumpStart hub content to reference. The ARN must not include a version suffix.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hub_content_reference#sagemaker_public_hub_content_arn TfHubContentReference#sagemaker_public_hub_content_arn}
    */
    readonly sagemakerPublicHubContentArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hub_content_reference#tags TfHubContentReference#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hub_content_reference#timeouts TfHubContentReference#timeouts}
    */
    readonly timeouts?: TfHubContentReference.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hub_content_reference aws_sagemaker_hub_content_reference}
*/
export declare class TfHubContentReference extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_sagemaker_hub_content_reference";
    /**
    * Generates CDKTN code for importing a TfHubContentReference resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfHubContentReference to import
    * @param importFromId The id of the existing TfHubContentReference that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hub_content_reference#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfHubContentReference to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hub_content_reference aws_sagemaker_hub_content_reference} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfHubContentReferenceConfig
    */
    constructor(scope: Construct, id: string, config: TfHubContentReferenceConfig);
    get hubArn(): string;
    get hubContentArn(): string;
    private _hubContentName?;
    get hubContentName(): string;
    set hubContentName(value: string);
    get hubContentNameInput(): string | undefined;
    get hubContentStatus(): string;
    get hubContentVersion(): string;
    private _hubName?;
    get hubName(): string;
    set hubName(value: string);
    get hubNameInput(): string | undefined;
    private _minVersion?;
    get minVersion(): string;
    set minVersion(value: string);
    resetMinVersion(): void;
    get minVersionInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _sagemakerPublicHubContentArn?;
    get sagemakerPublicHubContentArn(): string;
    set sagemakerPublicHubContentArn(value: string);
    get sagemakerPublicHubContentArnInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _timeouts;
    get timeouts(): TfHubContentReference.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfHubContentReference.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfHubContentReference.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfHubContentReferenceTimeoutsPropertyToTerraform(struct?: TfHubContentReference.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfHubContentReferenceTimeoutsPropertyToHclTerraform(struct?: TfHubContentReference.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfHubContentReference {
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hub_content_reference#create TfHubContentReference#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hub_content_reference#delete TfHubContentReference#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hub_content_reference#update TfHubContentReference#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
