import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfImageVersionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_image_version#aliases TfImageVersion#aliases}
    */
    readonly aliases?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_image_version#base_image TfImageVersion#base_image}
    */
    readonly baseImage: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_image_version#horovod TfImageVersion#horovod}
    */
    readonly horovod?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_image_version#id TfImageVersion#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_image_version#image_name TfImageVersion#image_name}
    */
    readonly imageName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_image_version#job_type TfImageVersion#job_type}
    */
    readonly jobType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_image_version#ml_framework TfImageVersion#ml_framework}
    */
    readonly mlFramework?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_image_version#processor TfImageVersion#processor}
    */
    readonly processor?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_image_version#programming_lang TfImageVersion#programming_lang}
    */
    readonly programmingLang?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_image_version#region TfImageVersion#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_image_version#release_notes TfImageVersion#release_notes}
    */
    readonly releaseNotes?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_image_version#vendor_guidance TfImageVersion#vendor_guidance}
    */
    readonly vendorGuidance?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_image_version aws_sagemaker_image_version}
*/
export declare class TfImageVersion extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_sagemaker_image_version";
    /**
    * Generates CDKTN code for importing a TfImageVersion resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfImageVersion to import
    * @param importFromId The id of the existing TfImageVersion that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_image_version#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfImageVersion to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_image_version aws_sagemaker_image_version} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfImageVersionConfig
    */
    constructor(scope: Construct, id: string, config: TfImageVersionConfig);
    private _aliases?;
    get aliases(): string[];
    set aliases(value: string[]);
    resetAliases(): void;
    get aliasesInput(): string[] | undefined;
    get arn(): string;
    private _baseImage?;
    get baseImage(): string;
    set baseImage(value: string);
    get baseImageInput(): string | undefined;
    get containerImage(): string;
    private _horovod?;
    get horovod(): boolean | cdktn.IResolvable;
    set horovod(value: boolean | cdktn.IResolvable);
    resetHorovod(): void;
    get horovodInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get imageArn(): string;
    private _imageName?;
    get imageName(): string;
    set imageName(value: string);
    get imageNameInput(): string | undefined;
    private _jobType?;
    get jobType(): string;
    set jobType(value: string);
    resetJobType(): void;
    get jobTypeInput(): string | undefined;
    private _mlFramework?;
    get mlFramework(): string;
    set mlFramework(value: string);
    resetMlFramework(): void;
    get mlFrameworkInput(): string | undefined;
    private _processor?;
    get processor(): string;
    set processor(value: string);
    resetProcessor(): void;
    get processorInput(): string | undefined;
    private _programmingLang?;
    get programmingLang(): string;
    set programmingLang(value: string);
    resetProgrammingLang(): void;
    get programmingLangInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _releaseNotes?;
    get releaseNotes(): string;
    set releaseNotes(value: string);
    resetReleaseNotes(): void;
    get releaseNotesInput(): string | undefined;
    private _vendorGuidance?;
    get vendorGuidance(): string;
    set vendorGuidance(value: string);
    resetVendorGuidance(): void;
    get vendorGuidanceInput(): string | undefined;
    get version(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
