import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfHyperParameterTuningJobConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#name TfHyperParameterTuningJob#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#region TfHyperParameterTuningJob#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#tags TfHyperParameterTuningJob#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * autotune block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#autotune TfHyperParameterTuningJob#autotune}
    */
    readonly autotune?: TfHyperParameterTuningJob.AutotuneProperty[] | cdktn.IResolvable;
    /**
    * config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#config TfHyperParameterTuningJob#config}
    */
    readonly config?: TfHyperParameterTuningJob.ConfigProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#timeouts TfHyperParameterTuningJob#timeouts}
    */
    readonly timeouts?: TfHyperParameterTuningJob.TimeoutsProperty;
    /**
    * training_job_definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#training_job_definition TfHyperParameterTuningJob#training_job_definition}
    */
    readonly trainingJobDefinition?: TfHyperParameterTuningJob.TrainingJobDefinitionProperty[] | cdktn.IResolvable;
    /**
    * training_job_definitions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#training_job_definitions TfHyperParameterTuningJob#training_job_definitions}
    */
    readonly trainingJobDefinitions?: TfHyperParameterTuningJob.TrainingJobDefinitionsProperty[] | cdktn.IResolvable;
    /**
    * warm_start_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#warm_start_config TfHyperParameterTuningJob#warm_start_config}
    */
    readonly warmStartConfig?: TfHyperParameterTuningJob.WarmStartConfigProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job aws_sagemaker_hyper_parameter_tuning_job}
*/
export declare class TfHyperParameterTuningJob extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_sagemaker_hyper_parameter_tuning_job";
    /**
    * Generates CDKTN code for importing a TfHyperParameterTuningJob resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfHyperParameterTuningJob to import
    * @param importFromId The id of the existing TfHyperParameterTuningJob that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfHyperParameterTuningJob to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job aws_sagemaker_hyper_parameter_tuning_job} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfHyperParameterTuningJobConfig
    */
    constructor(scope: Construct, id: string, config: TfHyperParameterTuningJobConfig);
    get arn(): string;
    get failureReason(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _autotune;
    get autotune(): TfHyperParameterTuningJob.AutotunePropertyList;
    putAutotune(value: TfHyperParameterTuningJob.AutotuneProperty[] | cdktn.IResolvable): void;
    resetAutotune(): void;
    get autotuneInput(): cdktn.IResolvable | TfHyperParameterTuningJob.AutotuneProperty[] | undefined;
    private _config;
    get config(): TfHyperParameterTuningJob.ConfigPropertyList;
    putConfig(value: TfHyperParameterTuningJob.ConfigProperty[] | cdktn.IResolvable): void;
    resetConfig(): void;
    get configInput(): cdktn.IResolvable | TfHyperParameterTuningJob.ConfigProperty[] | undefined;
    private _timeouts;
    get timeouts(): TfHyperParameterTuningJob.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfHyperParameterTuningJob.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfHyperParameterTuningJob.TimeoutsProperty | undefined;
    private _trainingJobDefinition;
    get trainingJobDefinition(): TfHyperParameterTuningJob.TrainingJobDefinitionPropertyList;
    putTrainingJobDefinition(value: TfHyperParameterTuningJob.TrainingJobDefinitionProperty[] | cdktn.IResolvable): void;
    resetTrainingJobDefinition(): void;
    get trainingJobDefinitionInput(): cdktn.IResolvable | TfHyperParameterTuningJob.TrainingJobDefinitionProperty[] | undefined;
    private _trainingJobDefinitions;
    get trainingJobDefinitions(): TfHyperParameterTuningJob.TrainingJobDefinitionsPropertyList;
    putTrainingJobDefinitions(value: TfHyperParameterTuningJob.TrainingJobDefinitionsProperty[] | cdktn.IResolvable): void;
    resetTrainingJobDefinitions(): void;
    get trainingJobDefinitionsInput(): cdktn.IResolvable | TfHyperParameterTuningJob.TrainingJobDefinitionsProperty[] | undefined;
    private _warmStartConfig;
    get warmStartConfig(): TfHyperParameterTuningJob.WarmStartConfigPropertyList;
    putWarmStartConfig(value: TfHyperParameterTuningJob.WarmStartConfigProperty[] | cdktn.IResolvable): void;
    resetWarmStartConfig(): void;
    get warmStartConfigInput(): cdktn.IResolvable | TfHyperParameterTuningJob.WarmStartConfigProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfHyperParameterTuningJobAutotunePropertyToTerraform(struct?: TfHyperParameterTuningJob.AutotuneProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobAutotunePropertyToHclTerraform(struct?: TfHyperParameterTuningJob.AutotuneProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobObjectivePropertyToTerraform(struct?: TfHyperParameterTuningJob.ObjectiveProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobObjectivePropertyToHclTerraform(struct?: TfHyperParameterTuningJob.ObjectiveProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobConfigParameterRangesAutoParametersPropertyToTerraform(struct?: TfHyperParameterTuningJob.ConfigParameterRangesAutoParametersProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobConfigParameterRangesAutoParametersPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.ConfigParameterRangesAutoParametersProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobConfigParameterRangesCategoricalParameterRangesPropertyToTerraform(struct?: TfHyperParameterTuningJob.ConfigParameterRangesCategoricalParameterRangesProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobConfigParameterRangesCategoricalParameterRangesPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.ConfigParameterRangesCategoricalParameterRangesProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobConfigParameterRangesContinuousParameterRangesPropertyToTerraform(struct?: TfHyperParameterTuningJob.ConfigParameterRangesContinuousParameterRangesProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobConfigParameterRangesContinuousParameterRangesPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.ConfigParameterRangesContinuousParameterRangesProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobConfigParameterRangesIntegerParameterRangesPropertyToTerraform(struct?: TfHyperParameterTuningJob.ConfigParameterRangesIntegerParameterRangesProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobConfigParameterRangesIntegerParameterRangesPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.ConfigParameterRangesIntegerParameterRangesProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobParameterRangesPropertyToTerraform(struct?: TfHyperParameterTuningJob.ParameterRangesProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobParameterRangesPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.ParameterRangesProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobResourceLimitsPropertyToTerraform(struct?: TfHyperParameterTuningJob.ResourceLimitsProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobResourceLimitsPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.ResourceLimitsProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobHyperbandStrategyConfigPropertyToTerraform(struct?: TfHyperParameterTuningJob.HyperbandStrategyConfigProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobHyperbandStrategyConfigPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.HyperbandStrategyConfigProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobStrategyConfigPropertyToTerraform(struct?: TfHyperParameterTuningJob.StrategyConfigProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobStrategyConfigPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.StrategyConfigProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobBestObjectiveNotImprovingPropertyToTerraform(struct?: TfHyperParameterTuningJob.BestObjectiveNotImprovingProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobBestObjectiveNotImprovingPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.BestObjectiveNotImprovingProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobConvergenceDetectedPropertyToTerraform(struct?: TfHyperParameterTuningJob.ConvergenceDetectedProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobConvergenceDetectedPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.ConvergenceDetectedProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTuningJobCompletionCriteriaPropertyToTerraform(struct?: TfHyperParameterTuningJob.TuningJobCompletionCriteriaProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTuningJobCompletionCriteriaPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TuningJobCompletionCriteriaProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobConfigPropertyToTerraform(struct?: TfHyperParameterTuningJob.ConfigProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobConfigPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.ConfigProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTimeoutsPropertyToTerraform(struct?: TfHyperParameterTuningJob.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTimeoutsPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionRetryStrategyPropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionRetryStrategyProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionRetryStrategyPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionRetryStrategyProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionAlgorithmSpecificationMetricDefinitionsPropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionAlgorithmSpecificationMetricDefinitionsProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionAlgorithmSpecificationMetricDefinitionsPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionAlgorithmSpecificationMetricDefinitionsProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionAlgorithmSpecificationPropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionAlgorithmSpecificationProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionAlgorithmSpecificationPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionAlgorithmSpecificationProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionCheckpointConfigPropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionCheckpointConfigProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionCheckpointConfigPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionCheckpointConfigProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionHyperParameterRangesAutoParametersPropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionHyperParameterRangesAutoParametersProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionHyperParameterRangesAutoParametersPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionHyperParameterRangesAutoParametersProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionHyperParameterRangesCategoricalParameterRangesPropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionHyperParameterRangesCategoricalParameterRangesProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionHyperParameterRangesCategoricalParameterRangesPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionHyperParameterRangesCategoricalParameterRangesProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionHyperParameterRangesContinuousParameterRangesPropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionHyperParameterRangesContinuousParameterRangesProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionHyperParameterRangesContinuousParameterRangesPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionHyperParameterRangesContinuousParameterRangesProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionHyperParameterRangesIntegerParameterRangesPropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionHyperParameterRangesIntegerParameterRangesProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionHyperParameterRangesIntegerParameterRangesPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionHyperParameterRangesIntegerParameterRangesProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionHyperParameterRangesPropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionHyperParameterRangesProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionHyperParameterRangesPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionHyperParameterRangesProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionHyperParameterTuningResourceConfigInstanceConfigsPropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionHyperParameterTuningResourceConfigInstanceConfigsProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionHyperParameterTuningResourceConfigInstanceConfigsPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionHyperParameterTuningResourceConfigInstanceConfigsProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionHyperParameterTuningResourceConfigPropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionHyperParameterTuningResourceConfigProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionHyperParameterTuningResourceConfigPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionHyperParameterTuningResourceConfigProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionInputDataConfigDataSourceFileSystemDataSourcePropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionInputDataConfigDataSourceFileSystemDataSourceProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionInputDataConfigDataSourceFileSystemDataSourcePropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionInputDataConfigDataSourceFileSystemDataSourceProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionInputDataConfigDataSourceS3DataSourceHubAccessConfigPropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionInputDataConfigDataSourceS3DataSourceHubAccessConfigProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionInputDataConfigDataSourceS3DataSourceHubAccessConfigPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionInputDataConfigDataSourceS3DataSourceHubAccessConfigProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionInputDataConfigDataSourceS3DataSourceModelAccessConfigPropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionInputDataConfigDataSourceS3DataSourceModelAccessConfigProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionInputDataConfigDataSourceS3DataSourceModelAccessConfigPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionInputDataConfigDataSourceS3DataSourceModelAccessConfigProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionInputDataConfigDataSourceS3DataSourcePropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionInputDataConfigDataSourceS3DataSourceProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionInputDataConfigDataSourceS3DataSourcePropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionInputDataConfigDataSourceS3DataSourceProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionInputDataConfigDataSourcePropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionInputDataConfigDataSourceProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionInputDataConfigDataSourcePropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionInputDataConfigDataSourceProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionInputDataConfigShuffleConfigPropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionInputDataConfigShuffleConfigProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionInputDataConfigShuffleConfigPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionInputDataConfigShuffleConfigProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionInputDataConfigPropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionInputDataConfigProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionInputDataConfigPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionInputDataConfigProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionOutputDataConfigPropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionOutputDataConfigProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionOutputDataConfigPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionOutputDataConfigProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionResourceConfigInstanceGroupsPropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionResourceConfigInstanceGroupsProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionResourceConfigInstanceGroupsPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionResourceConfigInstanceGroupsProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionResourceConfigInstancePlacementConfigPlacementSpecificationsPropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionResourceConfigInstancePlacementConfigPlacementSpecificationsProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionResourceConfigInstancePlacementConfigPlacementSpecificationsPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionResourceConfigInstancePlacementConfigPlacementSpecificationsProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionResourceConfigInstancePlacementConfigPropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionResourceConfigInstancePlacementConfigProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionResourceConfigInstancePlacementConfigPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionResourceConfigInstancePlacementConfigProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionResourceConfigPropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionResourceConfigProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionResourceConfigPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionResourceConfigProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionStoppingConditionPropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionStoppingConditionProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionStoppingConditionPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionStoppingConditionProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionTuningObjectivePropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionTuningObjectiveProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionTuningObjectivePropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionTuningObjectiveProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionVpcConfigPropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionVpcConfigProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionVpcConfigPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionVpcConfigProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionPropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsRetryStrategyPropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsRetryStrategyProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsRetryStrategyPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsRetryStrategyProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsAlgorithmSpecificationMetricDefinitionsPropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsAlgorithmSpecificationMetricDefinitionsProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsAlgorithmSpecificationMetricDefinitionsPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsAlgorithmSpecificationMetricDefinitionsProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsAlgorithmSpecificationPropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsAlgorithmSpecificationProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsAlgorithmSpecificationPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsAlgorithmSpecificationProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsCheckpointConfigPropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsCheckpointConfigProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsCheckpointConfigPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsCheckpointConfigProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsHyperParameterRangesAutoParametersPropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsHyperParameterRangesAutoParametersProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsHyperParameterRangesAutoParametersPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsHyperParameterRangesAutoParametersProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsHyperParameterRangesCategoricalParameterRangesPropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsHyperParameterRangesCategoricalParameterRangesProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsHyperParameterRangesCategoricalParameterRangesPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsHyperParameterRangesCategoricalParameterRangesProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsHyperParameterRangesContinuousParameterRangesPropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsHyperParameterRangesContinuousParameterRangesProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsHyperParameterRangesContinuousParameterRangesPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsHyperParameterRangesContinuousParameterRangesProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsHyperParameterRangesIntegerParameterRangesPropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsHyperParameterRangesIntegerParameterRangesProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsHyperParameterRangesIntegerParameterRangesPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsHyperParameterRangesIntegerParameterRangesProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsHyperParameterRangesPropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsHyperParameterRangesProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsHyperParameterRangesPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsHyperParameterRangesProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsHyperParameterTuningResourceConfigInstanceConfigsPropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsHyperParameterTuningResourceConfigInstanceConfigsProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsHyperParameterTuningResourceConfigInstanceConfigsPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsHyperParameterTuningResourceConfigInstanceConfigsProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsHyperParameterTuningResourceConfigPropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsHyperParameterTuningResourceConfigProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsHyperParameterTuningResourceConfigPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsHyperParameterTuningResourceConfigProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsInputDataConfigDataSourceFileSystemDataSourcePropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsInputDataConfigDataSourceFileSystemDataSourceProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsInputDataConfigDataSourceFileSystemDataSourcePropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsInputDataConfigDataSourceFileSystemDataSourceProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsInputDataConfigDataSourceS3DataSourceHubAccessConfigPropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsInputDataConfigDataSourceS3DataSourceHubAccessConfigProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsInputDataConfigDataSourceS3DataSourceHubAccessConfigPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsInputDataConfigDataSourceS3DataSourceHubAccessConfigProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsInputDataConfigDataSourceS3DataSourceModelAccessConfigPropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsInputDataConfigDataSourceS3DataSourceModelAccessConfigProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsInputDataConfigDataSourceS3DataSourceModelAccessConfigPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsInputDataConfigDataSourceS3DataSourceModelAccessConfigProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsInputDataConfigDataSourceS3DataSourcePropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsInputDataConfigDataSourceS3DataSourceProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsInputDataConfigDataSourceS3DataSourcePropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsInputDataConfigDataSourceS3DataSourceProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsInputDataConfigDataSourcePropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsInputDataConfigDataSourceProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsInputDataConfigDataSourcePropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsInputDataConfigDataSourceProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsInputDataConfigShuffleConfigPropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsInputDataConfigShuffleConfigProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsInputDataConfigShuffleConfigPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsInputDataConfigShuffleConfigProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsInputDataConfigPropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsInputDataConfigProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsInputDataConfigPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsInputDataConfigProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsOutputDataConfigPropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsOutputDataConfigProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsOutputDataConfigPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsOutputDataConfigProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsResourceConfigInstanceGroupsPropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsResourceConfigInstanceGroupsProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsResourceConfigInstanceGroupsPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsResourceConfigInstanceGroupsProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsResourceConfigInstancePlacementConfigPlacementSpecificationsPropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsResourceConfigInstancePlacementConfigPlacementSpecificationsProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsResourceConfigInstancePlacementConfigPlacementSpecificationsPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsResourceConfigInstancePlacementConfigPlacementSpecificationsProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsResourceConfigInstancePlacementConfigPropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsResourceConfigInstancePlacementConfigProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsResourceConfigInstancePlacementConfigPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsResourceConfigInstancePlacementConfigProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsResourceConfigPropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsResourceConfigProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsResourceConfigPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsResourceConfigProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsStoppingConditionPropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsStoppingConditionProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsStoppingConditionPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsStoppingConditionProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsTuningObjectivePropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsTuningObjectiveProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsTuningObjectivePropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsTuningObjectiveProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsVpcConfigPropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsVpcConfigProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsVpcConfigPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsVpcConfigProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsPropertyToTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobTrainingJobDefinitionsPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.TrainingJobDefinitionsProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobParentHyperParameterTuningJobsPropertyToTerraform(struct?: TfHyperParameterTuningJob.ParentHyperParameterTuningJobsProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobParentHyperParameterTuningJobsPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.ParentHyperParameterTuningJobsProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobWarmStartConfigPropertyToTerraform(struct?: TfHyperParameterTuningJob.WarmStartConfigProperty | cdktn.IResolvable): any;
export declare function tfHyperParameterTuningJobWarmStartConfigPropertyToHclTerraform(struct?: TfHyperParameterTuningJob.WarmStartConfigProperty | cdktn.IResolvable): any;
export declare namespace TfHyperParameterTuningJob {
    interface AutotuneProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#mode TfHyperParameterTuningJob#mode}
        */
        readonly mode: string;
    }
    class AutotunePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AutotuneProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AutotuneProperty | cdktn.IResolvable | undefined);
        private _mode?;
        get mode(): string;
        set mode(value: string);
        get modeInput(): string | undefined;
    }
    class AutotunePropertyList extends cdktn.ComplexList {
        internalValue?: AutotuneProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AutotunePropertyOutputReference;
    }
    interface ObjectiveProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#metric_name TfHyperParameterTuningJob#metric_name}
        */
        readonly metricName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#type TfHyperParameterTuningJob#type}
        */
        readonly type: string;
    }
    class ObjectivePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ObjectiveProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ObjectiveProperty | cdktn.IResolvable | undefined);
        private _metricName?;
        get metricName(): string;
        set metricName(value: string);
        get metricNameInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class ObjectivePropertyList extends cdktn.ComplexList {
        internalValue?: ObjectiveProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ObjectivePropertyOutputReference;
    }
    interface ConfigParameterRangesAutoParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#name TfHyperParameterTuningJob#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#value_hint TfHyperParameterTuningJob#value_hint}
        */
        readonly valueHint: string;
    }
    class ConfigParameterRangesAutoParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConfigParameterRangesAutoParametersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConfigParameterRangesAutoParametersProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _valueHint?;
        get valueHint(): string;
        set valueHint(value: string);
        get valueHintInput(): string | undefined;
    }
    class ConfigParameterRangesAutoParametersPropertyList extends cdktn.ComplexList {
        internalValue?: ConfigParameterRangesAutoParametersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConfigParameterRangesAutoParametersPropertyOutputReference;
    }
    interface ConfigParameterRangesCategoricalParameterRangesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#name TfHyperParameterTuningJob#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#values TfHyperParameterTuningJob#values}
        */
        readonly values: string[];
    }
    class ConfigParameterRangesCategoricalParameterRangesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConfigParameterRangesCategoricalParameterRangesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConfigParameterRangesCategoricalParameterRangesProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class ConfigParameterRangesCategoricalParameterRangesPropertyList extends cdktn.ComplexList {
        internalValue?: ConfigParameterRangesCategoricalParameterRangesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConfigParameterRangesCategoricalParameterRangesPropertyOutputReference;
    }
    interface ConfigParameterRangesContinuousParameterRangesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#max_value TfHyperParameterTuningJob#max_value}
        */
        readonly maxValue: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#min_value TfHyperParameterTuningJob#min_value}
        */
        readonly minValue: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#name TfHyperParameterTuningJob#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#scaling_type TfHyperParameterTuningJob#scaling_type}
        */
        readonly scalingType?: string;
    }
    class ConfigParameterRangesContinuousParameterRangesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConfigParameterRangesContinuousParameterRangesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConfigParameterRangesContinuousParameterRangesProperty | cdktn.IResolvable | undefined);
        private _maxValue?;
        get maxValue(): string;
        set maxValue(value: string);
        get maxValueInput(): string | undefined;
        private _minValue?;
        get minValue(): string;
        set minValue(value: string);
        get minValueInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _scalingType?;
        get scalingType(): string;
        set scalingType(value: string);
        resetScalingType(): void;
        get scalingTypeInput(): string | undefined;
    }
    class ConfigParameterRangesContinuousParameterRangesPropertyList extends cdktn.ComplexList {
        internalValue?: ConfigParameterRangesContinuousParameterRangesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConfigParameterRangesContinuousParameterRangesPropertyOutputReference;
    }
    interface ConfigParameterRangesIntegerParameterRangesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#max_value TfHyperParameterTuningJob#max_value}
        */
        readonly maxValue: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#min_value TfHyperParameterTuningJob#min_value}
        */
        readonly minValue: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#name TfHyperParameterTuningJob#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#scaling_type TfHyperParameterTuningJob#scaling_type}
        */
        readonly scalingType?: string;
    }
    class ConfigParameterRangesIntegerParameterRangesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConfigParameterRangesIntegerParameterRangesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConfigParameterRangesIntegerParameterRangesProperty | cdktn.IResolvable | undefined);
        private _maxValue?;
        get maxValue(): string;
        set maxValue(value: string);
        get maxValueInput(): string | undefined;
        private _minValue?;
        get minValue(): string;
        set minValue(value: string);
        get minValueInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _scalingType?;
        get scalingType(): string;
        set scalingType(value: string);
        resetScalingType(): void;
        get scalingTypeInput(): string | undefined;
    }
    class ConfigParameterRangesIntegerParameterRangesPropertyList extends cdktn.ComplexList {
        internalValue?: ConfigParameterRangesIntegerParameterRangesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConfigParameterRangesIntegerParameterRangesPropertyOutputReference;
    }
    interface ParameterRangesProperty {
        /**
        * auto_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#auto_parameters TfHyperParameterTuningJob#auto_parameters}
        */
        readonly autoParameters?: ConfigParameterRangesAutoParametersProperty[] | cdktn.IResolvable;
        /**
        * categorical_parameter_ranges block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#categorical_parameter_ranges TfHyperParameterTuningJob#categorical_parameter_ranges}
        */
        readonly categoricalParameterRanges?: ConfigParameterRangesCategoricalParameterRangesProperty[] | cdktn.IResolvable;
        /**
        * continuous_parameter_ranges block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#continuous_parameter_ranges TfHyperParameterTuningJob#continuous_parameter_ranges}
        */
        readonly continuousParameterRanges?: ConfigParameterRangesContinuousParameterRangesProperty[] | cdktn.IResolvable;
        /**
        * integer_parameter_ranges block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#integer_parameter_ranges TfHyperParameterTuningJob#integer_parameter_ranges}
        */
        readonly integerParameterRanges?: ConfigParameterRangesIntegerParameterRangesProperty[] | cdktn.IResolvable;
    }
    class ParameterRangesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ParameterRangesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ParameterRangesProperty | cdktn.IResolvable | undefined);
        private _autoParameters;
        get autoParameters(): ConfigParameterRangesAutoParametersPropertyList;
        putAutoParameters(value: ConfigParameterRangesAutoParametersProperty[] | cdktn.IResolvable): void;
        resetAutoParameters(): void;
        get autoParametersInput(): cdktn.IResolvable | ConfigParameterRangesAutoParametersProperty[] | undefined;
        private _categoricalParameterRanges;
        get categoricalParameterRanges(): ConfigParameterRangesCategoricalParameterRangesPropertyList;
        putCategoricalParameterRanges(value: ConfigParameterRangesCategoricalParameterRangesProperty[] | cdktn.IResolvable): void;
        resetCategoricalParameterRanges(): void;
        get categoricalParameterRangesInput(): cdktn.IResolvable | ConfigParameterRangesCategoricalParameterRangesProperty[] | undefined;
        private _continuousParameterRanges;
        get continuousParameterRanges(): ConfigParameterRangesContinuousParameterRangesPropertyList;
        putContinuousParameterRanges(value: ConfigParameterRangesContinuousParameterRangesProperty[] | cdktn.IResolvable): void;
        resetContinuousParameterRanges(): void;
        get continuousParameterRangesInput(): cdktn.IResolvable | ConfigParameterRangesContinuousParameterRangesProperty[] | undefined;
        private _integerParameterRanges;
        get integerParameterRanges(): ConfigParameterRangesIntegerParameterRangesPropertyList;
        putIntegerParameterRanges(value: ConfigParameterRangesIntegerParameterRangesProperty[] | cdktn.IResolvable): void;
        resetIntegerParameterRanges(): void;
        get integerParameterRangesInput(): cdktn.IResolvable | ConfigParameterRangesIntegerParameterRangesProperty[] | undefined;
    }
    class ParameterRangesPropertyList extends cdktn.ComplexList {
        internalValue?: ParameterRangesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ParameterRangesPropertyOutputReference;
    }
    interface ResourceLimitsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#max_number_of_training_jobs TfHyperParameterTuningJob#max_number_of_training_jobs}
        */
        readonly maxNumberOfTrainingJobs?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#max_parallel_training_jobs TfHyperParameterTuningJob#max_parallel_training_jobs}
        */
        readonly maxParallelTrainingJobs: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#max_runtime_in_seconds TfHyperParameterTuningJob#max_runtime_in_seconds}
        */
        readonly maxRuntimeInSeconds?: number;
    }
    class ResourceLimitsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceLimitsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceLimitsProperty | cdktn.IResolvable | undefined);
        private _maxNumberOfTrainingJobs?;
        get maxNumberOfTrainingJobs(): number;
        set maxNumberOfTrainingJobs(value: number);
        resetMaxNumberOfTrainingJobs(): void;
        get maxNumberOfTrainingJobsInput(): number | undefined;
        private _maxParallelTrainingJobs?;
        get maxParallelTrainingJobs(): number;
        set maxParallelTrainingJobs(value: number);
        get maxParallelTrainingJobsInput(): number | undefined;
        private _maxRuntimeInSeconds?;
        get maxRuntimeInSeconds(): number;
        set maxRuntimeInSeconds(value: number);
        resetMaxRuntimeInSeconds(): void;
        get maxRuntimeInSecondsInput(): number | undefined;
    }
    class ResourceLimitsPropertyList extends cdktn.ComplexList {
        internalValue?: ResourceLimitsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceLimitsPropertyOutputReference;
    }
    interface HyperbandStrategyConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#max_resource TfHyperParameterTuningJob#max_resource}
        */
        readonly maxResource?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#min_resource TfHyperParameterTuningJob#min_resource}
        */
        readonly minResource?: number;
    }
    class HyperbandStrategyConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HyperbandStrategyConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: HyperbandStrategyConfigProperty | cdktn.IResolvable | undefined);
        private _maxResource?;
        get maxResource(): number;
        set maxResource(value: number);
        resetMaxResource(): void;
        get maxResourceInput(): number | undefined;
        private _minResource?;
        get minResource(): number;
        set minResource(value: number);
        resetMinResource(): void;
        get minResourceInput(): number | undefined;
    }
    class HyperbandStrategyConfigPropertyList extends cdktn.ComplexList {
        internalValue?: HyperbandStrategyConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HyperbandStrategyConfigPropertyOutputReference;
    }
    interface StrategyConfigProperty {
        /**
        * hyperband_strategy_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#hyperband_strategy_config TfHyperParameterTuningJob#hyperband_strategy_config}
        */
        readonly hyperbandStrategyConfig?: HyperbandStrategyConfigProperty[] | cdktn.IResolvable;
    }
    class StrategyConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StrategyConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StrategyConfigProperty | cdktn.IResolvable | undefined);
        private _hyperbandStrategyConfig;
        get hyperbandStrategyConfig(): HyperbandStrategyConfigPropertyList;
        putHyperbandStrategyConfig(value: HyperbandStrategyConfigProperty[] | cdktn.IResolvable): void;
        resetHyperbandStrategyConfig(): void;
        get hyperbandStrategyConfigInput(): cdktn.IResolvable | HyperbandStrategyConfigProperty[] | undefined;
    }
    class StrategyConfigPropertyList extends cdktn.ComplexList {
        internalValue?: StrategyConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StrategyConfigPropertyOutputReference;
    }
    interface BestObjectiveNotImprovingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#max_number_of_training_jobs_not_improving TfHyperParameterTuningJob#max_number_of_training_jobs_not_improving}
        */
        readonly maxNumberOfTrainingJobsNotImproving?: number;
    }
    class BestObjectiveNotImprovingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BestObjectiveNotImprovingProperty | cdktn.IResolvable | undefined;
        set internalValue(value: BestObjectiveNotImprovingProperty | cdktn.IResolvable | undefined);
        private _maxNumberOfTrainingJobsNotImproving?;
        get maxNumberOfTrainingJobsNotImproving(): number;
        set maxNumberOfTrainingJobsNotImproving(value: number);
        resetMaxNumberOfTrainingJobsNotImproving(): void;
        get maxNumberOfTrainingJobsNotImprovingInput(): number | undefined;
    }
    class BestObjectiveNotImprovingPropertyList extends cdktn.ComplexList {
        internalValue?: BestObjectiveNotImprovingProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BestObjectiveNotImprovingPropertyOutputReference;
    }
    interface ConvergenceDetectedProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#complete_on_convergence TfHyperParameterTuningJob#complete_on_convergence}
        */
        readonly completeOnConvergence?: string;
    }
    class ConvergenceDetectedPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConvergenceDetectedProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConvergenceDetectedProperty | cdktn.IResolvable | undefined);
        private _completeOnConvergence?;
        get completeOnConvergence(): string;
        set completeOnConvergence(value: string);
        resetCompleteOnConvergence(): void;
        get completeOnConvergenceInput(): string | undefined;
    }
    class ConvergenceDetectedPropertyList extends cdktn.ComplexList {
        internalValue?: ConvergenceDetectedProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConvergenceDetectedPropertyOutputReference;
    }
    interface TuningJobCompletionCriteriaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#target_objective_metric_value TfHyperParameterTuningJob#target_objective_metric_value}
        */
        readonly targetObjectiveMetricValue?: number;
        /**
        * best_objective_not_improving block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#best_objective_not_improving TfHyperParameterTuningJob#best_objective_not_improving}
        */
        readonly bestObjectiveNotImproving?: BestObjectiveNotImprovingProperty[] | cdktn.IResolvable;
        /**
        * convergence_detected block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#convergence_detected TfHyperParameterTuningJob#convergence_detected}
        */
        readonly convergenceDetected?: ConvergenceDetectedProperty[] | cdktn.IResolvable;
    }
    class TuningJobCompletionCriteriaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TuningJobCompletionCriteriaProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TuningJobCompletionCriteriaProperty | cdktn.IResolvable | undefined);
        private _targetObjectiveMetricValue?;
        get targetObjectiveMetricValue(): number;
        set targetObjectiveMetricValue(value: number);
        resetTargetObjectiveMetricValue(): void;
        get targetObjectiveMetricValueInput(): number | undefined;
        private _bestObjectiveNotImproving;
        get bestObjectiveNotImproving(): BestObjectiveNotImprovingPropertyList;
        putBestObjectiveNotImproving(value: BestObjectiveNotImprovingProperty[] | cdktn.IResolvable): void;
        resetBestObjectiveNotImproving(): void;
        get bestObjectiveNotImprovingInput(): cdktn.IResolvable | BestObjectiveNotImprovingProperty[] | undefined;
        private _convergenceDetected;
        get convergenceDetected(): ConvergenceDetectedPropertyList;
        putConvergenceDetected(value: ConvergenceDetectedProperty[] | cdktn.IResolvable): void;
        resetConvergenceDetected(): void;
        get convergenceDetectedInput(): cdktn.IResolvable | ConvergenceDetectedProperty[] | undefined;
    }
    class TuningJobCompletionCriteriaPropertyList extends cdktn.ComplexList {
        internalValue?: TuningJobCompletionCriteriaProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TuningJobCompletionCriteriaPropertyOutputReference;
    }
    interface ConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#random_seed TfHyperParameterTuningJob#random_seed}
        */
        readonly randomSeed?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#strategy TfHyperParameterTuningJob#strategy}
        */
        readonly strategy: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#training_job_early_stopping_type TfHyperParameterTuningJob#training_job_early_stopping_type}
        */
        readonly trainingJobEarlyStoppingType?: string;
        /**
        * objective block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#objective TfHyperParameterTuningJob#objective}
        */
        readonly objective?: ObjectiveProperty[] | cdktn.IResolvable;
        /**
        * parameter_ranges block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#parameter_ranges TfHyperParameterTuningJob#parameter_ranges}
        */
        readonly parameterRanges?: ParameterRangesProperty[] | cdktn.IResolvable;
        /**
        * resource_limits block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#resource_limits TfHyperParameterTuningJob#resource_limits}
        */
        readonly resourceLimits?: ResourceLimitsProperty[] | cdktn.IResolvable;
        /**
        * strategy_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#strategy_config TfHyperParameterTuningJob#strategy_config}
        */
        readonly strategyConfig?: StrategyConfigProperty[] | cdktn.IResolvable;
        /**
        * tuning_job_completion_criteria block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#tuning_job_completion_criteria TfHyperParameterTuningJob#tuning_job_completion_criteria}
        */
        readonly tuningJobCompletionCriteria?: TuningJobCompletionCriteriaProperty[] | cdktn.IResolvable;
    }
    class ConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConfigProperty | cdktn.IResolvable | undefined);
        private _randomSeed?;
        get randomSeed(): number;
        set randomSeed(value: number);
        resetRandomSeed(): void;
        get randomSeedInput(): number | undefined;
        private _strategy?;
        get strategy(): string;
        set strategy(value: string);
        get strategyInput(): string | undefined;
        private _trainingJobEarlyStoppingType?;
        get trainingJobEarlyStoppingType(): string;
        set trainingJobEarlyStoppingType(value: string);
        resetTrainingJobEarlyStoppingType(): void;
        get trainingJobEarlyStoppingTypeInput(): string | undefined;
        private _objective;
        get objective(): ObjectivePropertyList;
        putObjective(value: ObjectiveProperty[] | cdktn.IResolvable): void;
        resetObjective(): void;
        get objectiveInput(): cdktn.IResolvable | ObjectiveProperty[] | undefined;
        private _parameterRanges;
        get parameterRanges(): ParameterRangesPropertyList;
        putParameterRanges(value: ParameterRangesProperty[] | cdktn.IResolvable): void;
        resetParameterRanges(): void;
        get parameterRangesInput(): cdktn.IResolvable | ParameterRangesProperty[] | undefined;
        private _resourceLimits;
        get resourceLimits(): ResourceLimitsPropertyList;
        putResourceLimits(value: ResourceLimitsProperty[] | cdktn.IResolvable): void;
        resetResourceLimits(): void;
        get resourceLimitsInput(): cdktn.IResolvable | ResourceLimitsProperty[] | undefined;
        private _strategyConfig;
        get strategyConfig(): StrategyConfigPropertyList;
        putStrategyConfig(value: StrategyConfigProperty[] | cdktn.IResolvable): void;
        resetStrategyConfig(): void;
        get strategyConfigInput(): cdktn.IResolvable | StrategyConfigProperty[] | undefined;
        private _tuningJobCompletionCriteria;
        get tuningJobCompletionCriteria(): TuningJobCompletionCriteriaPropertyList;
        putTuningJobCompletionCriteria(value: TuningJobCompletionCriteriaProperty[] | cdktn.IResolvable): void;
        resetTuningJobCompletionCriteria(): void;
        get tuningJobCompletionCriteriaInput(): cdktn.IResolvable | TuningJobCompletionCriteriaProperty[] | undefined;
    }
    class ConfigPropertyList extends cdktn.ComplexList {
        internalValue?: ConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConfigPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#create TfHyperParameterTuningJob#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#delete TfHyperParameterTuningJob#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
    interface TrainingJobDefinitionRetryStrategyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#maximum_retry_attempts TfHyperParameterTuningJob#maximum_retry_attempts}
        */
        readonly maximumRetryAttempts?: number;
    }
    class TrainingJobDefinitionRetryStrategyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionRetryStrategyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionRetryStrategyProperty | cdktn.IResolvable | undefined);
        private _maximumRetryAttempts?;
        get maximumRetryAttempts(): number;
        set maximumRetryAttempts(value: number);
        resetMaximumRetryAttempts(): void;
        get maximumRetryAttemptsInput(): number | undefined;
    }
    class TrainingJobDefinitionRetryStrategyPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionRetryStrategyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionRetryStrategyPropertyOutputReference;
    }
    interface TrainingJobDefinitionAlgorithmSpecificationMetricDefinitionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#name TfHyperParameterTuningJob#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#regex TfHyperParameterTuningJob#regex}
        */
        readonly regex: string;
    }
    class TrainingJobDefinitionAlgorithmSpecificationMetricDefinitionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionAlgorithmSpecificationMetricDefinitionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionAlgorithmSpecificationMetricDefinitionsProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _regex?;
        get regex(): string;
        set regex(value: string);
        get regexInput(): string | undefined;
    }
    class TrainingJobDefinitionAlgorithmSpecificationMetricDefinitionsPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionAlgorithmSpecificationMetricDefinitionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionAlgorithmSpecificationMetricDefinitionsPropertyOutputReference;
    }
    interface TrainingJobDefinitionAlgorithmSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#algorithm_name TfHyperParameterTuningJob#algorithm_name}
        */
        readonly algorithmName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#training_image TfHyperParameterTuningJob#training_image}
        */
        readonly trainingImage?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#training_input_mode TfHyperParameterTuningJob#training_input_mode}
        */
        readonly trainingInputMode: string;
        /**
        * metric_definitions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#metric_definitions TfHyperParameterTuningJob#metric_definitions}
        */
        readonly metricDefinitions?: TrainingJobDefinitionAlgorithmSpecificationMetricDefinitionsProperty[] | cdktn.IResolvable;
    }
    class TrainingJobDefinitionAlgorithmSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionAlgorithmSpecificationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionAlgorithmSpecificationProperty | cdktn.IResolvable | undefined);
        private _algorithmName?;
        get algorithmName(): string;
        set algorithmName(value: string);
        resetAlgorithmName(): void;
        get algorithmNameInput(): string | undefined;
        private _trainingImage?;
        get trainingImage(): string;
        set trainingImage(value: string);
        resetTrainingImage(): void;
        get trainingImageInput(): string | undefined;
        private _trainingInputMode?;
        get trainingInputMode(): string;
        set trainingInputMode(value: string);
        get trainingInputModeInput(): string | undefined;
        private _metricDefinitions;
        get metricDefinitions(): TrainingJobDefinitionAlgorithmSpecificationMetricDefinitionsPropertyList;
        putMetricDefinitions(value: TrainingJobDefinitionAlgorithmSpecificationMetricDefinitionsProperty[] | cdktn.IResolvable): void;
        resetMetricDefinitions(): void;
        get metricDefinitionsInput(): cdktn.IResolvable | TrainingJobDefinitionAlgorithmSpecificationMetricDefinitionsProperty[] | undefined;
    }
    class TrainingJobDefinitionAlgorithmSpecificationPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionAlgorithmSpecificationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionAlgorithmSpecificationPropertyOutputReference;
    }
    interface TrainingJobDefinitionCheckpointConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#local_path TfHyperParameterTuningJob#local_path}
        */
        readonly localPath?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#s3_uri TfHyperParameterTuningJob#s3_uri}
        */
        readonly s3Uri: string;
    }
    class TrainingJobDefinitionCheckpointConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionCheckpointConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionCheckpointConfigProperty | cdktn.IResolvable | undefined);
        private _localPath?;
        get localPath(): string;
        set localPath(value: string);
        resetLocalPath(): void;
        get localPathInput(): string | undefined;
        private _s3Uri?;
        get s3Uri(): string;
        set s3Uri(value: string);
        get s3UriInput(): string | undefined;
    }
    class TrainingJobDefinitionCheckpointConfigPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionCheckpointConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionCheckpointConfigPropertyOutputReference;
    }
    interface TrainingJobDefinitionHyperParameterRangesAutoParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#name TfHyperParameterTuningJob#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#value_hint TfHyperParameterTuningJob#value_hint}
        */
        readonly valueHint: string;
    }
    class TrainingJobDefinitionHyperParameterRangesAutoParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionHyperParameterRangesAutoParametersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionHyperParameterRangesAutoParametersProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _valueHint?;
        get valueHint(): string;
        set valueHint(value: string);
        get valueHintInput(): string | undefined;
    }
    class TrainingJobDefinitionHyperParameterRangesAutoParametersPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionHyperParameterRangesAutoParametersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionHyperParameterRangesAutoParametersPropertyOutputReference;
    }
    interface TrainingJobDefinitionHyperParameterRangesCategoricalParameterRangesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#name TfHyperParameterTuningJob#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#values TfHyperParameterTuningJob#values}
        */
        readonly values: string[];
    }
    class TrainingJobDefinitionHyperParameterRangesCategoricalParameterRangesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionHyperParameterRangesCategoricalParameterRangesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionHyperParameterRangesCategoricalParameterRangesProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class TrainingJobDefinitionHyperParameterRangesCategoricalParameterRangesPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionHyperParameterRangesCategoricalParameterRangesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionHyperParameterRangesCategoricalParameterRangesPropertyOutputReference;
    }
    interface TrainingJobDefinitionHyperParameterRangesContinuousParameterRangesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#max_value TfHyperParameterTuningJob#max_value}
        */
        readonly maxValue: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#min_value TfHyperParameterTuningJob#min_value}
        */
        readonly minValue: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#name TfHyperParameterTuningJob#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#scaling_type TfHyperParameterTuningJob#scaling_type}
        */
        readonly scalingType?: string;
    }
    class TrainingJobDefinitionHyperParameterRangesContinuousParameterRangesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionHyperParameterRangesContinuousParameterRangesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionHyperParameterRangesContinuousParameterRangesProperty | cdktn.IResolvable | undefined);
        private _maxValue?;
        get maxValue(): string;
        set maxValue(value: string);
        get maxValueInput(): string | undefined;
        private _minValue?;
        get minValue(): string;
        set minValue(value: string);
        get minValueInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _scalingType?;
        get scalingType(): string;
        set scalingType(value: string);
        resetScalingType(): void;
        get scalingTypeInput(): string | undefined;
    }
    class TrainingJobDefinitionHyperParameterRangesContinuousParameterRangesPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionHyperParameterRangesContinuousParameterRangesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionHyperParameterRangesContinuousParameterRangesPropertyOutputReference;
    }
    interface TrainingJobDefinitionHyperParameterRangesIntegerParameterRangesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#max_value TfHyperParameterTuningJob#max_value}
        */
        readonly maxValue: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#min_value TfHyperParameterTuningJob#min_value}
        */
        readonly minValue: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#name TfHyperParameterTuningJob#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#scaling_type TfHyperParameterTuningJob#scaling_type}
        */
        readonly scalingType?: string;
    }
    class TrainingJobDefinitionHyperParameterRangesIntegerParameterRangesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionHyperParameterRangesIntegerParameterRangesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionHyperParameterRangesIntegerParameterRangesProperty | cdktn.IResolvable | undefined);
        private _maxValue?;
        get maxValue(): string;
        set maxValue(value: string);
        get maxValueInput(): string | undefined;
        private _minValue?;
        get minValue(): string;
        set minValue(value: string);
        get minValueInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _scalingType?;
        get scalingType(): string;
        set scalingType(value: string);
        resetScalingType(): void;
        get scalingTypeInput(): string | undefined;
    }
    class TrainingJobDefinitionHyperParameterRangesIntegerParameterRangesPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionHyperParameterRangesIntegerParameterRangesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionHyperParameterRangesIntegerParameterRangesPropertyOutputReference;
    }
    interface TrainingJobDefinitionHyperParameterRangesProperty {
        /**
        * auto_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#auto_parameters TfHyperParameterTuningJob#auto_parameters}
        */
        readonly autoParameters?: TrainingJobDefinitionHyperParameterRangesAutoParametersProperty[] | cdktn.IResolvable;
        /**
        * categorical_parameter_ranges block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#categorical_parameter_ranges TfHyperParameterTuningJob#categorical_parameter_ranges}
        */
        readonly categoricalParameterRanges?: TrainingJobDefinitionHyperParameterRangesCategoricalParameterRangesProperty[] | cdktn.IResolvable;
        /**
        * continuous_parameter_ranges block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#continuous_parameter_ranges TfHyperParameterTuningJob#continuous_parameter_ranges}
        */
        readonly continuousParameterRanges?: TrainingJobDefinitionHyperParameterRangesContinuousParameterRangesProperty[] | cdktn.IResolvable;
        /**
        * integer_parameter_ranges block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#integer_parameter_ranges TfHyperParameterTuningJob#integer_parameter_ranges}
        */
        readonly integerParameterRanges?: TrainingJobDefinitionHyperParameterRangesIntegerParameterRangesProperty[] | cdktn.IResolvable;
    }
    class TrainingJobDefinitionHyperParameterRangesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionHyperParameterRangesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionHyperParameterRangesProperty | cdktn.IResolvable | undefined);
        private _autoParameters;
        get autoParameters(): TrainingJobDefinitionHyperParameterRangesAutoParametersPropertyList;
        putAutoParameters(value: TrainingJobDefinitionHyperParameterRangesAutoParametersProperty[] | cdktn.IResolvable): void;
        resetAutoParameters(): void;
        get autoParametersInput(): cdktn.IResolvable | TrainingJobDefinitionHyperParameterRangesAutoParametersProperty[] | undefined;
        private _categoricalParameterRanges;
        get categoricalParameterRanges(): TrainingJobDefinitionHyperParameterRangesCategoricalParameterRangesPropertyList;
        putCategoricalParameterRanges(value: TrainingJobDefinitionHyperParameterRangesCategoricalParameterRangesProperty[] | cdktn.IResolvable): void;
        resetCategoricalParameterRanges(): void;
        get categoricalParameterRangesInput(): cdktn.IResolvable | TrainingJobDefinitionHyperParameterRangesCategoricalParameterRangesProperty[] | undefined;
        private _continuousParameterRanges;
        get continuousParameterRanges(): TrainingJobDefinitionHyperParameterRangesContinuousParameterRangesPropertyList;
        putContinuousParameterRanges(value: TrainingJobDefinitionHyperParameterRangesContinuousParameterRangesProperty[] | cdktn.IResolvable): void;
        resetContinuousParameterRanges(): void;
        get continuousParameterRangesInput(): cdktn.IResolvable | TrainingJobDefinitionHyperParameterRangesContinuousParameterRangesProperty[] | undefined;
        private _integerParameterRanges;
        get integerParameterRanges(): TrainingJobDefinitionHyperParameterRangesIntegerParameterRangesPropertyList;
        putIntegerParameterRanges(value: TrainingJobDefinitionHyperParameterRangesIntegerParameterRangesProperty[] | cdktn.IResolvable): void;
        resetIntegerParameterRanges(): void;
        get integerParameterRangesInput(): cdktn.IResolvable | TrainingJobDefinitionHyperParameterRangesIntegerParameterRangesProperty[] | undefined;
    }
    class TrainingJobDefinitionHyperParameterRangesPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionHyperParameterRangesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionHyperParameterRangesPropertyOutputReference;
    }
    interface TrainingJobDefinitionHyperParameterTuningResourceConfigInstanceConfigsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#instance_count TfHyperParameterTuningJob#instance_count}
        */
        readonly instanceCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#instance_type TfHyperParameterTuningJob#instance_type}
        */
        readonly instanceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#volume_size_in_gb TfHyperParameterTuningJob#volume_size_in_gb}
        */
        readonly volumeSizeInGb?: number;
    }
    class TrainingJobDefinitionHyperParameterTuningResourceConfigInstanceConfigsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionHyperParameterTuningResourceConfigInstanceConfigsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionHyperParameterTuningResourceConfigInstanceConfigsProperty | cdktn.IResolvable | undefined);
        private _instanceCount?;
        get instanceCount(): number;
        set instanceCount(value: number);
        resetInstanceCount(): void;
        get instanceCountInput(): number | undefined;
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        resetInstanceType(): void;
        get instanceTypeInput(): string | undefined;
        private _volumeSizeInGb?;
        get volumeSizeInGb(): number;
        set volumeSizeInGb(value: number);
        resetVolumeSizeInGb(): void;
        get volumeSizeInGbInput(): number | undefined;
    }
    class TrainingJobDefinitionHyperParameterTuningResourceConfigInstanceConfigsPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionHyperParameterTuningResourceConfigInstanceConfigsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionHyperParameterTuningResourceConfigInstanceConfigsPropertyOutputReference;
    }
    interface TrainingJobDefinitionHyperParameterTuningResourceConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#allocation_strategy TfHyperParameterTuningJob#allocation_strategy}
        */
        readonly allocationStrategy?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#instance_count TfHyperParameterTuningJob#instance_count}
        */
        readonly instanceCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#instance_type TfHyperParameterTuningJob#instance_type}
        */
        readonly instanceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#volume_kms_key_id TfHyperParameterTuningJob#volume_kms_key_id}
        */
        readonly volumeKmsKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#volume_size_in_gb TfHyperParameterTuningJob#volume_size_in_gb}
        */
        readonly volumeSizeInGb?: number;
        /**
        * instance_configs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#instance_configs TfHyperParameterTuningJob#instance_configs}
        */
        readonly instanceConfigs?: TrainingJobDefinitionHyperParameterTuningResourceConfigInstanceConfigsProperty[] | cdktn.IResolvable;
    }
    class TrainingJobDefinitionHyperParameterTuningResourceConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionHyperParameterTuningResourceConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionHyperParameterTuningResourceConfigProperty | cdktn.IResolvable | undefined);
        private _allocationStrategy?;
        get allocationStrategy(): string;
        set allocationStrategy(value: string);
        resetAllocationStrategy(): void;
        get allocationStrategyInput(): string | undefined;
        private _instanceCount?;
        get instanceCount(): number;
        set instanceCount(value: number);
        resetInstanceCount(): void;
        get instanceCountInput(): number | undefined;
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        resetInstanceType(): void;
        get instanceTypeInput(): string | undefined;
        private _volumeKmsKeyId?;
        get volumeKmsKeyId(): string;
        set volumeKmsKeyId(value: string);
        resetVolumeKmsKeyId(): void;
        get volumeKmsKeyIdInput(): string | undefined;
        private _volumeSizeInGb?;
        get volumeSizeInGb(): number;
        set volumeSizeInGb(value: number);
        resetVolumeSizeInGb(): void;
        get volumeSizeInGbInput(): number | undefined;
        private _instanceConfigs;
        get instanceConfigs(): TrainingJobDefinitionHyperParameterTuningResourceConfigInstanceConfigsPropertyList;
        putInstanceConfigs(value: TrainingJobDefinitionHyperParameterTuningResourceConfigInstanceConfigsProperty[] | cdktn.IResolvable): void;
        resetInstanceConfigs(): void;
        get instanceConfigsInput(): cdktn.IResolvable | TrainingJobDefinitionHyperParameterTuningResourceConfigInstanceConfigsProperty[] | undefined;
    }
    class TrainingJobDefinitionHyperParameterTuningResourceConfigPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionHyperParameterTuningResourceConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionHyperParameterTuningResourceConfigPropertyOutputReference;
    }
    interface TrainingJobDefinitionInputDataConfigDataSourceFileSystemDataSourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#directory_path TfHyperParameterTuningJob#directory_path}
        */
        readonly directoryPath: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#file_system_access_mode TfHyperParameterTuningJob#file_system_access_mode}
        */
        readonly fileSystemAccessMode: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#file_system_id TfHyperParameterTuningJob#file_system_id}
        */
        readonly fileSystemId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#file_system_type TfHyperParameterTuningJob#file_system_type}
        */
        readonly fileSystemType: string;
    }
    class TrainingJobDefinitionInputDataConfigDataSourceFileSystemDataSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionInputDataConfigDataSourceFileSystemDataSourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionInputDataConfigDataSourceFileSystemDataSourceProperty | cdktn.IResolvable | undefined);
        private _directoryPath?;
        get directoryPath(): string;
        set directoryPath(value: string);
        get directoryPathInput(): string | undefined;
        private _fileSystemAccessMode?;
        get fileSystemAccessMode(): string;
        set fileSystemAccessMode(value: string);
        get fileSystemAccessModeInput(): string | undefined;
        private _fileSystemId?;
        get fileSystemId(): string;
        set fileSystemId(value: string);
        get fileSystemIdInput(): string | undefined;
        private _fileSystemType?;
        get fileSystemType(): string;
        set fileSystemType(value: string);
        get fileSystemTypeInput(): string | undefined;
    }
    class TrainingJobDefinitionInputDataConfigDataSourceFileSystemDataSourcePropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionInputDataConfigDataSourceFileSystemDataSourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionInputDataConfigDataSourceFileSystemDataSourcePropertyOutputReference;
    }
    interface TrainingJobDefinitionInputDataConfigDataSourceS3DataSourceHubAccessConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#hub_content_arn TfHyperParameterTuningJob#hub_content_arn}
        */
        readonly hubContentArn: string;
    }
    class TrainingJobDefinitionInputDataConfigDataSourceS3DataSourceHubAccessConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionInputDataConfigDataSourceS3DataSourceHubAccessConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionInputDataConfigDataSourceS3DataSourceHubAccessConfigProperty | cdktn.IResolvable | undefined);
        private _hubContentArn?;
        get hubContentArn(): string;
        set hubContentArn(value: string);
        get hubContentArnInput(): string | undefined;
    }
    class TrainingJobDefinitionInputDataConfigDataSourceS3DataSourceHubAccessConfigPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionInputDataConfigDataSourceS3DataSourceHubAccessConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionInputDataConfigDataSourceS3DataSourceHubAccessConfigPropertyOutputReference;
    }
    interface TrainingJobDefinitionInputDataConfigDataSourceS3DataSourceModelAccessConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#accept_eula TfHyperParameterTuningJob#accept_eula}
        */
        readonly acceptEula: boolean | cdktn.IResolvable;
    }
    class TrainingJobDefinitionInputDataConfigDataSourceS3DataSourceModelAccessConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionInputDataConfigDataSourceS3DataSourceModelAccessConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionInputDataConfigDataSourceS3DataSourceModelAccessConfigProperty | cdktn.IResolvable | undefined);
        private _acceptEula?;
        get acceptEula(): boolean | cdktn.IResolvable;
        set acceptEula(value: boolean | cdktn.IResolvable);
        get acceptEulaInput(): boolean | cdktn.IResolvable | undefined;
    }
    class TrainingJobDefinitionInputDataConfigDataSourceS3DataSourceModelAccessConfigPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionInputDataConfigDataSourceS3DataSourceModelAccessConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionInputDataConfigDataSourceS3DataSourceModelAccessConfigPropertyOutputReference;
    }
    interface TrainingJobDefinitionInputDataConfigDataSourceS3DataSourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#attribute_names TfHyperParameterTuningJob#attribute_names}
        */
        readonly attributeNames?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#instance_group_names TfHyperParameterTuningJob#instance_group_names}
        */
        readonly instanceGroupNames?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#s3_data_distribution_type TfHyperParameterTuningJob#s3_data_distribution_type}
        */
        readonly s3DataDistributionType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#s3_data_type TfHyperParameterTuningJob#s3_data_type}
        */
        readonly s3DataType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#s3_uri TfHyperParameterTuningJob#s3_uri}
        */
        readonly s3Uri: string;
        /**
        * hub_access_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#hub_access_config TfHyperParameterTuningJob#hub_access_config}
        */
        readonly hubAccessConfig?: TrainingJobDefinitionInputDataConfigDataSourceS3DataSourceHubAccessConfigProperty[] | cdktn.IResolvable;
        /**
        * model_access_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#model_access_config TfHyperParameterTuningJob#model_access_config}
        */
        readonly modelAccessConfig?: TrainingJobDefinitionInputDataConfigDataSourceS3DataSourceModelAccessConfigProperty[] | cdktn.IResolvable;
    }
    class TrainingJobDefinitionInputDataConfigDataSourceS3DataSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionInputDataConfigDataSourceS3DataSourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionInputDataConfigDataSourceS3DataSourceProperty | cdktn.IResolvable | undefined);
        private _attributeNames?;
        get attributeNames(): string[];
        set attributeNames(value: string[]);
        resetAttributeNames(): void;
        get attributeNamesInput(): string[] | undefined;
        private _instanceGroupNames?;
        get instanceGroupNames(): string[];
        set instanceGroupNames(value: string[]);
        resetInstanceGroupNames(): void;
        get instanceGroupNamesInput(): string[] | undefined;
        private _s3DataDistributionType?;
        get s3DataDistributionType(): string;
        set s3DataDistributionType(value: string);
        resetS3DataDistributionType(): void;
        get s3DataDistributionTypeInput(): string | undefined;
        private _s3DataType?;
        get s3DataType(): string;
        set s3DataType(value: string);
        get s3DataTypeInput(): string | undefined;
        private _s3Uri?;
        get s3Uri(): string;
        set s3Uri(value: string);
        get s3UriInput(): string | undefined;
        private _hubAccessConfig;
        get hubAccessConfig(): TrainingJobDefinitionInputDataConfigDataSourceS3DataSourceHubAccessConfigPropertyList;
        putHubAccessConfig(value: TrainingJobDefinitionInputDataConfigDataSourceS3DataSourceHubAccessConfigProperty[] | cdktn.IResolvable): void;
        resetHubAccessConfig(): void;
        get hubAccessConfigInput(): cdktn.IResolvable | TrainingJobDefinitionInputDataConfigDataSourceS3DataSourceHubAccessConfigProperty[] | undefined;
        private _modelAccessConfig;
        get modelAccessConfig(): TrainingJobDefinitionInputDataConfigDataSourceS3DataSourceModelAccessConfigPropertyList;
        putModelAccessConfig(value: TrainingJobDefinitionInputDataConfigDataSourceS3DataSourceModelAccessConfigProperty[] | cdktn.IResolvable): void;
        resetModelAccessConfig(): void;
        get modelAccessConfigInput(): cdktn.IResolvable | TrainingJobDefinitionInputDataConfigDataSourceS3DataSourceModelAccessConfigProperty[] | undefined;
    }
    class TrainingJobDefinitionInputDataConfigDataSourceS3DataSourcePropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionInputDataConfigDataSourceS3DataSourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionInputDataConfigDataSourceS3DataSourcePropertyOutputReference;
    }
    interface TrainingJobDefinitionInputDataConfigDataSourceProperty {
        /**
        * file_system_data_source block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#file_system_data_source TfHyperParameterTuningJob#file_system_data_source}
        */
        readonly fileSystemDataSource?: TrainingJobDefinitionInputDataConfigDataSourceFileSystemDataSourceProperty[] | cdktn.IResolvable;
        /**
        * s3_data_source block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#s3_data_source TfHyperParameterTuningJob#s3_data_source}
        */
        readonly s3DataSource?: TrainingJobDefinitionInputDataConfigDataSourceS3DataSourceProperty[] | cdktn.IResolvable;
    }
    class TrainingJobDefinitionInputDataConfigDataSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionInputDataConfigDataSourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionInputDataConfigDataSourceProperty | cdktn.IResolvable | undefined);
        private _fileSystemDataSource;
        get fileSystemDataSource(): TrainingJobDefinitionInputDataConfigDataSourceFileSystemDataSourcePropertyList;
        putFileSystemDataSource(value: TrainingJobDefinitionInputDataConfigDataSourceFileSystemDataSourceProperty[] | cdktn.IResolvable): void;
        resetFileSystemDataSource(): void;
        get fileSystemDataSourceInput(): cdktn.IResolvable | TrainingJobDefinitionInputDataConfigDataSourceFileSystemDataSourceProperty[] | undefined;
        private _s3DataSource;
        get s3DataSource(): TrainingJobDefinitionInputDataConfigDataSourceS3DataSourcePropertyList;
        putS3DataSource(value: TrainingJobDefinitionInputDataConfigDataSourceS3DataSourceProperty[] | cdktn.IResolvable): void;
        resetS3DataSource(): void;
        get s3DataSourceInput(): cdktn.IResolvable | TrainingJobDefinitionInputDataConfigDataSourceS3DataSourceProperty[] | undefined;
    }
    class TrainingJobDefinitionInputDataConfigDataSourcePropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionInputDataConfigDataSourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionInputDataConfigDataSourcePropertyOutputReference;
    }
    interface TrainingJobDefinitionInputDataConfigShuffleConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#seed TfHyperParameterTuningJob#seed}
        */
        readonly seed: number;
    }
    class TrainingJobDefinitionInputDataConfigShuffleConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionInputDataConfigShuffleConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionInputDataConfigShuffleConfigProperty | cdktn.IResolvable | undefined);
        private _seed?;
        get seed(): number;
        set seed(value: number);
        get seedInput(): number | undefined;
    }
    class TrainingJobDefinitionInputDataConfigShuffleConfigPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionInputDataConfigShuffleConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionInputDataConfigShuffleConfigPropertyOutputReference;
    }
    interface TrainingJobDefinitionInputDataConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#channel_name TfHyperParameterTuningJob#channel_name}
        */
        readonly channelName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#compression_type TfHyperParameterTuningJob#compression_type}
        */
        readonly compressionType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#content_type TfHyperParameterTuningJob#content_type}
        */
        readonly contentType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#input_mode TfHyperParameterTuningJob#input_mode}
        */
        readonly inputMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#record_wrapper_type TfHyperParameterTuningJob#record_wrapper_type}
        */
        readonly recordWrapperType?: string;
        /**
        * data_source block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#data_source TfHyperParameterTuningJob#data_source}
        */
        readonly dataSource?: TrainingJobDefinitionInputDataConfigDataSourceProperty[] | cdktn.IResolvable;
        /**
        * shuffle_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#shuffle_config TfHyperParameterTuningJob#shuffle_config}
        */
        readonly shuffleConfig?: TrainingJobDefinitionInputDataConfigShuffleConfigProperty[] | cdktn.IResolvable;
    }
    class TrainingJobDefinitionInputDataConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionInputDataConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionInputDataConfigProperty | cdktn.IResolvable | undefined);
        private _channelName?;
        get channelName(): string;
        set channelName(value: string);
        get channelNameInput(): string | undefined;
        private _compressionType?;
        get compressionType(): string;
        set compressionType(value: string);
        resetCompressionType(): void;
        get compressionTypeInput(): string | undefined;
        private _contentType?;
        get contentType(): string;
        set contentType(value: string);
        resetContentType(): void;
        get contentTypeInput(): string | undefined;
        private _inputMode?;
        get inputMode(): string;
        set inputMode(value: string);
        resetInputMode(): void;
        get inputModeInput(): string | undefined;
        private _recordWrapperType?;
        get recordWrapperType(): string;
        set recordWrapperType(value: string);
        resetRecordWrapperType(): void;
        get recordWrapperTypeInput(): string | undefined;
        private _dataSource;
        get dataSource(): TrainingJobDefinitionInputDataConfigDataSourcePropertyList;
        putDataSource(value: TrainingJobDefinitionInputDataConfigDataSourceProperty[] | cdktn.IResolvable): void;
        resetDataSource(): void;
        get dataSourceInput(): cdktn.IResolvable | TrainingJobDefinitionInputDataConfigDataSourceProperty[] | undefined;
        private _shuffleConfig;
        get shuffleConfig(): TrainingJobDefinitionInputDataConfigShuffleConfigPropertyList;
        putShuffleConfig(value: TrainingJobDefinitionInputDataConfigShuffleConfigProperty[] | cdktn.IResolvable): void;
        resetShuffleConfig(): void;
        get shuffleConfigInput(): cdktn.IResolvable | TrainingJobDefinitionInputDataConfigShuffleConfigProperty[] | undefined;
    }
    class TrainingJobDefinitionInputDataConfigPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionInputDataConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionInputDataConfigPropertyOutputReference;
    }
    interface TrainingJobDefinitionOutputDataConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#compression_type TfHyperParameterTuningJob#compression_type}
        */
        readonly compressionType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#kms_key_id TfHyperParameterTuningJob#kms_key_id}
        */
        readonly kmsKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#s3_output_path TfHyperParameterTuningJob#s3_output_path}
        */
        readonly s3OutputPath: string;
    }
    class TrainingJobDefinitionOutputDataConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionOutputDataConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionOutputDataConfigProperty | cdktn.IResolvable | undefined);
        private _compressionType?;
        get compressionType(): string;
        set compressionType(value: string);
        resetCompressionType(): void;
        get compressionTypeInput(): string | undefined;
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        resetKmsKeyId(): void;
        get kmsKeyIdInput(): string | undefined;
        private _s3OutputPath?;
        get s3OutputPath(): string;
        set s3OutputPath(value: string);
        get s3OutputPathInput(): string | undefined;
    }
    class TrainingJobDefinitionOutputDataConfigPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionOutputDataConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionOutputDataConfigPropertyOutputReference;
    }
    interface TrainingJobDefinitionResourceConfigInstanceGroupsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#instance_count TfHyperParameterTuningJob#instance_count}
        */
        readonly instanceCount: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#instance_group_name TfHyperParameterTuningJob#instance_group_name}
        */
        readonly instanceGroupName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#instance_type TfHyperParameterTuningJob#instance_type}
        */
        readonly instanceType: string;
    }
    class TrainingJobDefinitionResourceConfigInstanceGroupsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionResourceConfigInstanceGroupsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionResourceConfigInstanceGroupsProperty | cdktn.IResolvable | undefined);
        private _instanceCount?;
        get instanceCount(): number;
        set instanceCount(value: number);
        get instanceCountInput(): number | undefined;
        private _instanceGroupName?;
        get instanceGroupName(): string;
        set instanceGroupName(value: string);
        get instanceGroupNameInput(): string | undefined;
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        get instanceTypeInput(): string | undefined;
    }
    class TrainingJobDefinitionResourceConfigInstanceGroupsPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionResourceConfigInstanceGroupsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionResourceConfigInstanceGroupsPropertyOutputReference;
    }
    interface TrainingJobDefinitionResourceConfigInstancePlacementConfigPlacementSpecificationsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#instance_count TfHyperParameterTuningJob#instance_count}
        */
        readonly instanceCount: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#ultra_server_id TfHyperParameterTuningJob#ultra_server_id}
        */
        readonly ultraServerId?: string;
    }
    class TrainingJobDefinitionResourceConfigInstancePlacementConfigPlacementSpecificationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionResourceConfigInstancePlacementConfigPlacementSpecificationsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionResourceConfigInstancePlacementConfigPlacementSpecificationsProperty | cdktn.IResolvable | undefined);
        private _instanceCount?;
        get instanceCount(): number;
        set instanceCount(value: number);
        get instanceCountInput(): number | undefined;
        private _ultraServerId?;
        get ultraServerId(): string;
        set ultraServerId(value: string);
        resetUltraServerId(): void;
        get ultraServerIdInput(): string | undefined;
    }
    class TrainingJobDefinitionResourceConfigInstancePlacementConfigPlacementSpecificationsPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionResourceConfigInstancePlacementConfigPlacementSpecificationsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionResourceConfigInstancePlacementConfigPlacementSpecificationsPropertyOutputReference;
    }
    interface TrainingJobDefinitionResourceConfigInstancePlacementConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#enable_multiple_jobs TfHyperParameterTuningJob#enable_multiple_jobs}
        */
        readonly enableMultipleJobs?: boolean | cdktn.IResolvable;
        /**
        * placement_specifications block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#placement_specifications TfHyperParameterTuningJob#placement_specifications}
        */
        readonly placementSpecifications?: TrainingJobDefinitionResourceConfigInstancePlacementConfigPlacementSpecificationsProperty[] | cdktn.IResolvable;
    }
    class TrainingJobDefinitionResourceConfigInstancePlacementConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionResourceConfigInstancePlacementConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionResourceConfigInstancePlacementConfigProperty | cdktn.IResolvable | undefined);
        private _enableMultipleJobs?;
        get enableMultipleJobs(): boolean | cdktn.IResolvable;
        set enableMultipleJobs(value: boolean | cdktn.IResolvable);
        resetEnableMultipleJobs(): void;
        get enableMultipleJobsInput(): boolean | cdktn.IResolvable | undefined;
        private _placementSpecifications;
        get placementSpecifications(): TrainingJobDefinitionResourceConfigInstancePlacementConfigPlacementSpecificationsPropertyList;
        putPlacementSpecifications(value: TrainingJobDefinitionResourceConfigInstancePlacementConfigPlacementSpecificationsProperty[] | cdktn.IResolvable): void;
        resetPlacementSpecifications(): void;
        get placementSpecificationsInput(): cdktn.IResolvable | TrainingJobDefinitionResourceConfigInstancePlacementConfigPlacementSpecificationsProperty[] | undefined;
    }
    class TrainingJobDefinitionResourceConfigInstancePlacementConfigPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionResourceConfigInstancePlacementConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionResourceConfigInstancePlacementConfigPropertyOutputReference;
    }
    interface TrainingJobDefinitionResourceConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#instance_count TfHyperParameterTuningJob#instance_count}
        */
        readonly instanceCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#instance_type TfHyperParameterTuningJob#instance_type}
        */
        readonly instanceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#keep_alive_period_in_seconds TfHyperParameterTuningJob#keep_alive_period_in_seconds}
        */
        readonly keepAlivePeriodInSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#training_plan_arn TfHyperParameterTuningJob#training_plan_arn}
        */
        readonly trainingPlanArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#volume_kms_key_id TfHyperParameterTuningJob#volume_kms_key_id}
        */
        readonly volumeKmsKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#volume_size_in_gb TfHyperParameterTuningJob#volume_size_in_gb}
        */
        readonly volumeSizeInGb?: number;
        /**
        * instance_groups block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#instance_groups TfHyperParameterTuningJob#instance_groups}
        */
        readonly instanceGroups?: TrainingJobDefinitionResourceConfigInstanceGroupsProperty[] | cdktn.IResolvable;
        /**
        * instance_placement_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#instance_placement_config TfHyperParameterTuningJob#instance_placement_config}
        */
        readonly instancePlacementConfig?: TrainingJobDefinitionResourceConfigInstancePlacementConfigProperty[] | cdktn.IResolvable;
    }
    class TrainingJobDefinitionResourceConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionResourceConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionResourceConfigProperty | cdktn.IResolvable | undefined);
        private _instanceCount?;
        get instanceCount(): number;
        set instanceCount(value: number);
        resetInstanceCount(): void;
        get instanceCountInput(): number | undefined;
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        resetInstanceType(): void;
        get instanceTypeInput(): string | undefined;
        private _keepAlivePeriodInSeconds?;
        get keepAlivePeriodInSeconds(): number;
        set keepAlivePeriodInSeconds(value: number);
        resetKeepAlivePeriodInSeconds(): void;
        get keepAlivePeriodInSecondsInput(): number | undefined;
        private _trainingPlanArn?;
        get trainingPlanArn(): string;
        set trainingPlanArn(value: string);
        resetTrainingPlanArn(): void;
        get trainingPlanArnInput(): string | undefined;
        private _volumeKmsKeyId?;
        get volumeKmsKeyId(): string;
        set volumeKmsKeyId(value: string);
        resetVolumeKmsKeyId(): void;
        get volumeKmsKeyIdInput(): string | undefined;
        private _volumeSizeInGb?;
        get volumeSizeInGb(): number;
        set volumeSizeInGb(value: number);
        resetVolumeSizeInGb(): void;
        get volumeSizeInGbInput(): number | undefined;
        private _instanceGroups;
        get instanceGroups(): TrainingJobDefinitionResourceConfigInstanceGroupsPropertyList;
        putInstanceGroups(value: TrainingJobDefinitionResourceConfigInstanceGroupsProperty[] | cdktn.IResolvable): void;
        resetInstanceGroups(): void;
        get instanceGroupsInput(): cdktn.IResolvable | TrainingJobDefinitionResourceConfigInstanceGroupsProperty[] | undefined;
        private _instancePlacementConfig;
        get instancePlacementConfig(): TrainingJobDefinitionResourceConfigInstancePlacementConfigPropertyList;
        putInstancePlacementConfig(value: TrainingJobDefinitionResourceConfigInstancePlacementConfigProperty[] | cdktn.IResolvable): void;
        resetInstancePlacementConfig(): void;
        get instancePlacementConfigInput(): cdktn.IResolvable | TrainingJobDefinitionResourceConfigInstancePlacementConfigProperty[] | undefined;
    }
    class TrainingJobDefinitionResourceConfigPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionResourceConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionResourceConfigPropertyOutputReference;
    }
    interface TrainingJobDefinitionStoppingConditionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#max_pending_time_in_seconds TfHyperParameterTuningJob#max_pending_time_in_seconds}
        */
        readonly maxPendingTimeInSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#max_runtime_in_seconds TfHyperParameterTuningJob#max_runtime_in_seconds}
        */
        readonly maxRuntimeInSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#max_wait_time_in_seconds TfHyperParameterTuningJob#max_wait_time_in_seconds}
        */
        readonly maxWaitTimeInSeconds?: number;
    }
    class TrainingJobDefinitionStoppingConditionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionStoppingConditionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionStoppingConditionProperty | cdktn.IResolvable | undefined);
        private _maxPendingTimeInSeconds?;
        get maxPendingTimeInSeconds(): number;
        set maxPendingTimeInSeconds(value: number);
        resetMaxPendingTimeInSeconds(): void;
        get maxPendingTimeInSecondsInput(): number | undefined;
        private _maxRuntimeInSeconds?;
        get maxRuntimeInSeconds(): number;
        set maxRuntimeInSeconds(value: number);
        resetMaxRuntimeInSeconds(): void;
        get maxRuntimeInSecondsInput(): number | undefined;
        private _maxWaitTimeInSeconds?;
        get maxWaitTimeInSeconds(): number;
        set maxWaitTimeInSeconds(value: number);
        resetMaxWaitTimeInSeconds(): void;
        get maxWaitTimeInSecondsInput(): number | undefined;
    }
    class TrainingJobDefinitionStoppingConditionPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionStoppingConditionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionStoppingConditionPropertyOutputReference;
    }
    interface TrainingJobDefinitionTuningObjectiveProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#metric_name TfHyperParameterTuningJob#metric_name}
        */
        readonly metricName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#type TfHyperParameterTuningJob#type}
        */
        readonly type: string;
    }
    class TrainingJobDefinitionTuningObjectivePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionTuningObjectiveProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionTuningObjectiveProperty | cdktn.IResolvable | undefined);
        private _metricName?;
        get metricName(): string;
        set metricName(value: string);
        get metricNameInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class TrainingJobDefinitionTuningObjectivePropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionTuningObjectiveProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionTuningObjectivePropertyOutputReference;
    }
    interface TrainingJobDefinitionVpcConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#security_group_ids TfHyperParameterTuningJob#security_group_ids}
        */
        readonly securityGroupIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#subnets TfHyperParameterTuningJob#subnets}
        */
        readonly subnets: string[];
    }
    class TrainingJobDefinitionVpcConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionVpcConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionVpcConfigProperty | cdktn.IResolvable | undefined);
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        get securityGroupIdsInput(): string[] | undefined;
        private _subnets?;
        get subnets(): string[];
        set subnets(value: string[]);
        get subnetsInput(): string[] | undefined;
    }
    class TrainingJobDefinitionVpcConfigPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionVpcConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionVpcConfigPropertyOutputReference;
    }
    interface TrainingJobDefinitionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#definition_name TfHyperParameterTuningJob#definition_name}
        */
        readonly definitionName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#enable_inter_container_traffic_encryption TfHyperParameterTuningJob#enable_inter_container_traffic_encryption}
        */
        readonly enableInterContainerTrafficEncryption?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#enable_managed_spot_training TfHyperParameterTuningJob#enable_managed_spot_training}
        */
        readonly enableManagedSpotTraining?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#enable_network_isolation TfHyperParameterTuningJob#enable_network_isolation}
        */
        readonly enableNetworkIsolation?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#environment TfHyperParameterTuningJob#environment}
        */
        readonly environment?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#retry_strategy TfHyperParameterTuningJob#retry_strategy}
        */
        readonly retryStrategy?: TrainingJobDefinitionRetryStrategyProperty[] | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#role_arn TfHyperParameterTuningJob#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#static_hyper_parameters TfHyperParameterTuningJob#static_hyper_parameters}
        */
        readonly staticHyperParameters?: {
            [key: string]: string;
        };
        /**
        * algorithm_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#algorithm_specification TfHyperParameterTuningJob#algorithm_specification}
        */
        readonly algorithmSpecification?: TrainingJobDefinitionAlgorithmSpecificationProperty[] | cdktn.IResolvable;
        /**
        * checkpoint_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#checkpoint_config TfHyperParameterTuningJob#checkpoint_config}
        */
        readonly checkpointConfig?: TrainingJobDefinitionCheckpointConfigProperty[] | cdktn.IResolvable;
        /**
        * hyper_parameter_ranges block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#hyper_parameter_ranges TfHyperParameterTuningJob#hyper_parameter_ranges}
        */
        readonly hyperParameterRanges?: TrainingJobDefinitionHyperParameterRangesProperty[] | cdktn.IResolvable;
        /**
        * hyper_parameter_tuning_resource_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#hyper_parameter_tuning_resource_config TfHyperParameterTuningJob#hyper_parameter_tuning_resource_config}
        */
        readonly hyperParameterTuningResourceConfig?: TrainingJobDefinitionHyperParameterTuningResourceConfigProperty[] | cdktn.IResolvable;
        /**
        * input_data_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#input_data_config TfHyperParameterTuningJob#input_data_config}
        */
        readonly inputDataConfig?: TrainingJobDefinitionInputDataConfigProperty[] | cdktn.IResolvable;
        /**
        * output_data_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#output_data_config TfHyperParameterTuningJob#output_data_config}
        */
        readonly outputDataConfig?: TrainingJobDefinitionOutputDataConfigProperty[] | cdktn.IResolvable;
        /**
        * resource_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#resource_config TfHyperParameterTuningJob#resource_config}
        */
        readonly resourceConfig?: TrainingJobDefinitionResourceConfigProperty[] | cdktn.IResolvable;
        /**
        * stopping_condition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#stopping_condition TfHyperParameterTuningJob#stopping_condition}
        */
        readonly stoppingCondition?: TrainingJobDefinitionStoppingConditionProperty[] | cdktn.IResolvable;
        /**
        * tuning_objective block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#tuning_objective TfHyperParameterTuningJob#tuning_objective}
        */
        readonly tuningObjective?: TrainingJobDefinitionTuningObjectiveProperty[] | cdktn.IResolvable;
        /**
        * vpc_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#vpc_config TfHyperParameterTuningJob#vpc_config}
        */
        readonly vpcConfig?: TrainingJobDefinitionVpcConfigProperty[] | cdktn.IResolvable;
    }
    class TrainingJobDefinitionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionProperty | cdktn.IResolvable | undefined);
        private _definitionName?;
        get definitionName(): string;
        set definitionName(value: string);
        resetDefinitionName(): void;
        get definitionNameInput(): string | undefined;
        private _enableInterContainerTrafficEncryption?;
        get enableInterContainerTrafficEncryption(): boolean | cdktn.IResolvable;
        set enableInterContainerTrafficEncryption(value: boolean | cdktn.IResolvable);
        resetEnableInterContainerTrafficEncryption(): void;
        get enableInterContainerTrafficEncryptionInput(): boolean | cdktn.IResolvable | undefined;
        private _enableManagedSpotTraining?;
        get enableManagedSpotTraining(): boolean | cdktn.IResolvable;
        set enableManagedSpotTraining(value: boolean | cdktn.IResolvable);
        resetEnableManagedSpotTraining(): void;
        get enableManagedSpotTrainingInput(): boolean | cdktn.IResolvable | undefined;
        private _enableNetworkIsolation?;
        get enableNetworkIsolation(): boolean | cdktn.IResolvable;
        set enableNetworkIsolation(value: boolean | cdktn.IResolvable);
        resetEnableNetworkIsolation(): void;
        get enableNetworkIsolationInput(): boolean | cdktn.IResolvable | undefined;
        private _environment?;
        get environment(): {
            [key: string]: string;
        };
        set environment(value: {
            [key: string]: string;
        });
        resetEnvironment(): void;
        get environmentInput(): {
            [key: string]: string;
        } | undefined;
        private _retryStrategy;
        get retryStrategy(): TrainingJobDefinitionRetryStrategyPropertyList;
        putRetryStrategy(value: TrainingJobDefinitionRetryStrategyProperty[] | cdktn.IResolvable): void;
        resetRetryStrategy(): void;
        get retryStrategyInput(): cdktn.IResolvable | TrainingJobDefinitionRetryStrategyProperty[] | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _staticHyperParameters?;
        get staticHyperParameters(): {
            [key: string]: string;
        };
        set staticHyperParameters(value: {
            [key: string]: string;
        });
        resetStaticHyperParameters(): void;
        get staticHyperParametersInput(): {
            [key: string]: string;
        } | undefined;
        private _algorithmSpecification;
        get algorithmSpecification(): TrainingJobDefinitionAlgorithmSpecificationPropertyList;
        putAlgorithmSpecification(value: TrainingJobDefinitionAlgorithmSpecificationProperty[] | cdktn.IResolvable): void;
        resetAlgorithmSpecification(): void;
        get algorithmSpecificationInput(): cdktn.IResolvable | TrainingJobDefinitionAlgorithmSpecificationProperty[] | undefined;
        private _checkpointConfig;
        get checkpointConfig(): TrainingJobDefinitionCheckpointConfigPropertyList;
        putCheckpointConfig(value: TrainingJobDefinitionCheckpointConfigProperty[] | cdktn.IResolvable): void;
        resetCheckpointConfig(): void;
        get checkpointConfigInput(): cdktn.IResolvable | TrainingJobDefinitionCheckpointConfigProperty[] | undefined;
        private _hyperParameterRanges;
        get hyperParameterRanges(): TrainingJobDefinitionHyperParameterRangesPropertyList;
        putHyperParameterRanges(value: TrainingJobDefinitionHyperParameterRangesProperty[] | cdktn.IResolvable): void;
        resetHyperParameterRanges(): void;
        get hyperParameterRangesInput(): cdktn.IResolvable | TrainingJobDefinitionHyperParameterRangesProperty[] | undefined;
        private _hyperParameterTuningResourceConfig;
        get hyperParameterTuningResourceConfig(): TrainingJobDefinitionHyperParameterTuningResourceConfigPropertyList;
        putHyperParameterTuningResourceConfig(value: TrainingJobDefinitionHyperParameterTuningResourceConfigProperty[] | cdktn.IResolvable): void;
        resetHyperParameterTuningResourceConfig(): void;
        get hyperParameterTuningResourceConfigInput(): cdktn.IResolvable | TrainingJobDefinitionHyperParameterTuningResourceConfigProperty[] | undefined;
        private _inputDataConfig;
        get inputDataConfig(): TrainingJobDefinitionInputDataConfigPropertyList;
        putInputDataConfig(value: TrainingJobDefinitionInputDataConfigProperty[] | cdktn.IResolvable): void;
        resetInputDataConfig(): void;
        get inputDataConfigInput(): cdktn.IResolvable | TrainingJobDefinitionInputDataConfigProperty[] | undefined;
        private _outputDataConfig;
        get outputDataConfig(): TrainingJobDefinitionOutputDataConfigPropertyList;
        putOutputDataConfig(value: TrainingJobDefinitionOutputDataConfigProperty[] | cdktn.IResolvable): void;
        resetOutputDataConfig(): void;
        get outputDataConfigInput(): cdktn.IResolvable | TrainingJobDefinitionOutputDataConfigProperty[] | undefined;
        private _resourceConfig;
        get resourceConfig(): TrainingJobDefinitionResourceConfigPropertyList;
        putResourceConfig(value: TrainingJobDefinitionResourceConfigProperty[] | cdktn.IResolvable): void;
        resetResourceConfig(): void;
        get resourceConfigInput(): cdktn.IResolvable | TrainingJobDefinitionResourceConfigProperty[] | undefined;
        private _stoppingCondition;
        get stoppingCondition(): TrainingJobDefinitionStoppingConditionPropertyList;
        putStoppingCondition(value: TrainingJobDefinitionStoppingConditionProperty[] | cdktn.IResolvable): void;
        resetStoppingCondition(): void;
        get stoppingConditionInput(): cdktn.IResolvable | TrainingJobDefinitionStoppingConditionProperty[] | undefined;
        private _tuningObjective;
        get tuningObjective(): TrainingJobDefinitionTuningObjectivePropertyList;
        putTuningObjective(value: TrainingJobDefinitionTuningObjectiveProperty[] | cdktn.IResolvable): void;
        resetTuningObjective(): void;
        get tuningObjectiveInput(): cdktn.IResolvable | TrainingJobDefinitionTuningObjectiveProperty[] | undefined;
        private _vpcConfig;
        get vpcConfig(): TrainingJobDefinitionVpcConfigPropertyList;
        putVpcConfig(value: TrainingJobDefinitionVpcConfigProperty[] | cdktn.IResolvable): void;
        resetVpcConfig(): void;
        get vpcConfigInput(): cdktn.IResolvable | TrainingJobDefinitionVpcConfigProperty[] | undefined;
    }
    class TrainingJobDefinitionPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionPropertyOutputReference;
    }
    interface TrainingJobDefinitionsRetryStrategyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#maximum_retry_attempts TfHyperParameterTuningJob#maximum_retry_attempts}
        */
        readonly maximumRetryAttempts?: number;
    }
    class TrainingJobDefinitionsRetryStrategyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionsRetryStrategyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionsRetryStrategyProperty | cdktn.IResolvable | undefined);
        private _maximumRetryAttempts?;
        get maximumRetryAttempts(): number;
        set maximumRetryAttempts(value: number);
        resetMaximumRetryAttempts(): void;
        get maximumRetryAttemptsInput(): number | undefined;
    }
    class TrainingJobDefinitionsRetryStrategyPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionsRetryStrategyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionsRetryStrategyPropertyOutputReference;
    }
    interface TrainingJobDefinitionsAlgorithmSpecificationMetricDefinitionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#name TfHyperParameterTuningJob#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#regex TfHyperParameterTuningJob#regex}
        */
        readonly regex: string;
    }
    class TrainingJobDefinitionsAlgorithmSpecificationMetricDefinitionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionsAlgorithmSpecificationMetricDefinitionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionsAlgorithmSpecificationMetricDefinitionsProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _regex?;
        get regex(): string;
        set regex(value: string);
        get regexInput(): string | undefined;
    }
    class TrainingJobDefinitionsAlgorithmSpecificationMetricDefinitionsPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionsAlgorithmSpecificationMetricDefinitionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionsAlgorithmSpecificationMetricDefinitionsPropertyOutputReference;
    }
    interface TrainingJobDefinitionsAlgorithmSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#algorithm_name TfHyperParameterTuningJob#algorithm_name}
        */
        readonly algorithmName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#training_image TfHyperParameterTuningJob#training_image}
        */
        readonly trainingImage?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#training_input_mode TfHyperParameterTuningJob#training_input_mode}
        */
        readonly trainingInputMode: string;
        /**
        * metric_definitions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#metric_definitions TfHyperParameterTuningJob#metric_definitions}
        */
        readonly metricDefinitions?: TrainingJobDefinitionsAlgorithmSpecificationMetricDefinitionsProperty[] | cdktn.IResolvable;
    }
    class TrainingJobDefinitionsAlgorithmSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionsAlgorithmSpecificationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionsAlgorithmSpecificationProperty | cdktn.IResolvable | undefined);
        private _algorithmName?;
        get algorithmName(): string;
        set algorithmName(value: string);
        resetAlgorithmName(): void;
        get algorithmNameInput(): string | undefined;
        private _trainingImage?;
        get trainingImage(): string;
        set trainingImage(value: string);
        resetTrainingImage(): void;
        get trainingImageInput(): string | undefined;
        private _trainingInputMode?;
        get trainingInputMode(): string;
        set trainingInputMode(value: string);
        get trainingInputModeInput(): string | undefined;
        private _metricDefinitions;
        get metricDefinitions(): TrainingJobDefinitionsAlgorithmSpecificationMetricDefinitionsPropertyList;
        putMetricDefinitions(value: TrainingJobDefinitionsAlgorithmSpecificationMetricDefinitionsProperty[] | cdktn.IResolvable): void;
        resetMetricDefinitions(): void;
        get metricDefinitionsInput(): cdktn.IResolvable | TrainingJobDefinitionsAlgorithmSpecificationMetricDefinitionsProperty[] | undefined;
    }
    class TrainingJobDefinitionsAlgorithmSpecificationPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionsAlgorithmSpecificationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionsAlgorithmSpecificationPropertyOutputReference;
    }
    interface TrainingJobDefinitionsCheckpointConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#local_path TfHyperParameterTuningJob#local_path}
        */
        readonly localPath?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#s3_uri TfHyperParameterTuningJob#s3_uri}
        */
        readonly s3Uri: string;
    }
    class TrainingJobDefinitionsCheckpointConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionsCheckpointConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionsCheckpointConfigProperty | cdktn.IResolvable | undefined);
        private _localPath?;
        get localPath(): string;
        set localPath(value: string);
        resetLocalPath(): void;
        get localPathInput(): string | undefined;
        private _s3Uri?;
        get s3Uri(): string;
        set s3Uri(value: string);
        get s3UriInput(): string | undefined;
    }
    class TrainingJobDefinitionsCheckpointConfigPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionsCheckpointConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionsCheckpointConfigPropertyOutputReference;
    }
    interface TrainingJobDefinitionsHyperParameterRangesAutoParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#name TfHyperParameterTuningJob#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#value_hint TfHyperParameterTuningJob#value_hint}
        */
        readonly valueHint: string;
    }
    class TrainingJobDefinitionsHyperParameterRangesAutoParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionsHyperParameterRangesAutoParametersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionsHyperParameterRangesAutoParametersProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _valueHint?;
        get valueHint(): string;
        set valueHint(value: string);
        get valueHintInput(): string | undefined;
    }
    class TrainingJobDefinitionsHyperParameterRangesAutoParametersPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionsHyperParameterRangesAutoParametersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionsHyperParameterRangesAutoParametersPropertyOutputReference;
    }
    interface TrainingJobDefinitionsHyperParameterRangesCategoricalParameterRangesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#name TfHyperParameterTuningJob#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#values TfHyperParameterTuningJob#values}
        */
        readonly values: string[];
    }
    class TrainingJobDefinitionsHyperParameterRangesCategoricalParameterRangesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionsHyperParameterRangesCategoricalParameterRangesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionsHyperParameterRangesCategoricalParameterRangesProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class TrainingJobDefinitionsHyperParameterRangesCategoricalParameterRangesPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionsHyperParameterRangesCategoricalParameterRangesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionsHyperParameterRangesCategoricalParameterRangesPropertyOutputReference;
    }
    interface TrainingJobDefinitionsHyperParameterRangesContinuousParameterRangesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#max_value TfHyperParameterTuningJob#max_value}
        */
        readonly maxValue: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#min_value TfHyperParameterTuningJob#min_value}
        */
        readonly minValue: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#name TfHyperParameterTuningJob#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#scaling_type TfHyperParameterTuningJob#scaling_type}
        */
        readonly scalingType?: string;
    }
    class TrainingJobDefinitionsHyperParameterRangesContinuousParameterRangesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionsHyperParameterRangesContinuousParameterRangesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionsHyperParameterRangesContinuousParameterRangesProperty | cdktn.IResolvable | undefined);
        private _maxValue?;
        get maxValue(): string;
        set maxValue(value: string);
        get maxValueInput(): string | undefined;
        private _minValue?;
        get minValue(): string;
        set minValue(value: string);
        get minValueInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _scalingType?;
        get scalingType(): string;
        set scalingType(value: string);
        resetScalingType(): void;
        get scalingTypeInput(): string | undefined;
    }
    class TrainingJobDefinitionsHyperParameterRangesContinuousParameterRangesPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionsHyperParameterRangesContinuousParameterRangesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionsHyperParameterRangesContinuousParameterRangesPropertyOutputReference;
    }
    interface TrainingJobDefinitionsHyperParameterRangesIntegerParameterRangesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#max_value TfHyperParameterTuningJob#max_value}
        */
        readonly maxValue: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#min_value TfHyperParameterTuningJob#min_value}
        */
        readonly minValue: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#name TfHyperParameterTuningJob#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#scaling_type TfHyperParameterTuningJob#scaling_type}
        */
        readonly scalingType?: string;
    }
    class TrainingJobDefinitionsHyperParameterRangesIntegerParameterRangesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionsHyperParameterRangesIntegerParameterRangesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionsHyperParameterRangesIntegerParameterRangesProperty | cdktn.IResolvable | undefined);
        private _maxValue?;
        get maxValue(): string;
        set maxValue(value: string);
        get maxValueInput(): string | undefined;
        private _minValue?;
        get minValue(): string;
        set minValue(value: string);
        get minValueInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _scalingType?;
        get scalingType(): string;
        set scalingType(value: string);
        resetScalingType(): void;
        get scalingTypeInput(): string | undefined;
    }
    class TrainingJobDefinitionsHyperParameterRangesIntegerParameterRangesPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionsHyperParameterRangesIntegerParameterRangesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionsHyperParameterRangesIntegerParameterRangesPropertyOutputReference;
    }
    interface TrainingJobDefinitionsHyperParameterRangesProperty {
        /**
        * auto_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#auto_parameters TfHyperParameterTuningJob#auto_parameters}
        */
        readonly autoParameters?: TrainingJobDefinitionsHyperParameterRangesAutoParametersProperty[] | cdktn.IResolvable;
        /**
        * categorical_parameter_ranges block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#categorical_parameter_ranges TfHyperParameterTuningJob#categorical_parameter_ranges}
        */
        readonly categoricalParameterRanges?: TrainingJobDefinitionsHyperParameterRangesCategoricalParameterRangesProperty[] | cdktn.IResolvable;
        /**
        * continuous_parameter_ranges block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#continuous_parameter_ranges TfHyperParameterTuningJob#continuous_parameter_ranges}
        */
        readonly continuousParameterRanges?: TrainingJobDefinitionsHyperParameterRangesContinuousParameterRangesProperty[] | cdktn.IResolvable;
        /**
        * integer_parameter_ranges block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#integer_parameter_ranges TfHyperParameterTuningJob#integer_parameter_ranges}
        */
        readonly integerParameterRanges?: TrainingJobDefinitionsHyperParameterRangesIntegerParameterRangesProperty[] | cdktn.IResolvable;
    }
    class TrainingJobDefinitionsHyperParameterRangesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionsHyperParameterRangesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionsHyperParameterRangesProperty | cdktn.IResolvable | undefined);
        private _autoParameters;
        get autoParameters(): TrainingJobDefinitionsHyperParameterRangesAutoParametersPropertyList;
        putAutoParameters(value: TrainingJobDefinitionsHyperParameterRangesAutoParametersProperty[] | cdktn.IResolvable): void;
        resetAutoParameters(): void;
        get autoParametersInput(): cdktn.IResolvable | TrainingJobDefinitionsHyperParameterRangesAutoParametersProperty[] | undefined;
        private _categoricalParameterRanges;
        get categoricalParameterRanges(): TrainingJobDefinitionsHyperParameterRangesCategoricalParameterRangesPropertyList;
        putCategoricalParameterRanges(value: TrainingJobDefinitionsHyperParameterRangesCategoricalParameterRangesProperty[] | cdktn.IResolvable): void;
        resetCategoricalParameterRanges(): void;
        get categoricalParameterRangesInput(): cdktn.IResolvable | TrainingJobDefinitionsHyperParameterRangesCategoricalParameterRangesProperty[] | undefined;
        private _continuousParameterRanges;
        get continuousParameterRanges(): TrainingJobDefinitionsHyperParameterRangesContinuousParameterRangesPropertyList;
        putContinuousParameterRanges(value: TrainingJobDefinitionsHyperParameterRangesContinuousParameterRangesProperty[] | cdktn.IResolvable): void;
        resetContinuousParameterRanges(): void;
        get continuousParameterRangesInput(): cdktn.IResolvable | TrainingJobDefinitionsHyperParameterRangesContinuousParameterRangesProperty[] | undefined;
        private _integerParameterRanges;
        get integerParameterRanges(): TrainingJobDefinitionsHyperParameterRangesIntegerParameterRangesPropertyList;
        putIntegerParameterRanges(value: TrainingJobDefinitionsHyperParameterRangesIntegerParameterRangesProperty[] | cdktn.IResolvable): void;
        resetIntegerParameterRanges(): void;
        get integerParameterRangesInput(): cdktn.IResolvable | TrainingJobDefinitionsHyperParameterRangesIntegerParameterRangesProperty[] | undefined;
    }
    class TrainingJobDefinitionsHyperParameterRangesPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionsHyperParameterRangesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionsHyperParameterRangesPropertyOutputReference;
    }
    interface TrainingJobDefinitionsHyperParameterTuningResourceConfigInstanceConfigsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#instance_count TfHyperParameterTuningJob#instance_count}
        */
        readonly instanceCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#instance_type TfHyperParameterTuningJob#instance_type}
        */
        readonly instanceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#volume_size_in_gb TfHyperParameterTuningJob#volume_size_in_gb}
        */
        readonly volumeSizeInGb?: number;
    }
    class TrainingJobDefinitionsHyperParameterTuningResourceConfigInstanceConfigsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionsHyperParameterTuningResourceConfigInstanceConfigsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionsHyperParameterTuningResourceConfigInstanceConfigsProperty | cdktn.IResolvable | undefined);
        private _instanceCount?;
        get instanceCount(): number;
        set instanceCount(value: number);
        resetInstanceCount(): void;
        get instanceCountInput(): number | undefined;
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        resetInstanceType(): void;
        get instanceTypeInput(): string | undefined;
        private _volumeSizeInGb?;
        get volumeSizeInGb(): number;
        set volumeSizeInGb(value: number);
        resetVolumeSizeInGb(): void;
        get volumeSizeInGbInput(): number | undefined;
    }
    class TrainingJobDefinitionsHyperParameterTuningResourceConfigInstanceConfigsPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionsHyperParameterTuningResourceConfigInstanceConfigsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionsHyperParameterTuningResourceConfigInstanceConfigsPropertyOutputReference;
    }
    interface TrainingJobDefinitionsHyperParameterTuningResourceConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#allocation_strategy TfHyperParameterTuningJob#allocation_strategy}
        */
        readonly allocationStrategy?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#instance_count TfHyperParameterTuningJob#instance_count}
        */
        readonly instanceCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#instance_type TfHyperParameterTuningJob#instance_type}
        */
        readonly instanceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#volume_kms_key_id TfHyperParameterTuningJob#volume_kms_key_id}
        */
        readonly volumeKmsKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#volume_size_in_gb TfHyperParameterTuningJob#volume_size_in_gb}
        */
        readonly volumeSizeInGb?: number;
        /**
        * instance_configs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#instance_configs TfHyperParameterTuningJob#instance_configs}
        */
        readonly instanceConfigs?: TrainingJobDefinitionsHyperParameterTuningResourceConfigInstanceConfigsProperty[] | cdktn.IResolvable;
    }
    class TrainingJobDefinitionsHyperParameterTuningResourceConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionsHyperParameterTuningResourceConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionsHyperParameterTuningResourceConfigProperty | cdktn.IResolvable | undefined);
        private _allocationStrategy?;
        get allocationStrategy(): string;
        set allocationStrategy(value: string);
        resetAllocationStrategy(): void;
        get allocationStrategyInput(): string | undefined;
        private _instanceCount?;
        get instanceCount(): number;
        set instanceCount(value: number);
        resetInstanceCount(): void;
        get instanceCountInput(): number | undefined;
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        resetInstanceType(): void;
        get instanceTypeInput(): string | undefined;
        private _volumeKmsKeyId?;
        get volumeKmsKeyId(): string;
        set volumeKmsKeyId(value: string);
        resetVolumeKmsKeyId(): void;
        get volumeKmsKeyIdInput(): string | undefined;
        private _volumeSizeInGb?;
        get volumeSizeInGb(): number;
        set volumeSizeInGb(value: number);
        resetVolumeSizeInGb(): void;
        get volumeSizeInGbInput(): number | undefined;
        private _instanceConfigs;
        get instanceConfigs(): TrainingJobDefinitionsHyperParameterTuningResourceConfigInstanceConfigsPropertyList;
        putInstanceConfigs(value: TrainingJobDefinitionsHyperParameterTuningResourceConfigInstanceConfigsProperty[] | cdktn.IResolvable): void;
        resetInstanceConfigs(): void;
        get instanceConfigsInput(): cdktn.IResolvable | TrainingJobDefinitionsHyperParameterTuningResourceConfigInstanceConfigsProperty[] | undefined;
    }
    class TrainingJobDefinitionsHyperParameterTuningResourceConfigPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionsHyperParameterTuningResourceConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionsHyperParameterTuningResourceConfigPropertyOutputReference;
    }
    interface TrainingJobDefinitionsInputDataConfigDataSourceFileSystemDataSourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#directory_path TfHyperParameterTuningJob#directory_path}
        */
        readonly directoryPath: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#file_system_access_mode TfHyperParameterTuningJob#file_system_access_mode}
        */
        readonly fileSystemAccessMode: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#file_system_id TfHyperParameterTuningJob#file_system_id}
        */
        readonly fileSystemId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#file_system_type TfHyperParameterTuningJob#file_system_type}
        */
        readonly fileSystemType: string;
    }
    class TrainingJobDefinitionsInputDataConfigDataSourceFileSystemDataSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionsInputDataConfigDataSourceFileSystemDataSourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionsInputDataConfigDataSourceFileSystemDataSourceProperty | cdktn.IResolvable | undefined);
        private _directoryPath?;
        get directoryPath(): string;
        set directoryPath(value: string);
        get directoryPathInput(): string | undefined;
        private _fileSystemAccessMode?;
        get fileSystemAccessMode(): string;
        set fileSystemAccessMode(value: string);
        get fileSystemAccessModeInput(): string | undefined;
        private _fileSystemId?;
        get fileSystemId(): string;
        set fileSystemId(value: string);
        get fileSystemIdInput(): string | undefined;
        private _fileSystemType?;
        get fileSystemType(): string;
        set fileSystemType(value: string);
        get fileSystemTypeInput(): string | undefined;
    }
    class TrainingJobDefinitionsInputDataConfigDataSourceFileSystemDataSourcePropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionsInputDataConfigDataSourceFileSystemDataSourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionsInputDataConfigDataSourceFileSystemDataSourcePropertyOutputReference;
    }
    interface TrainingJobDefinitionsInputDataConfigDataSourceS3DataSourceHubAccessConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#hub_content_arn TfHyperParameterTuningJob#hub_content_arn}
        */
        readonly hubContentArn: string;
    }
    class TrainingJobDefinitionsInputDataConfigDataSourceS3DataSourceHubAccessConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionsInputDataConfigDataSourceS3DataSourceHubAccessConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionsInputDataConfigDataSourceS3DataSourceHubAccessConfigProperty | cdktn.IResolvable | undefined);
        private _hubContentArn?;
        get hubContentArn(): string;
        set hubContentArn(value: string);
        get hubContentArnInput(): string | undefined;
    }
    class TrainingJobDefinitionsInputDataConfigDataSourceS3DataSourceHubAccessConfigPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionsInputDataConfigDataSourceS3DataSourceHubAccessConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionsInputDataConfigDataSourceS3DataSourceHubAccessConfigPropertyOutputReference;
    }
    interface TrainingJobDefinitionsInputDataConfigDataSourceS3DataSourceModelAccessConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#accept_eula TfHyperParameterTuningJob#accept_eula}
        */
        readonly acceptEula: boolean | cdktn.IResolvable;
    }
    class TrainingJobDefinitionsInputDataConfigDataSourceS3DataSourceModelAccessConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionsInputDataConfigDataSourceS3DataSourceModelAccessConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionsInputDataConfigDataSourceS3DataSourceModelAccessConfigProperty | cdktn.IResolvable | undefined);
        private _acceptEula?;
        get acceptEula(): boolean | cdktn.IResolvable;
        set acceptEula(value: boolean | cdktn.IResolvable);
        get acceptEulaInput(): boolean | cdktn.IResolvable | undefined;
    }
    class TrainingJobDefinitionsInputDataConfigDataSourceS3DataSourceModelAccessConfigPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionsInputDataConfigDataSourceS3DataSourceModelAccessConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionsInputDataConfigDataSourceS3DataSourceModelAccessConfigPropertyOutputReference;
    }
    interface TrainingJobDefinitionsInputDataConfigDataSourceS3DataSourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#attribute_names TfHyperParameterTuningJob#attribute_names}
        */
        readonly attributeNames?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#instance_group_names TfHyperParameterTuningJob#instance_group_names}
        */
        readonly instanceGroupNames?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#s3_data_distribution_type TfHyperParameterTuningJob#s3_data_distribution_type}
        */
        readonly s3DataDistributionType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#s3_data_type TfHyperParameterTuningJob#s3_data_type}
        */
        readonly s3DataType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#s3_uri TfHyperParameterTuningJob#s3_uri}
        */
        readonly s3Uri: string;
        /**
        * hub_access_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#hub_access_config TfHyperParameterTuningJob#hub_access_config}
        */
        readonly hubAccessConfig?: TrainingJobDefinitionsInputDataConfigDataSourceS3DataSourceHubAccessConfigProperty[] | cdktn.IResolvable;
        /**
        * model_access_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#model_access_config TfHyperParameterTuningJob#model_access_config}
        */
        readonly modelAccessConfig?: TrainingJobDefinitionsInputDataConfigDataSourceS3DataSourceModelAccessConfigProperty[] | cdktn.IResolvable;
    }
    class TrainingJobDefinitionsInputDataConfigDataSourceS3DataSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionsInputDataConfigDataSourceS3DataSourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionsInputDataConfigDataSourceS3DataSourceProperty | cdktn.IResolvable | undefined);
        private _attributeNames?;
        get attributeNames(): string[];
        set attributeNames(value: string[]);
        resetAttributeNames(): void;
        get attributeNamesInput(): string[] | undefined;
        private _instanceGroupNames?;
        get instanceGroupNames(): string[];
        set instanceGroupNames(value: string[]);
        resetInstanceGroupNames(): void;
        get instanceGroupNamesInput(): string[] | undefined;
        private _s3DataDistributionType?;
        get s3DataDistributionType(): string;
        set s3DataDistributionType(value: string);
        resetS3DataDistributionType(): void;
        get s3DataDistributionTypeInput(): string | undefined;
        private _s3DataType?;
        get s3DataType(): string;
        set s3DataType(value: string);
        get s3DataTypeInput(): string | undefined;
        private _s3Uri?;
        get s3Uri(): string;
        set s3Uri(value: string);
        get s3UriInput(): string | undefined;
        private _hubAccessConfig;
        get hubAccessConfig(): TrainingJobDefinitionsInputDataConfigDataSourceS3DataSourceHubAccessConfigPropertyList;
        putHubAccessConfig(value: TrainingJobDefinitionsInputDataConfigDataSourceS3DataSourceHubAccessConfigProperty[] | cdktn.IResolvable): void;
        resetHubAccessConfig(): void;
        get hubAccessConfigInput(): cdktn.IResolvable | TrainingJobDefinitionsInputDataConfigDataSourceS3DataSourceHubAccessConfigProperty[] | undefined;
        private _modelAccessConfig;
        get modelAccessConfig(): TrainingJobDefinitionsInputDataConfigDataSourceS3DataSourceModelAccessConfigPropertyList;
        putModelAccessConfig(value: TrainingJobDefinitionsInputDataConfigDataSourceS3DataSourceModelAccessConfigProperty[] | cdktn.IResolvable): void;
        resetModelAccessConfig(): void;
        get modelAccessConfigInput(): cdktn.IResolvable | TrainingJobDefinitionsInputDataConfigDataSourceS3DataSourceModelAccessConfigProperty[] | undefined;
    }
    class TrainingJobDefinitionsInputDataConfigDataSourceS3DataSourcePropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionsInputDataConfigDataSourceS3DataSourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionsInputDataConfigDataSourceS3DataSourcePropertyOutputReference;
    }
    interface TrainingJobDefinitionsInputDataConfigDataSourceProperty {
        /**
        * file_system_data_source block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#file_system_data_source TfHyperParameterTuningJob#file_system_data_source}
        */
        readonly fileSystemDataSource?: TrainingJobDefinitionsInputDataConfigDataSourceFileSystemDataSourceProperty[] | cdktn.IResolvable;
        /**
        * s3_data_source block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#s3_data_source TfHyperParameterTuningJob#s3_data_source}
        */
        readonly s3DataSource?: TrainingJobDefinitionsInputDataConfigDataSourceS3DataSourceProperty[] | cdktn.IResolvable;
    }
    class TrainingJobDefinitionsInputDataConfigDataSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionsInputDataConfigDataSourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionsInputDataConfigDataSourceProperty | cdktn.IResolvable | undefined);
        private _fileSystemDataSource;
        get fileSystemDataSource(): TrainingJobDefinitionsInputDataConfigDataSourceFileSystemDataSourcePropertyList;
        putFileSystemDataSource(value: TrainingJobDefinitionsInputDataConfigDataSourceFileSystemDataSourceProperty[] | cdktn.IResolvable): void;
        resetFileSystemDataSource(): void;
        get fileSystemDataSourceInput(): cdktn.IResolvable | TrainingJobDefinitionsInputDataConfigDataSourceFileSystemDataSourceProperty[] | undefined;
        private _s3DataSource;
        get s3DataSource(): TrainingJobDefinitionsInputDataConfigDataSourceS3DataSourcePropertyList;
        putS3DataSource(value: TrainingJobDefinitionsInputDataConfigDataSourceS3DataSourceProperty[] | cdktn.IResolvable): void;
        resetS3DataSource(): void;
        get s3DataSourceInput(): cdktn.IResolvable | TrainingJobDefinitionsInputDataConfigDataSourceS3DataSourceProperty[] | undefined;
    }
    class TrainingJobDefinitionsInputDataConfigDataSourcePropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionsInputDataConfigDataSourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionsInputDataConfigDataSourcePropertyOutputReference;
    }
    interface TrainingJobDefinitionsInputDataConfigShuffleConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#seed TfHyperParameterTuningJob#seed}
        */
        readonly seed: number;
    }
    class TrainingJobDefinitionsInputDataConfigShuffleConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionsInputDataConfigShuffleConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionsInputDataConfigShuffleConfigProperty | cdktn.IResolvable | undefined);
        private _seed?;
        get seed(): number;
        set seed(value: number);
        get seedInput(): number | undefined;
    }
    class TrainingJobDefinitionsInputDataConfigShuffleConfigPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionsInputDataConfigShuffleConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionsInputDataConfigShuffleConfigPropertyOutputReference;
    }
    interface TrainingJobDefinitionsInputDataConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#channel_name TfHyperParameterTuningJob#channel_name}
        */
        readonly channelName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#compression_type TfHyperParameterTuningJob#compression_type}
        */
        readonly compressionType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#content_type TfHyperParameterTuningJob#content_type}
        */
        readonly contentType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#input_mode TfHyperParameterTuningJob#input_mode}
        */
        readonly inputMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#record_wrapper_type TfHyperParameterTuningJob#record_wrapper_type}
        */
        readonly recordWrapperType?: string;
        /**
        * data_source block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#data_source TfHyperParameterTuningJob#data_source}
        */
        readonly dataSource?: TrainingJobDefinitionsInputDataConfigDataSourceProperty[] | cdktn.IResolvable;
        /**
        * shuffle_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#shuffle_config TfHyperParameterTuningJob#shuffle_config}
        */
        readonly shuffleConfig?: TrainingJobDefinitionsInputDataConfigShuffleConfigProperty[] | cdktn.IResolvable;
    }
    class TrainingJobDefinitionsInputDataConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionsInputDataConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionsInputDataConfigProperty | cdktn.IResolvable | undefined);
        private _channelName?;
        get channelName(): string;
        set channelName(value: string);
        get channelNameInput(): string | undefined;
        private _compressionType?;
        get compressionType(): string;
        set compressionType(value: string);
        resetCompressionType(): void;
        get compressionTypeInput(): string | undefined;
        private _contentType?;
        get contentType(): string;
        set contentType(value: string);
        resetContentType(): void;
        get contentTypeInput(): string | undefined;
        private _inputMode?;
        get inputMode(): string;
        set inputMode(value: string);
        resetInputMode(): void;
        get inputModeInput(): string | undefined;
        private _recordWrapperType?;
        get recordWrapperType(): string;
        set recordWrapperType(value: string);
        resetRecordWrapperType(): void;
        get recordWrapperTypeInput(): string | undefined;
        private _dataSource;
        get dataSource(): TrainingJobDefinitionsInputDataConfigDataSourcePropertyList;
        putDataSource(value: TrainingJobDefinitionsInputDataConfigDataSourceProperty[] | cdktn.IResolvable): void;
        resetDataSource(): void;
        get dataSourceInput(): cdktn.IResolvable | TrainingJobDefinitionsInputDataConfigDataSourceProperty[] | undefined;
        private _shuffleConfig;
        get shuffleConfig(): TrainingJobDefinitionsInputDataConfigShuffleConfigPropertyList;
        putShuffleConfig(value: TrainingJobDefinitionsInputDataConfigShuffleConfigProperty[] | cdktn.IResolvable): void;
        resetShuffleConfig(): void;
        get shuffleConfigInput(): cdktn.IResolvable | TrainingJobDefinitionsInputDataConfigShuffleConfigProperty[] | undefined;
    }
    class TrainingJobDefinitionsInputDataConfigPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionsInputDataConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionsInputDataConfigPropertyOutputReference;
    }
    interface TrainingJobDefinitionsOutputDataConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#compression_type TfHyperParameterTuningJob#compression_type}
        */
        readonly compressionType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#kms_key_id TfHyperParameterTuningJob#kms_key_id}
        */
        readonly kmsKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#s3_output_path TfHyperParameterTuningJob#s3_output_path}
        */
        readonly s3OutputPath: string;
    }
    class TrainingJobDefinitionsOutputDataConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionsOutputDataConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionsOutputDataConfigProperty | cdktn.IResolvable | undefined);
        private _compressionType?;
        get compressionType(): string;
        set compressionType(value: string);
        resetCompressionType(): void;
        get compressionTypeInput(): string | undefined;
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        resetKmsKeyId(): void;
        get kmsKeyIdInput(): string | undefined;
        private _s3OutputPath?;
        get s3OutputPath(): string;
        set s3OutputPath(value: string);
        get s3OutputPathInput(): string | undefined;
    }
    class TrainingJobDefinitionsOutputDataConfigPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionsOutputDataConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionsOutputDataConfigPropertyOutputReference;
    }
    interface TrainingJobDefinitionsResourceConfigInstanceGroupsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#instance_count TfHyperParameterTuningJob#instance_count}
        */
        readonly instanceCount: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#instance_group_name TfHyperParameterTuningJob#instance_group_name}
        */
        readonly instanceGroupName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#instance_type TfHyperParameterTuningJob#instance_type}
        */
        readonly instanceType: string;
    }
    class TrainingJobDefinitionsResourceConfigInstanceGroupsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionsResourceConfigInstanceGroupsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionsResourceConfigInstanceGroupsProperty | cdktn.IResolvable | undefined);
        private _instanceCount?;
        get instanceCount(): number;
        set instanceCount(value: number);
        get instanceCountInput(): number | undefined;
        private _instanceGroupName?;
        get instanceGroupName(): string;
        set instanceGroupName(value: string);
        get instanceGroupNameInput(): string | undefined;
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        get instanceTypeInput(): string | undefined;
    }
    class TrainingJobDefinitionsResourceConfigInstanceGroupsPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionsResourceConfigInstanceGroupsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionsResourceConfigInstanceGroupsPropertyOutputReference;
    }
    interface TrainingJobDefinitionsResourceConfigInstancePlacementConfigPlacementSpecificationsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#instance_count TfHyperParameterTuningJob#instance_count}
        */
        readonly instanceCount: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#ultra_server_id TfHyperParameterTuningJob#ultra_server_id}
        */
        readonly ultraServerId?: string;
    }
    class TrainingJobDefinitionsResourceConfigInstancePlacementConfigPlacementSpecificationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionsResourceConfigInstancePlacementConfigPlacementSpecificationsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionsResourceConfigInstancePlacementConfigPlacementSpecificationsProperty | cdktn.IResolvable | undefined);
        private _instanceCount?;
        get instanceCount(): number;
        set instanceCount(value: number);
        get instanceCountInput(): number | undefined;
        private _ultraServerId?;
        get ultraServerId(): string;
        set ultraServerId(value: string);
        resetUltraServerId(): void;
        get ultraServerIdInput(): string | undefined;
    }
    class TrainingJobDefinitionsResourceConfigInstancePlacementConfigPlacementSpecificationsPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionsResourceConfigInstancePlacementConfigPlacementSpecificationsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionsResourceConfigInstancePlacementConfigPlacementSpecificationsPropertyOutputReference;
    }
    interface TrainingJobDefinitionsResourceConfigInstancePlacementConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#enable_multiple_jobs TfHyperParameterTuningJob#enable_multiple_jobs}
        */
        readonly enableMultipleJobs?: boolean | cdktn.IResolvable;
        /**
        * placement_specifications block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#placement_specifications TfHyperParameterTuningJob#placement_specifications}
        */
        readonly placementSpecifications?: TrainingJobDefinitionsResourceConfigInstancePlacementConfigPlacementSpecificationsProperty[] | cdktn.IResolvable;
    }
    class TrainingJobDefinitionsResourceConfigInstancePlacementConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionsResourceConfigInstancePlacementConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionsResourceConfigInstancePlacementConfigProperty | cdktn.IResolvable | undefined);
        private _enableMultipleJobs?;
        get enableMultipleJobs(): boolean | cdktn.IResolvable;
        set enableMultipleJobs(value: boolean | cdktn.IResolvable);
        resetEnableMultipleJobs(): void;
        get enableMultipleJobsInput(): boolean | cdktn.IResolvable | undefined;
        private _placementSpecifications;
        get placementSpecifications(): TrainingJobDefinitionsResourceConfigInstancePlacementConfigPlacementSpecificationsPropertyList;
        putPlacementSpecifications(value: TrainingJobDefinitionsResourceConfigInstancePlacementConfigPlacementSpecificationsProperty[] | cdktn.IResolvable): void;
        resetPlacementSpecifications(): void;
        get placementSpecificationsInput(): cdktn.IResolvable | TrainingJobDefinitionsResourceConfigInstancePlacementConfigPlacementSpecificationsProperty[] | undefined;
    }
    class TrainingJobDefinitionsResourceConfigInstancePlacementConfigPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionsResourceConfigInstancePlacementConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionsResourceConfigInstancePlacementConfigPropertyOutputReference;
    }
    interface TrainingJobDefinitionsResourceConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#instance_count TfHyperParameterTuningJob#instance_count}
        */
        readonly instanceCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#instance_type TfHyperParameterTuningJob#instance_type}
        */
        readonly instanceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#keep_alive_period_in_seconds TfHyperParameterTuningJob#keep_alive_period_in_seconds}
        */
        readonly keepAlivePeriodInSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#training_plan_arn TfHyperParameterTuningJob#training_plan_arn}
        */
        readonly trainingPlanArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#volume_kms_key_id TfHyperParameterTuningJob#volume_kms_key_id}
        */
        readonly volumeKmsKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#volume_size_in_gb TfHyperParameterTuningJob#volume_size_in_gb}
        */
        readonly volumeSizeInGb?: number;
        /**
        * instance_groups block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#instance_groups TfHyperParameterTuningJob#instance_groups}
        */
        readonly instanceGroups?: TrainingJobDefinitionsResourceConfigInstanceGroupsProperty[] | cdktn.IResolvable;
        /**
        * instance_placement_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#instance_placement_config TfHyperParameterTuningJob#instance_placement_config}
        */
        readonly instancePlacementConfig?: TrainingJobDefinitionsResourceConfigInstancePlacementConfigProperty[] | cdktn.IResolvable;
    }
    class TrainingJobDefinitionsResourceConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionsResourceConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionsResourceConfigProperty | cdktn.IResolvable | undefined);
        private _instanceCount?;
        get instanceCount(): number;
        set instanceCount(value: number);
        resetInstanceCount(): void;
        get instanceCountInput(): number | undefined;
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        resetInstanceType(): void;
        get instanceTypeInput(): string | undefined;
        private _keepAlivePeriodInSeconds?;
        get keepAlivePeriodInSeconds(): number;
        set keepAlivePeriodInSeconds(value: number);
        resetKeepAlivePeriodInSeconds(): void;
        get keepAlivePeriodInSecondsInput(): number | undefined;
        private _trainingPlanArn?;
        get trainingPlanArn(): string;
        set trainingPlanArn(value: string);
        resetTrainingPlanArn(): void;
        get trainingPlanArnInput(): string | undefined;
        private _volumeKmsKeyId?;
        get volumeKmsKeyId(): string;
        set volumeKmsKeyId(value: string);
        resetVolumeKmsKeyId(): void;
        get volumeKmsKeyIdInput(): string | undefined;
        private _volumeSizeInGb?;
        get volumeSizeInGb(): number;
        set volumeSizeInGb(value: number);
        resetVolumeSizeInGb(): void;
        get volumeSizeInGbInput(): number | undefined;
        private _instanceGroups;
        get instanceGroups(): TrainingJobDefinitionsResourceConfigInstanceGroupsPropertyList;
        putInstanceGroups(value: TrainingJobDefinitionsResourceConfigInstanceGroupsProperty[] | cdktn.IResolvable): void;
        resetInstanceGroups(): void;
        get instanceGroupsInput(): cdktn.IResolvable | TrainingJobDefinitionsResourceConfigInstanceGroupsProperty[] | undefined;
        private _instancePlacementConfig;
        get instancePlacementConfig(): TrainingJobDefinitionsResourceConfigInstancePlacementConfigPropertyList;
        putInstancePlacementConfig(value: TrainingJobDefinitionsResourceConfigInstancePlacementConfigProperty[] | cdktn.IResolvable): void;
        resetInstancePlacementConfig(): void;
        get instancePlacementConfigInput(): cdktn.IResolvable | TrainingJobDefinitionsResourceConfigInstancePlacementConfigProperty[] | undefined;
    }
    class TrainingJobDefinitionsResourceConfigPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionsResourceConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionsResourceConfigPropertyOutputReference;
    }
    interface TrainingJobDefinitionsStoppingConditionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#max_pending_time_in_seconds TfHyperParameterTuningJob#max_pending_time_in_seconds}
        */
        readonly maxPendingTimeInSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#max_runtime_in_seconds TfHyperParameterTuningJob#max_runtime_in_seconds}
        */
        readonly maxRuntimeInSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#max_wait_time_in_seconds TfHyperParameterTuningJob#max_wait_time_in_seconds}
        */
        readonly maxWaitTimeInSeconds?: number;
    }
    class TrainingJobDefinitionsStoppingConditionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionsStoppingConditionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionsStoppingConditionProperty | cdktn.IResolvable | undefined);
        private _maxPendingTimeInSeconds?;
        get maxPendingTimeInSeconds(): number;
        set maxPendingTimeInSeconds(value: number);
        resetMaxPendingTimeInSeconds(): void;
        get maxPendingTimeInSecondsInput(): number | undefined;
        private _maxRuntimeInSeconds?;
        get maxRuntimeInSeconds(): number;
        set maxRuntimeInSeconds(value: number);
        resetMaxRuntimeInSeconds(): void;
        get maxRuntimeInSecondsInput(): number | undefined;
        private _maxWaitTimeInSeconds?;
        get maxWaitTimeInSeconds(): number;
        set maxWaitTimeInSeconds(value: number);
        resetMaxWaitTimeInSeconds(): void;
        get maxWaitTimeInSecondsInput(): number | undefined;
    }
    class TrainingJobDefinitionsStoppingConditionPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionsStoppingConditionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionsStoppingConditionPropertyOutputReference;
    }
    interface TrainingJobDefinitionsTuningObjectiveProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#metric_name TfHyperParameterTuningJob#metric_name}
        */
        readonly metricName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#type TfHyperParameterTuningJob#type}
        */
        readonly type: string;
    }
    class TrainingJobDefinitionsTuningObjectivePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionsTuningObjectiveProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionsTuningObjectiveProperty | cdktn.IResolvable | undefined);
        private _metricName?;
        get metricName(): string;
        set metricName(value: string);
        get metricNameInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class TrainingJobDefinitionsTuningObjectivePropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionsTuningObjectiveProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionsTuningObjectivePropertyOutputReference;
    }
    interface TrainingJobDefinitionsVpcConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#security_group_ids TfHyperParameterTuningJob#security_group_ids}
        */
        readonly securityGroupIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#subnets TfHyperParameterTuningJob#subnets}
        */
        readonly subnets: string[];
    }
    class TrainingJobDefinitionsVpcConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionsVpcConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionsVpcConfigProperty | cdktn.IResolvable | undefined);
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        get securityGroupIdsInput(): string[] | undefined;
        private _subnets?;
        get subnets(): string[];
        set subnets(value: string[]);
        get subnetsInput(): string[] | undefined;
    }
    class TrainingJobDefinitionsVpcConfigPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionsVpcConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionsVpcConfigPropertyOutputReference;
    }
    interface TrainingJobDefinitionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#definition_name TfHyperParameterTuningJob#definition_name}
        */
        readonly definitionName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#enable_inter_container_traffic_encryption TfHyperParameterTuningJob#enable_inter_container_traffic_encryption}
        */
        readonly enableInterContainerTrafficEncryption?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#enable_managed_spot_training TfHyperParameterTuningJob#enable_managed_spot_training}
        */
        readonly enableManagedSpotTraining?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#enable_network_isolation TfHyperParameterTuningJob#enable_network_isolation}
        */
        readonly enableNetworkIsolation?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#environment TfHyperParameterTuningJob#environment}
        */
        readonly environment?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#retry_strategy TfHyperParameterTuningJob#retry_strategy}
        */
        readonly retryStrategy?: TrainingJobDefinitionsRetryStrategyProperty[] | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#role_arn TfHyperParameterTuningJob#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#static_hyper_parameters TfHyperParameterTuningJob#static_hyper_parameters}
        */
        readonly staticHyperParameters?: {
            [key: string]: string;
        };
        /**
        * algorithm_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#algorithm_specification TfHyperParameterTuningJob#algorithm_specification}
        */
        readonly algorithmSpecification?: TrainingJobDefinitionsAlgorithmSpecificationProperty[] | cdktn.IResolvable;
        /**
        * checkpoint_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#checkpoint_config TfHyperParameterTuningJob#checkpoint_config}
        */
        readonly checkpointConfig?: TrainingJobDefinitionsCheckpointConfigProperty[] | cdktn.IResolvable;
        /**
        * hyper_parameter_ranges block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#hyper_parameter_ranges TfHyperParameterTuningJob#hyper_parameter_ranges}
        */
        readonly hyperParameterRanges?: TrainingJobDefinitionsHyperParameterRangesProperty[] | cdktn.IResolvable;
        /**
        * hyper_parameter_tuning_resource_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#hyper_parameter_tuning_resource_config TfHyperParameterTuningJob#hyper_parameter_tuning_resource_config}
        */
        readonly hyperParameterTuningResourceConfig?: TrainingJobDefinitionsHyperParameterTuningResourceConfigProperty[] | cdktn.IResolvable;
        /**
        * input_data_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#input_data_config TfHyperParameterTuningJob#input_data_config}
        */
        readonly inputDataConfig?: TrainingJobDefinitionsInputDataConfigProperty[] | cdktn.IResolvable;
        /**
        * output_data_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#output_data_config TfHyperParameterTuningJob#output_data_config}
        */
        readonly outputDataConfig?: TrainingJobDefinitionsOutputDataConfigProperty[] | cdktn.IResolvable;
        /**
        * resource_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#resource_config TfHyperParameterTuningJob#resource_config}
        */
        readonly resourceConfig?: TrainingJobDefinitionsResourceConfigProperty[] | cdktn.IResolvable;
        /**
        * stopping_condition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#stopping_condition TfHyperParameterTuningJob#stopping_condition}
        */
        readonly stoppingCondition?: TrainingJobDefinitionsStoppingConditionProperty[] | cdktn.IResolvable;
        /**
        * tuning_objective block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#tuning_objective TfHyperParameterTuningJob#tuning_objective}
        */
        readonly tuningObjective?: TrainingJobDefinitionsTuningObjectiveProperty[] | cdktn.IResolvable;
        /**
        * vpc_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#vpc_config TfHyperParameterTuningJob#vpc_config}
        */
        readonly vpcConfig?: TrainingJobDefinitionsVpcConfigProperty[] | cdktn.IResolvable;
    }
    class TrainingJobDefinitionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionsProperty | cdktn.IResolvable | undefined);
        private _definitionName?;
        get definitionName(): string;
        set definitionName(value: string);
        resetDefinitionName(): void;
        get definitionNameInput(): string | undefined;
        private _enableInterContainerTrafficEncryption?;
        get enableInterContainerTrafficEncryption(): boolean | cdktn.IResolvable;
        set enableInterContainerTrafficEncryption(value: boolean | cdktn.IResolvable);
        resetEnableInterContainerTrafficEncryption(): void;
        get enableInterContainerTrafficEncryptionInput(): boolean | cdktn.IResolvable | undefined;
        private _enableManagedSpotTraining?;
        get enableManagedSpotTraining(): boolean | cdktn.IResolvable;
        set enableManagedSpotTraining(value: boolean | cdktn.IResolvable);
        resetEnableManagedSpotTraining(): void;
        get enableManagedSpotTrainingInput(): boolean | cdktn.IResolvable | undefined;
        private _enableNetworkIsolation?;
        get enableNetworkIsolation(): boolean | cdktn.IResolvable;
        set enableNetworkIsolation(value: boolean | cdktn.IResolvable);
        resetEnableNetworkIsolation(): void;
        get enableNetworkIsolationInput(): boolean | cdktn.IResolvable | undefined;
        private _environment?;
        get environment(): {
            [key: string]: string;
        };
        set environment(value: {
            [key: string]: string;
        });
        resetEnvironment(): void;
        get environmentInput(): {
            [key: string]: string;
        } | undefined;
        private _retryStrategy;
        get retryStrategy(): TrainingJobDefinitionsRetryStrategyPropertyList;
        putRetryStrategy(value: TrainingJobDefinitionsRetryStrategyProperty[] | cdktn.IResolvable): void;
        resetRetryStrategy(): void;
        get retryStrategyInput(): cdktn.IResolvable | TrainingJobDefinitionsRetryStrategyProperty[] | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _staticHyperParameters?;
        get staticHyperParameters(): {
            [key: string]: string;
        };
        set staticHyperParameters(value: {
            [key: string]: string;
        });
        resetStaticHyperParameters(): void;
        get staticHyperParametersInput(): {
            [key: string]: string;
        } | undefined;
        private _algorithmSpecification;
        get algorithmSpecification(): TrainingJobDefinitionsAlgorithmSpecificationPropertyList;
        putAlgorithmSpecification(value: TrainingJobDefinitionsAlgorithmSpecificationProperty[] | cdktn.IResolvable): void;
        resetAlgorithmSpecification(): void;
        get algorithmSpecificationInput(): cdktn.IResolvable | TrainingJobDefinitionsAlgorithmSpecificationProperty[] | undefined;
        private _checkpointConfig;
        get checkpointConfig(): TrainingJobDefinitionsCheckpointConfigPropertyList;
        putCheckpointConfig(value: TrainingJobDefinitionsCheckpointConfigProperty[] | cdktn.IResolvable): void;
        resetCheckpointConfig(): void;
        get checkpointConfigInput(): cdktn.IResolvable | TrainingJobDefinitionsCheckpointConfigProperty[] | undefined;
        private _hyperParameterRanges;
        get hyperParameterRanges(): TrainingJobDefinitionsHyperParameterRangesPropertyList;
        putHyperParameterRanges(value: TrainingJobDefinitionsHyperParameterRangesProperty[] | cdktn.IResolvable): void;
        resetHyperParameterRanges(): void;
        get hyperParameterRangesInput(): cdktn.IResolvable | TrainingJobDefinitionsHyperParameterRangesProperty[] | undefined;
        private _hyperParameterTuningResourceConfig;
        get hyperParameterTuningResourceConfig(): TrainingJobDefinitionsHyperParameterTuningResourceConfigPropertyList;
        putHyperParameterTuningResourceConfig(value: TrainingJobDefinitionsHyperParameterTuningResourceConfigProperty[] | cdktn.IResolvable): void;
        resetHyperParameterTuningResourceConfig(): void;
        get hyperParameterTuningResourceConfigInput(): cdktn.IResolvable | TrainingJobDefinitionsHyperParameterTuningResourceConfigProperty[] | undefined;
        private _inputDataConfig;
        get inputDataConfig(): TrainingJobDefinitionsInputDataConfigPropertyList;
        putInputDataConfig(value: TrainingJobDefinitionsInputDataConfigProperty[] | cdktn.IResolvable): void;
        resetInputDataConfig(): void;
        get inputDataConfigInput(): cdktn.IResolvable | TrainingJobDefinitionsInputDataConfigProperty[] | undefined;
        private _outputDataConfig;
        get outputDataConfig(): TrainingJobDefinitionsOutputDataConfigPropertyList;
        putOutputDataConfig(value: TrainingJobDefinitionsOutputDataConfigProperty[] | cdktn.IResolvable): void;
        resetOutputDataConfig(): void;
        get outputDataConfigInput(): cdktn.IResolvable | TrainingJobDefinitionsOutputDataConfigProperty[] | undefined;
        private _resourceConfig;
        get resourceConfig(): TrainingJobDefinitionsResourceConfigPropertyList;
        putResourceConfig(value: TrainingJobDefinitionsResourceConfigProperty[] | cdktn.IResolvable): void;
        resetResourceConfig(): void;
        get resourceConfigInput(): cdktn.IResolvable | TrainingJobDefinitionsResourceConfigProperty[] | undefined;
        private _stoppingCondition;
        get stoppingCondition(): TrainingJobDefinitionsStoppingConditionPropertyList;
        putStoppingCondition(value: TrainingJobDefinitionsStoppingConditionProperty[] | cdktn.IResolvable): void;
        resetStoppingCondition(): void;
        get stoppingConditionInput(): cdktn.IResolvable | TrainingJobDefinitionsStoppingConditionProperty[] | undefined;
        private _tuningObjective;
        get tuningObjective(): TrainingJobDefinitionsTuningObjectivePropertyList;
        putTuningObjective(value: TrainingJobDefinitionsTuningObjectiveProperty[] | cdktn.IResolvable): void;
        resetTuningObjective(): void;
        get tuningObjectiveInput(): cdktn.IResolvable | TrainingJobDefinitionsTuningObjectiveProperty[] | undefined;
        private _vpcConfig;
        get vpcConfig(): TrainingJobDefinitionsVpcConfigPropertyList;
        putVpcConfig(value: TrainingJobDefinitionsVpcConfigProperty[] | cdktn.IResolvable): void;
        resetVpcConfig(): void;
        get vpcConfigInput(): cdktn.IResolvable | TrainingJobDefinitionsVpcConfigProperty[] | undefined;
    }
    class TrainingJobDefinitionsPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionsPropertyOutputReference;
    }
    interface ParentHyperParameterTuningJobsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#name TfHyperParameterTuningJob#name}
        */
        readonly name: string;
    }
    class ParentHyperParameterTuningJobsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ParentHyperParameterTuningJobsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ParentHyperParameterTuningJobsProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    class ParentHyperParameterTuningJobsPropertyList extends cdktn.ComplexList {
        internalValue?: ParentHyperParameterTuningJobsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ParentHyperParameterTuningJobsPropertyOutputReference;
    }
    interface WarmStartConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#warm_start_type TfHyperParameterTuningJob#warm_start_type}
        */
        readonly warmStartType?: string;
        /**
        * parent_hyper_parameter_tuning_jobs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hyper_parameter_tuning_job#parent_hyper_parameter_tuning_jobs TfHyperParameterTuningJob#parent_hyper_parameter_tuning_jobs}
        */
        readonly parentHyperParameterTuningJobs?: ParentHyperParameterTuningJobsProperty[] | cdktn.IResolvable;
    }
    class WarmStartConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WarmStartConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WarmStartConfigProperty | cdktn.IResolvable | undefined);
        private _warmStartType?;
        get warmStartType(): string;
        set warmStartType(value: string);
        resetWarmStartType(): void;
        get warmStartTypeInput(): string | undefined;
        private _parentHyperParameterTuningJobs;
        get parentHyperParameterTuningJobs(): ParentHyperParameterTuningJobsPropertyList;
        putParentHyperParameterTuningJobs(value: ParentHyperParameterTuningJobsProperty[] | cdktn.IResolvable): void;
        resetParentHyperParameterTuningJobs(): void;
        get parentHyperParameterTuningJobsInput(): cdktn.IResolvable | ParentHyperParameterTuningJobsProperty[] | undefined;
    }
    class WarmStartConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WarmStartConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WarmStartConfigPropertyOutputReference;
    }
}
