import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfPipelineConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_pipeline#id TfPipeline#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_pipeline#pipeline_definition TfPipeline#pipeline_definition}
    */
    readonly pipelineDefinition?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_pipeline#pipeline_description TfPipeline#pipeline_description}
    */
    readonly pipelineDescription?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_pipeline#pipeline_display_name TfPipeline#pipeline_display_name}
    */
    readonly pipelineDisplayName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_pipeline#pipeline_name TfPipeline#pipeline_name}
    */
    readonly pipelineName: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_pipeline#region TfPipeline#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_pipeline#role_arn TfPipeline#role_arn}
    */
    readonly roleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_pipeline#tags TfPipeline#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_pipeline#tags_all TfPipeline#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * parallelism_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_pipeline#parallelism_configuration TfPipeline#parallelism_configuration}
    */
    readonly parallelismConfiguration?: TfPipeline.ParallelismConfigurationProperty;
    /**
    * pipeline_definition_s3_location block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_pipeline#pipeline_definition_s3_location TfPipeline#pipeline_definition_s3_location}
    */
    readonly pipelineDefinitionS3Location?: TfPipeline.PipelineDefinitionS3LocationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_pipeline aws_sagemaker_pipeline}
*/
export declare class TfPipeline extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_sagemaker_pipeline";
    /**
    * Generates CDKTN code for importing a TfPipeline resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfPipeline to import
    * @param importFromId The id of the existing TfPipeline that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_pipeline#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfPipeline to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_pipeline aws_sagemaker_pipeline} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfPipelineConfig
    */
    constructor(scope: Construct, id: string, config: TfPipelineConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _pipelineDefinition?;
    get pipelineDefinition(): string;
    set pipelineDefinition(value: string);
    resetPipelineDefinition(): void;
    get pipelineDefinitionInput(): string | undefined;
    private _pipelineDescription?;
    get pipelineDescription(): string;
    set pipelineDescription(value: string);
    resetPipelineDescription(): void;
    get pipelineDescriptionInput(): string | undefined;
    private _pipelineDisplayName?;
    get pipelineDisplayName(): string;
    set pipelineDisplayName(value: string);
    get pipelineDisplayNameInput(): string | undefined;
    private _pipelineName?;
    get pipelineName(): string;
    set pipelineName(value: string);
    get pipelineNameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    resetRoleArn(): void;
    get roleArnInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _parallelismConfiguration;
    get parallelismConfiguration(): TfPipeline.ParallelismConfigurationPropertyOutputReference;
    putParallelismConfiguration(value: TfPipeline.ParallelismConfigurationProperty): void;
    resetParallelismConfiguration(): void;
    get parallelismConfigurationInput(): TfPipeline.ParallelismConfigurationProperty | undefined;
    private _pipelineDefinitionS3Location;
    get pipelineDefinitionS3Location(): TfPipeline.PipelineDefinitionS3LocationPropertyOutputReference;
    putPipelineDefinitionS3Location(value: TfPipeline.PipelineDefinitionS3LocationProperty): void;
    resetPipelineDefinitionS3Location(): void;
    get pipelineDefinitionS3LocationInput(): TfPipeline.PipelineDefinitionS3LocationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfPipelineParallelismConfigurationPropertyToTerraform(struct?: TfPipeline.ParallelismConfigurationPropertyOutputReference | TfPipeline.ParallelismConfigurationProperty): any;
export declare function tfPipelineParallelismConfigurationPropertyToHclTerraform(struct?: TfPipeline.ParallelismConfigurationPropertyOutputReference | TfPipeline.ParallelismConfigurationProperty): any;
export declare function tfPipelinePipelineDefinitionS3LocationPropertyToTerraform(struct?: TfPipeline.PipelineDefinitionS3LocationPropertyOutputReference | TfPipeline.PipelineDefinitionS3LocationProperty): any;
export declare function tfPipelinePipelineDefinitionS3LocationPropertyToHclTerraform(struct?: TfPipeline.PipelineDefinitionS3LocationPropertyOutputReference | TfPipeline.PipelineDefinitionS3LocationProperty): any;
export declare namespace TfPipeline {
    interface ParallelismConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_pipeline#max_parallel_execution_steps TfPipeline#max_parallel_execution_steps}
        */
        readonly maxParallelExecutionSteps: number;
    }
    class ParallelismConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ParallelismConfigurationProperty | undefined;
        set internalValue(value: ParallelismConfigurationProperty | undefined);
        private _maxParallelExecutionSteps?;
        get maxParallelExecutionSteps(): number;
        set maxParallelExecutionSteps(value: number);
        get maxParallelExecutionStepsInput(): number | undefined;
    }
    interface PipelineDefinitionS3LocationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_pipeline#bucket TfPipeline#bucket}
        */
        readonly bucket: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_pipeline#object_key TfPipeline#object_key}
        */
        readonly objectKey: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_pipeline#version_id TfPipeline#version_id}
        */
        readonly versionId?: string;
    }
    class PipelineDefinitionS3LocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PipelineDefinitionS3LocationProperty | undefined;
        set internalValue(value: PipelineDefinitionS3LocationProperty | undefined);
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        get bucketInput(): string | undefined;
        private _objectKey?;
        get objectKey(): string;
        set objectKey(value: string);
        get objectKeyInput(): string | undefined;
        private _versionId?;
        get versionId(): string;
        set versionId(value: string);
        resetVersionId(): void;
        get versionIdInput(): string | undefined;
    }
}
