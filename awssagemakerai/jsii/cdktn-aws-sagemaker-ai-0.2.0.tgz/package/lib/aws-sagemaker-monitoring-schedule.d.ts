import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfMonitoringScheduleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#id TfMonitoringSchedule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#name TfMonitoringSchedule#name}
    */
    readonly name?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#region TfMonitoringSchedule#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#tags TfMonitoringSchedule#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#tags_all TfMonitoringSchedule#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * monitoring_schedule_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#monitoring_schedule_config TfMonitoringSchedule#monitoring_schedule_config}
    */
    readonly monitoringScheduleConfig: TfMonitoringSchedule.MonitoringScheduleConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule aws_sagemaker_monitoring_schedule}
*/
export declare class TfMonitoringSchedule extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_sagemaker_monitoring_schedule";
    /**
    * Generates CDKTN code for importing a TfMonitoringSchedule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfMonitoringSchedule to import
    * @param importFromId The id of the existing TfMonitoringSchedule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfMonitoringSchedule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule aws_sagemaker_monitoring_schedule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfMonitoringScheduleConfig
    */
    constructor(scope: Construct, id: string, config: TfMonitoringScheduleConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _monitoringScheduleConfig;
    get monitoringScheduleConfig(): TfMonitoringSchedule.MonitoringScheduleConfigPropertyOutputReference;
    putMonitoringScheduleConfig(value: TfMonitoringSchedule.MonitoringScheduleConfigProperty): void;
    get monitoringScheduleConfigInput(): TfMonitoringSchedule.MonitoringScheduleConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfMonitoringScheduleConstraintsResourcePropertyToTerraform(struct?: TfMonitoringSchedule.ConstraintsResourcePropertyOutputReference | TfMonitoringSchedule.ConstraintsResourceProperty): any;
export declare function tfMonitoringScheduleConstraintsResourcePropertyToHclTerraform(struct?: TfMonitoringSchedule.ConstraintsResourcePropertyOutputReference | TfMonitoringSchedule.ConstraintsResourceProperty): any;
export declare function tfMonitoringScheduleStatisticsResourcePropertyToTerraform(struct?: TfMonitoringSchedule.StatisticsResourcePropertyOutputReference | TfMonitoringSchedule.StatisticsResourceProperty): any;
export declare function tfMonitoringScheduleStatisticsResourcePropertyToHclTerraform(struct?: TfMonitoringSchedule.StatisticsResourcePropertyOutputReference | TfMonitoringSchedule.StatisticsResourceProperty): any;
export declare function tfMonitoringScheduleBaselinePropertyToTerraform(struct?: TfMonitoringSchedule.BaselinePropertyOutputReference | TfMonitoringSchedule.BaselineProperty): any;
export declare function tfMonitoringScheduleBaselinePropertyToHclTerraform(struct?: TfMonitoringSchedule.BaselinePropertyOutputReference | TfMonitoringSchedule.BaselineProperty): any;
export declare function tfMonitoringScheduleMonitoringAppSpecificationPropertyToTerraform(struct?: TfMonitoringSchedule.MonitoringAppSpecificationPropertyOutputReference | TfMonitoringSchedule.MonitoringAppSpecificationProperty): any;
export declare function tfMonitoringScheduleMonitoringAppSpecificationPropertyToHclTerraform(struct?: TfMonitoringSchedule.MonitoringAppSpecificationPropertyOutputReference | TfMonitoringSchedule.MonitoringAppSpecificationProperty): any;
export declare function tfMonitoringScheduleCsvPropertyToTerraform(struct?: TfMonitoringSchedule.CsvPropertyOutputReference | TfMonitoringSchedule.CsvProperty): any;
export declare function tfMonitoringScheduleCsvPropertyToHclTerraform(struct?: TfMonitoringSchedule.CsvPropertyOutputReference | TfMonitoringSchedule.CsvProperty): any;
export declare function tfMonitoringScheduleJsonPropertyToTerraform(struct?: TfMonitoringSchedule.JsonPropertyOutputReference | TfMonitoringSchedule.JsonProperty): any;
export declare function tfMonitoringScheduleJsonPropertyToHclTerraform(struct?: TfMonitoringSchedule.JsonPropertyOutputReference | TfMonitoringSchedule.JsonProperty): any;
export declare function tfMonitoringScheduleDatasetFormatPropertyToTerraform(struct?: TfMonitoringSchedule.DatasetFormatPropertyOutputReference | TfMonitoringSchedule.DatasetFormatProperty): any;
export declare function tfMonitoringScheduleDatasetFormatPropertyToHclTerraform(struct?: TfMonitoringSchedule.DatasetFormatPropertyOutputReference | TfMonitoringSchedule.DatasetFormatProperty): any;
export declare function tfMonitoringScheduleBatchTransformInputPropertyToTerraform(struct?: TfMonitoringSchedule.BatchTransformInputPropertyOutputReference | TfMonitoringSchedule.BatchTransformInputProperty): any;
export declare function tfMonitoringScheduleBatchTransformInputPropertyToHclTerraform(struct?: TfMonitoringSchedule.BatchTransformInputPropertyOutputReference | TfMonitoringSchedule.BatchTransformInputProperty): any;
export declare function tfMonitoringScheduleEndpointInputPropertyToTerraform(struct?: TfMonitoringSchedule.EndpointInputPropertyOutputReference | TfMonitoringSchedule.EndpointInputProperty): any;
export declare function tfMonitoringScheduleEndpointInputPropertyToHclTerraform(struct?: TfMonitoringSchedule.EndpointInputPropertyOutputReference | TfMonitoringSchedule.EndpointInputProperty): any;
export declare function tfMonitoringScheduleMonitoringInputsPropertyToTerraform(struct?: TfMonitoringSchedule.MonitoringInputsPropertyOutputReference | TfMonitoringSchedule.MonitoringInputsProperty): any;
export declare function tfMonitoringScheduleMonitoringInputsPropertyToHclTerraform(struct?: TfMonitoringSchedule.MonitoringInputsPropertyOutputReference | TfMonitoringSchedule.MonitoringInputsProperty): any;
export declare function tfMonitoringScheduleS3OutputPropertyToTerraform(struct?: TfMonitoringSchedule.S3OutputPropertyOutputReference | TfMonitoringSchedule.S3OutputProperty): any;
export declare function tfMonitoringScheduleS3OutputPropertyToHclTerraform(struct?: TfMonitoringSchedule.S3OutputPropertyOutputReference | TfMonitoringSchedule.S3OutputProperty): any;
export declare function tfMonitoringScheduleMonitoringOutputsPropertyToTerraform(struct?: TfMonitoringSchedule.MonitoringOutputsPropertyOutputReference | TfMonitoringSchedule.MonitoringOutputsProperty): any;
export declare function tfMonitoringScheduleMonitoringOutputsPropertyToHclTerraform(struct?: TfMonitoringSchedule.MonitoringOutputsPropertyOutputReference | TfMonitoringSchedule.MonitoringOutputsProperty): any;
export declare function tfMonitoringScheduleMonitoringOutputConfigPropertyToTerraform(struct?: TfMonitoringSchedule.MonitoringOutputConfigPropertyOutputReference | TfMonitoringSchedule.MonitoringOutputConfigProperty): any;
export declare function tfMonitoringScheduleMonitoringOutputConfigPropertyToHclTerraform(struct?: TfMonitoringSchedule.MonitoringOutputConfigPropertyOutputReference | TfMonitoringSchedule.MonitoringOutputConfigProperty): any;
export declare function tfMonitoringScheduleClusterConfigPropertyToTerraform(struct?: TfMonitoringSchedule.ClusterConfigPropertyOutputReference | TfMonitoringSchedule.ClusterConfigProperty): any;
export declare function tfMonitoringScheduleClusterConfigPropertyToHclTerraform(struct?: TfMonitoringSchedule.ClusterConfigPropertyOutputReference | TfMonitoringSchedule.ClusterConfigProperty): any;
export declare function tfMonitoringScheduleMonitoringResourcesPropertyToTerraform(struct?: TfMonitoringSchedule.MonitoringResourcesPropertyOutputReference | TfMonitoringSchedule.MonitoringResourcesProperty): any;
export declare function tfMonitoringScheduleMonitoringResourcesPropertyToHclTerraform(struct?: TfMonitoringSchedule.MonitoringResourcesPropertyOutputReference | TfMonitoringSchedule.MonitoringResourcesProperty): any;
export declare function tfMonitoringScheduleVpcConfigPropertyToTerraform(struct?: TfMonitoringSchedule.VpcConfigPropertyOutputReference | TfMonitoringSchedule.VpcConfigProperty): any;
export declare function tfMonitoringScheduleVpcConfigPropertyToHclTerraform(struct?: TfMonitoringSchedule.VpcConfigPropertyOutputReference | TfMonitoringSchedule.VpcConfigProperty): any;
export declare function tfMonitoringScheduleNetworkConfigPropertyToTerraform(struct?: TfMonitoringSchedule.NetworkConfigPropertyOutputReference | TfMonitoringSchedule.NetworkConfigProperty): any;
export declare function tfMonitoringScheduleNetworkConfigPropertyToHclTerraform(struct?: TfMonitoringSchedule.NetworkConfigPropertyOutputReference | TfMonitoringSchedule.NetworkConfigProperty): any;
export declare function tfMonitoringScheduleStoppingConditionPropertyToTerraform(struct?: TfMonitoringSchedule.StoppingConditionProperty | cdktn.IResolvable): any;
export declare function tfMonitoringScheduleStoppingConditionPropertyToHclTerraform(struct?: TfMonitoringSchedule.StoppingConditionProperty | cdktn.IResolvable): any;
export declare function tfMonitoringScheduleMonitoringJobDefinitionPropertyToTerraform(struct?: TfMonitoringSchedule.MonitoringJobDefinitionPropertyOutputReference | TfMonitoringSchedule.MonitoringJobDefinitionProperty): any;
export declare function tfMonitoringScheduleMonitoringJobDefinitionPropertyToHclTerraform(struct?: TfMonitoringSchedule.MonitoringJobDefinitionPropertyOutputReference | TfMonitoringSchedule.MonitoringJobDefinitionProperty): any;
export declare function tfMonitoringScheduleScheduleConfigPropertyToTerraform(struct?: TfMonitoringSchedule.ScheduleConfigPropertyOutputReference | TfMonitoringSchedule.ScheduleConfigProperty): any;
export declare function tfMonitoringScheduleScheduleConfigPropertyToHclTerraform(struct?: TfMonitoringSchedule.ScheduleConfigPropertyOutputReference | TfMonitoringSchedule.ScheduleConfigProperty): any;
export declare function tfMonitoringScheduleMonitoringScheduleConfigPropertyToTerraform(struct?: TfMonitoringSchedule.MonitoringScheduleConfigPropertyOutputReference | TfMonitoringSchedule.MonitoringScheduleConfigProperty): any;
export declare function tfMonitoringScheduleMonitoringScheduleConfigPropertyToHclTerraform(struct?: TfMonitoringSchedule.MonitoringScheduleConfigPropertyOutputReference | TfMonitoringSchedule.MonitoringScheduleConfigProperty): any;
export declare namespace TfMonitoringSchedule {
    interface ConstraintsResourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#s3_uri TfMonitoringSchedule#s3_uri}
        */
        readonly s3Uri?: string;
    }
    class ConstraintsResourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConstraintsResourceProperty | undefined;
        set internalValue(value: ConstraintsResourceProperty | undefined);
        private _s3Uri?;
        get s3Uri(): string;
        set s3Uri(value: string);
        resetS3Uri(): void;
        get s3UriInput(): string | undefined;
    }
    interface StatisticsResourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#s3_uri TfMonitoringSchedule#s3_uri}
        */
        readonly s3Uri?: string;
    }
    class StatisticsResourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StatisticsResourceProperty | undefined;
        set internalValue(value: StatisticsResourceProperty | undefined);
        private _s3Uri?;
        get s3Uri(): string;
        set s3Uri(value: string);
        resetS3Uri(): void;
        get s3UriInput(): string | undefined;
    }
    interface BaselineProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#baselining_job_name TfMonitoringSchedule#baselining_job_name}
        */
        readonly baseliningJobName?: string;
        /**
        * constraints_resource block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#constraints_resource TfMonitoringSchedule#constraints_resource}
        */
        readonly constraintsResource?: ConstraintsResourceProperty;
        /**
        * statistics_resource block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#statistics_resource TfMonitoringSchedule#statistics_resource}
        */
        readonly statisticsResource?: StatisticsResourceProperty;
    }
    class BaselinePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BaselineProperty | undefined;
        set internalValue(value: BaselineProperty | undefined);
        private _baseliningJobName?;
        get baseliningJobName(): string;
        set baseliningJobName(value: string);
        resetBaseliningJobName(): void;
        get baseliningJobNameInput(): string | undefined;
        private _constraintsResource;
        get constraintsResource(): ConstraintsResourcePropertyOutputReference;
        putConstraintsResource(value: ConstraintsResourceProperty): void;
        resetConstraintsResource(): void;
        get constraintsResourceInput(): ConstraintsResourceProperty | undefined;
        private _statisticsResource;
        get statisticsResource(): StatisticsResourcePropertyOutputReference;
        putStatisticsResource(value: StatisticsResourceProperty): void;
        resetStatisticsResource(): void;
        get statisticsResourceInput(): StatisticsResourceProperty | undefined;
    }
    interface MonitoringAppSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#container_arguments TfMonitoringSchedule#container_arguments}
        */
        readonly containerArguments?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#container_entrypoint TfMonitoringSchedule#container_entrypoint}
        */
        readonly containerEntrypoint?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#image_uri TfMonitoringSchedule#image_uri}
        */
        readonly imageUri: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#post_analytics_processor_source_uri TfMonitoringSchedule#post_analytics_processor_source_uri}
        */
        readonly postAnalyticsProcessorSourceUri?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#record_preprocessor_source_uri TfMonitoringSchedule#record_preprocessor_source_uri}
        */
        readonly recordPreprocessorSourceUri?: string;
    }
    class MonitoringAppSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MonitoringAppSpecificationProperty | undefined;
        set internalValue(value: MonitoringAppSpecificationProperty | undefined);
        private _containerArguments?;
        get containerArguments(): string[];
        set containerArguments(value: string[]);
        resetContainerArguments(): void;
        get containerArgumentsInput(): string[] | undefined;
        private _containerEntrypoint?;
        get containerEntrypoint(): string[];
        set containerEntrypoint(value: string[]);
        resetContainerEntrypoint(): void;
        get containerEntrypointInput(): string[] | undefined;
        private _imageUri?;
        get imageUri(): string;
        set imageUri(value: string);
        get imageUriInput(): string | undefined;
        private _postAnalyticsProcessorSourceUri?;
        get postAnalyticsProcessorSourceUri(): string;
        set postAnalyticsProcessorSourceUri(value: string);
        resetPostAnalyticsProcessorSourceUri(): void;
        get postAnalyticsProcessorSourceUriInput(): string | undefined;
        private _recordPreprocessorSourceUri?;
        get recordPreprocessorSourceUri(): string;
        set recordPreprocessorSourceUri(value: string);
        resetRecordPreprocessorSourceUri(): void;
        get recordPreprocessorSourceUriInput(): string | undefined;
    }
    interface CsvProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#header TfMonitoringSchedule#header}
        */
        readonly header?: boolean | cdktn.IResolvable;
    }
    class CsvPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CsvProperty | undefined;
        set internalValue(value: CsvProperty | undefined);
        private _header?;
        get header(): boolean | cdktn.IResolvable;
        set header(value: boolean | cdktn.IResolvable);
        resetHeader(): void;
        get headerInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface JsonProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#line TfMonitoringSchedule#line}
        */
        readonly line?: boolean | cdktn.IResolvable;
    }
    class JsonPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): JsonProperty | undefined;
        set internalValue(value: JsonProperty | undefined);
        private _line?;
        get line(): boolean | cdktn.IResolvable;
        set line(value: boolean | cdktn.IResolvable);
        resetLine(): void;
        get lineInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface DatasetFormatProperty {
        /**
        * csv block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#csv TfMonitoringSchedule#csv}
        */
        readonly csv?: CsvProperty;
        /**
        * json block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#json TfMonitoringSchedule#json}
        */
        readonly json?: JsonProperty;
    }
    class DatasetFormatPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DatasetFormatProperty | undefined;
        set internalValue(value: DatasetFormatProperty | undefined);
        private _csv;
        get csv(): CsvPropertyOutputReference;
        putCsv(value: CsvProperty): void;
        resetCsv(): void;
        get csvInput(): CsvProperty | undefined;
        private _json;
        get json(): JsonPropertyOutputReference;
        putJson(value: JsonProperty): void;
        resetJson(): void;
        get jsonInput(): JsonProperty | undefined;
    }
    interface BatchTransformInputProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#data_captured_destination_s3_uri TfMonitoringSchedule#data_captured_destination_s3_uri}
        */
        readonly dataCapturedDestinationS3Uri: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#end_time_offset TfMonitoringSchedule#end_time_offset}
        */
        readonly endTimeOffset?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#exclude_features_attribute TfMonitoringSchedule#exclude_features_attribute}
        */
        readonly excludeFeaturesAttribute?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#features_attribute TfMonitoringSchedule#features_attribute}
        */
        readonly featuresAttribute?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#inference_attribute TfMonitoringSchedule#inference_attribute}
        */
        readonly inferenceAttribute?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#local_path TfMonitoringSchedule#local_path}
        */
        readonly localPath: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#probability_attribute TfMonitoringSchedule#probability_attribute}
        */
        readonly probabilityAttribute?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#probability_threshold_attribute TfMonitoringSchedule#probability_threshold_attribute}
        */
        readonly probabilityThresholdAttribute?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#s3_data_distribution_type TfMonitoringSchedule#s3_data_distribution_type}
        */
        readonly s3DataDistributionType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#s3_input_mode TfMonitoringSchedule#s3_input_mode}
        */
        readonly s3InputMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#start_time_offset TfMonitoringSchedule#start_time_offset}
        */
        readonly startTimeOffset?: string;
        /**
        * dataset_format block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#dataset_format TfMonitoringSchedule#dataset_format}
        */
        readonly datasetFormat: DatasetFormatProperty;
    }
    class BatchTransformInputPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BatchTransformInputProperty | undefined;
        set internalValue(value: BatchTransformInputProperty | undefined);
        private _dataCapturedDestinationS3Uri?;
        get dataCapturedDestinationS3Uri(): string;
        set dataCapturedDestinationS3Uri(value: string);
        get dataCapturedDestinationS3UriInput(): string | undefined;
        private _endTimeOffset?;
        get endTimeOffset(): string;
        set endTimeOffset(value: string);
        resetEndTimeOffset(): void;
        get endTimeOffsetInput(): string | undefined;
        private _excludeFeaturesAttribute?;
        get excludeFeaturesAttribute(): string;
        set excludeFeaturesAttribute(value: string);
        resetExcludeFeaturesAttribute(): void;
        get excludeFeaturesAttributeInput(): string | undefined;
        private _featuresAttribute?;
        get featuresAttribute(): string;
        set featuresAttribute(value: string);
        resetFeaturesAttribute(): void;
        get featuresAttributeInput(): string | undefined;
        private _inferenceAttribute?;
        get inferenceAttribute(): string;
        set inferenceAttribute(value: string);
        resetInferenceAttribute(): void;
        get inferenceAttributeInput(): string | undefined;
        private _localPath?;
        get localPath(): string;
        set localPath(value: string);
        get localPathInput(): string | undefined;
        private _probabilityAttribute?;
        get probabilityAttribute(): string;
        set probabilityAttribute(value: string);
        resetProbabilityAttribute(): void;
        get probabilityAttributeInput(): string | undefined;
        private _probabilityThresholdAttribute?;
        get probabilityThresholdAttribute(): number;
        set probabilityThresholdAttribute(value: number);
        resetProbabilityThresholdAttribute(): void;
        get probabilityThresholdAttributeInput(): number | undefined;
        private _s3DataDistributionType?;
        get s3DataDistributionType(): string;
        set s3DataDistributionType(value: string);
        resetS3DataDistributionType(): void;
        get s3DataDistributionTypeInput(): string | undefined;
        private _s3InputMode?;
        get s3InputMode(): string;
        set s3InputMode(value: string);
        resetS3InputMode(): void;
        get s3InputModeInput(): string | undefined;
        private _startTimeOffset?;
        get startTimeOffset(): string;
        set startTimeOffset(value: string);
        resetStartTimeOffset(): void;
        get startTimeOffsetInput(): string | undefined;
        private _datasetFormat;
        get datasetFormat(): DatasetFormatPropertyOutputReference;
        putDatasetFormat(value: DatasetFormatProperty): void;
        get datasetFormatInput(): DatasetFormatProperty | undefined;
    }
    interface EndpointInputProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#end_time_offset TfMonitoringSchedule#end_time_offset}
        */
        readonly endTimeOffset?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#endpoint_name TfMonitoringSchedule#endpoint_name}
        */
        readonly endpointName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#exclude_features_attribute TfMonitoringSchedule#exclude_features_attribute}
        */
        readonly excludeFeaturesAttribute?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#features_attribute TfMonitoringSchedule#features_attribute}
        */
        readonly featuresAttribute?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#inference_attribute TfMonitoringSchedule#inference_attribute}
        */
        readonly inferenceAttribute?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#local_path TfMonitoringSchedule#local_path}
        */
        readonly localPath: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#probability_attribute TfMonitoringSchedule#probability_attribute}
        */
        readonly probabilityAttribute?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#probability_threshold_attribute TfMonitoringSchedule#probability_threshold_attribute}
        */
        readonly probabilityThresholdAttribute?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#s3_data_distribution_type TfMonitoringSchedule#s3_data_distribution_type}
        */
        readonly s3DataDistributionType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#s3_input_mode TfMonitoringSchedule#s3_input_mode}
        */
        readonly s3InputMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#start_time_offset TfMonitoringSchedule#start_time_offset}
        */
        readonly startTimeOffset?: string;
    }
    class EndpointInputPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EndpointInputProperty | undefined;
        set internalValue(value: EndpointInputProperty | undefined);
        private _endTimeOffset?;
        get endTimeOffset(): string;
        set endTimeOffset(value: string);
        resetEndTimeOffset(): void;
        get endTimeOffsetInput(): string | undefined;
        private _endpointName?;
        get endpointName(): string;
        set endpointName(value: string);
        get endpointNameInput(): string | undefined;
        private _excludeFeaturesAttribute?;
        get excludeFeaturesAttribute(): string;
        set excludeFeaturesAttribute(value: string);
        resetExcludeFeaturesAttribute(): void;
        get excludeFeaturesAttributeInput(): string | undefined;
        private _featuresAttribute?;
        get featuresAttribute(): string;
        set featuresAttribute(value: string);
        resetFeaturesAttribute(): void;
        get featuresAttributeInput(): string | undefined;
        private _inferenceAttribute?;
        get inferenceAttribute(): string;
        set inferenceAttribute(value: string);
        resetInferenceAttribute(): void;
        get inferenceAttributeInput(): string | undefined;
        private _localPath?;
        get localPath(): string;
        set localPath(value: string);
        get localPathInput(): string | undefined;
        private _probabilityAttribute?;
        get probabilityAttribute(): string;
        set probabilityAttribute(value: string);
        resetProbabilityAttribute(): void;
        get probabilityAttributeInput(): string | undefined;
        private _probabilityThresholdAttribute?;
        get probabilityThresholdAttribute(): number;
        set probabilityThresholdAttribute(value: number);
        resetProbabilityThresholdAttribute(): void;
        get probabilityThresholdAttributeInput(): number | undefined;
        private _s3DataDistributionType?;
        get s3DataDistributionType(): string;
        set s3DataDistributionType(value: string);
        resetS3DataDistributionType(): void;
        get s3DataDistributionTypeInput(): string | undefined;
        private _s3InputMode?;
        get s3InputMode(): string;
        set s3InputMode(value: string);
        resetS3InputMode(): void;
        get s3InputModeInput(): string | undefined;
        private _startTimeOffset?;
        get startTimeOffset(): string;
        set startTimeOffset(value: string);
        resetStartTimeOffset(): void;
        get startTimeOffsetInput(): string | undefined;
    }
    interface MonitoringInputsProperty {
        /**
        * batch_transform_input block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#batch_transform_input TfMonitoringSchedule#batch_transform_input}
        */
        readonly batchTransformInput?: BatchTransformInputProperty;
        /**
        * endpoint_input block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#endpoint_input TfMonitoringSchedule#endpoint_input}
        */
        readonly endpointInput?: EndpointInputProperty;
    }
    class MonitoringInputsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MonitoringInputsProperty | undefined;
        set internalValue(value: MonitoringInputsProperty | undefined);
        private _batchTransformInput;
        get batchTransformInput(): BatchTransformInputPropertyOutputReference;
        putBatchTransformInput(value: BatchTransformInputProperty): void;
        resetBatchTransformInput(): void;
        get batchTransformInputInput(): BatchTransformInputProperty | undefined;
        private _endpointInput;
        get endpointInput(): EndpointInputPropertyOutputReference;
        putEndpointInput(value: EndpointInputProperty): void;
        resetEndpointInput(): void;
        get endpointInputInput(): EndpointInputProperty | undefined;
    }
    interface S3OutputProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#local_path TfMonitoringSchedule#local_path}
        */
        readonly localPath: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#s3_upload_mode TfMonitoringSchedule#s3_upload_mode}
        */
        readonly s3UploadMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#s3_uri TfMonitoringSchedule#s3_uri}
        */
        readonly s3Uri: string;
    }
    class S3OutputPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3OutputProperty | undefined;
        set internalValue(value: S3OutputProperty | undefined);
        private _localPath?;
        get localPath(): string;
        set localPath(value: string);
        get localPathInput(): string | undefined;
        private _s3UploadMode?;
        get s3UploadMode(): string;
        set s3UploadMode(value: string);
        resetS3UploadMode(): void;
        get s3UploadModeInput(): string | undefined;
        private _s3Uri?;
        get s3Uri(): string;
        set s3Uri(value: string);
        get s3UriInput(): string | undefined;
    }
    interface MonitoringOutputsProperty {
        /**
        * s3_output block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#s3_output TfMonitoringSchedule#s3_output}
        */
        readonly s3Output: S3OutputProperty;
    }
    class MonitoringOutputsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MonitoringOutputsProperty | undefined;
        set internalValue(value: MonitoringOutputsProperty | undefined);
        private _s3Output;
        get s3Output(): S3OutputPropertyOutputReference;
        putS3Output(value: S3OutputProperty): void;
        get s3OutputInput(): S3OutputProperty | undefined;
    }
    interface MonitoringOutputConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#kms_key_id TfMonitoringSchedule#kms_key_id}
        */
        readonly kmsKeyId?: string;
        /**
        * monitoring_outputs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#monitoring_outputs TfMonitoringSchedule#monitoring_outputs}
        */
        readonly monitoringOutputs: MonitoringOutputsProperty;
    }
    class MonitoringOutputConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MonitoringOutputConfigProperty | undefined;
        set internalValue(value: MonitoringOutputConfigProperty | undefined);
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        resetKmsKeyId(): void;
        get kmsKeyIdInput(): string | undefined;
        private _monitoringOutputs;
        get monitoringOutputs(): MonitoringOutputsPropertyOutputReference;
        putMonitoringOutputs(value: MonitoringOutputsProperty): void;
        get monitoringOutputsInput(): MonitoringOutputsProperty | undefined;
    }
    interface ClusterConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#instance_count TfMonitoringSchedule#instance_count}
        */
        readonly instanceCount: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#instance_type TfMonitoringSchedule#instance_type}
        */
        readonly instanceType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#volume_kms_key_id TfMonitoringSchedule#volume_kms_key_id}
        */
        readonly volumeKmsKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#volume_size_in_gb TfMonitoringSchedule#volume_size_in_gb}
        */
        readonly volumeSizeInGb: number;
    }
    class ClusterConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ClusterConfigProperty | undefined;
        set internalValue(value: ClusterConfigProperty | undefined);
        private _instanceCount?;
        get instanceCount(): number;
        set instanceCount(value: number);
        get instanceCountInput(): number | undefined;
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        get instanceTypeInput(): string | undefined;
        private _volumeKmsKeyId?;
        get volumeKmsKeyId(): string;
        set volumeKmsKeyId(value: string);
        resetVolumeKmsKeyId(): void;
        get volumeKmsKeyIdInput(): string | undefined;
        private _volumeSizeInGb?;
        get volumeSizeInGb(): number;
        set volumeSizeInGb(value: number);
        get volumeSizeInGbInput(): number | undefined;
    }
    interface MonitoringResourcesProperty {
        /**
        * cluster_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#cluster_config TfMonitoringSchedule#cluster_config}
        */
        readonly clusterConfig: ClusterConfigProperty;
    }
    class MonitoringResourcesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MonitoringResourcesProperty | undefined;
        set internalValue(value: MonitoringResourcesProperty | undefined);
        private _clusterConfig;
        get clusterConfig(): ClusterConfigPropertyOutputReference;
        putClusterConfig(value: ClusterConfigProperty): void;
        get clusterConfigInput(): ClusterConfigProperty | undefined;
    }
    interface VpcConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#security_group_ids TfMonitoringSchedule#security_group_ids}
        */
        readonly securityGroupIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#subnets TfMonitoringSchedule#subnets}
        */
        readonly subnets: string[];
    }
    class VpcConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VpcConfigProperty | undefined;
        set internalValue(value: VpcConfigProperty | undefined);
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        get securityGroupIdsInput(): string[] | undefined;
        private _subnets?;
        get subnets(): string[];
        set subnets(value: string[]);
        get subnetsInput(): string[] | undefined;
    }
    interface NetworkConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#enable_inter_container_traffic_encryption TfMonitoringSchedule#enable_inter_container_traffic_encryption}
        */
        readonly enableInterContainerTrafficEncryption?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#enable_network_isolation TfMonitoringSchedule#enable_network_isolation}
        */
        readonly enableNetworkIsolation?: boolean | cdktn.IResolvable;
        /**
        * vpc_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#vpc_config TfMonitoringSchedule#vpc_config}
        */
        readonly vpcConfig?: VpcConfigProperty;
    }
    class NetworkConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NetworkConfigProperty | undefined;
        set internalValue(value: NetworkConfigProperty | undefined);
        private _enableInterContainerTrafficEncryption?;
        get enableInterContainerTrafficEncryption(): boolean | cdktn.IResolvable;
        set enableInterContainerTrafficEncryption(value: boolean | cdktn.IResolvable);
        resetEnableInterContainerTrafficEncryption(): void;
        get enableInterContainerTrafficEncryptionInput(): boolean | cdktn.IResolvable | undefined;
        private _enableNetworkIsolation?;
        get enableNetworkIsolation(): boolean | cdktn.IResolvable;
        set enableNetworkIsolation(value: boolean | cdktn.IResolvable);
        resetEnableNetworkIsolation(): void;
        get enableNetworkIsolationInput(): boolean | cdktn.IResolvable | undefined;
        private _vpcConfig;
        get vpcConfig(): VpcConfigPropertyOutputReference;
        putVpcConfig(value: VpcConfigProperty): void;
        resetVpcConfig(): void;
        get vpcConfigInput(): VpcConfigProperty | undefined;
    }
    interface StoppingConditionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#max_runtime_in_seconds TfMonitoringSchedule#max_runtime_in_seconds}
        */
        readonly maxRuntimeInSeconds?: number;
    }
    class StoppingConditionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StoppingConditionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StoppingConditionProperty | cdktn.IResolvable | undefined);
        private _maxRuntimeInSeconds?;
        get maxRuntimeInSeconds(): number;
        set maxRuntimeInSeconds(value: number);
        resetMaxRuntimeInSeconds(): void;
        get maxRuntimeInSecondsInput(): number | undefined;
    }
    class StoppingConditionPropertyList extends cdktn.ComplexList {
        internalValue?: StoppingConditionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StoppingConditionPropertyOutputReference;
    }
    interface MonitoringJobDefinitionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#environment TfMonitoringSchedule#environment}
        */
        readonly environment?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#role_arn TfMonitoringSchedule#role_arn}
        */
        readonly roleArn: string;
        /**
        * baseline block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#baseline TfMonitoringSchedule#baseline}
        */
        readonly baseline?: BaselineProperty;
        /**
        * monitoring_app_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#monitoring_app_specification TfMonitoringSchedule#monitoring_app_specification}
        */
        readonly monitoringAppSpecification: MonitoringAppSpecificationProperty;
        /**
        * monitoring_inputs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#monitoring_inputs TfMonitoringSchedule#monitoring_inputs}
        */
        readonly monitoringInputs: MonitoringInputsProperty;
        /**
        * monitoring_output_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#monitoring_output_config TfMonitoringSchedule#monitoring_output_config}
        */
        readonly monitoringOutputConfig: MonitoringOutputConfigProperty;
        /**
        * monitoring_resources block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#monitoring_resources TfMonitoringSchedule#monitoring_resources}
        */
        readonly monitoringResources: MonitoringResourcesProperty;
        /**
        * network_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#network_config TfMonitoringSchedule#network_config}
        */
        readonly networkConfig?: NetworkConfigProperty;
        /**
        * stopping_condition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#stopping_condition TfMonitoringSchedule#stopping_condition}
        */
        readonly stoppingCondition?: StoppingConditionProperty[] | cdktn.IResolvable;
    }
    class MonitoringJobDefinitionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MonitoringJobDefinitionProperty | undefined;
        set internalValue(value: MonitoringJobDefinitionProperty | undefined);
        private _environment?;
        get environment(): {
            [key: string]: string;
        };
        set environment(value: {
            [key: string]: string;
        });
        resetEnvironment(): void;
        get environmentInput(): {
            [key: string]: string;
        } | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _baseline;
        get baseline(): BaselinePropertyOutputReference;
        putBaseline(value: BaselineProperty): void;
        resetBaseline(): void;
        get baselineInput(): BaselineProperty | undefined;
        private _monitoringAppSpecification;
        get monitoringAppSpecification(): MonitoringAppSpecificationPropertyOutputReference;
        putMonitoringAppSpecification(value: MonitoringAppSpecificationProperty): void;
        get monitoringAppSpecificationInput(): MonitoringAppSpecificationProperty | undefined;
        private _monitoringInputs;
        get monitoringInputs(): MonitoringInputsPropertyOutputReference;
        putMonitoringInputs(value: MonitoringInputsProperty): void;
        get monitoringInputsInput(): MonitoringInputsProperty | undefined;
        private _monitoringOutputConfig;
        get monitoringOutputConfig(): MonitoringOutputConfigPropertyOutputReference;
        putMonitoringOutputConfig(value: MonitoringOutputConfigProperty): void;
        get monitoringOutputConfigInput(): MonitoringOutputConfigProperty | undefined;
        private _monitoringResources;
        get monitoringResources(): MonitoringResourcesPropertyOutputReference;
        putMonitoringResources(value: MonitoringResourcesProperty): void;
        get monitoringResourcesInput(): MonitoringResourcesProperty | undefined;
        private _networkConfig;
        get networkConfig(): NetworkConfigPropertyOutputReference;
        putNetworkConfig(value: NetworkConfigProperty): void;
        resetNetworkConfig(): void;
        get networkConfigInput(): NetworkConfigProperty | undefined;
        private _stoppingCondition;
        get stoppingCondition(): StoppingConditionPropertyList;
        putStoppingCondition(value: StoppingConditionProperty[] | cdktn.IResolvable): void;
        resetStoppingCondition(): void;
        get stoppingConditionInput(): cdktn.IResolvable | StoppingConditionProperty[] | undefined;
    }
    interface ScheduleConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#schedule_expression TfMonitoringSchedule#schedule_expression}
        */
        readonly scheduleExpression: string;
    }
    class ScheduleConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ScheduleConfigProperty | undefined;
        set internalValue(value: ScheduleConfigProperty | undefined);
        private _scheduleExpression?;
        get scheduleExpression(): string;
        set scheduleExpression(value: string);
        get scheduleExpressionInput(): string | undefined;
    }
    interface MonitoringScheduleConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#monitoring_job_definition_name TfMonitoringSchedule#monitoring_job_definition_name}
        */
        readonly monitoringJobDefinitionName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#monitoring_type TfMonitoringSchedule#monitoring_type}
        */
        readonly monitoringType: string;
        /**
        * monitoring_job_definition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#monitoring_job_definition TfMonitoringSchedule#monitoring_job_definition}
        */
        readonly monitoringJobDefinition?: MonitoringJobDefinitionProperty;
        /**
        * schedule_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_monitoring_schedule#schedule_config TfMonitoringSchedule#schedule_config}
        */
        readonly scheduleConfig?: ScheduleConfigProperty;
    }
    class MonitoringScheduleConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MonitoringScheduleConfigProperty | undefined;
        set internalValue(value: MonitoringScheduleConfigProperty | undefined);
        private _monitoringJobDefinitionName?;
        get monitoringJobDefinitionName(): string;
        set monitoringJobDefinitionName(value: string);
        resetMonitoringJobDefinitionName(): void;
        get monitoringJobDefinitionNameInput(): string | undefined;
        private _monitoringType?;
        get monitoringType(): string;
        set monitoringType(value: string);
        get monitoringTypeInput(): string | undefined;
        private _monitoringJobDefinition;
        get monitoringJobDefinition(): MonitoringJobDefinitionPropertyOutputReference;
        putMonitoringJobDefinition(value: MonitoringJobDefinitionProperty): void;
        resetMonitoringJobDefinition(): void;
        get monitoringJobDefinitionInput(): MonitoringJobDefinitionProperty | undefined;
        private _scheduleConfig;
        get scheduleConfig(): ScheduleConfigPropertyOutputReference;
        putScheduleConfig(value: ScheduleConfigProperty): void;
        resetScheduleConfig(): void;
        get scheduleConfigInput(): ScheduleConfigProperty | undefined;
    }
}
