import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfCodeRepositoryConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_code_repository#code_repository_name TfCodeRepository#code_repository_name}
    */
    readonly codeRepositoryName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_code_repository#id TfCodeRepository#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_code_repository#region TfCodeRepository#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_code_repository#tags TfCodeRepository#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_code_repository#tags_all TfCodeRepository#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * git_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_code_repository#git_config TfCodeRepository#git_config}
    */
    readonly gitConfig: TfCodeRepository.GitConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_code_repository aws_sagemaker_code_repository}
*/
export declare class TfCodeRepository extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_sagemaker_code_repository";
    /**
    * Generates CDKTN code for importing a TfCodeRepository resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfCodeRepository to import
    * @param importFromId The id of the existing TfCodeRepository that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_code_repository#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfCodeRepository to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_code_repository aws_sagemaker_code_repository} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfCodeRepositoryConfig
    */
    constructor(scope: Construct, id: string, config: TfCodeRepositoryConfig);
    get arn(): string;
    private _codeRepositoryName?;
    get codeRepositoryName(): string;
    set codeRepositoryName(value: string);
    get codeRepositoryNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _gitConfig;
    get gitConfig(): TfCodeRepository.GitConfigPropertyOutputReference;
    putGitConfig(value: TfCodeRepository.GitConfigProperty): void;
    get gitConfigInput(): TfCodeRepository.GitConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfCodeRepositoryGitConfigPropertyToTerraform(struct?: TfCodeRepository.GitConfigPropertyOutputReference | TfCodeRepository.GitConfigProperty): any;
export declare function tfCodeRepositoryGitConfigPropertyToHclTerraform(struct?: TfCodeRepository.GitConfigPropertyOutputReference | TfCodeRepository.GitConfigProperty): any;
export declare namespace TfCodeRepository {
    interface GitConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_code_repository#branch TfCodeRepository#branch}
        */
        readonly branch?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_code_repository#repository_url TfCodeRepository#repository_url}
        */
        readonly repositoryUrl: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_code_repository#secret_arn TfCodeRepository#secret_arn}
        */
        readonly secretArn?: string;
    }
    class GitConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): GitConfigProperty | undefined;
        set internalValue(value: GitConfigProperty | undefined);
        private _branch?;
        get branch(): string;
        set branch(value: string);
        resetBranch(): void;
        get branchInput(): string | undefined;
        private _repositoryUrl?;
        get repositoryUrl(): string;
        set repositoryUrl(value: string);
        get repositoryUrlInput(): string | undefined;
        private _secretArn?;
        get secretArn(): string;
        set secretArn(value: string);
        resetSecretArn(): void;
        get secretArnInput(): string | undefined;
    }
}
