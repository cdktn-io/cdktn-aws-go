import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfEndpointConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#execution_role_arn TfEndpointConfiguration#execution_role_arn}
    */
    readonly executionRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#id TfEndpointConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#kms_key_arn TfEndpointConfiguration#kms_key_arn}
    */
    readonly kmsKeyArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#name TfEndpointConfiguration#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#name_prefix TfEndpointConfiguration#name_prefix}
    */
    readonly namePrefix?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#region TfEndpointConfiguration#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#tags TfEndpointConfiguration#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#tags_all TfEndpointConfiguration#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * async_inference_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#async_inference_config TfEndpointConfiguration#async_inference_config}
    */
    readonly asyncInferenceConfig?: TfEndpointConfiguration.AsyncInferenceConfigProperty;
    /**
    * data_capture_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#data_capture_config TfEndpointConfiguration#data_capture_config}
    */
    readonly dataCaptureConfig?: TfEndpointConfiguration.DataCaptureConfigProperty;
    /**
    * production_variants block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#production_variants TfEndpointConfiguration#production_variants}
    */
    readonly productionVariants: TfEndpointConfiguration.ProductionVariantsProperty[] | cdktn.IResolvable;
    /**
    * shadow_production_variants block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#shadow_production_variants TfEndpointConfiguration#shadow_production_variants}
    */
    readonly shadowProductionVariants?: TfEndpointConfiguration.ShadowProductionVariantsProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration aws_sagemaker_endpoint_configuration}
*/
export declare class TfEndpointConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_sagemaker_endpoint_configuration";
    /**
    * Generates CDKTN code for importing a TfEndpointConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfEndpointConfiguration to import
    * @param importFromId The id of the existing TfEndpointConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfEndpointConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration aws_sagemaker_endpoint_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfEndpointConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: TfEndpointConfigurationConfig);
    get arn(): string;
    private _executionRoleArn?;
    get executionRoleArn(): string;
    set executionRoleArn(value: string);
    resetExecutionRoleArn(): void;
    get executionRoleArnInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _kmsKeyArn?;
    get kmsKeyArn(): string;
    set kmsKeyArn(value: string);
    resetKmsKeyArn(): void;
    get kmsKeyArnInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namePrefix?;
    get namePrefix(): string;
    set namePrefix(value: string);
    resetNamePrefix(): void;
    get namePrefixInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _asyncInferenceConfig;
    get asyncInferenceConfig(): TfEndpointConfiguration.AsyncInferenceConfigPropertyOutputReference;
    putAsyncInferenceConfig(value: TfEndpointConfiguration.AsyncInferenceConfigProperty): void;
    resetAsyncInferenceConfig(): void;
    get asyncInferenceConfigInput(): TfEndpointConfiguration.AsyncInferenceConfigProperty | undefined;
    private _dataCaptureConfig;
    get dataCaptureConfig(): TfEndpointConfiguration.DataCaptureConfigPropertyOutputReference;
    putDataCaptureConfig(value: TfEndpointConfiguration.DataCaptureConfigProperty): void;
    resetDataCaptureConfig(): void;
    get dataCaptureConfigInput(): TfEndpointConfiguration.DataCaptureConfigProperty | undefined;
    private _productionVariants;
    get productionVariants(): TfEndpointConfiguration.ProductionVariantsPropertyList;
    putProductionVariants(value: TfEndpointConfiguration.ProductionVariantsProperty[] | cdktn.IResolvable): void;
    get productionVariantsInput(): cdktn.IResolvable | TfEndpointConfiguration.ProductionVariantsProperty[] | undefined;
    private _shadowProductionVariants;
    get shadowProductionVariants(): TfEndpointConfiguration.ShadowProductionVariantsPropertyList;
    putShadowProductionVariants(value: TfEndpointConfiguration.ShadowProductionVariantsProperty[] | cdktn.IResolvable): void;
    resetShadowProductionVariants(): void;
    get shadowProductionVariantsInput(): cdktn.IResolvable | TfEndpointConfiguration.ShadowProductionVariantsProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfEndpointConfigurationClientConfigPropertyToTerraform(struct?: TfEndpointConfiguration.ClientConfigPropertyOutputReference | TfEndpointConfiguration.ClientConfigProperty): any;
export declare function tfEndpointConfigurationClientConfigPropertyToHclTerraform(struct?: TfEndpointConfiguration.ClientConfigPropertyOutputReference | TfEndpointConfiguration.ClientConfigProperty): any;
export declare function tfEndpointConfigurationNotificationConfigPropertyToTerraform(struct?: TfEndpointConfiguration.NotificationConfigPropertyOutputReference | TfEndpointConfiguration.NotificationConfigProperty): any;
export declare function tfEndpointConfigurationNotificationConfigPropertyToHclTerraform(struct?: TfEndpointConfiguration.NotificationConfigPropertyOutputReference | TfEndpointConfiguration.NotificationConfigProperty): any;
export declare function tfEndpointConfigurationOutputConfigPropertyToTerraform(struct?: TfEndpointConfiguration.OutputConfigPropertyOutputReference | TfEndpointConfiguration.OutputConfigProperty): any;
export declare function tfEndpointConfigurationOutputConfigPropertyToHclTerraform(struct?: TfEndpointConfiguration.OutputConfigPropertyOutputReference | TfEndpointConfiguration.OutputConfigProperty): any;
export declare function tfEndpointConfigurationAsyncInferenceConfigPropertyToTerraform(struct?: TfEndpointConfiguration.AsyncInferenceConfigPropertyOutputReference | TfEndpointConfiguration.AsyncInferenceConfigProperty): any;
export declare function tfEndpointConfigurationAsyncInferenceConfigPropertyToHclTerraform(struct?: TfEndpointConfiguration.AsyncInferenceConfigPropertyOutputReference | TfEndpointConfiguration.AsyncInferenceConfigProperty): any;
export declare function tfEndpointConfigurationCaptureContentTypeHeaderPropertyToTerraform(struct?: TfEndpointConfiguration.CaptureContentTypeHeaderPropertyOutputReference | TfEndpointConfiguration.CaptureContentTypeHeaderProperty): any;
export declare function tfEndpointConfigurationCaptureContentTypeHeaderPropertyToHclTerraform(struct?: TfEndpointConfiguration.CaptureContentTypeHeaderPropertyOutputReference | TfEndpointConfiguration.CaptureContentTypeHeaderProperty): any;
export declare function tfEndpointConfigurationCaptureOptionsPropertyToTerraform(struct?: TfEndpointConfiguration.CaptureOptionsProperty | cdktn.IResolvable): any;
export declare function tfEndpointConfigurationCaptureOptionsPropertyToHclTerraform(struct?: TfEndpointConfiguration.CaptureOptionsProperty | cdktn.IResolvable): any;
export declare function tfEndpointConfigurationDataCaptureConfigPropertyToTerraform(struct?: TfEndpointConfiguration.DataCaptureConfigPropertyOutputReference | TfEndpointConfiguration.DataCaptureConfigProperty): any;
export declare function tfEndpointConfigurationDataCaptureConfigPropertyToHclTerraform(struct?: TfEndpointConfiguration.DataCaptureConfigPropertyOutputReference | TfEndpointConfiguration.DataCaptureConfigProperty): any;
export declare function tfEndpointConfigurationProductionVariantsCapacityReservationConfigPropertyToTerraform(struct?: TfEndpointConfiguration.ProductionVariantsCapacityReservationConfigPropertyOutputReference | TfEndpointConfiguration.ProductionVariantsCapacityReservationConfigProperty): any;
export declare function tfEndpointConfigurationProductionVariantsCapacityReservationConfigPropertyToHclTerraform(struct?: TfEndpointConfiguration.ProductionVariantsCapacityReservationConfigPropertyOutputReference | TfEndpointConfiguration.ProductionVariantsCapacityReservationConfigProperty): any;
export declare function tfEndpointConfigurationProductionVariantsCoreDumpConfigPropertyToTerraform(struct?: TfEndpointConfiguration.ProductionVariantsCoreDumpConfigPropertyOutputReference | TfEndpointConfiguration.ProductionVariantsCoreDumpConfigProperty): any;
export declare function tfEndpointConfigurationProductionVariantsCoreDumpConfigPropertyToHclTerraform(struct?: TfEndpointConfiguration.ProductionVariantsCoreDumpConfigPropertyOutputReference | TfEndpointConfiguration.ProductionVariantsCoreDumpConfigProperty): any;
export declare function tfEndpointConfigurationProductionVariantsManagedInstanceScalingPropertyToTerraform(struct?: TfEndpointConfiguration.ProductionVariantsManagedInstanceScalingPropertyOutputReference | TfEndpointConfiguration.ProductionVariantsManagedInstanceScalingProperty): any;
export declare function tfEndpointConfigurationProductionVariantsManagedInstanceScalingPropertyToHclTerraform(struct?: TfEndpointConfiguration.ProductionVariantsManagedInstanceScalingPropertyOutputReference | TfEndpointConfiguration.ProductionVariantsManagedInstanceScalingProperty): any;
export declare function tfEndpointConfigurationProductionVariantsRoutingConfigPropertyToTerraform(struct?: TfEndpointConfiguration.ProductionVariantsRoutingConfigProperty | cdktn.IResolvable): any;
export declare function tfEndpointConfigurationProductionVariantsRoutingConfigPropertyToHclTerraform(struct?: TfEndpointConfiguration.ProductionVariantsRoutingConfigProperty | cdktn.IResolvable): any;
export declare function tfEndpointConfigurationProductionVariantsServerlessConfigPropertyToTerraform(struct?: TfEndpointConfiguration.ProductionVariantsServerlessConfigPropertyOutputReference | TfEndpointConfiguration.ProductionVariantsServerlessConfigProperty): any;
export declare function tfEndpointConfigurationProductionVariantsServerlessConfigPropertyToHclTerraform(struct?: TfEndpointConfiguration.ProductionVariantsServerlessConfigPropertyOutputReference | TfEndpointConfiguration.ProductionVariantsServerlessConfigProperty): any;
export declare function tfEndpointConfigurationProductionVariantsPropertyToTerraform(struct?: TfEndpointConfiguration.ProductionVariantsProperty | cdktn.IResolvable): any;
export declare function tfEndpointConfigurationProductionVariantsPropertyToHclTerraform(struct?: TfEndpointConfiguration.ProductionVariantsProperty | cdktn.IResolvable): any;
export declare function tfEndpointConfigurationShadowProductionVariantsCapacityReservationConfigPropertyToTerraform(struct?: TfEndpointConfiguration.ShadowProductionVariantsCapacityReservationConfigPropertyOutputReference | TfEndpointConfiguration.ShadowProductionVariantsCapacityReservationConfigProperty): any;
export declare function tfEndpointConfigurationShadowProductionVariantsCapacityReservationConfigPropertyToHclTerraform(struct?: TfEndpointConfiguration.ShadowProductionVariantsCapacityReservationConfigPropertyOutputReference | TfEndpointConfiguration.ShadowProductionVariantsCapacityReservationConfigProperty): any;
export declare function tfEndpointConfigurationShadowProductionVariantsCoreDumpConfigPropertyToTerraform(struct?: TfEndpointConfiguration.ShadowProductionVariantsCoreDumpConfigPropertyOutputReference | TfEndpointConfiguration.ShadowProductionVariantsCoreDumpConfigProperty): any;
export declare function tfEndpointConfigurationShadowProductionVariantsCoreDumpConfigPropertyToHclTerraform(struct?: TfEndpointConfiguration.ShadowProductionVariantsCoreDumpConfigPropertyOutputReference | TfEndpointConfiguration.ShadowProductionVariantsCoreDumpConfigProperty): any;
export declare function tfEndpointConfigurationShadowProductionVariantsManagedInstanceScalingPropertyToTerraform(struct?: TfEndpointConfiguration.ShadowProductionVariantsManagedInstanceScalingPropertyOutputReference | TfEndpointConfiguration.ShadowProductionVariantsManagedInstanceScalingProperty): any;
export declare function tfEndpointConfigurationShadowProductionVariantsManagedInstanceScalingPropertyToHclTerraform(struct?: TfEndpointConfiguration.ShadowProductionVariantsManagedInstanceScalingPropertyOutputReference | TfEndpointConfiguration.ShadowProductionVariantsManagedInstanceScalingProperty): any;
export declare function tfEndpointConfigurationShadowProductionVariantsRoutingConfigPropertyToTerraform(struct?: TfEndpointConfiguration.ShadowProductionVariantsRoutingConfigProperty | cdktn.IResolvable): any;
export declare function tfEndpointConfigurationShadowProductionVariantsRoutingConfigPropertyToHclTerraform(struct?: TfEndpointConfiguration.ShadowProductionVariantsRoutingConfigProperty | cdktn.IResolvable): any;
export declare function tfEndpointConfigurationShadowProductionVariantsServerlessConfigPropertyToTerraform(struct?: TfEndpointConfiguration.ShadowProductionVariantsServerlessConfigPropertyOutputReference | TfEndpointConfiguration.ShadowProductionVariantsServerlessConfigProperty): any;
export declare function tfEndpointConfigurationShadowProductionVariantsServerlessConfigPropertyToHclTerraform(struct?: TfEndpointConfiguration.ShadowProductionVariantsServerlessConfigPropertyOutputReference | TfEndpointConfiguration.ShadowProductionVariantsServerlessConfigProperty): any;
export declare function tfEndpointConfigurationShadowProductionVariantsPropertyToTerraform(struct?: TfEndpointConfiguration.ShadowProductionVariantsProperty | cdktn.IResolvable): any;
export declare function tfEndpointConfigurationShadowProductionVariantsPropertyToHclTerraform(struct?: TfEndpointConfiguration.ShadowProductionVariantsProperty | cdktn.IResolvable): any;
export declare namespace TfEndpointConfiguration {
    interface ClientConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#max_concurrent_invocations_per_instance TfEndpointConfiguration#max_concurrent_invocations_per_instance}
        */
        readonly maxConcurrentInvocationsPerInstance?: number;
    }
    class ClientConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ClientConfigProperty | undefined;
        set internalValue(value: ClientConfigProperty | undefined);
        private _maxConcurrentInvocationsPerInstance?;
        get maxConcurrentInvocationsPerInstance(): number;
        set maxConcurrentInvocationsPerInstance(value: number);
        resetMaxConcurrentInvocationsPerInstance(): void;
        get maxConcurrentInvocationsPerInstanceInput(): number | undefined;
    }
    interface NotificationConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#error_topic TfEndpointConfiguration#error_topic}
        */
        readonly errorTopic?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#include_inference_response_in TfEndpointConfiguration#include_inference_response_in}
        */
        readonly includeInferenceResponseIn?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#success_topic TfEndpointConfiguration#success_topic}
        */
        readonly successTopic?: string;
    }
    class NotificationConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NotificationConfigProperty | undefined;
        set internalValue(value: NotificationConfigProperty | undefined);
        private _errorTopic?;
        get errorTopic(): string;
        set errorTopic(value: string);
        resetErrorTopic(): void;
        get errorTopicInput(): string | undefined;
        private _includeInferenceResponseIn?;
        get includeInferenceResponseIn(): string[];
        set includeInferenceResponseIn(value: string[]);
        resetIncludeInferenceResponseIn(): void;
        get includeInferenceResponseInInput(): string[] | undefined;
        private _successTopic?;
        get successTopic(): string;
        set successTopic(value: string);
        resetSuccessTopic(): void;
        get successTopicInput(): string | undefined;
    }
    interface OutputConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#kms_key_id TfEndpointConfiguration#kms_key_id}
        */
        readonly kmsKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#s3_failure_path TfEndpointConfiguration#s3_failure_path}
        */
        readonly s3FailurePath?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#s3_output_path TfEndpointConfiguration#s3_output_path}
        */
        readonly s3OutputPath: string;
        /**
        * notification_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#notification_config TfEndpointConfiguration#notification_config}
        */
        readonly notificationConfig?: NotificationConfigProperty;
    }
    class OutputConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OutputConfigProperty | undefined;
        set internalValue(value: OutputConfigProperty | undefined);
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        resetKmsKeyId(): void;
        get kmsKeyIdInput(): string | undefined;
        private _s3FailurePath?;
        get s3FailurePath(): string;
        set s3FailurePath(value: string);
        resetS3FailurePath(): void;
        get s3FailurePathInput(): string | undefined;
        private _s3OutputPath?;
        get s3OutputPath(): string;
        set s3OutputPath(value: string);
        get s3OutputPathInput(): string | undefined;
        private _notificationConfig;
        get notificationConfig(): NotificationConfigPropertyOutputReference;
        putNotificationConfig(value: NotificationConfigProperty): void;
        resetNotificationConfig(): void;
        get notificationConfigInput(): NotificationConfigProperty | undefined;
    }
    interface AsyncInferenceConfigProperty {
        /**
        * client_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#client_config TfEndpointConfiguration#client_config}
        */
        readonly clientConfig?: ClientConfigProperty;
        /**
        * output_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#output_config TfEndpointConfiguration#output_config}
        */
        readonly outputConfig: OutputConfigProperty;
    }
    class AsyncInferenceConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AsyncInferenceConfigProperty | undefined;
        set internalValue(value: AsyncInferenceConfigProperty | undefined);
        private _clientConfig;
        get clientConfig(): ClientConfigPropertyOutputReference;
        putClientConfig(value: ClientConfigProperty): void;
        resetClientConfig(): void;
        get clientConfigInput(): ClientConfigProperty | undefined;
        private _outputConfig;
        get outputConfig(): OutputConfigPropertyOutputReference;
        putOutputConfig(value: OutputConfigProperty): void;
        get outputConfigInput(): OutputConfigProperty | undefined;
    }
    interface CaptureContentTypeHeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#csv_content_types TfEndpointConfiguration#csv_content_types}
        */
        readonly csvContentTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#json_content_types TfEndpointConfiguration#json_content_types}
        */
        readonly jsonContentTypes?: string[];
    }
    class CaptureContentTypeHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CaptureContentTypeHeaderProperty | undefined;
        set internalValue(value: CaptureContentTypeHeaderProperty | undefined);
        private _csvContentTypes?;
        get csvContentTypes(): string[];
        set csvContentTypes(value: string[]);
        resetCsvContentTypes(): void;
        get csvContentTypesInput(): string[] | undefined;
        private _jsonContentTypes?;
        get jsonContentTypes(): string[];
        set jsonContentTypes(value: string[]);
        resetJsonContentTypes(): void;
        get jsonContentTypesInput(): string[] | undefined;
    }
    interface CaptureOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#capture_mode TfEndpointConfiguration#capture_mode}
        */
        readonly captureMode: string;
    }
    class CaptureOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CaptureOptionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CaptureOptionsProperty | cdktn.IResolvable | undefined);
        private _captureMode?;
        get captureMode(): string;
        set captureMode(value: string);
        get captureModeInput(): string | undefined;
    }
    class CaptureOptionsPropertyList extends cdktn.ComplexList {
        internalValue?: CaptureOptionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CaptureOptionsPropertyOutputReference;
    }
    interface DataCaptureConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#destination_s3_uri TfEndpointConfiguration#destination_s3_uri}
        */
        readonly destinationS3Uri: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#enable_capture TfEndpointConfiguration#enable_capture}
        */
        readonly enableCapture?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#initial_sampling_percentage TfEndpointConfiguration#initial_sampling_percentage}
        */
        readonly initialSamplingPercentage: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#kms_key_id TfEndpointConfiguration#kms_key_id}
        */
        readonly kmsKeyId?: string;
        /**
        * capture_content_type_header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#capture_content_type_header TfEndpointConfiguration#capture_content_type_header}
        */
        readonly captureContentTypeHeader?: CaptureContentTypeHeaderProperty;
        /**
        * capture_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#capture_options TfEndpointConfiguration#capture_options}
        */
        readonly captureOptions: CaptureOptionsProperty[] | cdktn.IResolvable;
    }
    class DataCaptureConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DataCaptureConfigProperty | undefined;
        set internalValue(value: DataCaptureConfigProperty | undefined);
        private _destinationS3Uri?;
        get destinationS3Uri(): string;
        set destinationS3Uri(value: string);
        get destinationS3UriInput(): string | undefined;
        private _enableCapture?;
        get enableCapture(): boolean | cdktn.IResolvable;
        set enableCapture(value: boolean | cdktn.IResolvable);
        resetEnableCapture(): void;
        get enableCaptureInput(): boolean | cdktn.IResolvable | undefined;
        private _initialSamplingPercentage?;
        get initialSamplingPercentage(): number;
        set initialSamplingPercentage(value: number);
        get initialSamplingPercentageInput(): number | undefined;
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        resetKmsKeyId(): void;
        get kmsKeyIdInput(): string | undefined;
        private _captureContentTypeHeader;
        get captureContentTypeHeader(): CaptureContentTypeHeaderPropertyOutputReference;
        putCaptureContentTypeHeader(value: CaptureContentTypeHeaderProperty): void;
        resetCaptureContentTypeHeader(): void;
        get captureContentTypeHeaderInput(): CaptureContentTypeHeaderProperty | undefined;
        private _captureOptions;
        get captureOptions(): CaptureOptionsPropertyList;
        putCaptureOptions(value: CaptureOptionsProperty[] | cdktn.IResolvable): void;
        get captureOptionsInput(): cdktn.IResolvable | CaptureOptionsProperty[] | undefined;
    }
    interface ProductionVariantsCapacityReservationConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#capacity_reservation_preference TfEndpointConfiguration#capacity_reservation_preference}
        */
        readonly capacityReservationPreference?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#ml_reservation_arn TfEndpointConfiguration#ml_reservation_arn}
        */
        readonly mlReservationArn?: string;
    }
    class ProductionVariantsCapacityReservationConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ProductionVariantsCapacityReservationConfigProperty | undefined;
        set internalValue(value: ProductionVariantsCapacityReservationConfigProperty | undefined);
        private _capacityReservationPreference?;
        get capacityReservationPreference(): string;
        set capacityReservationPreference(value: string);
        resetCapacityReservationPreference(): void;
        get capacityReservationPreferenceInput(): string | undefined;
        private _mlReservationArn?;
        get mlReservationArn(): string;
        set mlReservationArn(value: string);
        resetMlReservationArn(): void;
        get mlReservationArnInput(): string | undefined;
    }
    interface ProductionVariantsCoreDumpConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#destination_s3_uri TfEndpointConfiguration#destination_s3_uri}
        */
        readonly destinationS3Uri: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#kms_key_id TfEndpointConfiguration#kms_key_id}
        */
        readonly kmsKeyId?: string;
    }
    class ProductionVariantsCoreDumpConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ProductionVariantsCoreDumpConfigProperty | undefined;
        set internalValue(value: ProductionVariantsCoreDumpConfigProperty | undefined);
        private _destinationS3Uri?;
        get destinationS3Uri(): string;
        set destinationS3Uri(value: string);
        get destinationS3UriInput(): string | undefined;
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        resetKmsKeyId(): void;
        get kmsKeyIdInput(): string | undefined;
    }
    interface ProductionVariantsManagedInstanceScalingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#max_instance_count TfEndpointConfiguration#max_instance_count}
        */
        readonly maxInstanceCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#min_instance_count TfEndpointConfiguration#min_instance_count}
        */
        readonly minInstanceCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#status TfEndpointConfiguration#status}
        */
        readonly status?: string;
    }
    class ProductionVariantsManagedInstanceScalingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ProductionVariantsManagedInstanceScalingProperty | undefined;
        set internalValue(value: ProductionVariantsManagedInstanceScalingProperty | undefined);
        private _maxInstanceCount?;
        get maxInstanceCount(): number;
        set maxInstanceCount(value: number);
        resetMaxInstanceCount(): void;
        get maxInstanceCountInput(): number | undefined;
        private _minInstanceCount?;
        get minInstanceCount(): number;
        set minInstanceCount(value: number);
        resetMinInstanceCount(): void;
        get minInstanceCountInput(): number | undefined;
        private _status?;
        get status(): string;
        set status(value: string);
        resetStatus(): void;
        get statusInput(): string | undefined;
    }
    interface ProductionVariantsRoutingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#routing_strategy TfEndpointConfiguration#routing_strategy}
        */
        readonly routingStrategy: string;
    }
    class ProductionVariantsRoutingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ProductionVariantsRoutingConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ProductionVariantsRoutingConfigProperty | cdktn.IResolvable | undefined);
        private _routingStrategy?;
        get routingStrategy(): string;
        set routingStrategy(value: string);
        get routingStrategyInput(): string | undefined;
    }
    class ProductionVariantsRoutingConfigPropertyList extends cdktn.ComplexList {
        internalValue?: ProductionVariantsRoutingConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ProductionVariantsRoutingConfigPropertyOutputReference;
    }
    interface ProductionVariantsServerlessConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#max_concurrency TfEndpointConfiguration#max_concurrency}
        */
        readonly maxConcurrency: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#memory_size_in_mb TfEndpointConfiguration#memory_size_in_mb}
        */
        readonly memorySizeInMb: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#provisioned_concurrency TfEndpointConfiguration#provisioned_concurrency}
        */
        readonly provisionedConcurrency?: number;
    }
    class ProductionVariantsServerlessConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ProductionVariantsServerlessConfigProperty | undefined;
        set internalValue(value: ProductionVariantsServerlessConfigProperty | undefined);
        private _maxConcurrency?;
        get maxConcurrency(): number;
        set maxConcurrency(value: number);
        get maxConcurrencyInput(): number | undefined;
        private _memorySizeInMb?;
        get memorySizeInMb(): number;
        set memorySizeInMb(value: number);
        get memorySizeInMbInput(): number | undefined;
        private _provisionedConcurrency?;
        get provisionedConcurrency(): number;
        set provisionedConcurrency(value: number);
        resetProvisionedConcurrency(): void;
        get provisionedConcurrencyInput(): number | undefined;
    }
    interface ProductionVariantsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#accelerator_type TfEndpointConfiguration#accelerator_type}
        */
        readonly acceleratorType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#container_startup_health_check_timeout_in_seconds TfEndpointConfiguration#container_startup_health_check_timeout_in_seconds}
        */
        readonly containerStartupHealthCheckTimeoutInSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#enable_ssm_access TfEndpointConfiguration#enable_ssm_access}
        */
        readonly enableSsmAccess?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#inference_ami_version TfEndpointConfiguration#inference_ami_version}
        */
        readonly inferenceAmiVersion?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#initial_instance_count TfEndpointConfiguration#initial_instance_count}
        */
        readonly initialInstanceCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#initial_variant_weight TfEndpointConfiguration#initial_variant_weight}
        */
        readonly initialVariantWeight?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#instance_type TfEndpointConfiguration#instance_type}
        */
        readonly instanceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#model_data_download_timeout_in_seconds TfEndpointConfiguration#model_data_download_timeout_in_seconds}
        */
        readonly modelDataDownloadTimeoutInSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#model_name TfEndpointConfiguration#model_name}
        */
        readonly modelName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#variant_name TfEndpointConfiguration#variant_name}
        */
        readonly variantName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#volume_size_in_gb TfEndpointConfiguration#volume_size_in_gb}
        */
        readonly volumeSizeInGb?: number;
        /**
        * capacity_reservation_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#capacity_reservation_config TfEndpointConfiguration#capacity_reservation_config}
        */
        readonly capacityReservationConfig?: ProductionVariantsCapacityReservationConfigProperty;
        /**
        * core_dump_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#core_dump_config TfEndpointConfiguration#core_dump_config}
        */
        readonly coreDumpConfig?: ProductionVariantsCoreDumpConfigProperty;
        /**
        * managed_instance_scaling block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#managed_instance_scaling TfEndpointConfiguration#managed_instance_scaling}
        */
        readonly managedInstanceScaling?: ProductionVariantsManagedInstanceScalingProperty;
        /**
        * routing_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#routing_config TfEndpointConfiguration#routing_config}
        */
        readonly routingConfig?: ProductionVariantsRoutingConfigProperty[] | cdktn.IResolvable;
        /**
        * serverless_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#serverless_config TfEndpointConfiguration#serverless_config}
        */
        readonly serverlessConfig?: ProductionVariantsServerlessConfigProperty;
    }
    class ProductionVariantsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ProductionVariantsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ProductionVariantsProperty | cdktn.IResolvable | undefined);
        private _acceleratorType?;
        get acceleratorType(): string;
        set acceleratorType(value: string);
        resetAcceleratorType(): void;
        get acceleratorTypeInput(): string | undefined;
        private _containerStartupHealthCheckTimeoutInSeconds?;
        get containerStartupHealthCheckTimeoutInSeconds(): number;
        set containerStartupHealthCheckTimeoutInSeconds(value: number);
        resetContainerStartupHealthCheckTimeoutInSeconds(): void;
        get containerStartupHealthCheckTimeoutInSecondsInput(): number | undefined;
        private _enableSsmAccess?;
        get enableSsmAccess(): boolean | cdktn.IResolvable;
        set enableSsmAccess(value: boolean | cdktn.IResolvable);
        resetEnableSsmAccess(): void;
        get enableSsmAccessInput(): boolean | cdktn.IResolvable | undefined;
        private _inferenceAmiVersion?;
        get inferenceAmiVersion(): string;
        set inferenceAmiVersion(value: string);
        resetInferenceAmiVersion(): void;
        get inferenceAmiVersionInput(): string | undefined;
        private _initialInstanceCount?;
        get initialInstanceCount(): number;
        set initialInstanceCount(value: number);
        resetInitialInstanceCount(): void;
        get initialInstanceCountInput(): number | undefined;
        private _initialVariantWeight?;
        get initialVariantWeight(): number;
        set initialVariantWeight(value: number);
        resetInitialVariantWeight(): void;
        get initialVariantWeightInput(): number | undefined;
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        resetInstanceType(): void;
        get instanceTypeInput(): string | undefined;
        private _modelDataDownloadTimeoutInSeconds?;
        get modelDataDownloadTimeoutInSeconds(): number;
        set modelDataDownloadTimeoutInSeconds(value: number);
        resetModelDataDownloadTimeoutInSeconds(): void;
        get modelDataDownloadTimeoutInSecondsInput(): number | undefined;
        private _modelName?;
        get modelName(): string;
        set modelName(value: string);
        resetModelName(): void;
        get modelNameInput(): string | undefined;
        private _variantName?;
        get variantName(): string;
        set variantName(value: string);
        resetVariantName(): void;
        get variantNameInput(): string | undefined;
        private _volumeSizeInGb?;
        get volumeSizeInGb(): number;
        set volumeSizeInGb(value: number);
        resetVolumeSizeInGb(): void;
        get volumeSizeInGbInput(): number | undefined;
        private _capacityReservationConfig;
        get capacityReservationConfig(): ProductionVariantsCapacityReservationConfigPropertyOutputReference;
        putCapacityReservationConfig(value: ProductionVariantsCapacityReservationConfigProperty): void;
        resetCapacityReservationConfig(): void;
        get capacityReservationConfigInput(): ProductionVariantsCapacityReservationConfigProperty | undefined;
        private _coreDumpConfig;
        get coreDumpConfig(): ProductionVariantsCoreDumpConfigPropertyOutputReference;
        putCoreDumpConfig(value: ProductionVariantsCoreDumpConfigProperty): void;
        resetCoreDumpConfig(): void;
        get coreDumpConfigInput(): ProductionVariantsCoreDumpConfigProperty | undefined;
        private _managedInstanceScaling;
        get managedInstanceScaling(): ProductionVariantsManagedInstanceScalingPropertyOutputReference;
        putManagedInstanceScaling(value: ProductionVariantsManagedInstanceScalingProperty): void;
        resetManagedInstanceScaling(): void;
        get managedInstanceScalingInput(): ProductionVariantsManagedInstanceScalingProperty | undefined;
        private _routingConfig;
        get routingConfig(): ProductionVariantsRoutingConfigPropertyList;
        putRoutingConfig(value: ProductionVariantsRoutingConfigProperty[] | cdktn.IResolvable): void;
        resetRoutingConfig(): void;
        get routingConfigInput(): cdktn.IResolvable | ProductionVariantsRoutingConfigProperty[] | undefined;
        private _serverlessConfig;
        get serverlessConfig(): ProductionVariantsServerlessConfigPropertyOutputReference;
        putServerlessConfig(value: ProductionVariantsServerlessConfigProperty): void;
        resetServerlessConfig(): void;
        get serverlessConfigInput(): ProductionVariantsServerlessConfigProperty | undefined;
    }
    class ProductionVariantsPropertyList extends cdktn.ComplexList {
        internalValue?: ProductionVariantsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ProductionVariantsPropertyOutputReference;
    }
    interface ShadowProductionVariantsCapacityReservationConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#capacity_reservation_preference TfEndpointConfiguration#capacity_reservation_preference}
        */
        readonly capacityReservationPreference?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#ml_reservation_arn TfEndpointConfiguration#ml_reservation_arn}
        */
        readonly mlReservationArn?: string;
    }
    class ShadowProductionVariantsCapacityReservationConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ShadowProductionVariantsCapacityReservationConfigProperty | undefined;
        set internalValue(value: ShadowProductionVariantsCapacityReservationConfigProperty | undefined);
        private _capacityReservationPreference?;
        get capacityReservationPreference(): string;
        set capacityReservationPreference(value: string);
        resetCapacityReservationPreference(): void;
        get capacityReservationPreferenceInput(): string | undefined;
        private _mlReservationArn?;
        get mlReservationArn(): string;
        set mlReservationArn(value: string);
        resetMlReservationArn(): void;
        get mlReservationArnInput(): string | undefined;
    }
    interface ShadowProductionVariantsCoreDumpConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#destination_s3_uri TfEndpointConfiguration#destination_s3_uri}
        */
        readonly destinationS3Uri: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#kms_key_id TfEndpointConfiguration#kms_key_id}
        */
        readonly kmsKeyId: string;
    }
    class ShadowProductionVariantsCoreDumpConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ShadowProductionVariantsCoreDumpConfigProperty | undefined;
        set internalValue(value: ShadowProductionVariantsCoreDumpConfigProperty | undefined);
        private _destinationS3Uri?;
        get destinationS3Uri(): string;
        set destinationS3Uri(value: string);
        get destinationS3UriInput(): string | undefined;
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        get kmsKeyIdInput(): string | undefined;
    }
    interface ShadowProductionVariantsManagedInstanceScalingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#max_instance_count TfEndpointConfiguration#max_instance_count}
        */
        readonly maxInstanceCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#min_instance_count TfEndpointConfiguration#min_instance_count}
        */
        readonly minInstanceCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#status TfEndpointConfiguration#status}
        */
        readonly status?: string;
    }
    class ShadowProductionVariantsManagedInstanceScalingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ShadowProductionVariantsManagedInstanceScalingProperty | undefined;
        set internalValue(value: ShadowProductionVariantsManagedInstanceScalingProperty | undefined);
        private _maxInstanceCount?;
        get maxInstanceCount(): number;
        set maxInstanceCount(value: number);
        resetMaxInstanceCount(): void;
        get maxInstanceCountInput(): number | undefined;
        private _minInstanceCount?;
        get minInstanceCount(): number;
        set minInstanceCount(value: number);
        resetMinInstanceCount(): void;
        get minInstanceCountInput(): number | undefined;
        private _status?;
        get status(): string;
        set status(value: string);
        resetStatus(): void;
        get statusInput(): string | undefined;
    }
    interface ShadowProductionVariantsRoutingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#routing_strategy TfEndpointConfiguration#routing_strategy}
        */
        readonly routingStrategy: string;
    }
    class ShadowProductionVariantsRoutingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ShadowProductionVariantsRoutingConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ShadowProductionVariantsRoutingConfigProperty | cdktn.IResolvable | undefined);
        private _routingStrategy?;
        get routingStrategy(): string;
        set routingStrategy(value: string);
        get routingStrategyInput(): string | undefined;
    }
    class ShadowProductionVariantsRoutingConfigPropertyList extends cdktn.ComplexList {
        internalValue?: ShadowProductionVariantsRoutingConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ShadowProductionVariantsRoutingConfigPropertyOutputReference;
    }
    interface ShadowProductionVariantsServerlessConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#max_concurrency TfEndpointConfiguration#max_concurrency}
        */
        readonly maxConcurrency: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#memory_size_in_mb TfEndpointConfiguration#memory_size_in_mb}
        */
        readonly memorySizeInMb: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#provisioned_concurrency TfEndpointConfiguration#provisioned_concurrency}
        */
        readonly provisionedConcurrency?: number;
    }
    class ShadowProductionVariantsServerlessConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ShadowProductionVariantsServerlessConfigProperty | undefined;
        set internalValue(value: ShadowProductionVariantsServerlessConfigProperty | undefined);
        private _maxConcurrency?;
        get maxConcurrency(): number;
        set maxConcurrency(value: number);
        get maxConcurrencyInput(): number | undefined;
        private _memorySizeInMb?;
        get memorySizeInMb(): number;
        set memorySizeInMb(value: number);
        get memorySizeInMbInput(): number | undefined;
        private _provisionedConcurrency?;
        get provisionedConcurrency(): number;
        set provisionedConcurrency(value: number);
        resetProvisionedConcurrency(): void;
        get provisionedConcurrencyInput(): number | undefined;
    }
    interface ShadowProductionVariantsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#accelerator_type TfEndpointConfiguration#accelerator_type}
        */
        readonly acceleratorType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#container_startup_health_check_timeout_in_seconds TfEndpointConfiguration#container_startup_health_check_timeout_in_seconds}
        */
        readonly containerStartupHealthCheckTimeoutInSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#enable_ssm_access TfEndpointConfiguration#enable_ssm_access}
        */
        readonly enableSsmAccess?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#inference_ami_version TfEndpointConfiguration#inference_ami_version}
        */
        readonly inferenceAmiVersion?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#initial_instance_count TfEndpointConfiguration#initial_instance_count}
        */
        readonly initialInstanceCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#initial_variant_weight TfEndpointConfiguration#initial_variant_weight}
        */
        readonly initialVariantWeight?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#instance_type TfEndpointConfiguration#instance_type}
        */
        readonly instanceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#model_data_download_timeout_in_seconds TfEndpointConfiguration#model_data_download_timeout_in_seconds}
        */
        readonly modelDataDownloadTimeoutInSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#model_name TfEndpointConfiguration#model_name}
        */
        readonly modelName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#variant_name TfEndpointConfiguration#variant_name}
        */
        readonly variantName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#volume_size_in_gb TfEndpointConfiguration#volume_size_in_gb}
        */
        readonly volumeSizeInGb?: number;
        /**
        * capacity_reservation_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#capacity_reservation_config TfEndpointConfiguration#capacity_reservation_config}
        */
        readonly capacityReservationConfig?: ShadowProductionVariantsCapacityReservationConfigProperty;
        /**
        * core_dump_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#core_dump_config TfEndpointConfiguration#core_dump_config}
        */
        readonly coreDumpConfig?: ShadowProductionVariantsCoreDumpConfigProperty;
        /**
        * managed_instance_scaling block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#managed_instance_scaling TfEndpointConfiguration#managed_instance_scaling}
        */
        readonly managedInstanceScaling?: ShadowProductionVariantsManagedInstanceScalingProperty;
        /**
        * routing_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#routing_config TfEndpointConfiguration#routing_config}
        */
        readonly routingConfig?: ShadowProductionVariantsRoutingConfigProperty[] | cdktn.IResolvable;
        /**
        * serverless_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint_configuration#serverless_config TfEndpointConfiguration#serverless_config}
        */
        readonly serverlessConfig?: ShadowProductionVariantsServerlessConfigProperty;
    }
    class ShadowProductionVariantsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ShadowProductionVariantsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ShadowProductionVariantsProperty | cdktn.IResolvable | undefined);
        private _acceleratorType?;
        get acceleratorType(): string;
        set acceleratorType(value: string);
        resetAcceleratorType(): void;
        get acceleratorTypeInput(): string | undefined;
        private _containerStartupHealthCheckTimeoutInSeconds?;
        get containerStartupHealthCheckTimeoutInSeconds(): number;
        set containerStartupHealthCheckTimeoutInSeconds(value: number);
        resetContainerStartupHealthCheckTimeoutInSeconds(): void;
        get containerStartupHealthCheckTimeoutInSecondsInput(): number | undefined;
        private _enableSsmAccess?;
        get enableSsmAccess(): boolean | cdktn.IResolvable;
        set enableSsmAccess(value: boolean | cdktn.IResolvable);
        resetEnableSsmAccess(): void;
        get enableSsmAccessInput(): boolean | cdktn.IResolvable | undefined;
        private _inferenceAmiVersion?;
        get inferenceAmiVersion(): string;
        set inferenceAmiVersion(value: string);
        resetInferenceAmiVersion(): void;
        get inferenceAmiVersionInput(): string | undefined;
        private _initialInstanceCount?;
        get initialInstanceCount(): number;
        set initialInstanceCount(value: number);
        resetInitialInstanceCount(): void;
        get initialInstanceCountInput(): number | undefined;
        private _initialVariantWeight?;
        get initialVariantWeight(): number;
        set initialVariantWeight(value: number);
        resetInitialVariantWeight(): void;
        get initialVariantWeightInput(): number | undefined;
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        resetInstanceType(): void;
        get instanceTypeInput(): string | undefined;
        private _modelDataDownloadTimeoutInSeconds?;
        get modelDataDownloadTimeoutInSeconds(): number;
        set modelDataDownloadTimeoutInSeconds(value: number);
        resetModelDataDownloadTimeoutInSeconds(): void;
        get modelDataDownloadTimeoutInSecondsInput(): number | undefined;
        private _modelName?;
        get modelName(): string;
        set modelName(value: string);
        resetModelName(): void;
        get modelNameInput(): string | undefined;
        private _variantName?;
        get variantName(): string;
        set variantName(value: string);
        resetVariantName(): void;
        get variantNameInput(): string | undefined;
        private _volumeSizeInGb?;
        get volumeSizeInGb(): number;
        set volumeSizeInGb(value: number);
        resetVolumeSizeInGb(): void;
        get volumeSizeInGbInput(): number | undefined;
        private _capacityReservationConfig;
        get capacityReservationConfig(): ShadowProductionVariantsCapacityReservationConfigPropertyOutputReference;
        putCapacityReservationConfig(value: ShadowProductionVariantsCapacityReservationConfigProperty): void;
        resetCapacityReservationConfig(): void;
        get capacityReservationConfigInput(): ShadowProductionVariantsCapacityReservationConfigProperty | undefined;
        private _coreDumpConfig;
        get coreDumpConfig(): ShadowProductionVariantsCoreDumpConfigPropertyOutputReference;
        putCoreDumpConfig(value: ShadowProductionVariantsCoreDumpConfigProperty): void;
        resetCoreDumpConfig(): void;
        get coreDumpConfigInput(): ShadowProductionVariantsCoreDumpConfigProperty | undefined;
        private _managedInstanceScaling;
        get managedInstanceScaling(): ShadowProductionVariantsManagedInstanceScalingPropertyOutputReference;
        putManagedInstanceScaling(value: ShadowProductionVariantsManagedInstanceScalingProperty): void;
        resetManagedInstanceScaling(): void;
        get managedInstanceScalingInput(): ShadowProductionVariantsManagedInstanceScalingProperty | undefined;
        private _routingConfig;
        get routingConfig(): ShadowProductionVariantsRoutingConfigPropertyList;
        putRoutingConfig(value: ShadowProductionVariantsRoutingConfigProperty[] | cdktn.IResolvable): void;
        resetRoutingConfig(): void;
        get routingConfigInput(): cdktn.IResolvable | ShadowProductionVariantsRoutingConfigProperty[] | undefined;
        private _serverlessConfig;
        get serverlessConfig(): ShadowProductionVariantsServerlessConfigPropertyOutputReference;
        putServerlessConfig(value: ShadowProductionVariantsServerlessConfigProperty): void;
        resetServerlessConfig(): void;
        get serverlessConfigInput(): ShadowProductionVariantsServerlessConfigProperty | undefined;
    }
    class ShadowProductionVariantsPropertyList extends cdktn.ComplexList {
        internalValue?: ShadowProductionVariantsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ShadowProductionVariantsPropertyOutputReference;
    }
}
