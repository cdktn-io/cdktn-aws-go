import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSagemakerTrainingJobConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether to delete model packages in the configured model package group when destroying the training job.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#delete_model_packages_on_destroy AwsSagemakerTrainingJob#delete_model_packages_on_destroy}
    */
    readonly deleteModelPackagesOnDestroy?: boolean | cdktn.IResolvable;
    /**
    * Whether to delete detached VPC ENIs that SageMaker may leave behind when destroying the training job.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#delete_vpc_enis_on_destroy AwsSagemakerTrainingJob#delete_vpc_enis_on_destroy}
    */
    readonly deleteVpcEnisOnDestroy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#enable_inter_container_traffic_encryption AwsSagemakerTrainingJob#enable_inter_container_traffic_encryption}
    */
    readonly enableInterContainerTrafficEncryption?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#enable_managed_spot_training AwsSagemakerTrainingJob#enable_managed_spot_training}
    */
    readonly enableManagedSpotTraining?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#enable_network_isolation AwsSagemakerTrainingJob#enable_network_isolation}
    */
    readonly enableNetworkIsolation?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#environment AwsSagemakerTrainingJob#environment}
    */
    readonly environment?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#hyper_parameters AwsSagemakerTrainingJob#hyper_parameters}
    */
    readonly hyperParameters?: {
        [key: string]: string;
    };
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#region AwsSagemakerTrainingJob#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#role_arn AwsSagemakerTrainingJob#role_arn}
    */
    readonly roleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#tags AwsSagemakerTrainingJob#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#training_job_name AwsSagemakerTrainingJob#training_job_name}
    */
    readonly trainingJobName: string;
    /**
    * algorithm_specification block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#algorithm_specification AwsSagemakerTrainingJob#algorithm_specification}
    */
    readonly algorithmSpecification?: AwsSagemakerTrainingJob.AlgorithmSpecificationProperty[] | cdktn.IResolvable;
    /**
    * checkpoint_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#checkpoint_config AwsSagemakerTrainingJob#checkpoint_config}
    */
    readonly checkpointConfig?: AwsSagemakerTrainingJob.CheckpointConfigProperty[] | cdktn.IResolvable;
    /**
    * debug_hook_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#debug_hook_config AwsSagemakerTrainingJob#debug_hook_config}
    */
    readonly debugHookConfig?: AwsSagemakerTrainingJob.DebugHookConfigProperty[] | cdktn.IResolvable;
    /**
    * debug_rule_configurations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#debug_rule_configurations AwsSagemakerTrainingJob#debug_rule_configurations}
    */
    readonly debugRuleConfigurations?: AwsSagemakerTrainingJob.DebugRuleConfigurationsProperty[] | cdktn.IResolvable;
    /**
    * experiment_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#experiment_config AwsSagemakerTrainingJob#experiment_config}
    */
    readonly experimentConfig?: AwsSagemakerTrainingJob.ExperimentConfigProperty[] | cdktn.IResolvable;
    /**
    * infra_check_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#infra_check_config AwsSagemakerTrainingJob#infra_check_config}
    */
    readonly infraCheckConfig?: AwsSagemakerTrainingJob.InfraCheckConfigProperty[] | cdktn.IResolvable;
    /**
    * input_data_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#input_data_config AwsSagemakerTrainingJob#input_data_config}
    */
    readonly inputDataConfig?: AwsSagemakerTrainingJob.InputDataConfigProperty[] | cdktn.IResolvable;
    /**
    * mlflow_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#mlflow_config AwsSagemakerTrainingJob#mlflow_config}
    */
    readonly mlflowConfig?: AwsSagemakerTrainingJob.MlflowConfigProperty[] | cdktn.IResolvable;
    /**
    * model_package_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#model_package_config AwsSagemakerTrainingJob#model_package_config}
    */
    readonly modelPackageConfig?: AwsSagemakerTrainingJob.ModelPackageConfigProperty[] | cdktn.IResolvable;
    /**
    * output_data_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#output_data_config AwsSagemakerTrainingJob#output_data_config}
    */
    readonly outputDataConfig?: AwsSagemakerTrainingJob.OutputDataConfigProperty[] | cdktn.IResolvable;
    /**
    * profiler_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#profiler_config AwsSagemakerTrainingJob#profiler_config}
    */
    readonly profilerConfig?: AwsSagemakerTrainingJob.ProfilerConfigProperty[] | cdktn.IResolvable;
    /**
    * profiler_rule_configurations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#profiler_rule_configurations AwsSagemakerTrainingJob#profiler_rule_configurations}
    */
    readonly profilerRuleConfigurations?: AwsSagemakerTrainingJob.ProfilerRuleConfigurationsProperty[] | cdktn.IResolvable;
    /**
    * remote_debug_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#remote_debug_config AwsSagemakerTrainingJob#remote_debug_config}
    */
    readonly remoteDebugConfig?: AwsSagemakerTrainingJob.RemoteDebugConfigProperty[] | cdktn.IResolvable;
    /**
    * resource_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#resource_config AwsSagemakerTrainingJob#resource_config}
    */
    readonly resourceConfig?: AwsSagemakerTrainingJob.ResourceConfigProperty[] | cdktn.IResolvable;
    /**
    * retry_strategy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#retry_strategy AwsSagemakerTrainingJob#retry_strategy}
    */
    readonly retryStrategy?: AwsSagemakerTrainingJob.RetryStrategyProperty[] | cdktn.IResolvable;
    /**
    * serverless_job_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#serverless_job_config AwsSagemakerTrainingJob#serverless_job_config}
    */
    readonly serverlessJobConfig?: AwsSagemakerTrainingJob.ServerlessJobConfigProperty[] | cdktn.IResolvable;
    /**
    * session_chaining_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#session_chaining_config AwsSagemakerTrainingJob#session_chaining_config}
    */
    readonly sessionChainingConfig?: AwsSagemakerTrainingJob.SessionChainingConfigProperty[] | cdktn.IResolvable;
    /**
    * stopping_condition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#stopping_condition AwsSagemakerTrainingJob#stopping_condition}
    */
    readonly stoppingCondition?: AwsSagemakerTrainingJob.StoppingConditionProperty[] | cdktn.IResolvable;
    /**
    * tensor_board_output_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#tensor_board_output_config AwsSagemakerTrainingJob#tensor_board_output_config}
    */
    readonly tensorBoardOutputConfig?: AwsSagemakerTrainingJob.TensorBoardOutputConfigProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#timeouts AwsSagemakerTrainingJob#timeouts}
    */
    readonly timeouts?: AwsSagemakerTrainingJob.TimeoutsProperty;
    /**
    * vpc_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#vpc_config AwsSagemakerTrainingJob#vpc_config}
    */
    readonly vpcConfig?: AwsSagemakerTrainingJob.VpcConfigProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job aws_sagemaker_training_job}
*/
export declare class AwsSagemakerTrainingJob extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_sagemaker_training_job";
    /**
    * Generates CDKTN code for importing a AwsSagemakerTrainingJob resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSagemakerTrainingJob to import
    * @param importFromId The id of the existing AwsSagemakerTrainingJob that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSagemakerTrainingJob to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job aws_sagemaker_training_job} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSagemakerTrainingJobConfig
    */
    constructor(scope: Construct, id: string, config: AwsSagemakerTrainingJobConfig);
    get arn(): string;
    private _deleteModelPackagesOnDestroy?;
    get deleteModelPackagesOnDestroy(): boolean | cdktn.IResolvable;
    set deleteModelPackagesOnDestroy(value: boolean | cdktn.IResolvable);
    resetDeleteModelPackagesOnDestroy(): void;
    get deleteModelPackagesOnDestroyInput(): boolean | cdktn.IResolvable | undefined;
    private _deleteVpcEnisOnDestroy?;
    get deleteVpcEnisOnDestroy(): boolean | cdktn.IResolvable;
    set deleteVpcEnisOnDestroy(value: boolean | cdktn.IResolvable);
    resetDeleteVpcEnisOnDestroy(): void;
    get deleteVpcEnisOnDestroyInput(): boolean | cdktn.IResolvable | undefined;
    private _enableInterContainerTrafficEncryption?;
    get enableInterContainerTrafficEncryption(): boolean | cdktn.IResolvable;
    set enableInterContainerTrafficEncryption(value: boolean | cdktn.IResolvable);
    resetEnableInterContainerTrafficEncryption(): void;
    get enableInterContainerTrafficEncryptionInput(): boolean | cdktn.IResolvable | undefined;
    private _enableManagedSpotTraining?;
    get enableManagedSpotTraining(): boolean | cdktn.IResolvable;
    set enableManagedSpotTraining(value: boolean | cdktn.IResolvable);
    resetEnableManagedSpotTraining(): void;
    get enableManagedSpotTrainingInput(): boolean | cdktn.IResolvable | undefined;
    private _enableNetworkIsolation?;
    get enableNetworkIsolation(): boolean | cdktn.IResolvable;
    set enableNetworkIsolation(value: boolean | cdktn.IResolvable);
    resetEnableNetworkIsolation(): void;
    get enableNetworkIsolationInput(): boolean | cdktn.IResolvable | undefined;
    private _environment?;
    get environment(): {
        [key: string]: string;
    };
    set environment(value: {
        [key: string]: string;
    });
    resetEnvironment(): void;
    get environmentInput(): {
        [key: string]: string;
    } | undefined;
    private _hyperParameters?;
    get hyperParameters(): {
        [key: string]: string;
    };
    set hyperParameters(value: {
        [key: string]: string;
    });
    resetHyperParameters(): void;
    get hyperParametersInput(): {
        [key: string]: string;
    } | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _trainingJobName?;
    get trainingJobName(): string;
    set trainingJobName(value: string);
    get trainingJobNameInput(): string | undefined;
    private _algorithmSpecification;
    get algorithmSpecification(): AwsSagemakerTrainingJob.AlgorithmSpecificationPropertyList;
    putAlgorithmSpecification(value: AwsSagemakerTrainingJob.AlgorithmSpecificationProperty[] | cdktn.IResolvable): void;
    resetAlgorithmSpecification(): void;
    get algorithmSpecificationInput(): cdktn.IResolvable | AwsSagemakerTrainingJob.AlgorithmSpecificationProperty[] | undefined;
    private _checkpointConfig;
    get checkpointConfig(): AwsSagemakerTrainingJob.CheckpointConfigPropertyList;
    putCheckpointConfig(value: AwsSagemakerTrainingJob.CheckpointConfigProperty[] | cdktn.IResolvable): void;
    resetCheckpointConfig(): void;
    get checkpointConfigInput(): cdktn.IResolvable | AwsSagemakerTrainingJob.CheckpointConfigProperty[] | undefined;
    private _debugHookConfig;
    get debugHookConfig(): AwsSagemakerTrainingJob.DebugHookConfigPropertyList;
    putDebugHookConfig(value: AwsSagemakerTrainingJob.DebugHookConfigProperty[] | cdktn.IResolvable): void;
    resetDebugHookConfig(): void;
    get debugHookConfigInput(): cdktn.IResolvable | AwsSagemakerTrainingJob.DebugHookConfigProperty[] | undefined;
    private _debugRuleConfigurations;
    get debugRuleConfigurations(): AwsSagemakerTrainingJob.DebugRuleConfigurationsPropertyList;
    putDebugRuleConfigurations(value: AwsSagemakerTrainingJob.DebugRuleConfigurationsProperty[] | cdktn.IResolvable): void;
    resetDebugRuleConfigurations(): void;
    get debugRuleConfigurationsInput(): cdktn.IResolvable | AwsSagemakerTrainingJob.DebugRuleConfigurationsProperty[] | undefined;
    private _experimentConfig;
    get experimentConfig(): AwsSagemakerTrainingJob.ExperimentConfigPropertyList;
    putExperimentConfig(value: AwsSagemakerTrainingJob.ExperimentConfigProperty[] | cdktn.IResolvable): void;
    resetExperimentConfig(): void;
    get experimentConfigInput(): cdktn.IResolvable | AwsSagemakerTrainingJob.ExperimentConfigProperty[] | undefined;
    private _infraCheckConfig;
    get infraCheckConfig(): AwsSagemakerTrainingJob.InfraCheckConfigPropertyList;
    putInfraCheckConfig(value: AwsSagemakerTrainingJob.InfraCheckConfigProperty[] | cdktn.IResolvable): void;
    resetInfraCheckConfig(): void;
    get infraCheckConfigInput(): cdktn.IResolvable | AwsSagemakerTrainingJob.InfraCheckConfigProperty[] | undefined;
    private _inputDataConfig;
    get inputDataConfig(): AwsSagemakerTrainingJob.InputDataConfigPropertyList;
    putInputDataConfig(value: AwsSagemakerTrainingJob.InputDataConfigProperty[] | cdktn.IResolvable): void;
    resetInputDataConfig(): void;
    get inputDataConfigInput(): cdktn.IResolvable | AwsSagemakerTrainingJob.InputDataConfigProperty[] | undefined;
    private _mlflowConfig;
    get mlflowConfig(): AwsSagemakerTrainingJob.MlflowConfigPropertyList;
    putMlflowConfig(value: AwsSagemakerTrainingJob.MlflowConfigProperty[] | cdktn.IResolvable): void;
    resetMlflowConfig(): void;
    get mlflowConfigInput(): cdktn.IResolvable | AwsSagemakerTrainingJob.MlflowConfigProperty[] | undefined;
    private _modelPackageConfig;
    get modelPackageConfig(): AwsSagemakerTrainingJob.ModelPackageConfigPropertyList;
    putModelPackageConfig(value: AwsSagemakerTrainingJob.ModelPackageConfigProperty[] | cdktn.IResolvable): void;
    resetModelPackageConfig(): void;
    get modelPackageConfigInput(): cdktn.IResolvable | AwsSagemakerTrainingJob.ModelPackageConfigProperty[] | undefined;
    private _outputDataConfig;
    get outputDataConfig(): AwsSagemakerTrainingJob.OutputDataConfigPropertyList;
    putOutputDataConfig(value: AwsSagemakerTrainingJob.OutputDataConfigProperty[] | cdktn.IResolvable): void;
    resetOutputDataConfig(): void;
    get outputDataConfigInput(): cdktn.IResolvable | AwsSagemakerTrainingJob.OutputDataConfigProperty[] | undefined;
    private _profilerConfig;
    get profilerConfig(): AwsSagemakerTrainingJob.ProfilerConfigPropertyList;
    putProfilerConfig(value: AwsSagemakerTrainingJob.ProfilerConfigProperty[] | cdktn.IResolvable): void;
    resetProfilerConfig(): void;
    get profilerConfigInput(): cdktn.IResolvable | AwsSagemakerTrainingJob.ProfilerConfigProperty[] | undefined;
    private _profilerRuleConfigurations;
    get profilerRuleConfigurations(): AwsSagemakerTrainingJob.ProfilerRuleConfigurationsPropertyList;
    putProfilerRuleConfigurations(value: AwsSagemakerTrainingJob.ProfilerRuleConfigurationsProperty[] | cdktn.IResolvable): void;
    resetProfilerRuleConfigurations(): void;
    get profilerRuleConfigurationsInput(): cdktn.IResolvable | AwsSagemakerTrainingJob.ProfilerRuleConfigurationsProperty[] | undefined;
    private _remoteDebugConfig;
    get remoteDebugConfig(): AwsSagemakerTrainingJob.RemoteDebugConfigPropertyList;
    putRemoteDebugConfig(value: AwsSagemakerTrainingJob.RemoteDebugConfigProperty[] | cdktn.IResolvable): void;
    resetRemoteDebugConfig(): void;
    get remoteDebugConfigInput(): cdktn.IResolvable | AwsSagemakerTrainingJob.RemoteDebugConfigProperty[] | undefined;
    private _resourceConfig;
    get resourceConfig(): AwsSagemakerTrainingJob.ResourceConfigPropertyList;
    putResourceConfig(value: AwsSagemakerTrainingJob.ResourceConfigProperty[] | cdktn.IResolvable): void;
    resetResourceConfig(): void;
    get resourceConfigInput(): cdktn.IResolvable | AwsSagemakerTrainingJob.ResourceConfigProperty[] | undefined;
    private _retryStrategy;
    get retryStrategy(): AwsSagemakerTrainingJob.RetryStrategyPropertyList;
    putRetryStrategy(value: AwsSagemakerTrainingJob.RetryStrategyProperty[] | cdktn.IResolvable): void;
    resetRetryStrategy(): void;
    get retryStrategyInput(): cdktn.IResolvable | AwsSagemakerTrainingJob.RetryStrategyProperty[] | undefined;
    private _serverlessJobConfig;
    get serverlessJobConfig(): AwsSagemakerTrainingJob.ServerlessJobConfigPropertyList;
    putServerlessJobConfig(value: AwsSagemakerTrainingJob.ServerlessJobConfigProperty[] | cdktn.IResolvable): void;
    resetServerlessJobConfig(): void;
    get serverlessJobConfigInput(): cdktn.IResolvable | AwsSagemakerTrainingJob.ServerlessJobConfigProperty[] | undefined;
    private _sessionChainingConfig;
    get sessionChainingConfig(): AwsSagemakerTrainingJob.SessionChainingConfigPropertyList;
    putSessionChainingConfig(value: AwsSagemakerTrainingJob.SessionChainingConfigProperty[] | cdktn.IResolvable): void;
    resetSessionChainingConfig(): void;
    get sessionChainingConfigInput(): cdktn.IResolvable | AwsSagemakerTrainingJob.SessionChainingConfigProperty[] | undefined;
    private _stoppingCondition;
    get stoppingCondition(): AwsSagemakerTrainingJob.StoppingConditionPropertyList;
    putStoppingCondition(value: AwsSagemakerTrainingJob.StoppingConditionProperty[] | cdktn.IResolvable): void;
    resetStoppingCondition(): void;
    get stoppingConditionInput(): cdktn.IResolvable | AwsSagemakerTrainingJob.StoppingConditionProperty[] | undefined;
    private _tensorBoardOutputConfig;
    get tensorBoardOutputConfig(): AwsSagemakerTrainingJob.TensorBoardOutputConfigPropertyList;
    putTensorBoardOutputConfig(value: AwsSagemakerTrainingJob.TensorBoardOutputConfigProperty[] | cdktn.IResolvable): void;
    resetTensorBoardOutputConfig(): void;
    get tensorBoardOutputConfigInput(): cdktn.IResolvable | AwsSagemakerTrainingJob.TensorBoardOutputConfigProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsSagemakerTrainingJob.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsSagemakerTrainingJob.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsSagemakerTrainingJob.TimeoutsProperty | undefined;
    private _vpcConfig;
    get vpcConfig(): AwsSagemakerTrainingJob.VpcConfigPropertyList;
    putVpcConfig(value: AwsSagemakerTrainingJob.VpcConfigProperty[] | cdktn.IResolvable): void;
    resetVpcConfig(): void;
    get vpcConfigInput(): cdktn.IResolvable | AwsSagemakerTrainingJob.VpcConfigProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsSagemakerTrainingJobMetricDefinitionsPropertyToTerraform(struct?: AwsSagemakerTrainingJob.MetricDefinitionsProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobMetricDefinitionsPropertyToHclTerraform(struct?: AwsSagemakerTrainingJob.MetricDefinitionsProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobTrainingRepositoryAuthConfigPropertyToTerraform(struct?: AwsSagemakerTrainingJob.TrainingRepositoryAuthConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobTrainingRepositoryAuthConfigPropertyToHclTerraform(struct?: AwsSagemakerTrainingJob.TrainingRepositoryAuthConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobTrainingImageConfigPropertyToTerraform(struct?: AwsSagemakerTrainingJob.TrainingImageConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobTrainingImageConfigPropertyToHclTerraform(struct?: AwsSagemakerTrainingJob.TrainingImageConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobAlgorithmSpecificationPropertyToTerraform(struct?: AwsSagemakerTrainingJob.AlgorithmSpecificationProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobAlgorithmSpecificationPropertyToHclTerraform(struct?: AwsSagemakerTrainingJob.AlgorithmSpecificationProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobCheckpointConfigPropertyToTerraform(struct?: AwsSagemakerTrainingJob.CheckpointConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobCheckpointConfigPropertyToHclTerraform(struct?: AwsSagemakerTrainingJob.CheckpointConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobCollectionConfigurationsPropertyToTerraform(struct?: AwsSagemakerTrainingJob.CollectionConfigurationsProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobCollectionConfigurationsPropertyToHclTerraform(struct?: AwsSagemakerTrainingJob.CollectionConfigurationsProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobDebugHookConfigPropertyToTerraform(struct?: AwsSagemakerTrainingJob.DebugHookConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobDebugHookConfigPropertyToHclTerraform(struct?: AwsSagemakerTrainingJob.DebugHookConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobDebugRuleConfigurationsPropertyToTerraform(struct?: AwsSagemakerTrainingJob.DebugRuleConfigurationsProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobDebugRuleConfigurationsPropertyToHclTerraform(struct?: AwsSagemakerTrainingJob.DebugRuleConfigurationsProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobExperimentConfigPropertyToTerraform(struct?: AwsSagemakerTrainingJob.ExperimentConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobExperimentConfigPropertyToHclTerraform(struct?: AwsSagemakerTrainingJob.ExperimentConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobInfraCheckConfigPropertyToTerraform(struct?: AwsSagemakerTrainingJob.InfraCheckConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobInfraCheckConfigPropertyToHclTerraform(struct?: AwsSagemakerTrainingJob.InfraCheckConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobFileSystemDataSourcePropertyToTerraform(struct?: AwsSagemakerTrainingJob.FileSystemDataSourceProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobFileSystemDataSourcePropertyToHclTerraform(struct?: AwsSagemakerTrainingJob.FileSystemDataSourceProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobHubAccessConfigPropertyToTerraform(struct?: AwsSagemakerTrainingJob.HubAccessConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobHubAccessConfigPropertyToHclTerraform(struct?: AwsSagemakerTrainingJob.HubAccessConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobModelAccessConfigPropertyToTerraform(struct?: AwsSagemakerTrainingJob.ModelAccessConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobModelAccessConfigPropertyToHclTerraform(struct?: AwsSagemakerTrainingJob.ModelAccessConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobS3DataSourcePropertyToTerraform(struct?: AwsSagemakerTrainingJob.S3DataSourceProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobS3DataSourcePropertyToHclTerraform(struct?: AwsSagemakerTrainingJob.S3DataSourceProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobDataSourcePropertyToTerraform(struct?: AwsSagemakerTrainingJob.DataSourceProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobDataSourcePropertyToHclTerraform(struct?: AwsSagemakerTrainingJob.DataSourceProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobShuffleConfigPropertyToTerraform(struct?: AwsSagemakerTrainingJob.ShuffleConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobShuffleConfigPropertyToHclTerraform(struct?: AwsSagemakerTrainingJob.ShuffleConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobInputDataConfigPropertyToTerraform(struct?: AwsSagemakerTrainingJob.InputDataConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobInputDataConfigPropertyToHclTerraform(struct?: AwsSagemakerTrainingJob.InputDataConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobMlflowConfigPropertyToTerraform(struct?: AwsSagemakerTrainingJob.MlflowConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobMlflowConfigPropertyToHclTerraform(struct?: AwsSagemakerTrainingJob.MlflowConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobModelPackageConfigPropertyToTerraform(struct?: AwsSagemakerTrainingJob.ModelPackageConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobModelPackageConfigPropertyToHclTerraform(struct?: AwsSagemakerTrainingJob.ModelPackageConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobOutputDataConfigPropertyToTerraform(struct?: AwsSagemakerTrainingJob.OutputDataConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobOutputDataConfigPropertyToHclTerraform(struct?: AwsSagemakerTrainingJob.OutputDataConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobProfilerConfigPropertyToTerraform(struct?: AwsSagemakerTrainingJob.ProfilerConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobProfilerConfigPropertyToHclTerraform(struct?: AwsSagemakerTrainingJob.ProfilerConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobProfilerRuleConfigurationsPropertyToTerraform(struct?: AwsSagemakerTrainingJob.ProfilerRuleConfigurationsProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobProfilerRuleConfigurationsPropertyToHclTerraform(struct?: AwsSagemakerTrainingJob.ProfilerRuleConfigurationsProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobRemoteDebugConfigPropertyToTerraform(struct?: AwsSagemakerTrainingJob.RemoteDebugConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobRemoteDebugConfigPropertyToHclTerraform(struct?: AwsSagemakerTrainingJob.RemoteDebugConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobInstanceGroupsPropertyToTerraform(struct?: AwsSagemakerTrainingJob.InstanceGroupsProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobInstanceGroupsPropertyToHclTerraform(struct?: AwsSagemakerTrainingJob.InstanceGroupsProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobPlacementSpecificationsPropertyToTerraform(struct?: AwsSagemakerTrainingJob.PlacementSpecificationsProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobPlacementSpecificationsPropertyToHclTerraform(struct?: AwsSagemakerTrainingJob.PlacementSpecificationsProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobInstancePlacementConfigPropertyToTerraform(struct?: AwsSagemakerTrainingJob.InstancePlacementConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobInstancePlacementConfigPropertyToHclTerraform(struct?: AwsSagemakerTrainingJob.InstancePlacementConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobResourceConfigPropertyToTerraform(struct?: AwsSagemakerTrainingJob.ResourceConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobResourceConfigPropertyToHclTerraform(struct?: AwsSagemakerTrainingJob.ResourceConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobRetryStrategyPropertyToTerraform(struct?: AwsSagemakerTrainingJob.RetryStrategyProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobRetryStrategyPropertyToHclTerraform(struct?: AwsSagemakerTrainingJob.RetryStrategyProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobServerlessJobConfigPropertyToTerraform(struct?: AwsSagemakerTrainingJob.ServerlessJobConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobServerlessJobConfigPropertyToHclTerraform(struct?: AwsSagemakerTrainingJob.ServerlessJobConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobSessionChainingConfigPropertyToTerraform(struct?: AwsSagemakerTrainingJob.SessionChainingConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobSessionChainingConfigPropertyToHclTerraform(struct?: AwsSagemakerTrainingJob.SessionChainingConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobStoppingConditionPropertyToTerraform(struct?: AwsSagemakerTrainingJob.StoppingConditionProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobStoppingConditionPropertyToHclTerraform(struct?: AwsSagemakerTrainingJob.StoppingConditionProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobTensorBoardOutputConfigPropertyToTerraform(struct?: AwsSagemakerTrainingJob.TensorBoardOutputConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobTensorBoardOutputConfigPropertyToHclTerraform(struct?: AwsSagemakerTrainingJob.TensorBoardOutputConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobTimeoutsPropertyToTerraform(struct?: AwsSagemakerTrainingJob.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobTimeoutsPropertyToHclTerraform(struct?: AwsSagemakerTrainingJob.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobVpcConfigPropertyToTerraform(struct?: AwsSagemakerTrainingJob.VpcConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerTrainingJobVpcConfigPropertyToHclTerraform(struct?: AwsSagemakerTrainingJob.VpcConfigProperty | cdktn.IResolvable): any;
export declare namespace AwsSagemakerTrainingJob {
    interface MetricDefinitionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#name AwsSagemakerTrainingJob#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#regex AwsSagemakerTrainingJob#regex}
        */
        readonly regex: string;
    }
    class MetricDefinitionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MetricDefinitionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MetricDefinitionsProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _regex?;
        get regex(): string;
        set regex(value: string);
        get regexInput(): string | undefined;
    }
    class MetricDefinitionsPropertyList extends cdktn.ComplexList {
        internalValue?: MetricDefinitionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MetricDefinitionsPropertyOutputReference;
    }
    interface TrainingRepositoryAuthConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#training_repository_credentials_provider_arn AwsSagemakerTrainingJob#training_repository_credentials_provider_arn}
        */
        readonly trainingRepositoryCredentialsProviderArn?: string;
    }
    class TrainingRepositoryAuthConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingRepositoryAuthConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingRepositoryAuthConfigProperty | cdktn.IResolvable | undefined);
        private _trainingRepositoryCredentialsProviderArn?;
        get trainingRepositoryCredentialsProviderArn(): string;
        set trainingRepositoryCredentialsProviderArn(value: string);
        resetTrainingRepositoryCredentialsProviderArn(): void;
        get trainingRepositoryCredentialsProviderArnInput(): string | undefined;
    }
    class TrainingRepositoryAuthConfigPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingRepositoryAuthConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingRepositoryAuthConfigPropertyOutputReference;
    }
    interface TrainingImageConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#training_repository_access_mode AwsSagemakerTrainingJob#training_repository_access_mode}
        */
        readonly trainingRepositoryAccessMode?: string;
        /**
        * training_repository_auth_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#training_repository_auth_config AwsSagemakerTrainingJob#training_repository_auth_config}
        */
        readonly trainingRepositoryAuthConfig?: TrainingRepositoryAuthConfigProperty[] | cdktn.IResolvable;
    }
    class TrainingImageConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingImageConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingImageConfigProperty | cdktn.IResolvable | undefined);
        private _trainingRepositoryAccessMode?;
        get trainingRepositoryAccessMode(): string;
        set trainingRepositoryAccessMode(value: string);
        resetTrainingRepositoryAccessMode(): void;
        get trainingRepositoryAccessModeInput(): string | undefined;
        private _trainingRepositoryAuthConfig;
        get trainingRepositoryAuthConfig(): TrainingRepositoryAuthConfigPropertyList;
        putTrainingRepositoryAuthConfig(value: TrainingRepositoryAuthConfigProperty[] | cdktn.IResolvable): void;
        resetTrainingRepositoryAuthConfig(): void;
        get trainingRepositoryAuthConfigInput(): cdktn.IResolvable | TrainingRepositoryAuthConfigProperty[] | undefined;
    }
    class TrainingImageConfigPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingImageConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingImageConfigPropertyOutputReference;
    }
    interface AlgorithmSpecificationProperty {
        /**
        * Name or ARN of a SageMaker algorithm resource. Exactly one of `algorithm_name` or `training_image` must be set.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#algorithm_name AwsSagemakerTrainingJob#algorithm_name}
        */
        readonly algorithmName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#container_arguments AwsSagemakerTrainingJob#container_arguments}
        */
        readonly containerArguments?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#container_entrypoint AwsSagemakerTrainingJob#container_entrypoint}
        */
        readonly containerEntrypoint?: string[];
        /**
        * Whether SageMaker AI should publish time-series metrics. SageMaker enables this automatically for built-in algorithms, supported prebuilt images, and jobs with explicit `metric_definitions`.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#enable_sagemaker_metrics_time_series AwsSagemakerTrainingJob#enable_sagemaker_metrics_time_series}
        */
        readonly enableSagemakerMetricsTimeSeries?: boolean | cdktn.IResolvable;
        /**
        * Registry path of the training image. Exactly one of `algorithm_name` or `training_image` must be set. Use `metric_definitions` only when you need to extract custom metrics from your own training container logs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#training_image AwsSagemakerTrainingJob#training_image}
        */
        readonly trainingImage?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#training_input_mode AwsSagemakerTrainingJob#training_input_mode}
        */
        readonly trainingInputMode?: string;
        /**
        * metric_definitions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#metric_definitions AwsSagemakerTrainingJob#metric_definitions}
        */
        readonly metricDefinitions?: MetricDefinitionsProperty[] | cdktn.IResolvable;
        /**
        * training_image_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#training_image_config AwsSagemakerTrainingJob#training_image_config}
        */
        readonly trainingImageConfig?: TrainingImageConfigProperty[] | cdktn.IResolvable;
    }
    class AlgorithmSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AlgorithmSpecificationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AlgorithmSpecificationProperty | cdktn.IResolvable | undefined);
        private _algorithmName?;
        get algorithmName(): string;
        set algorithmName(value: string);
        resetAlgorithmName(): void;
        get algorithmNameInput(): string | undefined;
        private _containerArguments?;
        get containerArguments(): string[];
        set containerArguments(value: string[]);
        resetContainerArguments(): void;
        get containerArgumentsInput(): string[] | undefined;
        private _containerEntrypoint?;
        get containerEntrypoint(): string[];
        set containerEntrypoint(value: string[]);
        resetContainerEntrypoint(): void;
        get containerEntrypointInput(): string[] | undefined;
        private _enableSagemakerMetricsTimeSeries?;
        get enableSagemakerMetricsTimeSeries(): boolean | cdktn.IResolvable;
        set enableSagemakerMetricsTimeSeries(value: boolean | cdktn.IResolvable);
        resetEnableSagemakerMetricsTimeSeries(): void;
        get enableSagemakerMetricsTimeSeriesInput(): boolean | cdktn.IResolvable | undefined;
        private _trainingImage?;
        get trainingImage(): string;
        set trainingImage(value: string);
        resetTrainingImage(): void;
        get trainingImageInput(): string | undefined;
        private _trainingInputMode?;
        get trainingInputMode(): string;
        set trainingInputMode(value: string);
        resetTrainingInputMode(): void;
        get trainingInputModeInput(): string | undefined;
        private _metricDefinitions;
        get metricDefinitions(): MetricDefinitionsPropertyList;
        putMetricDefinitions(value: MetricDefinitionsProperty[] | cdktn.IResolvable): void;
        resetMetricDefinitions(): void;
        get metricDefinitionsInput(): cdktn.IResolvable | MetricDefinitionsProperty[] | undefined;
        private _trainingImageConfig;
        get trainingImageConfig(): TrainingImageConfigPropertyList;
        putTrainingImageConfig(value: TrainingImageConfigProperty[] | cdktn.IResolvable): void;
        resetTrainingImageConfig(): void;
        get trainingImageConfigInput(): cdktn.IResolvable | TrainingImageConfigProperty[] | undefined;
    }
    class AlgorithmSpecificationPropertyList extends cdktn.ComplexList {
        internalValue?: AlgorithmSpecificationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AlgorithmSpecificationPropertyOutputReference;
    }
    interface CheckpointConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#local_path AwsSagemakerTrainingJob#local_path}
        */
        readonly localPath?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#s3_uri AwsSagemakerTrainingJob#s3_uri}
        */
        readonly s3Uri: string;
    }
    class CheckpointConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CheckpointConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CheckpointConfigProperty | cdktn.IResolvable | undefined);
        private _localPath?;
        get localPath(): string;
        set localPath(value: string);
        resetLocalPath(): void;
        get localPathInput(): string | undefined;
        private _s3Uri?;
        get s3Uri(): string;
        set s3Uri(value: string);
        get s3UriInput(): string | undefined;
    }
    class CheckpointConfigPropertyList extends cdktn.ComplexList {
        internalValue?: CheckpointConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CheckpointConfigPropertyOutputReference;
    }
    interface CollectionConfigurationsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#collection_name AwsSagemakerTrainingJob#collection_name}
        */
        readonly collectionName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#collection_parameters AwsSagemakerTrainingJob#collection_parameters}
        */
        readonly collectionParameters?: {
            [key: string]: string;
        };
    }
    class CollectionConfigurationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CollectionConfigurationsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CollectionConfigurationsProperty | cdktn.IResolvable | undefined);
        private _collectionName?;
        get collectionName(): string;
        set collectionName(value: string);
        resetCollectionName(): void;
        get collectionNameInput(): string | undefined;
        private _collectionParameters?;
        get collectionParameters(): {
            [key: string]: string;
        };
        set collectionParameters(value: {
            [key: string]: string;
        });
        resetCollectionParameters(): void;
        get collectionParametersInput(): {
            [key: string]: string;
        } | undefined;
    }
    class CollectionConfigurationsPropertyList extends cdktn.ComplexList {
        internalValue?: CollectionConfigurationsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CollectionConfigurationsPropertyOutputReference;
    }
    interface DebugHookConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#hook_parameters AwsSagemakerTrainingJob#hook_parameters}
        */
        readonly hookParameters?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#local_path AwsSagemakerTrainingJob#local_path}
        */
        readonly localPath?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#s3_output_path AwsSagemakerTrainingJob#s3_output_path}
        */
        readonly s3OutputPath: string;
        /**
        * collection_configurations block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#collection_configurations AwsSagemakerTrainingJob#collection_configurations}
        */
        readonly collectionConfigurations?: CollectionConfigurationsProperty[] | cdktn.IResolvable;
    }
    class DebugHookConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DebugHookConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DebugHookConfigProperty | cdktn.IResolvable | undefined);
        private _hookParameters?;
        get hookParameters(): {
            [key: string]: string;
        };
        set hookParameters(value: {
            [key: string]: string;
        });
        resetHookParameters(): void;
        get hookParametersInput(): {
            [key: string]: string;
        } | undefined;
        private _localPath?;
        get localPath(): string;
        set localPath(value: string);
        resetLocalPath(): void;
        get localPathInput(): string | undefined;
        private _s3OutputPath?;
        get s3OutputPath(): string;
        set s3OutputPath(value: string);
        get s3OutputPathInput(): string | undefined;
        private _collectionConfigurations;
        get collectionConfigurations(): CollectionConfigurationsPropertyList;
        putCollectionConfigurations(value: CollectionConfigurationsProperty[] | cdktn.IResolvable): void;
        resetCollectionConfigurations(): void;
        get collectionConfigurationsInput(): cdktn.IResolvable | CollectionConfigurationsProperty[] | undefined;
    }
    class DebugHookConfigPropertyList extends cdktn.ComplexList {
        internalValue?: DebugHookConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DebugHookConfigPropertyOutputReference;
    }
    interface DebugRuleConfigurationsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#instance_type AwsSagemakerTrainingJob#instance_type}
        */
        readonly instanceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#local_path AwsSagemakerTrainingJob#local_path}
        */
        readonly localPath?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#rule_configuration_name AwsSagemakerTrainingJob#rule_configuration_name}
        */
        readonly ruleConfigurationName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#rule_evaluator_image AwsSagemakerTrainingJob#rule_evaluator_image}
        */
        readonly ruleEvaluatorImage: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#rule_parameters AwsSagemakerTrainingJob#rule_parameters}
        */
        readonly ruleParameters?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#s3_output_path AwsSagemakerTrainingJob#s3_output_path}
        */
        readonly s3OutputPath?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#volume_size_in_gb AwsSagemakerTrainingJob#volume_size_in_gb}
        */
        readonly volumeSizeInGb?: number;
    }
    class DebugRuleConfigurationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DebugRuleConfigurationsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DebugRuleConfigurationsProperty | cdktn.IResolvable | undefined);
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        resetInstanceType(): void;
        get instanceTypeInput(): string | undefined;
        private _localPath?;
        get localPath(): string;
        set localPath(value: string);
        resetLocalPath(): void;
        get localPathInput(): string | undefined;
        private _ruleConfigurationName?;
        get ruleConfigurationName(): string;
        set ruleConfigurationName(value: string);
        get ruleConfigurationNameInput(): string | undefined;
        private _ruleEvaluatorImage?;
        get ruleEvaluatorImage(): string;
        set ruleEvaluatorImage(value: string);
        get ruleEvaluatorImageInput(): string | undefined;
        private _ruleParameters?;
        get ruleParameters(): {
            [key: string]: string;
        };
        set ruleParameters(value: {
            [key: string]: string;
        });
        resetRuleParameters(): void;
        get ruleParametersInput(): {
            [key: string]: string;
        } | undefined;
        private _s3OutputPath?;
        get s3OutputPath(): string;
        set s3OutputPath(value: string);
        resetS3OutputPath(): void;
        get s3OutputPathInput(): string | undefined;
        private _volumeSizeInGb?;
        get volumeSizeInGb(): number;
        set volumeSizeInGb(value: number);
        resetVolumeSizeInGb(): void;
        get volumeSizeInGbInput(): number | undefined;
    }
    class DebugRuleConfigurationsPropertyList extends cdktn.ComplexList {
        internalValue?: DebugRuleConfigurationsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DebugRuleConfigurationsPropertyOutputReference;
    }
    interface ExperimentConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#experiment_name AwsSagemakerTrainingJob#experiment_name}
        */
        readonly experimentName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#run_name AwsSagemakerTrainingJob#run_name}
        */
        readonly runName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#trial_component_display_name AwsSagemakerTrainingJob#trial_component_display_name}
        */
        readonly trialComponentDisplayName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#trial_name AwsSagemakerTrainingJob#trial_name}
        */
        readonly trialName?: string;
    }
    class ExperimentConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExperimentConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ExperimentConfigProperty | cdktn.IResolvable | undefined);
        private _experimentName?;
        get experimentName(): string;
        set experimentName(value: string);
        resetExperimentName(): void;
        get experimentNameInput(): string | undefined;
        private _runName?;
        get runName(): string;
        set runName(value: string);
        resetRunName(): void;
        get runNameInput(): string | undefined;
        private _trialComponentDisplayName?;
        get trialComponentDisplayName(): string;
        set trialComponentDisplayName(value: string);
        resetTrialComponentDisplayName(): void;
        get trialComponentDisplayNameInput(): string | undefined;
        private _trialName?;
        get trialName(): string;
        set trialName(value: string);
        resetTrialName(): void;
        get trialNameInput(): string | undefined;
    }
    class ExperimentConfigPropertyList extends cdktn.ComplexList {
        internalValue?: ExperimentConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExperimentConfigPropertyOutputReference;
    }
    interface InfraCheckConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#enable_infra_check AwsSagemakerTrainingJob#enable_infra_check}
        */
        readonly enableInfraCheck?: boolean | cdktn.IResolvable;
    }
    class InfraCheckConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InfraCheckConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InfraCheckConfigProperty | cdktn.IResolvable | undefined);
        private _enableInfraCheck?;
        get enableInfraCheck(): boolean | cdktn.IResolvable;
        set enableInfraCheck(value: boolean | cdktn.IResolvable);
        resetEnableInfraCheck(): void;
        get enableInfraCheckInput(): boolean | cdktn.IResolvable | undefined;
    }
    class InfraCheckConfigPropertyList extends cdktn.ComplexList {
        internalValue?: InfraCheckConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InfraCheckConfigPropertyOutputReference;
    }
    interface FileSystemDataSourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#directory_path AwsSagemakerTrainingJob#directory_path}
        */
        readonly directoryPath: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#file_system_access_mode AwsSagemakerTrainingJob#file_system_access_mode}
        */
        readonly fileSystemAccessMode: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#file_system_id AwsSagemakerTrainingJob#file_system_id}
        */
        readonly fileSystemId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#file_system_type AwsSagemakerTrainingJob#file_system_type}
        */
        readonly fileSystemType: string;
    }
    class FileSystemDataSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FileSystemDataSourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FileSystemDataSourceProperty | cdktn.IResolvable | undefined);
        private _directoryPath?;
        get directoryPath(): string;
        set directoryPath(value: string);
        get directoryPathInput(): string | undefined;
        private _fileSystemAccessMode?;
        get fileSystemAccessMode(): string;
        set fileSystemAccessMode(value: string);
        get fileSystemAccessModeInput(): string | undefined;
        private _fileSystemId?;
        get fileSystemId(): string;
        set fileSystemId(value: string);
        get fileSystemIdInput(): string | undefined;
        private _fileSystemType?;
        get fileSystemType(): string;
        set fileSystemType(value: string);
        get fileSystemTypeInput(): string | undefined;
    }
    class FileSystemDataSourcePropertyList extends cdktn.ComplexList {
        internalValue?: FileSystemDataSourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FileSystemDataSourcePropertyOutputReference;
    }
    interface HubAccessConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#hub_content_arn AwsSagemakerTrainingJob#hub_content_arn}
        */
        readonly hubContentArn: string;
    }
    class HubAccessConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HubAccessConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: HubAccessConfigProperty | cdktn.IResolvable | undefined);
        private _hubContentArn?;
        get hubContentArn(): string;
        set hubContentArn(value: string);
        get hubContentArnInput(): string | undefined;
    }
    class HubAccessConfigPropertyList extends cdktn.ComplexList {
        internalValue?: HubAccessConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HubAccessConfigPropertyOutputReference;
    }
    interface ModelAccessConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#accept_eula AwsSagemakerTrainingJob#accept_eula}
        */
        readonly acceptEula: boolean | cdktn.IResolvable;
    }
    class ModelAccessConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ModelAccessConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ModelAccessConfigProperty | cdktn.IResolvable | undefined);
        private _acceptEula?;
        get acceptEula(): boolean | cdktn.IResolvable;
        set acceptEula(value: boolean | cdktn.IResolvable);
        get acceptEulaInput(): boolean | cdktn.IResolvable | undefined;
    }
    class ModelAccessConfigPropertyList extends cdktn.ComplexList {
        internalValue?: ModelAccessConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ModelAccessConfigPropertyOutputReference;
    }
    interface S3DataSourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#attribute_names AwsSagemakerTrainingJob#attribute_names}
        */
        readonly attributeNames?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#instance_group_names AwsSagemakerTrainingJob#instance_group_names}
        */
        readonly instanceGroupNames?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#s3_data_distribution_type AwsSagemakerTrainingJob#s3_data_distribution_type}
        */
        readonly s3DataDistributionType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#s3_data_type AwsSagemakerTrainingJob#s3_data_type}
        */
        readonly s3DataType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#s3_uri AwsSagemakerTrainingJob#s3_uri}
        */
        readonly s3Uri: string;
        /**
        * hub_access_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#hub_access_config AwsSagemakerTrainingJob#hub_access_config}
        */
        readonly hubAccessConfig?: HubAccessConfigProperty[] | cdktn.IResolvable;
        /**
        * model_access_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#model_access_config AwsSagemakerTrainingJob#model_access_config}
        */
        readonly modelAccessConfig?: ModelAccessConfigProperty[] | cdktn.IResolvable;
    }
    class S3DataSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3DataSourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: S3DataSourceProperty | cdktn.IResolvable | undefined);
        private _attributeNames?;
        get attributeNames(): string[];
        set attributeNames(value: string[]);
        resetAttributeNames(): void;
        get attributeNamesInput(): string[] | undefined;
        private _instanceGroupNames?;
        get instanceGroupNames(): string[];
        set instanceGroupNames(value: string[]);
        resetInstanceGroupNames(): void;
        get instanceGroupNamesInput(): string[] | undefined;
        private _s3DataDistributionType?;
        get s3DataDistributionType(): string;
        set s3DataDistributionType(value: string);
        resetS3DataDistributionType(): void;
        get s3DataDistributionTypeInput(): string | undefined;
        private _s3DataType?;
        get s3DataType(): string;
        set s3DataType(value: string);
        get s3DataTypeInput(): string | undefined;
        private _s3Uri?;
        get s3Uri(): string;
        set s3Uri(value: string);
        get s3UriInput(): string | undefined;
        private _hubAccessConfig;
        get hubAccessConfig(): HubAccessConfigPropertyList;
        putHubAccessConfig(value: HubAccessConfigProperty[] | cdktn.IResolvable): void;
        resetHubAccessConfig(): void;
        get hubAccessConfigInput(): cdktn.IResolvable | HubAccessConfigProperty[] | undefined;
        private _modelAccessConfig;
        get modelAccessConfig(): ModelAccessConfigPropertyList;
        putModelAccessConfig(value: ModelAccessConfigProperty[] | cdktn.IResolvable): void;
        resetModelAccessConfig(): void;
        get modelAccessConfigInput(): cdktn.IResolvable | ModelAccessConfigProperty[] | undefined;
    }
    class S3DataSourcePropertyList extends cdktn.ComplexList {
        internalValue?: S3DataSourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3DataSourcePropertyOutputReference;
    }
    interface DataSourceProperty {
        /**
        * file_system_data_source block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#file_system_data_source AwsSagemakerTrainingJob#file_system_data_source}
        */
        readonly fileSystemDataSource?: FileSystemDataSourceProperty[] | cdktn.IResolvable;
        /**
        * s3_data_source block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#s3_data_source AwsSagemakerTrainingJob#s3_data_source}
        */
        readonly s3DataSource?: S3DataSourceProperty[] | cdktn.IResolvable;
    }
    class DataSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataSourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DataSourceProperty | cdktn.IResolvable | undefined);
        private _fileSystemDataSource;
        get fileSystemDataSource(): FileSystemDataSourcePropertyList;
        putFileSystemDataSource(value: FileSystemDataSourceProperty[] | cdktn.IResolvable): void;
        resetFileSystemDataSource(): void;
        get fileSystemDataSourceInput(): cdktn.IResolvable | FileSystemDataSourceProperty[] | undefined;
        private _s3DataSource;
        get s3DataSource(): S3DataSourcePropertyList;
        putS3DataSource(value: S3DataSourceProperty[] | cdktn.IResolvable): void;
        resetS3DataSource(): void;
        get s3DataSourceInput(): cdktn.IResolvable | S3DataSourceProperty[] | undefined;
    }
    class DataSourcePropertyList extends cdktn.ComplexList {
        internalValue?: DataSourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataSourcePropertyOutputReference;
    }
    interface ShuffleConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#seed AwsSagemakerTrainingJob#seed}
        */
        readonly seed?: number;
    }
    class ShuffleConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ShuffleConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ShuffleConfigProperty | cdktn.IResolvable | undefined);
        private _seed?;
        get seed(): number;
        set seed(value: number);
        resetSeed(): void;
        get seedInput(): number | undefined;
    }
    class ShuffleConfigPropertyList extends cdktn.ComplexList {
        internalValue?: ShuffleConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ShuffleConfigPropertyOutputReference;
    }
    interface InputDataConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#channel_name AwsSagemakerTrainingJob#channel_name}
        */
        readonly channelName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#compression_type AwsSagemakerTrainingJob#compression_type}
        */
        readonly compressionType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#content_type AwsSagemakerTrainingJob#content_type}
        */
        readonly contentType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#input_mode AwsSagemakerTrainingJob#input_mode}
        */
        readonly inputMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#record_wrapper_type AwsSagemakerTrainingJob#record_wrapper_type}
        */
        readonly recordWrapperType?: string;
        /**
        * data_source block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#data_source AwsSagemakerTrainingJob#data_source}
        */
        readonly dataSource?: DataSourceProperty[] | cdktn.IResolvable;
        /**
        * shuffle_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#shuffle_config AwsSagemakerTrainingJob#shuffle_config}
        */
        readonly shuffleConfig?: ShuffleConfigProperty[] | cdktn.IResolvable;
    }
    class InputDataConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InputDataConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InputDataConfigProperty | cdktn.IResolvable | undefined);
        private _channelName?;
        get channelName(): string;
        set channelName(value: string);
        get channelNameInput(): string | undefined;
        private _compressionType?;
        get compressionType(): string;
        set compressionType(value: string);
        resetCompressionType(): void;
        get compressionTypeInput(): string | undefined;
        private _contentType?;
        get contentType(): string;
        set contentType(value: string);
        resetContentType(): void;
        get contentTypeInput(): string | undefined;
        private _inputMode?;
        get inputMode(): string;
        set inputMode(value: string);
        resetInputMode(): void;
        get inputModeInput(): string | undefined;
        private _recordWrapperType?;
        get recordWrapperType(): string;
        set recordWrapperType(value: string);
        resetRecordWrapperType(): void;
        get recordWrapperTypeInput(): string | undefined;
        private _dataSource;
        get dataSource(): DataSourcePropertyList;
        putDataSource(value: DataSourceProperty[] | cdktn.IResolvable): void;
        resetDataSource(): void;
        get dataSourceInput(): cdktn.IResolvable | DataSourceProperty[] | undefined;
        private _shuffleConfig;
        get shuffleConfig(): ShuffleConfigPropertyList;
        putShuffleConfig(value: ShuffleConfigProperty[] | cdktn.IResolvable): void;
        resetShuffleConfig(): void;
        get shuffleConfigInput(): cdktn.IResolvable | ShuffleConfigProperty[] | undefined;
    }
    class InputDataConfigPropertyList extends cdktn.ComplexList {
        internalValue?: InputDataConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InputDataConfigPropertyOutputReference;
    }
    interface MlflowConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#mlflow_experiment_name AwsSagemakerTrainingJob#mlflow_experiment_name}
        */
        readonly mlflowExperimentName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#mlflow_resource_arn AwsSagemakerTrainingJob#mlflow_resource_arn}
        */
        readonly mlflowResourceArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#mlflow_run_name AwsSagemakerTrainingJob#mlflow_run_name}
        */
        readonly mlflowRunName?: string;
    }
    class MlflowConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MlflowConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MlflowConfigProperty | cdktn.IResolvable | undefined);
        private _mlflowExperimentName?;
        get mlflowExperimentName(): string;
        set mlflowExperimentName(value: string);
        resetMlflowExperimentName(): void;
        get mlflowExperimentNameInput(): string | undefined;
        private _mlflowResourceArn?;
        get mlflowResourceArn(): string;
        set mlflowResourceArn(value: string);
        get mlflowResourceArnInput(): string | undefined;
        private _mlflowRunName?;
        get mlflowRunName(): string;
        set mlflowRunName(value: string);
        resetMlflowRunName(): void;
        get mlflowRunNameInput(): string | undefined;
    }
    class MlflowConfigPropertyList extends cdktn.ComplexList {
        internalValue?: MlflowConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MlflowConfigPropertyOutputReference;
    }
    interface ModelPackageConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#model_package_group_arn AwsSagemakerTrainingJob#model_package_group_arn}
        */
        readonly modelPackageGroupArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#source_model_package_arn AwsSagemakerTrainingJob#source_model_package_arn}
        */
        readonly sourceModelPackageArn?: string;
    }
    class ModelPackageConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ModelPackageConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ModelPackageConfigProperty | cdktn.IResolvable | undefined);
        private _modelPackageGroupArn?;
        get modelPackageGroupArn(): string;
        set modelPackageGroupArn(value: string);
        get modelPackageGroupArnInput(): string | undefined;
        private _sourceModelPackageArn?;
        get sourceModelPackageArn(): string;
        set sourceModelPackageArn(value: string);
        resetSourceModelPackageArn(): void;
        get sourceModelPackageArnInput(): string | undefined;
    }
    class ModelPackageConfigPropertyList extends cdktn.ComplexList {
        internalValue?: ModelPackageConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ModelPackageConfigPropertyOutputReference;
    }
    interface OutputDataConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#compression_type AwsSagemakerTrainingJob#compression_type}
        */
        readonly compressionType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#kms_key_id AwsSagemakerTrainingJob#kms_key_id}
        */
        readonly kmsKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#s3_output_path AwsSagemakerTrainingJob#s3_output_path}
        */
        readonly s3OutputPath: string;
    }
    class OutputDataConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OutputDataConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OutputDataConfigProperty | cdktn.IResolvable | undefined);
        private _compressionType?;
        get compressionType(): string;
        set compressionType(value: string);
        resetCompressionType(): void;
        get compressionTypeInput(): string | undefined;
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        resetKmsKeyId(): void;
        get kmsKeyIdInput(): string | undefined;
        private _s3OutputPath?;
        get s3OutputPath(): string;
        set s3OutputPath(value: string);
        get s3OutputPathInput(): string | undefined;
    }
    class OutputDataConfigPropertyList extends cdktn.ComplexList {
        internalValue?: OutputDataConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OutputDataConfigPropertyOutputReference;
    }
    interface ProfilerConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#disable_profiler AwsSagemakerTrainingJob#disable_profiler}
        */
        readonly disableProfiler?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#profiling_interval_in_milliseconds AwsSagemakerTrainingJob#profiling_interval_in_milliseconds}
        */
        readonly profilingIntervalInMilliseconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#profiling_parameters AwsSagemakerTrainingJob#profiling_parameters}
        */
        readonly profilingParameters?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#s3_output_path AwsSagemakerTrainingJob#s3_output_path}
        */
        readonly s3OutputPath?: string;
    }
    class ProfilerConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ProfilerConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ProfilerConfigProperty | cdktn.IResolvable | undefined);
        private _disableProfiler?;
        get disableProfiler(): boolean | cdktn.IResolvable;
        set disableProfiler(value: boolean | cdktn.IResolvable);
        resetDisableProfiler(): void;
        get disableProfilerInput(): boolean | cdktn.IResolvable | undefined;
        private _profilingIntervalInMilliseconds?;
        get profilingIntervalInMilliseconds(): number;
        set profilingIntervalInMilliseconds(value: number);
        resetProfilingIntervalInMilliseconds(): void;
        get profilingIntervalInMillisecondsInput(): number | undefined;
        private _profilingParameters?;
        get profilingParameters(): {
            [key: string]: string;
        };
        set profilingParameters(value: {
            [key: string]: string;
        });
        resetProfilingParameters(): void;
        get profilingParametersInput(): {
            [key: string]: string;
        } | undefined;
        private _s3OutputPath?;
        get s3OutputPath(): string;
        set s3OutputPath(value: string);
        resetS3OutputPath(): void;
        get s3OutputPathInput(): string | undefined;
    }
    class ProfilerConfigPropertyList extends cdktn.ComplexList {
        internalValue?: ProfilerConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ProfilerConfigPropertyOutputReference;
    }
    interface ProfilerRuleConfigurationsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#instance_type AwsSagemakerTrainingJob#instance_type}
        */
        readonly instanceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#local_path AwsSagemakerTrainingJob#local_path}
        */
        readonly localPath?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#rule_configuration_name AwsSagemakerTrainingJob#rule_configuration_name}
        */
        readonly ruleConfigurationName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#rule_evaluator_image AwsSagemakerTrainingJob#rule_evaluator_image}
        */
        readonly ruleEvaluatorImage: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#rule_parameters AwsSagemakerTrainingJob#rule_parameters}
        */
        readonly ruleParameters?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#s3_output_path AwsSagemakerTrainingJob#s3_output_path}
        */
        readonly s3OutputPath?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#volume_size_in_gb AwsSagemakerTrainingJob#volume_size_in_gb}
        */
        readonly volumeSizeInGb?: number;
    }
    class ProfilerRuleConfigurationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ProfilerRuleConfigurationsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ProfilerRuleConfigurationsProperty | cdktn.IResolvable | undefined);
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        resetInstanceType(): void;
        get instanceTypeInput(): string | undefined;
        private _localPath?;
        get localPath(): string;
        set localPath(value: string);
        resetLocalPath(): void;
        get localPathInput(): string | undefined;
        private _ruleConfigurationName?;
        get ruleConfigurationName(): string;
        set ruleConfigurationName(value: string);
        get ruleConfigurationNameInput(): string | undefined;
        private _ruleEvaluatorImage?;
        get ruleEvaluatorImage(): string;
        set ruleEvaluatorImage(value: string);
        get ruleEvaluatorImageInput(): string | undefined;
        private _ruleParameters?;
        get ruleParameters(): {
            [key: string]: string;
        };
        set ruleParameters(value: {
            [key: string]: string;
        });
        resetRuleParameters(): void;
        get ruleParametersInput(): {
            [key: string]: string;
        } | undefined;
        private _s3OutputPath?;
        get s3OutputPath(): string;
        set s3OutputPath(value: string);
        resetS3OutputPath(): void;
        get s3OutputPathInput(): string | undefined;
        private _volumeSizeInGb?;
        get volumeSizeInGb(): number;
        set volumeSizeInGb(value: number);
        resetVolumeSizeInGb(): void;
        get volumeSizeInGbInput(): number | undefined;
    }
    class ProfilerRuleConfigurationsPropertyList extends cdktn.ComplexList {
        internalValue?: ProfilerRuleConfigurationsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ProfilerRuleConfigurationsPropertyOutputReference;
    }
    interface RemoteDebugConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#enable_remote_debug AwsSagemakerTrainingJob#enable_remote_debug}
        */
        readonly enableRemoteDebug?: boolean | cdktn.IResolvable;
    }
    class RemoteDebugConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RemoteDebugConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RemoteDebugConfigProperty | cdktn.IResolvable | undefined);
        private _enableRemoteDebug?;
        get enableRemoteDebug(): boolean | cdktn.IResolvable;
        set enableRemoteDebug(value: boolean | cdktn.IResolvable);
        resetEnableRemoteDebug(): void;
        get enableRemoteDebugInput(): boolean | cdktn.IResolvable | undefined;
    }
    class RemoteDebugConfigPropertyList extends cdktn.ComplexList {
        internalValue?: RemoteDebugConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RemoteDebugConfigPropertyOutputReference;
    }
    interface InstanceGroupsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#instance_count AwsSagemakerTrainingJob#instance_count}
        */
        readonly instanceCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#instance_group_name AwsSagemakerTrainingJob#instance_group_name}
        */
        readonly instanceGroupName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#instance_type AwsSagemakerTrainingJob#instance_type}
        */
        readonly instanceType?: string;
    }
    class InstanceGroupsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InstanceGroupsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InstanceGroupsProperty | cdktn.IResolvable | undefined);
        private _instanceCount?;
        get instanceCount(): number;
        set instanceCount(value: number);
        resetInstanceCount(): void;
        get instanceCountInput(): number | undefined;
        private _instanceGroupName?;
        get instanceGroupName(): string;
        set instanceGroupName(value: string);
        resetInstanceGroupName(): void;
        get instanceGroupNameInput(): string | undefined;
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        resetInstanceType(): void;
        get instanceTypeInput(): string | undefined;
    }
    class InstanceGroupsPropertyList extends cdktn.ComplexList {
        internalValue?: InstanceGroupsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InstanceGroupsPropertyOutputReference;
    }
    interface PlacementSpecificationsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#instance_count AwsSagemakerTrainingJob#instance_count}
        */
        readonly instanceCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#ultra_server_id AwsSagemakerTrainingJob#ultra_server_id}
        */
        readonly ultraServerId?: string;
    }
    class PlacementSpecificationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PlacementSpecificationsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PlacementSpecificationsProperty | cdktn.IResolvable | undefined);
        private _instanceCount?;
        get instanceCount(): number;
        set instanceCount(value: number);
        resetInstanceCount(): void;
        get instanceCountInput(): number | undefined;
        private _ultraServerId?;
        get ultraServerId(): string;
        set ultraServerId(value: string);
        resetUltraServerId(): void;
        get ultraServerIdInput(): string | undefined;
    }
    class PlacementSpecificationsPropertyList extends cdktn.ComplexList {
        internalValue?: PlacementSpecificationsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PlacementSpecificationsPropertyOutputReference;
    }
    interface InstancePlacementConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#enable_multiple_jobs AwsSagemakerTrainingJob#enable_multiple_jobs}
        */
        readonly enableMultipleJobs?: boolean | cdktn.IResolvable;
        /**
        * placement_specifications block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#placement_specifications AwsSagemakerTrainingJob#placement_specifications}
        */
        readonly placementSpecifications?: PlacementSpecificationsProperty[] | cdktn.IResolvable;
    }
    class InstancePlacementConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InstancePlacementConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InstancePlacementConfigProperty | cdktn.IResolvable | undefined);
        private _enableMultipleJobs?;
        get enableMultipleJobs(): boolean | cdktn.IResolvable;
        set enableMultipleJobs(value: boolean | cdktn.IResolvable);
        resetEnableMultipleJobs(): void;
        get enableMultipleJobsInput(): boolean | cdktn.IResolvable | undefined;
        private _placementSpecifications;
        get placementSpecifications(): PlacementSpecificationsPropertyList;
        putPlacementSpecifications(value: PlacementSpecificationsProperty[] | cdktn.IResolvable): void;
        resetPlacementSpecifications(): void;
        get placementSpecificationsInput(): cdktn.IResolvable | PlacementSpecificationsProperty[] | undefined;
    }
    class InstancePlacementConfigPropertyList extends cdktn.ComplexList {
        internalValue?: InstancePlacementConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InstancePlacementConfigPropertyOutputReference;
    }
    interface ResourceConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#instance_count AwsSagemakerTrainingJob#instance_count}
        */
        readonly instanceCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#instance_type AwsSagemakerTrainingJob#instance_type}
        */
        readonly instanceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#keep_alive_period_in_seconds AwsSagemakerTrainingJob#keep_alive_period_in_seconds}
        */
        readonly keepAlivePeriodInSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#training_plan_arn AwsSagemakerTrainingJob#training_plan_arn}
        */
        readonly trainingPlanArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#volume_kms_key_id AwsSagemakerTrainingJob#volume_kms_key_id}
        */
        readonly volumeKmsKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#volume_size_in_gb AwsSagemakerTrainingJob#volume_size_in_gb}
        */
        readonly volumeSizeInGb?: number;
        /**
        * instance_groups block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#instance_groups AwsSagemakerTrainingJob#instance_groups}
        */
        readonly instanceGroups?: InstanceGroupsProperty[] | cdktn.IResolvable;
        /**
        * instance_placement_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#instance_placement_config AwsSagemakerTrainingJob#instance_placement_config}
        */
        readonly instancePlacementConfig?: InstancePlacementConfigProperty[] | cdktn.IResolvable;
    }
    class ResourceConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceConfigProperty | cdktn.IResolvable | undefined);
        private _instanceCount?;
        get instanceCount(): number;
        set instanceCount(value: number);
        resetInstanceCount(): void;
        get instanceCountInput(): number | undefined;
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        resetInstanceType(): void;
        get instanceTypeInput(): string | undefined;
        private _keepAlivePeriodInSeconds?;
        get keepAlivePeriodInSeconds(): number;
        set keepAlivePeriodInSeconds(value: number);
        resetKeepAlivePeriodInSeconds(): void;
        get keepAlivePeriodInSecondsInput(): number | undefined;
        private _trainingPlanArn?;
        get trainingPlanArn(): string;
        set trainingPlanArn(value: string);
        resetTrainingPlanArn(): void;
        get trainingPlanArnInput(): string | undefined;
        private _volumeKmsKeyId?;
        get volumeKmsKeyId(): string;
        set volumeKmsKeyId(value: string);
        resetVolumeKmsKeyId(): void;
        get volumeKmsKeyIdInput(): string | undefined;
        private _volumeSizeInGb?;
        get volumeSizeInGb(): number;
        set volumeSizeInGb(value: number);
        resetVolumeSizeInGb(): void;
        get volumeSizeInGbInput(): number | undefined;
        private _instanceGroups;
        get instanceGroups(): InstanceGroupsPropertyList;
        putInstanceGroups(value: InstanceGroupsProperty[] | cdktn.IResolvable): void;
        resetInstanceGroups(): void;
        get instanceGroupsInput(): cdktn.IResolvable | InstanceGroupsProperty[] | undefined;
        private _instancePlacementConfig;
        get instancePlacementConfig(): InstancePlacementConfigPropertyList;
        putInstancePlacementConfig(value: InstancePlacementConfigProperty[] | cdktn.IResolvable): void;
        resetInstancePlacementConfig(): void;
        get instancePlacementConfigInput(): cdktn.IResolvable | InstancePlacementConfigProperty[] | undefined;
    }
    class ResourceConfigPropertyList extends cdktn.ComplexList {
        internalValue?: ResourceConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceConfigPropertyOutputReference;
    }
    interface RetryStrategyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#maximum_retry_attempts AwsSagemakerTrainingJob#maximum_retry_attempts}
        */
        readonly maximumRetryAttempts: number;
    }
    class RetryStrategyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RetryStrategyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RetryStrategyProperty | cdktn.IResolvable | undefined);
        private _maximumRetryAttempts?;
        get maximumRetryAttempts(): number;
        set maximumRetryAttempts(value: number);
        get maximumRetryAttemptsInput(): number | undefined;
    }
    class RetryStrategyPropertyList extends cdktn.ComplexList {
        internalValue?: RetryStrategyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RetryStrategyPropertyOutputReference;
    }
    interface ServerlessJobConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#accept_eula AwsSagemakerTrainingJob#accept_eula}
        */
        readonly acceptEula?: boolean | cdktn.IResolvable;
        /**
        * Base model ARN in SageMaker Public Hub. SageMaker always selects the latest version of the provided model.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#base_model_arn AwsSagemakerTrainingJob#base_model_arn}
        */
        readonly baseModelArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#customization_technique AwsSagemakerTrainingJob#customization_technique}
        */
        readonly customizationTechnique?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#evaluation_type AwsSagemakerTrainingJob#evaluation_type}
        */
        readonly evaluationType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#evaluator_arn AwsSagemakerTrainingJob#evaluator_arn}
        */
        readonly evaluatorArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#job_type AwsSagemakerTrainingJob#job_type}
        */
        readonly jobType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#peft AwsSagemakerTrainingJob#peft}
        */
        readonly peft?: string;
    }
    class ServerlessJobConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ServerlessJobConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ServerlessJobConfigProperty | cdktn.IResolvable | undefined);
        private _acceptEula?;
        get acceptEula(): boolean | cdktn.IResolvable;
        set acceptEula(value: boolean | cdktn.IResolvable);
        resetAcceptEula(): void;
        get acceptEulaInput(): boolean | cdktn.IResolvable | undefined;
        private _baseModelArn?;
        get baseModelArn(): string;
        set baseModelArn(value: string);
        get baseModelArnInput(): string | undefined;
        private _customizationTechnique?;
        get customizationTechnique(): string;
        set customizationTechnique(value: string);
        resetCustomizationTechnique(): void;
        get customizationTechniqueInput(): string | undefined;
        private _evaluationType?;
        get evaluationType(): string;
        set evaluationType(value: string);
        resetEvaluationType(): void;
        get evaluationTypeInput(): string | undefined;
        private _evaluatorArn?;
        get evaluatorArn(): string;
        set evaluatorArn(value: string);
        resetEvaluatorArn(): void;
        get evaluatorArnInput(): string | undefined;
        private _jobType?;
        get jobType(): string;
        set jobType(value: string);
        get jobTypeInput(): string | undefined;
        private _peft?;
        get peft(): string;
        set peft(value: string);
        resetPeft(): void;
        get peftInput(): string | undefined;
    }
    class ServerlessJobConfigPropertyList extends cdktn.ComplexList {
        internalValue?: ServerlessJobConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ServerlessJobConfigPropertyOutputReference;
    }
    interface SessionChainingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#enable_session_tag_chaining AwsSagemakerTrainingJob#enable_session_tag_chaining}
        */
        readonly enableSessionTagChaining?: boolean | cdktn.IResolvable;
    }
    class SessionChainingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SessionChainingConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SessionChainingConfigProperty | cdktn.IResolvable | undefined);
        private _enableSessionTagChaining?;
        get enableSessionTagChaining(): boolean | cdktn.IResolvable;
        set enableSessionTagChaining(value: boolean | cdktn.IResolvable);
        resetEnableSessionTagChaining(): void;
        get enableSessionTagChainingInput(): boolean | cdktn.IResolvable | undefined;
    }
    class SessionChainingConfigPropertyList extends cdktn.ComplexList {
        internalValue?: SessionChainingConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SessionChainingConfigPropertyOutputReference;
    }
    interface StoppingConditionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#max_pending_time_in_seconds AwsSagemakerTrainingJob#max_pending_time_in_seconds}
        */
        readonly maxPendingTimeInSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#max_runtime_in_seconds AwsSagemakerTrainingJob#max_runtime_in_seconds}
        */
        readonly maxRuntimeInSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#max_wait_time_in_seconds AwsSagemakerTrainingJob#max_wait_time_in_seconds}
        */
        readonly maxWaitTimeInSeconds?: number;
    }
    class StoppingConditionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StoppingConditionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StoppingConditionProperty | cdktn.IResolvable | undefined);
        private _maxPendingTimeInSeconds?;
        get maxPendingTimeInSeconds(): number;
        set maxPendingTimeInSeconds(value: number);
        resetMaxPendingTimeInSeconds(): void;
        get maxPendingTimeInSecondsInput(): number | undefined;
        private _maxRuntimeInSeconds?;
        get maxRuntimeInSeconds(): number;
        set maxRuntimeInSeconds(value: number);
        resetMaxRuntimeInSeconds(): void;
        get maxRuntimeInSecondsInput(): number | undefined;
        private _maxWaitTimeInSeconds?;
        get maxWaitTimeInSeconds(): number;
        set maxWaitTimeInSeconds(value: number);
        resetMaxWaitTimeInSeconds(): void;
        get maxWaitTimeInSecondsInput(): number | undefined;
    }
    class StoppingConditionPropertyList extends cdktn.ComplexList {
        internalValue?: StoppingConditionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StoppingConditionPropertyOutputReference;
    }
    interface TensorBoardOutputConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#local_path AwsSagemakerTrainingJob#local_path}
        */
        readonly localPath?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#s3_output_path AwsSagemakerTrainingJob#s3_output_path}
        */
        readonly s3OutputPath: string;
    }
    class TensorBoardOutputConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TensorBoardOutputConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TensorBoardOutputConfigProperty | cdktn.IResolvable | undefined);
        private _localPath?;
        get localPath(): string;
        set localPath(value: string);
        resetLocalPath(): void;
        get localPathInput(): string | undefined;
        private _s3OutputPath?;
        get s3OutputPath(): string;
        set s3OutputPath(value: string);
        get s3OutputPathInput(): string | undefined;
    }
    class TensorBoardOutputConfigPropertyList extends cdktn.ComplexList {
        internalValue?: TensorBoardOutputConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TensorBoardOutputConfigPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#create AwsSagemakerTrainingJob#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#delete AwsSagemakerTrainingJob#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#update AwsSagemakerTrainingJob#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface VpcConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#security_group_ids AwsSagemakerTrainingJob#security_group_ids}
        */
        readonly securityGroupIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_training_job#subnets AwsSagemakerTrainingJob#subnets}
        */
        readonly subnets: string[];
    }
    class VpcConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VpcConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VpcConfigProperty | cdktn.IResolvable | undefined);
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        get securityGroupIdsInput(): string[] | undefined;
        private _subnets?;
        get subnets(): string[];
        set subnets(value: string[]);
        get subnetsInput(): string[] | undefined;
    }
    class VpcConfigPropertyList extends cdktn.ComplexList {
        internalValue?: VpcConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VpcConfigPropertyOutputReference;
    }
}
