import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSagemakerNotebookInstanceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_notebook_instance#additional_code_repositories AwsSagemakerNotebookInstance#additional_code_repositories}
    */
    readonly additionalCodeRepositories?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_notebook_instance#default_code_repository AwsSagemakerNotebookInstance#default_code_repository}
    */
    readonly defaultCodeRepository?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_notebook_instance#direct_internet_access AwsSagemakerNotebookInstance#direct_internet_access}
    */
    readonly directInternetAccess?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_notebook_instance#id AwsSagemakerNotebookInstance#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_notebook_instance#instance_type AwsSagemakerNotebookInstance#instance_type}
    */
    readonly instanceType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_notebook_instance#kms_key_id AwsSagemakerNotebookInstance#kms_key_id}
    */
    readonly kmsKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_notebook_instance#lifecycle_config_name AwsSagemakerNotebookInstance#lifecycle_config_name}
    */
    readonly lifecycleConfigName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_notebook_instance#name AwsSagemakerNotebookInstance#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_notebook_instance#platform_identifier AwsSagemakerNotebookInstance#platform_identifier}
    */
    readonly platformIdentifier?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_notebook_instance#region AwsSagemakerNotebookInstance#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_notebook_instance#role_arn AwsSagemakerNotebookInstance#role_arn}
    */
    readonly roleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_notebook_instance#root_access AwsSagemakerNotebookInstance#root_access}
    */
    readonly rootAccess?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_notebook_instance#security_groups AwsSagemakerNotebookInstance#security_groups}
    */
    readonly securityGroups?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_notebook_instance#subnet_id AwsSagemakerNotebookInstance#subnet_id}
    */
    readonly subnetId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_notebook_instance#tags AwsSagemakerNotebookInstance#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_notebook_instance#tags_all AwsSagemakerNotebookInstance#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_notebook_instance#volume_size AwsSagemakerNotebookInstance#volume_size}
    */
    readonly volumeSize?: number;
    /**
    * instance_metadata_service_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_notebook_instance#instance_metadata_service_configuration AwsSagemakerNotebookInstance#instance_metadata_service_configuration}
    */
    readonly instanceMetadataServiceConfiguration?: AwsSagemakerNotebookInstance.InstanceMetadataServiceConfigurationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_notebook_instance aws_sagemaker_notebook_instance}
*/
export declare class AwsSagemakerNotebookInstance extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_sagemaker_notebook_instance";
    /**
    * Generates CDKTN code for importing a AwsSagemakerNotebookInstance resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSagemakerNotebookInstance to import
    * @param importFromId The id of the existing AwsSagemakerNotebookInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_notebook_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSagemakerNotebookInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_notebook_instance aws_sagemaker_notebook_instance} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSagemakerNotebookInstanceConfig
    */
    constructor(scope: Construct, id: string, config: AwsSagemakerNotebookInstanceConfig);
    private _additionalCodeRepositories?;
    get additionalCodeRepositories(): string[];
    set additionalCodeRepositories(value: string[]);
    resetAdditionalCodeRepositories(): void;
    get additionalCodeRepositoriesInput(): string[] | undefined;
    get arn(): string;
    private _defaultCodeRepository?;
    get defaultCodeRepository(): string;
    set defaultCodeRepository(value: string);
    resetDefaultCodeRepository(): void;
    get defaultCodeRepositoryInput(): string | undefined;
    private _directInternetAccess?;
    get directInternetAccess(): string;
    set directInternetAccess(value: string);
    resetDirectInternetAccess(): void;
    get directInternetAccessInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceType?;
    get instanceType(): string;
    set instanceType(value: string);
    get instanceTypeInput(): string | undefined;
    private _kmsKeyId?;
    get kmsKeyId(): string;
    set kmsKeyId(value: string);
    resetKmsKeyId(): void;
    get kmsKeyIdInput(): string | undefined;
    private _lifecycleConfigName?;
    get lifecycleConfigName(): string;
    set lifecycleConfigName(value: string);
    resetLifecycleConfigName(): void;
    get lifecycleConfigNameInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get networkInterfaceId(): string;
    private _platformIdentifier?;
    get platformIdentifier(): string;
    set platformIdentifier(value: string);
    resetPlatformIdentifier(): void;
    get platformIdentifierInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    private _rootAccess?;
    get rootAccess(): string;
    set rootAccess(value: string);
    resetRootAccess(): void;
    get rootAccessInput(): string | undefined;
    private _securityGroups?;
    get securityGroups(): string[];
    set securityGroups(value: string[]);
    resetSecurityGroups(): void;
    get securityGroupsInput(): string[] | undefined;
    private _subnetId?;
    get subnetId(): string;
    set subnetId(value: string);
    resetSubnetId(): void;
    get subnetIdInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get url(): string;
    private _volumeSize?;
    get volumeSize(): number;
    set volumeSize(value: number);
    resetVolumeSize(): void;
    get volumeSizeInput(): number | undefined;
    private _instanceMetadataServiceConfiguration;
    get instanceMetadataServiceConfiguration(): AwsSagemakerNotebookInstance.InstanceMetadataServiceConfigurationPropertyOutputReference;
    putInstanceMetadataServiceConfiguration(value: AwsSagemakerNotebookInstance.InstanceMetadataServiceConfigurationProperty): void;
    resetInstanceMetadataServiceConfiguration(): void;
    get instanceMetadataServiceConfigurationInput(): AwsSagemakerNotebookInstance.InstanceMetadataServiceConfigurationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsSagemakerNotebookInstanceInstanceMetadataServiceConfigurationPropertyToTerraform(struct?: AwsSagemakerNotebookInstance.InstanceMetadataServiceConfigurationPropertyOutputReference | AwsSagemakerNotebookInstance.InstanceMetadataServiceConfigurationProperty): any;
export declare function awsSagemakerNotebookInstanceInstanceMetadataServiceConfigurationPropertyToHclTerraform(struct?: AwsSagemakerNotebookInstance.InstanceMetadataServiceConfigurationPropertyOutputReference | AwsSagemakerNotebookInstance.InstanceMetadataServiceConfigurationProperty): any;
export declare namespace AwsSagemakerNotebookInstance {
    interface InstanceMetadataServiceConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_notebook_instance#minimum_instance_metadata_service_version AwsSagemakerNotebookInstance#minimum_instance_metadata_service_version}
        */
        readonly minimumInstanceMetadataServiceVersion?: string;
    }
    class InstanceMetadataServiceConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InstanceMetadataServiceConfigurationProperty | undefined;
        set internalValue(value: InstanceMetadataServiceConfigurationProperty | undefined);
        private _minimumInstanceMetadataServiceVersion?;
        get minimumInstanceMetadataServiceVersion(): string;
        set minimumInstanceMetadataServiceVersion(value: string);
        resetMinimumInstanceMetadataServiceVersion(): void;
        get minimumInstanceMetadataServiceVersionInput(): string | undefined;
    }
}
