import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSagemakerHumanTaskUiConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_human_task_ui#human_task_ui_name AwsSagemakerHumanTaskUi#human_task_ui_name}
    */
    readonly humanTaskUiName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_human_task_ui#id AwsSagemakerHumanTaskUi#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_human_task_ui#region AwsSagemakerHumanTaskUi#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_human_task_ui#tags AwsSagemakerHumanTaskUi#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_human_task_ui#tags_all AwsSagemakerHumanTaskUi#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * ui_template block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_human_task_ui#ui_template AwsSagemakerHumanTaskUi#ui_template}
    */
    readonly uiTemplate: AwsSagemakerHumanTaskUi.UiTemplateProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_human_task_ui aws_sagemaker_human_task_ui}
*/
export declare class AwsSagemakerHumanTaskUi extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_sagemaker_human_task_ui";
    /**
    * Generates CDKTN code for importing a AwsSagemakerHumanTaskUi resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSagemakerHumanTaskUi to import
    * @param importFromId The id of the existing AwsSagemakerHumanTaskUi that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_human_task_ui#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSagemakerHumanTaskUi to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_human_task_ui aws_sagemaker_human_task_ui} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSagemakerHumanTaskUiConfig
    */
    constructor(scope: Construct, id: string, config: AwsSagemakerHumanTaskUiConfig);
    get arn(): string;
    private _humanTaskUiName?;
    get humanTaskUiName(): string;
    set humanTaskUiName(value: string);
    get humanTaskUiNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _uiTemplate;
    get uiTemplate(): AwsSagemakerHumanTaskUi.UiTemplatePropertyOutputReference;
    putUiTemplate(value: AwsSagemakerHumanTaskUi.UiTemplateProperty): void;
    get uiTemplateInput(): AwsSagemakerHumanTaskUi.UiTemplateProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsSagemakerHumanTaskUiUiTemplatePropertyToTerraform(struct?: AwsSagemakerHumanTaskUi.UiTemplatePropertyOutputReference | AwsSagemakerHumanTaskUi.UiTemplateProperty): any;
export declare function awsSagemakerHumanTaskUiUiTemplatePropertyToHclTerraform(struct?: AwsSagemakerHumanTaskUi.UiTemplatePropertyOutputReference | AwsSagemakerHumanTaskUi.UiTemplateProperty): any;
export declare namespace AwsSagemakerHumanTaskUi {
    interface UiTemplateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_human_task_ui#content AwsSagemakerHumanTaskUi#content}
        */
        readonly content?: string;
    }
    class UiTemplatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UiTemplateProperty | undefined;
        set internalValue(value: UiTemplateProperty | undefined);
        private _content?;
        get content(): string;
        set content(value: string);
        resetContent(): void;
        get contentInput(): string | undefined;
        get contentSha256(): string;
        get url(): string;
    }
}
