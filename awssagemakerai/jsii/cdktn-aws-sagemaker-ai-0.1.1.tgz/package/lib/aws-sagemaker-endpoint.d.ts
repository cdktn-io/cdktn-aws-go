import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSagemakerEndpointConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#endpoint_config_name AwsSagemakerEndpoint#endpoint_config_name}
    */
    readonly endpointConfigName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#id AwsSagemakerEndpoint#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#name AwsSagemakerEndpoint#name}
    */
    readonly name?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#region AwsSagemakerEndpoint#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#tags AwsSagemakerEndpoint#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#tags_all AwsSagemakerEndpoint#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * deployment_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#deployment_config AwsSagemakerEndpoint#deployment_config}
    */
    readonly deploymentConfig?: AwsSagemakerEndpoint.DeploymentConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint aws_sagemaker_endpoint}
*/
export declare class AwsSagemakerEndpoint extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_sagemaker_endpoint";
    /**
    * Generates CDKTN code for importing a AwsSagemakerEndpoint resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSagemakerEndpoint to import
    * @param importFromId The id of the existing AwsSagemakerEndpoint that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSagemakerEndpoint to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint aws_sagemaker_endpoint} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSagemakerEndpointConfig
    */
    constructor(scope: Construct, id: string, config: AwsSagemakerEndpointConfig);
    get arn(): string;
    private _endpointConfigName?;
    get endpointConfigName(): string;
    set endpointConfigName(value: string);
    get endpointConfigNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _deploymentConfig;
    get deploymentConfig(): AwsSagemakerEndpoint.DeploymentConfigPropertyOutputReference;
    putDeploymentConfig(value: AwsSagemakerEndpoint.DeploymentConfigProperty): void;
    resetDeploymentConfig(): void;
    get deploymentConfigInput(): AwsSagemakerEndpoint.DeploymentConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsSagemakerEndpointAlarmsPropertyToTerraform(struct?: AwsSagemakerEndpoint.AlarmsProperty | cdktn.IResolvable): any;
export declare function awsSagemakerEndpointAlarmsPropertyToHclTerraform(struct?: AwsSagemakerEndpoint.AlarmsProperty | cdktn.IResolvable): any;
export declare function awsSagemakerEndpointAutoRollbackConfigurationPropertyToTerraform(struct?: AwsSagemakerEndpoint.AutoRollbackConfigurationPropertyOutputReference | AwsSagemakerEndpoint.AutoRollbackConfigurationProperty): any;
export declare function awsSagemakerEndpointAutoRollbackConfigurationPropertyToHclTerraform(struct?: AwsSagemakerEndpoint.AutoRollbackConfigurationPropertyOutputReference | AwsSagemakerEndpoint.AutoRollbackConfigurationProperty): any;
export declare function awsSagemakerEndpointCanarySizePropertyToTerraform(struct?: AwsSagemakerEndpoint.CanarySizePropertyOutputReference | AwsSagemakerEndpoint.CanarySizeProperty): any;
export declare function awsSagemakerEndpointCanarySizePropertyToHclTerraform(struct?: AwsSagemakerEndpoint.CanarySizePropertyOutputReference | AwsSagemakerEndpoint.CanarySizeProperty): any;
export declare function awsSagemakerEndpointLinearStepSizePropertyToTerraform(struct?: AwsSagemakerEndpoint.LinearStepSizePropertyOutputReference | AwsSagemakerEndpoint.LinearStepSizeProperty): any;
export declare function awsSagemakerEndpointLinearStepSizePropertyToHclTerraform(struct?: AwsSagemakerEndpoint.LinearStepSizePropertyOutputReference | AwsSagemakerEndpoint.LinearStepSizeProperty): any;
export declare function awsSagemakerEndpointTrafficRoutingConfigurationPropertyToTerraform(struct?: AwsSagemakerEndpoint.TrafficRoutingConfigurationPropertyOutputReference | AwsSagemakerEndpoint.TrafficRoutingConfigurationProperty): any;
export declare function awsSagemakerEndpointTrafficRoutingConfigurationPropertyToHclTerraform(struct?: AwsSagemakerEndpoint.TrafficRoutingConfigurationPropertyOutputReference | AwsSagemakerEndpoint.TrafficRoutingConfigurationProperty): any;
export declare function awsSagemakerEndpointBlueGreenUpdatePolicyPropertyToTerraform(struct?: AwsSagemakerEndpoint.BlueGreenUpdatePolicyPropertyOutputReference | AwsSagemakerEndpoint.BlueGreenUpdatePolicyProperty): any;
export declare function awsSagemakerEndpointBlueGreenUpdatePolicyPropertyToHclTerraform(struct?: AwsSagemakerEndpoint.BlueGreenUpdatePolicyPropertyOutputReference | AwsSagemakerEndpoint.BlueGreenUpdatePolicyProperty): any;
export declare function awsSagemakerEndpointMaximumBatchSizePropertyToTerraform(struct?: AwsSagemakerEndpoint.MaximumBatchSizePropertyOutputReference | AwsSagemakerEndpoint.MaximumBatchSizeProperty): any;
export declare function awsSagemakerEndpointMaximumBatchSizePropertyToHclTerraform(struct?: AwsSagemakerEndpoint.MaximumBatchSizePropertyOutputReference | AwsSagemakerEndpoint.MaximumBatchSizeProperty): any;
export declare function awsSagemakerEndpointRollbackMaximumBatchSizePropertyToTerraform(struct?: AwsSagemakerEndpoint.RollbackMaximumBatchSizePropertyOutputReference | AwsSagemakerEndpoint.RollbackMaximumBatchSizeProperty): any;
export declare function awsSagemakerEndpointRollbackMaximumBatchSizePropertyToHclTerraform(struct?: AwsSagemakerEndpoint.RollbackMaximumBatchSizePropertyOutputReference | AwsSagemakerEndpoint.RollbackMaximumBatchSizeProperty): any;
export declare function awsSagemakerEndpointRollingUpdatePolicyPropertyToTerraform(struct?: AwsSagemakerEndpoint.RollingUpdatePolicyPropertyOutputReference | AwsSagemakerEndpoint.RollingUpdatePolicyProperty): any;
export declare function awsSagemakerEndpointRollingUpdatePolicyPropertyToHclTerraform(struct?: AwsSagemakerEndpoint.RollingUpdatePolicyPropertyOutputReference | AwsSagemakerEndpoint.RollingUpdatePolicyProperty): any;
export declare function awsSagemakerEndpointDeploymentConfigPropertyToTerraform(struct?: AwsSagemakerEndpoint.DeploymentConfigPropertyOutputReference | AwsSagemakerEndpoint.DeploymentConfigProperty): any;
export declare function awsSagemakerEndpointDeploymentConfigPropertyToHclTerraform(struct?: AwsSagemakerEndpoint.DeploymentConfigPropertyOutputReference | AwsSagemakerEndpoint.DeploymentConfigProperty): any;
export declare namespace AwsSagemakerEndpoint {
    interface AlarmsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#alarm_name AwsSagemakerEndpoint#alarm_name}
        */
        readonly alarmName: string;
    }
    class AlarmsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AlarmsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AlarmsProperty | cdktn.IResolvable | undefined);
        private _alarmName?;
        get alarmName(): string;
        set alarmName(value: string);
        get alarmNameInput(): string | undefined;
    }
    class AlarmsPropertyList extends cdktn.ComplexList {
        internalValue?: AlarmsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AlarmsPropertyOutputReference;
    }
    interface AutoRollbackConfigurationProperty {
        /**
        * alarms block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#alarms AwsSagemakerEndpoint#alarms}
        */
        readonly alarms?: AlarmsProperty[] | cdktn.IResolvable;
    }
    class AutoRollbackConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AutoRollbackConfigurationProperty | undefined;
        set internalValue(value: AutoRollbackConfigurationProperty | undefined);
        private _alarms;
        get alarms(): AlarmsPropertyList;
        putAlarms(value: AlarmsProperty[] | cdktn.IResolvable): void;
        resetAlarms(): void;
        get alarmsInput(): cdktn.IResolvable | AlarmsProperty[] | undefined;
    }
    interface CanarySizeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#type AwsSagemakerEndpoint#type}
        */
        readonly type: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#value AwsSagemakerEndpoint#value}
        */
        readonly value: number;
    }
    class CanarySizePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CanarySizeProperty | undefined;
        set internalValue(value: CanarySizeProperty | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface LinearStepSizeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#type AwsSagemakerEndpoint#type}
        */
        readonly type: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#value AwsSagemakerEndpoint#value}
        */
        readonly value: number;
    }
    class LinearStepSizePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LinearStepSizeProperty | undefined;
        set internalValue(value: LinearStepSizeProperty | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface TrafficRoutingConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#type AwsSagemakerEndpoint#type}
        */
        readonly type: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#wait_interval_in_seconds AwsSagemakerEndpoint#wait_interval_in_seconds}
        */
        readonly waitIntervalInSeconds: number;
        /**
        * canary_size block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#canary_size AwsSagemakerEndpoint#canary_size}
        */
        readonly canarySize?: CanarySizeProperty;
        /**
        * linear_step_size block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#linear_step_size AwsSagemakerEndpoint#linear_step_size}
        */
        readonly linearStepSize?: LinearStepSizeProperty;
    }
    class TrafficRoutingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TrafficRoutingConfigurationProperty | undefined;
        set internalValue(value: TrafficRoutingConfigurationProperty | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _waitIntervalInSeconds?;
        get waitIntervalInSeconds(): number;
        set waitIntervalInSeconds(value: number);
        get waitIntervalInSecondsInput(): number | undefined;
        private _canarySize;
        get canarySize(): CanarySizePropertyOutputReference;
        putCanarySize(value: CanarySizeProperty): void;
        resetCanarySize(): void;
        get canarySizeInput(): CanarySizeProperty | undefined;
        private _linearStepSize;
        get linearStepSize(): LinearStepSizePropertyOutputReference;
        putLinearStepSize(value: LinearStepSizeProperty): void;
        resetLinearStepSize(): void;
        get linearStepSizeInput(): LinearStepSizeProperty | undefined;
    }
    interface BlueGreenUpdatePolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#maximum_execution_timeout_in_seconds AwsSagemakerEndpoint#maximum_execution_timeout_in_seconds}
        */
        readonly maximumExecutionTimeoutInSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#termination_wait_in_seconds AwsSagemakerEndpoint#termination_wait_in_seconds}
        */
        readonly terminationWaitInSeconds?: number;
        /**
        * traffic_routing_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#traffic_routing_configuration AwsSagemakerEndpoint#traffic_routing_configuration}
        */
        readonly trafficRoutingConfiguration: TrafficRoutingConfigurationProperty;
    }
    class BlueGreenUpdatePolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BlueGreenUpdatePolicyProperty | undefined;
        set internalValue(value: BlueGreenUpdatePolicyProperty | undefined);
        private _maximumExecutionTimeoutInSeconds?;
        get maximumExecutionTimeoutInSeconds(): number;
        set maximumExecutionTimeoutInSeconds(value: number);
        resetMaximumExecutionTimeoutInSeconds(): void;
        get maximumExecutionTimeoutInSecondsInput(): number | undefined;
        private _terminationWaitInSeconds?;
        get terminationWaitInSeconds(): number;
        set terminationWaitInSeconds(value: number);
        resetTerminationWaitInSeconds(): void;
        get terminationWaitInSecondsInput(): number | undefined;
        private _trafficRoutingConfiguration;
        get trafficRoutingConfiguration(): TrafficRoutingConfigurationPropertyOutputReference;
        putTrafficRoutingConfiguration(value: TrafficRoutingConfigurationProperty): void;
        get trafficRoutingConfigurationInput(): TrafficRoutingConfigurationProperty | undefined;
    }
    interface MaximumBatchSizeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#type AwsSagemakerEndpoint#type}
        */
        readonly type: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#value AwsSagemakerEndpoint#value}
        */
        readonly value: number;
    }
    class MaximumBatchSizePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MaximumBatchSizeProperty | undefined;
        set internalValue(value: MaximumBatchSizeProperty | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface RollbackMaximumBatchSizeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#type AwsSagemakerEndpoint#type}
        */
        readonly type: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#value AwsSagemakerEndpoint#value}
        */
        readonly value: number;
    }
    class RollbackMaximumBatchSizePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RollbackMaximumBatchSizeProperty | undefined;
        set internalValue(value: RollbackMaximumBatchSizeProperty | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface RollingUpdatePolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#maximum_execution_timeout_in_seconds AwsSagemakerEndpoint#maximum_execution_timeout_in_seconds}
        */
        readonly maximumExecutionTimeoutInSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#wait_interval_in_seconds AwsSagemakerEndpoint#wait_interval_in_seconds}
        */
        readonly waitIntervalInSeconds: number;
        /**
        * maximum_batch_size block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#maximum_batch_size AwsSagemakerEndpoint#maximum_batch_size}
        */
        readonly maximumBatchSize: MaximumBatchSizeProperty;
        /**
        * rollback_maximum_batch_size block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#rollback_maximum_batch_size AwsSagemakerEndpoint#rollback_maximum_batch_size}
        */
        readonly rollbackMaximumBatchSize?: RollbackMaximumBatchSizeProperty;
    }
    class RollingUpdatePolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RollingUpdatePolicyProperty | undefined;
        set internalValue(value: RollingUpdatePolicyProperty | undefined);
        private _maximumExecutionTimeoutInSeconds?;
        get maximumExecutionTimeoutInSeconds(): number;
        set maximumExecutionTimeoutInSeconds(value: number);
        resetMaximumExecutionTimeoutInSeconds(): void;
        get maximumExecutionTimeoutInSecondsInput(): number | undefined;
        private _waitIntervalInSeconds?;
        get waitIntervalInSeconds(): number;
        set waitIntervalInSeconds(value: number);
        get waitIntervalInSecondsInput(): number | undefined;
        private _maximumBatchSize;
        get maximumBatchSize(): MaximumBatchSizePropertyOutputReference;
        putMaximumBatchSize(value: MaximumBatchSizeProperty): void;
        get maximumBatchSizeInput(): MaximumBatchSizeProperty | undefined;
        private _rollbackMaximumBatchSize;
        get rollbackMaximumBatchSize(): RollbackMaximumBatchSizePropertyOutputReference;
        putRollbackMaximumBatchSize(value: RollbackMaximumBatchSizeProperty): void;
        resetRollbackMaximumBatchSize(): void;
        get rollbackMaximumBatchSizeInput(): RollbackMaximumBatchSizeProperty | undefined;
    }
    interface DeploymentConfigProperty {
        /**
        * auto_rollback_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#auto_rollback_configuration AwsSagemakerEndpoint#auto_rollback_configuration}
        */
        readonly autoRollbackConfiguration?: AutoRollbackConfigurationProperty;
        /**
        * blue_green_update_policy block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#blue_green_update_policy AwsSagemakerEndpoint#blue_green_update_policy}
        */
        readonly blueGreenUpdatePolicy?: BlueGreenUpdatePolicyProperty;
        /**
        * rolling_update_policy block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#rolling_update_policy AwsSagemakerEndpoint#rolling_update_policy}
        */
        readonly rollingUpdatePolicy?: RollingUpdatePolicyProperty;
    }
    class DeploymentConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DeploymentConfigProperty | undefined;
        set internalValue(value: DeploymentConfigProperty | undefined);
        private _autoRollbackConfiguration;
        get autoRollbackConfiguration(): AutoRollbackConfigurationPropertyOutputReference;
        putAutoRollbackConfiguration(value: AutoRollbackConfigurationProperty): void;
        resetAutoRollbackConfiguration(): void;
        get autoRollbackConfigurationInput(): AutoRollbackConfigurationProperty | undefined;
        private _blueGreenUpdatePolicy;
        get blueGreenUpdatePolicy(): BlueGreenUpdatePolicyPropertyOutputReference;
        putBlueGreenUpdatePolicy(value: BlueGreenUpdatePolicyProperty): void;
        resetBlueGreenUpdatePolicy(): void;
        get blueGreenUpdatePolicyInput(): BlueGreenUpdatePolicyProperty | undefined;
        private _rollingUpdatePolicy;
        get rollingUpdatePolicy(): RollingUpdatePolicyPropertyOutputReference;
        putRollingUpdatePolicy(value: RollingUpdatePolicyProperty): void;
        resetRollingUpdatePolicy(): void;
        get rollingUpdatePolicyInput(): RollingUpdatePolicyProperty | undefined;
    }
}
