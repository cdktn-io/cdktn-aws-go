import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSagemakerLabelingJobConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job#label_attribute_name AwsSagemakerLabelingJob#label_attribute_name}
    */
    readonly labelAttributeName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job#label_category_config_s3_uri AwsSagemakerLabelingJob#label_category_config_s3_uri}
    */
    readonly labelCategoryConfigS3Uri?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job#labeling_job_name AwsSagemakerLabelingJob#labeling_job_name}
    */
    readonly labelingJobName: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job#region AwsSagemakerLabelingJob#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job#role_arn AwsSagemakerLabelingJob#role_arn}
    */
    readonly roleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job#stopping_conditions AwsSagemakerLabelingJob#stopping_conditions}
    */
    readonly stoppingConditions?: AwsSagemakerLabelingJob.StoppingConditionsProperty[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job#tags AwsSagemakerLabelingJob#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * human_task_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job#human_task_config AwsSagemakerLabelingJob#human_task_config}
    */
    readonly humanTaskConfig?: AwsSagemakerLabelingJob.HumanTaskConfigProperty[] | cdktn.IResolvable;
    /**
    * input_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job#input_config AwsSagemakerLabelingJob#input_config}
    */
    readonly inputConfig?: AwsSagemakerLabelingJob.InputConfigProperty[] | cdktn.IResolvable;
    /**
    * labeling_job_algorithms_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job#labeling_job_algorithms_config AwsSagemakerLabelingJob#labeling_job_algorithms_config}
    */
    readonly labelingJobAlgorithmsConfig?: AwsSagemakerLabelingJob.LabelingJobAlgorithmsConfigProperty[] | cdktn.IResolvable;
    /**
    * output_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job#output_config AwsSagemakerLabelingJob#output_config}
    */
    readonly outputConfig?: AwsSagemakerLabelingJob.OutputConfigProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job aws_sagemaker_labeling_job}
*/
export declare class AwsSagemakerLabelingJob extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_sagemaker_labeling_job";
    /**
    * Generates CDKTN code for importing a AwsSagemakerLabelingJob resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSagemakerLabelingJob to import
    * @param importFromId The id of the existing AwsSagemakerLabelingJob that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSagemakerLabelingJob to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job aws_sagemaker_labeling_job} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSagemakerLabelingJobConfig
    */
    constructor(scope: Construct, id: string, config: AwsSagemakerLabelingJobConfig);
    get failureReason(): string;
    get jobReferenceCode(): string;
    private _labelAttributeName?;
    get labelAttributeName(): string;
    set labelAttributeName(value: string);
    get labelAttributeNameInput(): string | undefined;
    private _labelCategoryConfigS3Uri?;
    get labelCategoryConfigS3Uri(): string;
    set labelCategoryConfigS3Uri(value: string);
    resetLabelCategoryConfigS3Uri(): void;
    get labelCategoryConfigS3UriInput(): string | undefined;
    private _labelCounters;
    get labelCounters(): AwsSagemakerLabelingJob.LabelCountersPropertyList;
    get labelingJobArn(): string;
    private _labelingJobName?;
    get labelingJobName(): string;
    set labelingJobName(value: string);
    get labelingJobNameInput(): string | undefined;
    get labelingJobStatus(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    private _stoppingConditions;
    get stoppingConditions(): AwsSagemakerLabelingJob.StoppingConditionsPropertyList;
    putStoppingConditions(value: AwsSagemakerLabelingJob.StoppingConditionsProperty[] | cdktn.IResolvable): void;
    resetStoppingConditions(): void;
    get stoppingConditionsInput(): cdktn.IResolvable | AwsSagemakerLabelingJob.StoppingConditionsProperty[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _humanTaskConfig;
    get humanTaskConfig(): AwsSagemakerLabelingJob.HumanTaskConfigPropertyList;
    putHumanTaskConfig(value: AwsSagemakerLabelingJob.HumanTaskConfigProperty[] | cdktn.IResolvable): void;
    resetHumanTaskConfig(): void;
    get humanTaskConfigInput(): cdktn.IResolvable | AwsSagemakerLabelingJob.HumanTaskConfigProperty[] | undefined;
    private _inputConfig;
    get inputConfig(): AwsSagemakerLabelingJob.InputConfigPropertyList;
    putInputConfig(value: AwsSagemakerLabelingJob.InputConfigProperty[] | cdktn.IResolvable): void;
    resetInputConfig(): void;
    get inputConfigInput(): cdktn.IResolvable | AwsSagemakerLabelingJob.InputConfigProperty[] | undefined;
    private _labelingJobAlgorithmsConfig;
    get labelingJobAlgorithmsConfig(): AwsSagemakerLabelingJob.LabelingJobAlgorithmsConfigPropertyList;
    putLabelingJobAlgorithmsConfig(value: AwsSagemakerLabelingJob.LabelingJobAlgorithmsConfigProperty[] | cdktn.IResolvable): void;
    resetLabelingJobAlgorithmsConfig(): void;
    get labelingJobAlgorithmsConfigInput(): cdktn.IResolvable | AwsSagemakerLabelingJob.LabelingJobAlgorithmsConfigProperty[] | undefined;
    private _outputConfig;
    get outputConfig(): AwsSagemakerLabelingJob.OutputConfigPropertyList;
    putOutputConfig(value: AwsSagemakerLabelingJob.OutputConfigProperty[] | cdktn.IResolvable): void;
    resetOutputConfig(): void;
    get outputConfigInput(): cdktn.IResolvable | AwsSagemakerLabelingJob.OutputConfigProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsSagemakerLabelingJobLabelCountersPropertyToTerraform(struct?: AwsSagemakerLabelingJob.LabelCountersProperty): any;
export declare function awsSagemakerLabelingJobLabelCountersPropertyToHclTerraform(struct?: AwsSagemakerLabelingJob.LabelCountersProperty): any;
export declare function awsSagemakerLabelingJobStoppingConditionsPropertyToTerraform(struct?: AwsSagemakerLabelingJob.StoppingConditionsProperty | cdktn.IResolvable): any;
export declare function awsSagemakerLabelingJobStoppingConditionsPropertyToHclTerraform(struct?: AwsSagemakerLabelingJob.StoppingConditionsProperty | cdktn.IResolvable): any;
export declare function awsSagemakerLabelingJobAnnotationConsolidationConfigPropertyToTerraform(struct?: AwsSagemakerLabelingJob.AnnotationConsolidationConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerLabelingJobAnnotationConsolidationConfigPropertyToHclTerraform(struct?: AwsSagemakerLabelingJob.AnnotationConsolidationConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerLabelingJobAmountInUsdPropertyToTerraform(struct?: AwsSagemakerLabelingJob.AmountInUsdProperty | cdktn.IResolvable): any;
export declare function awsSagemakerLabelingJobAmountInUsdPropertyToHclTerraform(struct?: AwsSagemakerLabelingJob.AmountInUsdProperty | cdktn.IResolvable): any;
export declare function awsSagemakerLabelingJobPublicWorkforceTaskPricePropertyToTerraform(struct?: AwsSagemakerLabelingJob.PublicWorkforceTaskPriceProperty | cdktn.IResolvable): any;
export declare function awsSagemakerLabelingJobPublicWorkforceTaskPricePropertyToHclTerraform(struct?: AwsSagemakerLabelingJob.PublicWorkforceTaskPriceProperty | cdktn.IResolvable): any;
export declare function awsSagemakerLabelingJobUiConfigPropertyToTerraform(struct?: AwsSagemakerLabelingJob.UiConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerLabelingJobUiConfigPropertyToHclTerraform(struct?: AwsSagemakerLabelingJob.UiConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerLabelingJobHumanTaskConfigPropertyToTerraform(struct?: AwsSagemakerLabelingJob.HumanTaskConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerLabelingJobHumanTaskConfigPropertyToHclTerraform(struct?: AwsSagemakerLabelingJob.HumanTaskConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerLabelingJobDataAttributesPropertyToTerraform(struct?: AwsSagemakerLabelingJob.DataAttributesProperty | cdktn.IResolvable): any;
export declare function awsSagemakerLabelingJobDataAttributesPropertyToHclTerraform(struct?: AwsSagemakerLabelingJob.DataAttributesProperty | cdktn.IResolvable): any;
export declare function awsSagemakerLabelingJobS3DataSourcePropertyToTerraform(struct?: AwsSagemakerLabelingJob.S3DataSourceProperty | cdktn.IResolvable): any;
export declare function awsSagemakerLabelingJobS3DataSourcePropertyToHclTerraform(struct?: AwsSagemakerLabelingJob.S3DataSourceProperty | cdktn.IResolvable): any;
export declare function awsSagemakerLabelingJobSnsDataSourcePropertyToTerraform(struct?: AwsSagemakerLabelingJob.SnsDataSourceProperty | cdktn.IResolvable): any;
export declare function awsSagemakerLabelingJobSnsDataSourcePropertyToHclTerraform(struct?: AwsSagemakerLabelingJob.SnsDataSourceProperty | cdktn.IResolvable): any;
export declare function awsSagemakerLabelingJobDataSourcePropertyToTerraform(struct?: AwsSagemakerLabelingJob.DataSourceProperty | cdktn.IResolvable): any;
export declare function awsSagemakerLabelingJobDataSourcePropertyToHclTerraform(struct?: AwsSagemakerLabelingJob.DataSourceProperty | cdktn.IResolvable): any;
export declare function awsSagemakerLabelingJobInputConfigPropertyToTerraform(struct?: AwsSagemakerLabelingJob.InputConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerLabelingJobInputConfigPropertyToHclTerraform(struct?: AwsSagemakerLabelingJob.InputConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerLabelingJobVpcConfigPropertyToTerraform(struct?: AwsSagemakerLabelingJob.VpcConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerLabelingJobVpcConfigPropertyToHclTerraform(struct?: AwsSagemakerLabelingJob.VpcConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerLabelingJobLabelingJobResourceConfigPropertyToTerraform(struct?: AwsSagemakerLabelingJob.LabelingJobResourceConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerLabelingJobLabelingJobResourceConfigPropertyToHclTerraform(struct?: AwsSagemakerLabelingJob.LabelingJobResourceConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerLabelingJobLabelingJobAlgorithmsConfigPropertyToTerraform(struct?: AwsSagemakerLabelingJob.LabelingJobAlgorithmsConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerLabelingJobLabelingJobAlgorithmsConfigPropertyToHclTerraform(struct?: AwsSagemakerLabelingJob.LabelingJobAlgorithmsConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerLabelingJobOutputConfigPropertyToTerraform(struct?: AwsSagemakerLabelingJob.OutputConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerLabelingJobOutputConfigPropertyToHclTerraform(struct?: AwsSagemakerLabelingJob.OutputConfigProperty | cdktn.IResolvable): any;
export declare namespace AwsSagemakerLabelingJob {
    interface LabelCountersProperty {
    }
    class LabelCountersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LabelCountersProperty | undefined;
        set internalValue(value: LabelCountersProperty | undefined);
        get failedNonRetryableError(): number;
        get humanLabeled(): number;
        get machineLabeled(): number;
        get totalLabeled(): number;
        get unlabeled(): number;
    }
    class LabelCountersPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LabelCountersPropertyOutputReference;
    }
    interface StoppingConditionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job#max_human_labeled_object_count AwsSagemakerLabelingJob#max_human_labeled_object_count}
        */
        readonly maxHumanLabeledObjectCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job#max_percentage_of_input_dataset_labeled AwsSagemakerLabelingJob#max_percentage_of_input_dataset_labeled}
        */
        readonly maxPercentageOfInputDatasetLabeled?: number;
    }
    class StoppingConditionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StoppingConditionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StoppingConditionsProperty | cdktn.IResolvable | undefined);
        private _maxHumanLabeledObjectCount?;
        get maxHumanLabeledObjectCount(): number;
        set maxHumanLabeledObjectCount(value: number);
        resetMaxHumanLabeledObjectCount(): void;
        get maxHumanLabeledObjectCountInput(): number | undefined;
        private _maxPercentageOfInputDatasetLabeled?;
        get maxPercentageOfInputDatasetLabeled(): number;
        set maxPercentageOfInputDatasetLabeled(value: number);
        resetMaxPercentageOfInputDatasetLabeled(): void;
        get maxPercentageOfInputDatasetLabeledInput(): number | undefined;
    }
    class StoppingConditionsPropertyList extends cdktn.ComplexList {
        internalValue?: StoppingConditionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StoppingConditionsPropertyOutputReference;
    }
    interface AnnotationConsolidationConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job#annotation_consolidation_lambda_arn AwsSagemakerLabelingJob#annotation_consolidation_lambda_arn}
        */
        readonly annotationConsolidationLambdaArn: string;
    }
    class AnnotationConsolidationConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AnnotationConsolidationConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AnnotationConsolidationConfigProperty | cdktn.IResolvable | undefined);
        private _annotationConsolidationLambdaArn?;
        get annotationConsolidationLambdaArn(): string;
        set annotationConsolidationLambdaArn(value: string);
        get annotationConsolidationLambdaArnInput(): string | undefined;
    }
    class AnnotationConsolidationConfigPropertyList extends cdktn.ComplexList {
        internalValue?: AnnotationConsolidationConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AnnotationConsolidationConfigPropertyOutputReference;
    }
    interface AmountInUsdProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job#cents AwsSagemakerLabelingJob#cents}
        */
        readonly cents?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job#dollars AwsSagemakerLabelingJob#dollars}
        */
        readonly dollars?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job#tenth_fractions_of_a_cent AwsSagemakerLabelingJob#tenth_fractions_of_a_cent}
        */
        readonly tenthFractionsOfACent?: number;
    }
    class AmountInUsdPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AmountInUsdProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AmountInUsdProperty | cdktn.IResolvable | undefined);
        private _cents?;
        get cents(): number;
        set cents(value: number);
        resetCents(): void;
        get centsInput(): number | undefined;
        private _dollars?;
        get dollars(): number;
        set dollars(value: number);
        resetDollars(): void;
        get dollarsInput(): number | undefined;
        private _tenthFractionsOfACent?;
        get tenthFractionsOfACent(): number;
        set tenthFractionsOfACent(value: number);
        resetTenthFractionsOfACent(): void;
        get tenthFractionsOfACentInput(): number | undefined;
    }
    class AmountInUsdPropertyList extends cdktn.ComplexList {
        internalValue?: AmountInUsdProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AmountInUsdPropertyOutputReference;
    }
    interface PublicWorkforceTaskPriceProperty {
        /**
        * amount_in_usd block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job#amount_in_usd AwsSagemakerLabelingJob#amount_in_usd}
        */
        readonly amountInUsd?: AmountInUsdProperty[] | cdktn.IResolvable;
    }
    class PublicWorkforceTaskPricePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PublicWorkforceTaskPriceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PublicWorkforceTaskPriceProperty | cdktn.IResolvable | undefined);
        private _amountInUsd;
        get amountInUsd(): AmountInUsdPropertyList;
        putAmountInUsd(value: AmountInUsdProperty[] | cdktn.IResolvable): void;
        resetAmountInUsd(): void;
        get amountInUsdInput(): cdktn.IResolvable | AmountInUsdProperty[] | undefined;
    }
    class PublicWorkforceTaskPricePropertyList extends cdktn.ComplexList {
        internalValue?: PublicWorkforceTaskPriceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PublicWorkforceTaskPricePropertyOutputReference;
    }
    interface UiConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job#human_task_ui_arn AwsSagemakerLabelingJob#human_task_ui_arn}
        */
        readonly humanTaskUiArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job#ui_template_s3_uri AwsSagemakerLabelingJob#ui_template_s3_uri}
        */
        readonly uiTemplateS3Uri?: string;
    }
    class UiConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): UiConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: UiConfigProperty | cdktn.IResolvable | undefined);
        private _humanTaskUiArn?;
        get humanTaskUiArn(): string;
        set humanTaskUiArn(value: string);
        resetHumanTaskUiArn(): void;
        get humanTaskUiArnInput(): string | undefined;
        private _uiTemplateS3Uri?;
        get uiTemplateS3Uri(): string;
        set uiTemplateS3Uri(value: string);
        resetUiTemplateS3Uri(): void;
        get uiTemplateS3UriInput(): string | undefined;
    }
    class UiConfigPropertyList extends cdktn.ComplexList {
        internalValue?: UiConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): UiConfigPropertyOutputReference;
    }
    interface HumanTaskConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job#max_concurrent_task_count AwsSagemakerLabelingJob#max_concurrent_task_count}
        */
        readonly maxConcurrentTaskCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job#number_of_human_workers_per_data_object AwsSagemakerLabelingJob#number_of_human_workers_per_data_object}
        */
        readonly numberOfHumanWorkersPerDataObject: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job#pre_human_task_lambda_arn AwsSagemakerLabelingJob#pre_human_task_lambda_arn}
        */
        readonly preHumanTaskLambdaArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job#task_availability_lifetime_in_seconds AwsSagemakerLabelingJob#task_availability_lifetime_in_seconds}
        */
        readonly taskAvailabilityLifetimeInSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job#task_description AwsSagemakerLabelingJob#task_description}
        */
        readonly taskDescription: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job#task_keywords AwsSagemakerLabelingJob#task_keywords}
        */
        readonly taskKeywords?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job#task_time_limit_in_seconds AwsSagemakerLabelingJob#task_time_limit_in_seconds}
        */
        readonly taskTimeLimitInSeconds: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job#task_title AwsSagemakerLabelingJob#task_title}
        */
        readonly taskTitle: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job#workteam_arn AwsSagemakerLabelingJob#workteam_arn}
        */
        readonly workteamArn: string;
        /**
        * annotation_consolidation_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job#annotation_consolidation_config AwsSagemakerLabelingJob#annotation_consolidation_config}
        */
        readonly annotationConsolidationConfig?: AnnotationConsolidationConfigProperty[] | cdktn.IResolvable;
        /**
        * public_workforce_task_price block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job#public_workforce_task_price AwsSagemakerLabelingJob#public_workforce_task_price}
        */
        readonly publicWorkforceTaskPrice?: PublicWorkforceTaskPriceProperty[] | cdktn.IResolvable;
        /**
        * ui_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job#ui_config AwsSagemakerLabelingJob#ui_config}
        */
        readonly uiConfig?: UiConfigProperty[] | cdktn.IResolvable;
    }
    class HumanTaskConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HumanTaskConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: HumanTaskConfigProperty | cdktn.IResolvable | undefined);
        private _maxConcurrentTaskCount?;
        get maxConcurrentTaskCount(): number;
        set maxConcurrentTaskCount(value: number);
        resetMaxConcurrentTaskCount(): void;
        get maxConcurrentTaskCountInput(): number | undefined;
        private _numberOfHumanWorkersPerDataObject?;
        get numberOfHumanWorkersPerDataObject(): number;
        set numberOfHumanWorkersPerDataObject(value: number);
        get numberOfHumanWorkersPerDataObjectInput(): number | undefined;
        private _preHumanTaskLambdaArn?;
        get preHumanTaskLambdaArn(): string;
        set preHumanTaskLambdaArn(value: string);
        resetPreHumanTaskLambdaArn(): void;
        get preHumanTaskLambdaArnInput(): string | undefined;
        private _taskAvailabilityLifetimeInSeconds?;
        get taskAvailabilityLifetimeInSeconds(): number;
        set taskAvailabilityLifetimeInSeconds(value: number);
        resetTaskAvailabilityLifetimeInSeconds(): void;
        get taskAvailabilityLifetimeInSecondsInput(): number | undefined;
        private _taskDescription?;
        get taskDescription(): string;
        set taskDescription(value: string);
        get taskDescriptionInput(): string | undefined;
        private _taskKeywords?;
        get taskKeywords(): string[];
        set taskKeywords(value: string[]);
        resetTaskKeywords(): void;
        get taskKeywordsInput(): string[] | undefined;
        private _taskTimeLimitInSeconds?;
        get taskTimeLimitInSeconds(): number;
        set taskTimeLimitInSeconds(value: number);
        get taskTimeLimitInSecondsInput(): number | undefined;
        private _taskTitle?;
        get taskTitle(): string;
        set taskTitle(value: string);
        get taskTitleInput(): string | undefined;
        private _workteamArn?;
        get workteamArn(): string;
        set workteamArn(value: string);
        get workteamArnInput(): string | undefined;
        private _annotationConsolidationConfig;
        get annotationConsolidationConfig(): AnnotationConsolidationConfigPropertyList;
        putAnnotationConsolidationConfig(value: AnnotationConsolidationConfigProperty[] | cdktn.IResolvable): void;
        resetAnnotationConsolidationConfig(): void;
        get annotationConsolidationConfigInput(): cdktn.IResolvable | AnnotationConsolidationConfigProperty[] | undefined;
        private _publicWorkforceTaskPrice;
        get publicWorkforceTaskPrice(): PublicWorkforceTaskPricePropertyList;
        putPublicWorkforceTaskPrice(value: PublicWorkforceTaskPriceProperty[] | cdktn.IResolvable): void;
        resetPublicWorkforceTaskPrice(): void;
        get publicWorkforceTaskPriceInput(): cdktn.IResolvable | PublicWorkforceTaskPriceProperty[] | undefined;
        private _uiConfig;
        get uiConfig(): UiConfigPropertyList;
        putUiConfig(value: UiConfigProperty[] | cdktn.IResolvable): void;
        resetUiConfig(): void;
        get uiConfigInput(): cdktn.IResolvable | UiConfigProperty[] | undefined;
    }
    class HumanTaskConfigPropertyList extends cdktn.ComplexList {
        internalValue?: HumanTaskConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HumanTaskConfigPropertyOutputReference;
    }
    interface DataAttributesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job#content_classifiers AwsSagemakerLabelingJob#content_classifiers}
        */
        readonly contentClassifiers?: string[];
    }
    class DataAttributesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataAttributesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DataAttributesProperty | cdktn.IResolvable | undefined);
        private _contentClassifiers?;
        get contentClassifiers(): string[];
        set contentClassifiers(value: string[]);
        resetContentClassifiers(): void;
        get contentClassifiersInput(): string[] | undefined;
    }
    class DataAttributesPropertyList extends cdktn.ComplexList {
        internalValue?: DataAttributesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataAttributesPropertyOutputReference;
    }
    interface S3DataSourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job#manifest_s3_uri AwsSagemakerLabelingJob#manifest_s3_uri}
        */
        readonly manifestS3Uri: string;
    }
    class S3DataSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3DataSourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: S3DataSourceProperty | cdktn.IResolvable | undefined);
        private _manifestS3Uri?;
        get manifestS3Uri(): string;
        set manifestS3Uri(value: string);
        get manifestS3UriInput(): string | undefined;
    }
    class S3DataSourcePropertyList extends cdktn.ComplexList {
        internalValue?: S3DataSourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3DataSourcePropertyOutputReference;
    }
    interface SnsDataSourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job#sns_topic_arn AwsSagemakerLabelingJob#sns_topic_arn}
        */
        readonly snsTopicArn: string;
    }
    class SnsDataSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SnsDataSourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SnsDataSourceProperty | cdktn.IResolvable | undefined);
        private _snsTopicArn?;
        get snsTopicArn(): string;
        set snsTopicArn(value: string);
        get snsTopicArnInput(): string | undefined;
    }
    class SnsDataSourcePropertyList extends cdktn.ComplexList {
        internalValue?: SnsDataSourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SnsDataSourcePropertyOutputReference;
    }
    interface DataSourceProperty {
        /**
        * s3_data_source block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job#s3_data_source AwsSagemakerLabelingJob#s3_data_source}
        */
        readonly s3DataSource?: S3DataSourceProperty[] | cdktn.IResolvable;
        /**
        * sns_data_source block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job#sns_data_source AwsSagemakerLabelingJob#sns_data_source}
        */
        readonly snsDataSource?: SnsDataSourceProperty[] | cdktn.IResolvable;
    }
    class DataSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataSourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DataSourceProperty | cdktn.IResolvable | undefined);
        private _s3DataSource;
        get s3DataSource(): S3DataSourcePropertyList;
        putS3DataSource(value: S3DataSourceProperty[] | cdktn.IResolvable): void;
        resetS3DataSource(): void;
        get s3DataSourceInput(): cdktn.IResolvable | S3DataSourceProperty[] | undefined;
        private _snsDataSource;
        get snsDataSource(): SnsDataSourcePropertyList;
        putSnsDataSource(value: SnsDataSourceProperty[] | cdktn.IResolvable): void;
        resetSnsDataSource(): void;
        get snsDataSourceInput(): cdktn.IResolvable | SnsDataSourceProperty[] | undefined;
    }
    class DataSourcePropertyList extends cdktn.ComplexList {
        internalValue?: DataSourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataSourcePropertyOutputReference;
    }
    interface InputConfigProperty {
        /**
        * data_attributes block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job#data_attributes AwsSagemakerLabelingJob#data_attributes}
        */
        readonly dataAttributes?: DataAttributesProperty[] | cdktn.IResolvable;
        /**
        * data_source block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job#data_source AwsSagemakerLabelingJob#data_source}
        */
        readonly dataSource?: DataSourceProperty[] | cdktn.IResolvable;
    }
    class InputConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InputConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InputConfigProperty | cdktn.IResolvable | undefined);
        private _dataAttributes;
        get dataAttributes(): DataAttributesPropertyList;
        putDataAttributes(value: DataAttributesProperty[] | cdktn.IResolvable): void;
        resetDataAttributes(): void;
        get dataAttributesInput(): cdktn.IResolvable | DataAttributesProperty[] | undefined;
        private _dataSource;
        get dataSource(): DataSourcePropertyList;
        putDataSource(value: DataSourceProperty[] | cdktn.IResolvable): void;
        resetDataSource(): void;
        get dataSourceInput(): cdktn.IResolvable | DataSourceProperty[] | undefined;
    }
    class InputConfigPropertyList extends cdktn.ComplexList {
        internalValue?: InputConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InputConfigPropertyOutputReference;
    }
    interface VpcConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job#security_group_ids AwsSagemakerLabelingJob#security_group_ids}
        */
        readonly securityGroupIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job#subnets AwsSagemakerLabelingJob#subnets}
        */
        readonly subnets: string[];
    }
    class VpcConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VpcConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VpcConfigProperty | cdktn.IResolvable | undefined);
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        get securityGroupIdsInput(): string[] | undefined;
        private _subnets?;
        get subnets(): string[];
        set subnets(value: string[]);
        get subnetsInput(): string[] | undefined;
    }
    class VpcConfigPropertyList extends cdktn.ComplexList {
        internalValue?: VpcConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VpcConfigPropertyOutputReference;
    }
    interface LabelingJobResourceConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job#volume_kms_key_id AwsSagemakerLabelingJob#volume_kms_key_id}
        */
        readonly volumeKmsKeyId?: string;
        /**
        * vpc_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job#vpc_config AwsSagemakerLabelingJob#vpc_config}
        */
        readonly vpcConfig?: VpcConfigProperty[] | cdktn.IResolvable;
    }
    class LabelingJobResourceConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LabelingJobResourceConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LabelingJobResourceConfigProperty | cdktn.IResolvable | undefined);
        private _volumeKmsKeyId?;
        get volumeKmsKeyId(): string;
        set volumeKmsKeyId(value: string);
        resetVolumeKmsKeyId(): void;
        get volumeKmsKeyIdInput(): string | undefined;
        private _vpcConfig;
        get vpcConfig(): VpcConfigPropertyList;
        putVpcConfig(value: VpcConfigProperty[] | cdktn.IResolvable): void;
        resetVpcConfig(): void;
        get vpcConfigInput(): cdktn.IResolvable | VpcConfigProperty[] | undefined;
    }
    class LabelingJobResourceConfigPropertyList extends cdktn.ComplexList {
        internalValue?: LabelingJobResourceConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LabelingJobResourceConfigPropertyOutputReference;
    }
    interface LabelingJobAlgorithmsConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job#initial_active_learning_model_arn AwsSagemakerLabelingJob#initial_active_learning_model_arn}
        */
        readonly initialActiveLearningModelArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job#labeling_job_algorithm_specification_arn AwsSagemakerLabelingJob#labeling_job_algorithm_specification_arn}
        */
        readonly labelingJobAlgorithmSpecificationArn: string;
        /**
        * labeling_job_resource_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job#labeling_job_resource_config AwsSagemakerLabelingJob#labeling_job_resource_config}
        */
        readonly labelingJobResourceConfig?: LabelingJobResourceConfigProperty[] | cdktn.IResolvable;
    }
    class LabelingJobAlgorithmsConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LabelingJobAlgorithmsConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LabelingJobAlgorithmsConfigProperty | cdktn.IResolvable | undefined);
        private _initialActiveLearningModelArn?;
        get initialActiveLearningModelArn(): string;
        set initialActiveLearningModelArn(value: string);
        resetInitialActiveLearningModelArn(): void;
        get initialActiveLearningModelArnInput(): string | undefined;
        private _labelingJobAlgorithmSpecificationArn?;
        get labelingJobAlgorithmSpecificationArn(): string;
        set labelingJobAlgorithmSpecificationArn(value: string);
        get labelingJobAlgorithmSpecificationArnInput(): string | undefined;
        private _labelingJobResourceConfig;
        get labelingJobResourceConfig(): LabelingJobResourceConfigPropertyList;
        putLabelingJobResourceConfig(value: LabelingJobResourceConfigProperty[] | cdktn.IResolvable): void;
        resetLabelingJobResourceConfig(): void;
        get labelingJobResourceConfigInput(): cdktn.IResolvable | LabelingJobResourceConfigProperty[] | undefined;
    }
    class LabelingJobAlgorithmsConfigPropertyList extends cdktn.ComplexList {
        internalValue?: LabelingJobAlgorithmsConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LabelingJobAlgorithmsConfigPropertyOutputReference;
    }
    interface OutputConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job#kms_key_id AwsSagemakerLabelingJob#kms_key_id}
        */
        readonly kmsKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job#s3_output_path AwsSagemakerLabelingJob#s3_output_path}
        */
        readonly s3OutputPath: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_labeling_job#sns_topic_arn AwsSagemakerLabelingJob#sns_topic_arn}
        */
        readonly snsTopicArn?: string;
    }
    class OutputConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OutputConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OutputConfigProperty | cdktn.IResolvable | undefined);
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        resetKmsKeyId(): void;
        get kmsKeyIdInput(): string | undefined;
        private _s3OutputPath?;
        get s3OutputPath(): string;
        set s3OutputPath(value: string);
        get s3OutputPathInput(): string | undefined;
        private _snsTopicArn?;
        get snsTopicArn(): string;
        set snsTopicArn(value: string);
        resetSnsTopicArn(): void;
        get snsTopicArnInput(): string | undefined;
    }
    class OutputConfigPropertyList extends cdktn.ComplexList {
        internalValue?: OutputConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OutputConfigPropertyOutputReference;
    }
}
