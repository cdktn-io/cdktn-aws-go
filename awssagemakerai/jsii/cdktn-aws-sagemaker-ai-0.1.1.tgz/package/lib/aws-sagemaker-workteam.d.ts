import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSagemakerWorkteamConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workteam#description AwsSagemakerWorkteam#description}
    */
    readonly description: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workteam#id AwsSagemakerWorkteam#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workteam#region AwsSagemakerWorkteam#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workteam#tags AwsSagemakerWorkteam#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workteam#tags_all AwsSagemakerWorkteam#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workteam#workforce_name AwsSagemakerWorkteam#workforce_name}
    */
    readonly workforceName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workteam#workteam_name AwsSagemakerWorkteam#workteam_name}
    */
    readonly workteamName: string;
    /**
    * member_definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workteam#member_definition AwsSagemakerWorkteam#member_definition}
    */
    readonly memberDefinition: AwsSagemakerWorkteam.MemberDefinitionProperty[] | cdktn.IResolvable;
    /**
    * notification_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workteam#notification_configuration AwsSagemakerWorkteam#notification_configuration}
    */
    readonly notificationConfiguration?: AwsSagemakerWorkteam.NotificationConfigurationProperty;
    /**
    * worker_access_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workteam#worker_access_configuration AwsSagemakerWorkteam#worker_access_configuration}
    */
    readonly workerAccessConfiguration?: AwsSagemakerWorkteam.WorkerAccessConfigurationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workteam aws_sagemaker_workteam}
*/
export declare class AwsSagemakerWorkteam extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_sagemaker_workteam";
    /**
    * Generates CDKTN code for importing a AwsSagemakerWorkteam resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSagemakerWorkteam to import
    * @param importFromId The id of the existing AwsSagemakerWorkteam that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workteam#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSagemakerWorkteam to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workteam aws_sagemaker_workteam} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSagemakerWorkteamConfig
    */
    constructor(scope: Construct, id: string, config: AwsSagemakerWorkteamConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get subdomain(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _workforceName?;
    get workforceName(): string;
    set workforceName(value: string);
    resetWorkforceName(): void;
    get workforceNameInput(): string | undefined;
    private _workteamName?;
    get workteamName(): string;
    set workteamName(value: string);
    get workteamNameInput(): string | undefined;
    private _memberDefinition;
    get memberDefinition(): AwsSagemakerWorkteam.MemberDefinitionPropertyList;
    putMemberDefinition(value: AwsSagemakerWorkteam.MemberDefinitionProperty[] | cdktn.IResolvable): void;
    get memberDefinitionInput(): cdktn.IResolvable | AwsSagemakerWorkteam.MemberDefinitionProperty[] | undefined;
    private _notificationConfiguration;
    get notificationConfiguration(): AwsSagemakerWorkteam.NotificationConfigurationPropertyOutputReference;
    putNotificationConfiguration(value: AwsSagemakerWorkteam.NotificationConfigurationProperty): void;
    resetNotificationConfiguration(): void;
    get notificationConfigurationInput(): AwsSagemakerWorkteam.NotificationConfigurationProperty | undefined;
    private _workerAccessConfiguration;
    get workerAccessConfiguration(): AwsSagemakerWorkteam.WorkerAccessConfigurationPropertyOutputReference;
    putWorkerAccessConfiguration(value: AwsSagemakerWorkteam.WorkerAccessConfigurationProperty): void;
    resetWorkerAccessConfiguration(): void;
    get workerAccessConfigurationInput(): AwsSagemakerWorkteam.WorkerAccessConfigurationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsSagemakerWorkteamCognitoMemberDefinitionPropertyToTerraform(struct?: AwsSagemakerWorkteam.CognitoMemberDefinitionPropertyOutputReference | AwsSagemakerWorkteam.CognitoMemberDefinitionProperty): any;
export declare function awsSagemakerWorkteamCognitoMemberDefinitionPropertyToHclTerraform(struct?: AwsSagemakerWorkteam.CognitoMemberDefinitionPropertyOutputReference | AwsSagemakerWorkteam.CognitoMemberDefinitionProperty): any;
export declare function awsSagemakerWorkteamOidcMemberDefinitionPropertyToTerraform(struct?: AwsSagemakerWorkteam.OidcMemberDefinitionPropertyOutputReference | AwsSagemakerWorkteam.OidcMemberDefinitionProperty): any;
export declare function awsSagemakerWorkteamOidcMemberDefinitionPropertyToHclTerraform(struct?: AwsSagemakerWorkteam.OidcMemberDefinitionPropertyOutputReference | AwsSagemakerWorkteam.OidcMemberDefinitionProperty): any;
export declare function awsSagemakerWorkteamMemberDefinitionPropertyToTerraform(struct?: AwsSagemakerWorkteam.MemberDefinitionProperty | cdktn.IResolvable): any;
export declare function awsSagemakerWorkteamMemberDefinitionPropertyToHclTerraform(struct?: AwsSagemakerWorkteam.MemberDefinitionProperty | cdktn.IResolvable): any;
export declare function awsSagemakerWorkteamNotificationConfigurationPropertyToTerraform(struct?: AwsSagemakerWorkteam.NotificationConfigurationPropertyOutputReference | AwsSagemakerWorkteam.NotificationConfigurationProperty): any;
export declare function awsSagemakerWorkteamNotificationConfigurationPropertyToHclTerraform(struct?: AwsSagemakerWorkteam.NotificationConfigurationPropertyOutputReference | AwsSagemakerWorkteam.NotificationConfigurationProperty): any;
export declare function awsSagemakerWorkteamIamPolicyConstraintsPropertyToTerraform(struct?: AwsSagemakerWorkteam.IamPolicyConstraintsPropertyOutputReference | AwsSagemakerWorkteam.IamPolicyConstraintsProperty): any;
export declare function awsSagemakerWorkteamIamPolicyConstraintsPropertyToHclTerraform(struct?: AwsSagemakerWorkteam.IamPolicyConstraintsPropertyOutputReference | AwsSagemakerWorkteam.IamPolicyConstraintsProperty): any;
export declare function awsSagemakerWorkteamS3PresignPropertyToTerraform(struct?: AwsSagemakerWorkteam.S3PresignPropertyOutputReference | AwsSagemakerWorkteam.S3PresignProperty): any;
export declare function awsSagemakerWorkteamS3PresignPropertyToHclTerraform(struct?: AwsSagemakerWorkteam.S3PresignPropertyOutputReference | AwsSagemakerWorkteam.S3PresignProperty): any;
export declare function awsSagemakerWorkteamWorkerAccessConfigurationPropertyToTerraform(struct?: AwsSagemakerWorkteam.WorkerAccessConfigurationPropertyOutputReference | AwsSagemakerWorkteam.WorkerAccessConfigurationProperty): any;
export declare function awsSagemakerWorkteamWorkerAccessConfigurationPropertyToHclTerraform(struct?: AwsSagemakerWorkteam.WorkerAccessConfigurationPropertyOutputReference | AwsSagemakerWorkteam.WorkerAccessConfigurationProperty): any;
export declare namespace AwsSagemakerWorkteam {
    interface CognitoMemberDefinitionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workteam#client_id AwsSagemakerWorkteam#client_id}
        */
        readonly clientId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workteam#user_group AwsSagemakerWorkteam#user_group}
        */
        readonly userGroup: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workteam#user_pool AwsSagemakerWorkteam#user_pool}
        */
        readonly userPool: string;
    }
    class CognitoMemberDefinitionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CognitoMemberDefinitionProperty | undefined;
        set internalValue(value: CognitoMemberDefinitionProperty | undefined);
        private _clientId?;
        get clientId(): string;
        set clientId(value: string);
        get clientIdInput(): string | undefined;
        private _userGroup?;
        get userGroup(): string;
        set userGroup(value: string);
        get userGroupInput(): string | undefined;
        private _userPool?;
        get userPool(): string;
        set userPool(value: string);
        get userPoolInput(): string | undefined;
    }
    interface OidcMemberDefinitionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workteam#groups AwsSagemakerWorkteam#groups}
        */
        readonly groups: string[];
    }
    class OidcMemberDefinitionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OidcMemberDefinitionProperty | undefined;
        set internalValue(value: OidcMemberDefinitionProperty | undefined);
        private _groups?;
        get groups(): string[];
        set groups(value: string[]);
        get groupsInput(): string[] | undefined;
    }
    interface MemberDefinitionProperty {
        /**
        * cognito_member_definition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workteam#cognito_member_definition AwsSagemakerWorkteam#cognito_member_definition}
        */
        readonly cognitoMemberDefinition?: CognitoMemberDefinitionProperty;
        /**
        * oidc_member_definition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workteam#oidc_member_definition AwsSagemakerWorkteam#oidc_member_definition}
        */
        readonly oidcMemberDefinition?: OidcMemberDefinitionProperty;
    }
    class MemberDefinitionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MemberDefinitionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MemberDefinitionProperty | cdktn.IResolvable | undefined);
        private _cognitoMemberDefinition;
        get cognitoMemberDefinition(): CognitoMemberDefinitionPropertyOutputReference;
        putCognitoMemberDefinition(value: CognitoMemberDefinitionProperty): void;
        resetCognitoMemberDefinition(): void;
        get cognitoMemberDefinitionInput(): CognitoMemberDefinitionProperty | undefined;
        private _oidcMemberDefinition;
        get oidcMemberDefinition(): OidcMemberDefinitionPropertyOutputReference;
        putOidcMemberDefinition(value: OidcMemberDefinitionProperty): void;
        resetOidcMemberDefinition(): void;
        get oidcMemberDefinitionInput(): OidcMemberDefinitionProperty | undefined;
    }
    class MemberDefinitionPropertyList extends cdktn.ComplexList {
        internalValue?: MemberDefinitionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MemberDefinitionPropertyOutputReference;
    }
    interface NotificationConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workteam#notification_topic_arn AwsSagemakerWorkteam#notification_topic_arn}
        */
        readonly notificationTopicArn?: string;
    }
    class NotificationConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NotificationConfigurationProperty | undefined;
        set internalValue(value: NotificationConfigurationProperty | undefined);
        private _notificationTopicArn?;
        get notificationTopicArn(): string;
        set notificationTopicArn(value: string);
        resetNotificationTopicArn(): void;
        get notificationTopicArnInput(): string | undefined;
    }
    interface IamPolicyConstraintsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workteam#source_ip AwsSagemakerWorkteam#source_ip}
        */
        readonly sourceIp?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workteam#vpc_source_ip AwsSagemakerWorkteam#vpc_source_ip}
        */
        readonly vpcSourceIp?: string;
    }
    class IamPolicyConstraintsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IamPolicyConstraintsProperty | undefined;
        set internalValue(value: IamPolicyConstraintsProperty | undefined);
        private _sourceIp?;
        get sourceIp(): string;
        set sourceIp(value: string);
        resetSourceIp(): void;
        get sourceIpInput(): string | undefined;
        private _vpcSourceIp?;
        get vpcSourceIp(): string;
        set vpcSourceIp(value: string);
        resetVpcSourceIp(): void;
        get vpcSourceIpInput(): string | undefined;
    }
    interface S3PresignProperty {
        /**
        * iam_policy_constraints block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workteam#iam_policy_constraints AwsSagemakerWorkteam#iam_policy_constraints}
        */
        readonly iamPolicyConstraints?: IamPolicyConstraintsProperty;
    }
    class S3PresignPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3PresignProperty | undefined;
        set internalValue(value: S3PresignProperty | undefined);
        private _iamPolicyConstraints;
        get iamPolicyConstraints(): IamPolicyConstraintsPropertyOutputReference;
        putIamPolicyConstraints(value: IamPolicyConstraintsProperty): void;
        resetIamPolicyConstraints(): void;
        get iamPolicyConstraintsInput(): IamPolicyConstraintsProperty | undefined;
    }
    interface WorkerAccessConfigurationProperty {
        /**
        * s3_presign block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workteam#s3_presign AwsSagemakerWorkteam#s3_presign}
        */
        readonly s3Presign?: S3PresignProperty;
    }
    class WorkerAccessConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): WorkerAccessConfigurationProperty | undefined;
        set internalValue(value: WorkerAccessConfigurationProperty | undefined);
        private _s3Presign;
        get s3Presign(): S3PresignPropertyOutputReference;
        putS3Presign(value: S3PresignProperty): void;
        resetS3Presign(): void;
        get s3PresignInput(): S3PresignProperty | undefined;
    }
}
