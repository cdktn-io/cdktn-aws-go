import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSagemakerAlgorithmConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#algorithm_description AwsSagemakerAlgorithm#algorithm_description}
    */
    readonly algorithmDescription?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#algorithm_name AwsSagemakerAlgorithm#algorithm_name}
    */
    readonly algorithmName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#certify_for_marketplace AwsSagemakerAlgorithm#certify_for_marketplace}
    */
    readonly certifyForMarketplace?: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#region AwsSagemakerAlgorithm#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#tags AwsSagemakerAlgorithm#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * inference_specification block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#inference_specification AwsSagemakerAlgorithm#inference_specification}
    */
    readonly inferenceSpecification?: AwsSagemakerAlgorithm.InferenceSpecificationProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#timeouts AwsSagemakerAlgorithm#timeouts}
    */
    readonly timeouts?: AwsSagemakerAlgorithm.TimeoutsProperty;
    /**
    * training_specification block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#training_specification AwsSagemakerAlgorithm#training_specification}
    */
    readonly trainingSpecification?: AwsSagemakerAlgorithm.TrainingSpecificationProperty[] | cdktn.IResolvable;
    /**
    * validation_specification block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#validation_specification AwsSagemakerAlgorithm#validation_specification}
    */
    readonly validationSpecification?: AwsSagemakerAlgorithm.ValidationSpecificationProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm aws_sagemaker_algorithm}
*/
export declare class AwsSagemakerAlgorithm extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_sagemaker_algorithm";
    /**
    * Generates CDKTN code for importing a AwsSagemakerAlgorithm resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSagemakerAlgorithm to import
    * @param importFromId The id of the existing AwsSagemakerAlgorithm that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSagemakerAlgorithm to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm aws_sagemaker_algorithm} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSagemakerAlgorithmConfig
    */
    constructor(scope: Construct, id: string, config: AwsSagemakerAlgorithmConfig);
    private _algorithmDescription?;
    get algorithmDescription(): string;
    set algorithmDescription(value: string);
    resetAlgorithmDescription(): void;
    get algorithmDescriptionInput(): string | undefined;
    private _algorithmName?;
    get algorithmName(): string;
    set algorithmName(value: string);
    get algorithmNameInput(): string | undefined;
    get algorithmStatus(): string;
    get arn(): string;
    private _certifyForMarketplace?;
    get certifyForMarketplace(): boolean | cdktn.IResolvable;
    set certifyForMarketplace(value: boolean | cdktn.IResolvable);
    resetCertifyForMarketplace(): void;
    get certifyForMarketplaceInput(): boolean | cdktn.IResolvable | undefined;
    get creationTime(): string;
    get productId(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _inferenceSpecification;
    get inferenceSpecification(): AwsSagemakerAlgorithm.InferenceSpecificationPropertyList;
    putInferenceSpecification(value: AwsSagemakerAlgorithm.InferenceSpecificationProperty[] | cdktn.IResolvable): void;
    resetInferenceSpecification(): void;
    get inferenceSpecificationInput(): cdktn.IResolvable | AwsSagemakerAlgorithm.InferenceSpecificationProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsSagemakerAlgorithm.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsSagemakerAlgorithm.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsSagemakerAlgorithm.TimeoutsProperty | undefined;
    private _trainingSpecification;
    get trainingSpecification(): AwsSagemakerAlgorithm.TrainingSpecificationPropertyList;
    putTrainingSpecification(value: AwsSagemakerAlgorithm.TrainingSpecificationProperty[] | cdktn.IResolvable): void;
    resetTrainingSpecification(): void;
    get trainingSpecificationInput(): cdktn.IResolvable | AwsSagemakerAlgorithm.TrainingSpecificationProperty[] | undefined;
    private _validationSpecification;
    get validationSpecification(): AwsSagemakerAlgorithm.ValidationSpecificationPropertyList;
    putValidationSpecification(value: AwsSagemakerAlgorithm.ValidationSpecificationProperty[] | cdktn.IResolvable): void;
    resetValidationSpecification(): void;
    get validationSpecificationInput(): cdktn.IResolvable | AwsSagemakerAlgorithm.ValidationSpecificationProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsSagemakerAlgorithmInferenceSpecificationContainersAdditionalS3DataSourcePropertyToTerraform(struct?: AwsSagemakerAlgorithm.InferenceSpecificationContainersAdditionalS3DataSourceProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmInferenceSpecificationContainersAdditionalS3DataSourcePropertyToHclTerraform(struct?: AwsSagemakerAlgorithm.InferenceSpecificationContainersAdditionalS3DataSourceProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmBaseModelPropertyToTerraform(struct?: AwsSagemakerAlgorithm.BaseModelProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmBaseModelPropertyToHclTerraform(struct?: AwsSagemakerAlgorithm.BaseModelProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmInferenceSpecificationContainersModelDataSourceS3DataSourceHubAccessConfigPropertyToTerraform(struct?: AwsSagemakerAlgorithm.InferenceSpecificationContainersModelDataSourceS3DataSourceHubAccessConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmInferenceSpecificationContainersModelDataSourceS3DataSourceHubAccessConfigPropertyToHclTerraform(struct?: AwsSagemakerAlgorithm.InferenceSpecificationContainersModelDataSourceS3DataSourceHubAccessConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmInferenceSpecificationContainersModelDataSourceS3DataSourceModelAccessConfigPropertyToTerraform(struct?: AwsSagemakerAlgorithm.InferenceSpecificationContainersModelDataSourceS3DataSourceModelAccessConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmInferenceSpecificationContainersModelDataSourceS3DataSourceModelAccessConfigPropertyToHclTerraform(struct?: AwsSagemakerAlgorithm.InferenceSpecificationContainersModelDataSourceS3DataSourceModelAccessConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmInferenceSpecificationContainersModelDataSourceS3DataSourcePropertyToTerraform(struct?: AwsSagemakerAlgorithm.InferenceSpecificationContainersModelDataSourceS3DataSourceProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmInferenceSpecificationContainersModelDataSourceS3DataSourcePropertyToHclTerraform(struct?: AwsSagemakerAlgorithm.InferenceSpecificationContainersModelDataSourceS3DataSourceProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmModelDataSourcePropertyToTerraform(struct?: AwsSagemakerAlgorithm.ModelDataSourceProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmModelDataSourcePropertyToHclTerraform(struct?: AwsSagemakerAlgorithm.ModelDataSourceProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmModelInputPropertyToTerraform(struct?: AwsSagemakerAlgorithm.ModelInputProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmModelInputPropertyToHclTerraform(struct?: AwsSagemakerAlgorithm.ModelInputProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmContainersPropertyToTerraform(struct?: AwsSagemakerAlgorithm.ContainersProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmContainersPropertyToHclTerraform(struct?: AwsSagemakerAlgorithm.ContainersProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmInferenceSpecificationPropertyToTerraform(struct?: AwsSagemakerAlgorithm.InferenceSpecificationProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmInferenceSpecificationPropertyToHclTerraform(struct?: AwsSagemakerAlgorithm.InferenceSpecificationProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmTimeoutsPropertyToTerraform(struct?: AwsSagemakerAlgorithm.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmTimeoutsPropertyToHclTerraform(struct?: AwsSagemakerAlgorithm.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmTrainingSpecificationAdditionalS3DataSourcePropertyToTerraform(struct?: AwsSagemakerAlgorithm.TrainingSpecificationAdditionalS3DataSourceProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmTrainingSpecificationAdditionalS3DataSourcePropertyToHclTerraform(struct?: AwsSagemakerAlgorithm.TrainingSpecificationAdditionalS3DataSourceProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmMetricDefinitionsPropertyToTerraform(struct?: AwsSagemakerAlgorithm.MetricDefinitionsProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmMetricDefinitionsPropertyToHclTerraform(struct?: AwsSagemakerAlgorithm.MetricDefinitionsProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmCategoricalParameterRangeSpecificationPropertyToTerraform(struct?: AwsSagemakerAlgorithm.CategoricalParameterRangeSpecificationProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmCategoricalParameterRangeSpecificationPropertyToHclTerraform(struct?: AwsSagemakerAlgorithm.CategoricalParameterRangeSpecificationProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmContinuousParameterRangeSpecificationPropertyToTerraform(struct?: AwsSagemakerAlgorithm.ContinuousParameterRangeSpecificationProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmContinuousParameterRangeSpecificationPropertyToHclTerraform(struct?: AwsSagemakerAlgorithm.ContinuousParameterRangeSpecificationProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmIntegerParameterRangeSpecificationPropertyToTerraform(struct?: AwsSagemakerAlgorithm.IntegerParameterRangeSpecificationProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmIntegerParameterRangeSpecificationPropertyToHclTerraform(struct?: AwsSagemakerAlgorithm.IntegerParameterRangeSpecificationProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmRangePropertyToTerraform(struct?: AwsSagemakerAlgorithm.RangeProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmRangePropertyToHclTerraform(struct?: AwsSagemakerAlgorithm.RangeProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmSupportedHyperParametersPropertyToTerraform(struct?: AwsSagemakerAlgorithm.SupportedHyperParametersProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmSupportedHyperParametersPropertyToHclTerraform(struct?: AwsSagemakerAlgorithm.SupportedHyperParametersProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmSupportedTuningJobObjectiveMetricsPropertyToTerraform(struct?: AwsSagemakerAlgorithm.SupportedTuningJobObjectiveMetricsProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmSupportedTuningJobObjectiveMetricsPropertyToHclTerraform(struct?: AwsSagemakerAlgorithm.SupportedTuningJobObjectiveMetricsProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmTrainingChannelsPropertyToTerraform(struct?: AwsSagemakerAlgorithm.TrainingChannelsProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmTrainingChannelsPropertyToHclTerraform(struct?: AwsSagemakerAlgorithm.TrainingChannelsProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmTrainingSpecificationPropertyToTerraform(struct?: AwsSagemakerAlgorithm.TrainingSpecificationProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmTrainingSpecificationPropertyToHclTerraform(struct?: AwsSagemakerAlgorithm.TrainingSpecificationProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmFileSystemDataSourcePropertyToTerraform(struct?: AwsSagemakerAlgorithm.FileSystemDataSourceProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmFileSystemDataSourcePropertyToHclTerraform(struct?: AwsSagemakerAlgorithm.FileSystemDataSourceProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceS3DataSourceHubAccessConfigPropertyToTerraform(struct?: AwsSagemakerAlgorithm.ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceS3DataSourceHubAccessConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceS3DataSourceHubAccessConfigPropertyToHclTerraform(struct?: AwsSagemakerAlgorithm.ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceS3DataSourceHubAccessConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceS3DataSourceModelAccessConfigPropertyToTerraform(struct?: AwsSagemakerAlgorithm.ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceS3DataSourceModelAccessConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceS3DataSourceModelAccessConfigPropertyToHclTerraform(struct?: AwsSagemakerAlgorithm.ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceS3DataSourceModelAccessConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceS3DataSourcePropertyToTerraform(struct?: AwsSagemakerAlgorithm.ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceS3DataSourceProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceS3DataSourcePropertyToHclTerraform(struct?: AwsSagemakerAlgorithm.ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceS3DataSourceProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourcePropertyToTerraform(struct?: AwsSagemakerAlgorithm.ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourcePropertyToHclTerraform(struct?: AwsSagemakerAlgorithm.ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmShuffleConfigPropertyToTerraform(struct?: AwsSagemakerAlgorithm.ShuffleConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmShuffleConfigPropertyToHclTerraform(struct?: AwsSagemakerAlgorithm.ShuffleConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmInputDataConfigPropertyToTerraform(struct?: AwsSagemakerAlgorithm.InputDataConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmInputDataConfigPropertyToHclTerraform(struct?: AwsSagemakerAlgorithm.InputDataConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmOutputDataConfigPropertyToTerraform(struct?: AwsSagemakerAlgorithm.OutputDataConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmOutputDataConfigPropertyToHclTerraform(struct?: AwsSagemakerAlgorithm.OutputDataConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmInstanceGroupsPropertyToTerraform(struct?: AwsSagemakerAlgorithm.InstanceGroupsProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmInstanceGroupsPropertyToHclTerraform(struct?: AwsSagemakerAlgorithm.InstanceGroupsProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmPlacementSpecificationsPropertyToTerraform(struct?: AwsSagemakerAlgorithm.PlacementSpecificationsProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmPlacementSpecificationsPropertyToHclTerraform(struct?: AwsSagemakerAlgorithm.PlacementSpecificationsProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmInstancePlacementConfigPropertyToTerraform(struct?: AwsSagemakerAlgorithm.InstancePlacementConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmInstancePlacementConfigPropertyToHclTerraform(struct?: AwsSagemakerAlgorithm.InstancePlacementConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmResourceConfigPropertyToTerraform(struct?: AwsSagemakerAlgorithm.ResourceConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmResourceConfigPropertyToHclTerraform(struct?: AwsSagemakerAlgorithm.ResourceConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmStoppingConditionPropertyToTerraform(struct?: AwsSagemakerAlgorithm.StoppingConditionProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmStoppingConditionPropertyToHclTerraform(struct?: AwsSagemakerAlgorithm.StoppingConditionProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmTrainingJobDefinitionPropertyToTerraform(struct?: AwsSagemakerAlgorithm.TrainingJobDefinitionProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmTrainingJobDefinitionPropertyToHclTerraform(struct?: AwsSagemakerAlgorithm.TrainingJobDefinitionProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmValidationSpecificationValidationProfilesTransformJobDefinitionTransformInputDataSourceS3DataSourcePropertyToTerraform(struct?: AwsSagemakerAlgorithm.ValidationSpecificationValidationProfilesTransformJobDefinitionTransformInputDataSourceS3DataSourceProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmValidationSpecificationValidationProfilesTransformJobDefinitionTransformInputDataSourceS3DataSourcePropertyToHclTerraform(struct?: AwsSagemakerAlgorithm.ValidationSpecificationValidationProfilesTransformJobDefinitionTransformInputDataSourceS3DataSourceProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmValidationSpecificationValidationProfilesTransformJobDefinitionTransformInputDataSourcePropertyToTerraform(struct?: AwsSagemakerAlgorithm.ValidationSpecificationValidationProfilesTransformJobDefinitionTransformInputDataSourceProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmValidationSpecificationValidationProfilesTransformJobDefinitionTransformInputDataSourcePropertyToHclTerraform(struct?: AwsSagemakerAlgorithm.ValidationSpecificationValidationProfilesTransformJobDefinitionTransformInputDataSourceProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmTransformInputPropertyToTerraform(struct?: AwsSagemakerAlgorithm.TransformInputProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmTransformInputPropertyToHclTerraform(struct?: AwsSagemakerAlgorithm.TransformInputProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmTransformOutputPropertyToTerraform(struct?: AwsSagemakerAlgorithm.TransformOutputProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmTransformOutputPropertyToHclTerraform(struct?: AwsSagemakerAlgorithm.TransformOutputProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmTransformResourcesPropertyToTerraform(struct?: AwsSagemakerAlgorithm.TransformResourcesProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmTransformResourcesPropertyToHclTerraform(struct?: AwsSagemakerAlgorithm.TransformResourcesProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmTransformJobDefinitionPropertyToTerraform(struct?: AwsSagemakerAlgorithm.TransformJobDefinitionProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmTransformJobDefinitionPropertyToHclTerraform(struct?: AwsSagemakerAlgorithm.TransformJobDefinitionProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmValidationProfilesPropertyToTerraform(struct?: AwsSagemakerAlgorithm.ValidationProfilesProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmValidationProfilesPropertyToHclTerraform(struct?: AwsSagemakerAlgorithm.ValidationProfilesProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmValidationSpecificationPropertyToTerraform(struct?: AwsSagemakerAlgorithm.ValidationSpecificationProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAlgorithmValidationSpecificationPropertyToHclTerraform(struct?: AwsSagemakerAlgorithm.ValidationSpecificationProperty | cdktn.IResolvable): any;
export declare namespace AwsSagemakerAlgorithm {
    interface InferenceSpecificationContainersAdditionalS3DataSourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#compression_type AwsSagemakerAlgorithm#compression_type}
        */
        readonly compressionType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#etag AwsSagemakerAlgorithm#etag}
        */
        readonly etag?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#s3_data_type AwsSagemakerAlgorithm#s3_data_type}
        */
        readonly s3DataType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#s3_uri AwsSagemakerAlgorithm#s3_uri}
        */
        readonly s3Uri: string;
    }
    class InferenceSpecificationContainersAdditionalS3DataSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InferenceSpecificationContainersAdditionalS3DataSourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InferenceSpecificationContainersAdditionalS3DataSourceProperty | cdktn.IResolvable | undefined);
        private _compressionType?;
        get compressionType(): string;
        set compressionType(value: string);
        resetCompressionType(): void;
        get compressionTypeInput(): string | undefined;
        private _etag?;
        get etag(): string;
        set etag(value: string);
        resetEtag(): void;
        get etagInput(): string | undefined;
        private _s3DataType?;
        get s3DataType(): string;
        set s3DataType(value: string);
        get s3DataTypeInput(): string | undefined;
        private _s3Uri?;
        get s3Uri(): string;
        set s3Uri(value: string);
        get s3UriInput(): string | undefined;
    }
    class InferenceSpecificationContainersAdditionalS3DataSourcePropertyList extends cdktn.ComplexList {
        internalValue?: InferenceSpecificationContainersAdditionalS3DataSourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InferenceSpecificationContainersAdditionalS3DataSourcePropertyOutputReference;
    }
    interface BaseModelProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#hub_content_name AwsSagemakerAlgorithm#hub_content_name}
        */
        readonly hubContentName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#hub_content_version AwsSagemakerAlgorithm#hub_content_version}
        */
        readonly hubContentVersion?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#recipe_name AwsSagemakerAlgorithm#recipe_name}
        */
        readonly recipeName?: string;
    }
    class BaseModelPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BaseModelProperty | cdktn.IResolvable | undefined;
        set internalValue(value: BaseModelProperty | cdktn.IResolvable | undefined);
        private _hubContentName?;
        get hubContentName(): string;
        set hubContentName(value: string);
        resetHubContentName(): void;
        get hubContentNameInput(): string | undefined;
        private _hubContentVersion?;
        get hubContentVersion(): string;
        set hubContentVersion(value: string);
        resetHubContentVersion(): void;
        get hubContentVersionInput(): string | undefined;
        private _recipeName?;
        get recipeName(): string;
        set recipeName(value: string);
        resetRecipeName(): void;
        get recipeNameInput(): string | undefined;
    }
    class BaseModelPropertyList extends cdktn.ComplexList {
        internalValue?: BaseModelProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BaseModelPropertyOutputReference;
    }
    interface InferenceSpecificationContainersModelDataSourceS3DataSourceHubAccessConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#hub_content_arn AwsSagemakerAlgorithm#hub_content_arn}
        */
        readonly hubContentArn?: string;
    }
    class InferenceSpecificationContainersModelDataSourceS3DataSourceHubAccessConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InferenceSpecificationContainersModelDataSourceS3DataSourceHubAccessConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InferenceSpecificationContainersModelDataSourceS3DataSourceHubAccessConfigProperty | cdktn.IResolvable | undefined);
        private _hubContentArn?;
        get hubContentArn(): string;
        set hubContentArn(value: string);
        resetHubContentArn(): void;
        get hubContentArnInput(): string | undefined;
    }
    class InferenceSpecificationContainersModelDataSourceS3DataSourceHubAccessConfigPropertyList extends cdktn.ComplexList {
        internalValue?: InferenceSpecificationContainersModelDataSourceS3DataSourceHubAccessConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InferenceSpecificationContainersModelDataSourceS3DataSourceHubAccessConfigPropertyOutputReference;
    }
    interface InferenceSpecificationContainersModelDataSourceS3DataSourceModelAccessConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#accept_eula AwsSagemakerAlgorithm#accept_eula}
        */
        readonly acceptEula?: boolean | cdktn.IResolvable;
    }
    class InferenceSpecificationContainersModelDataSourceS3DataSourceModelAccessConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InferenceSpecificationContainersModelDataSourceS3DataSourceModelAccessConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InferenceSpecificationContainersModelDataSourceS3DataSourceModelAccessConfigProperty | cdktn.IResolvable | undefined);
        private _acceptEula?;
        get acceptEula(): boolean | cdktn.IResolvable;
        set acceptEula(value: boolean | cdktn.IResolvable);
        resetAcceptEula(): void;
        get acceptEulaInput(): boolean | cdktn.IResolvable | undefined;
    }
    class InferenceSpecificationContainersModelDataSourceS3DataSourceModelAccessConfigPropertyList extends cdktn.ComplexList {
        internalValue?: InferenceSpecificationContainersModelDataSourceS3DataSourceModelAccessConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InferenceSpecificationContainersModelDataSourceS3DataSourceModelAccessConfigPropertyOutputReference;
    }
    interface InferenceSpecificationContainersModelDataSourceS3DataSourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#compression_type AwsSagemakerAlgorithm#compression_type}
        */
        readonly compressionType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#etag AwsSagemakerAlgorithm#etag}
        */
        readonly etag?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#manifest_etag AwsSagemakerAlgorithm#manifest_etag}
        */
        readonly manifestEtag?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#manifest_s3_uri AwsSagemakerAlgorithm#manifest_s3_uri}
        */
        readonly manifestS3Uri?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#s3_data_type AwsSagemakerAlgorithm#s3_data_type}
        */
        readonly s3DataType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#s3_uri AwsSagemakerAlgorithm#s3_uri}
        */
        readonly s3Uri: string;
        /**
        * hub_access_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#hub_access_config AwsSagemakerAlgorithm#hub_access_config}
        */
        readonly hubAccessConfig?: InferenceSpecificationContainersModelDataSourceS3DataSourceHubAccessConfigProperty[] | cdktn.IResolvable;
        /**
        * model_access_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#model_access_config AwsSagemakerAlgorithm#model_access_config}
        */
        readonly modelAccessConfig?: InferenceSpecificationContainersModelDataSourceS3DataSourceModelAccessConfigProperty[] | cdktn.IResolvable;
    }
    class InferenceSpecificationContainersModelDataSourceS3DataSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InferenceSpecificationContainersModelDataSourceS3DataSourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InferenceSpecificationContainersModelDataSourceS3DataSourceProperty | cdktn.IResolvable | undefined);
        private _compressionType?;
        get compressionType(): string;
        set compressionType(value: string);
        get compressionTypeInput(): string | undefined;
        private _etag?;
        get etag(): string;
        set etag(value: string);
        resetEtag(): void;
        get etagInput(): string | undefined;
        private _manifestEtag?;
        get manifestEtag(): string;
        set manifestEtag(value: string);
        resetManifestEtag(): void;
        get manifestEtagInput(): string | undefined;
        private _manifestS3Uri?;
        get manifestS3Uri(): string;
        set manifestS3Uri(value: string);
        resetManifestS3Uri(): void;
        get manifestS3UriInput(): string | undefined;
        private _s3DataType?;
        get s3DataType(): string;
        set s3DataType(value: string);
        get s3DataTypeInput(): string | undefined;
        private _s3Uri?;
        get s3Uri(): string;
        set s3Uri(value: string);
        get s3UriInput(): string | undefined;
        private _hubAccessConfig;
        get hubAccessConfig(): InferenceSpecificationContainersModelDataSourceS3DataSourceHubAccessConfigPropertyList;
        putHubAccessConfig(value: InferenceSpecificationContainersModelDataSourceS3DataSourceHubAccessConfigProperty[] | cdktn.IResolvable): void;
        resetHubAccessConfig(): void;
        get hubAccessConfigInput(): cdktn.IResolvable | InferenceSpecificationContainersModelDataSourceS3DataSourceHubAccessConfigProperty[] | undefined;
        private _modelAccessConfig;
        get modelAccessConfig(): InferenceSpecificationContainersModelDataSourceS3DataSourceModelAccessConfigPropertyList;
        putModelAccessConfig(value: InferenceSpecificationContainersModelDataSourceS3DataSourceModelAccessConfigProperty[] | cdktn.IResolvable): void;
        resetModelAccessConfig(): void;
        get modelAccessConfigInput(): cdktn.IResolvable | InferenceSpecificationContainersModelDataSourceS3DataSourceModelAccessConfigProperty[] | undefined;
    }
    class InferenceSpecificationContainersModelDataSourceS3DataSourcePropertyList extends cdktn.ComplexList {
        internalValue?: InferenceSpecificationContainersModelDataSourceS3DataSourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InferenceSpecificationContainersModelDataSourceS3DataSourcePropertyOutputReference;
    }
    interface ModelDataSourceProperty {
        /**
        * s3_data_source block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#s3_data_source AwsSagemakerAlgorithm#s3_data_source}
        */
        readonly s3DataSource?: InferenceSpecificationContainersModelDataSourceS3DataSourceProperty[] | cdktn.IResolvable;
    }
    class ModelDataSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ModelDataSourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ModelDataSourceProperty | cdktn.IResolvable | undefined);
        private _s3DataSource;
        get s3DataSource(): InferenceSpecificationContainersModelDataSourceS3DataSourcePropertyList;
        putS3DataSource(value: InferenceSpecificationContainersModelDataSourceS3DataSourceProperty[] | cdktn.IResolvable): void;
        resetS3DataSource(): void;
        get s3DataSourceInput(): cdktn.IResolvable | InferenceSpecificationContainersModelDataSourceS3DataSourceProperty[] | undefined;
    }
    class ModelDataSourcePropertyList extends cdktn.ComplexList {
        internalValue?: ModelDataSourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ModelDataSourcePropertyOutputReference;
    }
    interface ModelInputProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#data_input_config AwsSagemakerAlgorithm#data_input_config}
        */
        readonly dataInputConfig?: string;
    }
    class ModelInputPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ModelInputProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ModelInputProperty | cdktn.IResolvable | undefined);
        private _dataInputConfig?;
        get dataInputConfig(): string;
        set dataInputConfig(value: string);
        resetDataInputConfig(): void;
        get dataInputConfigInput(): string | undefined;
    }
    class ModelInputPropertyList extends cdktn.ComplexList {
        internalValue?: ModelInputProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ModelInputPropertyOutputReference;
    }
    interface ContainersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#container_hostname AwsSagemakerAlgorithm#container_hostname}
        */
        readonly containerHostname?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#environment AwsSagemakerAlgorithm#environment}
        */
        readonly environment?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#framework AwsSagemakerAlgorithm#framework}
        */
        readonly framework?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#framework_version AwsSagemakerAlgorithm#framework_version}
        */
        readonly frameworkVersion?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#image AwsSagemakerAlgorithm#image}
        */
        readonly image?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#image_digest AwsSagemakerAlgorithm#image_digest}
        */
        readonly imageDigest?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#is_checkpoint AwsSagemakerAlgorithm#is_checkpoint}
        */
        readonly isCheckpoint?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#model_data_etag AwsSagemakerAlgorithm#model_data_etag}
        */
        readonly modelDataEtag?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#model_data_url AwsSagemakerAlgorithm#model_data_url}
        */
        readonly modelDataUrl?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#nearest_model_name AwsSagemakerAlgorithm#nearest_model_name}
        */
        readonly nearestModelName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#product_id AwsSagemakerAlgorithm#product_id}
        */
        readonly productId?: string;
        /**
        * additional_s3_data_source block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#additional_s3_data_source AwsSagemakerAlgorithm#additional_s3_data_source}
        */
        readonly additionalS3DataSource?: InferenceSpecificationContainersAdditionalS3DataSourceProperty[] | cdktn.IResolvable;
        /**
        * base_model block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#base_model AwsSagemakerAlgorithm#base_model}
        */
        readonly baseModel?: BaseModelProperty[] | cdktn.IResolvable;
        /**
        * model_data_source block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#model_data_source AwsSagemakerAlgorithm#model_data_source}
        */
        readonly modelDataSource?: ModelDataSourceProperty[] | cdktn.IResolvable;
        /**
        * model_input block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#model_input AwsSagemakerAlgorithm#model_input}
        */
        readonly modelInput?: ModelInputProperty[] | cdktn.IResolvable;
    }
    class ContainersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ContainersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ContainersProperty | cdktn.IResolvable | undefined);
        private _containerHostname?;
        get containerHostname(): string;
        set containerHostname(value: string);
        resetContainerHostname(): void;
        get containerHostnameInput(): string | undefined;
        private _environment?;
        get environment(): {
            [key: string]: string;
        };
        set environment(value: {
            [key: string]: string;
        });
        resetEnvironment(): void;
        get environmentInput(): {
            [key: string]: string;
        } | undefined;
        private _framework?;
        get framework(): string;
        set framework(value: string);
        resetFramework(): void;
        get frameworkInput(): string | undefined;
        private _frameworkVersion?;
        get frameworkVersion(): string;
        set frameworkVersion(value: string);
        resetFrameworkVersion(): void;
        get frameworkVersionInput(): string | undefined;
        private _image?;
        get image(): string;
        set image(value: string);
        resetImage(): void;
        get imageInput(): string | undefined;
        private _imageDigest?;
        get imageDigest(): string;
        set imageDigest(value: string);
        resetImageDigest(): void;
        get imageDigestInput(): string | undefined;
        private _isCheckpoint?;
        get isCheckpoint(): boolean | cdktn.IResolvable;
        set isCheckpoint(value: boolean | cdktn.IResolvable);
        resetIsCheckpoint(): void;
        get isCheckpointInput(): boolean | cdktn.IResolvable | undefined;
        private _modelDataEtag?;
        get modelDataEtag(): string;
        set modelDataEtag(value: string);
        resetModelDataEtag(): void;
        get modelDataEtagInput(): string | undefined;
        private _modelDataUrl?;
        get modelDataUrl(): string;
        set modelDataUrl(value: string);
        resetModelDataUrl(): void;
        get modelDataUrlInput(): string | undefined;
        private _nearestModelName?;
        get nearestModelName(): string;
        set nearestModelName(value: string);
        resetNearestModelName(): void;
        get nearestModelNameInput(): string | undefined;
        private _productId?;
        get productId(): string;
        set productId(value: string);
        resetProductId(): void;
        get productIdInput(): string | undefined;
        private _additionalS3DataSource;
        get additionalS3DataSource(): InferenceSpecificationContainersAdditionalS3DataSourcePropertyList;
        putAdditionalS3DataSource(value: InferenceSpecificationContainersAdditionalS3DataSourceProperty[] | cdktn.IResolvable): void;
        resetAdditionalS3DataSource(): void;
        get additionalS3DataSourceInput(): cdktn.IResolvable | InferenceSpecificationContainersAdditionalS3DataSourceProperty[] | undefined;
        private _baseModel;
        get baseModel(): BaseModelPropertyList;
        putBaseModel(value: BaseModelProperty[] | cdktn.IResolvable): void;
        resetBaseModel(): void;
        get baseModelInput(): cdktn.IResolvable | BaseModelProperty[] | undefined;
        private _modelDataSource;
        get modelDataSource(): ModelDataSourcePropertyList;
        putModelDataSource(value: ModelDataSourceProperty[] | cdktn.IResolvable): void;
        resetModelDataSource(): void;
        get modelDataSourceInput(): cdktn.IResolvable | ModelDataSourceProperty[] | undefined;
        private _modelInput;
        get modelInput(): ModelInputPropertyList;
        putModelInput(value: ModelInputProperty[] | cdktn.IResolvable): void;
        resetModelInput(): void;
        get modelInputInput(): cdktn.IResolvable | ModelInputProperty[] | undefined;
    }
    class ContainersPropertyList extends cdktn.ComplexList {
        internalValue?: ContainersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ContainersPropertyOutputReference;
    }
    interface InferenceSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#supported_content_types AwsSagemakerAlgorithm#supported_content_types}
        */
        readonly supportedContentTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#supported_realtime_inference_instance_types AwsSagemakerAlgorithm#supported_realtime_inference_instance_types}
        */
        readonly supportedRealtimeInferenceInstanceTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#supported_response_mime_types AwsSagemakerAlgorithm#supported_response_mime_types}
        */
        readonly supportedResponseMimeTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#supported_transform_instance_types AwsSagemakerAlgorithm#supported_transform_instance_types}
        */
        readonly supportedTransformInstanceTypes?: string[];
        /**
        * containers block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#containers AwsSagemakerAlgorithm#containers}
        */
        readonly containers?: ContainersProperty[] | cdktn.IResolvable;
    }
    class InferenceSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InferenceSpecificationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InferenceSpecificationProperty | cdktn.IResolvable | undefined);
        private _supportedContentTypes?;
        get supportedContentTypes(): string[];
        set supportedContentTypes(value: string[]);
        resetSupportedContentTypes(): void;
        get supportedContentTypesInput(): string[] | undefined;
        private _supportedRealtimeInferenceInstanceTypes?;
        get supportedRealtimeInferenceInstanceTypes(): string[];
        set supportedRealtimeInferenceInstanceTypes(value: string[]);
        resetSupportedRealtimeInferenceInstanceTypes(): void;
        get supportedRealtimeInferenceInstanceTypesInput(): string[] | undefined;
        private _supportedResponseMimeTypes?;
        get supportedResponseMimeTypes(): string[];
        set supportedResponseMimeTypes(value: string[]);
        resetSupportedResponseMimeTypes(): void;
        get supportedResponseMimeTypesInput(): string[] | undefined;
        private _supportedTransformInstanceTypes?;
        get supportedTransformInstanceTypes(): string[];
        set supportedTransformInstanceTypes(value: string[]);
        resetSupportedTransformInstanceTypes(): void;
        get supportedTransformInstanceTypesInput(): string[] | undefined;
        private _containers;
        get containers(): ContainersPropertyList;
        putContainers(value: ContainersProperty[] | cdktn.IResolvable): void;
        resetContainers(): void;
        get containersInput(): cdktn.IResolvable | ContainersProperty[] | undefined;
    }
    class InferenceSpecificationPropertyList extends cdktn.ComplexList {
        internalValue?: InferenceSpecificationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InferenceSpecificationPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#create AwsSagemakerAlgorithm#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#delete AwsSagemakerAlgorithm#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
    interface TrainingSpecificationAdditionalS3DataSourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#compression_type AwsSagemakerAlgorithm#compression_type}
        */
        readonly compressionType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#etag AwsSagemakerAlgorithm#etag}
        */
        readonly etag?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#s3_data_type AwsSagemakerAlgorithm#s3_data_type}
        */
        readonly s3DataType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#s3_uri AwsSagemakerAlgorithm#s3_uri}
        */
        readonly s3Uri: string;
    }
    class TrainingSpecificationAdditionalS3DataSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingSpecificationAdditionalS3DataSourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingSpecificationAdditionalS3DataSourceProperty | cdktn.IResolvable | undefined);
        private _compressionType?;
        get compressionType(): string;
        set compressionType(value: string);
        resetCompressionType(): void;
        get compressionTypeInput(): string | undefined;
        private _etag?;
        get etag(): string;
        set etag(value: string);
        resetEtag(): void;
        get etagInput(): string | undefined;
        private _s3DataType?;
        get s3DataType(): string;
        set s3DataType(value: string);
        get s3DataTypeInput(): string | undefined;
        private _s3Uri?;
        get s3Uri(): string;
        set s3Uri(value: string);
        get s3UriInput(): string | undefined;
    }
    class TrainingSpecificationAdditionalS3DataSourcePropertyList extends cdktn.ComplexList {
        internalValue?: TrainingSpecificationAdditionalS3DataSourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingSpecificationAdditionalS3DataSourcePropertyOutputReference;
    }
    interface MetricDefinitionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#name AwsSagemakerAlgorithm#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#regex AwsSagemakerAlgorithm#regex}
        */
        readonly regex: string;
    }
    class MetricDefinitionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MetricDefinitionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MetricDefinitionsProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _regex?;
        get regex(): string;
        set regex(value: string);
        get regexInput(): string | undefined;
    }
    class MetricDefinitionsPropertyList extends cdktn.ComplexList {
        internalValue?: MetricDefinitionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MetricDefinitionsPropertyOutputReference;
    }
    interface CategoricalParameterRangeSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#values AwsSagemakerAlgorithm#values}
        */
        readonly values: string[];
    }
    class CategoricalParameterRangeSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CategoricalParameterRangeSpecificationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CategoricalParameterRangeSpecificationProperty | cdktn.IResolvable | undefined);
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class CategoricalParameterRangeSpecificationPropertyList extends cdktn.ComplexList {
        internalValue?: CategoricalParameterRangeSpecificationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CategoricalParameterRangeSpecificationPropertyOutputReference;
    }
    interface ContinuousParameterRangeSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#max_value AwsSagemakerAlgorithm#max_value}
        */
        readonly maxValue: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#min_value AwsSagemakerAlgorithm#min_value}
        */
        readonly minValue: string;
    }
    class ContinuousParameterRangeSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ContinuousParameterRangeSpecificationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ContinuousParameterRangeSpecificationProperty | cdktn.IResolvable | undefined);
        private _maxValue?;
        get maxValue(): string;
        set maxValue(value: string);
        get maxValueInput(): string | undefined;
        private _minValue?;
        get minValue(): string;
        set minValue(value: string);
        get minValueInput(): string | undefined;
    }
    class ContinuousParameterRangeSpecificationPropertyList extends cdktn.ComplexList {
        internalValue?: ContinuousParameterRangeSpecificationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ContinuousParameterRangeSpecificationPropertyOutputReference;
    }
    interface IntegerParameterRangeSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#max_value AwsSagemakerAlgorithm#max_value}
        */
        readonly maxValue: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#min_value AwsSagemakerAlgorithm#min_value}
        */
        readonly minValue: string;
    }
    class IntegerParameterRangeSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IntegerParameterRangeSpecificationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IntegerParameterRangeSpecificationProperty | cdktn.IResolvable | undefined);
        private _maxValue?;
        get maxValue(): string;
        set maxValue(value: string);
        get maxValueInput(): string | undefined;
        private _minValue?;
        get minValue(): string;
        set minValue(value: string);
        get minValueInput(): string | undefined;
    }
    class IntegerParameterRangeSpecificationPropertyList extends cdktn.ComplexList {
        internalValue?: IntegerParameterRangeSpecificationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IntegerParameterRangeSpecificationPropertyOutputReference;
    }
    interface RangeProperty {
        /**
        * categorical_parameter_range_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#categorical_parameter_range_specification AwsSagemakerAlgorithm#categorical_parameter_range_specification}
        */
        readonly categoricalParameterRangeSpecification?: CategoricalParameterRangeSpecificationProperty[] | cdktn.IResolvable;
        /**
        * continuous_parameter_range_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#continuous_parameter_range_specification AwsSagemakerAlgorithm#continuous_parameter_range_specification}
        */
        readonly continuousParameterRangeSpecification?: ContinuousParameterRangeSpecificationProperty[] | cdktn.IResolvable;
        /**
        * integer_parameter_range_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#integer_parameter_range_specification AwsSagemakerAlgorithm#integer_parameter_range_specification}
        */
        readonly integerParameterRangeSpecification?: IntegerParameterRangeSpecificationProperty[] | cdktn.IResolvable;
    }
    class RangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RangeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RangeProperty | cdktn.IResolvable | undefined);
        private _categoricalParameterRangeSpecification;
        get categoricalParameterRangeSpecification(): CategoricalParameterRangeSpecificationPropertyList;
        putCategoricalParameterRangeSpecification(value: CategoricalParameterRangeSpecificationProperty[] | cdktn.IResolvable): void;
        resetCategoricalParameterRangeSpecification(): void;
        get categoricalParameterRangeSpecificationInput(): cdktn.IResolvable | CategoricalParameterRangeSpecificationProperty[] | undefined;
        private _continuousParameterRangeSpecification;
        get continuousParameterRangeSpecification(): ContinuousParameterRangeSpecificationPropertyList;
        putContinuousParameterRangeSpecification(value: ContinuousParameterRangeSpecificationProperty[] | cdktn.IResolvable): void;
        resetContinuousParameterRangeSpecification(): void;
        get continuousParameterRangeSpecificationInput(): cdktn.IResolvable | ContinuousParameterRangeSpecificationProperty[] | undefined;
        private _integerParameterRangeSpecification;
        get integerParameterRangeSpecification(): IntegerParameterRangeSpecificationPropertyList;
        putIntegerParameterRangeSpecification(value: IntegerParameterRangeSpecificationProperty[] | cdktn.IResolvable): void;
        resetIntegerParameterRangeSpecification(): void;
        get integerParameterRangeSpecificationInput(): cdktn.IResolvable | IntegerParameterRangeSpecificationProperty[] | undefined;
    }
    class RangePropertyList extends cdktn.ComplexList {
        internalValue?: RangeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RangePropertyOutputReference;
    }
    interface SupportedHyperParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#default_value AwsSagemakerAlgorithm#default_value}
        */
        readonly defaultValue?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#description AwsSagemakerAlgorithm#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#is_required AwsSagemakerAlgorithm#is_required}
        */
        readonly isRequired?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#is_tunable AwsSagemakerAlgorithm#is_tunable}
        */
        readonly isTunable?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#name AwsSagemakerAlgorithm#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#type AwsSagemakerAlgorithm#type}
        */
        readonly type: string;
        /**
        * range block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#range AwsSagemakerAlgorithm#range}
        */
        readonly range?: RangeProperty[] | cdktn.IResolvable;
    }
    class SupportedHyperParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SupportedHyperParametersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SupportedHyperParametersProperty | cdktn.IResolvable | undefined);
        private _defaultValue?;
        get defaultValue(): string;
        set defaultValue(value: string);
        resetDefaultValue(): void;
        get defaultValueInput(): string | undefined;
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _isRequired?;
        get isRequired(): boolean | cdktn.IResolvable;
        set isRequired(value: boolean | cdktn.IResolvable);
        resetIsRequired(): void;
        get isRequiredInput(): boolean | cdktn.IResolvable | undefined;
        private _isTunable?;
        get isTunable(): boolean | cdktn.IResolvable;
        set isTunable(value: boolean | cdktn.IResolvable);
        resetIsTunable(): void;
        get isTunableInput(): boolean | cdktn.IResolvable | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _range;
        get range(): RangePropertyList;
        putRange(value: RangeProperty[] | cdktn.IResolvable): void;
        resetRange(): void;
        get rangeInput(): cdktn.IResolvable | RangeProperty[] | undefined;
    }
    class SupportedHyperParametersPropertyList extends cdktn.ComplexList {
        internalValue?: SupportedHyperParametersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SupportedHyperParametersPropertyOutputReference;
    }
    interface SupportedTuningJobObjectiveMetricsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#metric_name AwsSagemakerAlgorithm#metric_name}
        */
        readonly metricName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#type AwsSagemakerAlgorithm#type}
        */
        readonly type: string;
    }
    class SupportedTuningJobObjectiveMetricsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SupportedTuningJobObjectiveMetricsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SupportedTuningJobObjectiveMetricsProperty | cdktn.IResolvable | undefined);
        private _metricName?;
        get metricName(): string;
        set metricName(value: string);
        get metricNameInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class SupportedTuningJobObjectiveMetricsPropertyList extends cdktn.ComplexList {
        internalValue?: SupportedTuningJobObjectiveMetricsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SupportedTuningJobObjectiveMetricsPropertyOutputReference;
    }
    interface TrainingChannelsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#description AwsSagemakerAlgorithm#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#is_required AwsSagemakerAlgorithm#is_required}
        */
        readonly isRequired?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#name AwsSagemakerAlgorithm#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#supported_compression_types AwsSagemakerAlgorithm#supported_compression_types}
        */
        readonly supportedCompressionTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#supported_content_types AwsSagemakerAlgorithm#supported_content_types}
        */
        readonly supportedContentTypes: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#supported_input_modes AwsSagemakerAlgorithm#supported_input_modes}
        */
        readonly supportedInputModes: string[];
    }
    class TrainingChannelsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingChannelsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingChannelsProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _isRequired?;
        get isRequired(): boolean | cdktn.IResolvable;
        set isRequired(value: boolean | cdktn.IResolvable);
        resetIsRequired(): void;
        get isRequiredInput(): boolean | cdktn.IResolvable | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _supportedCompressionTypes?;
        get supportedCompressionTypes(): string[];
        set supportedCompressionTypes(value: string[]);
        resetSupportedCompressionTypes(): void;
        get supportedCompressionTypesInput(): string[] | undefined;
        private _supportedContentTypes?;
        get supportedContentTypes(): string[];
        set supportedContentTypes(value: string[]);
        get supportedContentTypesInput(): string[] | undefined;
        private _supportedInputModes?;
        get supportedInputModes(): string[];
        set supportedInputModes(value: string[]);
        get supportedInputModesInput(): string[] | undefined;
    }
    class TrainingChannelsPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingChannelsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingChannelsPropertyOutputReference;
    }
    interface TrainingSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#supported_training_instance_types AwsSagemakerAlgorithm#supported_training_instance_types}
        */
        readonly supportedTrainingInstanceTypes: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#supports_distributed_training AwsSagemakerAlgorithm#supports_distributed_training}
        */
        readonly supportsDistributedTraining?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#training_image AwsSagemakerAlgorithm#training_image}
        */
        readonly trainingImage: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#training_image_digest AwsSagemakerAlgorithm#training_image_digest}
        */
        readonly trainingImageDigest?: string;
        /**
        * additional_s3_data_source block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#additional_s3_data_source AwsSagemakerAlgorithm#additional_s3_data_source}
        */
        readonly additionalS3DataSource?: TrainingSpecificationAdditionalS3DataSourceProperty[] | cdktn.IResolvable;
        /**
        * metric_definitions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#metric_definitions AwsSagemakerAlgorithm#metric_definitions}
        */
        readonly metricDefinitions?: MetricDefinitionsProperty[] | cdktn.IResolvable;
        /**
        * supported_hyper_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#supported_hyper_parameters AwsSagemakerAlgorithm#supported_hyper_parameters}
        */
        readonly supportedHyperParameters?: SupportedHyperParametersProperty[] | cdktn.IResolvable;
        /**
        * supported_tuning_job_objective_metrics block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#supported_tuning_job_objective_metrics AwsSagemakerAlgorithm#supported_tuning_job_objective_metrics}
        */
        readonly supportedTuningJobObjectiveMetrics?: SupportedTuningJobObjectiveMetricsProperty[] | cdktn.IResolvable;
        /**
        * training_channels block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#training_channels AwsSagemakerAlgorithm#training_channels}
        */
        readonly trainingChannels?: TrainingChannelsProperty[] | cdktn.IResolvable;
    }
    class TrainingSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingSpecificationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingSpecificationProperty | cdktn.IResolvable | undefined);
        private _supportedTrainingInstanceTypes?;
        get supportedTrainingInstanceTypes(): string[];
        set supportedTrainingInstanceTypes(value: string[]);
        get supportedTrainingInstanceTypesInput(): string[] | undefined;
        private _supportsDistributedTraining?;
        get supportsDistributedTraining(): boolean | cdktn.IResolvable;
        set supportsDistributedTraining(value: boolean | cdktn.IResolvable);
        resetSupportsDistributedTraining(): void;
        get supportsDistributedTrainingInput(): boolean | cdktn.IResolvable | undefined;
        private _trainingImage?;
        get trainingImage(): string;
        set trainingImage(value: string);
        get trainingImageInput(): string | undefined;
        private _trainingImageDigest?;
        get trainingImageDigest(): string;
        set trainingImageDigest(value: string);
        resetTrainingImageDigest(): void;
        get trainingImageDigestInput(): string | undefined;
        private _additionalS3DataSource;
        get additionalS3DataSource(): TrainingSpecificationAdditionalS3DataSourcePropertyList;
        putAdditionalS3DataSource(value: TrainingSpecificationAdditionalS3DataSourceProperty[] | cdktn.IResolvable): void;
        resetAdditionalS3DataSource(): void;
        get additionalS3DataSourceInput(): cdktn.IResolvable | TrainingSpecificationAdditionalS3DataSourceProperty[] | undefined;
        private _metricDefinitions;
        get metricDefinitions(): MetricDefinitionsPropertyList;
        putMetricDefinitions(value: MetricDefinitionsProperty[] | cdktn.IResolvable): void;
        resetMetricDefinitions(): void;
        get metricDefinitionsInput(): cdktn.IResolvable | MetricDefinitionsProperty[] | undefined;
        private _supportedHyperParameters;
        get supportedHyperParameters(): SupportedHyperParametersPropertyList;
        putSupportedHyperParameters(value: SupportedHyperParametersProperty[] | cdktn.IResolvable): void;
        resetSupportedHyperParameters(): void;
        get supportedHyperParametersInput(): cdktn.IResolvable | SupportedHyperParametersProperty[] | undefined;
        private _supportedTuningJobObjectiveMetrics;
        get supportedTuningJobObjectiveMetrics(): SupportedTuningJobObjectiveMetricsPropertyList;
        putSupportedTuningJobObjectiveMetrics(value: SupportedTuningJobObjectiveMetricsProperty[] | cdktn.IResolvable): void;
        resetSupportedTuningJobObjectiveMetrics(): void;
        get supportedTuningJobObjectiveMetricsInput(): cdktn.IResolvable | SupportedTuningJobObjectiveMetricsProperty[] | undefined;
        private _trainingChannels;
        get trainingChannels(): TrainingChannelsPropertyList;
        putTrainingChannels(value: TrainingChannelsProperty[] | cdktn.IResolvable): void;
        resetTrainingChannels(): void;
        get trainingChannelsInput(): cdktn.IResolvable | TrainingChannelsProperty[] | undefined;
    }
    class TrainingSpecificationPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingSpecificationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingSpecificationPropertyOutputReference;
    }
    interface FileSystemDataSourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#directory_path AwsSagemakerAlgorithm#directory_path}
        */
        readonly directoryPath: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#file_system_access_mode AwsSagemakerAlgorithm#file_system_access_mode}
        */
        readonly fileSystemAccessMode: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#file_system_id AwsSagemakerAlgorithm#file_system_id}
        */
        readonly fileSystemId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#file_system_type AwsSagemakerAlgorithm#file_system_type}
        */
        readonly fileSystemType: string;
    }
    class FileSystemDataSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FileSystemDataSourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FileSystemDataSourceProperty | cdktn.IResolvable | undefined);
        private _directoryPath?;
        get directoryPath(): string;
        set directoryPath(value: string);
        get directoryPathInput(): string | undefined;
        private _fileSystemAccessMode?;
        get fileSystemAccessMode(): string;
        set fileSystemAccessMode(value: string);
        get fileSystemAccessModeInput(): string | undefined;
        private _fileSystemId?;
        get fileSystemId(): string;
        set fileSystemId(value: string);
        get fileSystemIdInput(): string | undefined;
        private _fileSystemType?;
        get fileSystemType(): string;
        set fileSystemType(value: string);
        get fileSystemTypeInput(): string | undefined;
    }
    class FileSystemDataSourcePropertyList extends cdktn.ComplexList {
        internalValue?: FileSystemDataSourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FileSystemDataSourcePropertyOutputReference;
    }
    interface ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceS3DataSourceHubAccessConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#hub_content_arn AwsSagemakerAlgorithm#hub_content_arn}
        */
        readonly hubContentArn?: string;
    }
    class ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceS3DataSourceHubAccessConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceS3DataSourceHubAccessConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceS3DataSourceHubAccessConfigProperty | cdktn.IResolvable | undefined);
        private _hubContentArn?;
        get hubContentArn(): string;
        set hubContentArn(value: string);
        resetHubContentArn(): void;
        get hubContentArnInput(): string | undefined;
    }
    class ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceS3DataSourceHubAccessConfigPropertyList extends cdktn.ComplexList {
        internalValue?: ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceS3DataSourceHubAccessConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceS3DataSourceHubAccessConfigPropertyOutputReference;
    }
    interface ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceS3DataSourceModelAccessConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#accept_eula AwsSagemakerAlgorithm#accept_eula}
        */
        readonly acceptEula?: boolean | cdktn.IResolvable;
    }
    class ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceS3DataSourceModelAccessConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceS3DataSourceModelAccessConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceS3DataSourceModelAccessConfigProperty | cdktn.IResolvable | undefined);
        private _acceptEula?;
        get acceptEula(): boolean | cdktn.IResolvable;
        set acceptEula(value: boolean | cdktn.IResolvable);
        resetAcceptEula(): void;
        get acceptEulaInput(): boolean | cdktn.IResolvable | undefined;
    }
    class ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceS3DataSourceModelAccessConfigPropertyList extends cdktn.ComplexList {
        internalValue?: ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceS3DataSourceModelAccessConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceS3DataSourceModelAccessConfigPropertyOutputReference;
    }
    interface ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceS3DataSourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#attribute_names AwsSagemakerAlgorithm#attribute_names}
        */
        readonly attributeNames?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#instance_group_names AwsSagemakerAlgorithm#instance_group_names}
        */
        readonly instanceGroupNames?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#s3_data_distribution_type AwsSagemakerAlgorithm#s3_data_distribution_type}
        */
        readonly s3DataDistributionType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#s3_data_type AwsSagemakerAlgorithm#s3_data_type}
        */
        readonly s3DataType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#s3_uri AwsSagemakerAlgorithm#s3_uri}
        */
        readonly s3Uri: string;
        /**
        * hub_access_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#hub_access_config AwsSagemakerAlgorithm#hub_access_config}
        */
        readonly hubAccessConfig?: ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceS3DataSourceHubAccessConfigProperty[] | cdktn.IResolvable;
        /**
        * model_access_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#model_access_config AwsSagemakerAlgorithm#model_access_config}
        */
        readonly modelAccessConfig?: ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceS3DataSourceModelAccessConfigProperty[] | cdktn.IResolvable;
    }
    class ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceS3DataSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceS3DataSourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceS3DataSourceProperty | cdktn.IResolvable | undefined);
        private _attributeNames?;
        get attributeNames(): string[];
        set attributeNames(value: string[]);
        resetAttributeNames(): void;
        get attributeNamesInput(): string[] | undefined;
        private _instanceGroupNames?;
        get instanceGroupNames(): string[];
        set instanceGroupNames(value: string[]);
        resetInstanceGroupNames(): void;
        get instanceGroupNamesInput(): string[] | undefined;
        private _s3DataDistributionType?;
        get s3DataDistributionType(): string;
        set s3DataDistributionType(value: string);
        resetS3DataDistributionType(): void;
        get s3DataDistributionTypeInput(): string | undefined;
        private _s3DataType?;
        get s3DataType(): string;
        set s3DataType(value: string);
        get s3DataTypeInput(): string | undefined;
        private _s3Uri?;
        get s3Uri(): string;
        set s3Uri(value: string);
        get s3UriInput(): string | undefined;
        private _hubAccessConfig;
        get hubAccessConfig(): ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceS3DataSourceHubAccessConfigPropertyList;
        putHubAccessConfig(value: ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceS3DataSourceHubAccessConfigProperty[] | cdktn.IResolvable): void;
        resetHubAccessConfig(): void;
        get hubAccessConfigInput(): cdktn.IResolvable | ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceS3DataSourceHubAccessConfigProperty[] | undefined;
        private _modelAccessConfig;
        get modelAccessConfig(): ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceS3DataSourceModelAccessConfigPropertyList;
        putModelAccessConfig(value: ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceS3DataSourceModelAccessConfigProperty[] | cdktn.IResolvable): void;
        resetModelAccessConfig(): void;
        get modelAccessConfigInput(): cdktn.IResolvable | ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceS3DataSourceModelAccessConfigProperty[] | undefined;
    }
    class ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceS3DataSourcePropertyList extends cdktn.ComplexList {
        internalValue?: ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceS3DataSourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceS3DataSourcePropertyOutputReference;
    }
    interface ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceProperty {
        /**
        * file_system_data_source block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#file_system_data_source AwsSagemakerAlgorithm#file_system_data_source}
        */
        readonly fileSystemDataSource?: FileSystemDataSourceProperty[] | cdktn.IResolvable;
        /**
        * s3_data_source block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#s3_data_source AwsSagemakerAlgorithm#s3_data_source}
        */
        readonly s3DataSource?: ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceS3DataSourceProperty[] | cdktn.IResolvable;
    }
    class ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceProperty | cdktn.IResolvable | undefined);
        private _fileSystemDataSource;
        get fileSystemDataSource(): FileSystemDataSourcePropertyList;
        putFileSystemDataSource(value: FileSystemDataSourceProperty[] | cdktn.IResolvable): void;
        resetFileSystemDataSource(): void;
        get fileSystemDataSourceInput(): cdktn.IResolvable | FileSystemDataSourceProperty[] | undefined;
        private _s3DataSource;
        get s3DataSource(): ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceS3DataSourcePropertyList;
        putS3DataSource(value: ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceS3DataSourceProperty[] | cdktn.IResolvable): void;
        resetS3DataSource(): void;
        get s3DataSourceInput(): cdktn.IResolvable | ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceS3DataSourceProperty[] | undefined;
    }
    class ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourcePropertyList extends cdktn.ComplexList {
        internalValue?: ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourcePropertyOutputReference;
    }
    interface ShuffleConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#seed AwsSagemakerAlgorithm#seed}
        */
        readonly seed: number;
    }
    class ShuffleConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ShuffleConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ShuffleConfigProperty | cdktn.IResolvable | undefined);
        private _seed?;
        get seed(): number;
        set seed(value: number);
        get seedInput(): number | undefined;
    }
    class ShuffleConfigPropertyList extends cdktn.ComplexList {
        internalValue?: ShuffleConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ShuffleConfigPropertyOutputReference;
    }
    interface InputDataConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#channel_name AwsSagemakerAlgorithm#channel_name}
        */
        readonly channelName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#compression_type AwsSagemakerAlgorithm#compression_type}
        */
        readonly compressionType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#content_type AwsSagemakerAlgorithm#content_type}
        */
        readonly contentType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#input_mode AwsSagemakerAlgorithm#input_mode}
        */
        readonly inputMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#record_wrapper_type AwsSagemakerAlgorithm#record_wrapper_type}
        */
        readonly recordWrapperType?: string;
        /**
        * data_source block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#data_source AwsSagemakerAlgorithm#data_source}
        */
        readonly dataSource?: ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceProperty[] | cdktn.IResolvable;
        /**
        * shuffle_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#shuffle_config AwsSagemakerAlgorithm#shuffle_config}
        */
        readonly shuffleConfig?: ShuffleConfigProperty[] | cdktn.IResolvable;
    }
    class InputDataConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InputDataConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InputDataConfigProperty | cdktn.IResolvable | undefined);
        private _channelName?;
        get channelName(): string;
        set channelName(value: string);
        get channelNameInput(): string | undefined;
        private _compressionType?;
        get compressionType(): string;
        set compressionType(value: string);
        resetCompressionType(): void;
        get compressionTypeInput(): string | undefined;
        private _contentType?;
        get contentType(): string;
        set contentType(value: string);
        resetContentType(): void;
        get contentTypeInput(): string | undefined;
        private _inputMode?;
        get inputMode(): string;
        set inputMode(value: string);
        resetInputMode(): void;
        get inputModeInput(): string | undefined;
        private _recordWrapperType?;
        get recordWrapperType(): string;
        set recordWrapperType(value: string);
        resetRecordWrapperType(): void;
        get recordWrapperTypeInput(): string | undefined;
        private _dataSource;
        get dataSource(): ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourcePropertyList;
        putDataSource(value: ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceProperty[] | cdktn.IResolvable): void;
        resetDataSource(): void;
        get dataSourceInput(): cdktn.IResolvable | ValidationSpecificationValidationProfilesTrainingJobDefinitionInputDataConfigDataSourceProperty[] | undefined;
        private _shuffleConfig;
        get shuffleConfig(): ShuffleConfigPropertyList;
        putShuffleConfig(value: ShuffleConfigProperty[] | cdktn.IResolvable): void;
        resetShuffleConfig(): void;
        get shuffleConfigInput(): cdktn.IResolvable | ShuffleConfigProperty[] | undefined;
    }
    class InputDataConfigPropertyList extends cdktn.ComplexList {
        internalValue?: InputDataConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InputDataConfigPropertyOutputReference;
    }
    interface OutputDataConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#compression_type AwsSagemakerAlgorithm#compression_type}
        */
        readonly compressionType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#kms_key_id AwsSagemakerAlgorithm#kms_key_id}
        */
        readonly kmsKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#s3_output_path AwsSagemakerAlgorithm#s3_output_path}
        */
        readonly s3OutputPath: string;
    }
    class OutputDataConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OutputDataConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OutputDataConfigProperty | cdktn.IResolvable | undefined);
        private _compressionType?;
        get compressionType(): string;
        set compressionType(value: string);
        resetCompressionType(): void;
        get compressionTypeInput(): string | undefined;
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        resetKmsKeyId(): void;
        get kmsKeyIdInput(): string | undefined;
        private _s3OutputPath?;
        get s3OutputPath(): string;
        set s3OutputPath(value: string);
        get s3OutputPathInput(): string | undefined;
    }
    class OutputDataConfigPropertyList extends cdktn.ComplexList {
        internalValue?: OutputDataConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OutputDataConfigPropertyOutputReference;
    }
    interface InstanceGroupsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#instance_count AwsSagemakerAlgorithm#instance_count}
        */
        readonly instanceCount: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#instance_group_name AwsSagemakerAlgorithm#instance_group_name}
        */
        readonly instanceGroupName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#instance_type AwsSagemakerAlgorithm#instance_type}
        */
        readonly instanceType: string;
    }
    class InstanceGroupsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InstanceGroupsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InstanceGroupsProperty | cdktn.IResolvable | undefined);
        private _instanceCount?;
        get instanceCount(): number;
        set instanceCount(value: number);
        get instanceCountInput(): number | undefined;
        private _instanceGroupName?;
        get instanceGroupName(): string;
        set instanceGroupName(value: string);
        get instanceGroupNameInput(): string | undefined;
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        get instanceTypeInput(): string | undefined;
    }
    class InstanceGroupsPropertyList extends cdktn.ComplexList {
        internalValue?: InstanceGroupsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InstanceGroupsPropertyOutputReference;
    }
    interface PlacementSpecificationsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#instance_count AwsSagemakerAlgorithm#instance_count}
        */
        readonly instanceCount: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#ultra_server_id AwsSagemakerAlgorithm#ultra_server_id}
        */
        readonly ultraServerId?: string;
    }
    class PlacementSpecificationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PlacementSpecificationsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PlacementSpecificationsProperty | cdktn.IResolvable | undefined);
        private _instanceCount?;
        get instanceCount(): number;
        set instanceCount(value: number);
        get instanceCountInput(): number | undefined;
        private _ultraServerId?;
        get ultraServerId(): string;
        set ultraServerId(value: string);
        resetUltraServerId(): void;
        get ultraServerIdInput(): string | undefined;
    }
    class PlacementSpecificationsPropertyList extends cdktn.ComplexList {
        internalValue?: PlacementSpecificationsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PlacementSpecificationsPropertyOutputReference;
    }
    interface InstancePlacementConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#enable_multiple_jobs AwsSagemakerAlgorithm#enable_multiple_jobs}
        */
        readonly enableMultipleJobs?: boolean | cdktn.IResolvable;
        /**
        * placement_specifications block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#placement_specifications AwsSagemakerAlgorithm#placement_specifications}
        */
        readonly placementSpecifications?: PlacementSpecificationsProperty[] | cdktn.IResolvable;
    }
    class InstancePlacementConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InstancePlacementConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InstancePlacementConfigProperty | cdktn.IResolvable | undefined);
        private _enableMultipleJobs?;
        get enableMultipleJobs(): boolean | cdktn.IResolvable;
        set enableMultipleJobs(value: boolean | cdktn.IResolvable);
        resetEnableMultipleJobs(): void;
        get enableMultipleJobsInput(): boolean | cdktn.IResolvable | undefined;
        private _placementSpecifications;
        get placementSpecifications(): PlacementSpecificationsPropertyList;
        putPlacementSpecifications(value: PlacementSpecificationsProperty[] | cdktn.IResolvable): void;
        resetPlacementSpecifications(): void;
        get placementSpecificationsInput(): cdktn.IResolvable | PlacementSpecificationsProperty[] | undefined;
    }
    class InstancePlacementConfigPropertyList extends cdktn.ComplexList {
        internalValue?: InstancePlacementConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InstancePlacementConfigPropertyOutputReference;
    }
    interface ResourceConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#instance_count AwsSagemakerAlgorithm#instance_count}
        */
        readonly instanceCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#instance_type AwsSagemakerAlgorithm#instance_type}
        */
        readonly instanceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#keep_alive_period_in_seconds AwsSagemakerAlgorithm#keep_alive_period_in_seconds}
        */
        readonly keepAlivePeriodInSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#training_plan_arn AwsSagemakerAlgorithm#training_plan_arn}
        */
        readonly trainingPlanArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#volume_kms_key_id AwsSagemakerAlgorithm#volume_kms_key_id}
        */
        readonly volumeKmsKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#volume_size_in_gb AwsSagemakerAlgorithm#volume_size_in_gb}
        */
        readonly volumeSizeInGb?: number;
        /**
        * instance_groups block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#instance_groups AwsSagemakerAlgorithm#instance_groups}
        */
        readonly instanceGroups?: InstanceGroupsProperty[] | cdktn.IResolvable;
        /**
        * instance_placement_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#instance_placement_config AwsSagemakerAlgorithm#instance_placement_config}
        */
        readonly instancePlacementConfig?: InstancePlacementConfigProperty[] | cdktn.IResolvable;
    }
    class ResourceConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceConfigProperty | cdktn.IResolvable | undefined);
        private _instanceCount?;
        get instanceCount(): number;
        set instanceCount(value: number);
        resetInstanceCount(): void;
        get instanceCountInput(): number | undefined;
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        resetInstanceType(): void;
        get instanceTypeInput(): string | undefined;
        private _keepAlivePeriodInSeconds?;
        get keepAlivePeriodInSeconds(): number;
        set keepAlivePeriodInSeconds(value: number);
        resetKeepAlivePeriodInSeconds(): void;
        get keepAlivePeriodInSecondsInput(): number | undefined;
        private _trainingPlanArn?;
        get trainingPlanArn(): string;
        set trainingPlanArn(value: string);
        resetTrainingPlanArn(): void;
        get trainingPlanArnInput(): string | undefined;
        private _volumeKmsKeyId?;
        get volumeKmsKeyId(): string;
        set volumeKmsKeyId(value: string);
        resetVolumeKmsKeyId(): void;
        get volumeKmsKeyIdInput(): string | undefined;
        private _volumeSizeInGb?;
        get volumeSizeInGb(): number;
        set volumeSizeInGb(value: number);
        resetVolumeSizeInGb(): void;
        get volumeSizeInGbInput(): number | undefined;
        private _instanceGroups;
        get instanceGroups(): InstanceGroupsPropertyList;
        putInstanceGroups(value: InstanceGroupsProperty[] | cdktn.IResolvable): void;
        resetInstanceGroups(): void;
        get instanceGroupsInput(): cdktn.IResolvable | InstanceGroupsProperty[] | undefined;
        private _instancePlacementConfig;
        get instancePlacementConfig(): InstancePlacementConfigPropertyList;
        putInstancePlacementConfig(value: InstancePlacementConfigProperty[] | cdktn.IResolvable): void;
        resetInstancePlacementConfig(): void;
        get instancePlacementConfigInput(): cdktn.IResolvable | InstancePlacementConfigProperty[] | undefined;
    }
    class ResourceConfigPropertyList extends cdktn.ComplexList {
        internalValue?: ResourceConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceConfigPropertyOutputReference;
    }
    interface StoppingConditionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#max_pending_time_in_seconds AwsSagemakerAlgorithm#max_pending_time_in_seconds}
        */
        readonly maxPendingTimeInSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#max_runtime_in_seconds AwsSagemakerAlgorithm#max_runtime_in_seconds}
        */
        readonly maxRuntimeInSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#max_wait_time_in_seconds AwsSagemakerAlgorithm#max_wait_time_in_seconds}
        */
        readonly maxWaitTimeInSeconds?: number;
    }
    class StoppingConditionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StoppingConditionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StoppingConditionProperty | cdktn.IResolvable | undefined);
        private _maxPendingTimeInSeconds?;
        get maxPendingTimeInSeconds(): number;
        set maxPendingTimeInSeconds(value: number);
        resetMaxPendingTimeInSeconds(): void;
        get maxPendingTimeInSecondsInput(): number | undefined;
        private _maxRuntimeInSeconds?;
        get maxRuntimeInSeconds(): number;
        set maxRuntimeInSeconds(value: number);
        resetMaxRuntimeInSeconds(): void;
        get maxRuntimeInSecondsInput(): number | undefined;
        private _maxWaitTimeInSeconds?;
        get maxWaitTimeInSeconds(): number;
        set maxWaitTimeInSeconds(value: number);
        resetMaxWaitTimeInSeconds(): void;
        get maxWaitTimeInSecondsInput(): number | undefined;
    }
    class StoppingConditionPropertyList extends cdktn.ComplexList {
        internalValue?: StoppingConditionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StoppingConditionPropertyOutputReference;
    }
    interface TrainingJobDefinitionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#hyper_parameters AwsSagemakerAlgorithm#hyper_parameters}
        */
        readonly hyperParameters?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#training_input_mode AwsSagemakerAlgorithm#training_input_mode}
        */
        readonly trainingInputMode: string;
        /**
        * input_data_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#input_data_config AwsSagemakerAlgorithm#input_data_config}
        */
        readonly inputDataConfig?: InputDataConfigProperty[] | cdktn.IResolvable;
        /**
        * output_data_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#output_data_config AwsSagemakerAlgorithm#output_data_config}
        */
        readonly outputDataConfig?: OutputDataConfigProperty[] | cdktn.IResolvable;
        /**
        * resource_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#resource_config AwsSagemakerAlgorithm#resource_config}
        */
        readonly resourceConfig?: ResourceConfigProperty[] | cdktn.IResolvable;
        /**
        * stopping_condition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#stopping_condition AwsSagemakerAlgorithm#stopping_condition}
        */
        readonly stoppingCondition?: StoppingConditionProperty[] | cdktn.IResolvable;
    }
    class TrainingJobDefinitionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingJobDefinitionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingJobDefinitionProperty | cdktn.IResolvable | undefined);
        private _hyperParameters?;
        get hyperParameters(): {
            [key: string]: string;
        };
        set hyperParameters(value: {
            [key: string]: string;
        });
        resetHyperParameters(): void;
        get hyperParametersInput(): {
            [key: string]: string;
        } | undefined;
        private _trainingInputMode?;
        get trainingInputMode(): string;
        set trainingInputMode(value: string);
        get trainingInputModeInput(): string | undefined;
        private _inputDataConfig;
        get inputDataConfig(): InputDataConfigPropertyList;
        putInputDataConfig(value: InputDataConfigProperty[] | cdktn.IResolvable): void;
        resetInputDataConfig(): void;
        get inputDataConfigInput(): cdktn.IResolvable | InputDataConfigProperty[] | undefined;
        private _outputDataConfig;
        get outputDataConfig(): OutputDataConfigPropertyList;
        putOutputDataConfig(value: OutputDataConfigProperty[] | cdktn.IResolvable): void;
        resetOutputDataConfig(): void;
        get outputDataConfigInput(): cdktn.IResolvable | OutputDataConfigProperty[] | undefined;
        private _resourceConfig;
        get resourceConfig(): ResourceConfigPropertyList;
        putResourceConfig(value: ResourceConfigProperty[] | cdktn.IResolvable): void;
        resetResourceConfig(): void;
        get resourceConfigInput(): cdktn.IResolvable | ResourceConfigProperty[] | undefined;
        private _stoppingCondition;
        get stoppingCondition(): StoppingConditionPropertyList;
        putStoppingCondition(value: StoppingConditionProperty[] | cdktn.IResolvable): void;
        resetStoppingCondition(): void;
        get stoppingConditionInput(): cdktn.IResolvable | StoppingConditionProperty[] | undefined;
    }
    class TrainingJobDefinitionPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingJobDefinitionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingJobDefinitionPropertyOutputReference;
    }
    interface ValidationSpecificationValidationProfilesTransformJobDefinitionTransformInputDataSourceS3DataSourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#s3_data_type AwsSagemakerAlgorithm#s3_data_type}
        */
        readonly s3DataType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#s3_uri AwsSagemakerAlgorithm#s3_uri}
        */
        readonly s3Uri: string;
    }
    class ValidationSpecificationValidationProfilesTransformJobDefinitionTransformInputDataSourceS3DataSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ValidationSpecificationValidationProfilesTransformJobDefinitionTransformInputDataSourceS3DataSourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ValidationSpecificationValidationProfilesTransformJobDefinitionTransformInputDataSourceS3DataSourceProperty | cdktn.IResolvable | undefined);
        private _s3DataType?;
        get s3DataType(): string;
        set s3DataType(value: string);
        get s3DataTypeInput(): string | undefined;
        private _s3Uri?;
        get s3Uri(): string;
        set s3Uri(value: string);
        get s3UriInput(): string | undefined;
    }
    class ValidationSpecificationValidationProfilesTransformJobDefinitionTransformInputDataSourceS3DataSourcePropertyList extends cdktn.ComplexList {
        internalValue?: ValidationSpecificationValidationProfilesTransformJobDefinitionTransformInputDataSourceS3DataSourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ValidationSpecificationValidationProfilesTransformJobDefinitionTransformInputDataSourceS3DataSourcePropertyOutputReference;
    }
    interface ValidationSpecificationValidationProfilesTransformJobDefinitionTransformInputDataSourceProperty {
        /**
        * s3_data_source block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#s3_data_source AwsSagemakerAlgorithm#s3_data_source}
        */
        readonly s3DataSource?: ValidationSpecificationValidationProfilesTransformJobDefinitionTransformInputDataSourceS3DataSourceProperty[] | cdktn.IResolvable;
    }
    class ValidationSpecificationValidationProfilesTransformJobDefinitionTransformInputDataSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ValidationSpecificationValidationProfilesTransformJobDefinitionTransformInputDataSourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ValidationSpecificationValidationProfilesTransformJobDefinitionTransformInputDataSourceProperty | cdktn.IResolvable | undefined);
        private _s3DataSource;
        get s3DataSource(): ValidationSpecificationValidationProfilesTransformJobDefinitionTransformInputDataSourceS3DataSourcePropertyList;
        putS3DataSource(value: ValidationSpecificationValidationProfilesTransformJobDefinitionTransformInputDataSourceS3DataSourceProperty[] | cdktn.IResolvable): void;
        resetS3DataSource(): void;
        get s3DataSourceInput(): cdktn.IResolvable | ValidationSpecificationValidationProfilesTransformJobDefinitionTransformInputDataSourceS3DataSourceProperty[] | undefined;
    }
    class ValidationSpecificationValidationProfilesTransformJobDefinitionTransformInputDataSourcePropertyList extends cdktn.ComplexList {
        internalValue?: ValidationSpecificationValidationProfilesTransformJobDefinitionTransformInputDataSourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ValidationSpecificationValidationProfilesTransformJobDefinitionTransformInputDataSourcePropertyOutputReference;
    }
    interface TransformInputProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#compression_type AwsSagemakerAlgorithm#compression_type}
        */
        readonly compressionType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#content_type AwsSagemakerAlgorithm#content_type}
        */
        readonly contentType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#split_type AwsSagemakerAlgorithm#split_type}
        */
        readonly splitType?: string;
        /**
        * data_source block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#data_source AwsSagemakerAlgorithm#data_source}
        */
        readonly dataSource?: ValidationSpecificationValidationProfilesTransformJobDefinitionTransformInputDataSourceProperty[] | cdktn.IResolvable;
    }
    class TransformInputPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TransformInputProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TransformInputProperty | cdktn.IResolvable | undefined);
        private _compressionType?;
        get compressionType(): string;
        set compressionType(value: string);
        resetCompressionType(): void;
        get compressionTypeInput(): string | undefined;
        private _contentType?;
        get contentType(): string;
        set contentType(value: string);
        resetContentType(): void;
        get contentTypeInput(): string | undefined;
        private _splitType?;
        get splitType(): string;
        set splitType(value: string);
        resetSplitType(): void;
        get splitTypeInput(): string | undefined;
        private _dataSource;
        get dataSource(): ValidationSpecificationValidationProfilesTransformJobDefinitionTransformInputDataSourcePropertyList;
        putDataSource(value: ValidationSpecificationValidationProfilesTransformJobDefinitionTransformInputDataSourceProperty[] | cdktn.IResolvable): void;
        resetDataSource(): void;
        get dataSourceInput(): cdktn.IResolvable | ValidationSpecificationValidationProfilesTransformJobDefinitionTransformInputDataSourceProperty[] | undefined;
    }
    class TransformInputPropertyList extends cdktn.ComplexList {
        internalValue?: TransformInputProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TransformInputPropertyOutputReference;
    }
    interface TransformOutputProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#accept AwsSagemakerAlgorithm#accept}
        */
        readonly accept?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#assemble_with AwsSagemakerAlgorithm#assemble_with}
        */
        readonly assembleWith?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#kms_key_id AwsSagemakerAlgorithm#kms_key_id}
        */
        readonly kmsKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#s3_output_path AwsSagemakerAlgorithm#s3_output_path}
        */
        readonly s3OutputPath: string;
    }
    class TransformOutputPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TransformOutputProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TransformOutputProperty | cdktn.IResolvable | undefined);
        private _accept?;
        get accept(): string;
        set accept(value: string);
        resetAccept(): void;
        get acceptInput(): string | undefined;
        private _assembleWith?;
        get assembleWith(): string;
        set assembleWith(value: string);
        resetAssembleWith(): void;
        get assembleWithInput(): string | undefined;
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        resetKmsKeyId(): void;
        get kmsKeyIdInput(): string | undefined;
        private _s3OutputPath?;
        get s3OutputPath(): string;
        set s3OutputPath(value: string);
        get s3OutputPathInput(): string | undefined;
    }
    class TransformOutputPropertyList extends cdktn.ComplexList {
        internalValue?: TransformOutputProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TransformOutputPropertyOutputReference;
    }
    interface TransformResourcesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#instance_count AwsSagemakerAlgorithm#instance_count}
        */
        readonly instanceCount: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#instance_type AwsSagemakerAlgorithm#instance_type}
        */
        readonly instanceType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#transform_ami_version AwsSagemakerAlgorithm#transform_ami_version}
        */
        readonly transformAmiVersion?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#volume_kms_key_id AwsSagemakerAlgorithm#volume_kms_key_id}
        */
        readonly volumeKmsKeyId?: string;
    }
    class TransformResourcesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TransformResourcesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TransformResourcesProperty | cdktn.IResolvable | undefined);
        private _instanceCount?;
        get instanceCount(): number;
        set instanceCount(value: number);
        get instanceCountInput(): number | undefined;
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        get instanceTypeInput(): string | undefined;
        private _transformAmiVersion?;
        get transformAmiVersion(): string;
        set transformAmiVersion(value: string);
        resetTransformAmiVersion(): void;
        get transformAmiVersionInput(): string | undefined;
        private _volumeKmsKeyId?;
        get volumeKmsKeyId(): string;
        set volumeKmsKeyId(value: string);
        resetVolumeKmsKeyId(): void;
        get volumeKmsKeyIdInput(): string | undefined;
    }
    class TransformResourcesPropertyList extends cdktn.ComplexList {
        internalValue?: TransformResourcesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TransformResourcesPropertyOutputReference;
    }
    interface TransformJobDefinitionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#batch_strategy AwsSagemakerAlgorithm#batch_strategy}
        */
        readonly batchStrategy?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#environment AwsSagemakerAlgorithm#environment}
        */
        readonly environment?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#max_concurrent_transforms AwsSagemakerAlgorithm#max_concurrent_transforms}
        */
        readonly maxConcurrentTransforms?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#max_payload_in_mb AwsSagemakerAlgorithm#max_payload_in_mb}
        */
        readonly maxPayloadInMb?: number;
        /**
        * transform_input block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#transform_input AwsSagemakerAlgorithm#transform_input}
        */
        readonly transformInput?: TransformInputProperty[] | cdktn.IResolvable;
        /**
        * transform_output block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#transform_output AwsSagemakerAlgorithm#transform_output}
        */
        readonly transformOutput?: TransformOutputProperty[] | cdktn.IResolvable;
        /**
        * transform_resources block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#transform_resources AwsSagemakerAlgorithm#transform_resources}
        */
        readonly transformResources?: TransformResourcesProperty[] | cdktn.IResolvable;
    }
    class TransformJobDefinitionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TransformJobDefinitionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TransformJobDefinitionProperty | cdktn.IResolvable | undefined);
        private _batchStrategy?;
        get batchStrategy(): string;
        set batchStrategy(value: string);
        resetBatchStrategy(): void;
        get batchStrategyInput(): string | undefined;
        private _environment?;
        get environment(): {
            [key: string]: string;
        };
        set environment(value: {
            [key: string]: string;
        });
        resetEnvironment(): void;
        get environmentInput(): {
            [key: string]: string;
        } | undefined;
        private _maxConcurrentTransforms?;
        get maxConcurrentTransforms(): number;
        set maxConcurrentTransforms(value: number);
        resetMaxConcurrentTransforms(): void;
        get maxConcurrentTransformsInput(): number | undefined;
        private _maxPayloadInMb?;
        get maxPayloadInMb(): number;
        set maxPayloadInMb(value: number);
        resetMaxPayloadInMb(): void;
        get maxPayloadInMbInput(): number | undefined;
        private _transformInput;
        get transformInput(): TransformInputPropertyList;
        putTransformInput(value: TransformInputProperty[] | cdktn.IResolvable): void;
        resetTransformInput(): void;
        get transformInputInput(): cdktn.IResolvable | TransformInputProperty[] | undefined;
        private _transformOutput;
        get transformOutput(): TransformOutputPropertyList;
        putTransformOutput(value: TransformOutputProperty[] | cdktn.IResolvable): void;
        resetTransformOutput(): void;
        get transformOutputInput(): cdktn.IResolvable | TransformOutputProperty[] | undefined;
        private _transformResources;
        get transformResources(): TransformResourcesPropertyList;
        putTransformResources(value: TransformResourcesProperty[] | cdktn.IResolvable): void;
        resetTransformResources(): void;
        get transformResourcesInput(): cdktn.IResolvable | TransformResourcesProperty[] | undefined;
    }
    class TransformJobDefinitionPropertyList extends cdktn.ComplexList {
        internalValue?: TransformJobDefinitionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TransformJobDefinitionPropertyOutputReference;
    }
    interface ValidationProfilesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#profile_name AwsSagemakerAlgorithm#profile_name}
        */
        readonly profileName: string;
        /**
        * training_job_definition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#training_job_definition AwsSagemakerAlgorithm#training_job_definition}
        */
        readonly trainingJobDefinition?: TrainingJobDefinitionProperty[] | cdktn.IResolvable;
        /**
        * transform_job_definition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#transform_job_definition AwsSagemakerAlgorithm#transform_job_definition}
        */
        readonly transformJobDefinition?: TransformJobDefinitionProperty[] | cdktn.IResolvable;
    }
    class ValidationProfilesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ValidationProfilesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ValidationProfilesProperty | cdktn.IResolvable | undefined);
        private _profileName?;
        get profileName(): string;
        set profileName(value: string);
        get profileNameInput(): string | undefined;
        private _trainingJobDefinition;
        get trainingJobDefinition(): TrainingJobDefinitionPropertyList;
        putTrainingJobDefinition(value: TrainingJobDefinitionProperty[] | cdktn.IResolvable): void;
        resetTrainingJobDefinition(): void;
        get trainingJobDefinitionInput(): cdktn.IResolvable | TrainingJobDefinitionProperty[] | undefined;
        private _transformJobDefinition;
        get transformJobDefinition(): TransformJobDefinitionPropertyList;
        putTransformJobDefinition(value: TransformJobDefinitionProperty[] | cdktn.IResolvable): void;
        resetTransformJobDefinition(): void;
        get transformJobDefinitionInput(): cdktn.IResolvable | TransformJobDefinitionProperty[] | undefined;
    }
    class ValidationProfilesPropertyList extends cdktn.ComplexList {
        internalValue?: ValidationProfilesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ValidationProfilesPropertyOutputReference;
    }
    interface ValidationSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#validation_role AwsSagemakerAlgorithm#validation_role}
        */
        readonly validationRole: string;
        /**
        * validation_profiles block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_algorithm#validation_profiles AwsSagemakerAlgorithm#validation_profiles}
        */
        readonly validationProfiles?: ValidationProfilesProperty[] | cdktn.IResolvable;
    }
    class ValidationSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ValidationSpecificationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ValidationSpecificationProperty | cdktn.IResolvable | undefined);
        private _validationRole?;
        get validationRole(): string;
        set validationRole(value: string);
        get validationRoleInput(): string | undefined;
        private _validationProfiles;
        get validationProfiles(): ValidationProfilesPropertyList;
        putValidationProfiles(value: ValidationProfilesProperty[] | cdktn.IResolvable): void;
        resetValidationProfiles(): void;
        get validationProfilesInput(): cdktn.IResolvable | ValidationProfilesProperty[] | undefined;
    }
    class ValidationSpecificationPropertyList extends cdktn.ComplexList {
        internalValue?: ValidationSpecificationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ValidationSpecificationPropertyOutputReference;
    }
}
