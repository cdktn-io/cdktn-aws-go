import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSagemakerDomainConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#app_network_access_type AwsSagemakerDomain#app_network_access_type}
    */
    readonly appNetworkAccessType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#app_security_group_management AwsSagemakerDomain#app_security_group_management}
    */
    readonly appSecurityGroupManagement?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#auth_mode AwsSagemakerDomain#auth_mode}
    */
    readonly authMode: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#domain_name AwsSagemakerDomain#domain_name}
    */
    readonly domainName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#id AwsSagemakerDomain#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#kms_key_id AwsSagemakerDomain#kms_key_id}
    */
    readonly kmsKeyId?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#region AwsSagemakerDomain#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#subnet_ids AwsSagemakerDomain#subnet_ids}
    */
    readonly subnetIds: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#tag_propagation AwsSagemakerDomain#tag_propagation}
    */
    readonly tagPropagation?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#tags AwsSagemakerDomain#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#tags_all AwsSagemakerDomain#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#vpc_id AwsSagemakerDomain#vpc_id}
    */
    readonly vpcId: string;
    /**
    * default_space_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#default_space_settings AwsSagemakerDomain#default_space_settings}
    */
    readonly defaultSpaceSettings?: AwsSagemakerDomain.DefaultSpaceSettingsProperty;
    /**
    * default_user_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#default_user_settings AwsSagemakerDomain#default_user_settings}
    */
    readonly defaultUserSettings: AwsSagemakerDomain.DefaultUserSettingsProperty;
    /**
    * domain_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#domain_settings AwsSagemakerDomain#domain_settings}
    */
    readonly domainSettings?: AwsSagemakerDomain.DomainSettingsProperty;
    /**
    * retention_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#retention_policy AwsSagemakerDomain#retention_policy}
    */
    readonly retentionPolicy?: AwsSagemakerDomain.RetentionPolicyProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain aws_sagemaker_domain}
*/
export declare class AwsSagemakerDomain extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_sagemaker_domain";
    /**
    * Generates CDKTN code for importing a AwsSagemakerDomain resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSagemakerDomain to import
    * @param importFromId The id of the existing AwsSagemakerDomain that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSagemakerDomain to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain aws_sagemaker_domain} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSagemakerDomainConfig
    */
    constructor(scope: Construct, id: string, config: AwsSagemakerDomainConfig);
    private _appNetworkAccessType?;
    get appNetworkAccessType(): string;
    set appNetworkAccessType(value: string);
    resetAppNetworkAccessType(): void;
    get appNetworkAccessTypeInput(): string | undefined;
    private _appSecurityGroupManagement?;
    get appSecurityGroupManagement(): string;
    set appSecurityGroupManagement(value: string);
    resetAppSecurityGroupManagement(): void;
    get appSecurityGroupManagementInput(): string | undefined;
    get arn(): string;
    private _authMode?;
    get authMode(): string;
    set authMode(value: string);
    get authModeInput(): string | undefined;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    get homeEfsFileSystemId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _kmsKeyId?;
    get kmsKeyId(): string;
    set kmsKeyId(value: string);
    resetKmsKeyId(): void;
    get kmsKeyIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get securityGroupIdForDomainBoundary(): string;
    get singleSignOnApplicationArn(): string;
    get singleSignOnManagedApplicationInstanceId(): string;
    private _subnetIds?;
    get subnetIds(): string[];
    set subnetIds(value: string[]);
    get subnetIdsInput(): string[] | undefined;
    private _tagPropagation?;
    get tagPropagation(): string;
    set tagPropagation(value: string);
    resetTagPropagation(): void;
    get tagPropagationInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get url(): string;
    private _vpcId?;
    get vpcId(): string;
    set vpcId(value: string);
    get vpcIdInput(): string | undefined;
    private _defaultSpaceSettings;
    get defaultSpaceSettings(): AwsSagemakerDomain.DefaultSpaceSettingsPropertyOutputReference;
    putDefaultSpaceSettings(value: AwsSagemakerDomain.DefaultSpaceSettingsProperty): void;
    resetDefaultSpaceSettings(): void;
    get defaultSpaceSettingsInput(): AwsSagemakerDomain.DefaultSpaceSettingsProperty | undefined;
    private _defaultUserSettings;
    get defaultUserSettings(): AwsSagemakerDomain.DefaultUserSettingsPropertyOutputReference;
    putDefaultUserSettings(value: AwsSagemakerDomain.DefaultUserSettingsProperty): void;
    get defaultUserSettingsInput(): AwsSagemakerDomain.DefaultUserSettingsProperty | undefined;
    private _domainSettings;
    get domainSettings(): AwsSagemakerDomain.DomainSettingsPropertyOutputReference;
    putDomainSettings(value: AwsSagemakerDomain.DomainSettingsProperty): void;
    resetDomainSettings(): void;
    get domainSettingsInput(): AwsSagemakerDomain.DomainSettingsProperty | undefined;
    private _retentionPolicy;
    get retentionPolicy(): AwsSagemakerDomain.RetentionPolicyPropertyOutputReference;
    putRetentionPolicy(value: AwsSagemakerDomain.RetentionPolicyProperty): void;
    resetRetentionPolicy(): void;
    get retentionPolicyInput(): AwsSagemakerDomain.RetentionPolicyProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsSagemakerDomainDefaultSpaceSettingsCustomFileSystemConfigEfsFileSystemConfigPropertyToTerraform(struct?: AwsSagemakerDomain.DefaultSpaceSettingsCustomFileSystemConfigEfsFileSystemConfigPropertyOutputReference | AwsSagemakerDomain.DefaultSpaceSettingsCustomFileSystemConfigEfsFileSystemConfigProperty): any;
export declare function awsSagemakerDomainDefaultSpaceSettingsCustomFileSystemConfigEfsFileSystemConfigPropertyToHclTerraform(struct?: AwsSagemakerDomain.DefaultSpaceSettingsCustomFileSystemConfigEfsFileSystemConfigPropertyOutputReference | AwsSagemakerDomain.DefaultSpaceSettingsCustomFileSystemConfigEfsFileSystemConfigProperty): any;
export declare function awsSagemakerDomainDefaultSpaceSettingsCustomFileSystemConfigPropertyToTerraform(struct?: AwsSagemakerDomain.DefaultSpaceSettingsCustomFileSystemConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerDomainDefaultSpaceSettingsCustomFileSystemConfigPropertyToHclTerraform(struct?: AwsSagemakerDomain.DefaultSpaceSettingsCustomFileSystemConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerDomainDefaultSpaceSettingsCustomPosixUserConfigPropertyToTerraform(struct?: AwsSagemakerDomain.DefaultSpaceSettingsCustomPosixUserConfigPropertyOutputReference | AwsSagemakerDomain.DefaultSpaceSettingsCustomPosixUserConfigProperty): any;
export declare function awsSagemakerDomainDefaultSpaceSettingsCustomPosixUserConfigPropertyToHclTerraform(struct?: AwsSagemakerDomain.DefaultSpaceSettingsCustomPosixUserConfigPropertyOutputReference | AwsSagemakerDomain.DefaultSpaceSettingsCustomPosixUserConfigProperty): any;
export declare function awsSagemakerDomainDefaultSpaceSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsPropertyToTerraform(struct?: AwsSagemakerDomain.DefaultSpaceSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsPropertyOutputReference | AwsSagemakerDomain.DefaultSpaceSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsProperty): any;
export declare function awsSagemakerDomainDefaultSpaceSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsPropertyToHclTerraform(struct?: AwsSagemakerDomain.DefaultSpaceSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsPropertyOutputReference | AwsSagemakerDomain.DefaultSpaceSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsProperty): any;
export declare function awsSagemakerDomainDefaultSpaceSettingsJupyterLabAppSettingsAppLifecycleManagementPropertyToTerraform(struct?: AwsSagemakerDomain.DefaultSpaceSettingsJupyterLabAppSettingsAppLifecycleManagementPropertyOutputReference | AwsSagemakerDomain.DefaultSpaceSettingsJupyterLabAppSettingsAppLifecycleManagementProperty): any;
export declare function awsSagemakerDomainDefaultSpaceSettingsJupyterLabAppSettingsAppLifecycleManagementPropertyToHclTerraform(struct?: AwsSagemakerDomain.DefaultSpaceSettingsJupyterLabAppSettingsAppLifecycleManagementPropertyOutputReference | AwsSagemakerDomain.DefaultSpaceSettingsJupyterLabAppSettingsAppLifecycleManagementProperty): any;
export declare function awsSagemakerDomainDefaultSpaceSettingsJupyterLabAppSettingsCodeRepositoryPropertyToTerraform(struct?: AwsSagemakerDomain.DefaultSpaceSettingsJupyterLabAppSettingsCodeRepositoryProperty | cdktn.IResolvable): any;
export declare function awsSagemakerDomainDefaultSpaceSettingsJupyterLabAppSettingsCodeRepositoryPropertyToHclTerraform(struct?: AwsSagemakerDomain.DefaultSpaceSettingsJupyterLabAppSettingsCodeRepositoryProperty | cdktn.IResolvable): any;
export declare function awsSagemakerDomainDefaultSpaceSettingsJupyterLabAppSettingsCustomImagePropertyToTerraform(struct?: AwsSagemakerDomain.DefaultSpaceSettingsJupyterLabAppSettingsCustomImageProperty | cdktn.IResolvable): any;
export declare function awsSagemakerDomainDefaultSpaceSettingsJupyterLabAppSettingsCustomImagePropertyToHclTerraform(struct?: AwsSagemakerDomain.DefaultSpaceSettingsJupyterLabAppSettingsCustomImageProperty | cdktn.IResolvable): any;
export declare function awsSagemakerDomainDefaultSpaceSettingsJupyterLabAppSettingsDefaultResourceSpecPropertyToTerraform(struct?: AwsSagemakerDomain.DefaultSpaceSettingsJupyterLabAppSettingsDefaultResourceSpecPropertyOutputReference | AwsSagemakerDomain.DefaultSpaceSettingsJupyterLabAppSettingsDefaultResourceSpecProperty): any;
export declare function awsSagemakerDomainDefaultSpaceSettingsJupyterLabAppSettingsDefaultResourceSpecPropertyToHclTerraform(struct?: AwsSagemakerDomain.DefaultSpaceSettingsJupyterLabAppSettingsDefaultResourceSpecPropertyOutputReference | AwsSagemakerDomain.DefaultSpaceSettingsJupyterLabAppSettingsDefaultResourceSpecProperty): any;
export declare function awsSagemakerDomainDefaultSpaceSettingsJupyterLabAppSettingsEmrSettingsPropertyToTerraform(struct?: AwsSagemakerDomain.DefaultSpaceSettingsJupyterLabAppSettingsEmrSettingsPropertyOutputReference | AwsSagemakerDomain.DefaultSpaceSettingsJupyterLabAppSettingsEmrSettingsProperty): any;
export declare function awsSagemakerDomainDefaultSpaceSettingsJupyterLabAppSettingsEmrSettingsPropertyToHclTerraform(struct?: AwsSagemakerDomain.DefaultSpaceSettingsJupyterLabAppSettingsEmrSettingsPropertyOutputReference | AwsSagemakerDomain.DefaultSpaceSettingsJupyterLabAppSettingsEmrSettingsProperty): any;
export declare function awsSagemakerDomainDefaultSpaceSettingsJupyterLabAppSettingsPropertyToTerraform(struct?: AwsSagemakerDomain.DefaultSpaceSettingsJupyterLabAppSettingsPropertyOutputReference | AwsSagemakerDomain.DefaultSpaceSettingsJupyterLabAppSettingsProperty): any;
export declare function awsSagemakerDomainDefaultSpaceSettingsJupyterLabAppSettingsPropertyToHclTerraform(struct?: AwsSagemakerDomain.DefaultSpaceSettingsJupyterLabAppSettingsPropertyOutputReference | AwsSagemakerDomain.DefaultSpaceSettingsJupyterLabAppSettingsProperty): any;
export declare function awsSagemakerDomainDefaultSpaceSettingsJupyterServerAppSettingsCodeRepositoryPropertyToTerraform(struct?: AwsSagemakerDomain.DefaultSpaceSettingsJupyterServerAppSettingsCodeRepositoryProperty | cdktn.IResolvable): any;
export declare function awsSagemakerDomainDefaultSpaceSettingsJupyterServerAppSettingsCodeRepositoryPropertyToHclTerraform(struct?: AwsSagemakerDomain.DefaultSpaceSettingsJupyterServerAppSettingsCodeRepositoryProperty | cdktn.IResolvable): any;
export declare function awsSagemakerDomainDefaultSpaceSettingsJupyterServerAppSettingsDefaultResourceSpecPropertyToTerraform(struct?: AwsSagemakerDomain.DefaultSpaceSettingsJupyterServerAppSettingsDefaultResourceSpecPropertyOutputReference | AwsSagemakerDomain.DefaultSpaceSettingsJupyterServerAppSettingsDefaultResourceSpecProperty): any;
export declare function awsSagemakerDomainDefaultSpaceSettingsJupyterServerAppSettingsDefaultResourceSpecPropertyToHclTerraform(struct?: AwsSagemakerDomain.DefaultSpaceSettingsJupyterServerAppSettingsDefaultResourceSpecPropertyOutputReference | AwsSagemakerDomain.DefaultSpaceSettingsJupyterServerAppSettingsDefaultResourceSpecProperty): any;
export declare function awsSagemakerDomainDefaultSpaceSettingsJupyterServerAppSettingsPropertyToTerraform(struct?: AwsSagemakerDomain.DefaultSpaceSettingsJupyterServerAppSettingsPropertyOutputReference | AwsSagemakerDomain.DefaultSpaceSettingsJupyterServerAppSettingsProperty): any;
export declare function awsSagemakerDomainDefaultSpaceSettingsJupyterServerAppSettingsPropertyToHclTerraform(struct?: AwsSagemakerDomain.DefaultSpaceSettingsJupyterServerAppSettingsPropertyOutputReference | AwsSagemakerDomain.DefaultSpaceSettingsJupyterServerAppSettingsProperty): any;
export declare function awsSagemakerDomainDefaultSpaceSettingsKernelGatewayAppSettingsCustomImagePropertyToTerraform(struct?: AwsSagemakerDomain.DefaultSpaceSettingsKernelGatewayAppSettingsCustomImageProperty | cdktn.IResolvable): any;
export declare function awsSagemakerDomainDefaultSpaceSettingsKernelGatewayAppSettingsCustomImagePropertyToHclTerraform(struct?: AwsSagemakerDomain.DefaultSpaceSettingsKernelGatewayAppSettingsCustomImageProperty | cdktn.IResolvable): any;
export declare function awsSagemakerDomainDefaultSpaceSettingsKernelGatewayAppSettingsDefaultResourceSpecPropertyToTerraform(struct?: AwsSagemakerDomain.DefaultSpaceSettingsKernelGatewayAppSettingsDefaultResourceSpecPropertyOutputReference | AwsSagemakerDomain.DefaultSpaceSettingsKernelGatewayAppSettingsDefaultResourceSpecProperty): any;
export declare function awsSagemakerDomainDefaultSpaceSettingsKernelGatewayAppSettingsDefaultResourceSpecPropertyToHclTerraform(struct?: AwsSagemakerDomain.DefaultSpaceSettingsKernelGatewayAppSettingsDefaultResourceSpecPropertyOutputReference | AwsSagemakerDomain.DefaultSpaceSettingsKernelGatewayAppSettingsDefaultResourceSpecProperty): any;
export declare function awsSagemakerDomainDefaultSpaceSettingsKernelGatewayAppSettingsPropertyToTerraform(struct?: AwsSagemakerDomain.DefaultSpaceSettingsKernelGatewayAppSettingsPropertyOutputReference | AwsSagemakerDomain.DefaultSpaceSettingsKernelGatewayAppSettingsProperty): any;
export declare function awsSagemakerDomainDefaultSpaceSettingsKernelGatewayAppSettingsPropertyToHclTerraform(struct?: AwsSagemakerDomain.DefaultSpaceSettingsKernelGatewayAppSettingsPropertyOutputReference | AwsSagemakerDomain.DefaultSpaceSettingsKernelGatewayAppSettingsProperty): any;
export declare function awsSagemakerDomainDefaultSpaceSettingsSpaceStorageSettingsDefaultEbsStorageSettingsPropertyToTerraform(struct?: AwsSagemakerDomain.DefaultSpaceSettingsSpaceStorageSettingsDefaultEbsStorageSettingsPropertyOutputReference | AwsSagemakerDomain.DefaultSpaceSettingsSpaceStorageSettingsDefaultEbsStorageSettingsProperty): any;
export declare function awsSagemakerDomainDefaultSpaceSettingsSpaceStorageSettingsDefaultEbsStorageSettingsPropertyToHclTerraform(struct?: AwsSagemakerDomain.DefaultSpaceSettingsSpaceStorageSettingsDefaultEbsStorageSettingsPropertyOutputReference | AwsSagemakerDomain.DefaultSpaceSettingsSpaceStorageSettingsDefaultEbsStorageSettingsProperty): any;
export declare function awsSagemakerDomainDefaultSpaceSettingsSpaceStorageSettingsPropertyToTerraform(struct?: AwsSagemakerDomain.DefaultSpaceSettingsSpaceStorageSettingsPropertyOutputReference | AwsSagemakerDomain.DefaultSpaceSettingsSpaceStorageSettingsProperty): any;
export declare function awsSagemakerDomainDefaultSpaceSettingsSpaceStorageSettingsPropertyToHclTerraform(struct?: AwsSagemakerDomain.DefaultSpaceSettingsSpaceStorageSettingsPropertyOutputReference | AwsSagemakerDomain.DefaultSpaceSettingsSpaceStorageSettingsProperty): any;
export declare function awsSagemakerDomainDefaultSpaceSettingsPropertyToTerraform(struct?: AwsSagemakerDomain.DefaultSpaceSettingsPropertyOutputReference | AwsSagemakerDomain.DefaultSpaceSettingsProperty): any;
export declare function awsSagemakerDomainDefaultSpaceSettingsPropertyToHclTerraform(struct?: AwsSagemakerDomain.DefaultSpaceSettingsPropertyOutputReference | AwsSagemakerDomain.DefaultSpaceSettingsProperty): any;
export declare function awsSagemakerDomainDirectDeploySettingsPropertyToTerraform(struct?: AwsSagemakerDomain.DirectDeploySettingsPropertyOutputReference | AwsSagemakerDomain.DirectDeploySettingsProperty): any;
export declare function awsSagemakerDomainDirectDeploySettingsPropertyToHclTerraform(struct?: AwsSagemakerDomain.DirectDeploySettingsPropertyOutputReference | AwsSagemakerDomain.DirectDeploySettingsProperty): any;
export declare function awsSagemakerDomainEmrServerlessSettingsPropertyToTerraform(struct?: AwsSagemakerDomain.EmrServerlessSettingsPropertyOutputReference | AwsSagemakerDomain.EmrServerlessSettingsProperty): any;
export declare function awsSagemakerDomainEmrServerlessSettingsPropertyToHclTerraform(struct?: AwsSagemakerDomain.EmrServerlessSettingsPropertyOutputReference | AwsSagemakerDomain.EmrServerlessSettingsProperty): any;
export declare function awsSagemakerDomainGenerativeAiSettingsPropertyToTerraform(struct?: AwsSagemakerDomain.GenerativeAiSettingsPropertyOutputReference | AwsSagemakerDomain.GenerativeAiSettingsProperty): any;
export declare function awsSagemakerDomainGenerativeAiSettingsPropertyToHclTerraform(struct?: AwsSagemakerDomain.GenerativeAiSettingsPropertyOutputReference | AwsSagemakerDomain.GenerativeAiSettingsProperty): any;
export declare function awsSagemakerDomainIdentityProviderOauthSettingsPropertyToTerraform(struct?: AwsSagemakerDomain.IdentityProviderOauthSettingsProperty | cdktn.IResolvable): any;
export declare function awsSagemakerDomainIdentityProviderOauthSettingsPropertyToHclTerraform(struct?: AwsSagemakerDomain.IdentityProviderOauthSettingsProperty | cdktn.IResolvable): any;
export declare function awsSagemakerDomainKendraSettingsPropertyToTerraform(struct?: AwsSagemakerDomain.KendraSettingsPropertyOutputReference | AwsSagemakerDomain.KendraSettingsProperty): any;
export declare function awsSagemakerDomainKendraSettingsPropertyToHclTerraform(struct?: AwsSagemakerDomain.KendraSettingsPropertyOutputReference | AwsSagemakerDomain.KendraSettingsProperty): any;
export declare function awsSagemakerDomainModelRegisterSettingsPropertyToTerraform(struct?: AwsSagemakerDomain.ModelRegisterSettingsPropertyOutputReference | AwsSagemakerDomain.ModelRegisterSettingsProperty): any;
export declare function awsSagemakerDomainModelRegisterSettingsPropertyToHclTerraform(struct?: AwsSagemakerDomain.ModelRegisterSettingsPropertyOutputReference | AwsSagemakerDomain.ModelRegisterSettingsProperty): any;
export declare function awsSagemakerDomainTimeSeriesForecastingSettingsPropertyToTerraform(struct?: AwsSagemakerDomain.TimeSeriesForecastingSettingsPropertyOutputReference | AwsSagemakerDomain.TimeSeriesForecastingSettingsProperty): any;
export declare function awsSagemakerDomainTimeSeriesForecastingSettingsPropertyToHclTerraform(struct?: AwsSagemakerDomain.TimeSeriesForecastingSettingsPropertyOutputReference | AwsSagemakerDomain.TimeSeriesForecastingSettingsProperty): any;
export declare function awsSagemakerDomainWorkspaceSettingsPropertyToTerraform(struct?: AwsSagemakerDomain.WorkspaceSettingsPropertyOutputReference | AwsSagemakerDomain.WorkspaceSettingsProperty): any;
export declare function awsSagemakerDomainWorkspaceSettingsPropertyToHclTerraform(struct?: AwsSagemakerDomain.WorkspaceSettingsPropertyOutputReference | AwsSagemakerDomain.WorkspaceSettingsProperty): any;
export declare function awsSagemakerDomainCanvasAppSettingsPropertyToTerraform(struct?: AwsSagemakerDomain.CanvasAppSettingsPropertyOutputReference | AwsSagemakerDomain.CanvasAppSettingsProperty): any;
export declare function awsSagemakerDomainCanvasAppSettingsPropertyToHclTerraform(struct?: AwsSagemakerDomain.CanvasAppSettingsPropertyOutputReference | AwsSagemakerDomain.CanvasAppSettingsProperty): any;
export declare function awsSagemakerDomainDefaultUserSettingsCodeEditorAppSettingsAppLifecycleManagementIdleSettingsPropertyToTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsCodeEditorAppSettingsAppLifecycleManagementIdleSettingsPropertyOutputReference | AwsSagemakerDomain.DefaultUserSettingsCodeEditorAppSettingsAppLifecycleManagementIdleSettingsProperty): any;
export declare function awsSagemakerDomainDefaultUserSettingsCodeEditorAppSettingsAppLifecycleManagementIdleSettingsPropertyToHclTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsCodeEditorAppSettingsAppLifecycleManagementIdleSettingsPropertyOutputReference | AwsSagemakerDomain.DefaultUserSettingsCodeEditorAppSettingsAppLifecycleManagementIdleSettingsProperty): any;
export declare function awsSagemakerDomainDefaultUserSettingsCodeEditorAppSettingsAppLifecycleManagementPropertyToTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsCodeEditorAppSettingsAppLifecycleManagementPropertyOutputReference | AwsSagemakerDomain.DefaultUserSettingsCodeEditorAppSettingsAppLifecycleManagementProperty): any;
export declare function awsSagemakerDomainDefaultUserSettingsCodeEditorAppSettingsAppLifecycleManagementPropertyToHclTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsCodeEditorAppSettingsAppLifecycleManagementPropertyOutputReference | AwsSagemakerDomain.DefaultUserSettingsCodeEditorAppSettingsAppLifecycleManagementProperty): any;
export declare function awsSagemakerDomainDefaultUserSettingsCodeEditorAppSettingsCustomImagePropertyToTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsCodeEditorAppSettingsCustomImageProperty | cdktn.IResolvable): any;
export declare function awsSagemakerDomainDefaultUserSettingsCodeEditorAppSettingsCustomImagePropertyToHclTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsCodeEditorAppSettingsCustomImageProperty | cdktn.IResolvable): any;
export declare function awsSagemakerDomainDefaultUserSettingsCodeEditorAppSettingsDefaultResourceSpecPropertyToTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsCodeEditorAppSettingsDefaultResourceSpecPropertyOutputReference | AwsSagemakerDomain.DefaultUserSettingsCodeEditorAppSettingsDefaultResourceSpecProperty): any;
export declare function awsSagemakerDomainDefaultUserSettingsCodeEditorAppSettingsDefaultResourceSpecPropertyToHclTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsCodeEditorAppSettingsDefaultResourceSpecPropertyOutputReference | AwsSagemakerDomain.DefaultUserSettingsCodeEditorAppSettingsDefaultResourceSpecProperty): any;
export declare function awsSagemakerDomainCodeEditorAppSettingsPropertyToTerraform(struct?: AwsSagemakerDomain.CodeEditorAppSettingsPropertyOutputReference | AwsSagemakerDomain.CodeEditorAppSettingsProperty): any;
export declare function awsSagemakerDomainCodeEditorAppSettingsPropertyToHclTerraform(struct?: AwsSagemakerDomain.CodeEditorAppSettingsPropertyOutputReference | AwsSagemakerDomain.CodeEditorAppSettingsProperty): any;
export declare function awsSagemakerDomainDefaultUserSettingsCustomFileSystemConfigEfsFileSystemConfigPropertyToTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsCustomFileSystemConfigEfsFileSystemConfigPropertyOutputReference | AwsSagemakerDomain.DefaultUserSettingsCustomFileSystemConfigEfsFileSystemConfigProperty): any;
export declare function awsSagemakerDomainDefaultUserSettingsCustomFileSystemConfigEfsFileSystemConfigPropertyToHclTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsCustomFileSystemConfigEfsFileSystemConfigPropertyOutputReference | AwsSagemakerDomain.DefaultUserSettingsCustomFileSystemConfigEfsFileSystemConfigProperty): any;
export declare function awsSagemakerDomainDefaultUserSettingsCustomFileSystemConfigPropertyToTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsCustomFileSystemConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerDomainDefaultUserSettingsCustomFileSystemConfigPropertyToHclTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsCustomFileSystemConfigProperty | cdktn.IResolvable): any;
export declare function awsSagemakerDomainDefaultUserSettingsCustomPosixUserConfigPropertyToTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsCustomPosixUserConfigPropertyOutputReference | AwsSagemakerDomain.DefaultUserSettingsCustomPosixUserConfigProperty): any;
export declare function awsSagemakerDomainDefaultUserSettingsCustomPosixUserConfigPropertyToHclTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsCustomPosixUserConfigPropertyOutputReference | AwsSagemakerDomain.DefaultUserSettingsCustomPosixUserConfigProperty): any;
export declare function awsSagemakerDomainDefaultUserSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsPropertyToTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsPropertyOutputReference | AwsSagemakerDomain.DefaultUserSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsProperty): any;
export declare function awsSagemakerDomainDefaultUserSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsPropertyToHclTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsPropertyOutputReference | AwsSagemakerDomain.DefaultUserSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsProperty): any;
export declare function awsSagemakerDomainDefaultUserSettingsJupyterLabAppSettingsAppLifecycleManagementPropertyToTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsJupyterLabAppSettingsAppLifecycleManagementPropertyOutputReference | AwsSagemakerDomain.DefaultUserSettingsJupyterLabAppSettingsAppLifecycleManagementProperty): any;
export declare function awsSagemakerDomainDefaultUserSettingsJupyterLabAppSettingsAppLifecycleManagementPropertyToHclTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsJupyterLabAppSettingsAppLifecycleManagementPropertyOutputReference | AwsSagemakerDomain.DefaultUserSettingsJupyterLabAppSettingsAppLifecycleManagementProperty): any;
export declare function awsSagemakerDomainDefaultUserSettingsJupyterLabAppSettingsCodeRepositoryPropertyToTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsJupyterLabAppSettingsCodeRepositoryProperty | cdktn.IResolvable): any;
export declare function awsSagemakerDomainDefaultUserSettingsJupyterLabAppSettingsCodeRepositoryPropertyToHclTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsJupyterLabAppSettingsCodeRepositoryProperty | cdktn.IResolvable): any;
export declare function awsSagemakerDomainDefaultUserSettingsJupyterLabAppSettingsCustomImagePropertyToTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsJupyterLabAppSettingsCustomImageProperty | cdktn.IResolvable): any;
export declare function awsSagemakerDomainDefaultUserSettingsJupyterLabAppSettingsCustomImagePropertyToHclTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsJupyterLabAppSettingsCustomImageProperty | cdktn.IResolvable): any;
export declare function awsSagemakerDomainDefaultUserSettingsJupyterLabAppSettingsDefaultResourceSpecPropertyToTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsJupyterLabAppSettingsDefaultResourceSpecPropertyOutputReference | AwsSagemakerDomain.DefaultUserSettingsJupyterLabAppSettingsDefaultResourceSpecProperty): any;
export declare function awsSagemakerDomainDefaultUserSettingsJupyterLabAppSettingsDefaultResourceSpecPropertyToHclTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsJupyterLabAppSettingsDefaultResourceSpecPropertyOutputReference | AwsSagemakerDomain.DefaultUserSettingsJupyterLabAppSettingsDefaultResourceSpecProperty): any;
export declare function awsSagemakerDomainDefaultUserSettingsJupyterLabAppSettingsEmrSettingsPropertyToTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsJupyterLabAppSettingsEmrSettingsPropertyOutputReference | AwsSagemakerDomain.DefaultUserSettingsJupyterLabAppSettingsEmrSettingsProperty): any;
export declare function awsSagemakerDomainDefaultUserSettingsJupyterLabAppSettingsEmrSettingsPropertyToHclTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsJupyterLabAppSettingsEmrSettingsPropertyOutputReference | AwsSagemakerDomain.DefaultUserSettingsJupyterLabAppSettingsEmrSettingsProperty): any;
export declare function awsSagemakerDomainDefaultUserSettingsJupyterLabAppSettingsPropertyToTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsJupyterLabAppSettingsPropertyOutputReference | AwsSagemakerDomain.DefaultUserSettingsJupyterLabAppSettingsProperty): any;
export declare function awsSagemakerDomainDefaultUserSettingsJupyterLabAppSettingsPropertyToHclTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsJupyterLabAppSettingsPropertyOutputReference | AwsSagemakerDomain.DefaultUserSettingsJupyterLabAppSettingsProperty): any;
export declare function awsSagemakerDomainDefaultUserSettingsJupyterServerAppSettingsCodeRepositoryPropertyToTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsJupyterServerAppSettingsCodeRepositoryProperty | cdktn.IResolvable): any;
export declare function awsSagemakerDomainDefaultUserSettingsJupyterServerAppSettingsCodeRepositoryPropertyToHclTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsJupyterServerAppSettingsCodeRepositoryProperty | cdktn.IResolvable): any;
export declare function awsSagemakerDomainDefaultUserSettingsJupyterServerAppSettingsDefaultResourceSpecPropertyToTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsJupyterServerAppSettingsDefaultResourceSpecPropertyOutputReference | AwsSagemakerDomain.DefaultUserSettingsJupyterServerAppSettingsDefaultResourceSpecProperty): any;
export declare function awsSagemakerDomainDefaultUserSettingsJupyterServerAppSettingsDefaultResourceSpecPropertyToHclTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsJupyterServerAppSettingsDefaultResourceSpecPropertyOutputReference | AwsSagemakerDomain.DefaultUserSettingsJupyterServerAppSettingsDefaultResourceSpecProperty): any;
export declare function awsSagemakerDomainDefaultUserSettingsJupyterServerAppSettingsPropertyToTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsJupyterServerAppSettingsPropertyOutputReference | AwsSagemakerDomain.DefaultUserSettingsJupyterServerAppSettingsProperty): any;
export declare function awsSagemakerDomainDefaultUserSettingsJupyterServerAppSettingsPropertyToHclTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsJupyterServerAppSettingsPropertyOutputReference | AwsSagemakerDomain.DefaultUserSettingsJupyterServerAppSettingsProperty): any;
export declare function awsSagemakerDomainDefaultUserSettingsKernelGatewayAppSettingsCustomImagePropertyToTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsKernelGatewayAppSettingsCustomImageProperty | cdktn.IResolvable): any;
export declare function awsSagemakerDomainDefaultUserSettingsKernelGatewayAppSettingsCustomImagePropertyToHclTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsKernelGatewayAppSettingsCustomImageProperty | cdktn.IResolvable): any;
export declare function awsSagemakerDomainDefaultUserSettingsKernelGatewayAppSettingsDefaultResourceSpecPropertyToTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsKernelGatewayAppSettingsDefaultResourceSpecPropertyOutputReference | AwsSagemakerDomain.DefaultUserSettingsKernelGatewayAppSettingsDefaultResourceSpecProperty): any;
export declare function awsSagemakerDomainDefaultUserSettingsKernelGatewayAppSettingsDefaultResourceSpecPropertyToHclTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsKernelGatewayAppSettingsDefaultResourceSpecPropertyOutputReference | AwsSagemakerDomain.DefaultUserSettingsKernelGatewayAppSettingsDefaultResourceSpecProperty): any;
export declare function awsSagemakerDomainDefaultUserSettingsKernelGatewayAppSettingsPropertyToTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsKernelGatewayAppSettingsPropertyOutputReference | AwsSagemakerDomain.DefaultUserSettingsKernelGatewayAppSettingsProperty): any;
export declare function awsSagemakerDomainDefaultUserSettingsKernelGatewayAppSettingsPropertyToHclTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsKernelGatewayAppSettingsPropertyOutputReference | AwsSagemakerDomain.DefaultUserSettingsKernelGatewayAppSettingsProperty): any;
export declare function awsSagemakerDomainDefaultUserSettingsRSessionAppSettingsCustomImagePropertyToTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsRSessionAppSettingsCustomImageProperty | cdktn.IResolvable): any;
export declare function awsSagemakerDomainDefaultUserSettingsRSessionAppSettingsCustomImagePropertyToHclTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsRSessionAppSettingsCustomImageProperty | cdktn.IResolvable): any;
export declare function awsSagemakerDomainDefaultUserSettingsRSessionAppSettingsDefaultResourceSpecPropertyToTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsRSessionAppSettingsDefaultResourceSpecPropertyOutputReference | AwsSagemakerDomain.DefaultUserSettingsRSessionAppSettingsDefaultResourceSpecProperty): any;
export declare function awsSagemakerDomainDefaultUserSettingsRSessionAppSettingsDefaultResourceSpecPropertyToHclTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsRSessionAppSettingsDefaultResourceSpecPropertyOutputReference | AwsSagemakerDomain.DefaultUserSettingsRSessionAppSettingsDefaultResourceSpecProperty): any;
export declare function awsSagemakerDomainRSessionAppSettingsPropertyToTerraform(struct?: AwsSagemakerDomain.RSessionAppSettingsPropertyOutputReference | AwsSagemakerDomain.RSessionAppSettingsProperty): any;
export declare function awsSagemakerDomainRSessionAppSettingsPropertyToHclTerraform(struct?: AwsSagemakerDomain.RSessionAppSettingsPropertyOutputReference | AwsSagemakerDomain.RSessionAppSettingsProperty): any;
export declare function awsSagemakerDomainRStudioServerProAppSettingsPropertyToTerraform(struct?: AwsSagemakerDomain.RStudioServerProAppSettingsPropertyOutputReference | AwsSagemakerDomain.RStudioServerProAppSettingsProperty): any;
export declare function awsSagemakerDomainRStudioServerProAppSettingsPropertyToHclTerraform(struct?: AwsSagemakerDomain.RStudioServerProAppSettingsPropertyOutputReference | AwsSagemakerDomain.RStudioServerProAppSettingsProperty): any;
export declare function awsSagemakerDomainSharingSettingsPropertyToTerraform(struct?: AwsSagemakerDomain.SharingSettingsPropertyOutputReference | AwsSagemakerDomain.SharingSettingsProperty): any;
export declare function awsSagemakerDomainSharingSettingsPropertyToHclTerraform(struct?: AwsSagemakerDomain.SharingSettingsPropertyOutputReference | AwsSagemakerDomain.SharingSettingsProperty): any;
export declare function awsSagemakerDomainDefaultUserSettingsSpaceStorageSettingsDefaultEbsStorageSettingsPropertyToTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsSpaceStorageSettingsDefaultEbsStorageSettingsPropertyOutputReference | AwsSagemakerDomain.DefaultUserSettingsSpaceStorageSettingsDefaultEbsStorageSettingsProperty): any;
export declare function awsSagemakerDomainDefaultUserSettingsSpaceStorageSettingsDefaultEbsStorageSettingsPropertyToHclTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsSpaceStorageSettingsDefaultEbsStorageSettingsPropertyOutputReference | AwsSagemakerDomain.DefaultUserSettingsSpaceStorageSettingsDefaultEbsStorageSettingsProperty): any;
export declare function awsSagemakerDomainDefaultUserSettingsSpaceStorageSettingsPropertyToTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsSpaceStorageSettingsPropertyOutputReference | AwsSagemakerDomain.DefaultUserSettingsSpaceStorageSettingsProperty): any;
export declare function awsSagemakerDomainDefaultUserSettingsSpaceStorageSettingsPropertyToHclTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsSpaceStorageSettingsPropertyOutputReference | AwsSagemakerDomain.DefaultUserSettingsSpaceStorageSettingsProperty): any;
export declare function awsSagemakerDomainStudioWebPortalSettingsPropertyToTerraform(struct?: AwsSagemakerDomain.StudioWebPortalSettingsPropertyOutputReference | AwsSagemakerDomain.StudioWebPortalSettingsProperty): any;
export declare function awsSagemakerDomainStudioWebPortalSettingsPropertyToHclTerraform(struct?: AwsSagemakerDomain.StudioWebPortalSettingsPropertyOutputReference | AwsSagemakerDomain.StudioWebPortalSettingsProperty): any;
export declare function awsSagemakerDomainDefaultUserSettingsTensorBoardAppSettingsDefaultResourceSpecPropertyToTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsTensorBoardAppSettingsDefaultResourceSpecPropertyOutputReference | AwsSagemakerDomain.DefaultUserSettingsTensorBoardAppSettingsDefaultResourceSpecProperty): any;
export declare function awsSagemakerDomainDefaultUserSettingsTensorBoardAppSettingsDefaultResourceSpecPropertyToHclTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsTensorBoardAppSettingsDefaultResourceSpecPropertyOutputReference | AwsSagemakerDomain.DefaultUserSettingsTensorBoardAppSettingsDefaultResourceSpecProperty): any;
export declare function awsSagemakerDomainTensorBoardAppSettingsPropertyToTerraform(struct?: AwsSagemakerDomain.TensorBoardAppSettingsPropertyOutputReference | AwsSagemakerDomain.TensorBoardAppSettingsProperty): any;
export declare function awsSagemakerDomainTensorBoardAppSettingsPropertyToHclTerraform(struct?: AwsSagemakerDomain.TensorBoardAppSettingsPropertyOutputReference | AwsSagemakerDomain.TensorBoardAppSettingsProperty): any;
export declare function awsSagemakerDomainDefaultUserSettingsPropertyToTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsPropertyOutputReference | AwsSagemakerDomain.DefaultUserSettingsProperty): any;
export declare function awsSagemakerDomainDefaultUserSettingsPropertyToHclTerraform(struct?: AwsSagemakerDomain.DefaultUserSettingsPropertyOutputReference | AwsSagemakerDomain.DefaultUserSettingsProperty): any;
export declare function awsSagemakerDomainDockerSettingsPropertyToTerraform(struct?: AwsSagemakerDomain.DockerSettingsPropertyOutputReference | AwsSagemakerDomain.DockerSettingsProperty): any;
export declare function awsSagemakerDomainDockerSettingsPropertyToHclTerraform(struct?: AwsSagemakerDomain.DockerSettingsPropertyOutputReference | AwsSagemakerDomain.DockerSettingsProperty): any;
export declare function awsSagemakerDomainDomainSettingsRStudioServerProDomainSettingsDefaultResourceSpecPropertyToTerraform(struct?: AwsSagemakerDomain.DomainSettingsRStudioServerProDomainSettingsDefaultResourceSpecPropertyOutputReference | AwsSagemakerDomain.DomainSettingsRStudioServerProDomainSettingsDefaultResourceSpecProperty): any;
export declare function awsSagemakerDomainDomainSettingsRStudioServerProDomainSettingsDefaultResourceSpecPropertyToHclTerraform(struct?: AwsSagemakerDomain.DomainSettingsRStudioServerProDomainSettingsDefaultResourceSpecPropertyOutputReference | AwsSagemakerDomain.DomainSettingsRStudioServerProDomainSettingsDefaultResourceSpecProperty): any;
export declare function awsSagemakerDomainRStudioServerProDomainSettingsPropertyToTerraform(struct?: AwsSagemakerDomain.RStudioServerProDomainSettingsPropertyOutputReference | AwsSagemakerDomain.RStudioServerProDomainSettingsProperty): any;
export declare function awsSagemakerDomainRStudioServerProDomainSettingsPropertyToHclTerraform(struct?: AwsSagemakerDomain.RStudioServerProDomainSettingsPropertyOutputReference | AwsSagemakerDomain.RStudioServerProDomainSettingsProperty): any;
export declare function awsSagemakerDomainTrustedIdentityPropagationSettingsPropertyToTerraform(struct?: AwsSagemakerDomain.TrustedIdentityPropagationSettingsPropertyOutputReference | AwsSagemakerDomain.TrustedIdentityPropagationSettingsProperty): any;
export declare function awsSagemakerDomainTrustedIdentityPropagationSettingsPropertyToHclTerraform(struct?: AwsSagemakerDomain.TrustedIdentityPropagationSettingsPropertyOutputReference | AwsSagemakerDomain.TrustedIdentityPropagationSettingsProperty): any;
export declare function awsSagemakerDomainDomainSettingsPropertyToTerraform(struct?: AwsSagemakerDomain.DomainSettingsPropertyOutputReference | AwsSagemakerDomain.DomainSettingsProperty): any;
export declare function awsSagemakerDomainDomainSettingsPropertyToHclTerraform(struct?: AwsSagemakerDomain.DomainSettingsPropertyOutputReference | AwsSagemakerDomain.DomainSettingsProperty): any;
export declare function awsSagemakerDomainRetentionPolicyPropertyToTerraform(struct?: AwsSagemakerDomain.RetentionPolicyPropertyOutputReference | AwsSagemakerDomain.RetentionPolicyProperty): any;
export declare function awsSagemakerDomainRetentionPolicyPropertyToHclTerraform(struct?: AwsSagemakerDomain.RetentionPolicyPropertyOutputReference | AwsSagemakerDomain.RetentionPolicyProperty): any;
export declare namespace AwsSagemakerDomain {
    interface DefaultSpaceSettingsCustomFileSystemConfigEfsFileSystemConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#file_system_id AwsSagemakerDomain#file_system_id}
        */
        readonly fileSystemId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#file_system_path AwsSagemakerDomain#file_system_path}
        */
        readonly fileSystemPath: string;
    }
    class DefaultSpaceSettingsCustomFileSystemConfigEfsFileSystemConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultSpaceSettingsCustomFileSystemConfigEfsFileSystemConfigProperty | undefined;
        set internalValue(value: DefaultSpaceSettingsCustomFileSystemConfigEfsFileSystemConfigProperty | undefined);
        private _fileSystemId?;
        get fileSystemId(): string;
        set fileSystemId(value: string);
        get fileSystemIdInput(): string | undefined;
        private _fileSystemPath?;
        get fileSystemPath(): string;
        set fileSystemPath(value: string);
        get fileSystemPathInput(): string | undefined;
    }
    interface DefaultSpaceSettingsCustomFileSystemConfigProperty {
        /**
        * efs_file_system_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#efs_file_system_config AwsSagemakerDomain#efs_file_system_config}
        */
        readonly efsFileSystemConfig?: DefaultSpaceSettingsCustomFileSystemConfigEfsFileSystemConfigProperty;
    }
    class DefaultSpaceSettingsCustomFileSystemConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefaultSpaceSettingsCustomFileSystemConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefaultSpaceSettingsCustomFileSystemConfigProperty | cdktn.IResolvable | undefined);
        private _efsFileSystemConfig;
        get efsFileSystemConfig(): DefaultSpaceSettingsCustomFileSystemConfigEfsFileSystemConfigPropertyOutputReference;
        putEfsFileSystemConfig(value: DefaultSpaceSettingsCustomFileSystemConfigEfsFileSystemConfigProperty): void;
        resetEfsFileSystemConfig(): void;
        get efsFileSystemConfigInput(): DefaultSpaceSettingsCustomFileSystemConfigEfsFileSystemConfigProperty | undefined;
    }
    class DefaultSpaceSettingsCustomFileSystemConfigPropertyList extends cdktn.ComplexList {
        internalValue?: DefaultSpaceSettingsCustomFileSystemConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefaultSpaceSettingsCustomFileSystemConfigPropertyOutputReference;
    }
    interface DefaultSpaceSettingsCustomPosixUserConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#gid AwsSagemakerDomain#gid}
        */
        readonly gid: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#uid AwsSagemakerDomain#uid}
        */
        readonly uid: number;
    }
    class DefaultSpaceSettingsCustomPosixUserConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultSpaceSettingsCustomPosixUserConfigProperty | undefined;
        set internalValue(value: DefaultSpaceSettingsCustomPosixUserConfigProperty | undefined);
        private _gid?;
        get gid(): number;
        set gid(value: number);
        get gidInput(): number | undefined;
        private _uid?;
        get uid(): number;
        set uid(value: number);
        get uidInput(): number | undefined;
    }
    interface DefaultSpaceSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#idle_timeout_in_minutes AwsSagemakerDomain#idle_timeout_in_minutes}
        */
        readonly idleTimeoutInMinutes?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#lifecycle_management AwsSagemakerDomain#lifecycle_management}
        */
        readonly lifecycleManagement?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#max_idle_timeout_in_minutes AwsSagemakerDomain#max_idle_timeout_in_minutes}
        */
        readonly maxIdleTimeoutInMinutes?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#min_idle_timeout_in_minutes AwsSagemakerDomain#min_idle_timeout_in_minutes}
        */
        readonly minIdleTimeoutInMinutes?: number;
    }
    class DefaultSpaceSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultSpaceSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsProperty | undefined;
        set internalValue(value: DefaultSpaceSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsProperty | undefined);
        private _idleTimeoutInMinutes?;
        get idleTimeoutInMinutes(): number;
        set idleTimeoutInMinutes(value: number);
        resetIdleTimeoutInMinutes(): void;
        get idleTimeoutInMinutesInput(): number | undefined;
        private _lifecycleManagement?;
        get lifecycleManagement(): string;
        set lifecycleManagement(value: string);
        resetLifecycleManagement(): void;
        get lifecycleManagementInput(): string | undefined;
        private _maxIdleTimeoutInMinutes?;
        get maxIdleTimeoutInMinutes(): number;
        set maxIdleTimeoutInMinutes(value: number);
        resetMaxIdleTimeoutInMinutes(): void;
        get maxIdleTimeoutInMinutesInput(): number | undefined;
        private _minIdleTimeoutInMinutes?;
        get minIdleTimeoutInMinutes(): number;
        set minIdleTimeoutInMinutes(value: number);
        resetMinIdleTimeoutInMinutes(): void;
        get minIdleTimeoutInMinutesInput(): number | undefined;
    }
    interface DefaultSpaceSettingsJupyterLabAppSettingsAppLifecycleManagementProperty {
        /**
        * idle_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#idle_settings AwsSagemakerDomain#idle_settings}
        */
        readonly idleSettings?: DefaultSpaceSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsProperty;
    }
    class DefaultSpaceSettingsJupyterLabAppSettingsAppLifecycleManagementPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultSpaceSettingsJupyterLabAppSettingsAppLifecycleManagementProperty | undefined;
        set internalValue(value: DefaultSpaceSettingsJupyterLabAppSettingsAppLifecycleManagementProperty | undefined);
        private _idleSettings;
        get idleSettings(): DefaultSpaceSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsPropertyOutputReference;
        putIdleSettings(value: DefaultSpaceSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsProperty): void;
        resetIdleSettings(): void;
        get idleSettingsInput(): DefaultSpaceSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsProperty | undefined;
    }
    interface DefaultSpaceSettingsJupyterLabAppSettingsCodeRepositoryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#repository_url AwsSagemakerDomain#repository_url}
        */
        readonly repositoryUrl: string;
    }
    class DefaultSpaceSettingsJupyterLabAppSettingsCodeRepositoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefaultSpaceSettingsJupyterLabAppSettingsCodeRepositoryProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefaultSpaceSettingsJupyterLabAppSettingsCodeRepositoryProperty | cdktn.IResolvable | undefined);
        private _repositoryUrl?;
        get repositoryUrl(): string;
        set repositoryUrl(value: string);
        get repositoryUrlInput(): string | undefined;
    }
    class DefaultSpaceSettingsJupyterLabAppSettingsCodeRepositoryPropertyList extends cdktn.ComplexList {
        internalValue?: DefaultSpaceSettingsJupyterLabAppSettingsCodeRepositoryProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefaultSpaceSettingsJupyterLabAppSettingsCodeRepositoryPropertyOutputReference;
    }
    interface DefaultSpaceSettingsJupyterLabAppSettingsCustomImageProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#app_image_config_name AwsSagemakerDomain#app_image_config_name}
        */
        readonly appImageConfigName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#image_name AwsSagemakerDomain#image_name}
        */
        readonly imageName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#image_version_number AwsSagemakerDomain#image_version_number}
        */
        readonly imageVersionNumber?: number;
    }
    class DefaultSpaceSettingsJupyterLabAppSettingsCustomImagePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefaultSpaceSettingsJupyterLabAppSettingsCustomImageProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefaultSpaceSettingsJupyterLabAppSettingsCustomImageProperty | cdktn.IResolvable | undefined);
        private _appImageConfigName?;
        get appImageConfigName(): string;
        set appImageConfigName(value: string);
        get appImageConfigNameInput(): string | undefined;
        private _imageName?;
        get imageName(): string;
        set imageName(value: string);
        get imageNameInput(): string | undefined;
        private _imageVersionNumber?;
        get imageVersionNumber(): number;
        set imageVersionNumber(value: number);
        resetImageVersionNumber(): void;
        get imageVersionNumberInput(): number | undefined;
    }
    class DefaultSpaceSettingsJupyterLabAppSettingsCustomImagePropertyList extends cdktn.ComplexList {
        internalValue?: DefaultSpaceSettingsJupyterLabAppSettingsCustomImageProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefaultSpaceSettingsJupyterLabAppSettingsCustomImagePropertyOutputReference;
    }
    interface DefaultSpaceSettingsJupyterLabAppSettingsDefaultResourceSpecProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#instance_type AwsSagemakerDomain#instance_type}
        */
        readonly instanceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#lifecycle_config_arn AwsSagemakerDomain#lifecycle_config_arn}
        */
        readonly lifecycleConfigArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#sagemaker_image_arn AwsSagemakerDomain#sagemaker_image_arn}
        */
        readonly sagemakerImageArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#sagemaker_image_version_alias AwsSagemakerDomain#sagemaker_image_version_alias}
        */
        readonly sagemakerImageVersionAlias?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#sagemaker_image_version_arn AwsSagemakerDomain#sagemaker_image_version_arn}
        */
        readonly sagemakerImageVersionArn?: string;
    }
    class DefaultSpaceSettingsJupyterLabAppSettingsDefaultResourceSpecPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultSpaceSettingsJupyterLabAppSettingsDefaultResourceSpecProperty | undefined;
        set internalValue(value: DefaultSpaceSettingsJupyterLabAppSettingsDefaultResourceSpecProperty | undefined);
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        resetInstanceType(): void;
        get instanceTypeInput(): string | undefined;
        private _lifecycleConfigArn?;
        get lifecycleConfigArn(): string;
        set lifecycleConfigArn(value: string);
        resetLifecycleConfigArn(): void;
        get lifecycleConfigArnInput(): string | undefined;
        private _sagemakerImageArn?;
        get sagemakerImageArn(): string;
        set sagemakerImageArn(value: string);
        resetSagemakerImageArn(): void;
        get sagemakerImageArnInput(): string | undefined;
        private _sagemakerImageVersionAlias?;
        get sagemakerImageVersionAlias(): string;
        set sagemakerImageVersionAlias(value: string);
        resetSagemakerImageVersionAlias(): void;
        get sagemakerImageVersionAliasInput(): string | undefined;
        private _sagemakerImageVersionArn?;
        get sagemakerImageVersionArn(): string;
        set sagemakerImageVersionArn(value: string);
        resetSagemakerImageVersionArn(): void;
        get sagemakerImageVersionArnInput(): string | undefined;
    }
    interface DefaultSpaceSettingsJupyterLabAppSettingsEmrSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#assumable_role_arns AwsSagemakerDomain#assumable_role_arns}
        */
        readonly assumableRoleArns?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#execution_role_arns AwsSagemakerDomain#execution_role_arns}
        */
        readonly executionRoleArns?: string[];
    }
    class DefaultSpaceSettingsJupyterLabAppSettingsEmrSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultSpaceSettingsJupyterLabAppSettingsEmrSettingsProperty | undefined;
        set internalValue(value: DefaultSpaceSettingsJupyterLabAppSettingsEmrSettingsProperty | undefined);
        private _assumableRoleArns?;
        get assumableRoleArns(): string[];
        set assumableRoleArns(value: string[]);
        resetAssumableRoleArns(): void;
        get assumableRoleArnsInput(): string[] | undefined;
        private _executionRoleArns?;
        get executionRoleArns(): string[];
        set executionRoleArns(value: string[]);
        resetExecutionRoleArns(): void;
        get executionRoleArnsInput(): string[] | undefined;
    }
    interface DefaultSpaceSettingsJupyterLabAppSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#built_in_lifecycle_config_arn AwsSagemakerDomain#built_in_lifecycle_config_arn}
        */
        readonly builtInLifecycleConfigArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#lifecycle_config_arns AwsSagemakerDomain#lifecycle_config_arns}
        */
        readonly lifecycleConfigArns?: string[];
        /**
        * app_lifecycle_management block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#app_lifecycle_management AwsSagemakerDomain#app_lifecycle_management}
        */
        readonly appLifecycleManagement?: DefaultSpaceSettingsJupyterLabAppSettingsAppLifecycleManagementProperty;
        /**
        * code_repository block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#code_repository AwsSagemakerDomain#code_repository}
        */
        readonly codeRepository?: DefaultSpaceSettingsJupyterLabAppSettingsCodeRepositoryProperty[] | cdktn.IResolvable;
        /**
        * custom_image block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#custom_image AwsSagemakerDomain#custom_image}
        */
        readonly customImage?: DefaultSpaceSettingsJupyterLabAppSettingsCustomImageProperty[] | cdktn.IResolvable;
        /**
        * default_resource_spec block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#default_resource_spec AwsSagemakerDomain#default_resource_spec}
        */
        readonly defaultResourceSpec?: DefaultSpaceSettingsJupyterLabAppSettingsDefaultResourceSpecProperty;
        /**
        * emr_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#emr_settings AwsSagemakerDomain#emr_settings}
        */
        readonly emrSettings?: DefaultSpaceSettingsJupyterLabAppSettingsEmrSettingsProperty;
    }
    class DefaultSpaceSettingsJupyterLabAppSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultSpaceSettingsJupyterLabAppSettingsProperty | undefined;
        set internalValue(value: DefaultSpaceSettingsJupyterLabAppSettingsProperty | undefined);
        private _builtInLifecycleConfigArn?;
        get builtInLifecycleConfigArn(): string;
        set builtInLifecycleConfigArn(value: string);
        resetBuiltInLifecycleConfigArn(): void;
        get builtInLifecycleConfigArnInput(): string | undefined;
        private _lifecycleConfigArns?;
        get lifecycleConfigArns(): string[];
        set lifecycleConfigArns(value: string[]);
        resetLifecycleConfigArns(): void;
        get lifecycleConfigArnsInput(): string[] | undefined;
        private _appLifecycleManagement;
        get appLifecycleManagement(): DefaultSpaceSettingsJupyterLabAppSettingsAppLifecycleManagementPropertyOutputReference;
        putAppLifecycleManagement(value: DefaultSpaceSettingsJupyterLabAppSettingsAppLifecycleManagementProperty): void;
        resetAppLifecycleManagement(): void;
        get appLifecycleManagementInput(): DefaultSpaceSettingsJupyterLabAppSettingsAppLifecycleManagementProperty | undefined;
        private _codeRepository;
        get codeRepository(): DefaultSpaceSettingsJupyterLabAppSettingsCodeRepositoryPropertyList;
        putCodeRepository(value: DefaultSpaceSettingsJupyterLabAppSettingsCodeRepositoryProperty[] | cdktn.IResolvable): void;
        resetCodeRepository(): void;
        get codeRepositoryInput(): cdktn.IResolvable | DefaultSpaceSettingsJupyterLabAppSettingsCodeRepositoryProperty[] | undefined;
        private _customImage;
        get customImage(): DefaultSpaceSettingsJupyterLabAppSettingsCustomImagePropertyList;
        putCustomImage(value: DefaultSpaceSettingsJupyterLabAppSettingsCustomImageProperty[] | cdktn.IResolvable): void;
        resetCustomImage(): void;
        get customImageInput(): cdktn.IResolvable | DefaultSpaceSettingsJupyterLabAppSettingsCustomImageProperty[] | undefined;
        private _defaultResourceSpec;
        get defaultResourceSpec(): DefaultSpaceSettingsJupyterLabAppSettingsDefaultResourceSpecPropertyOutputReference;
        putDefaultResourceSpec(value: DefaultSpaceSettingsJupyterLabAppSettingsDefaultResourceSpecProperty): void;
        resetDefaultResourceSpec(): void;
        get defaultResourceSpecInput(): DefaultSpaceSettingsJupyterLabAppSettingsDefaultResourceSpecProperty | undefined;
        private _emrSettings;
        get emrSettings(): DefaultSpaceSettingsJupyterLabAppSettingsEmrSettingsPropertyOutputReference;
        putEmrSettings(value: DefaultSpaceSettingsJupyterLabAppSettingsEmrSettingsProperty): void;
        resetEmrSettings(): void;
        get emrSettingsInput(): DefaultSpaceSettingsJupyterLabAppSettingsEmrSettingsProperty | undefined;
    }
    interface DefaultSpaceSettingsJupyterServerAppSettingsCodeRepositoryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#repository_url AwsSagemakerDomain#repository_url}
        */
        readonly repositoryUrl: string;
    }
    class DefaultSpaceSettingsJupyterServerAppSettingsCodeRepositoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefaultSpaceSettingsJupyterServerAppSettingsCodeRepositoryProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefaultSpaceSettingsJupyterServerAppSettingsCodeRepositoryProperty | cdktn.IResolvable | undefined);
        private _repositoryUrl?;
        get repositoryUrl(): string;
        set repositoryUrl(value: string);
        get repositoryUrlInput(): string | undefined;
    }
    class DefaultSpaceSettingsJupyterServerAppSettingsCodeRepositoryPropertyList extends cdktn.ComplexList {
        internalValue?: DefaultSpaceSettingsJupyterServerAppSettingsCodeRepositoryProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefaultSpaceSettingsJupyterServerAppSettingsCodeRepositoryPropertyOutputReference;
    }
    interface DefaultSpaceSettingsJupyterServerAppSettingsDefaultResourceSpecProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#instance_type AwsSagemakerDomain#instance_type}
        */
        readonly instanceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#lifecycle_config_arn AwsSagemakerDomain#lifecycle_config_arn}
        */
        readonly lifecycleConfigArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#sagemaker_image_arn AwsSagemakerDomain#sagemaker_image_arn}
        */
        readonly sagemakerImageArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#sagemaker_image_version_alias AwsSagemakerDomain#sagemaker_image_version_alias}
        */
        readonly sagemakerImageVersionAlias?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#sagemaker_image_version_arn AwsSagemakerDomain#sagemaker_image_version_arn}
        */
        readonly sagemakerImageVersionArn?: string;
    }
    class DefaultSpaceSettingsJupyterServerAppSettingsDefaultResourceSpecPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultSpaceSettingsJupyterServerAppSettingsDefaultResourceSpecProperty | undefined;
        set internalValue(value: DefaultSpaceSettingsJupyterServerAppSettingsDefaultResourceSpecProperty | undefined);
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        resetInstanceType(): void;
        get instanceTypeInput(): string | undefined;
        private _lifecycleConfigArn?;
        get lifecycleConfigArn(): string;
        set lifecycleConfigArn(value: string);
        resetLifecycleConfigArn(): void;
        get lifecycleConfigArnInput(): string | undefined;
        private _sagemakerImageArn?;
        get sagemakerImageArn(): string;
        set sagemakerImageArn(value: string);
        resetSagemakerImageArn(): void;
        get sagemakerImageArnInput(): string | undefined;
        private _sagemakerImageVersionAlias?;
        get sagemakerImageVersionAlias(): string;
        set sagemakerImageVersionAlias(value: string);
        resetSagemakerImageVersionAlias(): void;
        get sagemakerImageVersionAliasInput(): string | undefined;
        private _sagemakerImageVersionArn?;
        get sagemakerImageVersionArn(): string;
        set sagemakerImageVersionArn(value: string);
        resetSagemakerImageVersionArn(): void;
        get sagemakerImageVersionArnInput(): string | undefined;
    }
    interface DefaultSpaceSettingsJupyterServerAppSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#lifecycle_config_arns AwsSagemakerDomain#lifecycle_config_arns}
        */
        readonly lifecycleConfigArns?: string[];
        /**
        * code_repository block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#code_repository AwsSagemakerDomain#code_repository}
        */
        readonly codeRepository?: DefaultSpaceSettingsJupyterServerAppSettingsCodeRepositoryProperty[] | cdktn.IResolvable;
        /**
        * default_resource_spec block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#default_resource_spec AwsSagemakerDomain#default_resource_spec}
        */
        readonly defaultResourceSpec?: DefaultSpaceSettingsJupyterServerAppSettingsDefaultResourceSpecProperty;
    }
    class DefaultSpaceSettingsJupyterServerAppSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultSpaceSettingsJupyterServerAppSettingsProperty | undefined;
        set internalValue(value: DefaultSpaceSettingsJupyterServerAppSettingsProperty | undefined);
        private _lifecycleConfigArns?;
        get lifecycleConfigArns(): string[];
        set lifecycleConfigArns(value: string[]);
        resetLifecycleConfigArns(): void;
        get lifecycleConfigArnsInput(): string[] | undefined;
        private _codeRepository;
        get codeRepository(): DefaultSpaceSettingsJupyterServerAppSettingsCodeRepositoryPropertyList;
        putCodeRepository(value: DefaultSpaceSettingsJupyterServerAppSettingsCodeRepositoryProperty[] | cdktn.IResolvable): void;
        resetCodeRepository(): void;
        get codeRepositoryInput(): cdktn.IResolvable | DefaultSpaceSettingsJupyterServerAppSettingsCodeRepositoryProperty[] | undefined;
        private _defaultResourceSpec;
        get defaultResourceSpec(): DefaultSpaceSettingsJupyterServerAppSettingsDefaultResourceSpecPropertyOutputReference;
        putDefaultResourceSpec(value: DefaultSpaceSettingsJupyterServerAppSettingsDefaultResourceSpecProperty): void;
        resetDefaultResourceSpec(): void;
        get defaultResourceSpecInput(): DefaultSpaceSettingsJupyterServerAppSettingsDefaultResourceSpecProperty | undefined;
    }
    interface DefaultSpaceSettingsKernelGatewayAppSettingsCustomImageProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#app_image_config_name AwsSagemakerDomain#app_image_config_name}
        */
        readonly appImageConfigName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#image_name AwsSagemakerDomain#image_name}
        */
        readonly imageName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#image_version_number AwsSagemakerDomain#image_version_number}
        */
        readonly imageVersionNumber?: number;
    }
    class DefaultSpaceSettingsKernelGatewayAppSettingsCustomImagePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefaultSpaceSettingsKernelGatewayAppSettingsCustomImageProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefaultSpaceSettingsKernelGatewayAppSettingsCustomImageProperty | cdktn.IResolvable | undefined);
        private _appImageConfigName?;
        get appImageConfigName(): string;
        set appImageConfigName(value: string);
        get appImageConfigNameInput(): string | undefined;
        private _imageName?;
        get imageName(): string;
        set imageName(value: string);
        get imageNameInput(): string | undefined;
        private _imageVersionNumber?;
        get imageVersionNumber(): number;
        set imageVersionNumber(value: number);
        resetImageVersionNumber(): void;
        get imageVersionNumberInput(): number | undefined;
    }
    class DefaultSpaceSettingsKernelGatewayAppSettingsCustomImagePropertyList extends cdktn.ComplexList {
        internalValue?: DefaultSpaceSettingsKernelGatewayAppSettingsCustomImageProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefaultSpaceSettingsKernelGatewayAppSettingsCustomImagePropertyOutputReference;
    }
    interface DefaultSpaceSettingsKernelGatewayAppSettingsDefaultResourceSpecProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#instance_type AwsSagemakerDomain#instance_type}
        */
        readonly instanceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#lifecycle_config_arn AwsSagemakerDomain#lifecycle_config_arn}
        */
        readonly lifecycleConfigArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#sagemaker_image_arn AwsSagemakerDomain#sagemaker_image_arn}
        */
        readonly sagemakerImageArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#sagemaker_image_version_alias AwsSagemakerDomain#sagemaker_image_version_alias}
        */
        readonly sagemakerImageVersionAlias?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#sagemaker_image_version_arn AwsSagemakerDomain#sagemaker_image_version_arn}
        */
        readonly sagemakerImageVersionArn?: string;
    }
    class DefaultSpaceSettingsKernelGatewayAppSettingsDefaultResourceSpecPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultSpaceSettingsKernelGatewayAppSettingsDefaultResourceSpecProperty | undefined;
        set internalValue(value: DefaultSpaceSettingsKernelGatewayAppSettingsDefaultResourceSpecProperty | undefined);
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        resetInstanceType(): void;
        get instanceTypeInput(): string | undefined;
        private _lifecycleConfigArn?;
        get lifecycleConfigArn(): string;
        set lifecycleConfigArn(value: string);
        resetLifecycleConfigArn(): void;
        get lifecycleConfigArnInput(): string | undefined;
        private _sagemakerImageArn?;
        get sagemakerImageArn(): string;
        set sagemakerImageArn(value: string);
        resetSagemakerImageArn(): void;
        get sagemakerImageArnInput(): string | undefined;
        private _sagemakerImageVersionAlias?;
        get sagemakerImageVersionAlias(): string;
        set sagemakerImageVersionAlias(value: string);
        resetSagemakerImageVersionAlias(): void;
        get sagemakerImageVersionAliasInput(): string | undefined;
        private _sagemakerImageVersionArn?;
        get sagemakerImageVersionArn(): string;
        set sagemakerImageVersionArn(value: string);
        resetSagemakerImageVersionArn(): void;
        get sagemakerImageVersionArnInput(): string | undefined;
    }
    interface DefaultSpaceSettingsKernelGatewayAppSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#lifecycle_config_arns AwsSagemakerDomain#lifecycle_config_arns}
        */
        readonly lifecycleConfigArns?: string[];
        /**
        * custom_image block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#custom_image AwsSagemakerDomain#custom_image}
        */
        readonly customImage?: DefaultSpaceSettingsKernelGatewayAppSettingsCustomImageProperty[] | cdktn.IResolvable;
        /**
        * default_resource_spec block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#default_resource_spec AwsSagemakerDomain#default_resource_spec}
        */
        readonly defaultResourceSpec?: DefaultSpaceSettingsKernelGatewayAppSettingsDefaultResourceSpecProperty;
    }
    class DefaultSpaceSettingsKernelGatewayAppSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultSpaceSettingsKernelGatewayAppSettingsProperty | undefined;
        set internalValue(value: DefaultSpaceSettingsKernelGatewayAppSettingsProperty | undefined);
        private _lifecycleConfigArns?;
        get lifecycleConfigArns(): string[];
        set lifecycleConfigArns(value: string[]);
        resetLifecycleConfigArns(): void;
        get lifecycleConfigArnsInput(): string[] | undefined;
        private _customImage;
        get customImage(): DefaultSpaceSettingsKernelGatewayAppSettingsCustomImagePropertyList;
        putCustomImage(value: DefaultSpaceSettingsKernelGatewayAppSettingsCustomImageProperty[] | cdktn.IResolvable): void;
        resetCustomImage(): void;
        get customImageInput(): cdktn.IResolvable | DefaultSpaceSettingsKernelGatewayAppSettingsCustomImageProperty[] | undefined;
        private _defaultResourceSpec;
        get defaultResourceSpec(): DefaultSpaceSettingsKernelGatewayAppSettingsDefaultResourceSpecPropertyOutputReference;
        putDefaultResourceSpec(value: DefaultSpaceSettingsKernelGatewayAppSettingsDefaultResourceSpecProperty): void;
        resetDefaultResourceSpec(): void;
        get defaultResourceSpecInput(): DefaultSpaceSettingsKernelGatewayAppSettingsDefaultResourceSpecProperty | undefined;
    }
    interface DefaultSpaceSettingsSpaceStorageSettingsDefaultEbsStorageSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#default_ebs_volume_size_in_gb AwsSagemakerDomain#default_ebs_volume_size_in_gb}
        */
        readonly defaultEbsVolumeSizeInGb: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#maximum_ebs_volume_size_in_gb AwsSagemakerDomain#maximum_ebs_volume_size_in_gb}
        */
        readonly maximumEbsVolumeSizeInGb: number;
    }
    class DefaultSpaceSettingsSpaceStorageSettingsDefaultEbsStorageSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultSpaceSettingsSpaceStorageSettingsDefaultEbsStorageSettingsProperty | undefined;
        set internalValue(value: DefaultSpaceSettingsSpaceStorageSettingsDefaultEbsStorageSettingsProperty | undefined);
        private _defaultEbsVolumeSizeInGb?;
        get defaultEbsVolumeSizeInGb(): number;
        set defaultEbsVolumeSizeInGb(value: number);
        get defaultEbsVolumeSizeInGbInput(): number | undefined;
        private _maximumEbsVolumeSizeInGb?;
        get maximumEbsVolumeSizeInGb(): number;
        set maximumEbsVolumeSizeInGb(value: number);
        get maximumEbsVolumeSizeInGbInput(): number | undefined;
    }
    interface DefaultSpaceSettingsSpaceStorageSettingsProperty {
        /**
        * default_ebs_storage_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#default_ebs_storage_settings AwsSagemakerDomain#default_ebs_storage_settings}
        */
        readonly defaultEbsStorageSettings?: DefaultSpaceSettingsSpaceStorageSettingsDefaultEbsStorageSettingsProperty;
    }
    class DefaultSpaceSettingsSpaceStorageSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultSpaceSettingsSpaceStorageSettingsProperty | undefined;
        set internalValue(value: DefaultSpaceSettingsSpaceStorageSettingsProperty | undefined);
        private _defaultEbsStorageSettings;
        get defaultEbsStorageSettings(): DefaultSpaceSettingsSpaceStorageSettingsDefaultEbsStorageSettingsPropertyOutputReference;
        putDefaultEbsStorageSettings(value: DefaultSpaceSettingsSpaceStorageSettingsDefaultEbsStorageSettingsProperty): void;
        resetDefaultEbsStorageSettings(): void;
        get defaultEbsStorageSettingsInput(): DefaultSpaceSettingsSpaceStorageSettingsDefaultEbsStorageSettingsProperty | undefined;
    }
    interface DefaultSpaceSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#execution_role AwsSagemakerDomain#execution_role}
        */
        readonly executionRole: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#security_groups AwsSagemakerDomain#security_groups}
        */
        readonly securityGroups?: string[];
        /**
        * custom_file_system_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#custom_file_system_config AwsSagemakerDomain#custom_file_system_config}
        */
        readonly customFileSystemConfig?: DefaultSpaceSettingsCustomFileSystemConfigProperty[] | cdktn.IResolvable;
        /**
        * custom_posix_user_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#custom_posix_user_config AwsSagemakerDomain#custom_posix_user_config}
        */
        readonly customPosixUserConfig?: DefaultSpaceSettingsCustomPosixUserConfigProperty;
        /**
        * jupyter_lab_app_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#jupyter_lab_app_settings AwsSagemakerDomain#jupyter_lab_app_settings}
        */
        readonly jupyterLabAppSettings?: DefaultSpaceSettingsJupyterLabAppSettingsProperty;
        /**
        * jupyter_server_app_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#jupyter_server_app_settings AwsSagemakerDomain#jupyter_server_app_settings}
        */
        readonly jupyterServerAppSettings?: DefaultSpaceSettingsJupyterServerAppSettingsProperty;
        /**
        * kernel_gateway_app_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#kernel_gateway_app_settings AwsSagemakerDomain#kernel_gateway_app_settings}
        */
        readonly kernelGatewayAppSettings?: DefaultSpaceSettingsKernelGatewayAppSettingsProperty;
        /**
        * space_storage_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#space_storage_settings AwsSagemakerDomain#space_storage_settings}
        */
        readonly spaceStorageSettings?: DefaultSpaceSettingsSpaceStorageSettingsProperty;
    }
    class DefaultSpaceSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultSpaceSettingsProperty | undefined;
        set internalValue(value: DefaultSpaceSettingsProperty | undefined);
        private _executionRole?;
        get executionRole(): string;
        set executionRole(value: string);
        get executionRoleInput(): string | undefined;
        private _securityGroups?;
        get securityGroups(): string[];
        set securityGroups(value: string[]);
        resetSecurityGroups(): void;
        get securityGroupsInput(): string[] | undefined;
        private _customFileSystemConfig;
        get customFileSystemConfig(): DefaultSpaceSettingsCustomFileSystemConfigPropertyList;
        putCustomFileSystemConfig(value: DefaultSpaceSettingsCustomFileSystemConfigProperty[] | cdktn.IResolvable): void;
        resetCustomFileSystemConfig(): void;
        get customFileSystemConfigInput(): cdktn.IResolvable | DefaultSpaceSettingsCustomFileSystemConfigProperty[] | undefined;
        private _customPosixUserConfig;
        get customPosixUserConfig(): DefaultSpaceSettingsCustomPosixUserConfigPropertyOutputReference;
        putCustomPosixUserConfig(value: DefaultSpaceSettingsCustomPosixUserConfigProperty): void;
        resetCustomPosixUserConfig(): void;
        get customPosixUserConfigInput(): DefaultSpaceSettingsCustomPosixUserConfigProperty | undefined;
        private _jupyterLabAppSettings;
        get jupyterLabAppSettings(): DefaultSpaceSettingsJupyterLabAppSettingsPropertyOutputReference;
        putJupyterLabAppSettings(value: DefaultSpaceSettingsJupyterLabAppSettingsProperty): void;
        resetJupyterLabAppSettings(): void;
        get jupyterLabAppSettingsInput(): DefaultSpaceSettingsJupyterLabAppSettingsProperty | undefined;
        private _jupyterServerAppSettings;
        get jupyterServerAppSettings(): DefaultSpaceSettingsJupyterServerAppSettingsPropertyOutputReference;
        putJupyterServerAppSettings(value: DefaultSpaceSettingsJupyterServerAppSettingsProperty): void;
        resetJupyterServerAppSettings(): void;
        get jupyterServerAppSettingsInput(): DefaultSpaceSettingsJupyterServerAppSettingsProperty | undefined;
        private _kernelGatewayAppSettings;
        get kernelGatewayAppSettings(): DefaultSpaceSettingsKernelGatewayAppSettingsPropertyOutputReference;
        putKernelGatewayAppSettings(value: DefaultSpaceSettingsKernelGatewayAppSettingsProperty): void;
        resetKernelGatewayAppSettings(): void;
        get kernelGatewayAppSettingsInput(): DefaultSpaceSettingsKernelGatewayAppSettingsProperty | undefined;
        private _spaceStorageSettings;
        get spaceStorageSettings(): DefaultSpaceSettingsSpaceStorageSettingsPropertyOutputReference;
        putSpaceStorageSettings(value: DefaultSpaceSettingsSpaceStorageSettingsProperty): void;
        resetSpaceStorageSettings(): void;
        get spaceStorageSettingsInput(): DefaultSpaceSettingsSpaceStorageSettingsProperty | undefined;
    }
    interface DirectDeploySettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#status AwsSagemakerDomain#status}
        */
        readonly status?: string;
    }
    class DirectDeploySettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DirectDeploySettingsProperty | undefined;
        set internalValue(value: DirectDeploySettingsProperty | undefined);
        private _status?;
        get status(): string;
        set status(value: string);
        resetStatus(): void;
        get statusInput(): string | undefined;
    }
    interface EmrServerlessSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#execution_role_arn AwsSagemakerDomain#execution_role_arn}
        */
        readonly executionRoleArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#status AwsSagemakerDomain#status}
        */
        readonly status?: string;
    }
    class EmrServerlessSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EmrServerlessSettingsProperty | undefined;
        set internalValue(value: EmrServerlessSettingsProperty | undefined);
        private _executionRoleArn?;
        get executionRoleArn(): string;
        set executionRoleArn(value: string);
        resetExecutionRoleArn(): void;
        get executionRoleArnInput(): string | undefined;
        private _status?;
        get status(): string;
        set status(value: string);
        resetStatus(): void;
        get statusInput(): string | undefined;
    }
    interface GenerativeAiSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#amazon_bedrock_role_arn AwsSagemakerDomain#amazon_bedrock_role_arn}
        */
        readonly amazonBedrockRoleArn?: string;
    }
    class GenerativeAiSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): GenerativeAiSettingsProperty | undefined;
        set internalValue(value: GenerativeAiSettingsProperty | undefined);
        private _amazonBedrockRoleArn?;
        get amazonBedrockRoleArn(): string;
        set amazonBedrockRoleArn(value: string);
        resetAmazonBedrockRoleArn(): void;
        get amazonBedrockRoleArnInput(): string | undefined;
    }
    interface IdentityProviderOauthSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#data_source_name AwsSagemakerDomain#data_source_name}
        */
        readonly dataSourceName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#secret_arn AwsSagemakerDomain#secret_arn}
        */
        readonly secretArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#status AwsSagemakerDomain#status}
        */
        readonly status?: string;
    }
    class IdentityProviderOauthSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IdentityProviderOauthSettingsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IdentityProviderOauthSettingsProperty | cdktn.IResolvable | undefined);
        private _dataSourceName?;
        get dataSourceName(): string;
        set dataSourceName(value: string);
        resetDataSourceName(): void;
        get dataSourceNameInput(): string | undefined;
        private _secretArn?;
        get secretArn(): string;
        set secretArn(value: string);
        get secretArnInput(): string | undefined;
        private _status?;
        get status(): string;
        set status(value: string);
        resetStatus(): void;
        get statusInput(): string | undefined;
    }
    class IdentityProviderOauthSettingsPropertyList extends cdktn.ComplexList {
        internalValue?: IdentityProviderOauthSettingsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IdentityProviderOauthSettingsPropertyOutputReference;
    }
    interface KendraSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#status AwsSagemakerDomain#status}
        */
        readonly status?: string;
    }
    class KendraSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): KendraSettingsProperty | undefined;
        set internalValue(value: KendraSettingsProperty | undefined);
        private _status?;
        get status(): string;
        set status(value: string);
        resetStatus(): void;
        get statusInput(): string | undefined;
    }
    interface ModelRegisterSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#cross_account_model_register_role_arn AwsSagemakerDomain#cross_account_model_register_role_arn}
        */
        readonly crossAccountModelRegisterRoleArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#status AwsSagemakerDomain#status}
        */
        readonly status?: string;
    }
    class ModelRegisterSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ModelRegisterSettingsProperty | undefined;
        set internalValue(value: ModelRegisterSettingsProperty | undefined);
        private _crossAccountModelRegisterRoleArn?;
        get crossAccountModelRegisterRoleArn(): string;
        set crossAccountModelRegisterRoleArn(value: string);
        resetCrossAccountModelRegisterRoleArn(): void;
        get crossAccountModelRegisterRoleArnInput(): string | undefined;
        private _status?;
        get status(): string;
        set status(value: string);
        resetStatus(): void;
        get statusInput(): string | undefined;
    }
    interface TimeSeriesForecastingSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#amazon_forecast_role_arn AwsSagemakerDomain#amazon_forecast_role_arn}
        */
        readonly amazonForecastRoleArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#status AwsSagemakerDomain#status}
        */
        readonly status?: string;
    }
    class TimeSeriesForecastingSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeSeriesForecastingSettingsProperty | undefined;
        set internalValue(value: TimeSeriesForecastingSettingsProperty | undefined);
        private _amazonForecastRoleArn?;
        get amazonForecastRoleArn(): string;
        set amazonForecastRoleArn(value: string);
        resetAmazonForecastRoleArn(): void;
        get amazonForecastRoleArnInput(): string | undefined;
        private _status?;
        get status(): string;
        set status(value: string);
        resetStatus(): void;
        get statusInput(): string | undefined;
    }
    interface WorkspaceSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#s3_artifact_path AwsSagemakerDomain#s3_artifact_path}
        */
        readonly s3ArtifactPath?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#s3_kms_key_id AwsSagemakerDomain#s3_kms_key_id}
        */
        readonly s3KmsKeyId?: string;
    }
    class WorkspaceSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): WorkspaceSettingsProperty | undefined;
        set internalValue(value: WorkspaceSettingsProperty | undefined);
        private _s3ArtifactPath?;
        get s3ArtifactPath(): string;
        set s3ArtifactPath(value: string);
        resetS3ArtifactPath(): void;
        get s3ArtifactPathInput(): string | undefined;
        private _s3KmsKeyId?;
        get s3KmsKeyId(): string;
        set s3KmsKeyId(value: string);
        resetS3KmsKeyId(): void;
        get s3KmsKeyIdInput(): string | undefined;
    }
    interface CanvasAppSettingsProperty {
        /**
        * direct_deploy_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#direct_deploy_settings AwsSagemakerDomain#direct_deploy_settings}
        */
        readonly directDeploySettings?: DirectDeploySettingsProperty;
        /**
        * emr_serverless_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#emr_serverless_settings AwsSagemakerDomain#emr_serverless_settings}
        */
        readonly emrServerlessSettings?: EmrServerlessSettingsProperty;
        /**
        * generative_ai_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#generative_ai_settings AwsSagemakerDomain#generative_ai_settings}
        */
        readonly generativeAiSettings?: GenerativeAiSettingsProperty;
        /**
        * identity_provider_oauth_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#identity_provider_oauth_settings AwsSagemakerDomain#identity_provider_oauth_settings}
        */
        readonly identityProviderOauthSettings?: IdentityProviderOauthSettingsProperty[] | cdktn.IResolvable;
        /**
        * kendra_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#kendra_settings AwsSagemakerDomain#kendra_settings}
        */
        readonly kendraSettings?: KendraSettingsProperty;
        /**
        * model_register_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#model_register_settings AwsSagemakerDomain#model_register_settings}
        */
        readonly modelRegisterSettings?: ModelRegisterSettingsProperty;
        /**
        * time_series_forecasting_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#time_series_forecasting_settings AwsSagemakerDomain#time_series_forecasting_settings}
        */
        readonly timeSeriesForecastingSettings?: TimeSeriesForecastingSettingsProperty;
        /**
        * workspace_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#workspace_settings AwsSagemakerDomain#workspace_settings}
        */
        readonly workspaceSettings?: WorkspaceSettingsProperty;
    }
    class CanvasAppSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CanvasAppSettingsProperty | undefined;
        set internalValue(value: CanvasAppSettingsProperty | undefined);
        private _directDeploySettings;
        get directDeploySettings(): DirectDeploySettingsPropertyOutputReference;
        putDirectDeploySettings(value: DirectDeploySettingsProperty): void;
        resetDirectDeploySettings(): void;
        get directDeploySettingsInput(): DirectDeploySettingsProperty | undefined;
        private _emrServerlessSettings;
        get emrServerlessSettings(): EmrServerlessSettingsPropertyOutputReference;
        putEmrServerlessSettings(value: EmrServerlessSettingsProperty): void;
        resetEmrServerlessSettings(): void;
        get emrServerlessSettingsInput(): EmrServerlessSettingsProperty | undefined;
        private _generativeAiSettings;
        get generativeAiSettings(): GenerativeAiSettingsPropertyOutputReference;
        putGenerativeAiSettings(value: GenerativeAiSettingsProperty): void;
        resetGenerativeAiSettings(): void;
        get generativeAiSettingsInput(): GenerativeAiSettingsProperty | undefined;
        private _identityProviderOauthSettings;
        get identityProviderOauthSettings(): IdentityProviderOauthSettingsPropertyList;
        putIdentityProviderOauthSettings(value: IdentityProviderOauthSettingsProperty[] | cdktn.IResolvable): void;
        resetIdentityProviderOauthSettings(): void;
        get identityProviderOauthSettingsInput(): cdktn.IResolvable | IdentityProviderOauthSettingsProperty[] | undefined;
        private _kendraSettings;
        get kendraSettings(): KendraSettingsPropertyOutputReference;
        putKendraSettings(value: KendraSettingsProperty): void;
        resetKendraSettings(): void;
        get kendraSettingsInput(): KendraSettingsProperty | undefined;
        private _modelRegisterSettings;
        get modelRegisterSettings(): ModelRegisterSettingsPropertyOutputReference;
        putModelRegisterSettings(value: ModelRegisterSettingsProperty): void;
        resetModelRegisterSettings(): void;
        get modelRegisterSettingsInput(): ModelRegisterSettingsProperty | undefined;
        private _timeSeriesForecastingSettings;
        get timeSeriesForecastingSettings(): TimeSeriesForecastingSettingsPropertyOutputReference;
        putTimeSeriesForecastingSettings(value: TimeSeriesForecastingSettingsProperty): void;
        resetTimeSeriesForecastingSettings(): void;
        get timeSeriesForecastingSettingsInput(): TimeSeriesForecastingSettingsProperty | undefined;
        private _workspaceSettings;
        get workspaceSettings(): WorkspaceSettingsPropertyOutputReference;
        putWorkspaceSettings(value: WorkspaceSettingsProperty): void;
        resetWorkspaceSettings(): void;
        get workspaceSettingsInput(): WorkspaceSettingsProperty | undefined;
    }
    interface DefaultUserSettingsCodeEditorAppSettingsAppLifecycleManagementIdleSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#idle_timeout_in_minutes AwsSagemakerDomain#idle_timeout_in_minutes}
        */
        readonly idleTimeoutInMinutes?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#lifecycle_management AwsSagemakerDomain#lifecycle_management}
        */
        readonly lifecycleManagement?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#max_idle_timeout_in_minutes AwsSagemakerDomain#max_idle_timeout_in_minutes}
        */
        readonly maxIdleTimeoutInMinutes?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#min_idle_timeout_in_minutes AwsSagemakerDomain#min_idle_timeout_in_minutes}
        */
        readonly minIdleTimeoutInMinutes?: number;
    }
    class DefaultUserSettingsCodeEditorAppSettingsAppLifecycleManagementIdleSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultUserSettingsCodeEditorAppSettingsAppLifecycleManagementIdleSettingsProperty | undefined;
        set internalValue(value: DefaultUserSettingsCodeEditorAppSettingsAppLifecycleManagementIdleSettingsProperty | undefined);
        private _idleTimeoutInMinutes?;
        get idleTimeoutInMinutes(): number;
        set idleTimeoutInMinutes(value: number);
        resetIdleTimeoutInMinutes(): void;
        get idleTimeoutInMinutesInput(): number | undefined;
        private _lifecycleManagement?;
        get lifecycleManagement(): string;
        set lifecycleManagement(value: string);
        resetLifecycleManagement(): void;
        get lifecycleManagementInput(): string | undefined;
        private _maxIdleTimeoutInMinutes?;
        get maxIdleTimeoutInMinutes(): number;
        set maxIdleTimeoutInMinutes(value: number);
        resetMaxIdleTimeoutInMinutes(): void;
        get maxIdleTimeoutInMinutesInput(): number | undefined;
        private _minIdleTimeoutInMinutes?;
        get minIdleTimeoutInMinutes(): number;
        set minIdleTimeoutInMinutes(value: number);
        resetMinIdleTimeoutInMinutes(): void;
        get minIdleTimeoutInMinutesInput(): number | undefined;
    }
    interface DefaultUserSettingsCodeEditorAppSettingsAppLifecycleManagementProperty {
        /**
        * idle_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#idle_settings AwsSagemakerDomain#idle_settings}
        */
        readonly idleSettings?: DefaultUserSettingsCodeEditorAppSettingsAppLifecycleManagementIdleSettingsProperty;
    }
    class DefaultUserSettingsCodeEditorAppSettingsAppLifecycleManagementPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultUserSettingsCodeEditorAppSettingsAppLifecycleManagementProperty | undefined;
        set internalValue(value: DefaultUserSettingsCodeEditorAppSettingsAppLifecycleManagementProperty | undefined);
        private _idleSettings;
        get idleSettings(): DefaultUserSettingsCodeEditorAppSettingsAppLifecycleManagementIdleSettingsPropertyOutputReference;
        putIdleSettings(value: DefaultUserSettingsCodeEditorAppSettingsAppLifecycleManagementIdleSettingsProperty): void;
        resetIdleSettings(): void;
        get idleSettingsInput(): DefaultUserSettingsCodeEditorAppSettingsAppLifecycleManagementIdleSettingsProperty | undefined;
    }
    interface DefaultUserSettingsCodeEditorAppSettingsCustomImageProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#app_image_config_name AwsSagemakerDomain#app_image_config_name}
        */
        readonly appImageConfigName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#image_name AwsSagemakerDomain#image_name}
        */
        readonly imageName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#image_version_number AwsSagemakerDomain#image_version_number}
        */
        readonly imageVersionNumber?: number;
    }
    class DefaultUserSettingsCodeEditorAppSettingsCustomImagePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefaultUserSettingsCodeEditorAppSettingsCustomImageProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefaultUserSettingsCodeEditorAppSettingsCustomImageProperty | cdktn.IResolvable | undefined);
        private _appImageConfigName?;
        get appImageConfigName(): string;
        set appImageConfigName(value: string);
        get appImageConfigNameInput(): string | undefined;
        private _imageName?;
        get imageName(): string;
        set imageName(value: string);
        get imageNameInput(): string | undefined;
        private _imageVersionNumber?;
        get imageVersionNumber(): number;
        set imageVersionNumber(value: number);
        resetImageVersionNumber(): void;
        get imageVersionNumberInput(): number | undefined;
    }
    class DefaultUserSettingsCodeEditorAppSettingsCustomImagePropertyList extends cdktn.ComplexList {
        internalValue?: DefaultUserSettingsCodeEditorAppSettingsCustomImageProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefaultUserSettingsCodeEditorAppSettingsCustomImagePropertyOutputReference;
    }
    interface DefaultUserSettingsCodeEditorAppSettingsDefaultResourceSpecProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#instance_type AwsSagemakerDomain#instance_type}
        */
        readonly instanceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#lifecycle_config_arn AwsSagemakerDomain#lifecycle_config_arn}
        */
        readonly lifecycleConfigArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#sagemaker_image_arn AwsSagemakerDomain#sagemaker_image_arn}
        */
        readonly sagemakerImageArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#sagemaker_image_version_alias AwsSagemakerDomain#sagemaker_image_version_alias}
        */
        readonly sagemakerImageVersionAlias?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#sagemaker_image_version_arn AwsSagemakerDomain#sagemaker_image_version_arn}
        */
        readonly sagemakerImageVersionArn?: string;
    }
    class DefaultUserSettingsCodeEditorAppSettingsDefaultResourceSpecPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultUserSettingsCodeEditorAppSettingsDefaultResourceSpecProperty | undefined;
        set internalValue(value: DefaultUserSettingsCodeEditorAppSettingsDefaultResourceSpecProperty | undefined);
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        resetInstanceType(): void;
        get instanceTypeInput(): string | undefined;
        private _lifecycleConfigArn?;
        get lifecycleConfigArn(): string;
        set lifecycleConfigArn(value: string);
        resetLifecycleConfigArn(): void;
        get lifecycleConfigArnInput(): string | undefined;
        private _sagemakerImageArn?;
        get sagemakerImageArn(): string;
        set sagemakerImageArn(value: string);
        resetSagemakerImageArn(): void;
        get sagemakerImageArnInput(): string | undefined;
        private _sagemakerImageVersionAlias?;
        get sagemakerImageVersionAlias(): string;
        set sagemakerImageVersionAlias(value: string);
        resetSagemakerImageVersionAlias(): void;
        get sagemakerImageVersionAliasInput(): string | undefined;
        private _sagemakerImageVersionArn?;
        get sagemakerImageVersionArn(): string;
        set sagemakerImageVersionArn(value: string);
        resetSagemakerImageVersionArn(): void;
        get sagemakerImageVersionArnInput(): string | undefined;
    }
    interface CodeEditorAppSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#built_in_lifecycle_config_arn AwsSagemakerDomain#built_in_lifecycle_config_arn}
        */
        readonly builtInLifecycleConfigArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#lifecycle_config_arns AwsSagemakerDomain#lifecycle_config_arns}
        */
        readonly lifecycleConfigArns?: string[];
        /**
        * app_lifecycle_management block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#app_lifecycle_management AwsSagemakerDomain#app_lifecycle_management}
        */
        readonly appLifecycleManagement?: DefaultUserSettingsCodeEditorAppSettingsAppLifecycleManagementProperty;
        /**
        * custom_image block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#custom_image AwsSagemakerDomain#custom_image}
        */
        readonly customImage?: DefaultUserSettingsCodeEditorAppSettingsCustomImageProperty[] | cdktn.IResolvable;
        /**
        * default_resource_spec block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#default_resource_spec AwsSagemakerDomain#default_resource_spec}
        */
        readonly defaultResourceSpec?: DefaultUserSettingsCodeEditorAppSettingsDefaultResourceSpecProperty;
    }
    class CodeEditorAppSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CodeEditorAppSettingsProperty | undefined;
        set internalValue(value: CodeEditorAppSettingsProperty | undefined);
        private _builtInLifecycleConfigArn?;
        get builtInLifecycleConfigArn(): string;
        set builtInLifecycleConfigArn(value: string);
        resetBuiltInLifecycleConfigArn(): void;
        get builtInLifecycleConfigArnInput(): string | undefined;
        private _lifecycleConfigArns?;
        get lifecycleConfigArns(): string[];
        set lifecycleConfigArns(value: string[]);
        resetLifecycleConfigArns(): void;
        get lifecycleConfigArnsInput(): string[] | undefined;
        private _appLifecycleManagement;
        get appLifecycleManagement(): DefaultUserSettingsCodeEditorAppSettingsAppLifecycleManagementPropertyOutputReference;
        putAppLifecycleManagement(value: DefaultUserSettingsCodeEditorAppSettingsAppLifecycleManagementProperty): void;
        resetAppLifecycleManagement(): void;
        get appLifecycleManagementInput(): DefaultUserSettingsCodeEditorAppSettingsAppLifecycleManagementProperty | undefined;
        private _customImage;
        get customImage(): DefaultUserSettingsCodeEditorAppSettingsCustomImagePropertyList;
        putCustomImage(value: DefaultUserSettingsCodeEditorAppSettingsCustomImageProperty[] | cdktn.IResolvable): void;
        resetCustomImage(): void;
        get customImageInput(): cdktn.IResolvable | DefaultUserSettingsCodeEditorAppSettingsCustomImageProperty[] | undefined;
        private _defaultResourceSpec;
        get defaultResourceSpec(): DefaultUserSettingsCodeEditorAppSettingsDefaultResourceSpecPropertyOutputReference;
        putDefaultResourceSpec(value: DefaultUserSettingsCodeEditorAppSettingsDefaultResourceSpecProperty): void;
        resetDefaultResourceSpec(): void;
        get defaultResourceSpecInput(): DefaultUserSettingsCodeEditorAppSettingsDefaultResourceSpecProperty | undefined;
    }
    interface DefaultUserSettingsCustomFileSystemConfigEfsFileSystemConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#file_system_id AwsSagemakerDomain#file_system_id}
        */
        readonly fileSystemId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#file_system_path AwsSagemakerDomain#file_system_path}
        */
        readonly fileSystemPath: string;
    }
    class DefaultUserSettingsCustomFileSystemConfigEfsFileSystemConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultUserSettingsCustomFileSystemConfigEfsFileSystemConfigProperty | undefined;
        set internalValue(value: DefaultUserSettingsCustomFileSystemConfigEfsFileSystemConfigProperty | undefined);
        private _fileSystemId?;
        get fileSystemId(): string;
        set fileSystemId(value: string);
        get fileSystemIdInput(): string | undefined;
        private _fileSystemPath?;
        get fileSystemPath(): string;
        set fileSystemPath(value: string);
        get fileSystemPathInput(): string | undefined;
    }
    interface DefaultUserSettingsCustomFileSystemConfigProperty {
        /**
        * efs_file_system_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#efs_file_system_config AwsSagemakerDomain#efs_file_system_config}
        */
        readonly efsFileSystemConfig?: DefaultUserSettingsCustomFileSystemConfigEfsFileSystemConfigProperty;
    }
    class DefaultUserSettingsCustomFileSystemConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefaultUserSettingsCustomFileSystemConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefaultUserSettingsCustomFileSystemConfigProperty | cdktn.IResolvable | undefined);
        private _efsFileSystemConfig;
        get efsFileSystemConfig(): DefaultUserSettingsCustomFileSystemConfigEfsFileSystemConfigPropertyOutputReference;
        putEfsFileSystemConfig(value: DefaultUserSettingsCustomFileSystemConfigEfsFileSystemConfigProperty): void;
        resetEfsFileSystemConfig(): void;
        get efsFileSystemConfigInput(): DefaultUserSettingsCustomFileSystemConfigEfsFileSystemConfigProperty | undefined;
    }
    class DefaultUserSettingsCustomFileSystemConfigPropertyList extends cdktn.ComplexList {
        internalValue?: DefaultUserSettingsCustomFileSystemConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefaultUserSettingsCustomFileSystemConfigPropertyOutputReference;
    }
    interface DefaultUserSettingsCustomPosixUserConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#gid AwsSagemakerDomain#gid}
        */
        readonly gid: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#uid AwsSagemakerDomain#uid}
        */
        readonly uid: number;
    }
    class DefaultUserSettingsCustomPosixUserConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultUserSettingsCustomPosixUserConfigProperty | undefined;
        set internalValue(value: DefaultUserSettingsCustomPosixUserConfigProperty | undefined);
        private _gid?;
        get gid(): number;
        set gid(value: number);
        get gidInput(): number | undefined;
        private _uid?;
        get uid(): number;
        set uid(value: number);
        get uidInput(): number | undefined;
    }
    interface DefaultUserSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#idle_timeout_in_minutes AwsSagemakerDomain#idle_timeout_in_minutes}
        */
        readonly idleTimeoutInMinutes?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#lifecycle_management AwsSagemakerDomain#lifecycle_management}
        */
        readonly lifecycleManagement?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#max_idle_timeout_in_minutes AwsSagemakerDomain#max_idle_timeout_in_minutes}
        */
        readonly maxIdleTimeoutInMinutes?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#min_idle_timeout_in_minutes AwsSagemakerDomain#min_idle_timeout_in_minutes}
        */
        readonly minIdleTimeoutInMinutes?: number;
    }
    class DefaultUserSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultUserSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsProperty | undefined;
        set internalValue(value: DefaultUserSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsProperty | undefined);
        private _idleTimeoutInMinutes?;
        get idleTimeoutInMinutes(): number;
        set idleTimeoutInMinutes(value: number);
        resetIdleTimeoutInMinutes(): void;
        get idleTimeoutInMinutesInput(): number | undefined;
        private _lifecycleManagement?;
        get lifecycleManagement(): string;
        set lifecycleManagement(value: string);
        resetLifecycleManagement(): void;
        get lifecycleManagementInput(): string | undefined;
        private _maxIdleTimeoutInMinutes?;
        get maxIdleTimeoutInMinutes(): number;
        set maxIdleTimeoutInMinutes(value: number);
        resetMaxIdleTimeoutInMinutes(): void;
        get maxIdleTimeoutInMinutesInput(): number | undefined;
        private _minIdleTimeoutInMinutes?;
        get minIdleTimeoutInMinutes(): number;
        set minIdleTimeoutInMinutes(value: number);
        resetMinIdleTimeoutInMinutes(): void;
        get minIdleTimeoutInMinutesInput(): number | undefined;
    }
    interface DefaultUserSettingsJupyterLabAppSettingsAppLifecycleManagementProperty {
        /**
        * idle_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#idle_settings AwsSagemakerDomain#idle_settings}
        */
        readonly idleSettings?: DefaultUserSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsProperty;
    }
    class DefaultUserSettingsJupyterLabAppSettingsAppLifecycleManagementPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultUserSettingsJupyterLabAppSettingsAppLifecycleManagementProperty | undefined;
        set internalValue(value: DefaultUserSettingsJupyterLabAppSettingsAppLifecycleManagementProperty | undefined);
        private _idleSettings;
        get idleSettings(): DefaultUserSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsPropertyOutputReference;
        putIdleSettings(value: DefaultUserSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsProperty): void;
        resetIdleSettings(): void;
        get idleSettingsInput(): DefaultUserSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsProperty | undefined;
    }
    interface DefaultUserSettingsJupyterLabAppSettingsCodeRepositoryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#repository_url AwsSagemakerDomain#repository_url}
        */
        readonly repositoryUrl: string;
    }
    class DefaultUserSettingsJupyterLabAppSettingsCodeRepositoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefaultUserSettingsJupyterLabAppSettingsCodeRepositoryProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefaultUserSettingsJupyterLabAppSettingsCodeRepositoryProperty | cdktn.IResolvable | undefined);
        private _repositoryUrl?;
        get repositoryUrl(): string;
        set repositoryUrl(value: string);
        get repositoryUrlInput(): string | undefined;
    }
    class DefaultUserSettingsJupyterLabAppSettingsCodeRepositoryPropertyList extends cdktn.ComplexList {
        internalValue?: DefaultUserSettingsJupyterLabAppSettingsCodeRepositoryProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefaultUserSettingsJupyterLabAppSettingsCodeRepositoryPropertyOutputReference;
    }
    interface DefaultUserSettingsJupyterLabAppSettingsCustomImageProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#app_image_config_name AwsSagemakerDomain#app_image_config_name}
        */
        readonly appImageConfigName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#image_name AwsSagemakerDomain#image_name}
        */
        readonly imageName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#image_version_number AwsSagemakerDomain#image_version_number}
        */
        readonly imageVersionNumber?: number;
    }
    class DefaultUserSettingsJupyterLabAppSettingsCustomImagePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefaultUserSettingsJupyterLabAppSettingsCustomImageProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefaultUserSettingsJupyterLabAppSettingsCustomImageProperty | cdktn.IResolvable | undefined);
        private _appImageConfigName?;
        get appImageConfigName(): string;
        set appImageConfigName(value: string);
        get appImageConfigNameInput(): string | undefined;
        private _imageName?;
        get imageName(): string;
        set imageName(value: string);
        get imageNameInput(): string | undefined;
        private _imageVersionNumber?;
        get imageVersionNumber(): number;
        set imageVersionNumber(value: number);
        resetImageVersionNumber(): void;
        get imageVersionNumberInput(): number | undefined;
    }
    class DefaultUserSettingsJupyterLabAppSettingsCustomImagePropertyList extends cdktn.ComplexList {
        internalValue?: DefaultUserSettingsJupyterLabAppSettingsCustomImageProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefaultUserSettingsJupyterLabAppSettingsCustomImagePropertyOutputReference;
    }
    interface DefaultUserSettingsJupyterLabAppSettingsDefaultResourceSpecProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#instance_type AwsSagemakerDomain#instance_type}
        */
        readonly instanceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#lifecycle_config_arn AwsSagemakerDomain#lifecycle_config_arn}
        */
        readonly lifecycleConfigArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#sagemaker_image_arn AwsSagemakerDomain#sagemaker_image_arn}
        */
        readonly sagemakerImageArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#sagemaker_image_version_alias AwsSagemakerDomain#sagemaker_image_version_alias}
        */
        readonly sagemakerImageVersionAlias?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#sagemaker_image_version_arn AwsSagemakerDomain#sagemaker_image_version_arn}
        */
        readonly sagemakerImageVersionArn?: string;
    }
    class DefaultUserSettingsJupyterLabAppSettingsDefaultResourceSpecPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultUserSettingsJupyterLabAppSettingsDefaultResourceSpecProperty | undefined;
        set internalValue(value: DefaultUserSettingsJupyterLabAppSettingsDefaultResourceSpecProperty | undefined);
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        resetInstanceType(): void;
        get instanceTypeInput(): string | undefined;
        private _lifecycleConfigArn?;
        get lifecycleConfigArn(): string;
        set lifecycleConfigArn(value: string);
        resetLifecycleConfigArn(): void;
        get lifecycleConfigArnInput(): string | undefined;
        private _sagemakerImageArn?;
        get sagemakerImageArn(): string;
        set sagemakerImageArn(value: string);
        resetSagemakerImageArn(): void;
        get sagemakerImageArnInput(): string | undefined;
        private _sagemakerImageVersionAlias?;
        get sagemakerImageVersionAlias(): string;
        set sagemakerImageVersionAlias(value: string);
        resetSagemakerImageVersionAlias(): void;
        get sagemakerImageVersionAliasInput(): string | undefined;
        private _sagemakerImageVersionArn?;
        get sagemakerImageVersionArn(): string;
        set sagemakerImageVersionArn(value: string);
        resetSagemakerImageVersionArn(): void;
        get sagemakerImageVersionArnInput(): string | undefined;
    }
    interface DefaultUserSettingsJupyterLabAppSettingsEmrSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#assumable_role_arns AwsSagemakerDomain#assumable_role_arns}
        */
        readonly assumableRoleArns?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#execution_role_arns AwsSagemakerDomain#execution_role_arns}
        */
        readonly executionRoleArns?: string[];
    }
    class DefaultUserSettingsJupyterLabAppSettingsEmrSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultUserSettingsJupyterLabAppSettingsEmrSettingsProperty | undefined;
        set internalValue(value: DefaultUserSettingsJupyterLabAppSettingsEmrSettingsProperty | undefined);
        private _assumableRoleArns?;
        get assumableRoleArns(): string[];
        set assumableRoleArns(value: string[]);
        resetAssumableRoleArns(): void;
        get assumableRoleArnsInput(): string[] | undefined;
        private _executionRoleArns?;
        get executionRoleArns(): string[];
        set executionRoleArns(value: string[]);
        resetExecutionRoleArns(): void;
        get executionRoleArnsInput(): string[] | undefined;
    }
    interface DefaultUserSettingsJupyterLabAppSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#built_in_lifecycle_config_arn AwsSagemakerDomain#built_in_lifecycle_config_arn}
        */
        readonly builtInLifecycleConfigArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#lifecycle_config_arns AwsSagemakerDomain#lifecycle_config_arns}
        */
        readonly lifecycleConfigArns?: string[];
        /**
        * app_lifecycle_management block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#app_lifecycle_management AwsSagemakerDomain#app_lifecycle_management}
        */
        readonly appLifecycleManagement?: DefaultUserSettingsJupyterLabAppSettingsAppLifecycleManagementProperty;
        /**
        * code_repository block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#code_repository AwsSagemakerDomain#code_repository}
        */
        readonly codeRepository?: DefaultUserSettingsJupyterLabAppSettingsCodeRepositoryProperty[] | cdktn.IResolvable;
        /**
        * custom_image block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#custom_image AwsSagemakerDomain#custom_image}
        */
        readonly customImage?: DefaultUserSettingsJupyterLabAppSettingsCustomImageProperty[] | cdktn.IResolvable;
        /**
        * default_resource_spec block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#default_resource_spec AwsSagemakerDomain#default_resource_spec}
        */
        readonly defaultResourceSpec?: DefaultUserSettingsJupyterLabAppSettingsDefaultResourceSpecProperty;
        /**
        * emr_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#emr_settings AwsSagemakerDomain#emr_settings}
        */
        readonly emrSettings?: DefaultUserSettingsJupyterLabAppSettingsEmrSettingsProperty;
    }
    class DefaultUserSettingsJupyterLabAppSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultUserSettingsJupyterLabAppSettingsProperty | undefined;
        set internalValue(value: DefaultUserSettingsJupyterLabAppSettingsProperty | undefined);
        private _builtInLifecycleConfigArn?;
        get builtInLifecycleConfigArn(): string;
        set builtInLifecycleConfigArn(value: string);
        resetBuiltInLifecycleConfigArn(): void;
        get builtInLifecycleConfigArnInput(): string | undefined;
        private _lifecycleConfigArns?;
        get lifecycleConfigArns(): string[];
        set lifecycleConfigArns(value: string[]);
        resetLifecycleConfigArns(): void;
        get lifecycleConfigArnsInput(): string[] | undefined;
        private _appLifecycleManagement;
        get appLifecycleManagement(): DefaultUserSettingsJupyterLabAppSettingsAppLifecycleManagementPropertyOutputReference;
        putAppLifecycleManagement(value: DefaultUserSettingsJupyterLabAppSettingsAppLifecycleManagementProperty): void;
        resetAppLifecycleManagement(): void;
        get appLifecycleManagementInput(): DefaultUserSettingsJupyterLabAppSettingsAppLifecycleManagementProperty | undefined;
        private _codeRepository;
        get codeRepository(): DefaultUserSettingsJupyterLabAppSettingsCodeRepositoryPropertyList;
        putCodeRepository(value: DefaultUserSettingsJupyterLabAppSettingsCodeRepositoryProperty[] | cdktn.IResolvable): void;
        resetCodeRepository(): void;
        get codeRepositoryInput(): cdktn.IResolvable | DefaultUserSettingsJupyterLabAppSettingsCodeRepositoryProperty[] | undefined;
        private _customImage;
        get customImage(): DefaultUserSettingsJupyterLabAppSettingsCustomImagePropertyList;
        putCustomImage(value: DefaultUserSettingsJupyterLabAppSettingsCustomImageProperty[] | cdktn.IResolvable): void;
        resetCustomImage(): void;
        get customImageInput(): cdktn.IResolvable | DefaultUserSettingsJupyterLabAppSettingsCustomImageProperty[] | undefined;
        private _defaultResourceSpec;
        get defaultResourceSpec(): DefaultUserSettingsJupyterLabAppSettingsDefaultResourceSpecPropertyOutputReference;
        putDefaultResourceSpec(value: DefaultUserSettingsJupyterLabAppSettingsDefaultResourceSpecProperty): void;
        resetDefaultResourceSpec(): void;
        get defaultResourceSpecInput(): DefaultUserSettingsJupyterLabAppSettingsDefaultResourceSpecProperty | undefined;
        private _emrSettings;
        get emrSettings(): DefaultUserSettingsJupyterLabAppSettingsEmrSettingsPropertyOutputReference;
        putEmrSettings(value: DefaultUserSettingsJupyterLabAppSettingsEmrSettingsProperty): void;
        resetEmrSettings(): void;
        get emrSettingsInput(): DefaultUserSettingsJupyterLabAppSettingsEmrSettingsProperty | undefined;
    }
    interface DefaultUserSettingsJupyterServerAppSettingsCodeRepositoryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#repository_url AwsSagemakerDomain#repository_url}
        */
        readonly repositoryUrl: string;
    }
    class DefaultUserSettingsJupyterServerAppSettingsCodeRepositoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefaultUserSettingsJupyterServerAppSettingsCodeRepositoryProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefaultUserSettingsJupyterServerAppSettingsCodeRepositoryProperty | cdktn.IResolvable | undefined);
        private _repositoryUrl?;
        get repositoryUrl(): string;
        set repositoryUrl(value: string);
        get repositoryUrlInput(): string | undefined;
    }
    class DefaultUserSettingsJupyterServerAppSettingsCodeRepositoryPropertyList extends cdktn.ComplexList {
        internalValue?: DefaultUserSettingsJupyterServerAppSettingsCodeRepositoryProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefaultUserSettingsJupyterServerAppSettingsCodeRepositoryPropertyOutputReference;
    }
    interface DefaultUserSettingsJupyterServerAppSettingsDefaultResourceSpecProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#instance_type AwsSagemakerDomain#instance_type}
        */
        readonly instanceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#lifecycle_config_arn AwsSagemakerDomain#lifecycle_config_arn}
        */
        readonly lifecycleConfigArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#sagemaker_image_arn AwsSagemakerDomain#sagemaker_image_arn}
        */
        readonly sagemakerImageArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#sagemaker_image_version_alias AwsSagemakerDomain#sagemaker_image_version_alias}
        */
        readonly sagemakerImageVersionAlias?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#sagemaker_image_version_arn AwsSagemakerDomain#sagemaker_image_version_arn}
        */
        readonly sagemakerImageVersionArn?: string;
    }
    class DefaultUserSettingsJupyterServerAppSettingsDefaultResourceSpecPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultUserSettingsJupyterServerAppSettingsDefaultResourceSpecProperty | undefined;
        set internalValue(value: DefaultUserSettingsJupyterServerAppSettingsDefaultResourceSpecProperty | undefined);
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        resetInstanceType(): void;
        get instanceTypeInput(): string | undefined;
        private _lifecycleConfigArn?;
        get lifecycleConfigArn(): string;
        set lifecycleConfigArn(value: string);
        resetLifecycleConfigArn(): void;
        get lifecycleConfigArnInput(): string | undefined;
        private _sagemakerImageArn?;
        get sagemakerImageArn(): string;
        set sagemakerImageArn(value: string);
        resetSagemakerImageArn(): void;
        get sagemakerImageArnInput(): string | undefined;
        private _sagemakerImageVersionAlias?;
        get sagemakerImageVersionAlias(): string;
        set sagemakerImageVersionAlias(value: string);
        resetSagemakerImageVersionAlias(): void;
        get sagemakerImageVersionAliasInput(): string | undefined;
        private _sagemakerImageVersionArn?;
        get sagemakerImageVersionArn(): string;
        set sagemakerImageVersionArn(value: string);
        resetSagemakerImageVersionArn(): void;
        get sagemakerImageVersionArnInput(): string | undefined;
    }
    interface DefaultUserSettingsJupyterServerAppSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#lifecycle_config_arns AwsSagemakerDomain#lifecycle_config_arns}
        */
        readonly lifecycleConfigArns?: string[];
        /**
        * code_repository block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#code_repository AwsSagemakerDomain#code_repository}
        */
        readonly codeRepository?: DefaultUserSettingsJupyterServerAppSettingsCodeRepositoryProperty[] | cdktn.IResolvable;
        /**
        * default_resource_spec block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#default_resource_spec AwsSagemakerDomain#default_resource_spec}
        */
        readonly defaultResourceSpec?: DefaultUserSettingsJupyterServerAppSettingsDefaultResourceSpecProperty;
    }
    class DefaultUserSettingsJupyterServerAppSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultUserSettingsJupyterServerAppSettingsProperty | undefined;
        set internalValue(value: DefaultUserSettingsJupyterServerAppSettingsProperty | undefined);
        private _lifecycleConfigArns?;
        get lifecycleConfigArns(): string[];
        set lifecycleConfigArns(value: string[]);
        resetLifecycleConfigArns(): void;
        get lifecycleConfigArnsInput(): string[] | undefined;
        private _codeRepository;
        get codeRepository(): DefaultUserSettingsJupyterServerAppSettingsCodeRepositoryPropertyList;
        putCodeRepository(value: DefaultUserSettingsJupyterServerAppSettingsCodeRepositoryProperty[] | cdktn.IResolvable): void;
        resetCodeRepository(): void;
        get codeRepositoryInput(): cdktn.IResolvable | DefaultUserSettingsJupyterServerAppSettingsCodeRepositoryProperty[] | undefined;
        private _defaultResourceSpec;
        get defaultResourceSpec(): DefaultUserSettingsJupyterServerAppSettingsDefaultResourceSpecPropertyOutputReference;
        putDefaultResourceSpec(value: DefaultUserSettingsJupyterServerAppSettingsDefaultResourceSpecProperty): void;
        resetDefaultResourceSpec(): void;
        get defaultResourceSpecInput(): DefaultUserSettingsJupyterServerAppSettingsDefaultResourceSpecProperty | undefined;
    }
    interface DefaultUserSettingsKernelGatewayAppSettingsCustomImageProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#app_image_config_name AwsSagemakerDomain#app_image_config_name}
        */
        readonly appImageConfigName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#image_name AwsSagemakerDomain#image_name}
        */
        readonly imageName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#image_version_number AwsSagemakerDomain#image_version_number}
        */
        readonly imageVersionNumber?: number;
    }
    class DefaultUserSettingsKernelGatewayAppSettingsCustomImagePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefaultUserSettingsKernelGatewayAppSettingsCustomImageProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefaultUserSettingsKernelGatewayAppSettingsCustomImageProperty | cdktn.IResolvable | undefined);
        private _appImageConfigName?;
        get appImageConfigName(): string;
        set appImageConfigName(value: string);
        get appImageConfigNameInput(): string | undefined;
        private _imageName?;
        get imageName(): string;
        set imageName(value: string);
        get imageNameInput(): string | undefined;
        private _imageVersionNumber?;
        get imageVersionNumber(): number;
        set imageVersionNumber(value: number);
        resetImageVersionNumber(): void;
        get imageVersionNumberInput(): number | undefined;
    }
    class DefaultUserSettingsKernelGatewayAppSettingsCustomImagePropertyList extends cdktn.ComplexList {
        internalValue?: DefaultUserSettingsKernelGatewayAppSettingsCustomImageProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefaultUserSettingsKernelGatewayAppSettingsCustomImagePropertyOutputReference;
    }
    interface DefaultUserSettingsKernelGatewayAppSettingsDefaultResourceSpecProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#instance_type AwsSagemakerDomain#instance_type}
        */
        readonly instanceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#lifecycle_config_arn AwsSagemakerDomain#lifecycle_config_arn}
        */
        readonly lifecycleConfigArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#sagemaker_image_arn AwsSagemakerDomain#sagemaker_image_arn}
        */
        readonly sagemakerImageArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#sagemaker_image_version_alias AwsSagemakerDomain#sagemaker_image_version_alias}
        */
        readonly sagemakerImageVersionAlias?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#sagemaker_image_version_arn AwsSagemakerDomain#sagemaker_image_version_arn}
        */
        readonly sagemakerImageVersionArn?: string;
    }
    class DefaultUserSettingsKernelGatewayAppSettingsDefaultResourceSpecPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultUserSettingsKernelGatewayAppSettingsDefaultResourceSpecProperty | undefined;
        set internalValue(value: DefaultUserSettingsKernelGatewayAppSettingsDefaultResourceSpecProperty | undefined);
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        resetInstanceType(): void;
        get instanceTypeInput(): string | undefined;
        private _lifecycleConfigArn?;
        get lifecycleConfigArn(): string;
        set lifecycleConfigArn(value: string);
        resetLifecycleConfigArn(): void;
        get lifecycleConfigArnInput(): string | undefined;
        private _sagemakerImageArn?;
        get sagemakerImageArn(): string;
        set sagemakerImageArn(value: string);
        resetSagemakerImageArn(): void;
        get sagemakerImageArnInput(): string | undefined;
        private _sagemakerImageVersionAlias?;
        get sagemakerImageVersionAlias(): string;
        set sagemakerImageVersionAlias(value: string);
        resetSagemakerImageVersionAlias(): void;
        get sagemakerImageVersionAliasInput(): string | undefined;
        private _sagemakerImageVersionArn?;
        get sagemakerImageVersionArn(): string;
        set sagemakerImageVersionArn(value: string);
        resetSagemakerImageVersionArn(): void;
        get sagemakerImageVersionArnInput(): string | undefined;
    }
    interface DefaultUserSettingsKernelGatewayAppSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#lifecycle_config_arns AwsSagemakerDomain#lifecycle_config_arns}
        */
        readonly lifecycleConfigArns?: string[];
        /**
        * custom_image block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#custom_image AwsSagemakerDomain#custom_image}
        */
        readonly customImage?: DefaultUserSettingsKernelGatewayAppSettingsCustomImageProperty[] | cdktn.IResolvable;
        /**
        * default_resource_spec block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#default_resource_spec AwsSagemakerDomain#default_resource_spec}
        */
        readonly defaultResourceSpec?: DefaultUserSettingsKernelGatewayAppSettingsDefaultResourceSpecProperty;
    }
    class DefaultUserSettingsKernelGatewayAppSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultUserSettingsKernelGatewayAppSettingsProperty | undefined;
        set internalValue(value: DefaultUserSettingsKernelGatewayAppSettingsProperty | undefined);
        private _lifecycleConfigArns?;
        get lifecycleConfigArns(): string[];
        set lifecycleConfigArns(value: string[]);
        resetLifecycleConfigArns(): void;
        get lifecycleConfigArnsInput(): string[] | undefined;
        private _customImage;
        get customImage(): DefaultUserSettingsKernelGatewayAppSettingsCustomImagePropertyList;
        putCustomImage(value: DefaultUserSettingsKernelGatewayAppSettingsCustomImageProperty[] | cdktn.IResolvable): void;
        resetCustomImage(): void;
        get customImageInput(): cdktn.IResolvable | DefaultUserSettingsKernelGatewayAppSettingsCustomImageProperty[] | undefined;
        private _defaultResourceSpec;
        get defaultResourceSpec(): DefaultUserSettingsKernelGatewayAppSettingsDefaultResourceSpecPropertyOutputReference;
        putDefaultResourceSpec(value: DefaultUserSettingsKernelGatewayAppSettingsDefaultResourceSpecProperty): void;
        resetDefaultResourceSpec(): void;
        get defaultResourceSpecInput(): DefaultUserSettingsKernelGatewayAppSettingsDefaultResourceSpecProperty | undefined;
    }
    interface DefaultUserSettingsRSessionAppSettingsCustomImageProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#app_image_config_name AwsSagemakerDomain#app_image_config_name}
        */
        readonly appImageConfigName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#image_name AwsSagemakerDomain#image_name}
        */
        readonly imageName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#image_version_number AwsSagemakerDomain#image_version_number}
        */
        readonly imageVersionNumber?: number;
    }
    class DefaultUserSettingsRSessionAppSettingsCustomImagePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefaultUserSettingsRSessionAppSettingsCustomImageProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefaultUserSettingsRSessionAppSettingsCustomImageProperty | cdktn.IResolvable | undefined);
        private _appImageConfigName?;
        get appImageConfigName(): string;
        set appImageConfigName(value: string);
        get appImageConfigNameInput(): string | undefined;
        private _imageName?;
        get imageName(): string;
        set imageName(value: string);
        get imageNameInput(): string | undefined;
        private _imageVersionNumber?;
        get imageVersionNumber(): number;
        set imageVersionNumber(value: number);
        resetImageVersionNumber(): void;
        get imageVersionNumberInput(): number | undefined;
    }
    class DefaultUserSettingsRSessionAppSettingsCustomImagePropertyList extends cdktn.ComplexList {
        internalValue?: DefaultUserSettingsRSessionAppSettingsCustomImageProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefaultUserSettingsRSessionAppSettingsCustomImagePropertyOutputReference;
    }
    interface DefaultUserSettingsRSessionAppSettingsDefaultResourceSpecProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#instance_type AwsSagemakerDomain#instance_type}
        */
        readonly instanceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#lifecycle_config_arn AwsSagemakerDomain#lifecycle_config_arn}
        */
        readonly lifecycleConfigArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#sagemaker_image_arn AwsSagemakerDomain#sagemaker_image_arn}
        */
        readonly sagemakerImageArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#sagemaker_image_version_alias AwsSagemakerDomain#sagemaker_image_version_alias}
        */
        readonly sagemakerImageVersionAlias?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#sagemaker_image_version_arn AwsSagemakerDomain#sagemaker_image_version_arn}
        */
        readonly sagemakerImageVersionArn?: string;
    }
    class DefaultUserSettingsRSessionAppSettingsDefaultResourceSpecPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultUserSettingsRSessionAppSettingsDefaultResourceSpecProperty | undefined;
        set internalValue(value: DefaultUserSettingsRSessionAppSettingsDefaultResourceSpecProperty | undefined);
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        resetInstanceType(): void;
        get instanceTypeInput(): string | undefined;
        private _lifecycleConfigArn?;
        get lifecycleConfigArn(): string;
        set lifecycleConfigArn(value: string);
        resetLifecycleConfigArn(): void;
        get lifecycleConfigArnInput(): string | undefined;
        private _sagemakerImageArn?;
        get sagemakerImageArn(): string;
        set sagemakerImageArn(value: string);
        resetSagemakerImageArn(): void;
        get sagemakerImageArnInput(): string | undefined;
        private _sagemakerImageVersionAlias?;
        get sagemakerImageVersionAlias(): string;
        set sagemakerImageVersionAlias(value: string);
        resetSagemakerImageVersionAlias(): void;
        get sagemakerImageVersionAliasInput(): string | undefined;
        private _sagemakerImageVersionArn?;
        get sagemakerImageVersionArn(): string;
        set sagemakerImageVersionArn(value: string);
        resetSagemakerImageVersionArn(): void;
        get sagemakerImageVersionArnInput(): string | undefined;
    }
    interface RSessionAppSettingsProperty {
        /**
        * custom_image block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#custom_image AwsSagemakerDomain#custom_image}
        */
        readonly customImage?: DefaultUserSettingsRSessionAppSettingsCustomImageProperty[] | cdktn.IResolvable;
        /**
        * default_resource_spec block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#default_resource_spec AwsSagemakerDomain#default_resource_spec}
        */
        readonly defaultResourceSpec?: DefaultUserSettingsRSessionAppSettingsDefaultResourceSpecProperty;
    }
    class RSessionAppSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RSessionAppSettingsProperty | undefined;
        set internalValue(value: RSessionAppSettingsProperty | undefined);
        private _customImage;
        get customImage(): DefaultUserSettingsRSessionAppSettingsCustomImagePropertyList;
        putCustomImage(value: DefaultUserSettingsRSessionAppSettingsCustomImageProperty[] | cdktn.IResolvable): void;
        resetCustomImage(): void;
        get customImageInput(): cdktn.IResolvable | DefaultUserSettingsRSessionAppSettingsCustomImageProperty[] | undefined;
        private _defaultResourceSpec;
        get defaultResourceSpec(): DefaultUserSettingsRSessionAppSettingsDefaultResourceSpecPropertyOutputReference;
        putDefaultResourceSpec(value: DefaultUserSettingsRSessionAppSettingsDefaultResourceSpecProperty): void;
        resetDefaultResourceSpec(): void;
        get defaultResourceSpecInput(): DefaultUserSettingsRSessionAppSettingsDefaultResourceSpecProperty | undefined;
    }
    interface RStudioServerProAppSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#access_status AwsSagemakerDomain#access_status}
        */
        readonly accessStatus?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#user_group AwsSagemakerDomain#user_group}
        */
        readonly userGroup?: string;
    }
    class RStudioServerProAppSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RStudioServerProAppSettingsProperty | undefined;
        set internalValue(value: RStudioServerProAppSettingsProperty | undefined);
        private _accessStatus?;
        get accessStatus(): string;
        set accessStatus(value: string);
        resetAccessStatus(): void;
        get accessStatusInput(): string | undefined;
        private _userGroup?;
        get userGroup(): string;
        set userGroup(value: string);
        resetUserGroup(): void;
        get userGroupInput(): string | undefined;
    }
    interface SharingSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#notebook_output_option AwsSagemakerDomain#notebook_output_option}
        */
        readonly notebookOutputOption?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#s3_kms_key_id AwsSagemakerDomain#s3_kms_key_id}
        */
        readonly s3KmsKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#s3_output_path AwsSagemakerDomain#s3_output_path}
        */
        readonly s3OutputPath?: string;
    }
    class SharingSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SharingSettingsProperty | undefined;
        set internalValue(value: SharingSettingsProperty | undefined);
        private _notebookOutputOption?;
        get notebookOutputOption(): string;
        set notebookOutputOption(value: string);
        resetNotebookOutputOption(): void;
        get notebookOutputOptionInput(): string | undefined;
        private _s3KmsKeyId?;
        get s3KmsKeyId(): string;
        set s3KmsKeyId(value: string);
        resetS3KmsKeyId(): void;
        get s3KmsKeyIdInput(): string | undefined;
        private _s3OutputPath?;
        get s3OutputPath(): string;
        set s3OutputPath(value: string);
        resetS3OutputPath(): void;
        get s3OutputPathInput(): string | undefined;
    }
    interface DefaultUserSettingsSpaceStorageSettingsDefaultEbsStorageSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#default_ebs_volume_size_in_gb AwsSagemakerDomain#default_ebs_volume_size_in_gb}
        */
        readonly defaultEbsVolumeSizeInGb: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#maximum_ebs_volume_size_in_gb AwsSagemakerDomain#maximum_ebs_volume_size_in_gb}
        */
        readonly maximumEbsVolumeSizeInGb: number;
    }
    class DefaultUserSettingsSpaceStorageSettingsDefaultEbsStorageSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultUserSettingsSpaceStorageSettingsDefaultEbsStorageSettingsProperty | undefined;
        set internalValue(value: DefaultUserSettingsSpaceStorageSettingsDefaultEbsStorageSettingsProperty | undefined);
        private _defaultEbsVolumeSizeInGb?;
        get defaultEbsVolumeSizeInGb(): number;
        set defaultEbsVolumeSizeInGb(value: number);
        get defaultEbsVolumeSizeInGbInput(): number | undefined;
        private _maximumEbsVolumeSizeInGb?;
        get maximumEbsVolumeSizeInGb(): number;
        set maximumEbsVolumeSizeInGb(value: number);
        get maximumEbsVolumeSizeInGbInput(): number | undefined;
    }
    interface DefaultUserSettingsSpaceStorageSettingsProperty {
        /**
        * default_ebs_storage_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#default_ebs_storage_settings AwsSagemakerDomain#default_ebs_storage_settings}
        */
        readonly defaultEbsStorageSettings?: DefaultUserSettingsSpaceStorageSettingsDefaultEbsStorageSettingsProperty;
    }
    class DefaultUserSettingsSpaceStorageSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultUserSettingsSpaceStorageSettingsProperty | undefined;
        set internalValue(value: DefaultUserSettingsSpaceStorageSettingsProperty | undefined);
        private _defaultEbsStorageSettings;
        get defaultEbsStorageSettings(): DefaultUserSettingsSpaceStorageSettingsDefaultEbsStorageSettingsPropertyOutputReference;
        putDefaultEbsStorageSettings(value: DefaultUserSettingsSpaceStorageSettingsDefaultEbsStorageSettingsProperty): void;
        resetDefaultEbsStorageSettings(): void;
        get defaultEbsStorageSettingsInput(): DefaultUserSettingsSpaceStorageSettingsDefaultEbsStorageSettingsProperty | undefined;
    }
    interface StudioWebPortalSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#hidden_app_types AwsSagemakerDomain#hidden_app_types}
        */
        readonly hiddenAppTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#hidden_instance_types AwsSagemakerDomain#hidden_instance_types}
        */
        readonly hiddenInstanceTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#hidden_ml_tools AwsSagemakerDomain#hidden_ml_tools}
        */
        readonly hiddenMlTools?: string[];
    }
    class StudioWebPortalSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StudioWebPortalSettingsProperty | undefined;
        set internalValue(value: StudioWebPortalSettingsProperty | undefined);
        private _hiddenAppTypes?;
        get hiddenAppTypes(): string[];
        set hiddenAppTypes(value: string[]);
        resetHiddenAppTypes(): void;
        get hiddenAppTypesInput(): string[] | undefined;
        private _hiddenInstanceTypes?;
        get hiddenInstanceTypes(): string[];
        set hiddenInstanceTypes(value: string[]);
        resetHiddenInstanceTypes(): void;
        get hiddenInstanceTypesInput(): string[] | undefined;
        private _hiddenMlTools?;
        get hiddenMlTools(): string[];
        set hiddenMlTools(value: string[]);
        resetHiddenMlTools(): void;
        get hiddenMlToolsInput(): string[] | undefined;
    }
    interface DefaultUserSettingsTensorBoardAppSettingsDefaultResourceSpecProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#instance_type AwsSagemakerDomain#instance_type}
        */
        readonly instanceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#lifecycle_config_arn AwsSagemakerDomain#lifecycle_config_arn}
        */
        readonly lifecycleConfigArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#sagemaker_image_arn AwsSagemakerDomain#sagemaker_image_arn}
        */
        readonly sagemakerImageArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#sagemaker_image_version_alias AwsSagemakerDomain#sagemaker_image_version_alias}
        */
        readonly sagemakerImageVersionAlias?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#sagemaker_image_version_arn AwsSagemakerDomain#sagemaker_image_version_arn}
        */
        readonly sagemakerImageVersionArn?: string;
    }
    class DefaultUserSettingsTensorBoardAppSettingsDefaultResourceSpecPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultUserSettingsTensorBoardAppSettingsDefaultResourceSpecProperty | undefined;
        set internalValue(value: DefaultUserSettingsTensorBoardAppSettingsDefaultResourceSpecProperty | undefined);
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        resetInstanceType(): void;
        get instanceTypeInput(): string | undefined;
        private _lifecycleConfigArn?;
        get lifecycleConfigArn(): string;
        set lifecycleConfigArn(value: string);
        resetLifecycleConfigArn(): void;
        get lifecycleConfigArnInput(): string | undefined;
        private _sagemakerImageArn?;
        get sagemakerImageArn(): string;
        set sagemakerImageArn(value: string);
        resetSagemakerImageArn(): void;
        get sagemakerImageArnInput(): string | undefined;
        private _sagemakerImageVersionAlias?;
        get sagemakerImageVersionAlias(): string;
        set sagemakerImageVersionAlias(value: string);
        resetSagemakerImageVersionAlias(): void;
        get sagemakerImageVersionAliasInput(): string | undefined;
        private _sagemakerImageVersionArn?;
        get sagemakerImageVersionArn(): string;
        set sagemakerImageVersionArn(value: string);
        resetSagemakerImageVersionArn(): void;
        get sagemakerImageVersionArnInput(): string | undefined;
    }
    interface TensorBoardAppSettingsProperty {
        /**
        * default_resource_spec block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#default_resource_spec AwsSagemakerDomain#default_resource_spec}
        */
        readonly defaultResourceSpec?: DefaultUserSettingsTensorBoardAppSettingsDefaultResourceSpecProperty;
    }
    class TensorBoardAppSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TensorBoardAppSettingsProperty | undefined;
        set internalValue(value: TensorBoardAppSettingsProperty | undefined);
        private _defaultResourceSpec;
        get defaultResourceSpec(): DefaultUserSettingsTensorBoardAppSettingsDefaultResourceSpecPropertyOutputReference;
        putDefaultResourceSpec(value: DefaultUserSettingsTensorBoardAppSettingsDefaultResourceSpecProperty): void;
        resetDefaultResourceSpec(): void;
        get defaultResourceSpecInput(): DefaultUserSettingsTensorBoardAppSettingsDefaultResourceSpecProperty | undefined;
    }
    interface DefaultUserSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#auto_mount_home_efs AwsSagemakerDomain#auto_mount_home_efs}
        */
        readonly autoMountHomeEfs?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#default_landing_uri AwsSagemakerDomain#default_landing_uri}
        */
        readonly defaultLandingUri?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#execution_role AwsSagemakerDomain#execution_role}
        */
        readonly executionRole: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#security_groups AwsSagemakerDomain#security_groups}
        */
        readonly securityGroups?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#studio_web_portal AwsSagemakerDomain#studio_web_portal}
        */
        readonly studioWebPortal?: string;
        /**
        * canvas_app_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#canvas_app_settings AwsSagemakerDomain#canvas_app_settings}
        */
        readonly canvasAppSettings?: CanvasAppSettingsProperty;
        /**
        * code_editor_app_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#code_editor_app_settings AwsSagemakerDomain#code_editor_app_settings}
        */
        readonly codeEditorAppSettings?: CodeEditorAppSettingsProperty;
        /**
        * custom_file_system_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#custom_file_system_config AwsSagemakerDomain#custom_file_system_config}
        */
        readonly customFileSystemConfig?: DefaultUserSettingsCustomFileSystemConfigProperty[] | cdktn.IResolvable;
        /**
        * custom_posix_user_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#custom_posix_user_config AwsSagemakerDomain#custom_posix_user_config}
        */
        readonly customPosixUserConfig?: DefaultUserSettingsCustomPosixUserConfigProperty;
        /**
        * jupyter_lab_app_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#jupyter_lab_app_settings AwsSagemakerDomain#jupyter_lab_app_settings}
        */
        readonly jupyterLabAppSettings?: DefaultUserSettingsJupyterLabAppSettingsProperty;
        /**
        * jupyter_server_app_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#jupyter_server_app_settings AwsSagemakerDomain#jupyter_server_app_settings}
        */
        readonly jupyterServerAppSettings?: DefaultUserSettingsJupyterServerAppSettingsProperty;
        /**
        * kernel_gateway_app_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#kernel_gateway_app_settings AwsSagemakerDomain#kernel_gateway_app_settings}
        */
        readonly kernelGatewayAppSettings?: DefaultUserSettingsKernelGatewayAppSettingsProperty;
        /**
        * r_session_app_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#r_session_app_settings AwsSagemakerDomain#r_session_app_settings}
        */
        readonly rSessionAppSettings?: RSessionAppSettingsProperty;
        /**
        * r_studio_server_pro_app_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#r_studio_server_pro_app_settings AwsSagemakerDomain#r_studio_server_pro_app_settings}
        */
        readonly rStudioServerProAppSettings?: RStudioServerProAppSettingsProperty;
        /**
        * sharing_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#sharing_settings AwsSagemakerDomain#sharing_settings}
        */
        readonly sharingSettings?: SharingSettingsProperty;
        /**
        * space_storage_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#space_storage_settings AwsSagemakerDomain#space_storage_settings}
        */
        readonly spaceStorageSettings?: DefaultUserSettingsSpaceStorageSettingsProperty;
        /**
        * studio_web_portal_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#studio_web_portal_settings AwsSagemakerDomain#studio_web_portal_settings}
        */
        readonly studioWebPortalSettings?: StudioWebPortalSettingsProperty;
        /**
        * tensor_board_app_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#tensor_board_app_settings AwsSagemakerDomain#tensor_board_app_settings}
        */
        readonly tensorBoardAppSettings?: TensorBoardAppSettingsProperty;
    }
    class DefaultUserSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultUserSettingsProperty | undefined;
        set internalValue(value: DefaultUserSettingsProperty | undefined);
        private _autoMountHomeEfs?;
        get autoMountHomeEfs(): string;
        set autoMountHomeEfs(value: string);
        resetAutoMountHomeEfs(): void;
        get autoMountHomeEfsInput(): string | undefined;
        private _defaultLandingUri?;
        get defaultLandingUri(): string;
        set defaultLandingUri(value: string);
        resetDefaultLandingUri(): void;
        get defaultLandingUriInput(): string | undefined;
        private _executionRole?;
        get executionRole(): string;
        set executionRole(value: string);
        get executionRoleInput(): string | undefined;
        private _securityGroups?;
        get securityGroups(): string[];
        set securityGroups(value: string[]);
        resetSecurityGroups(): void;
        get securityGroupsInput(): string[] | undefined;
        private _studioWebPortal?;
        get studioWebPortal(): string;
        set studioWebPortal(value: string);
        resetStudioWebPortal(): void;
        get studioWebPortalInput(): string | undefined;
        private _canvasAppSettings;
        get canvasAppSettings(): CanvasAppSettingsPropertyOutputReference;
        putCanvasAppSettings(value: CanvasAppSettingsProperty): void;
        resetCanvasAppSettings(): void;
        get canvasAppSettingsInput(): CanvasAppSettingsProperty | undefined;
        private _codeEditorAppSettings;
        get codeEditorAppSettings(): CodeEditorAppSettingsPropertyOutputReference;
        putCodeEditorAppSettings(value: CodeEditorAppSettingsProperty): void;
        resetCodeEditorAppSettings(): void;
        get codeEditorAppSettingsInput(): CodeEditorAppSettingsProperty | undefined;
        private _customFileSystemConfig;
        get customFileSystemConfig(): DefaultUserSettingsCustomFileSystemConfigPropertyList;
        putCustomFileSystemConfig(value: DefaultUserSettingsCustomFileSystemConfigProperty[] | cdktn.IResolvable): void;
        resetCustomFileSystemConfig(): void;
        get customFileSystemConfigInput(): cdktn.IResolvable | DefaultUserSettingsCustomFileSystemConfigProperty[] | undefined;
        private _customPosixUserConfig;
        get customPosixUserConfig(): DefaultUserSettingsCustomPosixUserConfigPropertyOutputReference;
        putCustomPosixUserConfig(value: DefaultUserSettingsCustomPosixUserConfigProperty): void;
        resetCustomPosixUserConfig(): void;
        get customPosixUserConfigInput(): DefaultUserSettingsCustomPosixUserConfigProperty | undefined;
        private _jupyterLabAppSettings;
        get jupyterLabAppSettings(): DefaultUserSettingsJupyterLabAppSettingsPropertyOutputReference;
        putJupyterLabAppSettings(value: DefaultUserSettingsJupyterLabAppSettingsProperty): void;
        resetJupyterLabAppSettings(): void;
        get jupyterLabAppSettingsInput(): DefaultUserSettingsJupyterLabAppSettingsProperty | undefined;
        private _jupyterServerAppSettings;
        get jupyterServerAppSettings(): DefaultUserSettingsJupyterServerAppSettingsPropertyOutputReference;
        putJupyterServerAppSettings(value: DefaultUserSettingsJupyterServerAppSettingsProperty): void;
        resetJupyterServerAppSettings(): void;
        get jupyterServerAppSettingsInput(): DefaultUserSettingsJupyterServerAppSettingsProperty | undefined;
        private _kernelGatewayAppSettings;
        get kernelGatewayAppSettings(): DefaultUserSettingsKernelGatewayAppSettingsPropertyOutputReference;
        putKernelGatewayAppSettings(value: DefaultUserSettingsKernelGatewayAppSettingsProperty): void;
        resetKernelGatewayAppSettings(): void;
        get kernelGatewayAppSettingsInput(): DefaultUserSettingsKernelGatewayAppSettingsProperty | undefined;
        private _rSessionAppSettings;
        get rSessionAppSettings(): RSessionAppSettingsPropertyOutputReference;
        putRSessionAppSettings(value: RSessionAppSettingsProperty): void;
        resetRSessionAppSettings(): void;
        get rSessionAppSettingsInput(): RSessionAppSettingsProperty | undefined;
        private _rStudioServerProAppSettings;
        get rStudioServerProAppSettings(): RStudioServerProAppSettingsPropertyOutputReference;
        putRStudioServerProAppSettings(value: RStudioServerProAppSettingsProperty): void;
        resetRStudioServerProAppSettings(): void;
        get rStudioServerProAppSettingsInput(): RStudioServerProAppSettingsProperty | undefined;
        private _sharingSettings;
        get sharingSettings(): SharingSettingsPropertyOutputReference;
        putSharingSettings(value: SharingSettingsProperty): void;
        resetSharingSettings(): void;
        get sharingSettingsInput(): SharingSettingsProperty | undefined;
        private _spaceStorageSettings;
        get spaceStorageSettings(): DefaultUserSettingsSpaceStorageSettingsPropertyOutputReference;
        putSpaceStorageSettings(value: DefaultUserSettingsSpaceStorageSettingsProperty): void;
        resetSpaceStorageSettings(): void;
        get spaceStorageSettingsInput(): DefaultUserSettingsSpaceStorageSettingsProperty | undefined;
        private _studioWebPortalSettings;
        get studioWebPortalSettings(): StudioWebPortalSettingsPropertyOutputReference;
        putStudioWebPortalSettings(value: StudioWebPortalSettingsProperty): void;
        resetStudioWebPortalSettings(): void;
        get studioWebPortalSettingsInput(): StudioWebPortalSettingsProperty | undefined;
        private _tensorBoardAppSettings;
        get tensorBoardAppSettings(): TensorBoardAppSettingsPropertyOutputReference;
        putTensorBoardAppSettings(value: TensorBoardAppSettingsProperty): void;
        resetTensorBoardAppSettings(): void;
        get tensorBoardAppSettingsInput(): TensorBoardAppSettingsProperty | undefined;
    }
    interface DockerSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#enable_docker_access AwsSagemakerDomain#enable_docker_access}
        */
        readonly enableDockerAccess?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#vpc_only_trusted_accounts AwsSagemakerDomain#vpc_only_trusted_accounts}
        */
        readonly vpcOnlyTrustedAccounts?: string[];
    }
    class DockerSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DockerSettingsProperty | undefined;
        set internalValue(value: DockerSettingsProperty | undefined);
        private _enableDockerAccess?;
        get enableDockerAccess(): string;
        set enableDockerAccess(value: string);
        resetEnableDockerAccess(): void;
        get enableDockerAccessInput(): string | undefined;
        private _vpcOnlyTrustedAccounts?;
        get vpcOnlyTrustedAccounts(): string[];
        set vpcOnlyTrustedAccounts(value: string[]);
        resetVpcOnlyTrustedAccounts(): void;
        get vpcOnlyTrustedAccountsInput(): string[] | undefined;
    }
    interface DomainSettingsRStudioServerProDomainSettingsDefaultResourceSpecProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#instance_type AwsSagemakerDomain#instance_type}
        */
        readonly instanceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#lifecycle_config_arn AwsSagemakerDomain#lifecycle_config_arn}
        */
        readonly lifecycleConfigArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#sagemaker_image_arn AwsSagemakerDomain#sagemaker_image_arn}
        */
        readonly sagemakerImageArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#sagemaker_image_version_alias AwsSagemakerDomain#sagemaker_image_version_alias}
        */
        readonly sagemakerImageVersionAlias?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#sagemaker_image_version_arn AwsSagemakerDomain#sagemaker_image_version_arn}
        */
        readonly sagemakerImageVersionArn?: string;
    }
    class DomainSettingsRStudioServerProDomainSettingsDefaultResourceSpecPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DomainSettingsRStudioServerProDomainSettingsDefaultResourceSpecProperty | undefined;
        set internalValue(value: DomainSettingsRStudioServerProDomainSettingsDefaultResourceSpecProperty | undefined);
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        resetInstanceType(): void;
        get instanceTypeInput(): string | undefined;
        private _lifecycleConfigArn?;
        get lifecycleConfigArn(): string;
        set lifecycleConfigArn(value: string);
        resetLifecycleConfigArn(): void;
        get lifecycleConfigArnInput(): string | undefined;
        private _sagemakerImageArn?;
        get sagemakerImageArn(): string;
        set sagemakerImageArn(value: string);
        resetSagemakerImageArn(): void;
        get sagemakerImageArnInput(): string | undefined;
        private _sagemakerImageVersionAlias?;
        get sagemakerImageVersionAlias(): string;
        set sagemakerImageVersionAlias(value: string);
        resetSagemakerImageVersionAlias(): void;
        get sagemakerImageVersionAliasInput(): string | undefined;
        private _sagemakerImageVersionArn?;
        get sagemakerImageVersionArn(): string;
        set sagemakerImageVersionArn(value: string);
        resetSagemakerImageVersionArn(): void;
        get sagemakerImageVersionArnInput(): string | undefined;
    }
    interface RStudioServerProDomainSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#domain_execution_role_arn AwsSagemakerDomain#domain_execution_role_arn}
        */
        readonly domainExecutionRoleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#r_studio_connect_url AwsSagemakerDomain#r_studio_connect_url}
        */
        readonly rStudioConnectUrl?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#r_studio_package_manager_url AwsSagemakerDomain#r_studio_package_manager_url}
        */
        readonly rStudioPackageManagerUrl?: string;
        /**
        * default_resource_spec block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#default_resource_spec AwsSagemakerDomain#default_resource_spec}
        */
        readonly defaultResourceSpec?: DomainSettingsRStudioServerProDomainSettingsDefaultResourceSpecProperty;
    }
    class RStudioServerProDomainSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RStudioServerProDomainSettingsProperty | undefined;
        set internalValue(value: RStudioServerProDomainSettingsProperty | undefined);
        private _domainExecutionRoleArn?;
        get domainExecutionRoleArn(): string;
        set domainExecutionRoleArn(value: string);
        get domainExecutionRoleArnInput(): string | undefined;
        private _rStudioConnectUrl?;
        get rStudioConnectUrl(): string;
        set rStudioConnectUrl(value: string);
        resetRStudioConnectUrl(): void;
        get rStudioConnectUrlInput(): string | undefined;
        private _rStudioPackageManagerUrl?;
        get rStudioPackageManagerUrl(): string;
        set rStudioPackageManagerUrl(value: string);
        resetRStudioPackageManagerUrl(): void;
        get rStudioPackageManagerUrlInput(): string | undefined;
        private _defaultResourceSpec;
        get defaultResourceSpec(): DomainSettingsRStudioServerProDomainSettingsDefaultResourceSpecPropertyOutputReference;
        putDefaultResourceSpec(value: DomainSettingsRStudioServerProDomainSettingsDefaultResourceSpecProperty): void;
        resetDefaultResourceSpec(): void;
        get defaultResourceSpecInput(): DomainSettingsRStudioServerProDomainSettingsDefaultResourceSpecProperty | undefined;
    }
    interface TrustedIdentityPropagationSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#status AwsSagemakerDomain#status}
        */
        readonly status: string;
    }
    class TrustedIdentityPropagationSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TrustedIdentityPropagationSettingsProperty | undefined;
        set internalValue(value: TrustedIdentityPropagationSettingsProperty | undefined);
        private _status?;
        get status(): string;
        set status(value: string);
        get statusInput(): string | undefined;
    }
    interface DomainSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#execution_role_identity_config AwsSagemakerDomain#execution_role_identity_config}
        */
        readonly executionRoleIdentityConfig?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#security_group_ids AwsSagemakerDomain#security_group_ids}
        */
        readonly securityGroupIds?: string[];
        /**
        * docker_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#docker_settings AwsSagemakerDomain#docker_settings}
        */
        readonly dockerSettings?: DockerSettingsProperty;
        /**
        * r_studio_server_pro_domain_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#r_studio_server_pro_domain_settings AwsSagemakerDomain#r_studio_server_pro_domain_settings}
        */
        readonly rStudioServerProDomainSettings?: RStudioServerProDomainSettingsProperty;
        /**
        * trusted_identity_propagation_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#trusted_identity_propagation_settings AwsSagemakerDomain#trusted_identity_propagation_settings}
        */
        readonly trustedIdentityPropagationSettings?: TrustedIdentityPropagationSettingsProperty;
    }
    class DomainSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DomainSettingsProperty | undefined;
        set internalValue(value: DomainSettingsProperty | undefined);
        private _executionRoleIdentityConfig?;
        get executionRoleIdentityConfig(): string;
        set executionRoleIdentityConfig(value: string);
        resetExecutionRoleIdentityConfig(): void;
        get executionRoleIdentityConfigInput(): string | undefined;
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        resetSecurityGroupIds(): void;
        get securityGroupIdsInput(): string[] | undefined;
        private _dockerSettings;
        get dockerSettings(): DockerSettingsPropertyOutputReference;
        putDockerSettings(value: DockerSettingsProperty): void;
        resetDockerSettings(): void;
        get dockerSettingsInput(): DockerSettingsProperty | undefined;
        private _rStudioServerProDomainSettings;
        get rStudioServerProDomainSettings(): RStudioServerProDomainSettingsPropertyOutputReference;
        putRStudioServerProDomainSettings(value: RStudioServerProDomainSettingsProperty): void;
        resetRStudioServerProDomainSettings(): void;
        get rStudioServerProDomainSettingsInput(): RStudioServerProDomainSettingsProperty | undefined;
        private _trustedIdentityPropagationSettings;
        get trustedIdentityPropagationSettings(): TrustedIdentityPropagationSettingsPropertyOutputReference;
        putTrustedIdentityPropagationSettings(value: TrustedIdentityPropagationSettingsProperty): void;
        resetTrustedIdentityPropagationSettings(): void;
        get trustedIdentityPropagationSettingsInput(): TrustedIdentityPropagationSettingsProperty | undefined;
    }
    interface RetentionPolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_domain#home_efs_file_system AwsSagemakerDomain#home_efs_file_system}
        */
        readonly homeEfsFileSystem?: string;
    }
    class RetentionPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RetentionPolicyProperty | undefined;
        set internalValue(value: RetentionPolicyProperty | undefined);
        private _homeEfsFileSystem?;
        get homeEfsFileSystem(): string;
        set homeEfsFileSystem(value: string);
        resetHomeEfsFileSystem(): void;
        get homeEfsFileSystemInput(): string | undefined;
    }
}
