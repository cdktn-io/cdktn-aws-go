import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSagemakerAppImageConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#app_image_config_name AwsSagemakerAppImageConfig#app_image_config_name}
    */
    readonly appImageConfigName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#id AwsSagemakerAppImageConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#region AwsSagemakerAppImageConfig#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#tags AwsSagemakerAppImageConfig#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#tags_all AwsSagemakerAppImageConfig#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * code_editor_app_image_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#code_editor_app_image_config AwsSagemakerAppImageConfig#code_editor_app_image_config}
    */
    readonly codeEditorAppImageConfig?: AwsSagemakerAppImageConfig.CodeEditorAppImageConfigProperty;
    /**
    * jupyter_lab_image_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#jupyter_lab_image_config AwsSagemakerAppImageConfig#jupyter_lab_image_config}
    */
    readonly jupyterLabImageConfig?: AwsSagemakerAppImageConfig.JupyterLabImageConfigProperty;
    /**
    * kernel_gateway_image_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#kernel_gateway_image_config AwsSagemakerAppImageConfig#kernel_gateway_image_config}
    */
    readonly kernelGatewayImageConfig?: AwsSagemakerAppImageConfig.KernelGatewayImageConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config aws_sagemaker_app_image_config}
*/
export declare class AwsSagemakerAppImageConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_sagemaker_app_image_config";
    /**
    * Generates CDKTN code for importing a AwsSagemakerAppImageConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSagemakerAppImageConfig to import
    * @param importFromId The id of the existing AwsSagemakerAppImageConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSagemakerAppImageConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config aws_sagemaker_app_image_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSagemakerAppImageConfigConfig
    */
    constructor(scope: Construct, id: string, config: AwsSagemakerAppImageConfigConfig);
    private _appImageConfigName?;
    get appImageConfigName(): string;
    set appImageConfigName(value: string);
    get appImageConfigNameInput(): string | undefined;
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _codeEditorAppImageConfig;
    get codeEditorAppImageConfig(): AwsSagemakerAppImageConfig.CodeEditorAppImageConfigPropertyOutputReference;
    putCodeEditorAppImageConfig(value: AwsSagemakerAppImageConfig.CodeEditorAppImageConfigProperty): void;
    resetCodeEditorAppImageConfig(): void;
    get codeEditorAppImageConfigInput(): AwsSagemakerAppImageConfig.CodeEditorAppImageConfigProperty | undefined;
    private _jupyterLabImageConfig;
    get jupyterLabImageConfig(): AwsSagemakerAppImageConfig.JupyterLabImageConfigPropertyOutputReference;
    putJupyterLabImageConfig(value: AwsSagemakerAppImageConfig.JupyterLabImageConfigProperty): void;
    resetJupyterLabImageConfig(): void;
    get jupyterLabImageConfigInput(): AwsSagemakerAppImageConfig.JupyterLabImageConfigProperty | undefined;
    private _kernelGatewayImageConfig;
    get kernelGatewayImageConfig(): AwsSagemakerAppImageConfig.KernelGatewayImageConfigPropertyOutputReference;
    putKernelGatewayImageConfig(value: AwsSagemakerAppImageConfig.KernelGatewayImageConfigProperty): void;
    resetKernelGatewayImageConfig(): void;
    get kernelGatewayImageConfigInput(): AwsSagemakerAppImageConfig.KernelGatewayImageConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsSagemakerAppImageConfigCodeEditorAppImageConfigContainerConfigPropertyToTerraform(struct?: AwsSagemakerAppImageConfig.CodeEditorAppImageConfigContainerConfigPropertyOutputReference | AwsSagemakerAppImageConfig.CodeEditorAppImageConfigContainerConfigProperty): any;
export declare function awsSagemakerAppImageConfigCodeEditorAppImageConfigContainerConfigPropertyToHclTerraform(struct?: AwsSagemakerAppImageConfig.CodeEditorAppImageConfigContainerConfigPropertyOutputReference | AwsSagemakerAppImageConfig.CodeEditorAppImageConfigContainerConfigProperty): any;
export declare function awsSagemakerAppImageConfigCodeEditorAppImageConfigFileSystemConfigPropertyToTerraform(struct?: AwsSagemakerAppImageConfig.CodeEditorAppImageConfigFileSystemConfigPropertyOutputReference | AwsSagemakerAppImageConfig.CodeEditorAppImageConfigFileSystemConfigProperty): any;
export declare function awsSagemakerAppImageConfigCodeEditorAppImageConfigFileSystemConfigPropertyToHclTerraform(struct?: AwsSagemakerAppImageConfig.CodeEditorAppImageConfigFileSystemConfigPropertyOutputReference | AwsSagemakerAppImageConfig.CodeEditorAppImageConfigFileSystemConfigProperty): any;
export declare function awsSagemakerAppImageConfigCodeEditorAppImageConfigPropertyToTerraform(struct?: AwsSagemakerAppImageConfig.CodeEditorAppImageConfigPropertyOutputReference | AwsSagemakerAppImageConfig.CodeEditorAppImageConfigProperty): any;
export declare function awsSagemakerAppImageConfigCodeEditorAppImageConfigPropertyToHclTerraform(struct?: AwsSagemakerAppImageConfig.CodeEditorAppImageConfigPropertyOutputReference | AwsSagemakerAppImageConfig.CodeEditorAppImageConfigProperty): any;
export declare function awsSagemakerAppImageConfigJupyterLabImageConfigContainerConfigPropertyToTerraform(struct?: AwsSagemakerAppImageConfig.JupyterLabImageConfigContainerConfigPropertyOutputReference | AwsSagemakerAppImageConfig.JupyterLabImageConfigContainerConfigProperty): any;
export declare function awsSagemakerAppImageConfigJupyterLabImageConfigContainerConfigPropertyToHclTerraform(struct?: AwsSagemakerAppImageConfig.JupyterLabImageConfigContainerConfigPropertyOutputReference | AwsSagemakerAppImageConfig.JupyterLabImageConfigContainerConfigProperty): any;
export declare function awsSagemakerAppImageConfigJupyterLabImageConfigFileSystemConfigPropertyToTerraform(struct?: AwsSagemakerAppImageConfig.JupyterLabImageConfigFileSystemConfigPropertyOutputReference | AwsSagemakerAppImageConfig.JupyterLabImageConfigFileSystemConfigProperty): any;
export declare function awsSagemakerAppImageConfigJupyterLabImageConfigFileSystemConfigPropertyToHclTerraform(struct?: AwsSagemakerAppImageConfig.JupyterLabImageConfigFileSystemConfigPropertyOutputReference | AwsSagemakerAppImageConfig.JupyterLabImageConfigFileSystemConfigProperty): any;
export declare function awsSagemakerAppImageConfigJupyterLabImageConfigPropertyToTerraform(struct?: AwsSagemakerAppImageConfig.JupyterLabImageConfigPropertyOutputReference | AwsSagemakerAppImageConfig.JupyterLabImageConfigProperty): any;
export declare function awsSagemakerAppImageConfigJupyterLabImageConfigPropertyToHclTerraform(struct?: AwsSagemakerAppImageConfig.JupyterLabImageConfigPropertyOutputReference | AwsSagemakerAppImageConfig.JupyterLabImageConfigProperty): any;
export declare function awsSagemakerAppImageConfigKernelGatewayImageConfigFileSystemConfigPropertyToTerraform(struct?: AwsSagemakerAppImageConfig.KernelGatewayImageConfigFileSystemConfigPropertyOutputReference | AwsSagemakerAppImageConfig.KernelGatewayImageConfigFileSystemConfigProperty): any;
export declare function awsSagemakerAppImageConfigKernelGatewayImageConfigFileSystemConfigPropertyToHclTerraform(struct?: AwsSagemakerAppImageConfig.KernelGatewayImageConfigFileSystemConfigPropertyOutputReference | AwsSagemakerAppImageConfig.KernelGatewayImageConfigFileSystemConfigProperty): any;
export declare function awsSagemakerAppImageConfigKernelSpecPropertyToTerraform(struct?: AwsSagemakerAppImageConfig.KernelSpecProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAppImageConfigKernelSpecPropertyToHclTerraform(struct?: AwsSagemakerAppImageConfig.KernelSpecProperty | cdktn.IResolvable): any;
export declare function awsSagemakerAppImageConfigKernelGatewayImageConfigPropertyToTerraform(struct?: AwsSagemakerAppImageConfig.KernelGatewayImageConfigPropertyOutputReference | AwsSagemakerAppImageConfig.KernelGatewayImageConfigProperty): any;
export declare function awsSagemakerAppImageConfigKernelGatewayImageConfigPropertyToHclTerraform(struct?: AwsSagemakerAppImageConfig.KernelGatewayImageConfigPropertyOutputReference | AwsSagemakerAppImageConfig.KernelGatewayImageConfigProperty): any;
export declare namespace AwsSagemakerAppImageConfig {
    interface CodeEditorAppImageConfigContainerConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#container_arguments AwsSagemakerAppImageConfig#container_arguments}
        */
        readonly containerArguments?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#container_entrypoint AwsSagemakerAppImageConfig#container_entrypoint}
        */
        readonly containerEntrypoint?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#container_environment_variables AwsSagemakerAppImageConfig#container_environment_variables}
        */
        readonly containerEnvironmentVariables?: {
            [key: string]: string;
        };
    }
    class CodeEditorAppImageConfigContainerConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CodeEditorAppImageConfigContainerConfigProperty | undefined;
        set internalValue(value: CodeEditorAppImageConfigContainerConfigProperty | undefined);
        private _containerArguments?;
        get containerArguments(): string[];
        set containerArguments(value: string[]);
        resetContainerArguments(): void;
        get containerArgumentsInput(): string[] | undefined;
        private _containerEntrypoint?;
        get containerEntrypoint(): string[];
        set containerEntrypoint(value: string[]);
        resetContainerEntrypoint(): void;
        get containerEntrypointInput(): string[] | undefined;
        private _containerEnvironmentVariables?;
        get containerEnvironmentVariables(): {
            [key: string]: string;
        };
        set containerEnvironmentVariables(value: {
            [key: string]: string;
        });
        resetContainerEnvironmentVariables(): void;
        get containerEnvironmentVariablesInput(): {
            [key: string]: string;
        } | undefined;
    }
    interface CodeEditorAppImageConfigFileSystemConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#default_gid AwsSagemakerAppImageConfig#default_gid}
        */
        readonly defaultGid?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#default_uid AwsSagemakerAppImageConfig#default_uid}
        */
        readonly defaultUid?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#mount_path AwsSagemakerAppImageConfig#mount_path}
        */
        readonly mountPath?: string;
    }
    class CodeEditorAppImageConfigFileSystemConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CodeEditorAppImageConfigFileSystemConfigProperty | undefined;
        set internalValue(value: CodeEditorAppImageConfigFileSystemConfigProperty | undefined);
        private _defaultGid?;
        get defaultGid(): number;
        set defaultGid(value: number);
        resetDefaultGid(): void;
        get defaultGidInput(): number | undefined;
        private _defaultUid?;
        get defaultUid(): number;
        set defaultUid(value: number);
        resetDefaultUid(): void;
        get defaultUidInput(): number | undefined;
        private _mountPath?;
        get mountPath(): string;
        set mountPath(value: string);
        resetMountPath(): void;
        get mountPathInput(): string | undefined;
    }
    interface CodeEditorAppImageConfigProperty {
        /**
        * container_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#container_config AwsSagemakerAppImageConfig#container_config}
        */
        readonly containerConfig?: CodeEditorAppImageConfigContainerConfigProperty;
        /**
        * file_system_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#file_system_config AwsSagemakerAppImageConfig#file_system_config}
        */
        readonly fileSystemConfig?: CodeEditorAppImageConfigFileSystemConfigProperty;
    }
    class CodeEditorAppImageConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CodeEditorAppImageConfigProperty | undefined;
        set internalValue(value: CodeEditorAppImageConfigProperty | undefined);
        private _containerConfig;
        get containerConfig(): CodeEditorAppImageConfigContainerConfigPropertyOutputReference;
        putContainerConfig(value: CodeEditorAppImageConfigContainerConfigProperty): void;
        resetContainerConfig(): void;
        get containerConfigInput(): CodeEditorAppImageConfigContainerConfigProperty | undefined;
        private _fileSystemConfig;
        get fileSystemConfig(): CodeEditorAppImageConfigFileSystemConfigPropertyOutputReference;
        putFileSystemConfig(value: CodeEditorAppImageConfigFileSystemConfigProperty): void;
        resetFileSystemConfig(): void;
        get fileSystemConfigInput(): CodeEditorAppImageConfigFileSystemConfigProperty | undefined;
    }
    interface JupyterLabImageConfigContainerConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#container_arguments AwsSagemakerAppImageConfig#container_arguments}
        */
        readonly containerArguments?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#container_entrypoint AwsSagemakerAppImageConfig#container_entrypoint}
        */
        readonly containerEntrypoint?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#container_environment_variables AwsSagemakerAppImageConfig#container_environment_variables}
        */
        readonly containerEnvironmentVariables?: {
            [key: string]: string;
        };
    }
    class JupyterLabImageConfigContainerConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): JupyterLabImageConfigContainerConfigProperty | undefined;
        set internalValue(value: JupyterLabImageConfigContainerConfigProperty | undefined);
        private _containerArguments?;
        get containerArguments(): string[];
        set containerArguments(value: string[]);
        resetContainerArguments(): void;
        get containerArgumentsInput(): string[] | undefined;
        private _containerEntrypoint?;
        get containerEntrypoint(): string[];
        set containerEntrypoint(value: string[]);
        resetContainerEntrypoint(): void;
        get containerEntrypointInput(): string[] | undefined;
        private _containerEnvironmentVariables?;
        get containerEnvironmentVariables(): {
            [key: string]: string;
        };
        set containerEnvironmentVariables(value: {
            [key: string]: string;
        });
        resetContainerEnvironmentVariables(): void;
        get containerEnvironmentVariablesInput(): {
            [key: string]: string;
        } | undefined;
    }
    interface JupyterLabImageConfigFileSystemConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#default_gid AwsSagemakerAppImageConfig#default_gid}
        */
        readonly defaultGid?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#default_uid AwsSagemakerAppImageConfig#default_uid}
        */
        readonly defaultUid?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#mount_path AwsSagemakerAppImageConfig#mount_path}
        */
        readonly mountPath?: string;
    }
    class JupyterLabImageConfigFileSystemConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): JupyterLabImageConfigFileSystemConfigProperty | undefined;
        set internalValue(value: JupyterLabImageConfigFileSystemConfigProperty | undefined);
        private _defaultGid?;
        get defaultGid(): number;
        set defaultGid(value: number);
        resetDefaultGid(): void;
        get defaultGidInput(): number | undefined;
        private _defaultUid?;
        get defaultUid(): number;
        set defaultUid(value: number);
        resetDefaultUid(): void;
        get defaultUidInput(): number | undefined;
        private _mountPath?;
        get mountPath(): string;
        set mountPath(value: string);
        resetMountPath(): void;
        get mountPathInput(): string | undefined;
    }
    interface JupyterLabImageConfigProperty {
        /**
        * container_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#container_config AwsSagemakerAppImageConfig#container_config}
        */
        readonly containerConfig?: JupyterLabImageConfigContainerConfigProperty;
        /**
        * file_system_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#file_system_config AwsSagemakerAppImageConfig#file_system_config}
        */
        readonly fileSystemConfig?: JupyterLabImageConfigFileSystemConfigProperty;
    }
    class JupyterLabImageConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): JupyterLabImageConfigProperty | undefined;
        set internalValue(value: JupyterLabImageConfigProperty | undefined);
        private _containerConfig;
        get containerConfig(): JupyterLabImageConfigContainerConfigPropertyOutputReference;
        putContainerConfig(value: JupyterLabImageConfigContainerConfigProperty): void;
        resetContainerConfig(): void;
        get containerConfigInput(): JupyterLabImageConfigContainerConfigProperty | undefined;
        private _fileSystemConfig;
        get fileSystemConfig(): JupyterLabImageConfigFileSystemConfigPropertyOutputReference;
        putFileSystemConfig(value: JupyterLabImageConfigFileSystemConfigProperty): void;
        resetFileSystemConfig(): void;
        get fileSystemConfigInput(): JupyterLabImageConfigFileSystemConfigProperty | undefined;
    }
    interface KernelGatewayImageConfigFileSystemConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#default_gid AwsSagemakerAppImageConfig#default_gid}
        */
        readonly defaultGid?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#default_uid AwsSagemakerAppImageConfig#default_uid}
        */
        readonly defaultUid?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#mount_path AwsSagemakerAppImageConfig#mount_path}
        */
        readonly mountPath?: string;
    }
    class KernelGatewayImageConfigFileSystemConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): KernelGatewayImageConfigFileSystemConfigProperty | undefined;
        set internalValue(value: KernelGatewayImageConfigFileSystemConfigProperty | undefined);
        private _defaultGid?;
        get defaultGid(): number;
        set defaultGid(value: number);
        resetDefaultGid(): void;
        get defaultGidInput(): number | undefined;
        private _defaultUid?;
        get defaultUid(): number;
        set defaultUid(value: number);
        resetDefaultUid(): void;
        get defaultUidInput(): number | undefined;
        private _mountPath?;
        get mountPath(): string;
        set mountPath(value: string);
        resetMountPath(): void;
        get mountPathInput(): string | undefined;
    }
    interface KernelSpecProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#display_name AwsSagemakerAppImageConfig#display_name}
        */
        readonly displayName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#name AwsSagemakerAppImageConfig#name}
        */
        readonly name: string;
    }
    class KernelSpecPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KernelSpecProperty | cdktn.IResolvable | undefined;
        set internalValue(value: KernelSpecProperty | cdktn.IResolvable | undefined);
        private _displayName?;
        get displayName(): string;
        set displayName(value: string);
        resetDisplayName(): void;
        get displayNameInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    class KernelSpecPropertyList extends cdktn.ComplexList {
        internalValue?: KernelSpecProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KernelSpecPropertyOutputReference;
    }
    interface KernelGatewayImageConfigProperty {
        /**
        * file_system_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#file_system_config AwsSagemakerAppImageConfig#file_system_config}
        */
        readonly fileSystemConfig?: KernelGatewayImageConfigFileSystemConfigProperty;
        /**
        * kernel_spec block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#kernel_spec AwsSagemakerAppImageConfig#kernel_spec}
        */
        readonly kernelSpec: KernelSpecProperty[] | cdktn.IResolvable;
    }
    class KernelGatewayImageConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): KernelGatewayImageConfigProperty | undefined;
        set internalValue(value: KernelGatewayImageConfigProperty | undefined);
        private _fileSystemConfig;
        get fileSystemConfig(): KernelGatewayImageConfigFileSystemConfigPropertyOutputReference;
        putFileSystemConfig(value: KernelGatewayImageConfigFileSystemConfigProperty): void;
        resetFileSystemConfig(): void;
        get fileSystemConfigInput(): KernelGatewayImageConfigFileSystemConfigProperty | undefined;
        private _kernelSpec;
        get kernelSpec(): KernelSpecPropertyList;
        putKernelSpec(value: KernelSpecProperty[] | cdktn.IResolvable): void;
        get kernelSpecInput(): cdktn.IResolvable | KernelSpecProperty[] | undefined;
    }
}
