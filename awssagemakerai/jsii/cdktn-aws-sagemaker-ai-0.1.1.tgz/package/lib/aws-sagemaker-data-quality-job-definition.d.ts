import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSagemakerDataQualityJobDefinitionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#id AwsSagemakerDataQualityJobDefinition#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#name AwsSagemakerDataQualityJobDefinition#name}
    */
    readonly name?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#region AwsSagemakerDataQualityJobDefinition#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#role_arn AwsSagemakerDataQualityJobDefinition#role_arn}
    */
    readonly roleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#tags AwsSagemakerDataQualityJobDefinition#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#tags_all AwsSagemakerDataQualityJobDefinition#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * data_quality_app_specification block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#data_quality_app_specification AwsSagemakerDataQualityJobDefinition#data_quality_app_specification}
    */
    readonly dataQualityAppSpecification: AwsSagemakerDataQualityJobDefinition.DataQualityAppSpecificationProperty;
    /**
    * data_quality_baseline_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#data_quality_baseline_config AwsSagemakerDataQualityJobDefinition#data_quality_baseline_config}
    */
    readonly dataQualityBaselineConfig?: AwsSagemakerDataQualityJobDefinition.DataQualityBaselineConfigProperty;
    /**
    * data_quality_job_input block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#data_quality_job_input AwsSagemakerDataQualityJobDefinition#data_quality_job_input}
    */
    readonly dataQualityJobInput: AwsSagemakerDataQualityJobDefinition.DataQualityJobInputProperty;
    /**
    * data_quality_job_output_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#data_quality_job_output_config AwsSagemakerDataQualityJobDefinition#data_quality_job_output_config}
    */
    readonly dataQualityJobOutputConfig: AwsSagemakerDataQualityJobDefinition.DataQualityJobOutputConfigProperty;
    /**
    * job_resources block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#job_resources AwsSagemakerDataQualityJobDefinition#job_resources}
    */
    readonly jobResources: AwsSagemakerDataQualityJobDefinition.JobResourcesProperty;
    /**
    * network_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#network_config AwsSagemakerDataQualityJobDefinition#network_config}
    */
    readonly networkConfig?: AwsSagemakerDataQualityJobDefinition.NetworkConfigProperty;
    /**
    * stopping_condition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#stopping_condition AwsSagemakerDataQualityJobDefinition#stopping_condition}
    */
    readonly stoppingCondition?: AwsSagemakerDataQualityJobDefinition.StoppingConditionProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition aws_sagemaker_data_quality_job_definition}
*/
export declare class AwsSagemakerDataQualityJobDefinition extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_sagemaker_data_quality_job_definition";
    /**
    * Generates CDKTN code for importing a AwsSagemakerDataQualityJobDefinition resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSagemakerDataQualityJobDefinition to import
    * @param importFromId The id of the existing AwsSagemakerDataQualityJobDefinition that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSagemakerDataQualityJobDefinition to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition aws_sagemaker_data_quality_job_definition} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSagemakerDataQualityJobDefinitionConfig
    */
    constructor(scope: Construct, id: string, config: AwsSagemakerDataQualityJobDefinitionConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _dataQualityAppSpecification;
    get dataQualityAppSpecification(): AwsSagemakerDataQualityJobDefinition.DataQualityAppSpecificationPropertyOutputReference;
    putDataQualityAppSpecification(value: AwsSagemakerDataQualityJobDefinition.DataQualityAppSpecificationProperty): void;
    get dataQualityAppSpecificationInput(): AwsSagemakerDataQualityJobDefinition.DataQualityAppSpecificationProperty | undefined;
    private _dataQualityBaselineConfig;
    get dataQualityBaselineConfig(): AwsSagemakerDataQualityJobDefinition.DataQualityBaselineConfigPropertyOutputReference;
    putDataQualityBaselineConfig(value: AwsSagemakerDataQualityJobDefinition.DataQualityBaselineConfigProperty): void;
    resetDataQualityBaselineConfig(): void;
    get dataQualityBaselineConfigInput(): AwsSagemakerDataQualityJobDefinition.DataQualityBaselineConfigProperty | undefined;
    private _dataQualityJobInput;
    get dataQualityJobInput(): AwsSagemakerDataQualityJobDefinition.DataQualityJobInputPropertyOutputReference;
    putDataQualityJobInput(value: AwsSagemakerDataQualityJobDefinition.DataQualityJobInputProperty): void;
    get dataQualityJobInputInput(): AwsSagemakerDataQualityJobDefinition.DataQualityJobInputProperty | undefined;
    private _dataQualityJobOutputConfig;
    get dataQualityJobOutputConfig(): AwsSagemakerDataQualityJobDefinition.DataQualityJobOutputConfigPropertyOutputReference;
    putDataQualityJobOutputConfig(value: AwsSagemakerDataQualityJobDefinition.DataQualityJobOutputConfigProperty): void;
    get dataQualityJobOutputConfigInput(): AwsSagemakerDataQualityJobDefinition.DataQualityJobOutputConfigProperty | undefined;
    private _jobResources;
    get jobResources(): AwsSagemakerDataQualityJobDefinition.JobResourcesPropertyOutputReference;
    putJobResources(value: AwsSagemakerDataQualityJobDefinition.JobResourcesProperty): void;
    get jobResourcesInput(): AwsSagemakerDataQualityJobDefinition.JobResourcesProperty | undefined;
    private _networkConfig;
    get networkConfig(): AwsSagemakerDataQualityJobDefinition.NetworkConfigPropertyOutputReference;
    putNetworkConfig(value: AwsSagemakerDataQualityJobDefinition.NetworkConfigProperty): void;
    resetNetworkConfig(): void;
    get networkConfigInput(): AwsSagemakerDataQualityJobDefinition.NetworkConfigProperty | undefined;
    private _stoppingCondition;
    get stoppingCondition(): AwsSagemakerDataQualityJobDefinition.StoppingConditionPropertyOutputReference;
    putStoppingCondition(value: AwsSagemakerDataQualityJobDefinition.StoppingConditionProperty): void;
    resetStoppingCondition(): void;
    get stoppingConditionInput(): AwsSagemakerDataQualityJobDefinition.StoppingConditionProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsSagemakerDataQualityJobDefinitionDataQualityAppSpecificationPropertyToTerraform(struct?: AwsSagemakerDataQualityJobDefinition.DataQualityAppSpecificationPropertyOutputReference | AwsSagemakerDataQualityJobDefinition.DataQualityAppSpecificationProperty): any;
export declare function awsSagemakerDataQualityJobDefinitionDataQualityAppSpecificationPropertyToHclTerraform(struct?: AwsSagemakerDataQualityJobDefinition.DataQualityAppSpecificationPropertyOutputReference | AwsSagemakerDataQualityJobDefinition.DataQualityAppSpecificationProperty): any;
export declare function awsSagemakerDataQualityJobDefinitionConstraintsResourcePropertyToTerraform(struct?: AwsSagemakerDataQualityJobDefinition.ConstraintsResourcePropertyOutputReference | AwsSagemakerDataQualityJobDefinition.ConstraintsResourceProperty): any;
export declare function awsSagemakerDataQualityJobDefinitionConstraintsResourcePropertyToHclTerraform(struct?: AwsSagemakerDataQualityJobDefinition.ConstraintsResourcePropertyOutputReference | AwsSagemakerDataQualityJobDefinition.ConstraintsResourceProperty): any;
export declare function awsSagemakerDataQualityJobDefinitionStatisticsResourcePropertyToTerraform(struct?: AwsSagemakerDataQualityJobDefinition.StatisticsResourcePropertyOutputReference | AwsSagemakerDataQualityJobDefinition.StatisticsResourceProperty): any;
export declare function awsSagemakerDataQualityJobDefinitionStatisticsResourcePropertyToHclTerraform(struct?: AwsSagemakerDataQualityJobDefinition.StatisticsResourcePropertyOutputReference | AwsSagemakerDataQualityJobDefinition.StatisticsResourceProperty): any;
export declare function awsSagemakerDataQualityJobDefinitionDataQualityBaselineConfigPropertyToTerraform(struct?: AwsSagemakerDataQualityJobDefinition.DataQualityBaselineConfigPropertyOutputReference | AwsSagemakerDataQualityJobDefinition.DataQualityBaselineConfigProperty): any;
export declare function awsSagemakerDataQualityJobDefinitionDataQualityBaselineConfigPropertyToHclTerraform(struct?: AwsSagemakerDataQualityJobDefinition.DataQualityBaselineConfigPropertyOutputReference | AwsSagemakerDataQualityJobDefinition.DataQualityBaselineConfigProperty): any;
export declare function awsSagemakerDataQualityJobDefinitionCsvPropertyToTerraform(struct?: AwsSagemakerDataQualityJobDefinition.CsvPropertyOutputReference | AwsSagemakerDataQualityJobDefinition.CsvProperty): any;
export declare function awsSagemakerDataQualityJobDefinitionCsvPropertyToHclTerraform(struct?: AwsSagemakerDataQualityJobDefinition.CsvPropertyOutputReference | AwsSagemakerDataQualityJobDefinition.CsvProperty): any;
export declare function awsSagemakerDataQualityJobDefinitionJsonPropertyToTerraform(struct?: AwsSagemakerDataQualityJobDefinition.JsonPropertyOutputReference | AwsSagemakerDataQualityJobDefinition.JsonProperty): any;
export declare function awsSagemakerDataQualityJobDefinitionJsonPropertyToHclTerraform(struct?: AwsSagemakerDataQualityJobDefinition.JsonPropertyOutputReference | AwsSagemakerDataQualityJobDefinition.JsonProperty): any;
export declare function awsSagemakerDataQualityJobDefinitionDatasetFormatPropertyToTerraform(struct?: AwsSagemakerDataQualityJobDefinition.DatasetFormatPropertyOutputReference | AwsSagemakerDataQualityJobDefinition.DatasetFormatProperty): any;
export declare function awsSagemakerDataQualityJobDefinitionDatasetFormatPropertyToHclTerraform(struct?: AwsSagemakerDataQualityJobDefinition.DatasetFormatPropertyOutputReference | AwsSagemakerDataQualityJobDefinition.DatasetFormatProperty): any;
export declare function awsSagemakerDataQualityJobDefinitionBatchTransformInputPropertyToTerraform(struct?: AwsSagemakerDataQualityJobDefinition.BatchTransformInputPropertyOutputReference | AwsSagemakerDataQualityJobDefinition.BatchTransformInputProperty): any;
export declare function awsSagemakerDataQualityJobDefinitionBatchTransformInputPropertyToHclTerraform(struct?: AwsSagemakerDataQualityJobDefinition.BatchTransformInputPropertyOutputReference | AwsSagemakerDataQualityJobDefinition.BatchTransformInputProperty): any;
export declare function awsSagemakerDataQualityJobDefinitionEndpointInputPropertyToTerraform(struct?: AwsSagemakerDataQualityJobDefinition.EndpointInputPropertyOutputReference | AwsSagemakerDataQualityJobDefinition.EndpointInputProperty): any;
export declare function awsSagemakerDataQualityJobDefinitionEndpointInputPropertyToHclTerraform(struct?: AwsSagemakerDataQualityJobDefinition.EndpointInputPropertyOutputReference | AwsSagemakerDataQualityJobDefinition.EndpointInputProperty): any;
export declare function awsSagemakerDataQualityJobDefinitionDataQualityJobInputPropertyToTerraform(struct?: AwsSagemakerDataQualityJobDefinition.DataQualityJobInputPropertyOutputReference | AwsSagemakerDataQualityJobDefinition.DataQualityJobInputProperty): any;
export declare function awsSagemakerDataQualityJobDefinitionDataQualityJobInputPropertyToHclTerraform(struct?: AwsSagemakerDataQualityJobDefinition.DataQualityJobInputPropertyOutputReference | AwsSagemakerDataQualityJobDefinition.DataQualityJobInputProperty): any;
export declare function awsSagemakerDataQualityJobDefinitionS3OutputPropertyToTerraform(struct?: AwsSagemakerDataQualityJobDefinition.S3OutputPropertyOutputReference | AwsSagemakerDataQualityJobDefinition.S3OutputProperty): any;
export declare function awsSagemakerDataQualityJobDefinitionS3OutputPropertyToHclTerraform(struct?: AwsSagemakerDataQualityJobDefinition.S3OutputPropertyOutputReference | AwsSagemakerDataQualityJobDefinition.S3OutputProperty): any;
export declare function awsSagemakerDataQualityJobDefinitionMonitoringOutputsPropertyToTerraform(struct?: AwsSagemakerDataQualityJobDefinition.MonitoringOutputsPropertyOutputReference | AwsSagemakerDataQualityJobDefinition.MonitoringOutputsProperty): any;
export declare function awsSagemakerDataQualityJobDefinitionMonitoringOutputsPropertyToHclTerraform(struct?: AwsSagemakerDataQualityJobDefinition.MonitoringOutputsPropertyOutputReference | AwsSagemakerDataQualityJobDefinition.MonitoringOutputsProperty): any;
export declare function awsSagemakerDataQualityJobDefinitionDataQualityJobOutputConfigPropertyToTerraform(struct?: AwsSagemakerDataQualityJobDefinition.DataQualityJobOutputConfigPropertyOutputReference | AwsSagemakerDataQualityJobDefinition.DataQualityJobOutputConfigProperty): any;
export declare function awsSagemakerDataQualityJobDefinitionDataQualityJobOutputConfigPropertyToHclTerraform(struct?: AwsSagemakerDataQualityJobDefinition.DataQualityJobOutputConfigPropertyOutputReference | AwsSagemakerDataQualityJobDefinition.DataQualityJobOutputConfigProperty): any;
export declare function awsSagemakerDataQualityJobDefinitionClusterConfigPropertyToTerraform(struct?: AwsSagemakerDataQualityJobDefinition.ClusterConfigPropertyOutputReference | AwsSagemakerDataQualityJobDefinition.ClusterConfigProperty): any;
export declare function awsSagemakerDataQualityJobDefinitionClusterConfigPropertyToHclTerraform(struct?: AwsSagemakerDataQualityJobDefinition.ClusterConfigPropertyOutputReference | AwsSagemakerDataQualityJobDefinition.ClusterConfigProperty): any;
export declare function awsSagemakerDataQualityJobDefinitionJobResourcesPropertyToTerraform(struct?: AwsSagemakerDataQualityJobDefinition.JobResourcesPropertyOutputReference | AwsSagemakerDataQualityJobDefinition.JobResourcesProperty): any;
export declare function awsSagemakerDataQualityJobDefinitionJobResourcesPropertyToHclTerraform(struct?: AwsSagemakerDataQualityJobDefinition.JobResourcesPropertyOutputReference | AwsSagemakerDataQualityJobDefinition.JobResourcesProperty): any;
export declare function awsSagemakerDataQualityJobDefinitionVpcConfigPropertyToTerraform(struct?: AwsSagemakerDataQualityJobDefinition.VpcConfigPropertyOutputReference | AwsSagemakerDataQualityJobDefinition.VpcConfigProperty): any;
export declare function awsSagemakerDataQualityJobDefinitionVpcConfigPropertyToHclTerraform(struct?: AwsSagemakerDataQualityJobDefinition.VpcConfigPropertyOutputReference | AwsSagemakerDataQualityJobDefinition.VpcConfigProperty): any;
export declare function awsSagemakerDataQualityJobDefinitionNetworkConfigPropertyToTerraform(struct?: AwsSagemakerDataQualityJobDefinition.NetworkConfigPropertyOutputReference | AwsSagemakerDataQualityJobDefinition.NetworkConfigProperty): any;
export declare function awsSagemakerDataQualityJobDefinitionNetworkConfigPropertyToHclTerraform(struct?: AwsSagemakerDataQualityJobDefinition.NetworkConfigPropertyOutputReference | AwsSagemakerDataQualityJobDefinition.NetworkConfigProperty): any;
export declare function awsSagemakerDataQualityJobDefinitionStoppingConditionPropertyToTerraform(struct?: AwsSagemakerDataQualityJobDefinition.StoppingConditionPropertyOutputReference | AwsSagemakerDataQualityJobDefinition.StoppingConditionProperty): any;
export declare function awsSagemakerDataQualityJobDefinitionStoppingConditionPropertyToHclTerraform(struct?: AwsSagemakerDataQualityJobDefinition.StoppingConditionPropertyOutputReference | AwsSagemakerDataQualityJobDefinition.StoppingConditionProperty): any;
export declare namespace AwsSagemakerDataQualityJobDefinition {
    interface DataQualityAppSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#environment AwsSagemakerDataQualityJobDefinition#environment}
        */
        readonly environment?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#image_uri AwsSagemakerDataQualityJobDefinition#image_uri}
        */
        readonly imageUri: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#post_analytics_processor_source_uri AwsSagemakerDataQualityJobDefinition#post_analytics_processor_source_uri}
        */
        readonly postAnalyticsProcessorSourceUri?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#record_preprocessor_source_uri AwsSagemakerDataQualityJobDefinition#record_preprocessor_source_uri}
        */
        readonly recordPreprocessorSourceUri?: string;
    }
    class DataQualityAppSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DataQualityAppSpecificationProperty | undefined;
        set internalValue(value: DataQualityAppSpecificationProperty | undefined);
        private _environment?;
        get environment(): {
            [key: string]: string;
        };
        set environment(value: {
            [key: string]: string;
        });
        resetEnvironment(): void;
        get environmentInput(): {
            [key: string]: string;
        } | undefined;
        private _imageUri?;
        get imageUri(): string;
        set imageUri(value: string);
        get imageUriInput(): string | undefined;
        private _postAnalyticsProcessorSourceUri?;
        get postAnalyticsProcessorSourceUri(): string;
        set postAnalyticsProcessorSourceUri(value: string);
        resetPostAnalyticsProcessorSourceUri(): void;
        get postAnalyticsProcessorSourceUriInput(): string | undefined;
        private _recordPreprocessorSourceUri?;
        get recordPreprocessorSourceUri(): string;
        set recordPreprocessorSourceUri(value: string);
        resetRecordPreprocessorSourceUri(): void;
        get recordPreprocessorSourceUriInput(): string | undefined;
    }
    interface ConstraintsResourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#s3_uri AwsSagemakerDataQualityJobDefinition#s3_uri}
        */
        readonly s3Uri?: string;
    }
    class ConstraintsResourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConstraintsResourceProperty | undefined;
        set internalValue(value: ConstraintsResourceProperty | undefined);
        private _s3Uri?;
        get s3Uri(): string;
        set s3Uri(value: string);
        resetS3Uri(): void;
        get s3UriInput(): string | undefined;
    }
    interface StatisticsResourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#s3_uri AwsSagemakerDataQualityJobDefinition#s3_uri}
        */
        readonly s3Uri?: string;
    }
    class StatisticsResourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StatisticsResourceProperty | undefined;
        set internalValue(value: StatisticsResourceProperty | undefined);
        private _s3Uri?;
        get s3Uri(): string;
        set s3Uri(value: string);
        resetS3Uri(): void;
        get s3UriInput(): string | undefined;
    }
    interface DataQualityBaselineConfigProperty {
        /**
        * constraints_resource block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#constraints_resource AwsSagemakerDataQualityJobDefinition#constraints_resource}
        */
        readonly constraintsResource?: ConstraintsResourceProperty;
        /**
        * statistics_resource block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#statistics_resource AwsSagemakerDataQualityJobDefinition#statistics_resource}
        */
        readonly statisticsResource?: StatisticsResourceProperty;
    }
    class DataQualityBaselineConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DataQualityBaselineConfigProperty | undefined;
        set internalValue(value: DataQualityBaselineConfigProperty | undefined);
        private _constraintsResource;
        get constraintsResource(): ConstraintsResourcePropertyOutputReference;
        putConstraintsResource(value: ConstraintsResourceProperty): void;
        resetConstraintsResource(): void;
        get constraintsResourceInput(): ConstraintsResourceProperty | undefined;
        private _statisticsResource;
        get statisticsResource(): StatisticsResourcePropertyOutputReference;
        putStatisticsResource(value: StatisticsResourceProperty): void;
        resetStatisticsResource(): void;
        get statisticsResourceInput(): StatisticsResourceProperty | undefined;
    }
    interface CsvProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#header AwsSagemakerDataQualityJobDefinition#header}
        */
        readonly header?: boolean | cdktn.IResolvable;
    }
    class CsvPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CsvProperty | undefined;
        set internalValue(value: CsvProperty | undefined);
        private _header?;
        get header(): boolean | cdktn.IResolvable;
        set header(value: boolean | cdktn.IResolvable);
        resetHeader(): void;
        get headerInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface JsonProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#line AwsSagemakerDataQualityJobDefinition#line}
        */
        readonly line?: boolean | cdktn.IResolvable;
    }
    class JsonPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): JsonProperty | undefined;
        set internalValue(value: JsonProperty | undefined);
        private _line?;
        get line(): boolean | cdktn.IResolvable;
        set line(value: boolean | cdktn.IResolvable);
        resetLine(): void;
        get lineInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface DatasetFormatProperty {
        /**
        * csv block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#csv AwsSagemakerDataQualityJobDefinition#csv}
        */
        readonly csv?: CsvProperty;
        /**
        * json block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#json AwsSagemakerDataQualityJobDefinition#json}
        */
        readonly json?: JsonProperty;
    }
    class DatasetFormatPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DatasetFormatProperty | undefined;
        set internalValue(value: DatasetFormatProperty | undefined);
        private _csv;
        get csv(): CsvPropertyOutputReference;
        putCsv(value: CsvProperty): void;
        resetCsv(): void;
        get csvInput(): CsvProperty | undefined;
        private _json;
        get json(): JsonPropertyOutputReference;
        putJson(value: JsonProperty): void;
        resetJson(): void;
        get jsonInput(): JsonProperty | undefined;
    }
    interface BatchTransformInputProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#data_captured_destination_s3_uri AwsSagemakerDataQualityJobDefinition#data_captured_destination_s3_uri}
        */
        readonly dataCapturedDestinationS3Uri: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#local_path AwsSagemakerDataQualityJobDefinition#local_path}
        */
        readonly localPath?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#s3_data_distribution_type AwsSagemakerDataQualityJobDefinition#s3_data_distribution_type}
        */
        readonly s3DataDistributionType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#s3_input_mode AwsSagemakerDataQualityJobDefinition#s3_input_mode}
        */
        readonly s3InputMode?: string;
        /**
        * dataset_format block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#dataset_format AwsSagemakerDataQualityJobDefinition#dataset_format}
        */
        readonly datasetFormat: DatasetFormatProperty;
    }
    class BatchTransformInputPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BatchTransformInputProperty | undefined;
        set internalValue(value: BatchTransformInputProperty | undefined);
        private _dataCapturedDestinationS3Uri?;
        get dataCapturedDestinationS3Uri(): string;
        set dataCapturedDestinationS3Uri(value: string);
        get dataCapturedDestinationS3UriInput(): string | undefined;
        private _localPath?;
        get localPath(): string;
        set localPath(value: string);
        resetLocalPath(): void;
        get localPathInput(): string | undefined;
        private _s3DataDistributionType?;
        get s3DataDistributionType(): string;
        set s3DataDistributionType(value: string);
        resetS3DataDistributionType(): void;
        get s3DataDistributionTypeInput(): string | undefined;
        private _s3InputMode?;
        get s3InputMode(): string;
        set s3InputMode(value: string);
        resetS3InputMode(): void;
        get s3InputModeInput(): string | undefined;
        private _datasetFormat;
        get datasetFormat(): DatasetFormatPropertyOutputReference;
        putDatasetFormat(value: DatasetFormatProperty): void;
        get datasetFormatInput(): DatasetFormatProperty | undefined;
    }
    interface EndpointInputProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#endpoint_name AwsSagemakerDataQualityJobDefinition#endpoint_name}
        */
        readonly endpointName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#local_path AwsSagemakerDataQualityJobDefinition#local_path}
        */
        readonly localPath?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#s3_data_distribution_type AwsSagemakerDataQualityJobDefinition#s3_data_distribution_type}
        */
        readonly s3DataDistributionType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#s3_input_mode AwsSagemakerDataQualityJobDefinition#s3_input_mode}
        */
        readonly s3InputMode?: string;
    }
    class EndpointInputPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EndpointInputProperty | undefined;
        set internalValue(value: EndpointInputProperty | undefined);
        private _endpointName?;
        get endpointName(): string;
        set endpointName(value: string);
        get endpointNameInput(): string | undefined;
        private _localPath?;
        get localPath(): string;
        set localPath(value: string);
        resetLocalPath(): void;
        get localPathInput(): string | undefined;
        private _s3DataDistributionType?;
        get s3DataDistributionType(): string;
        set s3DataDistributionType(value: string);
        resetS3DataDistributionType(): void;
        get s3DataDistributionTypeInput(): string | undefined;
        private _s3InputMode?;
        get s3InputMode(): string;
        set s3InputMode(value: string);
        resetS3InputMode(): void;
        get s3InputModeInput(): string | undefined;
    }
    interface DataQualityJobInputProperty {
        /**
        * batch_transform_input block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#batch_transform_input AwsSagemakerDataQualityJobDefinition#batch_transform_input}
        */
        readonly batchTransformInput?: BatchTransformInputProperty;
        /**
        * endpoint_input block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#endpoint_input AwsSagemakerDataQualityJobDefinition#endpoint_input}
        */
        readonly endpointInput?: EndpointInputProperty;
    }
    class DataQualityJobInputPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DataQualityJobInputProperty | undefined;
        set internalValue(value: DataQualityJobInputProperty | undefined);
        private _batchTransformInput;
        get batchTransformInput(): BatchTransformInputPropertyOutputReference;
        putBatchTransformInput(value: BatchTransformInputProperty): void;
        resetBatchTransformInput(): void;
        get batchTransformInputInput(): BatchTransformInputProperty | undefined;
        private _endpointInput;
        get endpointInput(): EndpointInputPropertyOutputReference;
        putEndpointInput(value: EndpointInputProperty): void;
        resetEndpointInput(): void;
        get endpointInputInput(): EndpointInputProperty | undefined;
    }
    interface S3OutputProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#local_path AwsSagemakerDataQualityJobDefinition#local_path}
        */
        readonly localPath?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#s3_upload_mode AwsSagemakerDataQualityJobDefinition#s3_upload_mode}
        */
        readonly s3UploadMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#s3_uri AwsSagemakerDataQualityJobDefinition#s3_uri}
        */
        readonly s3Uri: string;
    }
    class S3OutputPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3OutputProperty | undefined;
        set internalValue(value: S3OutputProperty | undefined);
        private _localPath?;
        get localPath(): string;
        set localPath(value: string);
        resetLocalPath(): void;
        get localPathInput(): string | undefined;
        private _s3UploadMode?;
        get s3UploadMode(): string;
        set s3UploadMode(value: string);
        resetS3UploadMode(): void;
        get s3UploadModeInput(): string | undefined;
        private _s3Uri?;
        get s3Uri(): string;
        set s3Uri(value: string);
        get s3UriInput(): string | undefined;
    }
    interface MonitoringOutputsProperty {
        /**
        * s3_output block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#s3_output AwsSagemakerDataQualityJobDefinition#s3_output}
        */
        readonly s3Output: S3OutputProperty;
    }
    class MonitoringOutputsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MonitoringOutputsProperty | undefined;
        set internalValue(value: MonitoringOutputsProperty | undefined);
        private _s3Output;
        get s3Output(): S3OutputPropertyOutputReference;
        putS3Output(value: S3OutputProperty): void;
        get s3OutputInput(): S3OutputProperty | undefined;
    }
    interface DataQualityJobOutputConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#kms_key_id AwsSagemakerDataQualityJobDefinition#kms_key_id}
        */
        readonly kmsKeyId?: string;
        /**
        * monitoring_outputs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#monitoring_outputs AwsSagemakerDataQualityJobDefinition#monitoring_outputs}
        */
        readonly monitoringOutputs: MonitoringOutputsProperty;
    }
    class DataQualityJobOutputConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DataQualityJobOutputConfigProperty | undefined;
        set internalValue(value: DataQualityJobOutputConfigProperty | undefined);
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        resetKmsKeyId(): void;
        get kmsKeyIdInput(): string | undefined;
        private _monitoringOutputs;
        get monitoringOutputs(): MonitoringOutputsPropertyOutputReference;
        putMonitoringOutputs(value: MonitoringOutputsProperty): void;
        get monitoringOutputsInput(): MonitoringOutputsProperty | undefined;
    }
    interface ClusterConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#instance_count AwsSagemakerDataQualityJobDefinition#instance_count}
        */
        readonly instanceCount: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#instance_type AwsSagemakerDataQualityJobDefinition#instance_type}
        */
        readonly instanceType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#volume_kms_key_id AwsSagemakerDataQualityJobDefinition#volume_kms_key_id}
        */
        readonly volumeKmsKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#volume_size_in_gb AwsSagemakerDataQualityJobDefinition#volume_size_in_gb}
        */
        readonly volumeSizeInGb: number;
    }
    class ClusterConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ClusterConfigProperty | undefined;
        set internalValue(value: ClusterConfigProperty | undefined);
        private _instanceCount?;
        get instanceCount(): number;
        set instanceCount(value: number);
        get instanceCountInput(): number | undefined;
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        get instanceTypeInput(): string | undefined;
        private _volumeKmsKeyId?;
        get volumeKmsKeyId(): string;
        set volumeKmsKeyId(value: string);
        resetVolumeKmsKeyId(): void;
        get volumeKmsKeyIdInput(): string | undefined;
        private _volumeSizeInGb?;
        get volumeSizeInGb(): number;
        set volumeSizeInGb(value: number);
        get volumeSizeInGbInput(): number | undefined;
    }
    interface JobResourcesProperty {
        /**
        * cluster_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#cluster_config AwsSagemakerDataQualityJobDefinition#cluster_config}
        */
        readonly clusterConfig: ClusterConfigProperty;
    }
    class JobResourcesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): JobResourcesProperty | undefined;
        set internalValue(value: JobResourcesProperty | undefined);
        private _clusterConfig;
        get clusterConfig(): ClusterConfigPropertyOutputReference;
        putClusterConfig(value: ClusterConfigProperty): void;
        get clusterConfigInput(): ClusterConfigProperty | undefined;
    }
    interface VpcConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#security_group_ids AwsSagemakerDataQualityJobDefinition#security_group_ids}
        */
        readonly securityGroupIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#subnets AwsSagemakerDataQualityJobDefinition#subnets}
        */
        readonly subnets: string[];
    }
    class VpcConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VpcConfigProperty | undefined;
        set internalValue(value: VpcConfigProperty | undefined);
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        get securityGroupIdsInput(): string[] | undefined;
        private _subnets?;
        get subnets(): string[];
        set subnets(value: string[]);
        get subnetsInput(): string[] | undefined;
    }
    interface NetworkConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#enable_inter_container_traffic_encryption AwsSagemakerDataQualityJobDefinition#enable_inter_container_traffic_encryption}
        */
        readonly enableInterContainerTrafficEncryption?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#enable_network_isolation AwsSagemakerDataQualityJobDefinition#enable_network_isolation}
        */
        readonly enableNetworkIsolation?: boolean | cdktn.IResolvable;
        /**
        * vpc_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#vpc_config AwsSagemakerDataQualityJobDefinition#vpc_config}
        */
        readonly vpcConfig?: VpcConfigProperty;
    }
    class NetworkConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NetworkConfigProperty | undefined;
        set internalValue(value: NetworkConfigProperty | undefined);
        private _enableInterContainerTrafficEncryption?;
        get enableInterContainerTrafficEncryption(): boolean | cdktn.IResolvable;
        set enableInterContainerTrafficEncryption(value: boolean | cdktn.IResolvable);
        resetEnableInterContainerTrafficEncryption(): void;
        get enableInterContainerTrafficEncryptionInput(): boolean | cdktn.IResolvable | undefined;
        private _enableNetworkIsolation?;
        get enableNetworkIsolation(): boolean | cdktn.IResolvable;
        set enableNetworkIsolation(value: boolean | cdktn.IResolvable);
        resetEnableNetworkIsolation(): void;
        get enableNetworkIsolationInput(): boolean | cdktn.IResolvable | undefined;
        private _vpcConfig;
        get vpcConfig(): VpcConfigPropertyOutputReference;
        putVpcConfig(value: VpcConfigProperty): void;
        resetVpcConfig(): void;
        get vpcConfigInput(): VpcConfigProperty | undefined;
    }
    interface StoppingConditionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_data_quality_job_definition#max_runtime_in_seconds AwsSagemakerDataQualityJobDefinition#max_runtime_in_seconds}
        */
        readonly maxRuntimeInSeconds?: number;
    }
    class StoppingConditionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StoppingConditionProperty | undefined;
        set internalValue(value: StoppingConditionProperty | undefined);
        private _maxRuntimeInSeconds?;
        get maxRuntimeInSeconds(): number;
        set maxRuntimeInSeconds(value: number);
        resetMaxRuntimeInSeconds(): void;
        get maxRuntimeInSecondsInput(): number | undefined;
    }
}
