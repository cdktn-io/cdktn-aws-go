import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSagemakerFeatureGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_feature_group#description AwsSagemakerFeatureGroup#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_feature_group#event_time_feature_name AwsSagemakerFeatureGroup#event_time_feature_name}
    */
    readonly eventTimeFeatureName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_feature_group#feature_group_name AwsSagemakerFeatureGroup#feature_group_name}
    */
    readonly featureGroupName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_feature_group#id AwsSagemakerFeatureGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_feature_group#record_identifier_feature_name AwsSagemakerFeatureGroup#record_identifier_feature_name}
    */
    readonly recordIdentifierFeatureName: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_feature_group#region AwsSagemakerFeatureGroup#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_feature_group#role_arn AwsSagemakerFeatureGroup#role_arn}
    */
    readonly roleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_feature_group#tags AwsSagemakerFeatureGroup#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_feature_group#tags_all AwsSagemakerFeatureGroup#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * feature_definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_feature_group#feature_definition AwsSagemakerFeatureGroup#feature_definition}
    */
    readonly featureDefinition: AwsSagemakerFeatureGroup.FeatureDefinitionProperty[] | cdktn.IResolvable;
    /**
    * offline_store_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_feature_group#offline_store_config AwsSagemakerFeatureGroup#offline_store_config}
    */
    readonly offlineStoreConfig?: AwsSagemakerFeatureGroup.OfflineStoreConfigProperty;
    /**
    * online_store_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_feature_group#online_store_config AwsSagemakerFeatureGroup#online_store_config}
    */
    readonly onlineStoreConfig?: AwsSagemakerFeatureGroup.OnlineStoreConfigProperty;
    /**
    * throughput_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_feature_group#throughput_config AwsSagemakerFeatureGroup#throughput_config}
    */
    readonly throughputConfig?: AwsSagemakerFeatureGroup.ThroughputConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_feature_group aws_sagemaker_feature_group}
*/
export declare class AwsSagemakerFeatureGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_sagemaker_feature_group";
    /**
    * Generates CDKTN code for importing a AwsSagemakerFeatureGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSagemakerFeatureGroup to import
    * @param importFromId The id of the existing AwsSagemakerFeatureGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_feature_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSagemakerFeatureGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_feature_group aws_sagemaker_feature_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSagemakerFeatureGroupConfig
    */
    constructor(scope: Construct, id: string, config: AwsSagemakerFeatureGroupConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _eventTimeFeatureName?;
    get eventTimeFeatureName(): string;
    set eventTimeFeatureName(value: string);
    get eventTimeFeatureNameInput(): string | undefined;
    private _featureGroupName?;
    get featureGroupName(): string;
    set featureGroupName(value: string);
    get featureGroupNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _recordIdentifierFeatureName?;
    get recordIdentifierFeatureName(): string;
    set recordIdentifierFeatureName(value: string);
    get recordIdentifierFeatureNameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _featureDefinition;
    get featureDefinition(): AwsSagemakerFeatureGroup.FeatureDefinitionPropertyList;
    putFeatureDefinition(value: AwsSagemakerFeatureGroup.FeatureDefinitionProperty[] | cdktn.IResolvable): void;
    get featureDefinitionInput(): cdktn.IResolvable | AwsSagemakerFeatureGroup.FeatureDefinitionProperty[] | undefined;
    private _offlineStoreConfig;
    get offlineStoreConfig(): AwsSagemakerFeatureGroup.OfflineStoreConfigPropertyOutputReference;
    putOfflineStoreConfig(value: AwsSagemakerFeatureGroup.OfflineStoreConfigProperty): void;
    resetOfflineStoreConfig(): void;
    get offlineStoreConfigInput(): AwsSagemakerFeatureGroup.OfflineStoreConfigProperty | undefined;
    private _onlineStoreConfig;
    get onlineStoreConfig(): AwsSagemakerFeatureGroup.OnlineStoreConfigPropertyOutputReference;
    putOnlineStoreConfig(value: AwsSagemakerFeatureGroup.OnlineStoreConfigProperty): void;
    resetOnlineStoreConfig(): void;
    get onlineStoreConfigInput(): AwsSagemakerFeatureGroup.OnlineStoreConfigProperty | undefined;
    private _throughputConfig;
    get throughputConfig(): AwsSagemakerFeatureGroup.ThroughputConfigPropertyOutputReference;
    putThroughputConfig(value: AwsSagemakerFeatureGroup.ThroughputConfigProperty): void;
    resetThroughputConfig(): void;
    get throughputConfigInput(): AwsSagemakerFeatureGroup.ThroughputConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsSagemakerFeatureGroupVectorConfigPropertyToTerraform(struct?: AwsSagemakerFeatureGroup.VectorConfigPropertyOutputReference | AwsSagemakerFeatureGroup.VectorConfigProperty): any;
export declare function awsSagemakerFeatureGroupVectorConfigPropertyToHclTerraform(struct?: AwsSagemakerFeatureGroup.VectorConfigPropertyOutputReference | AwsSagemakerFeatureGroup.VectorConfigProperty): any;
export declare function awsSagemakerFeatureGroupCollectionConfigPropertyToTerraform(struct?: AwsSagemakerFeatureGroup.CollectionConfigPropertyOutputReference | AwsSagemakerFeatureGroup.CollectionConfigProperty): any;
export declare function awsSagemakerFeatureGroupCollectionConfigPropertyToHclTerraform(struct?: AwsSagemakerFeatureGroup.CollectionConfigPropertyOutputReference | AwsSagemakerFeatureGroup.CollectionConfigProperty): any;
export declare function awsSagemakerFeatureGroupFeatureDefinitionPropertyToTerraform(struct?: AwsSagemakerFeatureGroup.FeatureDefinitionProperty | cdktn.IResolvable): any;
export declare function awsSagemakerFeatureGroupFeatureDefinitionPropertyToHclTerraform(struct?: AwsSagemakerFeatureGroup.FeatureDefinitionProperty | cdktn.IResolvable): any;
export declare function awsSagemakerFeatureGroupDataCatalogConfigPropertyToTerraform(struct?: AwsSagemakerFeatureGroup.DataCatalogConfigPropertyOutputReference | AwsSagemakerFeatureGroup.DataCatalogConfigProperty): any;
export declare function awsSagemakerFeatureGroupDataCatalogConfigPropertyToHclTerraform(struct?: AwsSagemakerFeatureGroup.DataCatalogConfigPropertyOutputReference | AwsSagemakerFeatureGroup.DataCatalogConfigProperty): any;
export declare function awsSagemakerFeatureGroupS3StorageConfigPropertyToTerraform(struct?: AwsSagemakerFeatureGroup.S3StorageConfigPropertyOutputReference | AwsSagemakerFeatureGroup.S3StorageConfigProperty): any;
export declare function awsSagemakerFeatureGroupS3StorageConfigPropertyToHclTerraform(struct?: AwsSagemakerFeatureGroup.S3StorageConfigPropertyOutputReference | AwsSagemakerFeatureGroup.S3StorageConfigProperty): any;
export declare function awsSagemakerFeatureGroupOfflineStoreConfigPropertyToTerraform(struct?: AwsSagemakerFeatureGroup.OfflineStoreConfigPropertyOutputReference | AwsSagemakerFeatureGroup.OfflineStoreConfigProperty): any;
export declare function awsSagemakerFeatureGroupOfflineStoreConfigPropertyToHclTerraform(struct?: AwsSagemakerFeatureGroup.OfflineStoreConfigPropertyOutputReference | AwsSagemakerFeatureGroup.OfflineStoreConfigProperty): any;
export declare function awsSagemakerFeatureGroupSecurityConfigPropertyToTerraform(struct?: AwsSagemakerFeatureGroup.SecurityConfigPropertyOutputReference | AwsSagemakerFeatureGroup.SecurityConfigProperty): any;
export declare function awsSagemakerFeatureGroupSecurityConfigPropertyToHclTerraform(struct?: AwsSagemakerFeatureGroup.SecurityConfigPropertyOutputReference | AwsSagemakerFeatureGroup.SecurityConfigProperty): any;
export declare function awsSagemakerFeatureGroupTtlDurationPropertyToTerraform(struct?: AwsSagemakerFeatureGroup.TtlDurationPropertyOutputReference | AwsSagemakerFeatureGroup.TtlDurationProperty): any;
export declare function awsSagemakerFeatureGroupTtlDurationPropertyToHclTerraform(struct?: AwsSagemakerFeatureGroup.TtlDurationPropertyOutputReference | AwsSagemakerFeatureGroup.TtlDurationProperty): any;
export declare function awsSagemakerFeatureGroupOnlineStoreConfigPropertyToTerraform(struct?: AwsSagemakerFeatureGroup.OnlineStoreConfigPropertyOutputReference | AwsSagemakerFeatureGroup.OnlineStoreConfigProperty): any;
export declare function awsSagemakerFeatureGroupOnlineStoreConfigPropertyToHclTerraform(struct?: AwsSagemakerFeatureGroup.OnlineStoreConfigPropertyOutputReference | AwsSagemakerFeatureGroup.OnlineStoreConfigProperty): any;
export declare function awsSagemakerFeatureGroupThroughputConfigPropertyToTerraform(struct?: AwsSagemakerFeatureGroup.ThroughputConfigPropertyOutputReference | AwsSagemakerFeatureGroup.ThroughputConfigProperty): any;
export declare function awsSagemakerFeatureGroupThroughputConfigPropertyToHclTerraform(struct?: AwsSagemakerFeatureGroup.ThroughputConfigPropertyOutputReference | AwsSagemakerFeatureGroup.ThroughputConfigProperty): any;
export declare namespace AwsSagemakerFeatureGroup {
    interface VectorConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_feature_group#dimension AwsSagemakerFeatureGroup#dimension}
        */
        readonly dimension?: number;
    }
    class VectorConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VectorConfigProperty | undefined;
        set internalValue(value: VectorConfigProperty | undefined);
        private _dimension?;
        get dimension(): number;
        set dimension(value: number);
        resetDimension(): void;
        get dimensionInput(): number | undefined;
    }
    interface CollectionConfigProperty {
        /**
        * vector_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_feature_group#vector_config AwsSagemakerFeatureGroup#vector_config}
        */
        readonly vectorConfig?: VectorConfigProperty;
    }
    class CollectionConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CollectionConfigProperty | undefined;
        set internalValue(value: CollectionConfigProperty | undefined);
        private _vectorConfig;
        get vectorConfig(): VectorConfigPropertyOutputReference;
        putVectorConfig(value: VectorConfigProperty): void;
        resetVectorConfig(): void;
        get vectorConfigInput(): VectorConfigProperty | undefined;
    }
    interface FeatureDefinitionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_feature_group#collection_type AwsSagemakerFeatureGroup#collection_type}
        */
        readonly collectionType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_feature_group#feature_name AwsSagemakerFeatureGroup#feature_name}
        */
        readonly featureName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_feature_group#feature_type AwsSagemakerFeatureGroup#feature_type}
        */
        readonly featureType?: string;
        /**
        * collection_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_feature_group#collection_config AwsSagemakerFeatureGroup#collection_config}
        */
        readonly collectionConfig?: CollectionConfigProperty;
    }
    class FeatureDefinitionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FeatureDefinitionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FeatureDefinitionProperty | cdktn.IResolvable | undefined);
        private _collectionType?;
        get collectionType(): string;
        set collectionType(value: string);
        resetCollectionType(): void;
        get collectionTypeInput(): string | undefined;
        private _featureName?;
        get featureName(): string;
        set featureName(value: string);
        resetFeatureName(): void;
        get featureNameInput(): string | undefined;
        private _featureType?;
        get featureType(): string;
        set featureType(value: string);
        resetFeatureType(): void;
        get featureTypeInput(): string | undefined;
        private _collectionConfig;
        get collectionConfig(): CollectionConfigPropertyOutputReference;
        putCollectionConfig(value: CollectionConfigProperty): void;
        resetCollectionConfig(): void;
        get collectionConfigInput(): CollectionConfigProperty | undefined;
    }
    class FeatureDefinitionPropertyList extends cdktn.ComplexList {
        internalValue?: FeatureDefinitionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FeatureDefinitionPropertyOutputReference;
    }
    interface DataCatalogConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_feature_group#catalog AwsSagemakerFeatureGroup#catalog}
        */
        readonly catalog?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_feature_group#database AwsSagemakerFeatureGroup#database}
        */
        readonly database?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_feature_group#table_name AwsSagemakerFeatureGroup#table_name}
        */
        readonly tableName?: string;
    }
    class DataCatalogConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DataCatalogConfigProperty | undefined;
        set internalValue(value: DataCatalogConfigProperty | undefined);
        private _catalog?;
        get catalog(): string;
        set catalog(value: string);
        resetCatalog(): void;
        get catalogInput(): string | undefined;
        private _database?;
        get database(): string;
        set database(value: string);
        resetDatabase(): void;
        get databaseInput(): string | undefined;
        private _tableName?;
        get tableName(): string;
        set tableName(value: string);
        resetTableName(): void;
        get tableNameInput(): string | undefined;
    }
    interface S3StorageConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_feature_group#kms_key_id AwsSagemakerFeatureGroup#kms_key_id}
        */
        readonly kmsKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_feature_group#resolved_output_s3_uri AwsSagemakerFeatureGroup#resolved_output_s3_uri}
        */
        readonly resolvedOutputS3Uri?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_feature_group#s3_uri AwsSagemakerFeatureGroup#s3_uri}
        */
        readonly s3Uri: string;
    }
    class S3StorageConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3StorageConfigProperty | undefined;
        set internalValue(value: S3StorageConfigProperty | undefined);
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        resetKmsKeyId(): void;
        get kmsKeyIdInput(): string | undefined;
        private _resolvedOutputS3Uri?;
        get resolvedOutputS3Uri(): string;
        set resolvedOutputS3Uri(value: string);
        resetResolvedOutputS3Uri(): void;
        get resolvedOutputS3UriInput(): string | undefined;
        private _s3Uri?;
        get s3Uri(): string;
        set s3Uri(value: string);
        get s3UriInput(): string | undefined;
    }
    interface OfflineStoreConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_feature_group#disable_glue_table_creation AwsSagemakerFeatureGroup#disable_glue_table_creation}
        */
        readonly disableGlueTableCreation?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_feature_group#table_format AwsSagemakerFeatureGroup#table_format}
        */
        readonly tableFormat?: string;
        /**
        * data_catalog_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_feature_group#data_catalog_config AwsSagemakerFeatureGroup#data_catalog_config}
        */
        readonly dataCatalogConfig?: DataCatalogConfigProperty;
        /**
        * s3_storage_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_feature_group#s3_storage_config AwsSagemakerFeatureGroup#s3_storage_config}
        */
        readonly s3StorageConfig: S3StorageConfigProperty;
    }
    class OfflineStoreConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OfflineStoreConfigProperty | undefined;
        set internalValue(value: OfflineStoreConfigProperty | undefined);
        private _disableGlueTableCreation?;
        get disableGlueTableCreation(): boolean | cdktn.IResolvable;
        set disableGlueTableCreation(value: boolean | cdktn.IResolvable);
        resetDisableGlueTableCreation(): void;
        get disableGlueTableCreationInput(): boolean | cdktn.IResolvable | undefined;
        private _tableFormat?;
        get tableFormat(): string;
        set tableFormat(value: string);
        resetTableFormat(): void;
        get tableFormatInput(): string | undefined;
        private _dataCatalogConfig;
        get dataCatalogConfig(): DataCatalogConfigPropertyOutputReference;
        putDataCatalogConfig(value: DataCatalogConfigProperty): void;
        resetDataCatalogConfig(): void;
        get dataCatalogConfigInput(): DataCatalogConfigProperty | undefined;
        private _s3StorageConfig;
        get s3StorageConfig(): S3StorageConfigPropertyOutputReference;
        putS3StorageConfig(value: S3StorageConfigProperty): void;
        get s3StorageConfigInput(): S3StorageConfigProperty | undefined;
    }
    interface SecurityConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_feature_group#kms_key_id AwsSagemakerFeatureGroup#kms_key_id}
        */
        readonly kmsKeyId?: string;
    }
    class SecurityConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SecurityConfigProperty | undefined;
        set internalValue(value: SecurityConfigProperty | undefined);
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        resetKmsKeyId(): void;
        get kmsKeyIdInput(): string | undefined;
    }
    interface TtlDurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_feature_group#unit AwsSagemakerFeatureGroup#unit}
        */
        readonly unit?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_feature_group#value AwsSagemakerFeatureGroup#value}
        */
        readonly value?: number;
    }
    class TtlDurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TtlDurationProperty | undefined;
        set internalValue(value: TtlDurationProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        resetUnit(): void;
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        resetValue(): void;
        get valueInput(): number | undefined;
    }
    interface OnlineStoreConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_feature_group#enable_online_store AwsSagemakerFeatureGroup#enable_online_store}
        */
        readonly enableOnlineStore?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_feature_group#storage_type AwsSagemakerFeatureGroup#storage_type}
        */
        readonly storageType?: string;
        /**
        * security_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_feature_group#security_config AwsSagemakerFeatureGroup#security_config}
        */
        readonly securityConfig?: SecurityConfigProperty;
        /**
        * ttl_duration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_feature_group#ttl_duration AwsSagemakerFeatureGroup#ttl_duration}
        */
        readonly ttlDuration?: TtlDurationProperty;
    }
    class OnlineStoreConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OnlineStoreConfigProperty | undefined;
        set internalValue(value: OnlineStoreConfigProperty | undefined);
        private _enableOnlineStore?;
        get enableOnlineStore(): boolean | cdktn.IResolvable;
        set enableOnlineStore(value: boolean | cdktn.IResolvable);
        resetEnableOnlineStore(): void;
        get enableOnlineStoreInput(): boolean | cdktn.IResolvable | undefined;
        private _storageType?;
        get storageType(): string;
        set storageType(value: string);
        resetStorageType(): void;
        get storageTypeInput(): string | undefined;
        private _securityConfig;
        get securityConfig(): SecurityConfigPropertyOutputReference;
        putSecurityConfig(value: SecurityConfigProperty): void;
        resetSecurityConfig(): void;
        get securityConfigInput(): SecurityConfigProperty | undefined;
        private _ttlDuration;
        get ttlDuration(): TtlDurationPropertyOutputReference;
        putTtlDuration(value: TtlDurationProperty): void;
        resetTtlDuration(): void;
        get ttlDurationInput(): TtlDurationProperty | undefined;
    }
    interface ThroughputConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_feature_group#provisioned_read_capacity_units AwsSagemakerFeatureGroup#provisioned_read_capacity_units}
        */
        readonly provisionedReadCapacityUnits?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_feature_group#provisioned_write_capacity_units AwsSagemakerFeatureGroup#provisioned_write_capacity_units}
        */
        readonly provisionedWriteCapacityUnits?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_feature_group#throughput_mode AwsSagemakerFeatureGroup#throughput_mode}
        */
        readonly throughputMode?: string;
    }
    class ThroughputConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ThroughputConfigProperty | undefined;
        set internalValue(value: ThroughputConfigProperty | undefined);
        private _provisionedReadCapacityUnits?;
        get provisionedReadCapacityUnits(): number;
        set provisionedReadCapacityUnits(value: number);
        resetProvisionedReadCapacityUnits(): void;
        get provisionedReadCapacityUnitsInput(): number | undefined;
        private _provisionedWriteCapacityUnits?;
        get provisionedWriteCapacityUnits(): number;
        set provisionedWriteCapacityUnits(value: number);
        resetProvisionedWriteCapacityUnits(): void;
        get provisionedWriteCapacityUnitsInput(): number | undefined;
        private _throughputMode?;
        get throughputMode(): string;
        set throughputMode(value: string);
        resetThroughputMode(): void;
        get throughputModeInput(): string | undefined;
    }
}
