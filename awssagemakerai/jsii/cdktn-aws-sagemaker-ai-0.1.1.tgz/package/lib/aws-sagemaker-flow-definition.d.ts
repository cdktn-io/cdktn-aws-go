import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSagemakerFlowDefinitionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#flow_definition_name AwsSagemakerFlowDefinition#flow_definition_name}
    */
    readonly flowDefinitionName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#id AwsSagemakerFlowDefinition#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#region AwsSagemakerFlowDefinition#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#role_arn AwsSagemakerFlowDefinition#role_arn}
    */
    readonly roleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#tags AwsSagemakerFlowDefinition#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#tags_all AwsSagemakerFlowDefinition#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * human_loop_activation_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#human_loop_activation_config AwsSagemakerFlowDefinition#human_loop_activation_config}
    */
    readonly humanLoopActivationConfig?: AwsSagemakerFlowDefinition.HumanLoopActivationConfigProperty;
    /**
    * human_loop_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#human_loop_config AwsSagemakerFlowDefinition#human_loop_config}
    */
    readonly humanLoopConfig: AwsSagemakerFlowDefinition.HumanLoopConfigProperty;
    /**
    * human_loop_request_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#human_loop_request_source AwsSagemakerFlowDefinition#human_loop_request_source}
    */
    readonly humanLoopRequestSource?: AwsSagemakerFlowDefinition.HumanLoopRequestSourceProperty;
    /**
    * output_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#output_config AwsSagemakerFlowDefinition#output_config}
    */
    readonly outputConfig: AwsSagemakerFlowDefinition.OutputConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition aws_sagemaker_flow_definition}
*/
export declare class AwsSagemakerFlowDefinition extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_sagemaker_flow_definition";
    /**
    * Generates CDKTN code for importing a AwsSagemakerFlowDefinition resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSagemakerFlowDefinition to import
    * @param importFromId The id of the existing AwsSagemakerFlowDefinition that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSagemakerFlowDefinition to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition aws_sagemaker_flow_definition} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSagemakerFlowDefinitionConfig
    */
    constructor(scope: Construct, id: string, config: AwsSagemakerFlowDefinitionConfig);
    get arn(): string;
    private _flowDefinitionName?;
    get flowDefinitionName(): string;
    set flowDefinitionName(value: string);
    get flowDefinitionNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _humanLoopActivationConfig;
    get humanLoopActivationConfig(): AwsSagemakerFlowDefinition.HumanLoopActivationConfigPropertyOutputReference;
    putHumanLoopActivationConfig(value: AwsSagemakerFlowDefinition.HumanLoopActivationConfigProperty): void;
    resetHumanLoopActivationConfig(): void;
    get humanLoopActivationConfigInput(): AwsSagemakerFlowDefinition.HumanLoopActivationConfigProperty | undefined;
    private _humanLoopConfig;
    get humanLoopConfig(): AwsSagemakerFlowDefinition.HumanLoopConfigPropertyOutputReference;
    putHumanLoopConfig(value: AwsSagemakerFlowDefinition.HumanLoopConfigProperty): void;
    get humanLoopConfigInput(): AwsSagemakerFlowDefinition.HumanLoopConfigProperty | undefined;
    private _humanLoopRequestSource;
    get humanLoopRequestSource(): AwsSagemakerFlowDefinition.HumanLoopRequestSourcePropertyOutputReference;
    putHumanLoopRequestSource(value: AwsSagemakerFlowDefinition.HumanLoopRequestSourceProperty): void;
    resetHumanLoopRequestSource(): void;
    get humanLoopRequestSourceInput(): AwsSagemakerFlowDefinition.HumanLoopRequestSourceProperty | undefined;
    private _outputConfig;
    get outputConfig(): AwsSagemakerFlowDefinition.OutputConfigPropertyOutputReference;
    putOutputConfig(value: AwsSagemakerFlowDefinition.OutputConfigProperty): void;
    get outputConfigInput(): AwsSagemakerFlowDefinition.OutputConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsSagemakerFlowDefinitionHumanLoopActivationConditionsConfigPropertyToTerraform(struct?: AwsSagemakerFlowDefinition.HumanLoopActivationConditionsConfigPropertyOutputReference | AwsSagemakerFlowDefinition.HumanLoopActivationConditionsConfigProperty): any;
export declare function awsSagemakerFlowDefinitionHumanLoopActivationConditionsConfigPropertyToHclTerraform(struct?: AwsSagemakerFlowDefinition.HumanLoopActivationConditionsConfigPropertyOutputReference | AwsSagemakerFlowDefinition.HumanLoopActivationConditionsConfigProperty): any;
export declare function awsSagemakerFlowDefinitionHumanLoopActivationConfigPropertyToTerraform(struct?: AwsSagemakerFlowDefinition.HumanLoopActivationConfigPropertyOutputReference | AwsSagemakerFlowDefinition.HumanLoopActivationConfigProperty): any;
export declare function awsSagemakerFlowDefinitionHumanLoopActivationConfigPropertyToHclTerraform(struct?: AwsSagemakerFlowDefinition.HumanLoopActivationConfigPropertyOutputReference | AwsSagemakerFlowDefinition.HumanLoopActivationConfigProperty): any;
export declare function awsSagemakerFlowDefinitionAmountInUsdPropertyToTerraform(struct?: AwsSagemakerFlowDefinition.AmountInUsdPropertyOutputReference | AwsSagemakerFlowDefinition.AmountInUsdProperty): any;
export declare function awsSagemakerFlowDefinitionAmountInUsdPropertyToHclTerraform(struct?: AwsSagemakerFlowDefinition.AmountInUsdPropertyOutputReference | AwsSagemakerFlowDefinition.AmountInUsdProperty): any;
export declare function awsSagemakerFlowDefinitionPublicWorkforceTaskPricePropertyToTerraform(struct?: AwsSagemakerFlowDefinition.PublicWorkforceTaskPricePropertyOutputReference | AwsSagemakerFlowDefinition.PublicWorkforceTaskPriceProperty): any;
export declare function awsSagemakerFlowDefinitionPublicWorkforceTaskPricePropertyToHclTerraform(struct?: AwsSagemakerFlowDefinition.PublicWorkforceTaskPricePropertyOutputReference | AwsSagemakerFlowDefinition.PublicWorkforceTaskPriceProperty): any;
export declare function awsSagemakerFlowDefinitionHumanLoopConfigPropertyToTerraform(struct?: AwsSagemakerFlowDefinition.HumanLoopConfigPropertyOutputReference | AwsSagemakerFlowDefinition.HumanLoopConfigProperty): any;
export declare function awsSagemakerFlowDefinitionHumanLoopConfigPropertyToHclTerraform(struct?: AwsSagemakerFlowDefinition.HumanLoopConfigPropertyOutputReference | AwsSagemakerFlowDefinition.HumanLoopConfigProperty): any;
export declare function awsSagemakerFlowDefinitionHumanLoopRequestSourcePropertyToTerraform(struct?: AwsSagemakerFlowDefinition.HumanLoopRequestSourcePropertyOutputReference | AwsSagemakerFlowDefinition.HumanLoopRequestSourceProperty): any;
export declare function awsSagemakerFlowDefinitionHumanLoopRequestSourcePropertyToHclTerraform(struct?: AwsSagemakerFlowDefinition.HumanLoopRequestSourcePropertyOutputReference | AwsSagemakerFlowDefinition.HumanLoopRequestSourceProperty): any;
export declare function awsSagemakerFlowDefinitionOutputConfigPropertyToTerraform(struct?: AwsSagemakerFlowDefinition.OutputConfigPropertyOutputReference | AwsSagemakerFlowDefinition.OutputConfigProperty): any;
export declare function awsSagemakerFlowDefinitionOutputConfigPropertyToHclTerraform(struct?: AwsSagemakerFlowDefinition.OutputConfigPropertyOutputReference | AwsSagemakerFlowDefinition.OutputConfigProperty): any;
export declare namespace AwsSagemakerFlowDefinition {
    interface HumanLoopActivationConditionsConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#human_loop_activation_conditions AwsSagemakerFlowDefinition#human_loop_activation_conditions}
        */
        readonly humanLoopActivationConditions: string;
    }
    class HumanLoopActivationConditionsConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HumanLoopActivationConditionsConfigProperty | undefined;
        set internalValue(value: HumanLoopActivationConditionsConfigProperty | undefined);
        private _humanLoopActivationConditions?;
        get humanLoopActivationConditions(): string;
        set humanLoopActivationConditions(value: string);
        get humanLoopActivationConditionsInput(): string | undefined;
    }
    interface HumanLoopActivationConfigProperty {
        /**
        * human_loop_activation_conditions_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#human_loop_activation_conditions_config AwsSagemakerFlowDefinition#human_loop_activation_conditions_config}
        */
        readonly humanLoopActivationConditionsConfig?: HumanLoopActivationConditionsConfigProperty;
    }
    class HumanLoopActivationConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HumanLoopActivationConfigProperty | undefined;
        set internalValue(value: HumanLoopActivationConfigProperty | undefined);
        private _humanLoopActivationConditionsConfig;
        get humanLoopActivationConditionsConfig(): HumanLoopActivationConditionsConfigPropertyOutputReference;
        putHumanLoopActivationConditionsConfig(value: HumanLoopActivationConditionsConfigProperty): void;
        resetHumanLoopActivationConditionsConfig(): void;
        get humanLoopActivationConditionsConfigInput(): HumanLoopActivationConditionsConfigProperty | undefined;
    }
    interface AmountInUsdProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#cents AwsSagemakerFlowDefinition#cents}
        */
        readonly cents?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#dollars AwsSagemakerFlowDefinition#dollars}
        */
        readonly dollars?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#tenth_fractions_of_a_cent AwsSagemakerFlowDefinition#tenth_fractions_of_a_cent}
        */
        readonly tenthFractionsOfACent?: number;
    }
    class AmountInUsdPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AmountInUsdProperty | undefined;
        set internalValue(value: AmountInUsdProperty | undefined);
        private _cents?;
        get cents(): number;
        set cents(value: number);
        resetCents(): void;
        get centsInput(): number | undefined;
        private _dollars?;
        get dollars(): number;
        set dollars(value: number);
        resetDollars(): void;
        get dollarsInput(): number | undefined;
        private _tenthFractionsOfACent?;
        get tenthFractionsOfACent(): number;
        set tenthFractionsOfACent(value: number);
        resetTenthFractionsOfACent(): void;
        get tenthFractionsOfACentInput(): number | undefined;
    }
    interface PublicWorkforceTaskPriceProperty {
        /**
        * amount_in_usd block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#amount_in_usd AwsSagemakerFlowDefinition#amount_in_usd}
        */
        readonly amountInUsd?: AmountInUsdProperty;
    }
    class PublicWorkforceTaskPricePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PublicWorkforceTaskPriceProperty | undefined;
        set internalValue(value: PublicWorkforceTaskPriceProperty | undefined);
        private _amountInUsd;
        get amountInUsd(): AmountInUsdPropertyOutputReference;
        putAmountInUsd(value: AmountInUsdProperty): void;
        resetAmountInUsd(): void;
        get amountInUsdInput(): AmountInUsdProperty | undefined;
    }
    interface HumanLoopConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#human_task_ui_arn AwsSagemakerFlowDefinition#human_task_ui_arn}
        */
        readonly humanTaskUiArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#task_availability_lifetime_in_seconds AwsSagemakerFlowDefinition#task_availability_lifetime_in_seconds}
        */
        readonly taskAvailabilityLifetimeInSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#task_count AwsSagemakerFlowDefinition#task_count}
        */
        readonly taskCount: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#task_description AwsSagemakerFlowDefinition#task_description}
        */
        readonly taskDescription: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#task_keywords AwsSagemakerFlowDefinition#task_keywords}
        */
        readonly taskKeywords?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#task_time_limit_in_seconds AwsSagemakerFlowDefinition#task_time_limit_in_seconds}
        */
        readonly taskTimeLimitInSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#task_title AwsSagemakerFlowDefinition#task_title}
        */
        readonly taskTitle: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#workteam_arn AwsSagemakerFlowDefinition#workteam_arn}
        */
        readonly workteamArn: string;
        /**
        * public_workforce_task_price block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#public_workforce_task_price AwsSagemakerFlowDefinition#public_workforce_task_price}
        */
        readonly publicWorkforceTaskPrice?: PublicWorkforceTaskPriceProperty;
    }
    class HumanLoopConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HumanLoopConfigProperty | undefined;
        set internalValue(value: HumanLoopConfigProperty | undefined);
        private _humanTaskUiArn?;
        get humanTaskUiArn(): string;
        set humanTaskUiArn(value: string);
        get humanTaskUiArnInput(): string | undefined;
        private _taskAvailabilityLifetimeInSeconds?;
        get taskAvailabilityLifetimeInSeconds(): number;
        set taskAvailabilityLifetimeInSeconds(value: number);
        resetTaskAvailabilityLifetimeInSeconds(): void;
        get taskAvailabilityLifetimeInSecondsInput(): number | undefined;
        private _taskCount?;
        get taskCount(): number;
        set taskCount(value: number);
        get taskCountInput(): number | undefined;
        private _taskDescription?;
        get taskDescription(): string;
        set taskDescription(value: string);
        get taskDescriptionInput(): string | undefined;
        private _taskKeywords?;
        get taskKeywords(): string[];
        set taskKeywords(value: string[]);
        resetTaskKeywords(): void;
        get taskKeywordsInput(): string[] | undefined;
        private _taskTimeLimitInSeconds?;
        get taskTimeLimitInSeconds(): number;
        set taskTimeLimitInSeconds(value: number);
        resetTaskTimeLimitInSeconds(): void;
        get taskTimeLimitInSecondsInput(): number | undefined;
        private _taskTitle?;
        get taskTitle(): string;
        set taskTitle(value: string);
        get taskTitleInput(): string | undefined;
        private _workteamArn?;
        get workteamArn(): string;
        set workteamArn(value: string);
        get workteamArnInput(): string | undefined;
        private _publicWorkforceTaskPrice;
        get publicWorkforceTaskPrice(): PublicWorkforceTaskPricePropertyOutputReference;
        putPublicWorkforceTaskPrice(value: PublicWorkforceTaskPriceProperty): void;
        resetPublicWorkforceTaskPrice(): void;
        get publicWorkforceTaskPriceInput(): PublicWorkforceTaskPriceProperty | undefined;
    }
    interface HumanLoopRequestSourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#aws_managed_human_loop_request_source AwsSagemakerFlowDefinition#aws_managed_human_loop_request_source}
        */
        readonly awsManagedHumanLoopRequestSource: string;
    }
    class HumanLoopRequestSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HumanLoopRequestSourceProperty | undefined;
        set internalValue(value: HumanLoopRequestSourceProperty | undefined);
        private _awsManagedHumanLoopRequestSource?;
        get awsManagedHumanLoopRequestSource(): string;
        set awsManagedHumanLoopRequestSource(value: string);
        get awsManagedHumanLoopRequestSourceInput(): string | undefined;
    }
    interface OutputConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#kms_key_id AwsSagemakerFlowDefinition#kms_key_id}
        */
        readonly kmsKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_flow_definition#s3_output_path AwsSagemakerFlowDefinition#s3_output_path}
        */
        readonly s3OutputPath: string;
    }
    class OutputConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OutputConfigProperty | undefined;
        set internalValue(value: OutputConfigProperty | undefined);
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        resetKmsKeyId(): void;
        get kmsKeyIdInput(): string | undefined;
        private _s3OutputPath?;
        get s3OutputPath(): string;
        set s3OutputPath(value: string);
        get s3OutputPathInput(): string | undefined;
    }
}
