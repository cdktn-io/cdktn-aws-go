import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsOdbCloudAutonomousVmClusterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Unique ID of the Autonomous VM cluster.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_cloud_autonomous_vm_cluster#id DataAwsOdbCloudAutonomousVmCluster#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_cloud_autonomous_vm_cluster#region DataAwsOdbCloudAutonomousVmCluster#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_cloud_autonomous_vm_cluster aws_odb_cloud_autonomous_vm_cluster}
*/
export declare class DataAwsOdbCloudAutonomousVmCluster extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_odb_cloud_autonomous_vm_cluster";
    /**
    * Generates CDKTN code for importing a DataAwsOdbCloudAutonomousVmCluster resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsOdbCloudAutonomousVmCluster to import
    * @param importFromId The id of the existing DataAwsOdbCloudAutonomousVmCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_cloud_autonomous_vm_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsOdbCloudAutonomousVmCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_cloud_autonomous_vm_cluster aws_odb_cloud_autonomous_vm_cluster} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsOdbCloudAutonomousVmClusterConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsOdbCloudAutonomousVmClusterConfig);
    get arn(): string;
    get autonomousDataStoragePercentage(): number;
    get autonomousDataStorageSizeInTbs(): number;
    get availableAutonomousDataStorageSizeInTbs(): number;
    get availableContainerDatabases(): number;
    get availableCpus(): number;
    get cloudExadataInfrastructureArn(): string;
    get cloudExadataInfrastructureId(): string;
    get computeModel(): string;
    get cpuCoreCount(): number;
    get cpuCoreCountPerNode(): number;
    get cpuPercentage(): number;
    get createdAt(): string;
    get dataStorageSizeInGbs(): number;
    get dataStorageSizeInTbs(): number;
    get dbServers(): string[];
    get description(): string;
    get displayName(): string;
    get domain(): string;
    get exadataStorageInTbsLowestScaledValue(): number;
    get hostname(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get isMtlsEnabledVmCluster(): cdktn.IResolvable;
    get licenseModel(): string;
    private _maintenanceWindow;
    get maintenanceWindow(): DataAwsOdbCloudAutonomousVmCluster.MaintenanceWindowPropertyList;
    get maxAcdsLowestScaledValue(): number;
    get memoryPerOracleComputeUnitInGbs(): number;
    get memorySizeInGbs(): number;
    get nodeCount(): number;
    get nonProvisionableAutonomousContainerDatabases(): number;
    get ociResourceAnchorName(): string;
    get ociUrl(): string;
    get ocid(): string;
    get odbNetworkArn(): string;
    get odbNetworkId(): string;
    get odbNodeStorageSizeInGbs(): number;
    get percentProgress(): number;
    get provisionableAutonomousContainerDatabases(): number;
    get provisionedAutonomousContainerDatabases(): number;
    get provisionedCpus(): number;
    get reclaimableCpus(): number;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get reservedCpus(): number;
    get scanListenerPortNonTls(): number;
    get scanListenerPortTls(): number;
    get shape(): string;
    get status(): string;
    get statusReason(): string;
    private _tags;
    get tags(): cdktn.StringMap;
    get timeDatabaseSslCertificateExpires(): string;
    get timeOrdsCertificateExpires(): string;
    get timeZone(): string;
    get totalContainerDatabases(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsOdbCloudAutonomousVmClusterDaysOfWeekPropertyToTerraform(struct?: DataAwsOdbCloudAutonomousVmCluster.DaysOfWeekProperty): any;
export declare function dataAwsOdbCloudAutonomousVmClusterDaysOfWeekPropertyToHclTerraform(struct?: DataAwsOdbCloudAutonomousVmCluster.DaysOfWeekProperty): any;
export declare function dataAwsOdbCloudAutonomousVmClusterMonthsPropertyToTerraform(struct?: DataAwsOdbCloudAutonomousVmCluster.MonthsProperty): any;
export declare function dataAwsOdbCloudAutonomousVmClusterMonthsPropertyToHclTerraform(struct?: DataAwsOdbCloudAutonomousVmCluster.MonthsProperty): any;
export declare function dataAwsOdbCloudAutonomousVmClusterMaintenanceWindowPropertyToTerraform(struct?: DataAwsOdbCloudAutonomousVmCluster.MaintenanceWindowProperty): any;
export declare function dataAwsOdbCloudAutonomousVmClusterMaintenanceWindowPropertyToHclTerraform(struct?: DataAwsOdbCloudAutonomousVmCluster.MaintenanceWindowProperty): any;
export declare namespace DataAwsOdbCloudAutonomousVmCluster {
    interface DaysOfWeekProperty {
    }
    class DaysOfWeekPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DaysOfWeekProperty | undefined;
        set internalValue(value: DaysOfWeekProperty | undefined);
        get name(): string;
    }
    class DaysOfWeekPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DaysOfWeekPropertyOutputReference;
    }
    interface MonthsProperty {
    }
    class MonthsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MonthsProperty | undefined;
        set internalValue(value: MonthsProperty | undefined);
        get name(): string;
    }
    class MonthsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MonthsPropertyOutputReference;
    }
    interface MaintenanceWindowProperty {
    }
    class MaintenanceWindowPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MaintenanceWindowProperty | undefined;
        set internalValue(value: MaintenanceWindowProperty | undefined);
        private _daysOfWeek;
        get daysOfWeek(): DaysOfWeekPropertyList;
        get hoursOfDay(): number[];
        get leadTimeInWeeks(): number;
        private _months;
        get months(): MonthsPropertyList;
        get preference(): string;
        get weeksOfMonth(): number[];
    }
    class MaintenanceWindowPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MaintenanceWindowPropertyOutputReference;
    }
}
