import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsOdbNetworkPeeringConnectionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Display name of the odb network peering connection. Changing this will force terraform to create new resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_network_peering_connection#display_name AwsOdbNetworkPeeringConnection#display_name}
    */
    readonly displayName: string;
    /**
    * ARN of the odb network peering connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_network_peering_connection#odb_network_arn AwsOdbNetworkPeeringConnection#odb_network_arn}
    */
    readonly odbNetworkArn?: string;
    /**
    * Required field. The unique identifier of the ODB network that initiates the peering connection. A sample ID is odbpcx-abcdefgh12345678. Changing this will force terraform to create new resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_network_peering_connection#odb_network_id AwsOdbNetworkPeeringConnection#odb_network_id}
    */
    readonly odbNetworkId?: string;
    /**
    * List of peered network cidrs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_network_peering_connection#peer_network_cidrs AwsOdbNetworkPeeringConnection#peer_network_cidrs}
    */
    readonly peerNetworkCidrs?: string[];
    /**
    * Required field. The unique identifier of the ODB peering connection. Changing this will force terraform to create new resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_network_peering_connection#peer_network_id AwsOdbNetworkPeeringConnection#peer_network_id}
    */
    readonly peerNetworkId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_network_peering_connection#region AwsOdbNetworkPeeringConnection#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_network_peering_connection#tags AwsOdbNetworkPeeringConnection#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_network_peering_connection#timeouts AwsOdbNetworkPeeringConnection#timeouts}
    */
    readonly timeouts?: AwsOdbNetworkPeeringConnection.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_network_peering_connection aws_odb_network_peering_connection}
*/
export declare class AwsOdbNetworkPeeringConnection extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_odb_network_peering_connection";
    /**
    * Generates CDKTN code for importing a AwsOdbNetworkPeeringConnection resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsOdbNetworkPeeringConnection to import
    * @param importFromId The id of the existing AwsOdbNetworkPeeringConnection that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_network_peering_connection#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsOdbNetworkPeeringConnection to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_network_peering_connection aws_odb_network_peering_connection} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsOdbNetworkPeeringConnectionConfig
    */
    constructor(scope: Construct, id: string, config: AwsOdbNetworkPeeringConnectionConfig);
    get arn(): string;
    get createdAt(): string;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    get id(): string;
    private _odbNetworkArn?;
    get odbNetworkArn(): string;
    set odbNetworkArn(value: string);
    resetOdbNetworkArn(): void;
    get odbNetworkArnInput(): string | undefined;
    private _odbNetworkId?;
    get odbNetworkId(): string;
    set odbNetworkId(value: string);
    resetOdbNetworkId(): void;
    get odbNetworkIdInput(): string | undefined;
    get odbPeeringConnectionType(): string;
    get peerNetworkArn(): string;
    private _peerNetworkCidrs?;
    get peerNetworkCidrs(): string[];
    set peerNetworkCidrs(value: string[]);
    resetPeerNetworkCidrs(): void;
    get peerNetworkCidrsInput(): string[] | undefined;
    private _peerNetworkId?;
    get peerNetworkId(): string;
    set peerNetworkId(value: string);
    get peerNetworkIdInput(): string | undefined;
    get percentProgress(): number;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    get statusReason(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _timeouts;
    get timeouts(): AwsOdbNetworkPeeringConnection.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsOdbNetworkPeeringConnection.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsOdbNetworkPeeringConnection.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsOdbNetworkPeeringConnectionTimeoutsPropertyToTerraform(struct?: AwsOdbNetworkPeeringConnection.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsOdbNetworkPeeringConnectionTimeoutsPropertyToHclTerraform(struct?: AwsOdbNetworkPeeringConnection.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsOdbNetworkPeeringConnection {
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_network_peering_connection#create AwsOdbNetworkPeeringConnection#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_network_peering_connection#delete AwsOdbNetworkPeeringConnection#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_network_peering_connection#update AwsOdbNetworkPeeringConnection#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
