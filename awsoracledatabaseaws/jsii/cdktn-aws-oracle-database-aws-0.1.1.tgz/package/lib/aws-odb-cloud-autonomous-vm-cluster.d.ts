import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsOdbCloudAutonomousVmClusterConfig extends cdktn.TerraformMetaArguments {
    /**
    * The data storage size allocated for Autonomous Databases in the Autonomous VM cluster, in TB. Changing this will force terraform to create new resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_autonomous_vm_cluster#autonomous_data_storage_size_in_tbs AwsOdbCloudAutonomousVmCluster#autonomous_data_storage_size_in_tbs}
    */
    readonly autonomousDataStorageSizeInTbs: number;
    /**
    * The unique identifier of the Exadata infrastructure for this VM cluster. Changing this will create a new resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_autonomous_vm_cluster#cloud_exadata_infrastructure_arn AwsOdbCloudAutonomousVmCluster#cloud_exadata_infrastructure_arn}
    */
    readonly cloudExadataInfrastructureArn?: string;
    /**
    * Exadata infrastructure id. Changing this will force terraform to create new resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_autonomous_vm_cluster#cloud_exadata_infrastructure_id AwsOdbCloudAutonomousVmCluster#cloud_exadata_infrastructure_id}
    */
    readonly cloudExadataInfrastructureId?: string;
    /**
    * The number of CPU cores enabled per node in the Autonomous VM cluster.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_autonomous_vm_cluster#cpu_core_count_per_node AwsOdbCloudAutonomousVmCluster#cpu_core_count_per_node}
    */
    readonly cpuCoreCountPerNode: number;
    /**
    * The database servers in the Autonomous VM cluster. Changing this will force terraform to create new resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_autonomous_vm_cluster#db_servers AwsOdbCloudAutonomousVmCluster#db_servers}
    */
    readonly dbServers: string[];
    /**
    * The description of the Autonomous VM cluster.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_autonomous_vm_cluster#description AwsOdbCloudAutonomousVmCluster#description}
    */
    readonly description?: string;
    /**
    * The display name of the Autonomous VM cluster. Changing this will force terraform to create new resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_autonomous_vm_cluster#display_name AwsOdbCloudAutonomousVmCluster#display_name}
    */
    readonly displayName: string;
    /**
    * Indicates whether mutual TLS (mTLS) authentication is enabled for the Autonomous VM cluster. Changing this will force terraform to create new resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_autonomous_vm_cluster#is_mtls_enabled_vm_cluster AwsOdbCloudAutonomousVmCluster#is_mtls_enabled_vm_cluster}
    */
    readonly isMtlsEnabledVmCluster?: boolean | cdktn.IResolvable;
    /**
    * The license model for the Autonomous VM cluster. Valid values are LICENSE_INCLUDED or BRING_YOUR_OWN_LICENSE . Changing this will force terraform to create new resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_autonomous_vm_cluster#license_model AwsOdbCloudAutonomousVmCluster#license_model}
    */
    readonly licenseModel?: string;
    /**
    * The amount of memory allocated per Oracle Compute Unit, in GB. Changing this will force terraform to create new resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_autonomous_vm_cluster#memory_per_oracle_compute_unit_in_gbs AwsOdbCloudAutonomousVmCluster#memory_per_oracle_compute_unit_in_gbs}
    */
    readonly memoryPerOracleComputeUnitInGbs: number;
    /**
    * The unique identifier of the ODB network for the VM cluster. This member is required. Changing this will create a new resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_autonomous_vm_cluster#odb_network_arn AwsOdbCloudAutonomousVmCluster#odb_network_arn}
    */
    readonly odbNetworkArn?: string;
    /**
    * The unique identifier of the ODB network associated with this Autonomous VM Cluster. Changing this will force terraform to create new resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_autonomous_vm_cluster#odb_network_id AwsOdbCloudAutonomousVmCluster#odb_network_id}
    */
    readonly odbNetworkId?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_autonomous_vm_cluster#region AwsOdbCloudAutonomousVmCluster#region}
    */
    readonly region?: string;
    /**
    * The SCAN listener port for non-TLS (TCP) protocol. The default is 1521. Changing this will force terraform to create new resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_autonomous_vm_cluster#scan_listener_port_non_tls AwsOdbCloudAutonomousVmCluster#scan_listener_port_non_tls}
    */
    readonly scanListenerPortNonTls: number;
    /**
    * The SCAN listener port for TLS (TCP) protocol. The default is 2484. Changing this will force terraform to create new resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_autonomous_vm_cluster#scan_listener_port_tls AwsOdbCloudAutonomousVmCluster#scan_listener_port_tls}
    */
    readonly scanListenerPortTls: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_autonomous_vm_cluster#tags AwsOdbCloudAutonomousVmCluster#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * The time zone of the Autonomous VM cluster. Changing this will force terraform to create new resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_autonomous_vm_cluster#time_zone AwsOdbCloudAutonomousVmCluster#time_zone}
    */
    readonly timeZone?: string;
    /**
    * The total number of Autonomous Container Databases that can be created with the allocated local storage. Changing this will force terraform to create new resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_autonomous_vm_cluster#total_container_databases AwsOdbCloudAutonomousVmCluster#total_container_databases}
    */
    readonly totalContainerDatabases: number;
    /**
    * maintenance_window block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_autonomous_vm_cluster#maintenance_window AwsOdbCloudAutonomousVmCluster#maintenance_window}
    */
    readonly maintenanceWindow?: AwsOdbCloudAutonomousVmCluster.MaintenanceWindowProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_autonomous_vm_cluster#timeouts AwsOdbCloudAutonomousVmCluster#timeouts}
    */
    readonly timeouts?: AwsOdbCloudAutonomousVmCluster.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_autonomous_vm_cluster aws_odb_cloud_autonomous_vm_cluster}
*/
export declare class AwsOdbCloudAutonomousVmCluster extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_odb_cloud_autonomous_vm_cluster";
    /**
    * Generates CDKTN code for importing a AwsOdbCloudAutonomousVmCluster resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsOdbCloudAutonomousVmCluster to import
    * @param importFromId The id of the existing AwsOdbCloudAutonomousVmCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_autonomous_vm_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsOdbCloudAutonomousVmCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_autonomous_vm_cluster aws_odb_cloud_autonomous_vm_cluster} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsOdbCloudAutonomousVmClusterConfig
    */
    constructor(scope: Construct, id: string, config: AwsOdbCloudAutonomousVmClusterConfig);
    get arn(): string;
    get autonomousDataStoragePercentage(): number;
    private _autonomousDataStorageSizeInTbs?;
    get autonomousDataStorageSizeInTbs(): number;
    set autonomousDataStorageSizeInTbs(value: number);
    get autonomousDataStorageSizeInTbsInput(): number | undefined;
    get availableAutonomousDataStorageSizeInTbs(): number;
    get availableContainerDatabases(): number;
    get availableCpus(): number;
    private _cloudExadataInfrastructureArn?;
    get cloudExadataInfrastructureArn(): string;
    set cloudExadataInfrastructureArn(value: string);
    resetCloudExadataInfrastructureArn(): void;
    get cloudExadataInfrastructureArnInput(): string | undefined;
    private _cloudExadataInfrastructureId?;
    get cloudExadataInfrastructureId(): string;
    set cloudExadataInfrastructureId(value: string);
    resetCloudExadataInfrastructureId(): void;
    get cloudExadataInfrastructureIdInput(): string | undefined;
    get computeModel(): string;
    get cpuCoreCount(): number;
    private _cpuCoreCountPerNode?;
    get cpuCoreCountPerNode(): number;
    set cpuCoreCountPerNode(value: number);
    get cpuCoreCountPerNodeInput(): number | undefined;
    get cpuPercentage(): number;
    get createdAt(): string;
    get dataStorageSizeInGbs(): number;
    get dataStorageSizeInTbs(): number;
    private _dbServers?;
    get dbServers(): string[];
    set dbServers(value: string[]);
    get dbServersInput(): string[] | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    get domain(): string;
    get exadataStorageInTbsLowestScaledValue(): number;
    get hostname(): string;
    get id(): string;
    private _isMtlsEnabledVmCluster?;
    get isMtlsEnabledVmCluster(): boolean | cdktn.IResolvable;
    set isMtlsEnabledVmCluster(value: boolean | cdktn.IResolvable);
    resetIsMtlsEnabledVmCluster(): void;
    get isMtlsEnabledVmClusterInput(): boolean | cdktn.IResolvable | undefined;
    private _licenseModel?;
    get licenseModel(): string;
    set licenseModel(value: string);
    resetLicenseModel(): void;
    get licenseModelInput(): string | undefined;
    get maxAcdsLowestScaledValue(): number;
    private _memoryPerOracleComputeUnitInGbs?;
    get memoryPerOracleComputeUnitInGbs(): number;
    set memoryPerOracleComputeUnitInGbs(value: number);
    get memoryPerOracleComputeUnitInGbsInput(): number | undefined;
    get memorySizeInGbs(): number;
    get nodeCount(): number;
    get nonProvisionableAutonomousContainerDatabases(): number;
    get ociResourceAnchorName(): string;
    get ociUrl(): string;
    get ocid(): string;
    private _odbNetworkArn?;
    get odbNetworkArn(): string;
    set odbNetworkArn(value: string);
    resetOdbNetworkArn(): void;
    get odbNetworkArnInput(): string | undefined;
    private _odbNetworkId?;
    get odbNetworkId(): string;
    set odbNetworkId(value: string);
    resetOdbNetworkId(): void;
    get odbNetworkIdInput(): string | undefined;
    get odbNodeStorageSizeInGbs(): number;
    get percentProgress(): number;
    get provisionableAutonomousContainerDatabases(): number;
    get provisionedAutonomousContainerDatabases(): number;
    get provisionedCpus(): number;
    get reclaimableCpus(): number;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get reservedCpus(): number;
    private _scanListenerPortNonTls?;
    get scanListenerPortNonTls(): number;
    set scanListenerPortNonTls(value: number);
    get scanListenerPortNonTlsInput(): number | undefined;
    private _scanListenerPortTls?;
    get scanListenerPortTls(): number;
    set scanListenerPortTls(value: number);
    get scanListenerPortTlsInput(): number | undefined;
    get shape(): string;
    get status(): string;
    get statusReason(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    get timeDatabaseSslCertificateExpires(): string;
    get timeOrdsCertificateExpires(): string;
    private _timeZone?;
    get timeZone(): string;
    set timeZone(value: string);
    resetTimeZone(): void;
    get timeZoneInput(): string | undefined;
    private _totalContainerDatabases?;
    get totalContainerDatabases(): number;
    set totalContainerDatabases(value: number);
    get totalContainerDatabasesInput(): number | undefined;
    private _maintenanceWindow;
    get maintenanceWindow(): AwsOdbCloudAutonomousVmCluster.MaintenanceWindowPropertyList;
    putMaintenanceWindow(value: AwsOdbCloudAutonomousVmCluster.MaintenanceWindowProperty[] | cdktn.IResolvable): void;
    resetMaintenanceWindow(): void;
    get maintenanceWindowInput(): cdktn.IResolvable | AwsOdbCloudAutonomousVmCluster.MaintenanceWindowProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsOdbCloudAutonomousVmCluster.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsOdbCloudAutonomousVmCluster.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsOdbCloudAutonomousVmCluster.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsOdbCloudAutonomousVmClusterDaysOfWeekPropertyToTerraform(struct?: AwsOdbCloudAutonomousVmCluster.DaysOfWeekProperty | cdktn.IResolvable): any;
export declare function awsOdbCloudAutonomousVmClusterDaysOfWeekPropertyToHclTerraform(struct?: AwsOdbCloudAutonomousVmCluster.DaysOfWeekProperty | cdktn.IResolvable): any;
export declare function awsOdbCloudAutonomousVmClusterMonthsPropertyToTerraform(struct?: AwsOdbCloudAutonomousVmCluster.MonthsProperty | cdktn.IResolvable): any;
export declare function awsOdbCloudAutonomousVmClusterMonthsPropertyToHclTerraform(struct?: AwsOdbCloudAutonomousVmCluster.MonthsProperty | cdktn.IResolvable): any;
export declare function awsOdbCloudAutonomousVmClusterMaintenanceWindowPropertyToTerraform(struct?: AwsOdbCloudAutonomousVmCluster.MaintenanceWindowProperty | cdktn.IResolvable): any;
export declare function awsOdbCloudAutonomousVmClusterMaintenanceWindowPropertyToHclTerraform(struct?: AwsOdbCloudAutonomousVmCluster.MaintenanceWindowProperty | cdktn.IResolvable): any;
export declare function awsOdbCloudAutonomousVmClusterTimeoutsPropertyToTerraform(struct?: AwsOdbCloudAutonomousVmCluster.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsOdbCloudAutonomousVmClusterTimeoutsPropertyToHclTerraform(struct?: AwsOdbCloudAutonomousVmCluster.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsOdbCloudAutonomousVmCluster {
    interface DaysOfWeekProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_autonomous_vm_cluster#name AwsOdbCloudAutonomousVmCluster#name}
        */
        readonly name?: string;
    }
    class DaysOfWeekPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DaysOfWeekProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DaysOfWeekProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
    }
    class DaysOfWeekPropertyList extends cdktn.ComplexList {
        internalValue?: DaysOfWeekProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DaysOfWeekPropertyOutputReference;
    }
    interface MonthsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_autonomous_vm_cluster#name AwsOdbCloudAutonomousVmCluster#name}
        */
        readonly name?: string;
    }
    class MonthsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MonthsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MonthsProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
    }
    class MonthsPropertyList extends cdktn.ComplexList {
        internalValue?: MonthsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MonthsPropertyOutputReference;
    }
    interface MaintenanceWindowProperty {
        /**
        * The days of the week when maintenance can be performed.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_autonomous_vm_cluster#days_of_week AwsOdbCloudAutonomousVmCluster#days_of_week}
        */
        readonly daysOfWeek?: DaysOfWeekProperty[] | cdktn.IResolvable;
        /**
        * The hours of the day when maintenance can be performed.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_autonomous_vm_cluster#hours_of_day AwsOdbCloudAutonomousVmCluster#hours_of_day}
        */
        readonly hoursOfDay?: number[];
        /**
        * The lead time in weeks before the maintenance window.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_autonomous_vm_cluster#lead_time_in_weeks AwsOdbCloudAutonomousVmCluster#lead_time_in_weeks}
        */
        readonly leadTimeInWeeks?: number;
        /**
        * The months when maintenance can be performed.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_autonomous_vm_cluster#months AwsOdbCloudAutonomousVmCluster#months}
        */
        readonly months?: MonthsProperty[] | cdktn.IResolvable;
        /**
        * The preference for the maintenance window scheduling.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_autonomous_vm_cluster#preference AwsOdbCloudAutonomousVmCluster#preference}
        */
        readonly preference: string;
        /**
        * Indicates whether to skip release updates during maintenance.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_autonomous_vm_cluster#weeks_of_month AwsOdbCloudAutonomousVmCluster#weeks_of_month}
        */
        readonly weeksOfMonth?: number[];
    }
    class MaintenanceWindowPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MaintenanceWindowProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MaintenanceWindowProperty | cdktn.IResolvable | undefined);
        private _daysOfWeek;
        get daysOfWeek(): DaysOfWeekPropertyList;
        putDaysOfWeek(value: DaysOfWeekProperty[] | cdktn.IResolvable): void;
        resetDaysOfWeek(): void;
        get daysOfWeekInput(): cdktn.IResolvable | DaysOfWeekProperty[] | undefined;
        private _hoursOfDay?;
        get hoursOfDay(): number[];
        set hoursOfDay(value: number[]);
        resetHoursOfDay(): void;
        get hoursOfDayInput(): number[] | undefined;
        private _leadTimeInWeeks?;
        get leadTimeInWeeks(): number;
        set leadTimeInWeeks(value: number);
        resetLeadTimeInWeeks(): void;
        get leadTimeInWeeksInput(): number | undefined;
        private _months;
        get months(): MonthsPropertyList;
        putMonths(value: MonthsProperty[] | cdktn.IResolvable): void;
        resetMonths(): void;
        get monthsInput(): cdktn.IResolvable | MonthsProperty[] | undefined;
        private _preference?;
        get preference(): string;
        set preference(value: string);
        get preferenceInput(): string | undefined;
        private _weeksOfMonth?;
        get weeksOfMonth(): number[];
        set weeksOfMonth(value: number[]);
        resetWeeksOfMonth(): void;
        get weeksOfMonthInput(): number[] | undefined;
    }
    class MaintenanceWindowPropertyList extends cdktn.ComplexList {
        internalValue?: MaintenanceWindowProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MaintenanceWindowPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_autonomous_vm_cluster#create AwsOdbCloudAutonomousVmCluster#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_autonomous_vm_cluster#delete AwsOdbCloudAutonomousVmCluster#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_autonomous_vm_cluster#update AwsOdbCloudAutonomousVmCluster#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
