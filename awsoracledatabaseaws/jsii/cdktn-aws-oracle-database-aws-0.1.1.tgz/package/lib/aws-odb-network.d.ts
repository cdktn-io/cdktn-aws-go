import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsOdbNetworkConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the Availability Zone (AZ) where the odb network is located. Changing this will force terraform to create new resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_network#availability_zone AwsOdbNetwork#availability_zone}
    */
    readonly availabilityZone?: string;
    /**
    * The AZ ID of the AZ where the ODB network is located. Changing this will force terraform to create new resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_network#availability_zone_id AwsOdbNetwork#availability_zone_id}
    */
    readonly availabilityZoneId: string;
    /**
    * The CIDR range of the backup subnet for the ODB network. Changing this will force terraform to create new resource.
    * 	Constraints:
    * 	   - Must not overlap with the CIDR range of the client subnet.
    * 	   - Must not overlap with the CIDR ranges of the VPCs that are connected to the
    * 	   ODB network.
    * 	   - Must not use the following CIDR ranges that are reserved by OCI:
    * 	   - 100.106.0.0/16 and 100.107.0.0/16
    * 	   - 169.254.0.0/16
    * 	   - 224.0.0.0 - 239.255.255.255
    * 	   - 240.0.0.0 - 255.255.255.255
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_network#backup_subnet_cidr AwsOdbNetwork#backup_subnet_cidr}
    */
    readonly backupSubnetCidr: string;
    /**
    * The CIDR notation for the network resource. Changing this will force terraform to create new resource.
    *  Constraints:
    *   	 - Must not overlap with the CIDR range of the backup subnet.
    *    	- Must not overlap with the CIDR ranges of the VPCs that are connected to the
    *    ODB network.
    *   	- Must not use the following CIDR ranges that are reserved by OCI:
    *   	 - 100.106.0.0/16 and 100.107.0.0/16
    *   	 - 169.254.0.0/16
    *    	- 224.0.0.0 - 239.255.255.255
    *    	- 240.0.0.0 - 255.255.255.255
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_network#client_subnet_cidr AwsOdbNetwork#client_subnet_cidr}
    */
    readonly clientSubnetCidr: string;
    /**
    * The list of regions enabled for cross-region restore in the ODB network.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_network#cross_region_s3_restore_sources_access AwsOdbNetwork#cross_region_s3_restore_sources_access}
    */
    readonly crossRegionS3RestoreSourcesAccess?: string[];
    /**
    * The name of the custom domain that the network is located. custom_domain_name and default_dns_prefix both can't be given.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_network#custom_domain_name AwsOdbNetwork#custom_domain_name}
    */
    readonly customDomainName?: string;
    /**
    * The default DNS prefix for the network resource. Changing this will force terraform to create new resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_network#default_dns_prefix AwsOdbNetwork#default_dns_prefix}
    */
    readonly defaultDnsPrefix?: string;
    /**
    * If set to true deletes associated OCI resources. Default false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_network#delete_associated_resources AwsOdbNetwork#delete_associated_resources}
    */
    readonly deleteAssociatedResources?: boolean | cdktn.IResolvable;
    /**
    * The user-friendly name for the odb network. Changing this will force terraform to create a new resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_network#display_name AwsOdbNetwork#display_name}
    */
    readonly displayName: string;
    /**
    * Specifies the configuration for Amazon KMS access from the ODB network.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_network#kms_access AwsOdbNetwork#kms_access}
    */
    readonly kmsAccess?: string;
    /**
    * Specifies the endpoint policy for Amazon KMS access from the ODB network.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_network#kms_policy_document AwsOdbNetwork#kms_policy_document}
    */
    readonly kmsPolicyDocument?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_network#region AwsOdbNetwork#region}
    */
    readonly region?: string;
    /**
    * Specifies the configuration for Amazon S3 access from the ODB network.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_network#s3_access AwsOdbNetwork#s3_access}
    */
    readonly s3Access: string;
    /**
    * Specifies the endpoint policy for Amazon S3 access from the ODB network.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_network#s3_policy_document AwsOdbNetwork#s3_policy_document}
    */
    readonly s3PolicyDocument?: string;
    /**
    * Specifies the configuration for Amazon STS access from the ODB network.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_network#sts_access AwsOdbNetwork#sts_access}
    */
    readonly stsAccess?: string;
    /**
    * Specifies the endpoint policy for Amazon STS access from the ODB network.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_network#sts_policy_document AwsOdbNetwork#sts_policy_document}
    */
    readonly stsPolicyDocument?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_network#tags AwsOdbNetwork#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Specifies the configuration for Zero-ETL access from the ODB network.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_network#zero_etl_access AwsOdbNetwork#zero_etl_access}
    */
    readonly zeroEtlAccess: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_network#timeouts AwsOdbNetwork#timeouts}
    */
    readonly timeouts?: AwsOdbNetwork.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_network aws_odb_network}
*/
export declare class AwsOdbNetwork extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_odb_network";
    /**
    * Generates CDKTN code for importing a AwsOdbNetwork resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsOdbNetwork to import
    * @param importFromId The id of the existing AwsOdbNetwork that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_network#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsOdbNetwork to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_network aws_odb_network} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsOdbNetworkConfig
    */
    constructor(scope: Construct, id: string, config: AwsOdbNetworkConfig);
    get arn(): string;
    private _availabilityZone?;
    get availabilityZone(): string;
    set availabilityZone(value: string);
    resetAvailabilityZone(): void;
    get availabilityZoneInput(): string | undefined;
    private _availabilityZoneId?;
    get availabilityZoneId(): string;
    set availabilityZoneId(value: string);
    get availabilityZoneIdInput(): string | undefined;
    private _backupSubnetCidr?;
    get backupSubnetCidr(): string;
    set backupSubnetCidr(value: string);
    get backupSubnetCidrInput(): string | undefined;
    private _clientSubnetCidr?;
    get clientSubnetCidr(): string;
    set clientSubnetCidr(value: string);
    get clientSubnetCidrInput(): string | undefined;
    get createdAt(): string;
    private _crossRegionS3RestoreSourcesAccess?;
    get crossRegionS3RestoreSourcesAccess(): string[];
    set crossRegionS3RestoreSourcesAccess(value: string[]);
    resetCrossRegionS3RestoreSourcesAccess(): void;
    get crossRegionS3RestoreSourcesAccessInput(): string[] | undefined;
    private _customDomainName?;
    get customDomainName(): string;
    set customDomainName(value: string);
    resetCustomDomainName(): void;
    get customDomainNameInput(): string | undefined;
    private _defaultDnsPrefix?;
    get defaultDnsPrefix(): string;
    set defaultDnsPrefix(value: string);
    resetDefaultDnsPrefix(): void;
    get defaultDnsPrefixInput(): string | undefined;
    private _deleteAssociatedResources?;
    get deleteAssociatedResources(): boolean | cdktn.IResolvable;
    set deleteAssociatedResources(value: boolean | cdktn.IResolvable);
    resetDeleteAssociatedResources(): void;
    get deleteAssociatedResourcesInput(): boolean | cdktn.IResolvable | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    get ec2PlacementGroupIds(): string[];
    get id(): string;
    private _kmsAccess?;
    get kmsAccess(): string;
    set kmsAccess(value: string);
    resetKmsAccess(): void;
    get kmsAccessInput(): string | undefined;
    private _kmsPolicyDocument?;
    get kmsPolicyDocument(): string;
    set kmsPolicyDocument(value: string);
    resetKmsPolicyDocument(): void;
    get kmsPolicyDocumentInput(): string | undefined;
    private _managedServices;
    get managedServices(): AwsOdbNetwork.ManagedServicesPropertyList;
    private _ociDnsForwardingConfigs;
    get ociDnsForwardingConfigs(): AwsOdbNetwork.OciDnsForwardingConfigsPropertyList;
    get ociNetworkAnchorId(): string;
    get ociNetworkAnchorUrl(): string;
    get ociResourceAnchorName(): string;
    get ociVcnId(): string;
    get ociVcnUrl(): string;
    get peeredCidrs(): string[];
    get percentProgress(): number;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _s3Access?;
    get s3Access(): string;
    set s3Access(value: string);
    get s3AccessInput(): string | undefined;
    private _s3PolicyDocument?;
    get s3PolicyDocument(): string;
    set s3PolicyDocument(value: string);
    resetS3PolicyDocument(): void;
    get s3PolicyDocumentInput(): string | undefined;
    get status(): string;
    get statusReason(): string;
    private _stsAccess?;
    get stsAccess(): string;
    set stsAccess(value: string);
    resetStsAccess(): void;
    get stsAccessInput(): string | undefined;
    private _stsPolicyDocument?;
    get stsPolicyDocument(): string;
    set stsPolicyDocument(value: string);
    resetStsPolicyDocument(): void;
    get stsPolicyDocumentInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _zeroEtlAccess?;
    get zeroEtlAccess(): string;
    set zeroEtlAccess(value: string);
    get zeroEtlAccessInput(): string | undefined;
    private _timeouts;
    get timeouts(): AwsOdbNetwork.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsOdbNetwork.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsOdbNetwork.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsOdbNetworkCrossRegionS3RestoreSourcesAccessPropertyToTerraform(struct?: AwsOdbNetwork.CrossRegionS3RestoreSourcesAccessProperty): any;
export declare function awsOdbNetworkCrossRegionS3RestoreSourcesAccessPropertyToHclTerraform(struct?: AwsOdbNetwork.CrossRegionS3RestoreSourcesAccessProperty): any;
export declare function awsOdbNetworkKmsAccessPropertyToTerraform(struct?: AwsOdbNetwork.KmsAccessProperty): any;
export declare function awsOdbNetworkKmsAccessPropertyToHclTerraform(struct?: AwsOdbNetwork.KmsAccessProperty): any;
export declare function awsOdbNetworkManagedS3BackupAccessPropertyToTerraform(struct?: AwsOdbNetwork.ManagedS3BackupAccessProperty): any;
export declare function awsOdbNetworkManagedS3BackupAccessPropertyToHclTerraform(struct?: AwsOdbNetwork.ManagedS3BackupAccessProperty): any;
export declare function awsOdbNetworkS3AccessPropertyToTerraform(struct?: AwsOdbNetwork.S3AccessProperty): any;
export declare function awsOdbNetworkS3AccessPropertyToHclTerraform(struct?: AwsOdbNetwork.S3AccessProperty): any;
export declare function awsOdbNetworkServiceNetworkEndpointPropertyToTerraform(struct?: AwsOdbNetwork.ServiceNetworkEndpointProperty): any;
export declare function awsOdbNetworkServiceNetworkEndpointPropertyToHclTerraform(struct?: AwsOdbNetwork.ServiceNetworkEndpointProperty): any;
export declare function awsOdbNetworkStsAccessPropertyToTerraform(struct?: AwsOdbNetwork.StsAccessProperty): any;
export declare function awsOdbNetworkStsAccessPropertyToHclTerraform(struct?: AwsOdbNetwork.StsAccessProperty): any;
export declare function awsOdbNetworkZeroEtlAccessPropertyToTerraform(struct?: AwsOdbNetwork.ZeroEtlAccessProperty): any;
export declare function awsOdbNetworkZeroEtlAccessPropertyToHclTerraform(struct?: AwsOdbNetwork.ZeroEtlAccessProperty): any;
export declare function awsOdbNetworkManagedServicesPropertyToTerraform(struct?: AwsOdbNetwork.ManagedServicesProperty): any;
export declare function awsOdbNetworkManagedServicesPropertyToHclTerraform(struct?: AwsOdbNetwork.ManagedServicesProperty): any;
export declare function awsOdbNetworkOciDnsForwardingConfigsPropertyToTerraform(struct?: AwsOdbNetwork.OciDnsForwardingConfigsProperty): any;
export declare function awsOdbNetworkOciDnsForwardingConfigsPropertyToHclTerraform(struct?: AwsOdbNetwork.OciDnsForwardingConfigsProperty): any;
export declare function awsOdbNetworkTimeoutsPropertyToTerraform(struct?: AwsOdbNetwork.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsOdbNetworkTimeoutsPropertyToHclTerraform(struct?: AwsOdbNetwork.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsOdbNetwork {
    interface CrossRegionS3RestoreSourcesAccessProperty {
    }
    class CrossRegionS3RestoreSourcesAccessPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CrossRegionS3RestoreSourcesAccessProperty | undefined;
        set internalValue(value: CrossRegionS3RestoreSourcesAccessProperty | undefined);
        get ipv4Addresses(): string[];
        get region(): string;
        get status(): string;
    }
    class CrossRegionS3RestoreSourcesAccessPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CrossRegionS3RestoreSourcesAccessPropertyOutputReference;
    }
    interface KmsAccessProperty {
    }
    class KmsAccessPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KmsAccessProperty | undefined;
        set internalValue(value: KmsAccessProperty | undefined);
        get domainName(): string;
        get ipv4Addresses(): string[];
        get kmsPolicyDocument(): string;
        get status(): string;
    }
    class KmsAccessPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KmsAccessPropertyOutputReference;
    }
    interface ManagedS3BackupAccessProperty {
    }
    class ManagedS3BackupAccessPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ManagedS3BackupAccessProperty | undefined;
        set internalValue(value: ManagedS3BackupAccessProperty | undefined);
        get ipv4Addresses(): string[];
        get status(): string;
    }
    class ManagedS3BackupAccessPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ManagedS3BackupAccessPropertyOutputReference;
    }
    interface S3AccessProperty {
    }
    class S3AccessPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3AccessProperty | undefined;
        set internalValue(value: S3AccessProperty | undefined);
        get domainName(): string;
        get ipv4Addresses(): string[];
        get s3PolicyDocument(): string;
        get status(): string;
    }
    class S3AccessPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3AccessPropertyOutputReference;
    }
    interface ServiceNetworkEndpointProperty {
    }
    class ServiceNetworkEndpointPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ServiceNetworkEndpointProperty | undefined;
        set internalValue(value: ServiceNetworkEndpointProperty | undefined);
        get vpcEndpointId(): string;
        get vpcEndpointType(): string;
    }
    class ServiceNetworkEndpointPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ServiceNetworkEndpointPropertyOutputReference;
    }
    interface StsAccessProperty {
    }
    class StsAccessPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StsAccessProperty | undefined;
        set internalValue(value: StsAccessProperty | undefined);
        get domainName(): string;
        get ipv4Addresses(): string[];
        get status(): string;
        get stsPolicyDocument(): string;
    }
    class StsAccessPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StsAccessPropertyOutputReference;
    }
    interface ZeroEtlAccessProperty {
    }
    class ZeroEtlAccessPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ZeroEtlAccessProperty | undefined;
        set internalValue(value: ZeroEtlAccessProperty | undefined);
        get cidr(): string;
        get status(): string;
    }
    class ZeroEtlAccessPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ZeroEtlAccessPropertyOutputReference;
    }
    interface ManagedServicesProperty {
    }
    class ManagedServicesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ManagedServicesProperty | undefined;
        set internalValue(value: ManagedServicesProperty | undefined);
        private _crossRegionS3RestoreSourcesAccess;
        get crossRegionS3RestoreSourcesAccess(): CrossRegionS3RestoreSourcesAccessPropertyList;
        private _kmsAccess;
        get kmsAccess(): KmsAccessPropertyList;
        private _managedS3BackupAccess;
        get managedS3BackupAccess(): ManagedS3BackupAccessPropertyList;
        get managedServiceIpv4Cidrs(): string[];
        get resourceGatewayArn(): string;
        private _s3Access;
        get s3Access(): S3AccessPropertyList;
        get serviceNetworkArn(): string;
        private _serviceNetworkEndpoint;
        get serviceNetworkEndpoint(): ServiceNetworkEndpointPropertyList;
        private _stsAccess;
        get stsAccess(): StsAccessPropertyList;
        private _zeroEtlAccess;
        get zeroEtlAccess(): ZeroEtlAccessPropertyList;
    }
    class ManagedServicesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ManagedServicesPropertyOutputReference;
    }
    interface OciDnsForwardingConfigsProperty {
    }
    class OciDnsForwardingConfigsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OciDnsForwardingConfigsProperty | undefined;
        set internalValue(value: OciDnsForwardingConfigsProperty | undefined);
        get domainName(): string;
        get ociDnsListenerIp(): string;
    }
    class OciDnsForwardingConfigsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OciDnsForwardingConfigsPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_network#create AwsOdbNetwork#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_network#delete AwsOdbNetwork#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_network#update AwsOdbNetwork#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
