import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsOdbCloudVmClusterConfig extends cdktn.TerraformMetaArguments {
    /**
    * The unique identifier of the Exadata infrastructure for this VM cluster. Changing this will create a new resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_vm_cluster#cloud_exadata_infrastructure_arn AwsOdbCloudVmCluster#cloud_exadata_infrastructure_arn}
    */
    readonly cloudExadataInfrastructureArn?: string;
    /**
    * The unique identifier of the Exadata infrastructure for this VM cluster. Changing this will create a new resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_vm_cluster#cloud_exadata_infrastructure_id AwsOdbCloudVmCluster#cloud_exadata_infrastructure_id}
    */
    readonly cloudExadataInfrastructureId?: string;
    /**
    * The name of the Grid Infrastructure (GI) cluster. Changing this will create a new resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_vm_cluster#cluster_name AwsOdbCloudVmCluster#cluster_name}
    */
    readonly clusterName?: string;
    /**
    * The number of CPU cores to enable on the VM cluster. Changing this will create a new resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_vm_cluster#cpu_core_count AwsOdbCloudVmCluster#cpu_core_count}
    */
    readonly cpuCoreCount: number;
    /**
    * The size of the data disk group, in terabytes (TBs), to allocate for the VM cluster. Changing this will create a new resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_vm_cluster#data_storage_size_in_tbs AwsOdbCloudVmCluster#data_storage_size_in_tbs}
    */
    readonly dataStorageSizeInTbs: number;
    /**
    * The amount of local node storage, in gigabytes (GBs), to allocate for the VM cluster. Changing this will create a new resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_vm_cluster#db_node_storage_size_in_gbs AwsOdbCloudVmCluster#db_node_storage_size_in_gbs}
    */
    readonly dbNodeStorageSizeInGbs?: number;
    /**
    * The list of database servers for the VM cluster. Changing this will create a new resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_vm_cluster#db_servers AwsOdbCloudVmCluster#db_servers}
    */
    readonly dbServers: string[];
    /**
    * A user-friendly name for the VM cluster. This member is required. Changing this will create a new resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_vm_cluster#display_name AwsOdbCloudVmCluster#display_name}
    */
    readonly displayName: string;
    /**
    * A valid software version of Oracle Grid Infrastructure (GI). To get the list of valid values, use the ListGiVersions operation and specify the shape of the Exadata infrastructure. Example: 19.0.0.0 This member is required. Changing this will create a new resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_vm_cluster#gi_version AwsOdbCloudVmCluster#gi_version}
    */
    readonly giVersion: string;
    /**
    * The host name prefix for the VM cluster. Constraints: - Can't be "localhost" or "hostname". - Can't contain "-version". - The maximum length of the combined hostname and domain is 63 characters. - The hostname must be unique within the subnet. This member is required. Changing this will create a new resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_vm_cluster#hostname_prefix AwsOdbCloudVmCluster#hostname_prefix}
    */
    readonly hostnamePrefix: string;
    /**
    * Specifies whether to enable database backups to local Exadata storage for the VM cluster. Changing this will create a new resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_vm_cluster#is_local_backup_enabled AwsOdbCloudVmCluster#is_local_backup_enabled}
    */
    readonly isLocalBackupEnabled?: boolean | cdktn.IResolvable;
    /**
    * Specifies whether to create a sparse disk group for the VM cluster. Changing this will create a new resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_vm_cluster#is_sparse_diskgroup_enabled AwsOdbCloudVmCluster#is_sparse_diskgroup_enabled}
    */
    readonly isSparseDiskgroupEnabled?: boolean | cdktn.IResolvable;
    /**
    * The Oracle license model to apply to the VM cluster. Default: LICENSE_INCLUDED. Changing this will create a new resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_vm_cluster#license_model AwsOdbCloudVmCluster#license_model}
    */
    readonly licenseModel?: string;
    /**
    * The amount of memory, in gigabytes (GBs), to allocate for the VM cluster. Changing this will create a new resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_vm_cluster#memory_size_in_gbs AwsOdbCloudVmCluster#memory_size_in_gbs}
    */
    readonly memorySizeInGbs?: number;
    /**
    * The unique identifier of the ODB network for the VM cluster. This member is required. Changing this will create a new resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_vm_cluster#odb_network_arn AwsOdbCloudVmCluster#odb_network_arn}
    */
    readonly odbNetworkArn?: string;
    /**
    * The unique identifier of the ODB network for the VM cluster. This member is required. Changing this will create a new resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_vm_cluster#odb_network_id AwsOdbCloudVmCluster#odb_network_id}
    */
    readonly odbNetworkId?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_vm_cluster#region AwsOdbCloudVmCluster#region}
    */
    readonly region?: string;
    /**
    * The port number for TCP connections to the single client access name (SCAN) listener. Valid values: 1024–8999 with the following exceptions: 2484 , 6100 , 6200 , 7060, 7070 , 7085 , and 7879Default: 1521. Changing this will create a new resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_vm_cluster#scan_listener_port_tcp AwsOdbCloudVmCluster#scan_listener_port_tcp}
    */
    readonly scanListenerPortTcp?: number;
    /**
    * The public key portion of one or more key pairs used for SSH access to the VM cluster. This member is required. Changing this will create a new resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_vm_cluster#ssh_public_keys AwsOdbCloudVmCluster#ssh_public_keys}
    */
    readonly sshPublicKeys: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_vm_cluster#tags AwsOdbCloudVmCluster#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * The configured time zone of the VM cluster. Changing this will create a new resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_vm_cluster#timezone AwsOdbCloudVmCluster#timezone}
    */
    readonly timezone?: string;
    /**
    * data_collection_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_vm_cluster#data_collection_options AwsOdbCloudVmCluster#data_collection_options}
    */
    readonly dataCollectionOptions?: AwsOdbCloudVmCluster.DataCollectionOptionsProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_vm_cluster#timeouts AwsOdbCloudVmCluster#timeouts}
    */
    readonly timeouts?: AwsOdbCloudVmCluster.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_vm_cluster aws_odb_cloud_vm_cluster}
*/
export declare class AwsOdbCloudVmCluster extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_odb_cloud_vm_cluster";
    /**
    * Generates CDKTN code for importing a AwsOdbCloudVmCluster resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsOdbCloudVmCluster to import
    * @param importFromId The id of the existing AwsOdbCloudVmCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_vm_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsOdbCloudVmCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_vm_cluster aws_odb_cloud_vm_cluster} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsOdbCloudVmClusterConfig
    */
    constructor(scope: Construct, id: string, config: AwsOdbCloudVmClusterConfig);
    get arn(): string;
    private _cloudExadataInfrastructureArn?;
    get cloudExadataInfrastructureArn(): string;
    set cloudExadataInfrastructureArn(value: string);
    resetCloudExadataInfrastructureArn(): void;
    get cloudExadataInfrastructureArnInput(): string | undefined;
    private _cloudExadataInfrastructureId?;
    get cloudExadataInfrastructureId(): string;
    set cloudExadataInfrastructureId(value: string);
    resetCloudExadataInfrastructureId(): void;
    get cloudExadataInfrastructureIdInput(): string | undefined;
    private _clusterName?;
    get clusterName(): string;
    set clusterName(value: string);
    resetClusterName(): void;
    get clusterNameInput(): string | undefined;
    get computeModel(): string;
    private _cpuCoreCount?;
    get cpuCoreCount(): number;
    set cpuCoreCount(value: number);
    get cpuCoreCountInput(): number | undefined;
    get createdAt(): string;
    private _dataStorageSizeInTbs?;
    get dataStorageSizeInTbs(): number;
    set dataStorageSizeInTbs(value: number);
    get dataStorageSizeInTbsInput(): number | undefined;
    private _dbNodeStorageSizeInGbs?;
    get dbNodeStorageSizeInGbs(): number;
    set dbNodeStorageSizeInGbs(value: number);
    resetDbNodeStorageSizeInGbs(): void;
    get dbNodeStorageSizeInGbsInput(): number | undefined;
    private _dbServers?;
    get dbServers(): string[];
    set dbServers(value: string[]);
    get dbServersInput(): string[] | undefined;
    get diskRedundancy(): string;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    get domain(): string;
    private _giVersion?;
    get giVersion(): string;
    set giVersion(value: string);
    get giVersionInput(): string | undefined;
    get giVersionComputed(): string;
    private _hostnamePrefix?;
    get hostnamePrefix(): string;
    set hostnamePrefix(value: string);
    get hostnamePrefixInput(): string | undefined;
    get hostnamePrefixComputed(): string;
    get id(): string;
    private _iormConfigCache;
    get iormConfigCache(): AwsOdbCloudVmCluster.IormConfigCachePropertyList;
    private _isLocalBackupEnabled?;
    get isLocalBackupEnabled(): boolean | cdktn.IResolvable;
    set isLocalBackupEnabled(value: boolean | cdktn.IResolvable);
    resetIsLocalBackupEnabled(): void;
    get isLocalBackupEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _isSparseDiskgroupEnabled?;
    get isSparseDiskgroupEnabled(): boolean | cdktn.IResolvable;
    set isSparseDiskgroupEnabled(value: boolean | cdktn.IResolvable);
    resetIsSparseDiskgroupEnabled(): void;
    get isSparseDiskgroupEnabledInput(): boolean | cdktn.IResolvable | undefined;
    get lastUpdateHistoryEntryId(): string;
    private _licenseModel?;
    get licenseModel(): string;
    set licenseModel(value: string);
    resetLicenseModel(): void;
    get licenseModelInput(): string | undefined;
    get listenerPort(): number;
    private _memorySizeInGbs?;
    get memorySizeInGbs(): number;
    set memorySizeInGbs(value: number);
    resetMemorySizeInGbs(): void;
    get memorySizeInGbsInput(): number | undefined;
    get nodeCount(): number;
    get ociResourceAnchorName(): string;
    get ociUrl(): string;
    get ocid(): string;
    private _odbNetworkArn?;
    get odbNetworkArn(): string;
    set odbNetworkArn(value: string);
    resetOdbNetworkArn(): void;
    get odbNetworkArnInput(): string | undefined;
    private _odbNetworkId?;
    get odbNetworkId(): string;
    set odbNetworkId(value: string);
    resetOdbNetworkId(): void;
    get odbNetworkIdInput(): string | undefined;
    get percentProgress(): number;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get scanDnsName(): string;
    get scanDnsRecordId(): string;
    get scanIpIds(): string[];
    private _scanListenerPortTcp?;
    get scanListenerPortTcp(): number;
    set scanListenerPortTcp(value: number);
    resetScanListenerPortTcp(): void;
    get scanListenerPortTcpInput(): number | undefined;
    get shape(): string;
    private _sshPublicKeys?;
    get sshPublicKeys(): string[];
    set sshPublicKeys(value: string[]);
    get sshPublicKeysInput(): string[] | undefined;
    get status(): string;
    get statusReason(): string;
    get storageSizeInGbs(): number;
    get systemVersion(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _timezone?;
    get timezone(): string;
    set timezone(value: string);
    resetTimezone(): void;
    get timezoneInput(): string | undefined;
    get vipIds(): string[];
    private _dataCollectionOptions;
    get dataCollectionOptions(): AwsOdbCloudVmCluster.DataCollectionOptionsPropertyList;
    putDataCollectionOptions(value: AwsOdbCloudVmCluster.DataCollectionOptionsProperty[] | cdktn.IResolvable): void;
    resetDataCollectionOptions(): void;
    get dataCollectionOptionsInput(): cdktn.IResolvable | AwsOdbCloudVmCluster.DataCollectionOptionsProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsOdbCloudVmCluster.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsOdbCloudVmCluster.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsOdbCloudVmCluster.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsOdbCloudVmClusterDbPlansPropertyToTerraform(struct?: AwsOdbCloudVmCluster.DbPlansProperty): any;
export declare function awsOdbCloudVmClusterDbPlansPropertyToHclTerraform(struct?: AwsOdbCloudVmCluster.DbPlansProperty): any;
export declare function awsOdbCloudVmClusterIormConfigCachePropertyToTerraform(struct?: AwsOdbCloudVmCluster.IormConfigCacheProperty): any;
export declare function awsOdbCloudVmClusterIormConfigCachePropertyToHclTerraform(struct?: AwsOdbCloudVmCluster.IormConfigCacheProperty): any;
export declare function awsOdbCloudVmClusterDataCollectionOptionsPropertyToTerraform(struct?: AwsOdbCloudVmCluster.DataCollectionOptionsProperty | cdktn.IResolvable): any;
export declare function awsOdbCloudVmClusterDataCollectionOptionsPropertyToHclTerraform(struct?: AwsOdbCloudVmCluster.DataCollectionOptionsProperty | cdktn.IResolvable): any;
export declare function awsOdbCloudVmClusterTimeoutsPropertyToTerraform(struct?: AwsOdbCloudVmCluster.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsOdbCloudVmClusterTimeoutsPropertyToHclTerraform(struct?: AwsOdbCloudVmCluster.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsOdbCloudVmCluster {
    interface DbPlansProperty {
    }
    class DbPlansPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DbPlansProperty | undefined;
        set internalValue(value: DbPlansProperty | undefined);
        get dbName(): string;
        get flashCacheLimit(): string;
        get share(): number;
    }
    class DbPlansPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DbPlansPropertyOutputReference;
    }
    interface IormConfigCacheProperty {
    }
    class IormConfigCachePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IormConfigCacheProperty | undefined;
        set internalValue(value: IormConfigCacheProperty | undefined);
        private _dbPlans;
        get dbPlans(): DbPlansPropertyList;
        get lifecycleDetails(): string;
        get lifecycleState(): string;
        get objective(): string;
    }
    class IormConfigCachePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IormConfigCachePropertyOutputReference;
    }
    interface DataCollectionOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_vm_cluster#is_diagnostics_events_enabled AwsOdbCloudVmCluster#is_diagnostics_events_enabled}
        */
        readonly isDiagnosticsEventsEnabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_vm_cluster#is_health_monitoring_enabled AwsOdbCloudVmCluster#is_health_monitoring_enabled}
        */
        readonly isHealthMonitoringEnabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_vm_cluster#is_incident_logs_enabled AwsOdbCloudVmCluster#is_incident_logs_enabled}
        */
        readonly isIncidentLogsEnabled: boolean | cdktn.IResolvable;
    }
    class DataCollectionOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataCollectionOptionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DataCollectionOptionsProperty | cdktn.IResolvable | undefined);
        private _isDiagnosticsEventsEnabled?;
        get isDiagnosticsEventsEnabled(): boolean | cdktn.IResolvable;
        set isDiagnosticsEventsEnabled(value: boolean | cdktn.IResolvable);
        get isDiagnosticsEventsEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _isHealthMonitoringEnabled?;
        get isHealthMonitoringEnabled(): boolean | cdktn.IResolvable;
        set isHealthMonitoringEnabled(value: boolean | cdktn.IResolvable);
        get isHealthMonitoringEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _isIncidentLogsEnabled?;
        get isIncidentLogsEnabled(): boolean | cdktn.IResolvable;
        set isIncidentLogsEnabled(value: boolean | cdktn.IResolvable);
        get isIncidentLogsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    class DataCollectionOptionsPropertyList extends cdktn.ComplexList {
        internalValue?: DataCollectionOptionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataCollectionOptionsPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_vm_cluster#create AwsOdbCloudVmCluster#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_vm_cluster#delete AwsOdbCloudVmCluster#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_vm_cluster#update AwsOdbCloudVmCluster#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
