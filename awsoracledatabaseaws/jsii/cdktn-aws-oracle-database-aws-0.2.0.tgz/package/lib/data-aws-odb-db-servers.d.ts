import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfDbServersConfig extends cdktn.TerraformMetaArguments {
    /**
    * The cloud exadata infrastructure ID. Mandatory field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_db_servers#cloud_exadata_infrastructure_id DataTfDbServers#cloud_exadata_infrastructure_id}
    */
    readonly cloudExadataInfrastructureId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_db_servers#region DataTfDbServers#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_db_servers aws_odb_db_servers}
*/
export declare class DataTfDbServers extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_odb_db_servers";
    /**
    * Generates CDKTN code for importing a DataTfDbServers resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfDbServers to import
    * @param importFromId The id of the existing DataTfDbServers that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_db_servers#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfDbServers to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_db_servers aws_odb_db_servers} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfDbServersConfig
    */
    constructor(scope: Construct, id: string, config: DataTfDbServersConfig);
    private _cloudExadataInfrastructureId?;
    get cloudExadataInfrastructureId(): string;
    set cloudExadataInfrastructureId(value: string);
    get cloudExadataInfrastructureIdInput(): string | undefined;
    private _dbServers;
    get dbServers(): DataTfDbServers.DbServersPropertyList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfDbServersDbServerPatchingDetailsPropertyToTerraform(struct?: DataTfDbServers.DbServerPatchingDetailsProperty): any;
export declare function dataTfDbServersDbServerPatchingDetailsPropertyToHclTerraform(struct?: DataTfDbServers.DbServerPatchingDetailsProperty): any;
export declare function dataTfDbServersDbServersPropertyToTerraform(struct?: DataTfDbServers.DbServersProperty): any;
export declare function dataTfDbServersDbServersPropertyToHclTerraform(struct?: DataTfDbServers.DbServersProperty): any;
export declare namespace DataTfDbServers {
    interface DbServerPatchingDetailsProperty {
    }
    class DbServerPatchingDetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DbServerPatchingDetailsProperty | undefined;
        set internalValue(value: DbServerPatchingDetailsProperty | undefined);
        get estimatedPatchDuration(): number;
        get patchingStatus(): string;
        get timePatchingEnded(): string;
        get timePatchingStarted(): string;
    }
    class DbServerPatchingDetailsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DbServerPatchingDetailsPropertyOutputReference;
    }
    interface DbServersProperty {
    }
    class DbServersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DbServersProperty | undefined;
        set internalValue(value: DbServersProperty | undefined);
        get autonomousVirtualMachineIds(): string[];
        get autonomousVmClusterIds(): string[];
        get computeModel(): string;
        get cpuCoreCount(): number;
        get createdAt(): string;
        get dbNodeStorageSizeInGbs(): number;
        private _dbServerPatchingDetails;
        get dbServerPatchingDetails(): DbServerPatchingDetailsPropertyList;
        get displayName(): string;
        get exadataInfrastructureId(): string;
        get id(): string;
        get maxCpuCount(): number;
        get maxDbNodeStorageInGbs(): number;
        get maxMemoryInGbs(): number;
        get memorySizeInGbs(): number;
        get ociResourceAnchorName(): string;
        get ocid(): string;
        get shape(): string;
        get status(): string;
        get statusReason(): string;
        get vmClusterIds(): string[];
    }
    class DbServersPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DbServersPropertyOutputReference;
    }
}
