import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfCloudExadataInfrastructureConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the Availability Zone (AZ) where the Exadata infrastructure is located. Changing this will force terraform to create new resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_exadata_infrastructure#availability_zone TfCloudExadataInfrastructure#availability_zone}
    */
    readonly availabilityZone?: string;
    /**
    *  The AZ ID of the AZ where the Exadata infrastructure is located. Changing this will force terraform to create new resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_exadata_infrastructure#availability_zone_id TfCloudExadataInfrastructure#availability_zone_id}
    */
    readonly availabilityZoneId: string;
    /**
    *  The number of compute instances that the Exadata infrastructure is located
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_exadata_infrastructure#compute_count TfCloudExadataInfrastructure#compute_count}
    */
    readonly computeCount?: number;
    /**
    * The email addresses of contacts to receive notification from Oracle about maintenance updates for the Exadata infrastructure. Changing this will force terraform to create new resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_exadata_infrastructure#customer_contacts_to_send_to_oci TfCloudExadataInfrastructure#customer_contacts_to_send_to_oci}
    */
    readonly customerContactsToSendToOci?: TfCloudExadataInfrastructure.CustomerContactsToSendToOciProperty[] | cdktn.IResolvable;
    /**
    * The database server model type of the Exadata infrastructure. For the list of valid model names, use the ListDbSystemShapes operation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_exadata_infrastructure#database_server_type TfCloudExadataInfrastructure#database_server_type}
    */
    readonly databaseServerType?: string;
    /**
    * The user-friendly name for the Exadata infrastructure. Changing this will force terraform to create a new resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_exadata_infrastructure#display_name TfCloudExadataInfrastructure#display_name}
    */
    readonly displayName: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_exadata_infrastructure#region TfCloudExadataInfrastructure#region}
    */
    readonly region?: string;
    /**
    * The model name of the Exadata infrastructure. Changing this will force terraform to create new resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_exadata_infrastructure#shape TfCloudExadataInfrastructure#shape}
    */
    readonly shape: string;
    /**
    * TThe number of storage servers that are activated for the Exadata infrastructure
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_exadata_infrastructure#storage_count TfCloudExadataInfrastructure#storage_count}
    */
    readonly storageCount?: number;
    /**
    * The storage server model type of the Exadata infrastructure. For the list of valid model names, use the ListDbSystemShapes operation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_exadata_infrastructure#storage_server_type TfCloudExadataInfrastructure#storage_server_type}
    */
    readonly storageServerType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_exadata_infrastructure#tags TfCloudExadataInfrastructure#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * maintenance_window block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_exadata_infrastructure#maintenance_window TfCloudExadataInfrastructure#maintenance_window}
    */
    readonly maintenanceWindow?: TfCloudExadataInfrastructure.MaintenanceWindowProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_exadata_infrastructure#timeouts TfCloudExadataInfrastructure#timeouts}
    */
    readonly timeouts?: TfCloudExadataInfrastructure.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_exadata_infrastructure aws_odb_cloud_exadata_infrastructure}
*/
export declare class TfCloudExadataInfrastructure extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_odb_cloud_exadata_infrastructure";
    /**
    * Generates CDKTN code for importing a TfCloudExadataInfrastructure resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfCloudExadataInfrastructure to import
    * @param importFromId The id of the existing TfCloudExadataInfrastructure that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_exadata_infrastructure#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfCloudExadataInfrastructure to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_exadata_infrastructure aws_odb_cloud_exadata_infrastructure} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfCloudExadataInfrastructureConfig
    */
    constructor(scope: Construct, id: string, config: TfCloudExadataInfrastructureConfig);
    get activatedStorageCount(): number;
    get additionalStorageCount(): number;
    get arn(): string;
    private _availabilityZone?;
    get availabilityZone(): string;
    set availabilityZone(value: string);
    resetAvailabilityZone(): void;
    get availabilityZoneInput(): string | undefined;
    private _availabilityZoneId?;
    get availabilityZoneId(): string;
    set availabilityZoneId(value: string);
    get availabilityZoneIdInput(): string | undefined;
    get availableStorageSizeInGbs(): number;
    private _computeCount?;
    get computeCount(): number;
    set computeCount(value: number);
    resetComputeCount(): void;
    get computeCountInput(): number | undefined;
    get computeModel(): string;
    get cpuCount(): number;
    get createdAt(): string;
    private _customerContactsToSendToOci;
    get customerContactsToSendToOci(): TfCloudExadataInfrastructure.CustomerContactsToSendToOciPropertyList;
    putCustomerContactsToSendToOci(value: TfCloudExadataInfrastructure.CustomerContactsToSendToOciProperty[] | cdktn.IResolvable): void;
    resetCustomerContactsToSendToOci(): void;
    get customerContactsToSendToOciInput(): cdktn.IResolvable | TfCloudExadataInfrastructure.CustomerContactsToSendToOciProperty[] | undefined;
    get dataStorageSizeInTbs(): number;
    private _databaseServerType?;
    get databaseServerType(): string;
    set databaseServerType(value: string);
    resetDatabaseServerType(): void;
    get databaseServerTypeInput(): string | undefined;
    get dbNodeStorageSizeInGbs(): number;
    get dbServerVersion(): string;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    get id(): string;
    get lastMaintenanceRunId(): string;
    get maxCpuCount(): number;
    get maxDataStorageInTbs(): number;
    get maxDbNodeStorageSizeInGbs(): number;
    get maxMemoryInGbs(): number;
    get memorySizeInGbs(): number;
    get monthlyDbServerVersion(): string;
    get monthlyStorageServerVersion(): string;
    get nextMaintenanceRunId(): string;
    get ociResourceAnchorName(): string;
    get ociUrl(): string;
    get ocid(): string;
    get percentProgress(): number;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _shape?;
    get shape(): string;
    set shape(value: string);
    get shapeInput(): string | undefined;
    get status(): string;
    get statusReason(): string;
    private _storageCount?;
    get storageCount(): number;
    set storageCount(value: number);
    resetStorageCount(): void;
    get storageCountInput(): number | undefined;
    private _storageServerType?;
    get storageServerType(): string;
    set storageServerType(value: string);
    resetStorageServerType(): void;
    get storageServerTypeInput(): string | undefined;
    get storageServerVersion(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    get totalStorageSizeInGbs(): number;
    private _maintenanceWindow;
    get maintenanceWindow(): TfCloudExadataInfrastructure.MaintenanceWindowPropertyList;
    putMaintenanceWindow(value: TfCloudExadataInfrastructure.MaintenanceWindowProperty[] | cdktn.IResolvable): void;
    resetMaintenanceWindow(): void;
    get maintenanceWindowInput(): cdktn.IResolvable | TfCloudExadataInfrastructure.MaintenanceWindowProperty[] | undefined;
    private _timeouts;
    get timeouts(): TfCloudExadataInfrastructure.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfCloudExadataInfrastructure.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfCloudExadataInfrastructure.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfCloudExadataInfrastructureCustomerContactsToSendToOciPropertyToTerraform(struct?: TfCloudExadataInfrastructure.CustomerContactsToSendToOciProperty | cdktn.IResolvable): any;
export declare function tfCloudExadataInfrastructureCustomerContactsToSendToOciPropertyToHclTerraform(struct?: TfCloudExadataInfrastructure.CustomerContactsToSendToOciProperty | cdktn.IResolvable): any;
export declare function tfCloudExadataInfrastructureDaysOfWeekPropertyToTerraform(struct?: TfCloudExadataInfrastructure.DaysOfWeekProperty | cdktn.IResolvable): any;
export declare function tfCloudExadataInfrastructureDaysOfWeekPropertyToHclTerraform(struct?: TfCloudExadataInfrastructure.DaysOfWeekProperty | cdktn.IResolvable): any;
export declare function tfCloudExadataInfrastructureMonthsPropertyToTerraform(struct?: TfCloudExadataInfrastructure.MonthsProperty | cdktn.IResolvable): any;
export declare function tfCloudExadataInfrastructureMonthsPropertyToHclTerraform(struct?: TfCloudExadataInfrastructure.MonthsProperty | cdktn.IResolvable): any;
export declare function tfCloudExadataInfrastructureMaintenanceWindowPropertyToTerraform(struct?: TfCloudExadataInfrastructure.MaintenanceWindowProperty | cdktn.IResolvable): any;
export declare function tfCloudExadataInfrastructureMaintenanceWindowPropertyToHclTerraform(struct?: TfCloudExadataInfrastructure.MaintenanceWindowProperty | cdktn.IResolvable): any;
export declare function tfCloudExadataInfrastructureTimeoutsPropertyToTerraform(struct?: TfCloudExadataInfrastructure.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfCloudExadataInfrastructureTimeoutsPropertyToHclTerraform(struct?: TfCloudExadataInfrastructure.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfCloudExadataInfrastructure {
    interface CustomerContactsToSendToOciProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_exadata_infrastructure#email TfCloudExadataInfrastructure#email}
        */
        readonly email?: string;
    }
    class CustomerContactsToSendToOciPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomerContactsToSendToOciProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CustomerContactsToSendToOciProperty | cdktn.IResolvable | undefined);
        private _email?;
        get email(): string;
        set email(value: string);
        resetEmail(): void;
        get emailInput(): string | undefined;
    }
    class CustomerContactsToSendToOciPropertyList extends cdktn.ComplexList {
        internalValue?: CustomerContactsToSendToOciProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomerContactsToSendToOciPropertyOutputReference;
    }
    interface DaysOfWeekProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_exadata_infrastructure#name TfCloudExadataInfrastructure#name}
        */
        readonly name?: string;
    }
    class DaysOfWeekPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DaysOfWeekProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DaysOfWeekProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
    }
    class DaysOfWeekPropertyList extends cdktn.ComplexList {
        internalValue?: DaysOfWeekProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DaysOfWeekPropertyOutputReference;
    }
    interface MonthsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_exadata_infrastructure#name TfCloudExadataInfrastructure#name}
        */
        readonly name?: string;
    }
    class MonthsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MonthsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MonthsProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
    }
    class MonthsPropertyList extends cdktn.ComplexList {
        internalValue?: MonthsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MonthsPropertyOutputReference;
    }
    interface MaintenanceWindowProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_exadata_infrastructure#custom_action_timeout_in_mins TfCloudExadataInfrastructure#custom_action_timeout_in_mins}
        */
        readonly customActionTimeoutInMins: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_exadata_infrastructure#days_of_week TfCloudExadataInfrastructure#days_of_week}
        */
        readonly daysOfWeek?: DaysOfWeekProperty[] | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_exadata_infrastructure#hours_of_day TfCloudExadataInfrastructure#hours_of_day}
        */
        readonly hoursOfDay?: number[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_exadata_infrastructure#is_custom_action_timeout_enabled TfCloudExadataInfrastructure#is_custom_action_timeout_enabled}
        */
        readonly isCustomActionTimeoutEnabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_exadata_infrastructure#lead_time_in_weeks TfCloudExadataInfrastructure#lead_time_in_weeks}
        */
        readonly leadTimeInWeeks?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_exadata_infrastructure#months TfCloudExadataInfrastructure#months}
        */
        readonly months?: MonthsProperty[] | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_exadata_infrastructure#patching_mode TfCloudExadataInfrastructure#patching_mode}
        */
        readonly patchingMode: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_exadata_infrastructure#preference TfCloudExadataInfrastructure#preference}
        */
        readonly preference: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_exadata_infrastructure#weeks_of_month TfCloudExadataInfrastructure#weeks_of_month}
        */
        readonly weeksOfMonth?: number[];
    }
    class MaintenanceWindowPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MaintenanceWindowProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MaintenanceWindowProperty | cdktn.IResolvable | undefined);
        private _customActionTimeoutInMins?;
        get customActionTimeoutInMins(): number;
        set customActionTimeoutInMins(value: number);
        get customActionTimeoutInMinsInput(): number | undefined;
        private _daysOfWeek;
        get daysOfWeek(): DaysOfWeekPropertyList;
        putDaysOfWeek(value: DaysOfWeekProperty[] | cdktn.IResolvable): void;
        resetDaysOfWeek(): void;
        get daysOfWeekInput(): cdktn.IResolvable | DaysOfWeekProperty[] | undefined;
        private _hoursOfDay?;
        get hoursOfDay(): number[];
        set hoursOfDay(value: number[]);
        resetHoursOfDay(): void;
        get hoursOfDayInput(): number[] | undefined;
        private _isCustomActionTimeoutEnabled?;
        get isCustomActionTimeoutEnabled(): boolean | cdktn.IResolvable;
        set isCustomActionTimeoutEnabled(value: boolean | cdktn.IResolvable);
        get isCustomActionTimeoutEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _leadTimeInWeeks?;
        get leadTimeInWeeks(): number;
        set leadTimeInWeeks(value: number);
        resetLeadTimeInWeeks(): void;
        get leadTimeInWeeksInput(): number | undefined;
        private _months;
        get months(): MonthsPropertyList;
        putMonths(value: MonthsProperty[] | cdktn.IResolvable): void;
        resetMonths(): void;
        get monthsInput(): cdktn.IResolvable | MonthsProperty[] | undefined;
        private _patchingMode?;
        get patchingMode(): string;
        set patchingMode(value: string);
        get patchingModeInput(): string | undefined;
        private _preference?;
        get preference(): string;
        set preference(value: string);
        get preferenceInput(): string | undefined;
        private _weeksOfMonth?;
        get weeksOfMonth(): number[];
        set weeksOfMonth(value: number[]);
        resetWeeksOfMonth(): void;
        get weeksOfMonthInput(): number[] | undefined;
    }
    class MaintenanceWindowPropertyList extends cdktn.ComplexList {
        internalValue?: MaintenanceWindowProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MaintenanceWindowPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_exadata_infrastructure#create TfCloudExadataInfrastructure#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_exadata_infrastructure#delete TfCloudExadataInfrastructure#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/odb_cloud_exadata_infrastructure#update TfCloudExadataInfrastructure#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
