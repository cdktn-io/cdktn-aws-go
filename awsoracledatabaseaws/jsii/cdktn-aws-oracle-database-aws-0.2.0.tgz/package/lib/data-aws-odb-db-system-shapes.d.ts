import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfDbSystemShapesConfig extends cdktn.TerraformMetaArguments {
    /**
    * The physical ID of the AZ, for example, use1-az4. This ID persists across accounts.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_db_system_shapes#availability_zone_id DataTfDbSystemShapes#availability_zone_id}
    */
    readonly availabilityZoneId?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_db_system_shapes#region DataTfDbSystemShapes#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_db_system_shapes aws_odb_db_system_shapes}
*/
export declare class DataTfDbSystemShapes extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_odb_db_system_shapes";
    /**
    * Generates CDKTN code for importing a DataTfDbSystemShapes resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfDbSystemShapes to import
    * @param importFromId The id of the existing DataTfDbSystemShapes that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_db_system_shapes#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfDbSystemShapes to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_db_system_shapes aws_odb_db_system_shapes} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfDbSystemShapesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataTfDbSystemShapesConfig);
    private _availabilityZoneId?;
    get availabilityZoneId(): string;
    set availabilityZoneId(value: string);
    resetAvailabilityZoneId(): void;
    get availabilityZoneIdInput(): string | undefined;
    private _dbSystemShapes;
    get dbSystemShapes(): DataTfDbSystemShapes.DbSystemShapesPropertyList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfDbSystemShapesDbSystemShapesPropertyToTerraform(struct?: DataTfDbSystemShapes.DbSystemShapesProperty): any;
export declare function dataTfDbSystemShapesDbSystemShapesPropertyToHclTerraform(struct?: DataTfDbSystemShapes.DbSystemShapesProperty): any;
export declare namespace DataTfDbSystemShapes {
    interface DbSystemShapesProperty {
    }
    class DbSystemShapesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DbSystemShapesProperty | undefined;
        set internalValue(value: DbSystemShapesProperty | undefined);
        get availableCoreCount(): number;
        get availableCoreCountPerNode(): number;
        get availableDataStorageInTbs(): number;
        get availableDataStoragePerServerInTbs(): number;
        get availableDbNodePerNodeInGbs(): number;
        get availableDbNodeStorageInGbs(): number;
        get availableMemoryInGbs(): number;
        get availableMemoryPerNodeInGbs(): number;
        get coreCountIncrement(): number;
        get maxStorageCount(): number;
        get maximumNodeCount(): number;
        get minCoreCountPerNode(): number;
        get minDataStorageInTbs(): number;
        get minDbNodeStoragePerNodeInGbs(): number;
        get minMemoryPerNodeInGbs(): number;
        get minStorageCount(): number;
        get minimumCoreCount(): number;
        get minimumNodeCount(): number;
        get name(): string;
        get runtimeMinimumCoreCount(): number;
        get shapeFamily(): string;
        get shapeType(): string;
    }
    class DbSystemShapesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DbSystemShapesPropertyOutputReference;
    }
}
