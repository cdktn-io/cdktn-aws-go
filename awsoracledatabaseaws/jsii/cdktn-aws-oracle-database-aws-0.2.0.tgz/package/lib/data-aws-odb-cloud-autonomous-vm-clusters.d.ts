import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfCloudAutonomousVmClustersConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_cloud_autonomous_vm_clusters#region DataTfCloudAutonomousVmClusters#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_cloud_autonomous_vm_clusters aws_odb_cloud_autonomous_vm_clusters}
*/
export declare class DataTfCloudAutonomousVmClusters extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_odb_cloud_autonomous_vm_clusters";
    /**
    * Generates CDKTN code for importing a DataTfCloudAutonomousVmClusters resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfCloudAutonomousVmClusters to import
    * @param importFromId The id of the existing DataTfCloudAutonomousVmClusters that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_cloud_autonomous_vm_clusters#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfCloudAutonomousVmClusters to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_cloud_autonomous_vm_clusters aws_odb_cloud_autonomous_vm_clusters} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfCloudAutonomousVmClustersConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataTfCloudAutonomousVmClustersConfig);
    private _cloudAutonomousVmClusters;
    get cloudAutonomousVmClusters(): DataTfCloudAutonomousVmClusters.CloudAutonomousVmClustersPropertyList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfCloudAutonomousVmClustersCloudAutonomousVmClustersPropertyToTerraform(struct?: DataTfCloudAutonomousVmClusters.CloudAutonomousVmClustersProperty): any;
export declare function dataTfCloudAutonomousVmClustersCloudAutonomousVmClustersPropertyToHclTerraform(struct?: DataTfCloudAutonomousVmClusters.CloudAutonomousVmClustersProperty): any;
export declare namespace DataTfCloudAutonomousVmClusters {
    interface CloudAutonomousVmClustersProperty {
    }
    class CloudAutonomousVmClustersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CloudAutonomousVmClustersProperty | undefined;
        set internalValue(value: CloudAutonomousVmClustersProperty | undefined);
        get arn(): string;
        get cloudExadataInfrastructureId(): string;
        get displayName(): string;
        get id(): string;
        get ociResourceAnchorName(): string;
        get ociUrl(): string;
        get ocid(): string;
        get odbNetworkId(): string;
    }
    class CloudAutonomousVmClustersPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CloudAutonomousVmClustersPropertyOutputReference;
    }
}
