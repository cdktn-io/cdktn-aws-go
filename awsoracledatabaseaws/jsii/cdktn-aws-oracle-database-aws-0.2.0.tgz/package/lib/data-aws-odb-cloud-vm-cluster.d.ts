import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfCloudVmClusterConfig extends cdktn.TerraformMetaArguments {
    /**
    * The unique identifier of the VM cluster.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_cloud_vm_cluster#id DataTfCloudVmCluster#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_cloud_vm_cluster#region DataTfCloudVmCluster#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_cloud_vm_cluster aws_odb_cloud_vm_cluster}
*/
export declare class DataTfCloudVmCluster extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_odb_cloud_vm_cluster";
    /**
    * Generates CDKTN code for importing a DataTfCloudVmCluster resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfCloudVmCluster to import
    * @param importFromId The id of the existing DataTfCloudVmCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_cloud_vm_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfCloudVmCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_cloud_vm_cluster aws_odb_cloud_vm_cluster} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfCloudVmClusterConfig
    */
    constructor(scope: Construct, id: string, config: DataTfCloudVmClusterConfig);
    get arn(): string;
    get cloudExadataInfrastructureArn(): string;
    get cloudExadataInfrastructureId(): string;
    get clusterName(): string;
    get computeModel(): string;
    get cpuCoreCount(): number;
    get createdAt(): string;
    private _dataCollectionOptions;
    get dataCollectionOptions(): DataTfCloudVmCluster.DataCollectionOptionsPropertyList;
    get dataStorageSizeInTbs(): number;
    get dbNodeStorageSizeInGbs(): number;
    get dbServers(): string[];
    get diskRedundancy(): string;
    get displayName(): string;
    get domain(): string;
    get giVersion(): string;
    get hostnamePrefixComputed(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _iormConfigCache;
    get iormConfigCache(): DataTfCloudVmCluster.IormConfigCachePropertyList;
    get isLocalBackupEnabled(): cdktn.IResolvable;
    get isSparseDiskGroupEnabled(): cdktn.IResolvable;
    get lastUpdateHistoryEntryId(): string;
    get licenseModel(): string;
    get listenerPort(): number;
    get memorySizeInGbs(): number;
    get nodeCount(): number;
    get ociResourceAnchorName(): string;
    get ociUrl(): string;
    get ocid(): string;
    get odbNetworkArn(): string;
    get odbNetworkId(): string;
    get percentProgress(): number;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get scanDnsName(): string;
    get scanDnsRecordId(): string;
    get scanIpIds(): string[];
    get shape(): string;
    get sshPublicKeys(): string[];
    get status(): string;
    get statusReason(): string;
    get storageSizeInGbs(): number;
    get systemVersion(): string;
    private _tags;
    get tags(): cdktn.StringMap;
    get timezone(): string;
    get vipIds(): string[];
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfCloudVmClusterDataCollectionOptionsPropertyToTerraform(struct?: DataTfCloudVmCluster.DataCollectionOptionsProperty): any;
export declare function dataTfCloudVmClusterDataCollectionOptionsPropertyToHclTerraform(struct?: DataTfCloudVmCluster.DataCollectionOptionsProperty): any;
export declare function dataTfCloudVmClusterDbPlansPropertyToTerraform(struct?: DataTfCloudVmCluster.DbPlansProperty): any;
export declare function dataTfCloudVmClusterDbPlansPropertyToHclTerraform(struct?: DataTfCloudVmCluster.DbPlansProperty): any;
export declare function dataTfCloudVmClusterIormConfigCachePropertyToTerraform(struct?: DataTfCloudVmCluster.IormConfigCacheProperty): any;
export declare function dataTfCloudVmClusterIormConfigCachePropertyToHclTerraform(struct?: DataTfCloudVmCluster.IormConfigCacheProperty): any;
export declare namespace DataTfCloudVmCluster {
    interface DataCollectionOptionsProperty {
    }
    class DataCollectionOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataCollectionOptionsProperty | undefined;
        set internalValue(value: DataCollectionOptionsProperty | undefined);
        get isDiagnosticsEventsEnabled(): cdktn.IResolvable;
        get isHealthMonitoringEnabled(): cdktn.IResolvable;
        get isIncidentLogsEnabled(): cdktn.IResolvable;
    }
    class DataCollectionOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataCollectionOptionsPropertyOutputReference;
    }
    interface DbPlansProperty {
    }
    class DbPlansPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DbPlansProperty | undefined;
        set internalValue(value: DbPlansProperty | undefined);
        get dbName(): string;
        get flashCacheLimit(): string;
        get share(): number;
    }
    class DbPlansPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DbPlansPropertyOutputReference;
    }
    interface IormConfigCacheProperty {
    }
    class IormConfigCachePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IormConfigCacheProperty | undefined;
        set internalValue(value: IormConfigCacheProperty | undefined);
        private _dbPlans;
        get dbPlans(): DbPlansPropertyList;
        get lifecycleDetails(): string;
        get lifecycleState(): string;
        get objective(): string;
    }
    class IormConfigCachePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IormConfigCachePropertyOutputReference;
    }
}
