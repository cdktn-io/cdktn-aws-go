import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfGiVersionsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_gi_versions#region DataTfGiVersions#region}
    */
    readonly region?: string;
    /**
    * The system shape.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_gi_versions#shape DataTfGiVersions#shape}
    */
    readonly shape?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_gi_versions aws_odb_gi_versions}
*/
export declare class DataTfGiVersions extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_odb_gi_versions";
    /**
    * Generates CDKTN code for importing a DataTfGiVersions resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfGiVersions to import
    * @param importFromId The id of the existing DataTfGiVersions that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_gi_versions#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfGiVersions to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_gi_versions aws_odb_gi_versions} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfGiVersionsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataTfGiVersionsConfig);
    private _giVersions;
    get giVersions(): DataTfGiVersions.GiVersionsPropertyList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _shape?;
    get shape(): string;
    set shape(value: string);
    resetShape(): void;
    get shapeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfGiVersionsGiVersionsPropertyToTerraform(struct?: DataTfGiVersions.GiVersionsProperty): any;
export declare function dataTfGiVersionsGiVersionsPropertyToHclTerraform(struct?: DataTfGiVersions.GiVersionsProperty): any;
export declare namespace DataTfGiVersions {
    interface GiVersionsProperty {
    }
    class GiVersionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GiVersionsProperty | undefined;
        set internalValue(value: GiVersionsProperty | undefined);
        get version(): string;
    }
    class GiVersionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GiVersionsPropertyOutputReference;
    }
}
