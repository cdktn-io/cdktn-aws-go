import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfNetworkPeeringConnectionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Network Peering Connection identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_network_peering_connection#id DataTfNetworkPeeringConnection#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_network_peering_connection#region DataTfNetworkPeeringConnection#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_network_peering_connection aws_odb_network_peering_connection}
*/
export declare class DataTfNetworkPeeringConnection extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_odb_network_peering_connection";
    /**
    * Generates CDKTN code for importing a DataTfNetworkPeeringConnection resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfNetworkPeeringConnection to import
    * @param importFromId The id of the existing DataTfNetworkPeeringConnection that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_network_peering_connection#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfNetworkPeeringConnection to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_network_peering_connection aws_odb_network_peering_connection} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfNetworkPeeringConnectionConfig
    */
    constructor(scope: Construct, id: string, config: DataTfNetworkPeeringConnectionConfig);
    get arn(): string;
    get createdAt(): string;
    get displayName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get odbNetworkArn(): string;
    get odbPeeringConnectionType(): string;
    get peerNetworkArn(): string;
    get peerNetworkCidrs(): string[];
    get percentProgress(): number;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    get statusReason(): string;
    private _tags;
    get tags(): cdktn.StringMap;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
