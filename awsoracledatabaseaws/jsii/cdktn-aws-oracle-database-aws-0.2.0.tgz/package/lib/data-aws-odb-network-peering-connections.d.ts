import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfNetworkPeeringConnectionsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_network_peering_connections#region DataTfNetworkPeeringConnections#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_network_peering_connections aws_odb_network_peering_connections}
*/
export declare class DataTfNetworkPeeringConnections extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_odb_network_peering_connections";
    /**
    * Generates CDKTN code for importing a DataTfNetworkPeeringConnections resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfNetworkPeeringConnections to import
    * @param importFromId The id of the existing DataTfNetworkPeeringConnections that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_network_peering_connections#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfNetworkPeeringConnections to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_network_peering_connections aws_odb_network_peering_connections} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfNetworkPeeringConnectionsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataTfNetworkPeeringConnectionsConfig);
    private _odbPeeringConnections;
    get odbPeeringConnections(): DataTfNetworkPeeringConnections.OdbPeeringConnectionsPropertyList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfNetworkPeeringConnectionsOdbPeeringConnectionsPropertyToTerraform(struct?: DataTfNetworkPeeringConnections.OdbPeeringConnectionsProperty): any;
export declare function dataTfNetworkPeeringConnectionsOdbPeeringConnectionsPropertyToHclTerraform(struct?: DataTfNetworkPeeringConnections.OdbPeeringConnectionsProperty): any;
export declare namespace DataTfNetworkPeeringConnections {
    interface OdbPeeringConnectionsProperty {
    }
    class OdbPeeringConnectionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OdbPeeringConnectionsProperty | undefined;
        set internalValue(value: OdbPeeringConnectionsProperty | undefined);
        get arn(): string;
        get displayName(): string;
        get id(): string;
        get odbNetworkArn(): string;
        get peerNetworkArn(): string;
    }
    class OdbPeeringConnectionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OdbPeeringConnectionsPropertyOutputReference;
    }
}
