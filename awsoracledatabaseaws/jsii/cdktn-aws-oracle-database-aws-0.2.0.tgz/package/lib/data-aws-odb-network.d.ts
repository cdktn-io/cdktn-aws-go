import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfNetworkConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_network#id DataTfNetwork#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_network#region DataTfNetwork#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_network aws_odb_network}
*/
export declare class DataTfNetwork extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_odb_network";
    /**
    * Generates CDKTN code for importing a DataTfNetwork resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfNetwork to import
    * @param importFromId The id of the existing DataTfNetwork that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_network#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfNetwork to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_network aws_odb_network} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfNetworkConfig
    */
    constructor(scope: Construct, id: string, config: DataTfNetworkConfig);
    get arn(): string;
    get availabilityZone(): string;
    get availabilityZoneId(): string;
    get backupSubnetCidr(): string;
    get clientSubnetCidr(): string;
    get createdAt(): string;
    get customDomainName(): string;
    get defaultDnsPrefix(): string;
    get displayName(): string;
    get ec2PlacementGroupIds(): string[];
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _managedServices;
    get managedServices(): DataTfNetwork.ManagedServicesPropertyList;
    private _ociDnsForwardingConfigs;
    get ociDnsForwardingConfigs(): DataTfNetwork.OciDnsForwardingConfigsPropertyList;
    get ociNetworkAnchorId(): string;
    get ociNetworkAnchorUrl(): string;
    get ociResourceAnchorName(): string;
    get ociVcnId(): string;
    get ociVcnUrl(): string;
    get peeredCidrs(): string[];
    get percentProgress(): number;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    get statusReason(): string;
    private _tags;
    get tags(): cdktn.StringMap;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfNetworkCrossRegionS3RestoreSourcesAccessPropertyToTerraform(struct?: DataTfNetwork.CrossRegionS3RestoreSourcesAccessProperty): any;
export declare function dataTfNetworkCrossRegionS3RestoreSourcesAccessPropertyToHclTerraform(struct?: DataTfNetwork.CrossRegionS3RestoreSourcesAccessProperty): any;
export declare function dataTfNetworkKmsAccessPropertyToTerraform(struct?: DataTfNetwork.KmsAccessProperty): any;
export declare function dataTfNetworkKmsAccessPropertyToHclTerraform(struct?: DataTfNetwork.KmsAccessProperty): any;
export declare function dataTfNetworkManagedS3BackupAccessPropertyToTerraform(struct?: DataTfNetwork.ManagedS3BackupAccessProperty): any;
export declare function dataTfNetworkManagedS3BackupAccessPropertyToHclTerraform(struct?: DataTfNetwork.ManagedS3BackupAccessProperty): any;
export declare function dataTfNetworkS3AccessPropertyToTerraform(struct?: DataTfNetwork.S3AccessProperty): any;
export declare function dataTfNetworkS3AccessPropertyToHclTerraform(struct?: DataTfNetwork.S3AccessProperty): any;
export declare function dataTfNetworkServiceNetworkEndpointPropertyToTerraform(struct?: DataTfNetwork.ServiceNetworkEndpointProperty): any;
export declare function dataTfNetworkServiceNetworkEndpointPropertyToHclTerraform(struct?: DataTfNetwork.ServiceNetworkEndpointProperty): any;
export declare function dataTfNetworkStsAccessPropertyToTerraform(struct?: DataTfNetwork.StsAccessProperty): any;
export declare function dataTfNetworkStsAccessPropertyToHclTerraform(struct?: DataTfNetwork.StsAccessProperty): any;
export declare function dataTfNetworkZeroTlAccessPropertyToTerraform(struct?: DataTfNetwork.ZeroTlAccessProperty): any;
export declare function dataTfNetworkZeroTlAccessPropertyToHclTerraform(struct?: DataTfNetwork.ZeroTlAccessProperty): any;
export declare function dataTfNetworkManagedServicesPropertyToTerraform(struct?: DataTfNetwork.ManagedServicesProperty): any;
export declare function dataTfNetworkManagedServicesPropertyToHclTerraform(struct?: DataTfNetwork.ManagedServicesProperty): any;
export declare function dataTfNetworkOciDnsForwardingConfigsPropertyToTerraform(struct?: DataTfNetwork.OciDnsForwardingConfigsProperty): any;
export declare function dataTfNetworkOciDnsForwardingConfigsPropertyToHclTerraform(struct?: DataTfNetwork.OciDnsForwardingConfigsProperty): any;
export declare namespace DataTfNetwork {
    interface CrossRegionS3RestoreSourcesAccessProperty {
    }
    class CrossRegionS3RestoreSourcesAccessPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CrossRegionS3RestoreSourcesAccessProperty | undefined;
        set internalValue(value: CrossRegionS3RestoreSourcesAccessProperty | undefined);
        get ipv4Addresses(): string[];
        get region(): string;
        get status(): string;
    }
    class CrossRegionS3RestoreSourcesAccessPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CrossRegionS3RestoreSourcesAccessPropertyOutputReference;
    }
    interface KmsAccessProperty {
    }
    class KmsAccessPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KmsAccessProperty | undefined;
        set internalValue(value: KmsAccessProperty | undefined);
        get domainName(): string;
        get ipv4Addresses(): string[];
        get kmsPolicyDocument(): string;
        get status(): string;
    }
    class KmsAccessPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KmsAccessPropertyOutputReference;
    }
    interface ManagedS3BackupAccessProperty {
    }
    class ManagedS3BackupAccessPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ManagedS3BackupAccessProperty | undefined;
        set internalValue(value: ManagedS3BackupAccessProperty | undefined);
        get ipv4Addresses(): string[];
        get status(): string;
    }
    class ManagedS3BackupAccessPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ManagedS3BackupAccessPropertyOutputReference;
    }
    interface S3AccessProperty {
    }
    class S3AccessPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3AccessProperty | undefined;
        set internalValue(value: S3AccessProperty | undefined);
        get domainName(): string;
        get ipv4Addresses(): string[];
        get s3PolicyDocument(): string;
        get status(): string;
    }
    class S3AccessPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3AccessPropertyOutputReference;
    }
    interface ServiceNetworkEndpointProperty {
    }
    class ServiceNetworkEndpointPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ServiceNetworkEndpointProperty | undefined;
        set internalValue(value: ServiceNetworkEndpointProperty | undefined);
        get vpcEndpointId(): string;
        get vpcEndpointType(): string;
    }
    class ServiceNetworkEndpointPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ServiceNetworkEndpointPropertyOutputReference;
    }
    interface StsAccessProperty {
    }
    class StsAccessPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StsAccessProperty | undefined;
        set internalValue(value: StsAccessProperty | undefined);
        get domainName(): string;
        get ipv4Addresses(): string[];
        get status(): string;
        get stsPolicyDocument(): string;
    }
    class StsAccessPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StsAccessPropertyOutputReference;
    }
    interface ZeroTlAccessProperty {
    }
    class ZeroTlAccessPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ZeroTlAccessProperty | undefined;
        set internalValue(value: ZeroTlAccessProperty | undefined);
        get cidr(): string;
        get status(): string;
    }
    class ZeroTlAccessPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ZeroTlAccessPropertyOutputReference;
    }
    interface ManagedServicesProperty {
    }
    class ManagedServicesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ManagedServicesProperty | undefined;
        set internalValue(value: ManagedServicesProperty | undefined);
        private _crossRegionS3RestoreSourcesAccess;
        get crossRegionS3RestoreSourcesAccess(): CrossRegionS3RestoreSourcesAccessPropertyList;
        private _kmsAccess;
        get kmsAccess(): KmsAccessPropertyList;
        private _managedS3BackupAccess;
        get managedS3BackupAccess(): ManagedS3BackupAccessPropertyList;
        get managedServiceIpv4Cidrs(): string[];
        get resourceGatewayArn(): string;
        private _s3Access;
        get s3Access(): S3AccessPropertyList;
        get serviceNetworkArn(): string;
        private _serviceNetworkEndpoint;
        get serviceNetworkEndpoint(): ServiceNetworkEndpointPropertyList;
        private _stsAccess;
        get stsAccess(): StsAccessPropertyList;
        private _zeroTlAccess;
        get zeroTlAccess(): ZeroTlAccessPropertyList;
    }
    class ManagedServicesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ManagedServicesPropertyOutputReference;
    }
    interface OciDnsForwardingConfigsProperty {
    }
    class OciDnsForwardingConfigsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OciDnsForwardingConfigsProperty | undefined;
        set internalValue(value: OciDnsForwardingConfigsProperty | undefined);
        get domainName(): string;
        get ociDnsListenerIp(): string;
    }
    class OciDnsForwardingConfigsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OciDnsForwardingConfigsPropertyOutputReference;
    }
}
