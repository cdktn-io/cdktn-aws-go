import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfCloudExadataInfrastructureConfig extends cdktn.TerraformMetaArguments {
    /**
    * The unique identifier of the Exadata infrastructure.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_cloud_exadata_infrastructure#id DataTfCloudExadataInfrastructure#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_cloud_exadata_infrastructure#region DataTfCloudExadataInfrastructure#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_cloud_exadata_infrastructure aws_odb_cloud_exadata_infrastructure}
*/
export declare class DataTfCloudExadataInfrastructure extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_odb_cloud_exadata_infrastructure";
    /**
    * Generates CDKTN code for importing a DataTfCloudExadataInfrastructure resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfCloudExadataInfrastructure to import
    * @param importFromId The id of the existing DataTfCloudExadataInfrastructure that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_cloud_exadata_infrastructure#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfCloudExadataInfrastructure to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_cloud_exadata_infrastructure aws_odb_cloud_exadata_infrastructure} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfCloudExadataInfrastructureConfig
    */
    constructor(scope: Construct, id: string, config: DataTfCloudExadataInfrastructureConfig);
    get activatedStorageCount(): number;
    get additionalStorageCount(): number;
    get arn(): string;
    get availabilityZone(): string;
    get availabilityZoneId(): string;
    get availableStorageSizeInGbs(): number;
    get computeCount(): number;
    get computeModel(): string;
    get cpuCount(): number;
    get createdAt(): string;
    private _customerContactsToSendToOci;
    get customerContactsToSendToOci(): DataTfCloudExadataInfrastructure.CustomerContactsToSendToOciPropertyList;
    get dataStorageSizeInTbs(): number;
    get databaseServerType(): string;
    get dbNodeStorageSizeInGbs(): number;
    get dbServerVersion(): string;
    get displayName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get lastMaintenanceRunId(): string;
    private _maintenanceWindow;
    get maintenanceWindow(): DataTfCloudExadataInfrastructure.MaintenanceWindowPropertyList;
    get maxCpuCount(): number;
    get maxDataStorageInTbs(): number;
    get maxDbNodeStorageSizeInGbs(): number;
    get maxMemoryInGbs(): number;
    get memorySizeInGbs(): number;
    get monthlyDbServerVersion(): string;
    get monthlyStorageServerVersion(): string;
    get nextMaintenanceRunId(): string;
    get ociResourceAnchorName(): string;
    get ociUrl(): string;
    get ocid(): string;
    get percentProgress(): number;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get shape(): string;
    get status(): string;
    get statusReason(): string;
    get storageCount(): number;
    get storageServerType(): string;
    get storageServerVersion(): string;
    private _tags;
    get tags(): cdktn.StringMap;
    get totalStorageSizeInGbs(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfCloudExadataInfrastructureCustomerContactsToSendToOciPropertyToTerraform(struct?: DataTfCloudExadataInfrastructure.CustomerContactsToSendToOciProperty): any;
export declare function dataTfCloudExadataInfrastructureCustomerContactsToSendToOciPropertyToHclTerraform(struct?: DataTfCloudExadataInfrastructure.CustomerContactsToSendToOciProperty): any;
export declare function dataTfCloudExadataInfrastructureDaysOfWeekPropertyToTerraform(struct?: DataTfCloudExadataInfrastructure.DaysOfWeekProperty): any;
export declare function dataTfCloudExadataInfrastructureDaysOfWeekPropertyToHclTerraform(struct?: DataTfCloudExadataInfrastructure.DaysOfWeekProperty): any;
export declare function dataTfCloudExadataInfrastructureMonthsPropertyToTerraform(struct?: DataTfCloudExadataInfrastructure.MonthsProperty): any;
export declare function dataTfCloudExadataInfrastructureMonthsPropertyToHclTerraform(struct?: DataTfCloudExadataInfrastructure.MonthsProperty): any;
export declare function dataTfCloudExadataInfrastructureMaintenanceWindowPropertyToTerraform(struct?: DataTfCloudExadataInfrastructure.MaintenanceWindowProperty): any;
export declare function dataTfCloudExadataInfrastructureMaintenanceWindowPropertyToHclTerraform(struct?: DataTfCloudExadataInfrastructure.MaintenanceWindowProperty): any;
export declare namespace DataTfCloudExadataInfrastructure {
    interface CustomerContactsToSendToOciProperty {
    }
    class CustomerContactsToSendToOciPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomerContactsToSendToOciProperty | undefined;
        set internalValue(value: CustomerContactsToSendToOciProperty | undefined);
        get email(): string;
    }
    class CustomerContactsToSendToOciPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomerContactsToSendToOciPropertyOutputReference;
    }
    interface DaysOfWeekProperty {
    }
    class DaysOfWeekPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DaysOfWeekProperty | undefined;
        set internalValue(value: DaysOfWeekProperty | undefined);
        get name(): string;
    }
    class DaysOfWeekPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DaysOfWeekPropertyOutputReference;
    }
    interface MonthsProperty {
    }
    class MonthsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MonthsProperty | undefined;
        set internalValue(value: MonthsProperty | undefined);
        get name(): string;
    }
    class MonthsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MonthsPropertyOutputReference;
    }
    interface MaintenanceWindowProperty {
    }
    class MaintenanceWindowPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MaintenanceWindowProperty | undefined;
        set internalValue(value: MaintenanceWindowProperty | undefined);
        get customActionTimeoutInMins(): number;
        private _daysOfWeek;
        get daysOfWeek(): DaysOfWeekPropertyList;
        get hoursOfDay(): number[];
        get isCustomActionTimeoutEnabled(): cdktn.IResolvable;
        get leadTimeInWeeks(): number;
        private _months;
        get months(): MonthsPropertyList;
        get patchingMode(): string;
        get preference(): string;
        get weeksOfMonth(): number[];
    }
    class MaintenanceWindowPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MaintenanceWindowPropertyOutputReference;
    }
}
