import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfNotificationChannelConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devopsguru_notification_channel#region TfNotificationChannel#region}
    */
    readonly region?: string;
    /**
    * filters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devopsguru_notification_channel#filters TfNotificationChannel#filters}
    */
    readonly filters?: TfNotificationChannel.FiltersProperty[] | cdktn.IResolvable;
    /**
    * sns block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devopsguru_notification_channel#sns TfNotificationChannel#sns}
    */
    readonly sns?: TfNotificationChannel.SnsProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devopsguru_notification_channel aws_devopsguru_notification_channel}
*/
export declare class TfNotificationChannel extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_devopsguru_notification_channel";
    /**
    * Generates CDKTN code for importing a TfNotificationChannel resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfNotificationChannel to import
    * @param importFromId The id of the existing TfNotificationChannel that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devopsguru_notification_channel#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfNotificationChannel to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devopsguru_notification_channel aws_devopsguru_notification_channel} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfNotificationChannelConfig = {}
    */
    constructor(scope: Construct, id: string, config?: TfNotificationChannelConfig);
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _filters;
    get filters(): TfNotificationChannel.FiltersPropertyList;
    putFilters(value: TfNotificationChannel.FiltersProperty[] | cdktn.IResolvable): void;
    resetFilters(): void;
    get filtersInput(): cdktn.IResolvable | TfNotificationChannel.FiltersProperty[] | undefined;
    private _sns;
    get sns(): TfNotificationChannel.SnsPropertyList;
    putSns(value: TfNotificationChannel.SnsProperty[] | cdktn.IResolvable): void;
    resetSns(): void;
    get snsInput(): cdktn.IResolvable | TfNotificationChannel.SnsProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfNotificationChannelFiltersPropertyToTerraform(struct?: TfNotificationChannel.FiltersProperty | cdktn.IResolvable): any;
export declare function tfNotificationChannelFiltersPropertyToHclTerraform(struct?: TfNotificationChannel.FiltersProperty | cdktn.IResolvable): any;
export declare function tfNotificationChannelSnsPropertyToTerraform(struct?: TfNotificationChannel.SnsProperty | cdktn.IResolvable): any;
export declare function tfNotificationChannelSnsPropertyToHclTerraform(struct?: TfNotificationChannel.SnsProperty | cdktn.IResolvable): any;
export declare namespace TfNotificationChannel {
    interface FiltersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devopsguru_notification_channel#message_types TfNotificationChannel#message_types}
        */
        readonly messageTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devopsguru_notification_channel#severities TfNotificationChannel#severities}
        */
        readonly severities?: string[];
    }
    class FiltersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FiltersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FiltersProperty | cdktn.IResolvable | undefined);
        private _messageTypes?;
        get messageTypes(): string[];
        set messageTypes(value: string[]);
        resetMessageTypes(): void;
        get messageTypesInput(): string[] | undefined;
        private _severities?;
        get severities(): string[];
        set severities(value: string[]);
        resetSeverities(): void;
        get severitiesInput(): string[] | undefined;
    }
    class FiltersPropertyList extends cdktn.ComplexList {
        internalValue?: FiltersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FiltersPropertyOutputReference;
    }
    interface SnsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devopsguru_notification_channel#topic_arn TfNotificationChannel#topic_arn}
        */
        readonly topicArn: string;
    }
    class SnsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SnsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SnsProperty | cdktn.IResolvable | undefined);
        private _topicArn?;
        get topicArn(): string;
        set topicArn(value: string);
        get topicArnInput(): string | undefined;
    }
    class SnsPropertyList extends cdktn.ComplexList {
        internalValue?: SnsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SnsPropertyOutputReference;
    }
}
