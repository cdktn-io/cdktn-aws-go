import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDevopsguruEventSourcesConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devopsguru_event_sources_config#region AwsDevopsguruEventSourcesConfig#region}
    */
    readonly region?: string;
    /**
    * event_sources block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devopsguru_event_sources_config#event_sources AwsDevopsguruEventSourcesConfig#event_sources}
    */
    readonly eventSources?: AwsDevopsguruEventSourcesConfig.EventSourcesProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devopsguru_event_sources_config aws_devopsguru_event_sources_config}
*/
export declare class AwsDevopsguruEventSourcesConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_devopsguru_event_sources_config";
    /**
    * Generates CDKTN code for importing a AwsDevopsguruEventSourcesConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDevopsguruEventSourcesConfig to import
    * @param importFromId The id of the existing AwsDevopsguruEventSourcesConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devopsguru_event_sources_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDevopsguruEventSourcesConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devopsguru_event_sources_config aws_devopsguru_event_sources_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDevopsguruEventSourcesConfigConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AwsDevopsguruEventSourcesConfigConfig);
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _eventSources;
    get eventSources(): AwsDevopsguruEventSourcesConfig.EventSourcesPropertyList;
    putEventSources(value: AwsDevopsguruEventSourcesConfig.EventSourcesProperty[] | cdktn.IResolvable): void;
    resetEventSources(): void;
    get eventSourcesInput(): cdktn.IResolvable | AwsDevopsguruEventSourcesConfig.EventSourcesProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsDevopsguruEventSourcesConfigAmazonCodeGuruProfilerPropertyToTerraform(struct?: AwsDevopsguruEventSourcesConfig.AmazonCodeGuruProfilerProperty | cdktn.IResolvable): any;
export declare function awsDevopsguruEventSourcesConfigAmazonCodeGuruProfilerPropertyToHclTerraform(struct?: AwsDevopsguruEventSourcesConfig.AmazonCodeGuruProfilerProperty | cdktn.IResolvable): any;
export declare function awsDevopsguruEventSourcesConfigEventSourcesPropertyToTerraform(struct?: AwsDevopsguruEventSourcesConfig.EventSourcesProperty | cdktn.IResolvable): any;
export declare function awsDevopsguruEventSourcesConfigEventSourcesPropertyToHclTerraform(struct?: AwsDevopsguruEventSourcesConfig.EventSourcesProperty | cdktn.IResolvable): any;
export declare namespace AwsDevopsguruEventSourcesConfig {
    interface AmazonCodeGuruProfilerProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devopsguru_event_sources_config#status AwsDevopsguruEventSourcesConfig#status}
        */
        readonly status: string;
    }
    class AmazonCodeGuruProfilerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AmazonCodeGuruProfilerProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AmazonCodeGuruProfilerProperty | cdktn.IResolvable | undefined);
        private _status?;
        get status(): string;
        set status(value: string);
        get statusInput(): string | undefined;
    }
    class AmazonCodeGuruProfilerPropertyList extends cdktn.ComplexList {
        internalValue?: AmazonCodeGuruProfilerProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AmazonCodeGuruProfilerPropertyOutputReference;
    }
    interface EventSourcesProperty {
        /**
        * amazon_code_guru_profiler block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devopsguru_event_sources_config#amazon_code_guru_profiler AwsDevopsguruEventSourcesConfig#amazon_code_guru_profiler}
        */
        readonly amazonCodeGuruProfiler?: AmazonCodeGuruProfilerProperty[] | cdktn.IResolvable;
    }
    class EventSourcesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EventSourcesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EventSourcesProperty | cdktn.IResolvable | undefined);
        private _amazonCodeGuruProfiler;
        get amazonCodeGuruProfiler(): AmazonCodeGuruProfilerPropertyList;
        putAmazonCodeGuruProfiler(value: AmazonCodeGuruProfilerProperty[] | cdktn.IResolvable): void;
        resetAmazonCodeGuruProfiler(): void;
        get amazonCodeGuruProfilerInput(): cdktn.IResolvable | AmazonCodeGuruProfilerProperty[] | undefined;
    }
    class EventSourcesPropertyList extends cdktn.ComplexList {
        internalValue?: EventSourcesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EventSourcesPropertyOutputReference;
    }
}
