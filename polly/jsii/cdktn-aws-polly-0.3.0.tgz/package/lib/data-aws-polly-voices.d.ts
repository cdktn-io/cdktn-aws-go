import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsVoicesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/polly_voices#engine DataAwsVoices#engine}
    */
    readonly engine?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/polly_voices#include_additional_language_codes DataAwsVoices#include_additional_language_codes}
    */
    readonly includeAdditionalLanguageCodes?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/polly_voices#language_code DataAwsVoices#language_code}
    */
    readonly languageCode?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/polly_voices#region DataAwsVoices#region}
    */
    readonly region?: string;
    /**
    * voices block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/polly_voices#voices DataAwsVoices#voices}
    */
    readonly voices?: DataAwsVoices.VoicesProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/polly_voices aws_polly_voices}
*/
export declare class DataAwsVoices extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_polly_voices";
    /**
    * Generates CDKTN code for importing a DataAwsVoices resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsVoices to import
    * @param importFromId The id of the existing DataAwsVoices that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/polly_voices#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsVoices to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/polly_voices aws_polly_voices} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsVoicesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsVoicesConfig);
    private _engine?;
    get engine(): string;
    set engine(value: string);
    resetEngine(): void;
    get engineInput(): string | undefined;
    get id(): string;
    private _includeAdditionalLanguageCodes?;
    get includeAdditionalLanguageCodes(): boolean | cdktn.IResolvable;
    set includeAdditionalLanguageCodes(value: boolean | cdktn.IResolvable);
    resetIncludeAdditionalLanguageCodes(): void;
    get includeAdditionalLanguageCodesInput(): boolean | cdktn.IResolvable | undefined;
    private _languageCode?;
    get languageCode(): string;
    set languageCode(value: string);
    resetLanguageCode(): void;
    get languageCodeInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _voices;
    get voices(): DataAwsVoices.VoicesPropertyList;
    putVoices(value: DataAwsVoices.VoicesProperty[] | cdktn.IResolvable): void;
    resetVoices(): void;
    get voicesInput(): cdktn.IResolvable | DataAwsVoices.VoicesProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsVoicesVoicesPropertyToTerraform(struct?: DataAwsVoices.VoicesProperty | cdktn.IResolvable): any;
export declare function dataAwsVoicesVoicesPropertyToHclTerraform(struct?: DataAwsVoices.VoicesProperty | cdktn.IResolvable): any;
export declare namespace DataAwsVoices {
    interface VoicesProperty {
    }
    class VoicesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VoicesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VoicesProperty | cdktn.IResolvable | undefined);
        get additionalLanguageCodes(): string[];
        get gender(): string;
        get id(): string;
        get languageCode(): string;
        get languageName(): string;
        get name(): string;
        get supportedEngines(): string[];
    }
    class VoicesPropertyList extends cdktn.ComplexList {
        internalValue?: VoicesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VoicesPropertyOutputReference;
    }
}
