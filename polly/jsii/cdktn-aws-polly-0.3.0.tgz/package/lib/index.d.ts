export * from './data-aws-polly-voices';
