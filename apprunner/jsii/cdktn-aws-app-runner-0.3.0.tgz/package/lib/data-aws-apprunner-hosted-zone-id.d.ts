import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsHostedZoneIdConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/apprunner_hosted_zone_id#region DataAwsHostedZoneId#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/apprunner_hosted_zone_id aws_apprunner_hosted_zone_id}
*/
export declare class DataAwsHostedZoneId extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_apprunner_hosted_zone_id";
    /**
    * Generates CDKTN code for importing a DataAwsHostedZoneId resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsHostedZoneId to import
    * @param importFromId The id of the existing DataAwsHostedZoneId that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/apprunner_hosted_zone_id#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsHostedZoneId to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/apprunner_hosted_zone_id aws_apprunner_hosted_zone_id} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsHostedZoneIdConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsHostedZoneIdConfig);
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
