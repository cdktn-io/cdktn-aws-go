import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsOrganizationalUnitAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/notifications_organizational_unit_association#notification_configuration_arn AwsOrganizationalUnitAssociation#notification_configuration_arn}
    */
    readonly notificationConfigurationArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/notifications_organizational_unit_association#organizational_unit_id AwsOrganizationalUnitAssociation#organizational_unit_id}
    */
    readonly organizationalUnitId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/notifications_organizational_unit_association aws_notifications_organizational_unit_association}
*/
export declare class AwsOrganizationalUnitAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_notifications_organizational_unit_association";
    /**
    * Generates CDKTN code for importing a AwsOrganizationalUnitAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsOrganizationalUnitAssociation to import
    * @param importFromId The id of the existing AwsOrganizationalUnitAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/notifications_organizational_unit_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsOrganizationalUnitAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/notifications_organizational_unit_association aws_notifications_organizational_unit_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsOrganizationalUnitAssociationConfig
    */
    constructor(scope: Construct, id: string, config: AwsOrganizationalUnitAssociationConfig);
    private _notificationConfigurationArn?;
    get notificationConfigurationArn(): string;
    set notificationConfigurationArn(value: string);
    get notificationConfigurationArnInput(): string | undefined;
    private _organizationalUnitId?;
    get organizationalUnitId(): string;
    set organizationalUnitId(value: string);
    get organizationalUnitIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
