import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsS3FilesFileSystemPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * File system ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_file_system_policy#file_system_id AwsS3FilesFileSystemPolicy#file_system_id}
    */
    readonly fileSystemId: string;
    /**
    * File system policy JSON
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_file_system_policy#policy AwsS3FilesFileSystemPolicy#policy}
    */
    readonly policy: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_file_system_policy#region AwsS3FilesFileSystemPolicy#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_file_system_policy aws_s3files_file_system_policy}
*/
export declare class AwsS3FilesFileSystemPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_s3files_file_system_policy";
    /**
    * Generates CDKTN code for importing a AwsS3FilesFileSystemPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsS3FilesFileSystemPolicy to import
    * @param importFromId The id of the existing AwsS3FilesFileSystemPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_file_system_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsS3FilesFileSystemPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_file_system_policy aws_s3files_file_system_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsS3FilesFileSystemPolicyConfig
    */
    constructor(scope: Construct, id: string, config: AwsS3FilesFileSystemPolicyConfig);
    private _fileSystemId?;
    get fileSystemId(): string;
    set fileSystemId(value: string);
    get fileSystemIdInput(): string | undefined;
    private _policy?;
    get policy(): string;
    set policy(value: string);
    get policyInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
