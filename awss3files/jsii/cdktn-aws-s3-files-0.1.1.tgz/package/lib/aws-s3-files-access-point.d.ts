import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsS3FilesAccessPointConfig extends cdktn.TerraformMetaArguments {
    /**
    * File system ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_access_point#file_system_id AwsS3FilesAccessPoint#file_system_id}
    */
    readonly fileSystemId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_access_point#region AwsS3FilesAccessPoint#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_access_point#tags AwsS3FilesAccessPoint#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * posix_user block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_access_point#posix_user AwsS3FilesAccessPoint#posix_user}
    */
    readonly posixUser?: AwsS3FilesAccessPoint.PosixUserProperty[] | cdktn.IResolvable;
    /**
    * root_directory block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_access_point#root_directory AwsS3FilesAccessPoint#root_directory}
    */
    readonly rootDirectory?: AwsS3FilesAccessPoint.RootDirectoryProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_access_point#timeouts AwsS3FilesAccessPoint#timeouts}
    */
    readonly timeouts?: AwsS3FilesAccessPoint.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_access_point aws_s3files_access_point}
*/
export declare class AwsS3FilesAccessPoint extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_s3files_access_point";
    /**
    * Generates CDKTN code for importing a AwsS3FilesAccessPoint resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsS3FilesAccessPoint to import
    * @param importFromId The id of the existing AwsS3FilesAccessPoint that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_access_point#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsS3FilesAccessPoint to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_access_point aws_s3files_access_point} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsS3FilesAccessPointConfig
    */
    constructor(scope: Construct, id: string, config: AwsS3FilesAccessPointConfig);
    get arn(): string;
    private _fileSystemId?;
    get fileSystemId(): string;
    set fileSystemId(value: string);
    get fileSystemIdInput(): string | undefined;
    get id(): string;
    get name(): string;
    get ownerId(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _posixUser;
    get posixUser(): AwsS3FilesAccessPoint.PosixUserPropertyList;
    putPosixUser(value: AwsS3FilesAccessPoint.PosixUserProperty[] | cdktn.IResolvable): void;
    resetPosixUser(): void;
    get posixUserInput(): cdktn.IResolvable | AwsS3FilesAccessPoint.PosixUserProperty[] | undefined;
    private _rootDirectory;
    get rootDirectory(): AwsS3FilesAccessPoint.RootDirectoryPropertyList;
    putRootDirectory(value: AwsS3FilesAccessPoint.RootDirectoryProperty[] | cdktn.IResolvable): void;
    resetRootDirectory(): void;
    get rootDirectoryInput(): cdktn.IResolvable | AwsS3FilesAccessPoint.RootDirectoryProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsS3FilesAccessPoint.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsS3FilesAccessPoint.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsS3FilesAccessPoint.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsS3FilesAccessPointPosixUserPropertyToTerraform(struct?: AwsS3FilesAccessPoint.PosixUserProperty | cdktn.IResolvable): any;
export declare function awsS3FilesAccessPointPosixUserPropertyToHclTerraform(struct?: AwsS3FilesAccessPoint.PosixUserProperty | cdktn.IResolvable): any;
export declare function awsS3FilesAccessPointCreationPermissionsPropertyToTerraform(struct?: AwsS3FilesAccessPoint.CreationPermissionsProperty | cdktn.IResolvable): any;
export declare function awsS3FilesAccessPointCreationPermissionsPropertyToHclTerraform(struct?: AwsS3FilesAccessPoint.CreationPermissionsProperty | cdktn.IResolvable): any;
export declare function awsS3FilesAccessPointRootDirectoryPropertyToTerraform(struct?: AwsS3FilesAccessPoint.RootDirectoryProperty | cdktn.IResolvable): any;
export declare function awsS3FilesAccessPointRootDirectoryPropertyToHclTerraform(struct?: AwsS3FilesAccessPoint.RootDirectoryProperty | cdktn.IResolvable): any;
export declare function awsS3FilesAccessPointTimeoutsPropertyToTerraform(struct?: AwsS3FilesAccessPoint.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsS3FilesAccessPointTimeoutsPropertyToHclTerraform(struct?: AwsS3FilesAccessPoint.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsS3FilesAccessPoint {
    interface PosixUserProperty {
        /**
        * POSIX group ID
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_access_point#gid AwsS3FilesAccessPoint#gid}
        */
        readonly gid: number;
        /**
        * Secondary POSIX group IDs
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_access_point#secondary_gids AwsS3FilesAccessPoint#secondary_gids}
        */
        readonly secondaryGids?: number[];
        /**
        * POSIX user ID
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_access_point#uid AwsS3FilesAccessPoint#uid}
        */
        readonly uid: number;
    }
    class PosixUserPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PosixUserProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PosixUserProperty | cdktn.IResolvable | undefined);
        private _gid?;
        get gid(): number;
        set gid(value: number);
        get gidInput(): number | undefined;
        private _secondaryGids?;
        get secondaryGids(): number[];
        set secondaryGids(value: number[]);
        resetSecondaryGids(): void;
        get secondaryGidsInput(): number[] | undefined;
        private _uid?;
        get uid(): number;
        set uid(value: number);
        get uidInput(): number | undefined;
    }
    class PosixUserPropertyList extends cdktn.ComplexList {
        internalValue?: PosixUserProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PosixUserPropertyOutputReference;
    }
    interface CreationPermissionsProperty {
        /**
        * Owner group ID
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_access_point#owner_gid AwsS3FilesAccessPoint#owner_gid}
        */
        readonly ownerGid: number;
        /**
        * Owner user ID
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_access_point#owner_uid AwsS3FilesAccessPoint#owner_uid}
        */
        readonly ownerUid: number;
        /**
        * POSIX permissions
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_access_point#permissions AwsS3FilesAccessPoint#permissions}
        */
        readonly permissions: string;
    }
    class CreationPermissionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CreationPermissionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CreationPermissionsProperty | cdktn.IResolvable | undefined);
        private _ownerGid?;
        get ownerGid(): number;
        set ownerGid(value: number);
        get ownerGidInput(): number | undefined;
        private _ownerUid?;
        get ownerUid(): number;
        set ownerUid(value: number);
        get ownerUidInput(): number | undefined;
        private _permissions?;
        get permissions(): string;
        set permissions(value: string);
        get permissionsInput(): string | undefined;
    }
    class CreationPermissionsPropertyList extends cdktn.ComplexList {
        internalValue?: CreationPermissionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CreationPermissionsPropertyOutputReference;
    }
    interface RootDirectoryProperty {
        /**
        * Root directory path
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_access_point#path AwsS3FilesAccessPoint#path}
        */
        readonly path?: string;
        /**
        * creation_permissions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_access_point#creation_permissions AwsS3FilesAccessPoint#creation_permissions}
        */
        readonly creationPermissions?: CreationPermissionsProperty[] | cdktn.IResolvable;
    }
    class RootDirectoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RootDirectoryProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RootDirectoryProperty | cdktn.IResolvable | undefined);
        private _path?;
        get path(): string;
        set path(value: string);
        resetPath(): void;
        get pathInput(): string | undefined;
        private _creationPermissions;
        get creationPermissions(): CreationPermissionsPropertyList;
        putCreationPermissions(value: CreationPermissionsProperty[] | cdktn.IResolvable): void;
        resetCreationPermissions(): void;
        get creationPermissionsInput(): cdktn.IResolvable | CreationPermissionsProperty[] | undefined;
    }
    class RootDirectoryPropertyList extends cdktn.ComplexList {
        internalValue?: RootDirectoryProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RootDirectoryPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_access_point#create AwsS3FilesAccessPoint#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_access_point#delete AwsS3FilesAccessPoint#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
