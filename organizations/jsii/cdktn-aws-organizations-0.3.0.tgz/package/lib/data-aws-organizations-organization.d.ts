import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsOrganizationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/organizations_organization#id DataAwsOrganization#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/organizations_organization#return_organization_only DataAwsOrganization#return_organization_only}
    */
    readonly returnOrganizationOnly?: boolean | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/organizations_organization aws_organizations_organization}
*/
export declare class DataAwsOrganization extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_organizations_organization";
    /**
    * Generates CDKTN code for importing a DataAwsOrganization resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsOrganization to import
    * @param importFromId The id of the existing DataAwsOrganization that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/organizations_organization#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsOrganization to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/organizations_organization aws_organizations_organization} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsOrganizationConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsOrganizationConfig);
    private _accounts;
    get accounts(): DataAwsOrganization.AccountsPropertyList;
    get arn(): string;
    get awsServiceAccessPrincipals(): string[];
    get enabledPolicyTypes(): string[];
    get featureSet(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get masterAccountArn(): string;
    get masterAccountEmail(): string;
    get masterAccountId(): string;
    get masterAccountName(): string;
    private _nonMasterAccounts;
    get nonMasterAccounts(): DataAwsOrganization.NonMasterAccountsPropertyList;
    private _returnOrganizationOnly?;
    get returnOrganizationOnly(): boolean | cdktn.IResolvable;
    set returnOrganizationOnly(value: boolean | cdktn.IResolvable);
    resetReturnOrganizationOnly(): void;
    get returnOrganizationOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _roots;
    get roots(): DataAwsOrganization.RootsPropertyList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsOrganizationAccountsPropertyToTerraform(struct?: DataAwsOrganization.AccountsProperty): any;
export declare function dataAwsOrganizationAccountsPropertyToHclTerraform(struct?: DataAwsOrganization.AccountsProperty): any;
export declare function dataAwsOrganizationNonMasterAccountsPropertyToTerraform(struct?: DataAwsOrganization.NonMasterAccountsProperty): any;
export declare function dataAwsOrganizationNonMasterAccountsPropertyToHclTerraform(struct?: DataAwsOrganization.NonMasterAccountsProperty): any;
export declare function dataAwsOrganizationPolicyTypesPropertyToTerraform(struct?: DataAwsOrganization.PolicyTypesProperty): any;
export declare function dataAwsOrganizationPolicyTypesPropertyToHclTerraform(struct?: DataAwsOrganization.PolicyTypesProperty): any;
export declare function dataAwsOrganizationRootsPropertyToTerraform(struct?: DataAwsOrganization.RootsProperty): any;
export declare function dataAwsOrganizationRootsPropertyToHclTerraform(struct?: DataAwsOrganization.RootsProperty): any;
export declare namespace DataAwsOrganization {
    interface AccountsProperty {
    }
    class AccountsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AccountsProperty | undefined;
        set internalValue(value: AccountsProperty | undefined);
        get arn(): string;
        get email(): string;
        get id(): string;
        get joinedMethod(): string;
        get joinedTimestamp(): string;
        get name(): string;
        get state(): string;
        get status(): string;
    }
    class AccountsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AccountsPropertyOutputReference;
    }
    interface NonMasterAccountsProperty {
    }
    class NonMasterAccountsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NonMasterAccountsProperty | undefined;
        set internalValue(value: NonMasterAccountsProperty | undefined);
        get arn(): string;
        get email(): string;
        get id(): string;
        get joinedMethod(): string;
        get joinedTimestamp(): string;
        get name(): string;
        get state(): string;
        get status(): string;
    }
    class NonMasterAccountsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NonMasterAccountsPropertyOutputReference;
    }
    interface PolicyTypesProperty {
    }
    class PolicyTypesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PolicyTypesProperty | undefined;
        set internalValue(value: PolicyTypesProperty | undefined);
        get status(): string;
        get type(): string;
    }
    class PolicyTypesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PolicyTypesPropertyOutputReference;
    }
    interface RootsProperty {
    }
    class RootsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RootsProperty | undefined;
        set internalValue(value: RootsProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
        private _policyTypes;
        get policyTypes(): PolicyTypesPropertyList;
    }
    class RootsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RootsPropertyOutputReference;
    }
}
