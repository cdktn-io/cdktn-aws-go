import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsEntityPathConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/organizations_entity_path#entity_id DataAwsEntityPath#entity_id}
    */
    readonly entityId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/organizations_entity_path aws_organizations_entity_path}
*/
export declare class DataAwsEntityPath extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_organizations_entity_path";
    /**
    * Generates CDKTN code for importing a DataAwsEntityPath resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsEntityPath to import
    * @param importFromId The id of the existing DataAwsEntityPath that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/organizations_entity_path#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsEntityPath to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/organizations_entity_path aws_organizations_entity_path} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsEntityPathConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsEntityPathConfig);
    private _entityId?;
    get entityId(): string;
    set entityId(value: string);
    get entityIdInput(): string | undefined;
    get entityPath(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
