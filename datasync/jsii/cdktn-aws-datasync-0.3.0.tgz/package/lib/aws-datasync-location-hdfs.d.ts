import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsLocationHdfsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_hdfs#agent_arns AwsLocationHdfs#agent_arns}
    */
    readonly agentArns: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_hdfs#authentication_type AwsLocationHdfs#authentication_type}
    */
    readonly authenticationType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_hdfs#block_size AwsLocationHdfs#block_size}
    */
    readonly blockSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_hdfs#id AwsLocationHdfs#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_hdfs#kerberos_keytab AwsLocationHdfs#kerberos_keytab}
    */
    readonly kerberosKeytab?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_hdfs#kerberos_keytab_base64 AwsLocationHdfs#kerberos_keytab_base64}
    */
    readonly kerberosKeytabBase64?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_hdfs#kerberos_krb5_conf AwsLocationHdfs#kerberos_krb5_conf}
    */
    readonly kerberosKrb5Conf?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_hdfs#kerberos_krb5_conf_base64 AwsLocationHdfs#kerberos_krb5_conf_base64}
    */
    readonly kerberosKrb5ConfBase64?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_hdfs#kerberos_principal AwsLocationHdfs#kerberos_principal}
    */
    readonly kerberosPrincipal?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_hdfs#kms_key_provider_uri AwsLocationHdfs#kms_key_provider_uri}
    */
    readonly kmsKeyProviderUri?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_hdfs#region AwsLocationHdfs#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_hdfs#replication_factor AwsLocationHdfs#replication_factor}
    */
    readonly replicationFactor?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_hdfs#simple_user AwsLocationHdfs#simple_user}
    */
    readonly simpleUser?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_hdfs#subdirectory AwsLocationHdfs#subdirectory}
    */
    readonly subdirectory?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_hdfs#tags AwsLocationHdfs#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_hdfs#tags_all AwsLocationHdfs#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * name_node block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_hdfs#name_node AwsLocationHdfs#name_node}
    */
    readonly nameNode: AwsLocationHdfs.NameNodeProperty[] | cdktn.IResolvable;
    /**
    * qop_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_hdfs#qop_configuration AwsLocationHdfs#qop_configuration}
    */
    readonly qopConfiguration?: AwsLocationHdfs.QopConfigurationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_hdfs aws_datasync_location_hdfs}
*/
export declare class AwsLocationHdfs extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_datasync_location_hdfs";
    /**
    * Generates CDKTN code for importing a AwsLocationHdfs resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsLocationHdfs to import
    * @param importFromId The id of the existing AwsLocationHdfs that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_hdfs#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsLocationHdfs to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_hdfs aws_datasync_location_hdfs} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsLocationHdfsConfig
    */
    constructor(scope: Construct, id: string, config: AwsLocationHdfsConfig);
    private _agentArns?;
    get agentArns(): string[];
    set agentArns(value: string[]);
    get agentArnsInput(): string[] | undefined;
    get arn(): string;
    private _authenticationType?;
    get authenticationType(): string;
    set authenticationType(value: string);
    resetAuthenticationType(): void;
    get authenticationTypeInput(): string | undefined;
    private _blockSize?;
    get blockSize(): number;
    set blockSize(value: number);
    resetBlockSize(): void;
    get blockSizeInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _kerberosKeytab?;
    get kerberosKeytab(): string;
    set kerberosKeytab(value: string);
    resetKerberosKeytab(): void;
    get kerberosKeytabInput(): string | undefined;
    private _kerberosKeytabBase64?;
    get kerberosKeytabBase64(): string;
    set kerberosKeytabBase64(value: string);
    resetKerberosKeytabBase64(): void;
    get kerberosKeytabBase64Input(): string | undefined;
    private _kerberosKrb5Conf?;
    get kerberosKrb5Conf(): string;
    set kerberosKrb5Conf(value: string);
    resetKerberosKrb5Conf(): void;
    get kerberosKrb5ConfInput(): string | undefined;
    private _kerberosKrb5ConfBase64?;
    get kerberosKrb5ConfBase64(): string;
    set kerberosKrb5ConfBase64(value: string);
    resetKerberosKrb5ConfBase64(): void;
    get kerberosKrb5ConfBase64Input(): string | undefined;
    private _kerberosPrincipal?;
    get kerberosPrincipal(): string;
    set kerberosPrincipal(value: string);
    resetKerberosPrincipal(): void;
    get kerberosPrincipalInput(): string | undefined;
    private _kmsKeyProviderUri?;
    get kmsKeyProviderUri(): string;
    set kmsKeyProviderUri(value: string);
    resetKmsKeyProviderUri(): void;
    get kmsKeyProviderUriInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _replicationFactor?;
    get replicationFactor(): number;
    set replicationFactor(value: number);
    resetReplicationFactor(): void;
    get replicationFactorInput(): number | undefined;
    private _simpleUser?;
    get simpleUser(): string;
    set simpleUser(value: string);
    resetSimpleUser(): void;
    get simpleUserInput(): string | undefined;
    private _subdirectory?;
    get subdirectory(): string;
    set subdirectory(value: string);
    resetSubdirectory(): void;
    get subdirectoryInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get uri(): string;
    private _nameNode;
    get nameNode(): AwsLocationHdfs.NameNodePropertyList;
    putNameNode(value: AwsLocationHdfs.NameNodeProperty[] | cdktn.IResolvable): void;
    get nameNodeInput(): cdktn.IResolvable | AwsLocationHdfs.NameNodeProperty[] | undefined;
    private _qopConfiguration;
    get qopConfiguration(): AwsLocationHdfs.QopConfigurationPropertyOutputReference;
    putQopConfiguration(value: AwsLocationHdfs.QopConfigurationProperty): void;
    resetQopConfiguration(): void;
    get qopConfigurationInput(): AwsLocationHdfs.QopConfigurationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsLocationHdfsNameNodePropertyToTerraform(struct?: AwsLocationHdfs.NameNodeProperty | cdktn.IResolvable): any;
export declare function awsLocationHdfsNameNodePropertyToHclTerraform(struct?: AwsLocationHdfs.NameNodeProperty | cdktn.IResolvable): any;
export declare function awsLocationHdfsQopConfigurationPropertyToTerraform(struct?: AwsLocationHdfs.QopConfigurationPropertyOutputReference | AwsLocationHdfs.QopConfigurationProperty): any;
export declare function awsLocationHdfsQopConfigurationPropertyToHclTerraform(struct?: AwsLocationHdfs.QopConfigurationPropertyOutputReference | AwsLocationHdfs.QopConfigurationProperty): any;
export declare namespace AwsLocationHdfs {
    interface NameNodeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_hdfs#hostname AwsLocationHdfs#hostname}
        */
        readonly hostname: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_hdfs#port AwsLocationHdfs#port}
        */
        readonly port: number;
    }
    class NameNodePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NameNodeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NameNodeProperty | cdktn.IResolvable | undefined);
        private _hostname?;
        get hostname(): string;
        set hostname(value: string);
        get hostnameInput(): string | undefined;
        private _port?;
        get port(): number;
        set port(value: number);
        get portInput(): number | undefined;
    }
    class NameNodePropertyList extends cdktn.ComplexList {
        internalValue?: NameNodeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NameNodePropertyOutputReference;
    }
    interface QopConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_hdfs#data_transfer_protection AwsLocationHdfs#data_transfer_protection}
        */
        readonly dataTransferProtection?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_hdfs#rpc_protection AwsLocationHdfs#rpc_protection}
        */
        readonly rpcProtection?: string;
    }
    class QopConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): QopConfigurationProperty | undefined;
        set internalValue(value: QopConfigurationProperty | undefined);
        private _dataTransferProtection?;
        get dataTransferProtection(): string;
        set dataTransferProtection(value: string);
        resetDataTransferProtection(): void;
        get dataTransferProtectionInput(): string | undefined;
        private _rpcProtection?;
        get rpcProtection(): string;
        set rpcProtection(value: string);
        resetRpcProtection(): void;
        get rpcProtectionInput(): string | undefined;
    }
}
