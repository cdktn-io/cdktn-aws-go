import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsLocationEfsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_efs#access_point_arn AwsLocationEfs#access_point_arn}
    */
    readonly accessPointArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_efs#efs_file_system_arn AwsLocationEfs#efs_file_system_arn}
    */
    readonly efsFileSystemArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_efs#file_system_access_role_arn AwsLocationEfs#file_system_access_role_arn}
    */
    readonly fileSystemAccessRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_efs#id AwsLocationEfs#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_efs#in_transit_encryption AwsLocationEfs#in_transit_encryption}
    */
    readonly inTransitEncryption?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_efs#region AwsLocationEfs#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_efs#subdirectory AwsLocationEfs#subdirectory}
    */
    readonly subdirectory?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_efs#tags AwsLocationEfs#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_efs#tags_all AwsLocationEfs#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * ec2_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_efs#ec2_config AwsLocationEfs#ec2_config}
    */
    readonly ec2Config: AwsLocationEfs.Ec2ConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_efs aws_datasync_location_efs}
*/
export declare class AwsLocationEfs extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_datasync_location_efs";
    /**
    * Generates CDKTN code for importing a AwsLocationEfs resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsLocationEfs to import
    * @param importFromId The id of the existing AwsLocationEfs that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_efs#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsLocationEfs to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_efs aws_datasync_location_efs} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsLocationEfsConfig
    */
    constructor(scope: Construct, id: string, config: AwsLocationEfsConfig);
    private _accessPointArn?;
    get accessPointArn(): string;
    set accessPointArn(value: string);
    resetAccessPointArn(): void;
    get accessPointArnInput(): string | undefined;
    get arn(): string;
    private _efsFileSystemArn?;
    get efsFileSystemArn(): string;
    set efsFileSystemArn(value: string);
    get efsFileSystemArnInput(): string | undefined;
    private _fileSystemAccessRoleArn?;
    get fileSystemAccessRoleArn(): string;
    set fileSystemAccessRoleArn(value: string);
    resetFileSystemAccessRoleArn(): void;
    get fileSystemAccessRoleArnInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _inTransitEncryption?;
    get inTransitEncryption(): string;
    set inTransitEncryption(value: string);
    resetInTransitEncryption(): void;
    get inTransitEncryptionInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _subdirectory?;
    get subdirectory(): string;
    set subdirectory(value: string);
    resetSubdirectory(): void;
    get subdirectoryInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get uri(): string;
    private _ec2Config;
    get ec2Config(): AwsLocationEfs.Ec2ConfigPropertyOutputReference;
    putEc2Config(value: AwsLocationEfs.Ec2ConfigProperty): void;
    get ec2ConfigInput(): AwsLocationEfs.Ec2ConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsLocationEfsEc2ConfigPropertyToTerraform(struct?: AwsLocationEfs.Ec2ConfigPropertyOutputReference | AwsLocationEfs.Ec2ConfigProperty): any;
export declare function awsLocationEfsEc2ConfigPropertyToHclTerraform(struct?: AwsLocationEfs.Ec2ConfigPropertyOutputReference | AwsLocationEfs.Ec2ConfigProperty): any;
export declare namespace AwsLocationEfs {
    interface Ec2ConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_efs#security_group_arns AwsLocationEfs#security_group_arns}
        */
        readonly securityGroupArns: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_efs#subnet_arn AwsLocationEfs#subnet_arn}
        */
        readonly subnetArn: string;
    }
    class Ec2ConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): Ec2ConfigProperty | undefined;
        set internalValue(value: Ec2ConfigProperty | undefined);
        private _securityGroupArns?;
        get securityGroupArns(): string[];
        set securityGroupArns(value: string[]);
        get securityGroupArnsInput(): string[] | undefined;
        private _subnetArn?;
        get subnetArn(): string;
        set subnetArn(value: string);
        get subnetArnInput(): string | undefined;
    }
}
