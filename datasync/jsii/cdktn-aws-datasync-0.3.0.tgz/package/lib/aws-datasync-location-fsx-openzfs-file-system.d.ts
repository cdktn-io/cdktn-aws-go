import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsLocationFsxOpenzfsFileSystemConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_fsx_openzfs_file_system#fsx_filesystem_arn AwsLocationFsxOpenzfsFileSystem#fsx_filesystem_arn}
    */
    readonly fsxFilesystemArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_fsx_openzfs_file_system#id AwsLocationFsxOpenzfsFileSystem#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_fsx_openzfs_file_system#region AwsLocationFsxOpenzfsFileSystem#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_fsx_openzfs_file_system#security_group_arns AwsLocationFsxOpenzfsFileSystem#security_group_arns}
    */
    readonly securityGroupArns: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_fsx_openzfs_file_system#subdirectory AwsLocationFsxOpenzfsFileSystem#subdirectory}
    */
    readonly subdirectory?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_fsx_openzfs_file_system#tags AwsLocationFsxOpenzfsFileSystem#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_fsx_openzfs_file_system#tags_all AwsLocationFsxOpenzfsFileSystem#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * protocol block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_fsx_openzfs_file_system#protocol AwsLocationFsxOpenzfsFileSystem#protocol}
    */
    readonly protocol: AwsLocationFsxOpenzfsFileSystem.ProtocolProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_fsx_openzfs_file_system aws_datasync_location_fsx_openzfs_file_system}
*/
export declare class AwsLocationFsxOpenzfsFileSystem extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_datasync_location_fsx_openzfs_file_system";
    /**
    * Generates CDKTN code for importing a AwsLocationFsxOpenzfsFileSystem resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsLocationFsxOpenzfsFileSystem to import
    * @param importFromId The id of the existing AwsLocationFsxOpenzfsFileSystem that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_fsx_openzfs_file_system#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsLocationFsxOpenzfsFileSystem to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_fsx_openzfs_file_system aws_datasync_location_fsx_openzfs_file_system} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsLocationFsxOpenzfsFileSystemConfig
    */
    constructor(scope: Construct, id: string, config: AwsLocationFsxOpenzfsFileSystemConfig);
    get arn(): string;
    get creationTime(): string;
    private _fsxFilesystemArn?;
    get fsxFilesystemArn(): string;
    set fsxFilesystemArn(value: string);
    get fsxFilesystemArnInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _securityGroupArns?;
    get securityGroupArns(): string[];
    set securityGroupArns(value: string[]);
    get securityGroupArnsInput(): string[] | undefined;
    private _subdirectory?;
    get subdirectory(): string;
    set subdirectory(value: string);
    resetSubdirectory(): void;
    get subdirectoryInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get uri(): string;
    private _protocol;
    get protocol(): AwsLocationFsxOpenzfsFileSystem.ProtocolPropertyOutputReference;
    putProtocol(value: AwsLocationFsxOpenzfsFileSystem.ProtocolProperty): void;
    get protocolInput(): AwsLocationFsxOpenzfsFileSystem.ProtocolProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsLocationFsxOpenzfsFileSystemMountOptionsPropertyToTerraform(struct?: AwsLocationFsxOpenzfsFileSystem.MountOptionsPropertyOutputReference | AwsLocationFsxOpenzfsFileSystem.MountOptionsProperty): any;
export declare function awsLocationFsxOpenzfsFileSystemMountOptionsPropertyToHclTerraform(struct?: AwsLocationFsxOpenzfsFileSystem.MountOptionsPropertyOutputReference | AwsLocationFsxOpenzfsFileSystem.MountOptionsProperty): any;
export declare function awsLocationFsxOpenzfsFileSystemNfsPropertyToTerraform(struct?: AwsLocationFsxOpenzfsFileSystem.NfsPropertyOutputReference | AwsLocationFsxOpenzfsFileSystem.NfsProperty): any;
export declare function awsLocationFsxOpenzfsFileSystemNfsPropertyToHclTerraform(struct?: AwsLocationFsxOpenzfsFileSystem.NfsPropertyOutputReference | AwsLocationFsxOpenzfsFileSystem.NfsProperty): any;
export declare function awsLocationFsxOpenzfsFileSystemProtocolPropertyToTerraform(struct?: AwsLocationFsxOpenzfsFileSystem.ProtocolPropertyOutputReference | AwsLocationFsxOpenzfsFileSystem.ProtocolProperty): any;
export declare function awsLocationFsxOpenzfsFileSystemProtocolPropertyToHclTerraform(struct?: AwsLocationFsxOpenzfsFileSystem.ProtocolPropertyOutputReference | AwsLocationFsxOpenzfsFileSystem.ProtocolProperty): any;
export declare namespace AwsLocationFsxOpenzfsFileSystem {
    interface MountOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_fsx_openzfs_file_system#version AwsLocationFsxOpenzfsFileSystem#version}
        */
        readonly version?: string;
    }
    class MountOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MountOptionsProperty | undefined;
        set internalValue(value: MountOptionsProperty | undefined);
        private _version?;
        get version(): string;
        set version(value: string);
        resetVersion(): void;
        get versionInput(): string | undefined;
    }
    interface NfsProperty {
        /**
        * mount_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_fsx_openzfs_file_system#mount_options AwsLocationFsxOpenzfsFileSystem#mount_options}
        */
        readonly mountOptions: MountOptionsProperty;
    }
    class NfsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NfsProperty | undefined;
        set internalValue(value: NfsProperty | undefined);
        private _mountOptions;
        get mountOptions(): MountOptionsPropertyOutputReference;
        putMountOptions(value: MountOptionsProperty): void;
        get mountOptionsInput(): MountOptionsProperty | undefined;
    }
    interface ProtocolProperty {
        /**
        * nfs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_fsx_openzfs_file_system#nfs AwsLocationFsxOpenzfsFileSystem#nfs}
        */
        readonly nfs: NfsProperty;
    }
    class ProtocolPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ProtocolProperty | undefined;
        set internalValue(value: ProtocolProperty | undefined);
        private _nfs;
        get nfs(): NfsPropertyOutputReference;
        putNfs(value: NfsProperty): void;
        get nfsInput(): NfsProperty | undefined;
    }
}
