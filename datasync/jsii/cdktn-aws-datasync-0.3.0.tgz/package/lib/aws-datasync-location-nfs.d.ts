import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsLocationNfsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_nfs#id AwsLocationNfs#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_nfs#region AwsLocationNfs#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_nfs#server_hostname AwsLocationNfs#server_hostname}
    */
    readonly serverHostname: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_nfs#subdirectory AwsLocationNfs#subdirectory}
    */
    readonly subdirectory: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_nfs#tags AwsLocationNfs#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_nfs#tags_all AwsLocationNfs#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * mount_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_nfs#mount_options AwsLocationNfs#mount_options}
    */
    readonly mountOptions?: AwsLocationNfs.MountOptionsProperty;
    /**
    * on_prem_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_nfs#on_prem_config AwsLocationNfs#on_prem_config}
    */
    readonly onPremConfig: AwsLocationNfs.OnPremConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_nfs aws_datasync_location_nfs}
*/
export declare class AwsLocationNfs extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_datasync_location_nfs";
    /**
    * Generates CDKTN code for importing a AwsLocationNfs resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsLocationNfs to import
    * @param importFromId The id of the existing AwsLocationNfs that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_nfs#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsLocationNfs to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_nfs aws_datasync_location_nfs} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsLocationNfsConfig
    */
    constructor(scope: Construct, id: string, config: AwsLocationNfsConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _serverHostname?;
    get serverHostname(): string;
    set serverHostname(value: string);
    get serverHostnameInput(): string | undefined;
    private _subdirectory?;
    get subdirectory(): string;
    set subdirectory(value: string);
    get subdirectoryInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get uri(): string;
    private _mountOptions;
    get mountOptions(): AwsLocationNfs.MountOptionsPropertyOutputReference;
    putMountOptions(value: AwsLocationNfs.MountOptionsProperty): void;
    resetMountOptions(): void;
    get mountOptionsInput(): AwsLocationNfs.MountOptionsProperty | undefined;
    private _onPremConfig;
    get onPremConfig(): AwsLocationNfs.OnPremConfigPropertyOutputReference;
    putOnPremConfig(value: AwsLocationNfs.OnPremConfigProperty): void;
    get onPremConfigInput(): AwsLocationNfs.OnPremConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsLocationNfsMountOptionsPropertyToTerraform(struct?: AwsLocationNfs.MountOptionsPropertyOutputReference | AwsLocationNfs.MountOptionsProperty): any;
export declare function awsLocationNfsMountOptionsPropertyToHclTerraform(struct?: AwsLocationNfs.MountOptionsPropertyOutputReference | AwsLocationNfs.MountOptionsProperty): any;
export declare function awsLocationNfsOnPremConfigPropertyToTerraform(struct?: AwsLocationNfs.OnPremConfigPropertyOutputReference | AwsLocationNfs.OnPremConfigProperty): any;
export declare function awsLocationNfsOnPremConfigPropertyToHclTerraform(struct?: AwsLocationNfs.OnPremConfigPropertyOutputReference | AwsLocationNfs.OnPremConfigProperty): any;
export declare namespace AwsLocationNfs {
    interface MountOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_nfs#version AwsLocationNfs#version}
        */
        readonly version?: string;
    }
    class MountOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MountOptionsProperty | undefined;
        set internalValue(value: MountOptionsProperty | undefined);
        private _version?;
        get version(): string;
        set version(value: string);
        resetVersion(): void;
        get versionInput(): string | undefined;
    }
    interface OnPremConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_nfs#agent_arns AwsLocationNfs#agent_arns}
        */
        readonly agentArns: string[];
    }
    class OnPremConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OnPremConfigProperty | undefined;
        set internalValue(value: OnPremConfigProperty | undefined);
        private _agentArns?;
        get agentArns(): string[];
        set agentArns(value: string[]);
        get agentArnsInput(): string[] | undefined;
    }
}
