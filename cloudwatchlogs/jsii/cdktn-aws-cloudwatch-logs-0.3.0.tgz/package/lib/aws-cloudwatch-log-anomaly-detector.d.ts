import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAnomalyDetectorConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_anomaly_detector#anomaly_visibility_time AwsAnomalyDetector#anomaly_visibility_time}
    */
    readonly anomalyVisibilityTime?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_anomaly_detector#detector_name AwsAnomalyDetector#detector_name}
    */
    readonly detectorName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_anomaly_detector#enabled AwsAnomalyDetector#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_anomaly_detector#evaluation_frequency AwsAnomalyDetector#evaluation_frequency}
    */
    readonly evaluationFrequency?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_anomaly_detector#filter_pattern AwsAnomalyDetector#filter_pattern}
    */
    readonly filterPattern?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_anomaly_detector#kms_key_id AwsAnomalyDetector#kms_key_id}
    */
    readonly kmsKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_anomaly_detector#log_group_arn_list AwsAnomalyDetector#log_group_arn_list}
    */
    readonly logGroupArnList: string[];
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_anomaly_detector#region AwsAnomalyDetector#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_anomaly_detector#tags AwsAnomalyDetector#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_anomaly_detector aws_cloudwatch_log_anomaly_detector}
*/
export declare class AwsAnomalyDetector extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudwatch_log_anomaly_detector";
    /**
    * Generates CDKTN code for importing a AwsAnomalyDetector resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsAnomalyDetector to import
    * @param importFromId The id of the existing AwsAnomalyDetector that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_anomaly_detector#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsAnomalyDetector to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_anomaly_detector aws_cloudwatch_log_anomaly_detector} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAnomalyDetectorConfig
    */
    constructor(scope: Construct, id: string, config: AwsAnomalyDetectorConfig);
    private _anomalyVisibilityTime?;
    get anomalyVisibilityTime(): number;
    set anomalyVisibilityTime(value: number);
    resetAnomalyVisibilityTime(): void;
    get anomalyVisibilityTimeInput(): number | undefined;
    get arn(): string;
    private _detectorName?;
    get detectorName(): string;
    set detectorName(value: string);
    resetDetectorName(): void;
    get detectorNameInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _evaluationFrequency?;
    get evaluationFrequency(): string;
    set evaluationFrequency(value: string);
    resetEvaluationFrequency(): void;
    get evaluationFrequencyInput(): string | undefined;
    private _filterPattern?;
    get filterPattern(): string;
    set filterPattern(value: string);
    resetFilterPattern(): void;
    get filterPatternInput(): string | undefined;
    private _kmsKeyId?;
    get kmsKeyId(): string;
    set kmsKeyId(value: string);
    resetKmsKeyId(): void;
    get kmsKeyIdInput(): string | undefined;
    private _logGroupArnList?;
    get logGroupArnList(): string[];
    set logGroupArnList(value: string[]);
    get logGroupArnListInput(): string[] | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
