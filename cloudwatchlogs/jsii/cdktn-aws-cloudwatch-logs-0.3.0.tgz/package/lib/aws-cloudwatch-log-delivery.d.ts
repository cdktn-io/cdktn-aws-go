import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDeliveryConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_delivery#delivery_destination_arn AwsDelivery#delivery_destination_arn}
    */
    readonly deliveryDestinationArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_delivery#delivery_source_name AwsDelivery#delivery_source_name}
    */
    readonly deliverySourceName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_delivery#field_delimiter AwsDelivery#field_delimiter}
    */
    readonly fieldDelimiter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_delivery#record_fields AwsDelivery#record_fields}
    */
    readonly recordFields?: string[];
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_delivery#region AwsDelivery#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_delivery#s3_delivery_configuration AwsDelivery#s3_delivery_configuration}
    */
    readonly s3DeliveryConfiguration?: AwsDelivery.S3DeliveryConfigurationProperty[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_delivery#tags AwsDelivery#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_delivery aws_cloudwatch_log_delivery}
*/
export declare class AwsDelivery extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudwatch_log_delivery";
    /**
    * Generates CDKTN code for importing a AwsDelivery resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDelivery to import
    * @param importFromId The id of the existing AwsDelivery that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_delivery#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDelivery to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_delivery aws_cloudwatch_log_delivery} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDeliveryConfig
    */
    constructor(scope: Construct, id: string, config: AwsDeliveryConfig);
    get arn(): string;
    private _deliveryDestinationArn?;
    get deliveryDestinationArn(): string;
    set deliveryDestinationArn(value: string);
    get deliveryDestinationArnInput(): string | undefined;
    private _deliverySourceName?;
    get deliverySourceName(): string;
    set deliverySourceName(value: string);
    get deliverySourceNameInput(): string | undefined;
    private _fieldDelimiter?;
    get fieldDelimiter(): string;
    set fieldDelimiter(value: string);
    resetFieldDelimiter(): void;
    get fieldDelimiterInput(): string | undefined;
    get id(): string;
    private _recordFields?;
    get recordFields(): string[];
    set recordFields(value: string[]);
    resetRecordFields(): void;
    get recordFieldsInput(): string[] | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _s3DeliveryConfiguration;
    get s3DeliveryConfiguration(): AwsDelivery.S3DeliveryConfigurationPropertyList;
    putS3DeliveryConfiguration(value: AwsDelivery.S3DeliveryConfigurationProperty[] | cdktn.IResolvable): void;
    resetS3DeliveryConfiguration(): void;
    get s3DeliveryConfigurationInput(): cdktn.IResolvable | AwsDelivery.S3DeliveryConfigurationProperty[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsDeliveryS3DeliveryConfigurationPropertyToTerraform(struct?: AwsDelivery.S3DeliveryConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDeliveryS3DeliveryConfigurationPropertyToHclTerraform(struct?: AwsDelivery.S3DeliveryConfigurationProperty | cdktn.IResolvable): any;
export declare namespace AwsDelivery {
    interface S3DeliveryConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_delivery#enable_hive_compatible_path AwsDelivery#enable_hive_compatible_path}
        */
        readonly enableHiveCompatiblePath?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_delivery#suffix_path AwsDelivery#suffix_path}
        */
        readonly suffixPath?: string;
    }
    class S3DeliveryConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3DeliveryConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: S3DeliveryConfigurationProperty | cdktn.IResolvable | undefined);
        private _enableHiveCompatiblePath?;
        get enableHiveCompatiblePath(): boolean | cdktn.IResolvable;
        set enableHiveCompatiblePath(value: boolean | cdktn.IResolvable);
        resetEnableHiveCompatiblePath(): void;
        get enableHiveCompatiblePathInput(): boolean | cdktn.IResolvable | undefined;
        private _suffixPath?;
        get suffixPath(): string;
        set suffixPath(value: string);
        resetSuffixPath(): void;
        get suffixPathInput(): string | undefined;
    }
    class S3DeliveryConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: S3DeliveryConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3DeliveryConfigurationPropertyOutputReference;
    }
}
