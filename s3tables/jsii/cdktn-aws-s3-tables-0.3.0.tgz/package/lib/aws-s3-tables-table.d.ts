import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsTableConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3tables_table#encryption_configuration AwsTable#encryption_configuration}
    */
    readonly encryptionConfiguration?: AwsTable.EncryptionConfigurationProperty;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3tables_table#format AwsTable#format}
    */
    readonly format: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3tables_table#maintenance_configuration AwsTable#maintenance_configuration}
    */
    readonly maintenanceConfiguration?: AwsTable.MaintenanceConfigurationProperty;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3tables_table#name AwsTable#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3tables_table#namespace AwsTable#namespace}
    */
    readonly namespace: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3tables_table#region AwsTable#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3tables_table#table_bucket_arn AwsTable#table_bucket_arn}
    */
    readonly tableBucketArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3tables_table#tags AwsTable#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3tables_table#metadata AwsTable#metadata}
    */
    readonly metadata?: AwsTable.MetadataProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3tables_table aws_s3tables_table}
*/
export declare class AwsTable extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_s3tables_table";
    /**
    * Generates CDKTN code for importing a AwsTable resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsTable to import
    * @param importFromId The id of the existing AwsTable that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3tables_table#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsTable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3tables_table aws_s3tables_table} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsTableConfig
    */
    constructor(scope: Construct, id: string, config: AwsTableConfig);
    get arn(): string;
    get createdAt(): string;
    get createdBy(): string;
    private _encryptionConfiguration;
    get encryptionConfiguration(): AwsTable.EncryptionConfigurationPropertyOutputReference;
    putEncryptionConfiguration(value: AwsTable.EncryptionConfigurationProperty): void;
    resetEncryptionConfiguration(): void;
    get encryptionConfigurationInput(): cdktn.IResolvable | AwsTable.EncryptionConfigurationProperty | undefined;
    private _format?;
    get format(): string;
    set format(value: string);
    get formatInput(): string | undefined;
    private _maintenanceConfiguration;
    get maintenanceConfiguration(): AwsTable.MaintenanceConfigurationPropertyOutputReference;
    putMaintenanceConfiguration(value: AwsTable.MaintenanceConfigurationProperty): void;
    resetMaintenanceConfiguration(): void;
    get maintenanceConfigurationInput(): cdktn.IResolvable | AwsTable.MaintenanceConfigurationProperty | undefined;
    get metadataLocation(): string;
    get modifiedAt(): string;
    get modifiedBy(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    get namespaceInput(): string | undefined;
    get ownerAccountId(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tableBucketArn?;
    get tableBucketArn(): string;
    set tableBucketArn(value: string);
    get tableBucketArnInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    get type(): string;
    get versionToken(): string;
    get warehouseLocation(): string;
    private _metadata;
    get metadata(): AwsTable.MetadataPropertyList;
    putMetadata(value: AwsTable.MetadataProperty[] | cdktn.IResolvable): void;
    resetMetadata(): void;
    get metadataInput(): cdktn.IResolvable | AwsTable.MetadataProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsTableEncryptionConfigurationPropertyToTerraform(struct?: AwsTable.EncryptionConfigurationProperty | cdktn.IResolvable): any;
export declare function awsTableEncryptionConfigurationPropertyToHclTerraform(struct?: AwsTable.EncryptionConfigurationProperty | cdktn.IResolvable): any;
export declare function awsTableMaintenanceConfigurationIcebergCompactionSettingsPropertyToTerraform(struct?: AwsTable.MaintenanceConfigurationIcebergCompactionSettingsProperty | cdktn.IResolvable): any;
export declare function awsTableMaintenanceConfigurationIcebergCompactionSettingsPropertyToHclTerraform(struct?: AwsTable.MaintenanceConfigurationIcebergCompactionSettingsProperty | cdktn.IResolvable): any;
export declare function awsTableIcebergCompactionPropertyToTerraform(struct?: AwsTable.IcebergCompactionProperty | cdktn.IResolvable): any;
export declare function awsTableIcebergCompactionPropertyToHclTerraform(struct?: AwsTable.IcebergCompactionProperty | cdktn.IResolvable): any;
export declare function awsTableMaintenanceConfigurationIcebergSnapshotManagementSettingsPropertyToTerraform(struct?: AwsTable.MaintenanceConfigurationIcebergSnapshotManagementSettingsProperty | cdktn.IResolvable): any;
export declare function awsTableMaintenanceConfigurationIcebergSnapshotManagementSettingsPropertyToHclTerraform(struct?: AwsTable.MaintenanceConfigurationIcebergSnapshotManagementSettingsProperty | cdktn.IResolvable): any;
export declare function awsTableIcebergSnapshotManagementPropertyToTerraform(struct?: AwsTable.IcebergSnapshotManagementProperty | cdktn.IResolvable): any;
export declare function awsTableIcebergSnapshotManagementPropertyToHclTerraform(struct?: AwsTable.IcebergSnapshotManagementProperty | cdktn.IResolvable): any;
export declare function awsTableMaintenanceConfigurationPropertyToTerraform(struct?: AwsTable.MaintenanceConfigurationProperty | cdktn.IResolvable): any;
export declare function awsTableMaintenanceConfigurationPropertyToHclTerraform(struct?: AwsTable.MaintenanceConfigurationProperty | cdktn.IResolvable): any;
export declare function awsTableFieldPropertyToTerraform(struct?: AwsTable.FieldProperty | cdktn.IResolvable): any;
export declare function awsTableFieldPropertyToHclTerraform(struct?: AwsTable.FieldProperty | cdktn.IResolvable): any;
export declare function awsTableSchemaPropertyToTerraform(struct?: AwsTable.SchemaProperty | cdktn.IResolvable): any;
export declare function awsTableSchemaPropertyToHclTerraform(struct?: AwsTable.SchemaProperty | cdktn.IResolvable): any;
export declare function awsTableIcebergPropertyToTerraform(struct?: AwsTable.IcebergProperty | cdktn.IResolvable): any;
export declare function awsTableIcebergPropertyToHclTerraform(struct?: AwsTable.IcebergProperty | cdktn.IResolvable): any;
export declare function awsTableMetadataPropertyToTerraform(struct?: AwsTable.MetadataProperty | cdktn.IResolvable): any;
export declare function awsTableMetadataPropertyToHclTerraform(struct?: AwsTable.MetadataProperty | cdktn.IResolvable): any;
export declare namespace AwsTable {
    interface EncryptionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3tables_table#kms_key_arn AwsTable#kms_key_arn}
        */
        readonly kmsKeyArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3tables_table#sse_algorithm AwsTable#sse_algorithm}
        */
        readonly sseAlgorithm?: string;
    }
    class EncryptionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncryptionConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EncryptionConfigurationProperty | cdktn.IResolvable | undefined);
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        resetKmsKeyArn(): void;
        get kmsKeyArnInput(): string | undefined;
        private _sseAlgorithm?;
        get sseAlgorithm(): string;
        set sseAlgorithm(value: string);
        resetSseAlgorithm(): void;
        get sseAlgorithmInput(): string | undefined;
    }
    interface MaintenanceConfigurationIcebergCompactionSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3tables_table#target_file_size_mb AwsTable#target_file_size_mb}
        */
        readonly targetFileSizeMb?: number;
    }
    class MaintenanceConfigurationIcebergCompactionSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MaintenanceConfigurationIcebergCompactionSettingsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MaintenanceConfigurationIcebergCompactionSettingsProperty | cdktn.IResolvable | undefined);
        private _targetFileSizeMb?;
        get targetFileSizeMb(): number;
        set targetFileSizeMb(value: number);
        resetTargetFileSizeMb(): void;
        get targetFileSizeMbInput(): number | undefined;
    }
    interface IcebergCompactionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3tables_table#settings AwsTable#settings}
        */
        readonly settings?: MaintenanceConfigurationIcebergCompactionSettingsProperty;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3tables_table#status AwsTable#status}
        */
        readonly status?: string;
    }
    class IcebergCompactionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IcebergCompactionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IcebergCompactionProperty | cdktn.IResolvable | undefined);
        private _settings;
        get settings(): MaintenanceConfigurationIcebergCompactionSettingsPropertyOutputReference;
        putSettings(value: MaintenanceConfigurationIcebergCompactionSettingsProperty): void;
        resetSettings(): void;
        get settingsInput(): cdktn.IResolvable | MaintenanceConfigurationIcebergCompactionSettingsProperty | undefined;
        private _status?;
        get status(): string;
        set status(value: string);
        resetStatus(): void;
        get statusInput(): string | undefined;
    }
    interface MaintenanceConfigurationIcebergSnapshotManagementSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3tables_table#max_snapshot_age_hours AwsTable#max_snapshot_age_hours}
        */
        readonly maxSnapshotAgeHours?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3tables_table#min_snapshots_to_keep AwsTable#min_snapshots_to_keep}
        */
        readonly minSnapshotsToKeep?: number;
    }
    class MaintenanceConfigurationIcebergSnapshotManagementSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MaintenanceConfigurationIcebergSnapshotManagementSettingsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MaintenanceConfigurationIcebergSnapshotManagementSettingsProperty | cdktn.IResolvable | undefined);
        private _maxSnapshotAgeHours?;
        get maxSnapshotAgeHours(): number;
        set maxSnapshotAgeHours(value: number);
        resetMaxSnapshotAgeHours(): void;
        get maxSnapshotAgeHoursInput(): number | undefined;
        private _minSnapshotsToKeep?;
        get minSnapshotsToKeep(): number;
        set minSnapshotsToKeep(value: number);
        resetMinSnapshotsToKeep(): void;
        get minSnapshotsToKeepInput(): number | undefined;
    }
    interface IcebergSnapshotManagementProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3tables_table#settings AwsTable#settings}
        */
        readonly settings?: MaintenanceConfigurationIcebergSnapshotManagementSettingsProperty;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3tables_table#status AwsTable#status}
        */
        readonly status?: string;
    }
    class IcebergSnapshotManagementPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IcebergSnapshotManagementProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IcebergSnapshotManagementProperty | cdktn.IResolvable | undefined);
        private _settings;
        get settings(): MaintenanceConfigurationIcebergSnapshotManagementSettingsPropertyOutputReference;
        putSettings(value: MaintenanceConfigurationIcebergSnapshotManagementSettingsProperty): void;
        resetSettings(): void;
        get settingsInput(): cdktn.IResolvable | MaintenanceConfigurationIcebergSnapshotManagementSettingsProperty | undefined;
        private _status?;
        get status(): string;
        set status(value: string);
        resetStatus(): void;
        get statusInput(): string | undefined;
    }
    interface MaintenanceConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3tables_table#iceberg_compaction AwsTable#iceberg_compaction}
        */
        readonly icebergCompaction?: IcebergCompactionProperty;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3tables_table#iceberg_snapshot_management AwsTable#iceberg_snapshot_management}
        */
        readonly icebergSnapshotManagement?: IcebergSnapshotManagementProperty;
    }
    class MaintenanceConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MaintenanceConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MaintenanceConfigurationProperty | cdktn.IResolvable | undefined);
        private _icebergCompaction;
        get icebergCompaction(): IcebergCompactionPropertyOutputReference;
        putIcebergCompaction(value: IcebergCompactionProperty): void;
        resetIcebergCompaction(): void;
        get icebergCompactionInput(): cdktn.IResolvable | IcebergCompactionProperty | undefined;
        private _icebergSnapshotManagement;
        get icebergSnapshotManagement(): IcebergSnapshotManagementPropertyOutputReference;
        putIcebergSnapshotManagement(value: IcebergSnapshotManagementProperty): void;
        resetIcebergSnapshotManagement(): void;
        get icebergSnapshotManagementInput(): cdktn.IResolvable | IcebergSnapshotManagementProperty | undefined;
    }
    interface FieldProperty {
        /**
        * The name of the field.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3tables_table#name AwsTable#name}
        */
        readonly name: string;
        /**
        * A Boolean value that specifies whether values are required for each row in this field. Default: false.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3tables_table#required AwsTable#required}
        */
        readonly required?: boolean | cdktn.IResolvable;
        /**
        * The field type. S3 Tables supports all Apache Iceberg primitive types.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3tables_table#type AwsTable#type}
        */
        readonly type: string;
    }
    class FieldPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FieldProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FieldProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _required?;
        get required(): boolean | cdktn.IResolvable;
        set required(value: boolean | cdktn.IResolvable);
        resetRequired(): void;
        get requiredInput(): boolean | cdktn.IResolvable | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class FieldPropertyList extends cdktn.ComplexList {
        internalValue?: FieldProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FieldPropertyOutputReference;
    }
    interface SchemaProperty {
        /**
        * field block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3tables_table#field AwsTable#field}
        */
        readonly field?: FieldProperty[] | cdktn.IResolvable;
    }
    class SchemaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SchemaProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SchemaProperty | cdktn.IResolvable | undefined);
        private _field;
        get field(): FieldPropertyList;
        putField(value: FieldProperty[] | cdktn.IResolvable): void;
        resetField(): void;
        get fieldInput(): cdktn.IResolvable | FieldProperty[] | undefined;
    }
    class SchemaPropertyList extends cdktn.ComplexList {
        internalValue?: SchemaProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SchemaPropertyOutputReference;
    }
    interface IcebergProperty {
        /**
        * A map of configuration properties for the Iceberg table, for example `write.distribution-mode` and `write.sort-order`.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3tables_table#properties AwsTable#properties}
        */
        readonly properties?: {
            [key: string]: string;
        };
        /**
        * schema block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3tables_table#schema AwsTable#schema}
        */
        readonly schema?: SchemaProperty[] | cdktn.IResolvable;
    }
    class IcebergPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IcebergProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IcebergProperty | cdktn.IResolvable | undefined);
        private _properties?;
        get properties(): {
            [key: string]: string;
        };
        set properties(value: {
            [key: string]: string;
        });
        resetProperties(): void;
        get propertiesInput(): {
            [key: string]: string;
        } | undefined;
        private _schema;
        get schema(): SchemaPropertyList;
        putSchema(value: SchemaProperty[] | cdktn.IResolvable): void;
        resetSchema(): void;
        get schemaInput(): cdktn.IResolvable | SchemaProperty[] | undefined;
    }
    class IcebergPropertyList extends cdktn.ComplexList {
        internalValue?: IcebergProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IcebergPropertyOutputReference;
    }
    interface MetadataProperty {
        /**
        * iceberg block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3tables_table#iceberg AwsTable#iceberg}
        */
        readonly iceberg?: IcebergProperty[] | cdktn.IResolvable;
    }
    class MetadataPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MetadataProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MetadataProperty | cdktn.IResolvable | undefined);
        private _iceberg;
        get iceberg(): IcebergPropertyList;
        putIceberg(value: IcebergProperty[] | cdktn.IResolvable): void;
        resetIceberg(): void;
        get icebergInput(): cdktn.IResolvable | IcebergProperty[] | undefined;
    }
    class MetadataPropertyList extends cdktn.ComplexList {
        internalValue?: MetadataProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MetadataPropertyOutputReference;
    }
}
