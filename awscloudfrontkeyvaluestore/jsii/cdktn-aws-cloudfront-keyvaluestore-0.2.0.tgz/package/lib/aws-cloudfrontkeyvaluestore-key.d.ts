import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfKeyConfig extends cdktn.TerraformMetaArguments {
    /**
    * The key to put.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfrontkeyvaluestore_key#key TfKey#key}
    */
    readonly key: string;
    /**
    * The Amazon Resource Name (ARN) of the Key Value Store.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfrontkeyvaluestore_key#key_value_store_arn TfKey#key_value_store_arn}
    */
    readonly keyValueStoreArn: string;
    /**
    * The value to put.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfrontkeyvaluestore_key#value TfKey#value}
    */
    readonly value: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfrontkeyvaluestore_key aws_cloudfrontkeyvaluestore_key}
*/
export declare class TfKey extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudfrontkeyvaluestore_key";
    /**
    * Generates CDKTN code for importing a TfKey resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfKey to import
    * @param importFromId The id of the existing TfKey that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfrontkeyvaluestore_key#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfKey to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfrontkeyvaluestore_key aws_cloudfrontkeyvaluestore_key} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfKeyConfig
    */
    constructor(scope: Construct, id: string, config: TfKeyConfig);
    get id(): string;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _keyValueStoreArn?;
    get keyValueStoreArn(): string;
    set keyValueStoreArn(value: string);
    get keyValueStoreArnInput(): string | undefined;
    get totalSizeInBytes(): number;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
