import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfResourceShareConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ram_resource_share#allow_external_principals TfResourceShare#allow_external_principals}
    */
    readonly allowExternalPrincipals?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ram_resource_share#id TfResourceShare#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ram_resource_share#name TfResourceShare#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ram_resource_share#permission_arns TfResourceShare#permission_arns}
    */
    readonly permissionArns?: string[];
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ram_resource_share#region TfResourceShare#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ram_resource_share#tags TfResourceShare#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ram_resource_share#tags_all TfResourceShare#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * resource_share_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ram_resource_share#resource_share_configuration TfResourceShare#resource_share_configuration}
    */
    readonly resourceShareConfiguration?: TfResourceShare.ResourceShareConfigurationProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ram_resource_share#timeouts TfResourceShare#timeouts}
    */
    readonly timeouts?: TfResourceShare.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ram_resource_share aws_ram_resource_share}
*/
export declare class TfResourceShare extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ram_resource_share";
    /**
    * Generates CDKTN code for importing a TfResourceShare resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfResourceShare to import
    * @param importFromId The id of the existing TfResourceShare that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ram_resource_share#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfResourceShare to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ram_resource_share aws_ram_resource_share} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfResourceShareConfig
    */
    constructor(scope: Construct, id: string, config: TfResourceShareConfig);
    private _allowExternalPrincipals?;
    get allowExternalPrincipals(): boolean | cdktn.IResolvable;
    set allowExternalPrincipals(value: boolean | cdktn.IResolvable);
    resetAllowExternalPrincipals(): void;
    get allowExternalPrincipalsInput(): boolean | cdktn.IResolvable | undefined;
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _permissionArns?;
    get permissionArns(): string[];
    set permissionArns(value: string[]);
    resetPermissionArns(): void;
    get permissionArnsInput(): string[] | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _resourceShareConfiguration;
    get resourceShareConfiguration(): TfResourceShare.ResourceShareConfigurationPropertyOutputReference;
    putResourceShareConfiguration(value: TfResourceShare.ResourceShareConfigurationProperty): void;
    resetResourceShareConfiguration(): void;
    get resourceShareConfigurationInput(): TfResourceShare.ResourceShareConfigurationProperty | undefined;
    private _timeouts;
    get timeouts(): TfResourceShare.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfResourceShare.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfResourceShare.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfResourceShareResourceShareConfigurationPropertyToTerraform(struct?: TfResourceShare.ResourceShareConfigurationPropertyOutputReference | TfResourceShare.ResourceShareConfigurationProperty): any;
export declare function tfResourceShareResourceShareConfigurationPropertyToHclTerraform(struct?: TfResourceShare.ResourceShareConfigurationPropertyOutputReference | TfResourceShare.ResourceShareConfigurationProperty): any;
export declare function tfResourceShareTimeoutsPropertyToTerraform(struct?: TfResourceShare.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfResourceShareTimeoutsPropertyToHclTerraform(struct?: TfResourceShare.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfResourceShare {
    interface ResourceShareConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ram_resource_share#retain_sharing_on_account_leave_organization TfResourceShare#retain_sharing_on_account_leave_organization}
        */
        readonly retainSharingOnAccountLeaveOrganization?: boolean | cdktn.IResolvable;
    }
    class ResourceShareConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ResourceShareConfigurationProperty | undefined;
        set internalValue(value: ResourceShareConfigurationProperty | undefined);
        private _retainSharingOnAccountLeaveOrganization?;
        get retainSharingOnAccountLeaveOrganization(): boolean | cdktn.IResolvable;
        set retainSharingOnAccountLeaveOrganization(value: boolean | cdktn.IResolvable);
        resetRetainSharingOnAccountLeaveOrganization(): void;
        get retainSharingOnAccountLeaveOrganizationInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ram_resource_share#create TfResourceShare#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ram_resource_share#delete TfResourceShare#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
