import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsRamResourceShareAssociationsExclusiveConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ram_resource_share_associations_exclusive#principals AwsRamResourceShareAssociationsExclusive#principals}
    */
    readonly principals?: string[];
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ram_resource_share_associations_exclusive#region AwsRamResourceShareAssociationsExclusive#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ram_resource_share_associations_exclusive#resource_arns AwsRamResourceShareAssociationsExclusive#resource_arns}
    */
    readonly resourceArns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ram_resource_share_associations_exclusive#resource_share_arn AwsRamResourceShareAssociationsExclusive#resource_share_arn}
    */
    readonly resourceShareArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ram_resource_share_associations_exclusive#sources AwsRamResourceShareAssociationsExclusive#sources}
    */
    readonly sources?: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ram_resource_share_associations_exclusive aws_ram_resource_share_associations_exclusive}
*/
export declare class AwsRamResourceShareAssociationsExclusive extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ram_resource_share_associations_exclusive";
    /**
    * Generates CDKTN code for importing a AwsRamResourceShareAssociationsExclusive resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsRamResourceShareAssociationsExclusive to import
    * @param importFromId The id of the existing AwsRamResourceShareAssociationsExclusive that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ram_resource_share_associations_exclusive#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsRamResourceShareAssociationsExclusive to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ram_resource_share_associations_exclusive aws_ram_resource_share_associations_exclusive} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsRamResourceShareAssociationsExclusiveConfig
    */
    constructor(scope: Construct, id: string, config: AwsRamResourceShareAssociationsExclusiveConfig);
    private _principals?;
    get principals(): string[];
    set principals(value: string[]);
    resetPrincipals(): void;
    get principalsInput(): string[] | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resourceArns?;
    get resourceArns(): string[];
    set resourceArns(value: string[]);
    resetResourceArns(): void;
    get resourceArnsInput(): string[] | undefined;
    private _resourceShareArn?;
    get resourceShareArn(): string;
    set resourceShareArn(value: string);
    get resourceShareArnInput(): string | undefined;
    private _sources?;
    get sources(): string[];
    set sources(value: string[]);
    resetSources(): void;
    get sourcesInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
