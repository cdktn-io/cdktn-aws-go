import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfRevisionAssetsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dataexchange_revision_assets#comment TfRevisionAssets#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dataexchange_revision_assets#data_set_id TfRevisionAssets#data_set_id}
    */
    readonly dataSetId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dataexchange_revision_assets#finalized TfRevisionAssets#finalized}
    */
    readonly finalized?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dataexchange_revision_assets#force_destroy TfRevisionAssets#force_destroy}
    */
    readonly forceDestroy?: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dataexchange_revision_assets#region TfRevisionAssets#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dataexchange_revision_assets#tags TfRevisionAssets#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * asset block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dataexchange_revision_assets#asset TfRevisionAssets#asset}
    */
    readonly asset?: TfRevisionAssets.AssetProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dataexchange_revision_assets#timeouts TfRevisionAssets#timeouts}
    */
    readonly timeouts?: TfRevisionAssets.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dataexchange_revision_assets aws_dataexchange_revision_assets}
*/
export declare class TfRevisionAssets extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_dataexchange_revision_assets";
    /**
    * Generates CDKTN code for importing a TfRevisionAssets resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfRevisionAssets to import
    * @param importFromId The id of the existing TfRevisionAssets that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dataexchange_revision_assets#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfRevisionAssets to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dataexchange_revision_assets aws_dataexchange_revision_assets} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfRevisionAssetsConfig
    */
    constructor(scope: Construct, id: string, config: TfRevisionAssetsConfig);
    get arn(): string;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    get createdAt(): string;
    private _dataSetId?;
    get dataSetId(): string;
    set dataSetId(value: string);
    get dataSetIdInput(): string | undefined;
    private _finalized?;
    get finalized(): boolean | cdktn.IResolvable;
    set finalized(value: boolean | cdktn.IResolvable);
    resetFinalized(): void;
    get finalizedInput(): boolean | cdktn.IResolvable | undefined;
    private _forceDestroy?;
    get forceDestroy(): boolean | cdktn.IResolvable;
    set forceDestroy(value: boolean | cdktn.IResolvable);
    resetForceDestroy(): void;
    get forceDestroyInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    get updatedAt(): string;
    private _asset;
    get asset(): TfRevisionAssets.AssetPropertyList;
    putAsset(value: TfRevisionAssets.AssetProperty[] | cdktn.IResolvable): void;
    resetAsset(): void;
    get assetInput(): cdktn.IResolvable | TfRevisionAssets.AssetProperty[] | undefined;
    private _timeouts;
    get timeouts(): TfRevisionAssets.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfRevisionAssets.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfRevisionAssets.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfRevisionAssetsKmsKeysToGrantPropertyToTerraform(struct?: TfRevisionAssets.KmsKeysToGrantProperty | cdktn.IResolvable): any;
export declare function tfRevisionAssetsKmsKeysToGrantPropertyToHclTerraform(struct?: TfRevisionAssets.KmsKeysToGrantProperty | cdktn.IResolvable): any;
export declare function tfRevisionAssetsAssetCreateS3DataAccessFromS3BucketAssetSourcePropertyToTerraform(struct?: TfRevisionAssets.AssetCreateS3DataAccessFromS3BucketAssetSourceProperty | cdktn.IResolvable): any;
export declare function tfRevisionAssetsAssetCreateS3DataAccessFromS3BucketAssetSourcePropertyToHclTerraform(struct?: TfRevisionAssets.AssetCreateS3DataAccessFromS3BucketAssetSourceProperty | cdktn.IResolvable): any;
export declare function tfRevisionAssetsCreateS3DataAccessFromS3BucketPropertyToTerraform(struct?: TfRevisionAssets.CreateS3DataAccessFromS3BucketProperty | cdktn.IResolvable): any;
export declare function tfRevisionAssetsCreateS3DataAccessFromS3BucketPropertyToHclTerraform(struct?: TfRevisionAssets.CreateS3DataAccessFromS3BucketProperty | cdktn.IResolvable): any;
export declare function tfRevisionAssetsAssetImportAssetsFromS3AssetSourcePropertyToTerraform(struct?: TfRevisionAssets.AssetImportAssetsFromS3AssetSourceProperty | cdktn.IResolvable): any;
export declare function tfRevisionAssetsAssetImportAssetsFromS3AssetSourcePropertyToHclTerraform(struct?: TfRevisionAssets.AssetImportAssetsFromS3AssetSourceProperty | cdktn.IResolvable): any;
export declare function tfRevisionAssetsImportAssetsFromS3PropertyToTerraform(struct?: TfRevisionAssets.ImportAssetsFromS3Property | cdktn.IResolvable): any;
export declare function tfRevisionAssetsImportAssetsFromS3PropertyToHclTerraform(struct?: TfRevisionAssets.ImportAssetsFromS3Property | cdktn.IResolvable): any;
export declare function tfRevisionAssetsImportAssetsFromSignedUrlPropertyToTerraform(struct?: TfRevisionAssets.ImportAssetsFromSignedUrlProperty | cdktn.IResolvable): any;
export declare function tfRevisionAssetsImportAssetsFromSignedUrlPropertyToHclTerraform(struct?: TfRevisionAssets.ImportAssetsFromSignedUrlProperty | cdktn.IResolvable): any;
export declare function tfRevisionAssetsAssetPropertyToTerraform(struct?: TfRevisionAssets.AssetProperty | cdktn.IResolvable): any;
export declare function tfRevisionAssetsAssetPropertyToHclTerraform(struct?: TfRevisionAssets.AssetProperty | cdktn.IResolvable): any;
export declare function tfRevisionAssetsTimeoutsPropertyToTerraform(struct?: TfRevisionAssets.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfRevisionAssetsTimeoutsPropertyToHclTerraform(struct?: TfRevisionAssets.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfRevisionAssets {
    interface KmsKeysToGrantProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dataexchange_revision_assets#kms_key_arn TfRevisionAssets#kms_key_arn}
        */
        readonly kmsKeyArn: string;
    }
    class KmsKeysToGrantPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KmsKeysToGrantProperty | cdktn.IResolvable | undefined;
        set internalValue(value: KmsKeysToGrantProperty | cdktn.IResolvable | undefined);
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        get kmsKeyArnInput(): string | undefined;
    }
    class KmsKeysToGrantPropertyList extends cdktn.ComplexList {
        internalValue?: KmsKeysToGrantProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KmsKeysToGrantPropertyOutputReference;
    }
    interface AssetCreateS3DataAccessFromS3BucketAssetSourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dataexchange_revision_assets#bucket TfRevisionAssets#bucket}
        */
        readonly bucket: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dataexchange_revision_assets#key_prefixes TfRevisionAssets#key_prefixes}
        */
        readonly keyPrefixes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dataexchange_revision_assets#keys TfRevisionAssets#keys}
        */
        readonly keys?: string[];
        /**
        * kms_keys_to_grant block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dataexchange_revision_assets#kms_keys_to_grant TfRevisionAssets#kms_keys_to_grant}
        */
        readonly kmsKeysToGrant?: KmsKeysToGrantProperty[] | cdktn.IResolvable;
    }
    class AssetCreateS3DataAccessFromS3BucketAssetSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AssetCreateS3DataAccessFromS3BucketAssetSourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AssetCreateS3DataAccessFromS3BucketAssetSourceProperty | cdktn.IResolvable | undefined);
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        get bucketInput(): string | undefined;
        private _keyPrefixes?;
        get keyPrefixes(): string[];
        set keyPrefixes(value: string[]);
        resetKeyPrefixes(): void;
        get keyPrefixesInput(): string[] | undefined;
        private _keys?;
        get keys(): string[];
        set keys(value: string[]);
        resetKeys(): void;
        get keysInput(): string[] | undefined;
        private _kmsKeysToGrant;
        get kmsKeysToGrant(): KmsKeysToGrantPropertyList;
        putKmsKeysToGrant(value: KmsKeysToGrantProperty[] | cdktn.IResolvable): void;
        resetKmsKeysToGrant(): void;
        get kmsKeysToGrantInput(): cdktn.IResolvable | KmsKeysToGrantProperty[] | undefined;
    }
    class AssetCreateS3DataAccessFromS3BucketAssetSourcePropertyList extends cdktn.ComplexList {
        internalValue?: AssetCreateS3DataAccessFromS3BucketAssetSourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AssetCreateS3DataAccessFromS3BucketAssetSourcePropertyOutputReference;
    }
    interface CreateS3DataAccessFromS3BucketProperty {
        /**
        * asset_source block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dataexchange_revision_assets#asset_source TfRevisionAssets#asset_source}
        */
        readonly assetSource?: AssetCreateS3DataAccessFromS3BucketAssetSourceProperty[] | cdktn.IResolvable;
    }
    class CreateS3DataAccessFromS3BucketPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CreateS3DataAccessFromS3BucketProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CreateS3DataAccessFromS3BucketProperty | cdktn.IResolvable | undefined);
        get accessPointAlias(): string;
        get accessPointArn(): string;
        private _assetSource;
        get assetSource(): AssetCreateS3DataAccessFromS3BucketAssetSourcePropertyList;
        putAssetSource(value: AssetCreateS3DataAccessFromS3BucketAssetSourceProperty[] | cdktn.IResolvable): void;
        resetAssetSource(): void;
        get assetSourceInput(): cdktn.IResolvable | AssetCreateS3DataAccessFromS3BucketAssetSourceProperty[] | undefined;
    }
    class CreateS3DataAccessFromS3BucketPropertyList extends cdktn.ComplexList {
        internalValue?: CreateS3DataAccessFromS3BucketProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CreateS3DataAccessFromS3BucketPropertyOutputReference;
    }
    interface AssetImportAssetsFromS3AssetSourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dataexchange_revision_assets#bucket TfRevisionAssets#bucket}
        */
        readonly bucket: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dataexchange_revision_assets#key TfRevisionAssets#key}
        */
        readonly key: string;
    }
    class AssetImportAssetsFromS3AssetSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AssetImportAssetsFromS3AssetSourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AssetImportAssetsFromS3AssetSourceProperty | cdktn.IResolvable | undefined);
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        get bucketInput(): string | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
    }
    class AssetImportAssetsFromS3AssetSourcePropertyList extends cdktn.ComplexList {
        internalValue?: AssetImportAssetsFromS3AssetSourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AssetImportAssetsFromS3AssetSourcePropertyOutputReference;
    }
    interface ImportAssetsFromS3Property {
        /**
        * asset_source block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dataexchange_revision_assets#asset_source TfRevisionAssets#asset_source}
        */
        readonly assetSource?: AssetImportAssetsFromS3AssetSourceProperty[] | cdktn.IResolvable;
    }
    class ImportAssetsFromS3PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ImportAssetsFromS3Property | cdktn.IResolvable | undefined;
        set internalValue(value: ImportAssetsFromS3Property | cdktn.IResolvable | undefined);
        private _assetSource;
        get assetSource(): AssetImportAssetsFromS3AssetSourcePropertyList;
        putAssetSource(value: AssetImportAssetsFromS3AssetSourceProperty[] | cdktn.IResolvable): void;
        resetAssetSource(): void;
        get assetSourceInput(): cdktn.IResolvable | AssetImportAssetsFromS3AssetSourceProperty[] | undefined;
    }
    class ImportAssetsFromS3PropertyList extends cdktn.ComplexList {
        internalValue?: ImportAssetsFromS3Property[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ImportAssetsFromS3PropertyOutputReference;
    }
    interface ImportAssetsFromSignedUrlProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dataexchange_revision_assets#filename TfRevisionAssets#filename}
        */
        readonly filename: string;
    }
    class ImportAssetsFromSignedUrlPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ImportAssetsFromSignedUrlProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ImportAssetsFromSignedUrlProperty | cdktn.IResolvable | undefined);
        private _filename?;
        get filename(): string;
        set filename(value: string);
        get filenameInput(): string | undefined;
    }
    class ImportAssetsFromSignedUrlPropertyList extends cdktn.ComplexList {
        internalValue?: ImportAssetsFromSignedUrlProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ImportAssetsFromSignedUrlPropertyOutputReference;
    }
    interface AssetProperty {
        /**
        * create_s3_data_access_from_s3_bucket block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dataexchange_revision_assets#create_s3_data_access_from_s3_bucket TfRevisionAssets#create_s3_data_access_from_s3_bucket}
        */
        readonly createS3DataAccessFromS3Bucket?: CreateS3DataAccessFromS3BucketProperty[] | cdktn.IResolvable;
        /**
        * import_assets_from_s3 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dataexchange_revision_assets#import_assets_from_s3 TfRevisionAssets#import_assets_from_s3}
        */
        readonly importAssetsFromS3?: ImportAssetsFromS3Property[] | cdktn.IResolvable;
        /**
        * import_assets_from_signed_url block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dataexchange_revision_assets#import_assets_from_signed_url TfRevisionAssets#import_assets_from_signed_url}
        */
        readonly importAssetsFromSignedUrl?: ImportAssetsFromSignedUrlProperty[] | cdktn.IResolvable;
    }
    class AssetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AssetProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AssetProperty | cdktn.IResolvable | undefined);
        get arn(): string;
        get createdAt(): string;
        get id(): string;
        get name(): string;
        get updatedAt(): string;
        private _createS3DataAccessFromS3Bucket;
        get createS3DataAccessFromS3Bucket(): CreateS3DataAccessFromS3BucketPropertyList;
        putCreateS3DataAccessFromS3Bucket(value: CreateS3DataAccessFromS3BucketProperty[] | cdktn.IResolvable): void;
        resetCreateS3DataAccessFromS3Bucket(): void;
        get createS3DataAccessFromS3BucketInput(): cdktn.IResolvable | CreateS3DataAccessFromS3BucketProperty[] | undefined;
        private _importAssetsFromS3;
        get importAssetsFromS3(): ImportAssetsFromS3PropertyList;
        putImportAssetsFromS3(value: ImportAssetsFromS3Property[] | cdktn.IResolvable): void;
        resetImportAssetsFromS3(): void;
        get importAssetsFromS3Input(): cdktn.IResolvable | ImportAssetsFromS3Property[] | undefined;
        private _importAssetsFromSignedUrl;
        get importAssetsFromSignedUrl(): ImportAssetsFromSignedUrlPropertyList;
        putImportAssetsFromSignedUrl(value: ImportAssetsFromSignedUrlProperty[] | cdktn.IResolvable): void;
        resetImportAssetsFromSignedUrl(): void;
        get importAssetsFromSignedUrlInput(): cdktn.IResolvable | ImportAssetsFromSignedUrlProperty[] | undefined;
    }
    class AssetPropertyList extends cdktn.ComplexList {
        internalValue?: AssetProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AssetPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dataexchange_revision_assets#create TfRevisionAssets#create}
        */
        readonly create?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
    }
}
