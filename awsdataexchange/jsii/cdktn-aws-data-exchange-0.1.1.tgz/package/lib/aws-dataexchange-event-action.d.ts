import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDataexchangeEventActionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dataexchange_event_action#region AwsDataexchangeEventAction#region}
    */
    readonly region?: string;
    /**
    * action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dataexchange_event_action#action AwsDataexchangeEventAction#action}
    */
    readonly action?: AwsDataexchangeEventAction.ActionProperty[] | cdktn.IResolvable;
    /**
    * event block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dataexchange_event_action#event AwsDataexchangeEventAction#event}
    */
    readonly event?: AwsDataexchangeEventAction.EventProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dataexchange_event_action aws_dataexchange_event_action}
*/
export declare class AwsDataexchangeEventAction extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_dataexchange_event_action";
    /**
    * Generates CDKTN code for importing a AwsDataexchangeEventAction resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDataexchangeEventAction to import
    * @param importFromId The id of the existing AwsDataexchangeEventAction that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dataexchange_event_action#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDataexchangeEventAction to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dataexchange_event_action aws_dataexchange_event_action} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDataexchangeEventActionConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AwsDataexchangeEventActionConfig);
    get arn(): string;
    get createdAt(): string;
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get updatedAt(): string;
    private _action;
    get action(): AwsDataexchangeEventAction.ActionPropertyList;
    putAction(value: AwsDataexchangeEventAction.ActionProperty[] | cdktn.IResolvable): void;
    resetAction(): void;
    get actionInput(): cdktn.IResolvable | AwsDataexchangeEventAction.ActionProperty[] | undefined;
    private _event;
    get event(): AwsDataexchangeEventAction.EventPropertyList;
    putEvent(value: AwsDataexchangeEventAction.EventProperty[] | cdktn.IResolvable): void;
    resetEvent(): void;
    get eventInput(): cdktn.IResolvable | AwsDataexchangeEventAction.EventProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsDataexchangeEventActionEncryptionPropertyToTerraform(struct?: AwsDataexchangeEventAction.EncryptionProperty | cdktn.IResolvable): any;
export declare function awsDataexchangeEventActionEncryptionPropertyToHclTerraform(struct?: AwsDataexchangeEventAction.EncryptionProperty | cdktn.IResolvable): any;
export declare function awsDataexchangeEventActionRevisionDestinationPropertyToTerraform(struct?: AwsDataexchangeEventAction.RevisionDestinationProperty | cdktn.IResolvable): any;
export declare function awsDataexchangeEventActionRevisionDestinationPropertyToHclTerraform(struct?: AwsDataexchangeEventAction.RevisionDestinationProperty | cdktn.IResolvable): any;
export declare function awsDataexchangeEventActionExportRevisionToS3PropertyToTerraform(struct?: AwsDataexchangeEventAction.ExportRevisionToS3Property | cdktn.IResolvable): any;
export declare function awsDataexchangeEventActionExportRevisionToS3PropertyToHclTerraform(struct?: AwsDataexchangeEventAction.ExportRevisionToS3Property | cdktn.IResolvable): any;
export declare function awsDataexchangeEventActionActionPropertyToTerraform(struct?: AwsDataexchangeEventAction.ActionProperty | cdktn.IResolvable): any;
export declare function awsDataexchangeEventActionActionPropertyToHclTerraform(struct?: AwsDataexchangeEventAction.ActionProperty | cdktn.IResolvable): any;
export declare function awsDataexchangeEventActionRevisionPublishedPropertyToTerraform(struct?: AwsDataexchangeEventAction.RevisionPublishedProperty | cdktn.IResolvable): any;
export declare function awsDataexchangeEventActionRevisionPublishedPropertyToHclTerraform(struct?: AwsDataexchangeEventAction.RevisionPublishedProperty | cdktn.IResolvable): any;
export declare function awsDataexchangeEventActionEventPropertyToTerraform(struct?: AwsDataexchangeEventAction.EventProperty | cdktn.IResolvable): any;
export declare function awsDataexchangeEventActionEventPropertyToHclTerraform(struct?: AwsDataexchangeEventAction.EventProperty | cdktn.IResolvable): any;
export declare namespace AwsDataexchangeEventAction {
    interface EncryptionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dataexchange_event_action#kms_key_arn AwsDataexchangeEventAction#kms_key_arn}
        */
        readonly kmsKeyArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dataexchange_event_action#type AwsDataexchangeEventAction#type}
        */
        readonly type?: string;
    }
    class EncryptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EncryptionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EncryptionProperty | cdktn.IResolvable | undefined);
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        resetKmsKeyArn(): void;
        get kmsKeyArnInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
    }
    class EncryptionPropertyList extends cdktn.ComplexList {
        internalValue?: EncryptionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EncryptionPropertyOutputReference;
    }
    interface RevisionDestinationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dataexchange_event_action#bucket AwsDataexchangeEventAction#bucket}
        */
        readonly bucket: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dataexchange_event_action#key_pattern AwsDataexchangeEventAction#key_pattern}
        */
        readonly keyPattern?: string;
    }
    class RevisionDestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RevisionDestinationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RevisionDestinationProperty | cdktn.IResolvable | undefined);
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        get bucketInput(): string | undefined;
        private _keyPattern?;
        get keyPattern(): string;
        set keyPattern(value: string);
        resetKeyPattern(): void;
        get keyPatternInput(): string | undefined;
    }
    class RevisionDestinationPropertyList extends cdktn.ComplexList {
        internalValue?: RevisionDestinationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RevisionDestinationPropertyOutputReference;
    }
    interface ExportRevisionToS3Property {
        /**
        * encryption block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dataexchange_event_action#encryption AwsDataexchangeEventAction#encryption}
        */
        readonly encryption?: EncryptionProperty[] | cdktn.IResolvable;
        /**
        * revision_destination block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dataexchange_event_action#revision_destination AwsDataexchangeEventAction#revision_destination}
        */
        readonly revisionDestination?: RevisionDestinationProperty[] | cdktn.IResolvable;
    }
    class ExportRevisionToS3PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExportRevisionToS3Property | cdktn.IResolvable | undefined;
        set internalValue(value: ExportRevisionToS3Property | cdktn.IResolvable | undefined);
        private _encryption;
        get encryption(): EncryptionPropertyList;
        putEncryption(value: EncryptionProperty[] | cdktn.IResolvable): void;
        resetEncryption(): void;
        get encryptionInput(): cdktn.IResolvable | EncryptionProperty[] | undefined;
        private _revisionDestination;
        get revisionDestination(): RevisionDestinationPropertyList;
        putRevisionDestination(value: RevisionDestinationProperty[] | cdktn.IResolvable): void;
        resetRevisionDestination(): void;
        get revisionDestinationInput(): cdktn.IResolvable | RevisionDestinationProperty[] | undefined;
    }
    class ExportRevisionToS3PropertyList extends cdktn.ComplexList {
        internalValue?: ExportRevisionToS3Property[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExportRevisionToS3PropertyOutputReference;
    }
    interface ActionProperty {
        /**
        * export_revision_to_s3 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dataexchange_event_action#export_revision_to_s3 AwsDataexchangeEventAction#export_revision_to_s3}
        */
        readonly exportRevisionToS3?: ExportRevisionToS3Property[] | cdktn.IResolvable;
    }
    class ActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ActionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ActionProperty | cdktn.IResolvable | undefined);
        private _exportRevisionToS3;
        get exportRevisionToS3(): ExportRevisionToS3PropertyList;
        putExportRevisionToS3(value: ExportRevisionToS3Property[] | cdktn.IResolvable): void;
        resetExportRevisionToS3(): void;
        get exportRevisionToS3Input(): cdktn.IResolvable | ExportRevisionToS3Property[] | undefined;
    }
    class ActionPropertyList extends cdktn.ComplexList {
        internalValue?: ActionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ActionPropertyOutputReference;
    }
    interface RevisionPublishedProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dataexchange_event_action#data_set_id AwsDataexchangeEventAction#data_set_id}
        */
        readonly dataSetId: string;
    }
    class RevisionPublishedPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RevisionPublishedProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RevisionPublishedProperty | cdktn.IResolvable | undefined);
        private _dataSetId?;
        get dataSetId(): string;
        set dataSetId(value: string);
        get dataSetIdInput(): string | undefined;
    }
    class RevisionPublishedPropertyList extends cdktn.ComplexList {
        internalValue?: RevisionPublishedProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RevisionPublishedPropertyOutputReference;
    }
    interface EventProperty {
        /**
        * revision_published block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dataexchange_event_action#revision_published AwsDataexchangeEventAction#revision_published}
        */
        readonly revisionPublished?: RevisionPublishedProperty[] | cdktn.IResolvable;
    }
    class EventPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EventProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EventProperty | cdktn.IResolvable | undefined);
        private _revisionPublished;
        get revisionPublished(): RevisionPublishedPropertyList;
        putRevisionPublished(value: RevisionPublishedProperty[] | cdktn.IResolvable): void;
        resetRevisionPublished(): void;
        get revisionPublishedInput(): cdktn.IResolvable | RevisionPublishedProperty[] | undefined;
    }
    class EventPropertyList extends cdktn.ComplexList {
        internalValue?: EventProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EventPropertyOutputReference;
    }
}
