import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfClusterActivityStreamConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster_activity_stream#engine_native_audit_fields_included TfClusterActivityStream#engine_native_audit_fields_included}
    */
    readonly engineNativeAuditFieldsIncluded?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster_activity_stream#id TfClusterActivityStream#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster_activity_stream#kms_key_id TfClusterActivityStream#kms_key_id}
    */
    readonly kmsKeyId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster_activity_stream#mode TfClusterActivityStream#mode}
    */
    readonly mode: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster_activity_stream#region TfClusterActivityStream#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster_activity_stream#resource_arn TfClusterActivityStream#resource_arn}
    */
    readonly resourceArn: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster_activity_stream aws_rds_cluster_activity_stream}
*/
export declare class TfClusterActivityStream extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_rds_cluster_activity_stream";
    /**
    * Generates CDKTN code for importing a TfClusterActivityStream resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfClusterActivityStream to import
    * @param importFromId The id of the existing TfClusterActivityStream that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster_activity_stream#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfClusterActivityStream to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster_activity_stream aws_rds_cluster_activity_stream} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfClusterActivityStreamConfig
    */
    constructor(scope: Construct, id: string, config: TfClusterActivityStreamConfig);
    private _engineNativeAuditFieldsIncluded?;
    get engineNativeAuditFieldsIncluded(): boolean | cdktn.IResolvable;
    set engineNativeAuditFieldsIncluded(value: boolean | cdktn.IResolvable);
    resetEngineNativeAuditFieldsIncluded(): void;
    get engineNativeAuditFieldsIncludedInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get kinesisStreamName(): string;
    private _kmsKeyId?;
    get kmsKeyId(): string;
    set kmsKeyId(value: string);
    get kmsKeyIdInput(): string | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    get modeInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resourceArn?;
    get resourceArn(): string;
    set resourceArn(value: string);
    get resourceArnInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
