import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfCertificateConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_certificate#default_for_new_launches DataTfCertificate#default_for_new_launches}
    */
    readonly defaultForNewLaunches?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_certificate#id DataTfCertificate#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_certificate#latest_valid_till DataTfCertificate#latest_valid_till}
    */
    readonly latestValidTill?: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_certificate#region DataTfCertificate#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_certificate aws_rds_certificate}
*/
export declare class DataTfCertificate extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_rds_certificate";
    /**
    * Generates CDKTN code for importing a DataTfCertificate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfCertificate to import
    * @param importFromId The id of the existing DataTfCertificate that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_certificate#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfCertificate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_certificate aws_rds_certificate} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfCertificateConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataTfCertificateConfig);
    get arn(): string;
    get certificateType(): string;
    get customerOverride(): cdktn.IResolvable;
    get customerOverrideValidTill(): string;
    private _defaultForNewLaunches?;
    get defaultForNewLaunches(): boolean | cdktn.IResolvable;
    set defaultForNewLaunches(value: boolean | cdktn.IResolvable);
    resetDefaultForNewLaunches(): void;
    get defaultForNewLaunchesInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _latestValidTill?;
    get latestValidTill(): boolean | cdktn.IResolvable;
    set latestValidTill(value: boolean | cdktn.IResolvable);
    resetLatestValidTill(): void;
    get latestValidTillInput(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get thumbprint(): string;
    get validFrom(): string;
    get validTill(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
