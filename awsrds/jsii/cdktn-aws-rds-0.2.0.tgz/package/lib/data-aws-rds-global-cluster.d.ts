import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfGlobalClusterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_global_cluster#identifier DataTfGlobalCluster#identifier}
    */
    readonly identifier: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_global_cluster#region DataTfGlobalCluster#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_global_cluster aws_rds_global_cluster}
*/
export declare class DataTfGlobalCluster extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_rds_global_cluster";
    /**
    * Generates CDKTN code for importing a DataTfGlobalCluster resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfGlobalCluster to import
    * @param importFromId The id of the existing DataTfGlobalCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_global_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfGlobalCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_global_cluster aws_rds_global_cluster} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfGlobalClusterConfig
    */
    constructor(scope: Construct, id: string, config: DataTfGlobalClusterConfig);
    get arn(): string;
    get databaseName(): string;
    get deletionProtection(): cdktn.IResolvable;
    get endpoint(): string;
    get engine(): string;
    get engineLifecycleSupport(): string;
    get engineVersion(): string;
    private _identifier?;
    get identifier(): string;
    set identifier(value: string);
    get identifierInput(): string | undefined;
    private _members;
    get members(): DataTfGlobalCluster.MembersPropertyList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get resourceId(): string;
    get storageEncrypted(): cdktn.IResolvable;
    private _tags;
    get tags(): cdktn.StringMap;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfGlobalClusterMembersPropertyToTerraform(struct?: DataTfGlobalCluster.MembersProperty): any;
export declare function dataTfGlobalClusterMembersPropertyToHclTerraform(struct?: DataTfGlobalCluster.MembersProperty): any;
export declare namespace DataTfGlobalCluster {
    interface MembersProperty {
    }
    class MembersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MembersProperty | undefined;
        set internalValue(value: MembersProperty | undefined);
        get dbClusterArn(): string;
        get isWriter(): cdktn.IResolvable;
    }
    class MembersPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MembersPropertyOutputReference;
    }
}
