import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfDbProxyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/db_proxy#id DataTfDbProxy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/db_proxy#name DataTfDbProxy#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/db_proxy#region DataTfDbProxy#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/db_proxy aws_db_proxy}
*/
export declare class DataTfDbProxy extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_db_proxy";
    /**
    * Generates CDKTN code for importing a DataTfDbProxy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfDbProxy to import
    * @param importFromId The id of the existing DataTfDbProxy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/db_proxy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfDbProxy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/db_proxy aws_db_proxy} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfDbProxyConfig
    */
    constructor(scope: Construct, id: string, config: DataTfDbProxyConfig);
    get arn(): string;
    private _auth;
    get auth(): DataTfDbProxy.AuthPropertyList;
    get debugLogging(): cdktn.IResolvable;
    get defaultAuthScheme(): string;
    get endpoint(): string;
    get endpointNetworkType(): string;
    get engineFamily(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get idleClientTimeout(): number;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get requireTls(): cdktn.IResolvable;
    get roleArn(): string;
    get targetConnectionNetworkType(): string;
    get vpcId(): string;
    get vpcSecurityGroupIds(): string[];
    get vpcSubnetIds(): string[];
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfDbProxyAuthPropertyToTerraform(struct?: DataTfDbProxy.AuthProperty): any;
export declare function dataTfDbProxyAuthPropertyToHclTerraform(struct?: DataTfDbProxy.AuthProperty): any;
export declare namespace DataTfDbProxy {
    interface AuthProperty {
    }
    class AuthPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthProperty | undefined;
        set internalValue(value: AuthProperty | undefined);
        get authScheme(): string;
        get clientPasswordAuthType(): string;
        get description(): string;
        get iamAuth(): string;
        get secretArn(): string;
        get username(): string;
    }
    class AuthPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthPropertyOutputReference;
    }
}
