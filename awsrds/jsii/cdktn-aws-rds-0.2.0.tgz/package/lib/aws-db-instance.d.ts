import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfDbInstanceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#allocated_storage TfDbInstance#allocated_storage}
    */
    readonly allocatedStorage?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#allow_major_version_upgrade TfDbInstance#allow_major_version_upgrade}
    */
    readonly allowMajorVersionUpgrade?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#apply_immediately TfDbInstance#apply_immediately}
    */
    readonly applyImmediately?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#auto_minor_version_upgrade TfDbInstance#auto_minor_version_upgrade}
    */
    readonly autoMinorVersionUpgrade?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#availability_zone TfDbInstance#availability_zone}
    */
    readonly availabilityZone?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#backup_retention_period TfDbInstance#backup_retention_period}
    */
    readonly backupRetentionPeriod?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#backup_target TfDbInstance#backup_target}
    */
    readonly backupTarget?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#backup_window TfDbInstance#backup_window}
    */
    readonly backupWindow?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#ca_cert_identifier TfDbInstance#ca_cert_identifier}
    */
    readonly caCertIdentifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#character_set_name TfDbInstance#character_set_name}
    */
    readonly characterSetName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#copy_tags_to_snapshot TfDbInstance#copy_tags_to_snapshot}
    */
    readonly copyTagsToSnapshot?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#custom_iam_instance_profile TfDbInstance#custom_iam_instance_profile}
    */
    readonly customIamInstanceProfile?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#customer_owned_ip_enabled TfDbInstance#customer_owned_ip_enabled}
    */
    readonly customerOwnedIpEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#database_insights_mode TfDbInstance#database_insights_mode}
    */
    readonly databaseInsightsMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#db_name TfDbInstance#db_name}
    */
    readonly dbName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#db_subnet_group_name TfDbInstance#db_subnet_group_name}
    */
    readonly dbSubnetGroupName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#dedicated_log_volume TfDbInstance#dedicated_log_volume}
    */
    readonly dedicatedLogVolume?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#delete_automated_backups TfDbInstance#delete_automated_backups}
    */
    readonly deleteAutomatedBackups?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#deletion_protection TfDbInstance#deletion_protection}
    */
    readonly deletionProtection?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#domain TfDbInstance#domain}
    */
    readonly domain?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#domain_auth_secret_arn TfDbInstance#domain_auth_secret_arn}
    */
    readonly domainAuthSecretArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#domain_dns_ips TfDbInstance#domain_dns_ips}
    */
    readonly domainDnsIps?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#domain_fqdn TfDbInstance#domain_fqdn}
    */
    readonly domainFqdn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#domain_iam_role_name TfDbInstance#domain_iam_role_name}
    */
    readonly domainIamRoleName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#domain_ou TfDbInstance#domain_ou}
    */
    readonly domainOu?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#enabled_cloudwatch_logs_exports TfDbInstance#enabled_cloudwatch_logs_exports}
    */
    readonly enabledCloudwatchLogsExports?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#engine TfDbInstance#engine}
    */
    readonly engine?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#engine_lifecycle_support TfDbInstance#engine_lifecycle_support}
    */
    readonly engineLifecycleSupport?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#engine_version TfDbInstance#engine_version}
    */
    readonly engineVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#final_snapshot_identifier TfDbInstance#final_snapshot_identifier}
    */
    readonly finalSnapshotIdentifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#iam_database_authentication_enabled TfDbInstance#iam_database_authentication_enabled}
    */
    readonly iamDatabaseAuthenticationEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#id TfDbInstance#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#identifier TfDbInstance#identifier}
    */
    readonly identifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#identifier_prefix TfDbInstance#identifier_prefix}
    */
    readonly identifierPrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#instance_class TfDbInstance#instance_class}
    */
    readonly instanceClass: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#iops TfDbInstance#iops}
    */
    readonly iops?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#kms_key_id TfDbInstance#kms_key_id}
    */
    readonly kmsKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#license_model TfDbInstance#license_model}
    */
    readonly licenseModel?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#maintenance_window TfDbInstance#maintenance_window}
    */
    readonly maintenanceWindow?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#manage_master_user_password TfDbInstance#manage_master_user_password}
    */
    readonly manageMasterUserPassword?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#master_user_secret_kms_key_id TfDbInstance#master_user_secret_kms_key_id}
    */
    readonly masterUserSecretKmsKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#max_allocated_storage TfDbInstance#max_allocated_storage}
    */
    readonly maxAllocatedStorage?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#monitoring_interval TfDbInstance#monitoring_interval}
    */
    readonly monitoringInterval?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#monitoring_role_arn TfDbInstance#monitoring_role_arn}
    */
    readonly monitoringRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#multi_az TfDbInstance#multi_az}
    */
    readonly multiAz?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#nchar_character_set_name TfDbInstance#nchar_character_set_name}
    */
    readonly ncharCharacterSetName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#network_type TfDbInstance#network_type}
    */
    readonly networkType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#option_group_name TfDbInstance#option_group_name}
    */
    readonly optionGroupName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#parameter_group_name TfDbInstance#parameter_group_name}
    */
    readonly parameterGroupName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#password TfDbInstance#password}
    */
    readonly password?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#password_wo TfDbInstance#password_wo}
    */
    readonly passwordWo?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#password_wo_version TfDbInstance#password_wo_version}
    */
    readonly passwordWoVersion?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#performance_insights_enabled TfDbInstance#performance_insights_enabled}
    */
    readonly performanceInsightsEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#performance_insights_kms_key_id TfDbInstance#performance_insights_kms_key_id}
    */
    readonly performanceInsightsKmsKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#performance_insights_retention_period TfDbInstance#performance_insights_retention_period}
    */
    readonly performanceInsightsRetentionPeriod?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#port TfDbInstance#port}
    */
    readonly port?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#publicly_accessible TfDbInstance#publicly_accessible}
    */
    readonly publiclyAccessible?: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#region TfDbInstance#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#replica_mode TfDbInstance#replica_mode}
    */
    readonly replicaMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#replicate_source_db TfDbInstance#replicate_source_db}
    */
    readonly replicateSourceDb?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#skip_final_snapshot TfDbInstance#skip_final_snapshot}
    */
    readonly skipFinalSnapshot?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#snapshot_identifier TfDbInstance#snapshot_identifier}
    */
    readonly snapshotIdentifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#storage_encrypted TfDbInstance#storage_encrypted}
    */
    readonly storageEncrypted?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#storage_throughput TfDbInstance#storage_throughput}
    */
    readonly storageThroughput?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#storage_type TfDbInstance#storage_type}
    */
    readonly storageType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#tags TfDbInstance#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#tags_all TfDbInstance#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#timezone TfDbInstance#timezone}
    */
    readonly timezone?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#upgrade_storage_config TfDbInstance#upgrade_storage_config}
    */
    readonly upgradeStorageConfig?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#username TfDbInstance#username}
    */
    readonly username?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#vpc_security_group_ids TfDbInstance#vpc_security_group_ids}
    */
    readonly vpcSecurityGroupIds?: string[];
    /**
    * blue_green_update block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#blue_green_update TfDbInstance#blue_green_update}
    */
    readonly blueGreenUpdate?: TfDbInstance.BlueGreenUpdateProperty;
    /**
    * restore_to_point_in_time block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#restore_to_point_in_time TfDbInstance#restore_to_point_in_time}
    */
    readonly restoreToPointInTime?: TfDbInstance.RestoreToPointInTimeProperty;
    /**
    * s3_import block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#s3_import TfDbInstance#s3_import}
    */
    readonly s3Import?: TfDbInstance.S3ImportProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#timeouts TfDbInstance#timeouts}
    */
    readonly timeouts?: TfDbInstance.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance aws_db_instance}
*/
export declare class TfDbInstance extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_db_instance";
    /**
    * Generates CDKTN code for importing a TfDbInstance resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfDbInstance to import
    * @param importFromId The id of the existing TfDbInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfDbInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance aws_db_instance} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfDbInstanceConfig
    */
    constructor(scope: Construct, id: string, config: TfDbInstanceConfig);
    get address(): string;
    private _allocatedStorage?;
    get allocatedStorage(): number;
    set allocatedStorage(value: number);
    resetAllocatedStorage(): void;
    get allocatedStorageInput(): number | undefined;
    private _allowMajorVersionUpgrade?;
    get allowMajorVersionUpgrade(): boolean | cdktn.IResolvable;
    set allowMajorVersionUpgrade(value: boolean | cdktn.IResolvable);
    resetAllowMajorVersionUpgrade(): void;
    get allowMajorVersionUpgradeInput(): boolean | cdktn.IResolvable | undefined;
    private _applyImmediately?;
    get applyImmediately(): boolean | cdktn.IResolvable;
    set applyImmediately(value: boolean | cdktn.IResolvable);
    resetApplyImmediately(): void;
    get applyImmediatelyInput(): boolean | cdktn.IResolvable | undefined;
    get arn(): string;
    private _autoMinorVersionUpgrade?;
    get autoMinorVersionUpgrade(): boolean | cdktn.IResolvable;
    set autoMinorVersionUpgrade(value: boolean | cdktn.IResolvable);
    resetAutoMinorVersionUpgrade(): void;
    get autoMinorVersionUpgradeInput(): boolean | cdktn.IResolvable | undefined;
    private _availabilityZone?;
    get availabilityZone(): string;
    set availabilityZone(value: string);
    resetAvailabilityZone(): void;
    get availabilityZoneInput(): string | undefined;
    private _backupRetentionPeriod?;
    get backupRetentionPeriod(): number;
    set backupRetentionPeriod(value: number);
    resetBackupRetentionPeriod(): void;
    get backupRetentionPeriodInput(): number | undefined;
    private _backupTarget?;
    get backupTarget(): string;
    set backupTarget(value: string);
    resetBackupTarget(): void;
    get backupTargetInput(): string | undefined;
    private _backupWindow?;
    get backupWindow(): string;
    set backupWindow(value: string);
    resetBackupWindow(): void;
    get backupWindowInput(): string | undefined;
    private _caCertIdentifier?;
    get caCertIdentifier(): string;
    set caCertIdentifier(value: string);
    resetCaCertIdentifier(): void;
    get caCertIdentifierInput(): string | undefined;
    private _characterSetName?;
    get characterSetName(): string;
    set characterSetName(value: string);
    resetCharacterSetName(): void;
    get characterSetNameInput(): string | undefined;
    private _copyTagsToSnapshot?;
    get copyTagsToSnapshot(): boolean | cdktn.IResolvable;
    set copyTagsToSnapshot(value: boolean | cdktn.IResolvable);
    resetCopyTagsToSnapshot(): void;
    get copyTagsToSnapshotInput(): boolean | cdktn.IResolvable | undefined;
    private _customIamInstanceProfile?;
    get customIamInstanceProfile(): string;
    set customIamInstanceProfile(value: string);
    resetCustomIamInstanceProfile(): void;
    get customIamInstanceProfileInput(): string | undefined;
    private _customerOwnedIpEnabled?;
    get customerOwnedIpEnabled(): boolean | cdktn.IResolvable;
    set customerOwnedIpEnabled(value: boolean | cdktn.IResolvable);
    resetCustomerOwnedIpEnabled(): void;
    get customerOwnedIpEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _databaseInsightsMode?;
    get databaseInsightsMode(): string;
    set databaseInsightsMode(value: string);
    resetDatabaseInsightsMode(): void;
    get databaseInsightsModeInput(): string | undefined;
    private _dbName?;
    get dbName(): string;
    set dbName(value: string);
    resetDbName(): void;
    get dbNameInput(): string | undefined;
    private _dbSubnetGroupName?;
    get dbSubnetGroupName(): string;
    set dbSubnetGroupName(value: string);
    resetDbSubnetGroupName(): void;
    get dbSubnetGroupNameInput(): string | undefined;
    private _dedicatedLogVolume?;
    get dedicatedLogVolume(): boolean | cdktn.IResolvable;
    set dedicatedLogVolume(value: boolean | cdktn.IResolvable);
    resetDedicatedLogVolume(): void;
    get dedicatedLogVolumeInput(): boolean | cdktn.IResolvable | undefined;
    private _deleteAutomatedBackups?;
    get deleteAutomatedBackups(): boolean | cdktn.IResolvable;
    set deleteAutomatedBackups(value: boolean | cdktn.IResolvable);
    resetDeleteAutomatedBackups(): void;
    get deleteAutomatedBackupsInput(): boolean | cdktn.IResolvable | undefined;
    private _deletionProtection?;
    get deletionProtection(): boolean | cdktn.IResolvable;
    set deletionProtection(value: boolean | cdktn.IResolvable);
    resetDeletionProtection(): void;
    get deletionProtectionInput(): boolean | cdktn.IResolvable | undefined;
    private _domain?;
    get domain(): string;
    set domain(value: string);
    resetDomain(): void;
    get domainInput(): string | undefined;
    private _domainAuthSecretArn?;
    get domainAuthSecretArn(): string;
    set domainAuthSecretArn(value: string);
    resetDomainAuthSecretArn(): void;
    get domainAuthSecretArnInput(): string | undefined;
    private _domainDnsIps?;
    get domainDnsIps(): string[];
    set domainDnsIps(value: string[]);
    resetDomainDnsIps(): void;
    get domainDnsIpsInput(): string[] | undefined;
    private _domainFqdn?;
    get domainFqdn(): string;
    set domainFqdn(value: string);
    resetDomainFqdn(): void;
    get domainFqdnInput(): string | undefined;
    private _domainIamRoleName?;
    get domainIamRoleName(): string;
    set domainIamRoleName(value: string);
    resetDomainIamRoleName(): void;
    get domainIamRoleNameInput(): string | undefined;
    private _domainOu?;
    get domainOu(): string;
    set domainOu(value: string);
    resetDomainOu(): void;
    get domainOuInput(): string | undefined;
    private _enabledCloudwatchLogsExports?;
    get enabledCloudwatchLogsExports(): string[];
    set enabledCloudwatchLogsExports(value: string[]);
    resetEnabledCloudwatchLogsExports(): void;
    get enabledCloudwatchLogsExportsInput(): string[] | undefined;
    get endpoint(): string;
    private _engine?;
    get engine(): string;
    set engine(value: string);
    resetEngine(): void;
    get engineInput(): string | undefined;
    private _engineLifecycleSupport?;
    get engineLifecycleSupport(): string;
    set engineLifecycleSupport(value: string);
    resetEngineLifecycleSupport(): void;
    get engineLifecycleSupportInput(): string | undefined;
    private _engineVersion?;
    get engineVersion(): string;
    set engineVersion(value: string);
    resetEngineVersion(): void;
    get engineVersionInput(): string | undefined;
    get engineVersionActual(): string;
    private _finalSnapshotIdentifier?;
    get finalSnapshotIdentifier(): string;
    set finalSnapshotIdentifier(value: string);
    resetFinalSnapshotIdentifier(): void;
    get finalSnapshotIdentifierInput(): string | undefined;
    get hostedZoneId(): string;
    private _iamDatabaseAuthenticationEnabled?;
    get iamDatabaseAuthenticationEnabled(): boolean | cdktn.IResolvable;
    set iamDatabaseAuthenticationEnabled(value: boolean | cdktn.IResolvable);
    resetIamDatabaseAuthenticationEnabled(): void;
    get iamDatabaseAuthenticationEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _identifier?;
    get identifier(): string;
    set identifier(value: string);
    resetIdentifier(): void;
    get identifierInput(): string | undefined;
    private _identifierPrefix?;
    get identifierPrefix(): string;
    set identifierPrefix(value: string);
    resetIdentifierPrefix(): void;
    get identifierPrefixInput(): string | undefined;
    private _instanceClass?;
    get instanceClass(): string;
    set instanceClass(value: string);
    get instanceClassInput(): string | undefined;
    private _iops?;
    get iops(): number;
    set iops(value: number);
    resetIops(): void;
    get iopsInput(): number | undefined;
    private _kmsKeyId?;
    get kmsKeyId(): string;
    set kmsKeyId(value: string);
    resetKmsKeyId(): void;
    get kmsKeyIdInput(): string | undefined;
    get latestRestorableTime(): string;
    private _licenseModel?;
    get licenseModel(): string;
    set licenseModel(value: string);
    resetLicenseModel(): void;
    get licenseModelInput(): string | undefined;
    private _listenerEndpoint;
    get listenerEndpoint(): TfDbInstance.ListenerEndpointPropertyList;
    private _maintenanceWindow?;
    get maintenanceWindow(): string;
    set maintenanceWindow(value: string);
    resetMaintenanceWindow(): void;
    get maintenanceWindowInput(): string | undefined;
    private _manageMasterUserPassword?;
    get manageMasterUserPassword(): boolean | cdktn.IResolvable;
    set manageMasterUserPassword(value: boolean | cdktn.IResolvable);
    resetManageMasterUserPassword(): void;
    get manageMasterUserPasswordInput(): boolean | cdktn.IResolvable | undefined;
    private _masterUserSecret;
    get masterUserSecret(): TfDbInstance.MasterUserSecretPropertyList;
    private _masterUserSecretKmsKeyId?;
    get masterUserSecretKmsKeyId(): string;
    set masterUserSecretKmsKeyId(value: string);
    resetMasterUserSecretKmsKeyId(): void;
    get masterUserSecretKmsKeyIdInput(): string | undefined;
    private _maxAllocatedStorage?;
    get maxAllocatedStorage(): number;
    set maxAllocatedStorage(value: number);
    resetMaxAllocatedStorage(): void;
    get maxAllocatedStorageInput(): number | undefined;
    private _monitoringInterval?;
    get monitoringInterval(): number;
    set monitoringInterval(value: number);
    resetMonitoringInterval(): void;
    get monitoringIntervalInput(): number | undefined;
    private _monitoringRoleArn?;
    get monitoringRoleArn(): string;
    set monitoringRoleArn(value: string);
    resetMonitoringRoleArn(): void;
    get monitoringRoleArnInput(): string | undefined;
    private _multiAz?;
    get multiAz(): boolean | cdktn.IResolvable;
    set multiAz(value: boolean | cdktn.IResolvable);
    resetMultiAz(): void;
    get multiAzInput(): boolean | cdktn.IResolvable | undefined;
    private _ncharCharacterSetName?;
    get ncharCharacterSetName(): string;
    set ncharCharacterSetName(value: string);
    resetNcharCharacterSetName(): void;
    get ncharCharacterSetNameInput(): string | undefined;
    private _networkType?;
    get networkType(): string;
    set networkType(value: string);
    resetNetworkType(): void;
    get networkTypeInput(): string | undefined;
    private _optionGroupName?;
    get optionGroupName(): string;
    set optionGroupName(value: string);
    resetOptionGroupName(): void;
    get optionGroupNameInput(): string | undefined;
    private _parameterGroupName?;
    get parameterGroupName(): string;
    set parameterGroupName(value: string);
    resetParameterGroupName(): void;
    get parameterGroupNameInput(): string | undefined;
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _passwordWo?;
    /**
    * @deprecated Write-only: the provider never returns this value; reading it always yields null by protocol contract. The getter remains for compatibility and will be removed in a future prebuilt-provider major.
    */
    get passwordWo(): string;
    set passwordWo(value: string);
    resetPasswordWo(): void;
    get passwordWoInput(): string | undefined;
    private _passwordWoVersion?;
    get passwordWoVersion(): number;
    set passwordWoVersion(value: number);
    resetPasswordWoVersion(): void;
    get passwordWoVersionInput(): number | undefined;
    private _performanceInsightsEnabled?;
    get performanceInsightsEnabled(): boolean | cdktn.IResolvable;
    set performanceInsightsEnabled(value: boolean | cdktn.IResolvable);
    resetPerformanceInsightsEnabled(): void;
    get performanceInsightsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _performanceInsightsKmsKeyId?;
    get performanceInsightsKmsKeyId(): string;
    set performanceInsightsKmsKeyId(value: string);
    resetPerformanceInsightsKmsKeyId(): void;
    get performanceInsightsKmsKeyIdInput(): string | undefined;
    private _performanceInsightsRetentionPeriod?;
    get performanceInsightsRetentionPeriod(): number;
    set performanceInsightsRetentionPeriod(value: number);
    resetPerformanceInsightsRetentionPeriod(): void;
    get performanceInsightsRetentionPeriodInput(): number | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
    private _publiclyAccessible?;
    get publiclyAccessible(): boolean | cdktn.IResolvable;
    set publiclyAccessible(value: boolean | cdktn.IResolvable);
    resetPubliclyAccessible(): void;
    get publiclyAccessibleInput(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _replicaMode?;
    get replicaMode(): string;
    set replicaMode(value: string);
    resetReplicaMode(): void;
    get replicaModeInput(): string | undefined;
    get replicas(): string[];
    private _replicateSourceDb?;
    get replicateSourceDb(): string;
    set replicateSourceDb(value: string);
    resetReplicateSourceDb(): void;
    get replicateSourceDbInput(): string | undefined;
    get resourceId(): string;
    private _skipFinalSnapshot?;
    get skipFinalSnapshot(): boolean | cdktn.IResolvable;
    set skipFinalSnapshot(value: boolean | cdktn.IResolvable);
    resetSkipFinalSnapshot(): void;
    get skipFinalSnapshotInput(): boolean | cdktn.IResolvable | undefined;
    private _snapshotIdentifier?;
    get snapshotIdentifier(): string;
    set snapshotIdentifier(value: string);
    resetSnapshotIdentifier(): void;
    get snapshotIdentifierInput(): string | undefined;
    get status(): string;
    private _storageEncrypted?;
    get storageEncrypted(): boolean | cdktn.IResolvable;
    set storageEncrypted(value: boolean | cdktn.IResolvable);
    resetStorageEncrypted(): void;
    get storageEncryptedInput(): boolean | cdktn.IResolvable | undefined;
    private _storageThroughput?;
    get storageThroughput(): number;
    set storageThroughput(value: number);
    resetStorageThroughput(): void;
    get storageThroughputInput(): number | undefined;
    private _storageType?;
    get storageType(): string;
    set storageType(value: string);
    resetStorageType(): void;
    get storageTypeInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _timezone?;
    get timezone(): string;
    set timezone(value: string);
    resetTimezone(): void;
    get timezoneInput(): string | undefined;
    get upgradeRolloutOrder(): string;
    private _upgradeStorageConfig?;
    get upgradeStorageConfig(): boolean | cdktn.IResolvable;
    set upgradeStorageConfig(value: boolean | cdktn.IResolvable);
    resetUpgradeStorageConfig(): void;
    get upgradeStorageConfigInput(): boolean | cdktn.IResolvable | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    resetUsername(): void;
    get usernameInput(): string | undefined;
    private _vpcSecurityGroupIds?;
    get vpcSecurityGroupIds(): string[];
    set vpcSecurityGroupIds(value: string[]);
    resetVpcSecurityGroupIds(): void;
    get vpcSecurityGroupIdsInput(): string[] | undefined;
    private _blueGreenUpdate;
    get blueGreenUpdate(): TfDbInstance.BlueGreenUpdatePropertyOutputReference;
    putBlueGreenUpdate(value: TfDbInstance.BlueGreenUpdateProperty): void;
    resetBlueGreenUpdate(): void;
    get blueGreenUpdateInput(): TfDbInstance.BlueGreenUpdateProperty | undefined;
    private _restoreToPointInTime;
    get restoreToPointInTime(): TfDbInstance.RestoreToPointInTimePropertyOutputReference;
    putRestoreToPointInTime(value: TfDbInstance.RestoreToPointInTimeProperty): void;
    resetRestoreToPointInTime(): void;
    get restoreToPointInTimeInput(): TfDbInstance.RestoreToPointInTimeProperty | undefined;
    private _s3Import;
    get s3Import(): TfDbInstance.S3ImportPropertyOutputReference;
    putS3Import(value: TfDbInstance.S3ImportProperty): void;
    resetS3Import(): void;
    get s3ImportInput(): TfDbInstance.S3ImportProperty | undefined;
    private _timeouts;
    get timeouts(): TfDbInstance.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfDbInstance.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfDbInstance.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfDbInstanceListenerEndpointPropertyToTerraform(struct?: TfDbInstance.ListenerEndpointProperty): any;
export declare function tfDbInstanceListenerEndpointPropertyToHclTerraform(struct?: TfDbInstance.ListenerEndpointProperty): any;
export declare function tfDbInstanceMasterUserSecretPropertyToTerraform(struct?: TfDbInstance.MasterUserSecretProperty): any;
export declare function tfDbInstanceMasterUserSecretPropertyToHclTerraform(struct?: TfDbInstance.MasterUserSecretProperty): any;
export declare function tfDbInstanceBlueGreenUpdatePropertyToTerraform(struct?: TfDbInstance.BlueGreenUpdatePropertyOutputReference | TfDbInstance.BlueGreenUpdateProperty): any;
export declare function tfDbInstanceBlueGreenUpdatePropertyToHclTerraform(struct?: TfDbInstance.BlueGreenUpdatePropertyOutputReference | TfDbInstance.BlueGreenUpdateProperty): any;
export declare function tfDbInstanceRestoreToPointInTimePropertyToTerraform(struct?: TfDbInstance.RestoreToPointInTimePropertyOutputReference | TfDbInstance.RestoreToPointInTimeProperty): any;
export declare function tfDbInstanceRestoreToPointInTimePropertyToHclTerraform(struct?: TfDbInstance.RestoreToPointInTimePropertyOutputReference | TfDbInstance.RestoreToPointInTimeProperty): any;
export declare function tfDbInstanceS3ImportPropertyToTerraform(struct?: TfDbInstance.S3ImportPropertyOutputReference | TfDbInstance.S3ImportProperty): any;
export declare function tfDbInstanceS3ImportPropertyToHclTerraform(struct?: TfDbInstance.S3ImportPropertyOutputReference | TfDbInstance.S3ImportProperty): any;
export declare function tfDbInstanceTimeoutsPropertyToTerraform(struct?: TfDbInstance.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfDbInstanceTimeoutsPropertyToHclTerraform(struct?: TfDbInstance.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfDbInstance {
    interface ListenerEndpointProperty {
    }
    class ListenerEndpointPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ListenerEndpointProperty | undefined;
        set internalValue(value: ListenerEndpointProperty | undefined);
        get address(): string;
        get hostedZoneId(): string;
        get port(): number;
    }
    class ListenerEndpointPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ListenerEndpointPropertyOutputReference;
    }
    interface MasterUserSecretProperty {
    }
    class MasterUserSecretPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MasterUserSecretProperty | undefined;
        set internalValue(value: MasterUserSecretProperty | undefined);
        get kmsKeyId(): string;
        get secretArn(): string;
        get secretStatus(): string;
    }
    class MasterUserSecretPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MasterUserSecretPropertyOutputReference;
    }
    interface BlueGreenUpdateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#enabled TfDbInstance#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
    }
    class BlueGreenUpdatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BlueGreenUpdateProperty | undefined;
        set internalValue(value: BlueGreenUpdateProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface RestoreToPointInTimeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#restore_time TfDbInstance#restore_time}
        */
        readonly restoreTime?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#source_db_instance_automated_backups_arn TfDbInstance#source_db_instance_automated_backups_arn}
        */
        readonly sourceDbInstanceAutomatedBackupsArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#source_db_instance_identifier TfDbInstance#source_db_instance_identifier}
        */
        readonly sourceDbInstanceIdentifier?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#source_dbi_resource_id TfDbInstance#source_dbi_resource_id}
        */
        readonly sourceDbiResourceId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#use_latest_restorable_time TfDbInstance#use_latest_restorable_time}
        */
        readonly useLatestRestorableTime?: boolean | cdktn.IResolvable;
    }
    class RestoreToPointInTimePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RestoreToPointInTimeProperty | undefined;
        set internalValue(value: RestoreToPointInTimeProperty | undefined);
        private _restoreTime?;
        get restoreTime(): string;
        set restoreTime(value: string);
        resetRestoreTime(): void;
        get restoreTimeInput(): string | undefined;
        private _sourceDbInstanceAutomatedBackupsArn?;
        get sourceDbInstanceAutomatedBackupsArn(): string;
        set sourceDbInstanceAutomatedBackupsArn(value: string);
        resetSourceDbInstanceAutomatedBackupsArn(): void;
        get sourceDbInstanceAutomatedBackupsArnInput(): string | undefined;
        private _sourceDbInstanceIdentifier?;
        get sourceDbInstanceIdentifier(): string;
        set sourceDbInstanceIdentifier(value: string);
        resetSourceDbInstanceIdentifier(): void;
        get sourceDbInstanceIdentifierInput(): string | undefined;
        private _sourceDbiResourceId?;
        get sourceDbiResourceId(): string;
        set sourceDbiResourceId(value: string);
        resetSourceDbiResourceId(): void;
        get sourceDbiResourceIdInput(): string | undefined;
        private _useLatestRestorableTime?;
        get useLatestRestorableTime(): boolean | cdktn.IResolvable;
        set useLatestRestorableTime(value: boolean | cdktn.IResolvable);
        resetUseLatestRestorableTime(): void;
        get useLatestRestorableTimeInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface S3ImportProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#bucket_name TfDbInstance#bucket_name}
        */
        readonly bucketName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#bucket_prefix TfDbInstance#bucket_prefix}
        */
        readonly bucketPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#ingestion_role TfDbInstance#ingestion_role}
        */
        readonly ingestionRole: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#source_engine TfDbInstance#source_engine}
        */
        readonly sourceEngine: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#source_engine_version TfDbInstance#source_engine_version}
        */
        readonly sourceEngineVersion: string;
    }
    class S3ImportPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3ImportProperty | undefined;
        set internalValue(value: S3ImportProperty | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        get bucketNameInput(): string | undefined;
        private _bucketPrefix?;
        get bucketPrefix(): string;
        set bucketPrefix(value: string);
        resetBucketPrefix(): void;
        get bucketPrefixInput(): string | undefined;
        private _ingestionRole?;
        get ingestionRole(): string;
        set ingestionRole(value: string);
        get ingestionRoleInput(): string | undefined;
        private _sourceEngine?;
        get sourceEngine(): string;
        set sourceEngine(value: string);
        get sourceEngineInput(): string | undefined;
        private _sourceEngineVersion?;
        get sourceEngineVersion(): string;
        set sourceEngineVersion(value: string);
        get sourceEngineVersionInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#create TfDbInstance#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#delete TfDbInstance#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance#update TfDbInstance#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
