import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfClusterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#allocated_storage TfCluster#allocated_storage}
    */
    readonly allocatedStorage?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#allow_major_version_upgrade TfCluster#allow_major_version_upgrade}
    */
    readonly allowMajorVersionUpgrade?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#apply_immediately TfCluster#apply_immediately}
    */
    readonly applyImmediately?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#auto_minor_version_upgrade TfCluster#auto_minor_version_upgrade}
    */
    readonly autoMinorVersionUpgrade?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#availability_zones TfCluster#availability_zones}
    */
    readonly availabilityZones?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#backtrack_window TfCluster#backtrack_window}
    */
    readonly backtrackWindow?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#backup_retention_period TfCluster#backup_retention_period}
    */
    readonly backupRetentionPeriod?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#ca_certificate_identifier TfCluster#ca_certificate_identifier}
    */
    readonly caCertificateIdentifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#cluster_identifier TfCluster#cluster_identifier}
    */
    readonly clusterIdentifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#cluster_identifier_prefix TfCluster#cluster_identifier_prefix}
    */
    readonly clusterIdentifierPrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#cluster_members TfCluster#cluster_members}
    */
    readonly clusterMembers?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#cluster_scalability_type TfCluster#cluster_scalability_type}
    */
    readonly clusterScalabilityType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#copy_tags_to_snapshot TfCluster#copy_tags_to_snapshot}
    */
    readonly copyTagsToSnapshot?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#database_insights_mode TfCluster#database_insights_mode}
    */
    readonly databaseInsightsMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#database_name TfCluster#database_name}
    */
    readonly databaseName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#db_cluster_instance_class TfCluster#db_cluster_instance_class}
    */
    readonly dbClusterInstanceClass?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#db_cluster_parameter_group_name TfCluster#db_cluster_parameter_group_name}
    */
    readonly dbClusterParameterGroupName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#db_instance_parameter_group_name TfCluster#db_instance_parameter_group_name}
    */
    readonly dbInstanceParameterGroupName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#db_subnet_group_name TfCluster#db_subnet_group_name}
    */
    readonly dbSubnetGroupName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#db_system_id TfCluster#db_system_id}
    */
    readonly dbSystemId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#delete_automated_backups TfCluster#delete_automated_backups}
    */
    readonly deleteAutomatedBackups?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#deletion_protection TfCluster#deletion_protection}
    */
    readonly deletionProtection?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#domain TfCluster#domain}
    */
    readonly domain?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#domain_iam_role_name TfCluster#domain_iam_role_name}
    */
    readonly domainIamRoleName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#enable_global_write_forwarding TfCluster#enable_global_write_forwarding}
    */
    readonly enableGlobalWriteForwarding?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#enable_http_endpoint TfCluster#enable_http_endpoint}
    */
    readonly enableHttpEndpoint?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#enable_local_write_forwarding TfCluster#enable_local_write_forwarding}
    */
    readonly enableLocalWriteForwarding?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#enabled_cloudwatch_logs_exports TfCluster#enabled_cloudwatch_logs_exports}
    */
    readonly enabledCloudwatchLogsExports?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#engine TfCluster#engine}
    */
    readonly engine: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#engine_lifecycle_support TfCluster#engine_lifecycle_support}
    */
    readonly engineLifecycleSupport?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#engine_mode TfCluster#engine_mode}
    */
    readonly engineMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#engine_version TfCluster#engine_version}
    */
    readonly engineVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#final_snapshot_identifier TfCluster#final_snapshot_identifier}
    */
    readonly finalSnapshotIdentifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#global_cluster_identifier TfCluster#global_cluster_identifier}
    */
    readonly globalClusterIdentifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#iam_database_authentication_enabled TfCluster#iam_database_authentication_enabled}
    */
    readonly iamDatabaseAuthenticationEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#iam_roles TfCluster#iam_roles}
    */
    readonly iamRoles?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#id TfCluster#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#iops TfCluster#iops}
    */
    readonly iops?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#kms_key_id TfCluster#kms_key_id}
    */
    readonly kmsKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#manage_master_user_password TfCluster#manage_master_user_password}
    */
    readonly manageMasterUserPassword?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#master_password TfCluster#master_password}
    */
    readonly masterPassword?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#master_password_wo TfCluster#master_password_wo}
    */
    readonly masterPasswordWo?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#master_password_wo_version TfCluster#master_password_wo_version}
    */
    readonly masterPasswordWoVersion?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#master_user_secret_kms_key_id TfCluster#master_user_secret_kms_key_id}
    */
    readonly masterUserSecretKmsKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#master_username TfCluster#master_username}
    */
    readonly masterUsername?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#monitoring_interval TfCluster#monitoring_interval}
    */
    readonly monitoringInterval?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#monitoring_role_arn TfCluster#monitoring_role_arn}
    */
    readonly monitoringRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#network_type TfCluster#network_type}
    */
    readonly networkType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#performance_insights_enabled TfCluster#performance_insights_enabled}
    */
    readonly performanceInsightsEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#performance_insights_kms_key_id TfCluster#performance_insights_kms_key_id}
    */
    readonly performanceInsightsKmsKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#performance_insights_retention_period TfCluster#performance_insights_retention_period}
    */
    readonly performanceInsightsRetentionPeriod?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#port TfCluster#port}
    */
    readonly port?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#preferred_backup_window TfCluster#preferred_backup_window}
    */
    readonly preferredBackupWindow?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#preferred_maintenance_window TfCluster#preferred_maintenance_window}
    */
    readonly preferredMaintenanceWindow?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#region TfCluster#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#replication_source_identifier TfCluster#replication_source_identifier}
    */
    readonly replicationSourceIdentifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#skip_final_snapshot TfCluster#skip_final_snapshot}
    */
    readonly skipFinalSnapshot?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#snapshot_identifier TfCluster#snapshot_identifier}
    */
    readonly snapshotIdentifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#source_region TfCluster#source_region}
    */
    readonly sourceRegion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#storage_encrypted TfCluster#storage_encrypted}
    */
    readonly storageEncrypted?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#storage_type TfCluster#storage_type}
    */
    readonly storageType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#tags TfCluster#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#tags_all TfCluster#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#vpc_security_group_ids TfCluster#vpc_security_group_ids}
    */
    readonly vpcSecurityGroupIds?: string[];
    /**
    * restore_to_point_in_time block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#restore_to_point_in_time TfCluster#restore_to_point_in_time}
    */
    readonly restoreToPointInTime?: TfCluster.RestoreToPointInTimeProperty;
    /**
    * s3_import block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#s3_import TfCluster#s3_import}
    */
    readonly s3Import?: TfCluster.S3ImportProperty;
    /**
    * scaling_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#scaling_configuration TfCluster#scaling_configuration}
    */
    readonly scalingConfiguration?: TfCluster.ScalingConfigurationProperty;
    /**
    * serverlessv2_scaling_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#serverlessv2_scaling_configuration TfCluster#serverlessv2_scaling_configuration}
    */
    readonly serverlessv2ScalingConfiguration?: TfCluster.Serverlessv2ScalingConfigurationProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#timeouts TfCluster#timeouts}
    */
    readonly timeouts?: TfCluster.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster aws_rds_cluster}
*/
export declare class TfCluster extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_rds_cluster";
    /**
    * Generates CDKTN code for importing a TfCluster resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfCluster to import
    * @param importFromId The id of the existing TfCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster aws_rds_cluster} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfClusterConfig
    */
    constructor(scope: Construct, id: string, config: TfClusterConfig);
    private _allocatedStorage?;
    get allocatedStorage(): number;
    set allocatedStorage(value: number);
    resetAllocatedStorage(): void;
    get allocatedStorageInput(): number | undefined;
    private _allowMajorVersionUpgrade?;
    get allowMajorVersionUpgrade(): boolean | cdktn.IResolvable;
    set allowMajorVersionUpgrade(value: boolean | cdktn.IResolvable);
    resetAllowMajorVersionUpgrade(): void;
    get allowMajorVersionUpgradeInput(): boolean | cdktn.IResolvable | undefined;
    private _applyImmediately?;
    get applyImmediately(): boolean | cdktn.IResolvable;
    set applyImmediately(value: boolean | cdktn.IResolvable);
    resetApplyImmediately(): void;
    get applyImmediatelyInput(): boolean | cdktn.IResolvable | undefined;
    get arn(): string;
    private _autoMinorVersionUpgrade?;
    get autoMinorVersionUpgrade(): boolean | cdktn.IResolvable;
    set autoMinorVersionUpgrade(value: boolean | cdktn.IResolvable);
    resetAutoMinorVersionUpgrade(): void;
    get autoMinorVersionUpgradeInput(): boolean | cdktn.IResolvable | undefined;
    private _availabilityZones?;
    get availabilityZones(): string[];
    set availabilityZones(value: string[]);
    resetAvailabilityZones(): void;
    get availabilityZonesInput(): string[] | undefined;
    private _backtrackWindow?;
    get backtrackWindow(): number;
    set backtrackWindow(value: number);
    resetBacktrackWindow(): void;
    get backtrackWindowInput(): number | undefined;
    private _backupRetentionPeriod?;
    get backupRetentionPeriod(): number;
    set backupRetentionPeriod(value: number);
    resetBackupRetentionPeriod(): void;
    get backupRetentionPeriodInput(): number | undefined;
    private _caCertificateIdentifier?;
    get caCertificateIdentifier(): string;
    set caCertificateIdentifier(value: string);
    resetCaCertificateIdentifier(): void;
    get caCertificateIdentifierInput(): string | undefined;
    get caCertificateValidTill(): string;
    private _clusterIdentifier?;
    get clusterIdentifier(): string;
    set clusterIdentifier(value: string);
    resetClusterIdentifier(): void;
    get clusterIdentifierInput(): string | undefined;
    private _clusterIdentifierPrefix?;
    get clusterIdentifierPrefix(): string;
    set clusterIdentifierPrefix(value: string);
    resetClusterIdentifierPrefix(): void;
    get clusterIdentifierPrefixInput(): string | undefined;
    private _clusterMembers?;
    get clusterMembers(): string[];
    set clusterMembers(value: string[]);
    resetClusterMembers(): void;
    get clusterMembersInput(): string[] | undefined;
    get clusterResourceId(): string;
    private _clusterScalabilityType?;
    get clusterScalabilityType(): string;
    set clusterScalabilityType(value: string);
    resetClusterScalabilityType(): void;
    get clusterScalabilityTypeInput(): string | undefined;
    private _copyTagsToSnapshot?;
    get copyTagsToSnapshot(): boolean | cdktn.IResolvable;
    set copyTagsToSnapshot(value: boolean | cdktn.IResolvable);
    resetCopyTagsToSnapshot(): void;
    get copyTagsToSnapshotInput(): boolean | cdktn.IResolvable | undefined;
    private _databaseInsightsMode?;
    get databaseInsightsMode(): string;
    set databaseInsightsMode(value: string);
    resetDatabaseInsightsMode(): void;
    get databaseInsightsModeInput(): string | undefined;
    private _databaseName?;
    get databaseName(): string;
    set databaseName(value: string);
    resetDatabaseName(): void;
    get databaseNameInput(): string | undefined;
    private _dbClusterInstanceClass?;
    get dbClusterInstanceClass(): string;
    set dbClusterInstanceClass(value: string);
    resetDbClusterInstanceClass(): void;
    get dbClusterInstanceClassInput(): string | undefined;
    private _dbClusterParameterGroupName?;
    get dbClusterParameterGroupName(): string;
    set dbClusterParameterGroupName(value: string);
    resetDbClusterParameterGroupName(): void;
    get dbClusterParameterGroupNameInput(): string | undefined;
    private _dbInstanceParameterGroupName?;
    get dbInstanceParameterGroupName(): string;
    set dbInstanceParameterGroupName(value: string);
    resetDbInstanceParameterGroupName(): void;
    get dbInstanceParameterGroupNameInput(): string | undefined;
    private _dbSubnetGroupName?;
    get dbSubnetGroupName(): string;
    set dbSubnetGroupName(value: string);
    resetDbSubnetGroupName(): void;
    get dbSubnetGroupNameInput(): string | undefined;
    private _dbSystemId?;
    get dbSystemId(): string;
    set dbSystemId(value: string);
    resetDbSystemId(): void;
    get dbSystemIdInput(): string | undefined;
    private _deleteAutomatedBackups?;
    get deleteAutomatedBackups(): boolean | cdktn.IResolvable;
    set deleteAutomatedBackups(value: boolean | cdktn.IResolvable);
    resetDeleteAutomatedBackups(): void;
    get deleteAutomatedBackupsInput(): boolean | cdktn.IResolvable | undefined;
    private _deletionProtection?;
    get deletionProtection(): boolean | cdktn.IResolvable;
    set deletionProtection(value: boolean | cdktn.IResolvable);
    resetDeletionProtection(): void;
    get deletionProtectionInput(): boolean | cdktn.IResolvable | undefined;
    private _domain?;
    get domain(): string;
    set domain(value: string);
    resetDomain(): void;
    get domainInput(): string | undefined;
    private _domainIamRoleName?;
    get domainIamRoleName(): string;
    set domainIamRoleName(value: string);
    resetDomainIamRoleName(): void;
    get domainIamRoleNameInput(): string | undefined;
    private _enableGlobalWriteForwarding?;
    get enableGlobalWriteForwarding(): boolean | cdktn.IResolvable;
    set enableGlobalWriteForwarding(value: boolean | cdktn.IResolvable);
    resetEnableGlobalWriteForwarding(): void;
    get enableGlobalWriteForwardingInput(): boolean | cdktn.IResolvable | undefined;
    private _enableHttpEndpoint?;
    get enableHttpEndpoint(): boolean | cdktn.IResolvable;
    set enableHttpEndpoint(value: boolean | cdktn.IResolvable);
    resetEnableHttpEndpoint(): void;
    get enableHttpEndpointInput(): boolean | cdktn.IResolvable | undefined;
    private _enableLocalWriteForwarding?;
    get enableLocalWriteForwarding(): boolean | cdktn.IResolvable;
    set enableLocalWriteForwarding(value: boolean | cdktn.IResolvable);
    resetEnableLocalWriteForwarding(): void;
    get enableLocalWriteForwardingInput(): boolean | cdktn.IResolvable | undefined;
    private _enabledCloudwatchLogsExports?;
    get enabledCloudwatchLogsExports(): string[];
    set enabledCloudwatchLogsExports(value: string[]);
    resetEnabledCloudwatchLogsExports(): void;
    get enabledCloudwatchLogsExportsInput(): string[] | undefined;
    get endpoint(): string;
    private _engine?;
    get engine(): string;
    set engine(value: string);
    get engineInput(): string | undefined;
    private _engineLifecycleSupport?;
    get engineLifecycleSupport(): string;
    set engineLifecycleSupport(value: string);
    resetEngineLifecycleSupport(): void;
    get engineLifecycleSupportInput(): string | undefined;
    private _engineMode?;
    get engineMode(): string;
    set engineMode(value: string);
    resetEngineMode(): void;
    get engineModeInput(): string | undefined;
    private _engineVersion?;
    get engineVersion(): string;
    set engineVersion(value: string);
    resetEngineVersion(): void;
    get engineVersionInput(): string | undefined;
    get engineVersionActual(): string;
    private _finalSnapshotIdentifier?;
    get finalSnapshotIdentifier(): string;
    set finalSnapshotIdentifier(value: string);
    resetFinalSnapshotIdentifier(): void;
    get finalSnapshotIdentifierInput(): string | undefined;
    private _globalClusterIdentifier?;
    get globalClusterIdentifier(): string;
    set globalClusterIdentifier(value: string);
    resetGlobalClusterIdentifier(): void;
    get globalClusterIdentifierInput(): string | undefined;
    get hostedZoneId(): string;
    private _iamDatabaseAuthenticationEnabled?;
    get iamDatabaseAuthenticationEnabled(): boolean | cdktn.IResolvable;
    set iamDatabaseAuthenticationEnabled(value: boolean | cdktn.IResolvable);
    resetIamDatabaseAuthenticationEnabled(): void;
    get iamDatabaseAuthenticationEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _iamRoles?;
    get iamRoles(): string[];
    set iamRoles(value: string[]);
    resetIamRoles(): void;
    get iamRolesInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _iops?;
    get iops(): number;
    set iops(value: number);
    resetIops(): void;
    get iopsInput(): number | undefined;
    private _kmsKeyId?;
    get kmsKeyId(): string;
    set kmsKeyId(value: string);
    resetKmsKeyId(): void;
    get kmsKeyIdInput(): string | undefined;
    private _manageMasterUserPassword?;
    get manageMasterUserPassword(): boolean | cdktn.IResolvable;
    set manageMasterUserPassword(value: boolean | cdktn.IResolvable);
    resetManageMasterUserPassword(): void;
    get manageMasterUserPasswordInput(): boolean | cdktn.IResolvable | undefined;
    private _masterPassword?;
    get masterPassword(): string;
    set masterPassword(value: string);
    resetMasterPassword(): void;
    get masterPasswordInput(): string | undefined;
    private _masterPasswordWo?;
    /**
    * @deprecated Write-only: the provider never returns this value; reading it always yields null by protocol contract. The getter remains for compatibility and will be removed in a future prebuilt-provider major.
    */
    get masterPasswordWo(): string;
    set masterPasswordWo(value: string);
    resetMasterPasswordWo(): void;
    get masterPasswordWoInput(): string | undefined;
    private _masterPasswordWoVersion?;
    get masterPasswordWoVersion(): number;
    set masterPasswordWoVersion(value: number);
    resetMasterPasswordWoVersion(): void;
    get masterPasswordWoVersionInput(): number | undefined;
    private _masterUserSecret;
    get masterUserSecret(): TfCluster.MasterUserSecretPropertyList;
    private _masterUserSecretKmsKeyId?;
    get masterUserSecretKmsKeyId(): string;
    set masterUserSecretKmsKeyId(value: string);
    resetMasterUserSecretKmsKeyId(): void;
    get masterUserSecretKmsKeyIdInput(): string | undefined;
    private _masterUsername?;
    get masterUsername(): string;
    set masterUsername(value: string);
    resetMasterUsername(): void;
    get masterUsernameInput(): string | undefined;
    private _monitoringInterval?;
    get monitoringInterval(): number;
    set monitoringInterval(value: number);
    resetMonitoringInterval(): void;
    get monitoringIntervalInput(): number | undefined;
    private _monitoringRoleArn?;
    get monitoringRoleArn(): string;
    set monitoringRoleArn(value: string);
    resetMonitoringRoleArn(): void;
    get monitoringRoleArnInput(): string | undefined;
    private _networkType?;
    get networkType(): string;
    set networkType(value: string);
    resetNetworkType(): void;
    get networkTypeInput(): string | undefined;
    private _performanceInsightsEnabled?;
    get performanceInsightsEnabled(): boolean | cdktn.IResolvable;
    set performanceInsightsEnabled(value: boolean | cdktn.IResolvable);
    resetPerformanceInsightsEnabled(): void;
    get performanceInsightsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _performanceInsightsKmsKeyId?;
    get performanceInsightsKmsKeyId(): string;
    set performanceInsightsKmsKeyId(value: string);
    resetPerformanceInsightsKmsKeyId(): void;
    get performanceInsightsKmsKeyIdInput(): string | undefined;
    private _performanceInsightsRetentionPeriod?;
    get performanceInsightsRetentionPeriod(): number;
    set performanceInsightsRetentionPeriod(value: number);
    resetPerformanceInsightsRetentionPeriod(): void;
    get performanceInsightsRetentionPeriodInput(): number | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
    private _preferredBackupWindow?;
    get preferredBackupWindow(): string;
    set preferredBackupWindow(value: string);
    resetPreferredBackupWindow(): void;
    get preferredBackupWindowInput(): string | undefined;
    private _preferredMaintenanceWindow?;
    get preferredMaintenanceWindow(): string;
    set preferredMaintenanceWindow(value: string);
    resetPreferredMaintenanceWindow(): void;
    get preferredMaintenanceWindowInput(): string | undefined;
    get readerEndpoint(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _replicationSourceIdentifier?;
    get replicationSourceIdentifier(): string;
    set replicationSourceIdentifier(value: string);
    resetReplicationSourceIdentifier(): void;
    get replicationSourceIdentifierInput(): string | undefined;
    private _skipFinalSnapshot?;
    get skipFinalSnapshot(): boolean | cdktn.IResolvable;
    set skipFinalSnapshot(value: boolean | cdktn.IResolvable);
    resetSkipFinalSnapshot(): void;
    get skipFinalSnapshotInput(): boolean | cdktn.IResolvable | undefined;
    private _snapshotIdentifier?;
    get snapshotIdentifier(): string;
    set snapshotIdentifier(value: string);
    resetSnapshotIdentifier(): void;
    get snapshotIdentifierInput(): string | undefined;
    private _sourceRegion?;
    get sourceRegion(): string;
    set sourceRegion(value: string);
    resetSourceRegion(): void;
    get sourceRegionInput(): string | undefined;
    private _storageEncrypted?;
    get storageEncrypted(): boolean | cdktn.IResolvable;
    set storageEncrypted(value: boolean | cdktn.IResolvable);
    resetStorageEncrypted(): void;
    get storageEncryptedInput(): boolean | cdktn.IResolvable | undefined;
    private _storageType?;
    get storageType(): string;
    set storageType(value: string);
    resetStorageType(): void;
    get storageTypeInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get upgradeRolloutOrder(): string;
    private _vpcSecurityGroupIds?;
    get vpcSecurityGroupIds(): string[];
    set vpcSecurityGroupIds(value: string[]);
    resetVpcSecurityGroupIds(): void;
    get vpcSecurityGroupIdsInput(): string[] | undefined;
    private _restoreToPointInTime;
    get restoreToPointInTime(): TfCluster.RestoreToPointInTimePropertyOutputReference;
    putRestoreToPointInTime(value: TfCluster.RestoreToPointInTimeProperty): void;
    resetRestoreToPointInTime(): void;
    get restoreToPointInTimeInput(): TfCluster.RestoreToPointInTimeProperty | undefined;
    private _s3Import;
    get s3Import(): TfCluster.S3ImportPropertyOutputReference;
    putS3Import(value: TfCluster.S3ImportProperty): void;
    resetS3Import(): void;
    get s3ImportInput(): TfCluster.S3ImportProperty | undefined;
    private _scalingConfiguration;
    get scalingConfiguration(): TfCluster.ScalingConfigurationPropertyOutputReference;
    putScalingConfiguration(value: TfCluster.ScalingConfigurationProperty): void;
    resetScalingConfiguration(): void;
    get scalingConfigurationInput(): TfCluster.ScalingConfigurationProperty | undefined;
    private _serverlessv2ScalingConfiguration;
    get serverlessv2ScalingConfiguration(): TfCluster.Serverlessv2ScalingConfigurationPropertyOutputReference;
    putServerlessv2ScalingConfiguration(value: TfCluster.Serverlessv2ScalingConfigurationProperty): void;
    resetServerlessv2ScalingConfiguration(): void;
    get serverlessv2ScalingConfigurationInput(): TfCluster.Serverlessv2ScalingConfigurationProperty | undefined;
    private _timeouts;
    get timeouts(): TfCluster.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfCluster.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfCluster.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfClusterMasterUserSecretPropertyToTerraform(struct?: TfCluster.MasterUserSecretProperty): any;
export declare function tfClusterMasterUserSecretPropertyToHclTerraform(struct?: TfCluster.MasterUserSecretProperty): any;
export declare function tfClusterRestoreToPointInTimePropertyToTerraform(struct?: TfCluster.RestoreToPointInTimePropertyOutputReference | TfCluster.RestoreToPointInTimeProperty): any;
export declare function tfClusterRestoreToPointInTimePropertyToHclTerraform(struct?: TfCluster.RestoreToPointInTimePropertyOutputReference | TfCluster.RestoreToPointInTimeProperty): any;
export declare function tfClusterS3ImportPropertyToTerraform(struct?: TfCluster.S3ImportPropertyOutputReference | TfCluster.S3ImportProperty): any;
export declare function tfClusterS3ImportPropertyToHclTerraform(struct?: TfCluster.S3ImportPropertyOutputReference | TfCluster.S3ImportProperty): any;
export declare function tfClusterScalingConfigurationPropertyToTerraform(struct?: TfCluster.ScalingConfigurationPropertyOutputReference | TfCluster.ScalingConfigurationProperty): any;
export declare function tfClusterScalingConfigurationPropertyToHclTerraform(struct?: TfCluster.ScalingConfigurationPropertyOutputReference | TfCluster.ScalingConfigurationProperty): any;
export declare function tfClusterServerlessv2ScalingConfigurationPropertyToTerraform(struct?: TfCluster.Serverlessv2ScalingConfigurationPropertyOutputReference | TfCluster.Serverlessv2ScalingConfigurationProperty): any;
export declare function tfClusterServerlessv2ScalingConfigurationPropertyToHclTerraform(struct?: TfCluster.Serverlessv2ScalingConfigurationPropertyOutputReference | TfCluster.Serverlessv2ScalingConfigurationProperty): any;
export declare function tfClusterTimeoutsPropertyToTerraform(struct?: TfCluster.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfClusterTimeoutsPropertyToHclTerraform(struct?: TfCluster.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfCluster {
    interface MasterUserSecretProperty {
    }
    class MasterUserSecretPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MasterUserSecretProperty | undefined;
        set internalValue(value: MasterUserSecretProperty | undefined);
        get kmsKeyId(): string;
        get secretArn(): string;
        get secretStatus(): string;
    }
    class MasterUserSecretPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MasterUserSecretPropertyOutputReference;
    }
    interface RestoreToPointInTimeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#restore_to_time TfCluster#restore_to_time}
        */
        readonly restoreToTime?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#restore_type TfCluster#restore_type}
        */
        readonly restoreType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#source_cluster_identifier TfCluster#source_cluster_identifier}
        */
        readonly sourceClusterIdentifier?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#source_cluster_resource_id TfCluster#source_cluster_resource_id}
        */
        readonly sourceClusterResourceId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#use_latest_restorable_time TfCluster#use_latest_restorable_time}
        */
        readonly useLatestRestorableTime?: boolean | cdktn.IResolvable;
    }
    class RestoreToPointInTimePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RestoreToPointInTimeProperty | undefined;
        set internalValue(value: RestoreToPointInTimeProperty | undefined);
        private _restoreToTime?;
        get restoreToTime(): string;
        set restoreToTime(value: string);
        resetRestoreToTime(): void;
        get restoreToTimeInput(): string | undefined;
        private _restoreType?;
        get restoreType(): string;
        set restoreType(value: string);
        resetRestoreType(): void;
        get restoreTypeInput(): string | undefined;
        private _sourceClusterIdentifier?;
        get sourceClusterIdentifier(): string;
        set sourceClusterIdentifier(value: string);
        resetSourceClusterIdentifier(): void;
        get sourceClusterIdentifierInput(): string | undefined;
        private _sourceClusterResourceId?;
        get sourceClusterResourceId(): string;
        set sourceClusterResourceId(value: string);
        resetSourceClusterResourceId(): void;
        get sourceClusterResourceIdInput(): string | undefined;
        private _useLatestRestorableTime?;
        get useLatestRestorableTime(): boolean | cdktn.IResolvable;
        set useLatestRestorableTime(value: boolean | cdktn.IResolvable);
        resetUseLatestRestorableTime(): void;
        get useLatestRestorableTimeInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface S3ImportProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#bucket_name TfCluster#bucket_name}
        */
        readonly bucketName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#bucket_prefix TfCluster#bucket_prefix}
        */
        readonly bucketPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#ingestion_role TfCluster#ingestion_role}
        */
        readonly ingestionRole: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#source_engine TfCluster#source_engine}
        */
        readonly sourceEngine: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#source_engine_version TfCluster#source_engine_version}
        */
        readonly sourceEngineVersion: string;
    }
    class S3ImportPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3ImportProperty | undefined;
        set internalValue(value: S3ImportProperty | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        get bucketNameInput(): string | undefined;
        private _bucketPrefix?;
        get bucketPrefix(): string;
        set bucketPrefix(value: string);
        resetBucketPrefix(): void;
        get bucketPrefixInput(): string | undefined;
        private _ingestionRole?;
        get ingestionRole(): string;
        set ingestionRole(value: string);
        get ingestionRoleInput(): string | undefined;
        private _sourceEngine?;
        get sourceEngine(): string;
        set sourceEngine(value: string);
        get sourceEngineInput(): string | undefined;
        private _sourceEngineVersion?;
        get sourceEngineVersion(): string;
        set sourceEngineVersion(value: string);
        get sourceEngineVersionInput(): string | undefined;
    }
    interface ScalingConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#auto_pause TfCluster#auto_pause}
        */
        readonly autoPause?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#max_capacity TfCluster#max_capacity}
        */
        readonly maxCapacity?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#min_capacity TfCluster#min_capacity}
        */
        readonly minCapacity?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#seconds_before_timeout TfCluster#seconds_before_timeout}
        */
        readonly secondsBeforeTimeout?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#seconds_until_auto_pause TfCluster#seconds_until_auto_pause}
        */
        readonly secondsUntilAutoPause?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#timeout_action TfCluster#timeout_action}
        */
        readonly timeoutAction?: string;
    }
    class ScalingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ScalingConfigurationProperty | undefined;
        set internalValue(value: ScalingConfigurationProperty | undefined);
        private _autoPause?;
        get autoPause(): boolean | cdktn.IResolvable;
        set autoPause(value: boolean | cdktn.IResolvable);
        resetAutoPause(): void;
        get autoPauseInput(): boolean | cdktn.IResolvable | undefined;
        private _maxCapacity?;
        get maxCapacity(): number;
        set maxCapacity(value: number);
        resetMaxCapacity(): void;
        get maxCapacityInput(): number | undefined;
        private _minCapacity?;
        get minCapacity(): number;
        set minCapacity(value: number);
        resetMinCapacity(): void;
        get minCapacityInput(): number | undefined;
        private _secondsBeforeTimeout?;
        get secondsBeforeTimeout(): number;
        set secondsBeforeTimeout(value: number);
        resetSecondsBeforeTimeout(): void;
        get secondsBeforeTimeoutInput(): number | undefined;
        private _secondsUntilAutoPause?;
        get secondsUntilAutoPause(): number;
        set secondsUntilAutoPause(value: number);
        resetSecondsUntilAutoPause(): void;
        get secondsUntilAutoPauseInput(): number | undefined;
        private _timeoutAction?;
        get timeoutAction(): string;
        set timeoutAction(value: string);
        resetTimeoutAction(): void;
        get timeoutActionInput(): string | undefined;
    }
    interface Serverlessv2ScalingConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#max_capacity TfCluster#max_capacity}
        */
        readonly maxCapacity: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#min_capacity TfCluster#min_capacity}
        */
        readonly minCapacity: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#seconds_until_auto_pause TfCluster#seconds_until_auto_pause}
        */
        readonly secondsUntilAutoPause?: number;
    }
    class Serverlessv2ScalingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): Serverlessv2ScalingConfigurationProperty | undefined;
        set internalValue(value: Serverlessv2ScalingConfigurationProperty | undefined);
        private _maxCapacity?;
        get maxCapacity(): number;
        set maxCapacity(value: number);
        get maxCapacityInput(): number | undefined;
        private _minCapacity?;
        get minCapacity(): number;
        set minCapacity(value: number);
        get minCapacityInput(): number | undefined;
        private _secondsUntilAutoPause?;
        get secondsUntilAutoPause(): number;
        set secondsUntilAutoPause(value: number);
        resetSecondsUntilAutoPause(): void;
        get secondsUntilAutoPauseInput(): number | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#create TfCluster#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#delete TfCluster#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster#update TfCluster#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
