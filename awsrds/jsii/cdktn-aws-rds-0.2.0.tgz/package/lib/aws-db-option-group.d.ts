import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfDbOptionGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_option_group#engine_name TfDbOptionGroup#engine_name}
    */
    readonly engineName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_option_group#id TfDbOptionGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_option_group#major_engine_version TfDbOptionGroup#major_engine_version}
    */
    readonly majorEngineVersion: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_option_group#name TfDbOptionGroup#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_option_group#name_prefix TfDbOptionGroup#name_prefix}
    */
    readonly namePrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_option_group#option_group_description TfDbOptionGroup#option_group_description}
    */
    readonly optionGroupDescription?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_option_group#region TfDbOptionGroup#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_option_group#skip_destroy TfDbOptionGroup#skip_destroy}
    */
    readonly skipDestroy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_option_group#tags TfDbOptionGroup#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_option_group#tags_all TfDbOptionGroup#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * option block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_option_group#option TfDbOptionGroup#option}
    */
    readonly option?: TfDbOptionGroup.OptionProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_option_group#timeouts TfDbOptionGroup#timeouts}
    */
    readonly timeouts?: TfDbOptionGroup.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_option_group aws_db_option_group}
*/
export declare class TfDbOptionGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_db_option_group";
    /**
    * Generates CDKTN code for importing a TfDbOptionGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfDbOptionGroup to import
    * @param importFromId The id of the existing TfDbOptionGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_option_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfDbOptionGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_option_group aws_db_option_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfDbOptionGroupConfig
    */
    constructor(scope: Construct, id: string, config: TfDbOptionGroupConfig);
    get arn(): string;
    private _engineName?;
    get engineName(): string;
    set engineName(value: string);
    get engineNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _majorEngineVersion?;
    get majorEngineVersion(): string;
    set majorEngineVersion(value: string);
    get majorEngineVersionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namePrefix?;
    get namePrefix(): string;
    set namePrefix(value: string);
    resetNamePrefix(): void;
    get namePrefixInput(): string | undefined;
    private _optionGroupDescription?;
    get optionGroupDescription(): string;
    set optionGroupDescription(value: string);
    resetOptionGroupDescription(): void;
    get optionGroupDescriptionInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _skipDestroy?;
    get skipDestroy(): boolean | cdktn.IResolvable;
    set skipDestroy(value: boolean | cdktn.IResolvable);
    resetSkipDestroy(): void;
    get skipDestroyInput(): boolean | cdktn.IResolvable | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _option;
    get option(): TfDbOptionGroup.OptionPropertyList;
    putOption(value: TfDbOptionGroup.OptionProperty[] | cdktn.IResolvable): void;
    resetOption(): void;
    get optionInput(): cdktn.IResolvable | TfDbOptionGroup.OptionProperty[] | undefined;
    private _timeouts;
    get timeouts(): TfDbOptionGroup.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfDbOptionGroup.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfDbOptionGroup.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfDbOptionGroupOptionSettingsPropertyToTerraform(struct?: TfDbOptionGroup.OptionSettingsProperty | cdktn.IResolvable): any;
export declare function tfDbOptionGroupOptionSettingsPropertyToHclTerraform(struct?: TfDbOptionGroup.OptionSettingsProperty | cdktn.IResolvable): any;
export declare function tfDbOptionGroupOptionPropertyToTerraform(struct?: TfDbOptionGroup.OptionProperty | cdktn.IResolvable): any;
export declare function tfDbOptionGroupOptionPropertyToHclTerraform(struct?: TfDbOptionGroup.OptionProperty | cdktn.IResolvable): any;
export declare function tfDbOptionGroupTimeoutsPropertyToTerraform(struct?: TfDbOptionGroup.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfDbOptionGroupTimeoutsPropertyToHclTerraform(struct?: TfDbOptionGroup.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfDbOptionGroup {
    interface OptionSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_option_group#name TfDbOptionGroup#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_option_group#value TfDbOptionGroup#value}
        */
        readonly value: string;
    }
    class OptionSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OptionSettingsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OptionSettingsProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class OptionSettingsPropertyList extends cdktn.ComplexList {
        internalValue?: OptionSettingsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OptionSettingsPropertyOutputReference;
    }
    interface OptionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_option_group#db_security_group_memberships TfDbOptionGroup#db_security_group_memberships}
        */
        readonly dbSecurityGroupMemberships?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_option_group#option_name TfDbOptionGroup#option_name}
        */
        readonly optionName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_option_group#port TfDbOptionGroup#port}
        */
        readonly port?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_option_group#version TfDbOptionGroup#version}
        */
        readonly version?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_option_group#vpc_security_group_memberships TfDbOptionGroup#vpc_security_group_memberships}
        */
        readonly vpcSecurityGroupMemberships?: string[];
        /**
        * option_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_option_group#option_settings TfDbOptionGroup#option_settings}
        */
        readonly optionSettings?: OptionSettingsProperty[] | cdktn.IResolvable;
    }
    class OptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OptionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OptionProperty | cdktn.IResolvable | undefined);
        private _dbSecurityGroupMemberships?;
        get dbSecurityGroupMemberships(): string[];
        set dbSecurityGroupMemberships(value: string[]);
        resetDbSecurityGroupMemberships(): void;
        get dbSecurityGroupMembershipsInput(): string[] | undefined;
        private _optionName?;
        get optionName(): string;
        set optionName(value: string);
        get optionNameInput(): string | undefined;
        private _port?;
        get port(): number;
        set port(value: number);
        resetPort(): void;
        get portInput(): number | undefined;
        private _version?;
        get version(): string;
        set version(value: string);
        resetVersion(): void;
        get versionInput(): string | undefined;
        private _vpcSecurityGroupMemberships?;
        get vpcSecurityGroupMemberships(): string[];
        set vpcSecurityGroupMemberships(value: string[]);
        resetVpcSecurityGroupMemberships(): void;
        get vpcSecurityGroupMembershipsInput(): string[] | undefined;
        private _optionSettings;
        get optionSettings(): OptionSettingsPropertyList;
        putOptionSettings(value: OptionSettingsProperty[] | cdktn.IResolvable): void;
        resetOptionSettings(): void;
        get optionSettingsInput(): cdktn.IResolvable | OptionSettingsProperty[] | undefined;
    }
    class OptionPropertyList extends cdktn.ComplexList {
        internalValue?: OptionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OptionPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_option_group#delete TfDbOptionGroup#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
