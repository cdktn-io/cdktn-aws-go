import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDbProxyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_proxy#debug_logging AwsDbProxy#debug_logging}
    */
    readonly debugLogging?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_proxy#default_auth_scheme AwsDbProxy#default_auth_scheme}
    */
    readonly defaultAuthScheme?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_proxy#endpoint_network_type AwsDbProxy#endpoint_network_type}
    */
    readonly endpointNetworkType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_proxy#engine_family AwsDbProxy#engine_family}
    */
    readonly engineFamily: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_proxy#id AwsDbProxy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_proxy#idle_client_timeout AwsDbProxy#idle_client_timeout}
    */
    readonly idleClientTimeout?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_proxy#name AwsDbProxy#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_proxy#region AwsDbProxy#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_proxy#require_tls AwsDbProxy#require_tls}
    */
    readonly requireTls?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_proxy#role_arn AwsDbProxy#role_arn}
    */
    readonly roleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_proxy#tags AwsDbProxy#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_proxy#tags_all AwsDbProxy#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_proxy#target_connection_network_type AwsDbProxy#target_connection_network_type}
    */
    readonly targetConnectionNetworkType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_proxy#vpc_security_group_ids AwsDbProxy#vpc_security_group_ids}
    */
    readonly vpcSecurityGroupIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_proxy#vpc_subnet_ids AwsDbProxy#vpc_subnet_ids}
    */
    readonly vpcSubnetIds: string[];
    /**
    * auth block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_proxy#auth AwsDbProxy#auth}
    */
    readonly auth?: AwsDbProxy.AuthProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_proxy#timeouts AwsDbProxy#timeouts}
    */
    readonly timeouts?: AwsDbProxy.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_proxy aws_db_proxy}
*/
export declare class AwsDbProxy extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_db_proxy";
    /**
    * Generates CDKTN code for importing a AwsDbProxy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDbProxy to import
    * @param importFromId The id of the existing AwsDbProxy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_proxy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDbProxy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_proxy aws_db_proxy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDbProxyConfig
    */
    constructor(scope: Construct, id: string, config: AwsDbProxyConfig);
    get arn(): string;
    private _debugLogging?;
    get debugLogging(): boolean | cdktn.IResolvable;
    set debugLogging(value: boolean | cdktn.IResolvable);
    resetDebugLogging(): void;
    get debugLoggingInput(): boolean | cdktn.IResolvable | undefined;
    private _defaultAuthScheme?;
    get defaultAuthScheme(): string;
    set defaultAuthScheme(value: string);
    resetDefaultAuthScheme(): void;
    get defaultAuthSchemeInput(): string | undefined;
    get endpoint(): string;
    private _endpointNetworkType?;
    get endpointNetworkType(): string;
    set endpointNetworkType(value: string);
    resetEndpointNetworkType(): void;
    get endpointNetworkTypeInput(): string | undefined;
    private _engineFamily?;
    get engineFamily(): string;
    set engineFamily(value: string);
    get engineFamilyInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _idleClientTimeout?;
    get idleClientTimeout(): number;
    set idleClientTimeout(value: number);
    resetIdleClientTimeout(): void;
    get idleClientTimeoutInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _requireTls?;
    get requireTls(): boolean | cdktn.IResolvable;
    set requireTls(value: boolean | cdktn.IResolvable);
    resetRequireTls(): void;
    get requireTlsInput(): boolean | cdktn.IResolvable | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _targetConnectionNetworkType?;
    get targetConnectionNetworkType(): string;
    set targetConnectionNetworkType(value: string);
    resetTargetConnectionNetworkType(): void;
    get targetConnectionNetworkTypeInput(): string | undefined;
    private _vpcSecurityGroupIds?;
    get vpcSecurityGroupIds(): string[];
    set vpcSecurityGroupIds(value: string[]);
    resetVpcSecurityGroupIds(): void;
    get vpcSecurityGroupIdsInput(): string[] | undefined;
    private _vpcSubnetIds?;
    get vpcSubnetIds(): string[];
    set vpcSubnetIds(value: string[]);
    get vpcSubnetIdsInput(): string[] | undefined;
    private _auth;
    get auth(): AwsDbProxy.AuthPropertyList;
    putAuth(value: AwsDbProxy.AuthProperty[] | cdktn.IResolvable): void;
    resetAuth(): void;
    get authInput(): cdktn.IResolvable | AwsDbProxy.AuthProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsDbProxy.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsDbProxy.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsDbProxy.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsDbProxyAuthPropertyToTerraform(struct?: AwsDbProxy.AuthProperty | cdktn.IResolvable): any;
export declare function awsDbProxyAuthPropertyToHclTerraform(struct?: AwsDbProxy.AuthProperty | cdktn.IResolvable): any;
export declare function awsDbProxyTimeoutsPropertyToTerraform(struct?: AwsDbProxy.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsDbProxyTimeoutsPropertyToHclTerraform(struct?: AwsDbProxy.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsDbProxy {
    interface AuthProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_proxy#auth_scheme AwsDbProxy#auth_scheme}
        */
        readonly authScheme?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_proxy#client_password_auth_type AwsDbProxy#client_password_auth_type}
        */
        readonly clientPasswordAuthType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_proxy#description AwsDbProxy#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_proxy#iam_auth AwsDbProxy#iam_auth}
        */
        readonly iamAuth?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_proxy#secret_arn AwsDbProxy#secret_arn}
        */
        readonly secretArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_proxy#username AwsDbProxy#username}
        */
        readonly username?: string;
    }
    class AuthPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AuthProperty | cdktn.IResolvable | undefined);
        private _authScheme?;
        get authScheme(): string;
        set authScheme(value: string);
        resetAuthScheme(): void;
        get authSchemeInput(): string | undefined;
        private _clientPasswordAuthType?;
        get clientPasswordAuthType(): string;
        set clientPasswordAuthType(value: string);
        resetClientPasswordAuthType(): void;
        get clientPasswordAuthTypeInput(): string | undefined;
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _iamAuth?;
        get iamAuth(): string;
        set iamAuth(value: string);
        resetIamAuth(): void;
        get iamAuthInput(): string | undefined;
        private _secretArn?;
        get secretArn(): string;
        set secretArn(value: string);
        resetSecretArn(): void;
        get secretArnInput(): string | undefined;
        private _username?;
        get username(): string;
        set username(value: string);
        resetUsername(): void;
        get usernameInput(): string | undefined;
    }
    class AuthPropertyList extends cdktn.ComplexList {
        internalValue?: AuthProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_proxy#create AwsDbProxy#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_proxy#delete AwsDbProxy#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_proxy#update AwsDbProxy#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
