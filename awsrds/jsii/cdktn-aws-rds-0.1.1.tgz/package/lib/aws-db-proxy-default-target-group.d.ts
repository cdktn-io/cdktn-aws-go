import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDbProxyDefaultTargetGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_proxy_default_target_group#db_proxy_name AwsDbProxyDefaultTargetGroup#db_proxy_name}
    */
    readonly dbProxyName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_proxy_default_target_group#id AwsDbProxyDefaultTargetGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_proxy_default_target_group#region AwsDbProxyDefaultTargetGroup#region}
    */
    readonly region?: string;
    /**
    * connection_pool_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_proxy_default_target_group#connection_pool_config AwsDbProxyDefaultTargetGroup#connection_pool_config}
    */
    readonly connectionPoolConfig?: AwsDbProxyDefaultTargetGroup.ConnectionPoolConfigProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_proxy_default_target_group#timeouts AwsDbProxyDefaultTargetGroup#timeouts}
    */
    readonly timeouts?: AwsDbProxyDefaultTargetGroup.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_proxy_default_target_group aws_db_proxy_default_target_group}
*/
export declare class AwsDbProxyDefaultTargetGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_db_proxy_default_target_group";
    /**
    * Generates CDKTN code for importing a AwsDbProxyDefaultTargetGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDbProxyDefaultTargetGroup to import
    * @param importFromId The id of the existing AwsDbProxyDefaultTargetGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_proxy_default_target_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDbProxyDefaultTargetGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_proxy_default_target_group aws_db_proxy_default_target_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDbProxyDefaultTargetGroupConfig
    */
    constructor(scope: Construct, id: string, config: AwsDbProxyDefaultTargetGroupConfig);
    get arn(): string;
    private _dbProxyName?;
    get dbProxyName(): string;
    set dbProxyName(value: string);
    get dbProxyNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get name(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _connectionPoolConfig;
    get connectionPoolConfig(): AwsDbProxyDefaultTargetGroup.ConnectionPoolConfigPropertyOutputReference;
    putConnectionPoolConfig(value: AwsDbProxyDefaultTargetGroup.ConnectionPoolConfigProperty): void;
    resetConnectionPoolConfig(): void;
    get connectionPoolConfigInput(): AwsDbProxyDefaultTargetGroup.ConnectionPoolConfigProperty | undefined;
    private _timeouts;
    get timeouts(): AwsDbProxyDefaultTargetGroup.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsDbProxyDefaultTargetGroup.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsDbProxyDefaultTargetGroup.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsDbProxyDefaultTargetGroupConnectionPoolConfigPropertyToTerraform(struct?: AwsDbProxyDefaultTargetGroup.ConnectionPoolConfigPropertyOutputReference | AwsDbProxyDefaultTargetGroup.ConnectionPoolConfigProperty): any;
export declare function awsDbProxyDefaultTargetGroupConnectionPoolConfigPropertyToHclTerraform(struct?: AwsDbProxyDefaultTargetGroup.ConnectionPoolConfigPropertyOutputReference | AwsDbProxyDefaultTargetGroup.ConnectionPoolConfigProperty): any;
export declare function awsDbProxyDefaultTargetGroupTimeoutsPropertyToTerraform(struct?: AwsDbProxyDefaultTargetGroup.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsDbProxyDefaultTargetGroupTimeoutsPropertyToHclTerraform(struct?: AwsDbProxyDefaultTargetGroup.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsDbProxyDefaultTargetGroup {
    interface ConnectionPoolConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_proxy_default_target_group#connection_borrow_timeout AwsDbProxyDefaultTargetGroup#connection_borrow_timeout}
        */
        readonly connectionBorrowTimeout?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_proxy_default_target_group#init_query AwsDbProxyDefaultTargetGroup#init_query}
        */
        readonly initQuery?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_proxy_default_target_group#max_connections_percent AwsDbProxyDefaultTargetGroup#max_connections_percent}
        */
        readonly maxConnectionsPercent?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_proxy_default_target_group#max_idle_connections_percent AwsDbProxyDefaultTargetGroup#max_idle_connections_percent}
        */
        readonly maxIdleConnectionsPercent?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_proxy_default_target_group#session_pinning_filters AwsDbProxyDefaultTargetGroup#session_pinning_filters}
        */
        readonly sessionPinningFilters?: string[];
    }
    class ConnectionPoolConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConnectionPoolConfigProperty | undefined;
        set internalValue(value: ConnectionPoolConfigProperty | undefined);
        private _connectionBorrowTimeout?;
        get connectionBorrowTimeout(): number;
        set connectionBorrowTimeout(value: number);
        resetConnectionBorrowTimeout(): void;
        get connectionBorrowTimeoutInput(): number | undefined;
        private _initQuery?;
        get initQuery(): string;
        set initQuery(value: string);
        resetInitQuery(): void;
        get initQueryInput(): string | undefined;
        private _maxConnectionsPercent?;
        get maxConnectionsPercent(): number;
        set maxConnectionsPercent(value: number);
        resetMaxConnectionsPercent(): void;
        get maxConnectionsPercentInput(): number | undefined;
        private _maxIdleConnectionsPercent?;
        get maxIdleConnectionsPercent(): number;
        set maxIdleConnectionsPercent(value: number);
        resetMaxIdleConnectionsPercent(): void;
        get maxIdleConnectionsPercentInput(): number | undefined;
        private _sessionPinningFilters?;
        get sessionPinningFilters(): string[];
        set sessionPinningFilters(value: string[]);
        resetSessionPinningFilters(): void;
        get sessionPinningFiltersInput(): string[] | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_proxy_default_target_group#create AwsDbProxyDefaultTargetGroup#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_proxy_default_target_group#update AwsDbProxyDefaultTargetGroup#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
