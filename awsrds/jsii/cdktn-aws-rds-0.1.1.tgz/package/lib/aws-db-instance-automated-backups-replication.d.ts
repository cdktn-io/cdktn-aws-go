import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDbInstanceAutomatedBackupsReplicationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance_automated_backups_replication#id AwsDbInstanceAutomatedBackupsReplication#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance_automated_backups_replication#kms_key_id AwsDbInstanceAutomatedBackupsReplication#kms_key_id}
    */
    readonly kmsKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance_automated_backups_replication#pre_signed_url AwsDbInstanceAutomatedBackupsReplication#pre_signed_url}
    */
    readonly preSignedUrl?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance_automated_backups_replication#region AwsDbInstanceAutomatedBackupsReplication#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance_automated_backups_replication#retention_period AwsDbInstanceAutomatedBackupsReplication#retention_period}
    */
    readonly retentionPeriod?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance_automated_backups_replication#source_db_instance_arn AwsDbInstanceAutomatedBackupsReplication#source_db_instance_arn}
    */
    readonly sourceDbInstanceArn: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance_automated_backups_replication#timeouts AwsDbInstanceAutomatedBackupsReplication#timeouts}
    */
    readonly timeouts?: AwsDbInstanceAutomatedBackupsReplication.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance_automated_backups_replication aws_db_instance_automated_backups_replication}
*/
export declare class AwsDbInstanceAutomatedBackupsReplication extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_db_instance_automated_backups_replication";
    /**
    * Generates CDKTN code for importing a AwsDbInstanceAutomatedBackupsReplication resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDbInstanceAutomatedBackupsReplication to import
    * @param importFromId The id of the existing AwsDbInstanceAutomatedBackupsReplication that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance_automated_backups_replication#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDbInstanceAutomatedBackupsReplication to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance_automated_backups_replication aws_db_instance_automated_backups_replication} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDbInstanceAutomatedBackupsReplicationConfig
    */
    constructor(scope: Construct, id: string, config: AwsDbInstanceAutomatedBackupsReplicationConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _kmsKeyId?;
    get kmsKeyId(): string;
    set kmsKeyId(value: string);
    resetKmsKeyId(): void;
    get kmsKeyIdInput(): string | undefined;
    private _preSignedUrl?;
    get preSignedUrl(): string;
    set preSignedUrl(value: string);
    resetPreSignedUrl(): void;
    get preSignedUrlInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _retentionPeriod?;
    get retentionPeriod(): number;
    set retentionPeriod(value: number);
    resetRetentionPeriod(): void;
    get retentionPeriodInput(): number | undefined;
    private _sourceDbInstanceArn?;
    get sourceDbInstanceArn(): string;
    set sourceDbInstanceArn(value: string);
    get sourceDbInstanceArnInput(): string | undefined;
    private _timeouts;
    get timeouts(): AwsDbInstanceAutomatedBackupsReplication.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsDbInstanceAutomatedBackupsReplication.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsDbInstanceAutomatedBackupsReplication.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsDbInstanceAutomatedBackupsReplicationTimeoutsPropertyToTerraform(struct?: AwsDbInstanceAutomatedBackupsReplication.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsDbInstanceAutomatedBackupsReplicationTimeoutsPropertyToHclTerraform(struct?: AwsDbInstanceAutomatedBackupsReplication.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsDbInstanceAutomatedBackupsReplication {
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance_automated_backups_replication#create AwsDbInstanceAutomatedBackupsReplication#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_instance_automated_backups_replication#delete AwsDbInstanceAutomatedBackupsReplication#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
