import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDbOptionGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_option_group#engine_name AwsDbOptionGroup#engine_name}
    */
    readonly engineName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_option_group#id AwsDbOptionGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_option_group#major_engine_version AwsDbOptionGroup#major_engine_version}
    */
    readonly majorEngineVersion: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_option_group#name AwsDbOptionGroup#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_option_group#name_prefix AwsDbOptionGroup#name_prefix}
    */
    readonly namePrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_option_group#option_group_description AwsDbOptionGroup#option_group_description}
    */
    readonly optionGroupDescription?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_option_group#region AwsDbOptionGroup#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_option_group#skip_destroy AwsDbOptionGroup#skip_destroy}
    */
    readonly skipDestroy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_option_group#tags AwsDbOptionGroup#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_option_group#tags_all AwsDbOptionGroup#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * option block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_option_group#option AwsDbOptionGroup#option}
    */
    readonly option?: AwsDbOptionGroup.OptionProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_option_group#timeouts AwsDbOptionGroup#timeouts}
    */
    readonly timeouts?: AwsDbOptionGroup.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_option_group aws_db_option_group}
*/
export declare class AwsDbOptionGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_db_option_group";
    /**
    * Generates CDKTN code for importing a AwsDbOptionGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDbOptionGroup to import
    * @param importFromId The id of the existing AwsDbOptionGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_option_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDbOptionGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_option_group aws_db_option_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDbOptionGroupConfig
    */
    constructor(scope: Construct, id: string, config: AwsDbOptionGroupConfig);
    get arn(): string;
    private _engineName?;
    get engineName(): string;
    set engineName(value: string);
    get engineNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _majorEngineVersion?;
    get majorEngineVersion(): string;
    set majorEngineVersion(value: string);
    get majorEngineVersionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namePrefix?;
    get namePrefix(): string;
    set namePrefix(value: string);
    resetNamePrefix(): void;
    get namePrefixInput(): string | undefined;
    private _optionGroupDescription?;
    get optionGroupDescription(): string;
    set optionGroupDescription(value: string);
    resetOptionGroupDescription(): void;
    get optionGroupDescriptionInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _skipDestroy?;
    get skipDestroy(): boolean | cdktn.IResolvable;
    set skipDestroy(value: boolean | cdktn.IResolvable);
    resetSkipDestroy(): void;
    get skipDestroyInput(): boolean | cdktn.IResolvable | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _option;
    get option(): AwsDbOptionGroup.OptionPropertyList;
    putOption(value: AwsDbOptionGroup.OptionProperty[] | cdktn.IResolvable): void;
    resetOption(): void;
    get optionInput(): cdktn.IResolvable | AwsDbOptionGroup.OptionProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsDbOptionGroup.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsDbOptionGroup.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsDbOptionGroup.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsDbOptionGroupOptionSettingsPropertyToTerraform(struct?: AwsDbOptionGroup.OptionSettingsProperty | cdktn.IResolvable): any;
export declare function awsDbOptionGroupOptionSettingsPropertyToHclTerraform(struct?: AwsDbOptionGroup.OptionSettingsProperty | cdktn.IResolvable): any;
export declare function awsDbOptionGroupOptionPropertyToTerraform(struct?: AwsDbOptionGroup.OptionProperty | cdktn.IResolvable): any;
export declare function awsDbOptionGroupOptionPropertyToHclTerraform(struct?: AwsDbOptionGroup.OptionProperty | cdktn.IResolvable): any;
export declare function awsDbOptionGroupTimeoutsPropertyToTerraform(struct?: AwsDbOptionGroup.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsDbOptionGroupTimeoutsPropertyToHclTerraform(struct?: AwsDbOptionGroup.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsDbOptionGroup {
    interface OptionSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_option_group#name AwsDbOptionGroup#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_option_group#value AwsDbOptionGroup#value}
        */
        readonly value: string;
    }
    class OptionSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OptionSettingsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OptionSettingsProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class OptionSettingsPropertyList extends cdktn.ComplexList {
        internalValue?: OptionSettingsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OptionSettingsPropertyOutputReference;
    }
    interface OptionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_option_group#db_security_group_memberships AwsDbOptionGroup#db_security_group_memberships}
        */
        readonly dbSecurityGroupMemberships?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_option_group#option_name AwsDbOptionGroup#option_name}
        */
        readonly optionName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_option_group#port AwsDbOptionGroup#port}
        */
        readonly port?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_option_group#version AwsDbOptionGroup#version}
        */
        readonly version?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_option_group#vpc_security_group_memberships AwsDbOptionGroup#vpc_security_group_memberships}
        */
        readonly vpcSecurityGroupMemberships?: string[];
        /**
        * option_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_option_group#option_settings AwsDbOptionGroup#option_settings}
        */
        readonly optionSettings?: OptionSettingsProperty[] | cdktn.IResolvable;
    }
    class OptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OptionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OptionProperty | cdktn.IResolvable | undefined);
        private _dbSecurityGroupMemberships?;
        get dbSecurityGroupMemberships(): string[];
        set dbSecurityGroupMemberships(value: string[]);
        resetDbSecurityGroupMemberships(): void;
        get dbSecurityGroupMembershipsInput(): string[] | undefined;
        private _optionName?;
        get optionName(): string;
        set optionName(value: string);
        get optionNameInput(): string | undefined;
        private _port?;
        get port(): number;
        set port(value: number);
        resetPort(): void;
        get portInput(): number | undefined;
        private _version?;
        get version(): string;
        set version(value: string);
        resetVersion(): void;
        get versionInput(): string | undefined;
        private _vpcSecurityGroupMemberships?;
        get vpcSecurityGroupMemberships(): string[];
        set vpcSecurityGroupMemberships(value: string[]);
        resetVpcSecurityGroupMemberships(): void;
        get vpcSecurityGroupMembershipsInput(): string[] | undefined;
        private _optionSettings;
        get optionSettings(): OptionSettingsPropertyList;
        putOptionSettings(value: OptionSettingsProperty[] | cdktn.IResolvable): void;
        resetOptionSettings(): void;
        get optionSettingsInput(): cdktn.IResolvable | OptionSettingsProperty[] | undefined;
    }
    class OptionPropertyList extends cdktn.ComplexList {
        internalValue?: OptionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OptionPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/db_option_group#delete AwsDbOptionGroup#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
