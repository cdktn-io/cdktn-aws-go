import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsRdsReservedInstanceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_reserved_instance#id AwsRdsReservedInstance#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_reserved_instance#instance_count AwsRdsReservedInstance#instance_count}
    */
    readonly instanceCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_reserved_instance#offering_id AwsRdsReservedInstance#offering_id}
    */
    readonly offeringId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_reserved_instance#region AwsRdsReservedInstance#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_reserved_instance#reservation_id AwsRdsReservedInstance#reservation_id}
    */
    readonly reservationId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_reserved_instance#tags AwsRdsReservedInstance#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_reserved_instance#tags_all AwsRdsReservedInstance#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_reserved_instance#timeouts AwsRdsReservedInstance#timeouts}
    */
    readonly timeouts?: AwsRdsReservedInstance.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_reserved_instance aws_rds_reserved_instance}
*/
export declare class AwsRdsReservedInstance extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_rds_reserved_instance";
    /**
    * Generates CDKTN code for importing a AwsRdsReservedInstance resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsRdsReservedInstance to import
    * @param importFromId The id of the existing AwsRdsReservedInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_reserved_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsRdsReservedInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_reserved_instance aws_rds_reserved_instance} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsRdsReservedInstanceConfig
    */
    constructor(scope: Construct, id: string, config: AwsRdsReservedInstanceConfig);
    get arn(): string;
    get currencyCode(): string;
    get dbInstanceClass(): string;
    get duration(): number;
    get fixedPrice(): number;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceCount?;
    get instanceCount(): number;
    set instanceCount(value: number);
    resetInstanceCount(): void;
    get instanceCountInput(): number | undefined;
    get leaseId(): string;
    get multiAz(): cdktn.IResolvable;
    private _offeringId?;
    get offeringId(): string;
    set offeringId(value: string);
    get offeringIdInput(): string | undefined;
    get offeringType(): string;
    get productDescription(): string;
    private _recurringCharges;
    get recurringCharges(): AwsRdsReservedInstance.RecurringChargesPropertyList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _reservationId?;
    get reservationId(): string;
    set reservationId(value: string);
    resetReservationId(): void;
    get reservationIdInput(): string | undefined;
    get startTime(): string;
    get state(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get usagePrice(): number;
    private _timeouts;
    get timeouts(): AwsRdsReservedInstance.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsRdsReservedInstance.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsRdsReservedInstance.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsRdsReservedInstanceRecurringChargesPropertyToTerraform(struct?: AwsRdsReservedInstance.RecurringChargesProperty): any;
export declare function awsRdsReservedInstanceRecurringChargesPropertyToHclTerraform(struct?: AwsRdsReservedInstance.RecurringChargesProperty): any;
export declare function awsRdsReservedInstanceTimeoutsPropertyToTerraform(struct?: AwsRdsReservedInstance.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsRdsReservedInstanceTimeoutsPropertyToHclTerraform(struct?: AwsRdsReservedInstance.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsRdsReservedInstance {
    interface RecurringChargesProperty {
    }
    class RecurringChargesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RecurringChargesProperty | undefined;
        set internalValue(value: RecurringChargesProperty | undefined);
        get recurringChargeAmount(): number;
        get recurringChargeFrequency(): string;
    }
    class RecurringChargesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RecurringChargesPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_reserved_instance#create AwsRdsReservedInstance#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_reserved_instance#delete AwsRdsReservedInstance#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_reserved_instance#update AwsRdsReservedInstance#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
