import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsConnectionGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_connection_group#anycast_ip_list_id AwsConnectionGroup#anycast_ip_list_id}
    */
    readonly anycastIpListId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_connection_group#enabled AwsConnectionGroup#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_connection_group#ipv6_enabled AwsConnectionGroup#ipv6_enabled}
    */
    readonly ipv6Enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_connection_group#name AwsConnectionGroup#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_connection_group#tags AwsConnectionGroup#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_connection_group#wait_for_deployment AwsConnectionGroup#wait_for_deployment}
    */
    readonly waitForDeployment?: boolean | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_connection_group#timeouts AwsConnectionGroup#timeouts}
    */
    readonly timeouts?: AwsConnectionGroup.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_connection_group aws_cloudfront_connection_group}
*/
export declare class AwsConnectionGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudfront_connection_group";
    /**
    * Generates CDKTN code for importing a AwsConnectionGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsConnectionGroup to import
    * @param importFromId The id of the existing AwsConnectionGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_connection_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsConnectionGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_connection_group aws_cloudfront_connection_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsConnectionGroupConfig
    */
    constructor(scope: Construct, id: string, config: AwsConnectionGroupConfig);
    private _anycastIpListId?;
    get anycastIpListId(): string;
    set anycastIpListId(value: string);
    resetAnycastIpListId(): void;
    get anycastIpListIdInput(): string | undefined;
    get arn(): string;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get etag(): string;
    get id(): string;
    private _ipv6Enabled?;
    get ipv6Enabled(): boolean | cdktn.IResolvable;
    set ipv6Enabled(value: boolean | cdktn.IResolvable);
    resetIpv6Enabled(): void;
    get ipv6EnabledInput(): boolean | cdktn.IResolvable | undefined;
    get isDefault(): cdktn.IResolvable;
    get lastModifiedTime(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get routingEndpoint(): string;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _waitForDeployment?;
    get waitForDeployment(): boolean | cdktn.IResolvable;
    set waitForDeployment(value: boolean | cdktn.IResolvable);
    resetWaitForDeployment(): void;
    get waitForDeploymentInput(): boolean | cdktn.IResolvable | undefined;
    private _timeouts;
    get timeouts(): AwsConnectionGroup.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsConnectionGroup.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsConnectionGroup.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsConnectionGroupTimeoutsPropertyToTerraform(struct?: AwsConnectionGroup.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsConnectionGroupTimeoutsPropertyToHclTerraform(struct?: AwsConnectionGroup.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsConnectionGroup {
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Default is 90 minutes.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_connection_group#create AwsConnectionGroup#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Default is 90 minutes.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_connection_group#delete AwsConnectionGroup#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Default is 90 minutes.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_connection_group#update AwsConnectionGroup#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
