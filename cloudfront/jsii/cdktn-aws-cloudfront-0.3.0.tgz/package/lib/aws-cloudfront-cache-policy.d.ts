import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsCachePolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_cache_policy#comment AwsCachePolicy#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_cache_policy#default_ttl AwsCachePolicy#default_ttl}
    */
    readonly defaultTtl?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_cache_policy#id AwsCachePolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_cache_policy#max_ttl AwsCachePolicy#max_ttl}
    */
    readonly maxTtl?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_cache_policy#min_ttl AwsCachePolicy#min_ttl}
    */
    readonly minTtl?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_cache_policy#name AwsCachePolicy#name}
    */
    readonly name: string;
    /**
    * parameters_in_cache_key_and_forwarded_to_origin block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_cache_policy#parameters_in_cache_key_and_forwarded_to_origin AwsCachePolicy#parameters_in_cache_key_and_forwarded_to_origin}
    */
    readonly parametersInCacheKeyAndForwardedToOrigin: AwsCachePolicy.ParametersInCacheKeyAndForwardedToOriginProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_cache_policy aws_cloudfront_cache_policy}
*/
export declare class AwsCachePolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudfront_cache_policy";
    /**
    * Generates CDKTN code for importing a AwsCachePolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsCachePolicy to import
    * @param importFromId The id of the existing AwsCachePolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_cache_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsCachePolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_cache_policy aws_cloudfront_cache_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsCachePolicyConfig
    */
    constructor(scope: Construct, id: string, config: AwsCachePolicyConfig);
    get arn(): string;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _defaultTtl?;
    get defaultTtl(): number;
    set defaultTtl(value: number);
    resetDefaultTtl(): void;
    get defaultTtlInput(): number | undefined;
    get etag(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _maxTtl?;
    get maxTtl(): number;
    set maxTtl(value: number);
    resetMaxTtl(): void;
    get maxTtlInput(): number | undefined;
    private _minTtl?;
    get minTtl(): number;
    set minTtl(value: number);
    resetMinTtl(): void;
    get minTtlInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parametersInCacheKeyAndForwardedToOrigin;
    get parametersInCacheKeyAndForwardedToOrigin(): AwsCachePolicy.ParametersInCacheKeyAndForwardedToOriginPropertyOutputReference;
    putParametersInCacheKeyAndForwardedToOrigin(value: AwsCachePolicy.ParametersInCacheKeyAndForwardedToOriginProperty): void;
    get parametersInCacheKeyAndForwardedToOriginInput(): AwsCachePolicy.ParametersInCacheKeyAndForwardedToOriginProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsCachePolicyCookiesPropertyToTerraform(struct?: AwsCachePolicy.CookiesPropertyOutputReference | AwsCachePolicy.CookiesProperty): any;
export declare function awsCachePolicyCookiesPropertyToHclTerraform(struct?: AwsCachePolicy.CookiesPropertyOutputReference | AwsCachePolicy.CookiesProperty): any;
export declare function awsCachePolicyCookiesConfigPropertyToTerraform(struct?: AwsCachePolicy.CookiesConfigPropertyOutputReference | AwsCachePolicy.CookiesConfigProperty): any;
export declare function awsCachePolicyCookiesConfigPropertyToHclTerraform(struct?: AwsCachePolicy.CookiesConfigPropertyOutputReference | AwsCachePolicy.CookiesConfigProperty): any;
export declare function awsCachePolicyHeadersPropertyToTerraform(struct?: AwsCachePolicy.HeadersPropertyOutputReference | AwsCachePolicy.HeadersProperty): any;
export declare function awsCachePolicyHeadersPropertyToHclTerraform(struct?: AwsCachePolicy.HeadersPropertyOutputReference | AwsCachePolicy.HeadersProperty): any;
export declare function awsCachePolicyHeadersConfigPropertyToTerraform(struct?: AwsCachePolicy.HeadersConfigPropertyOutputReference | AwsCachePolicy.HeadersConfigProperty): any;
export declare function awsCachePolicyHeadersConfigPropertyToHclTerraform(struct?: AwsCachePolicy.HeadersConfigPropertyOutputReference | AwsCachePolicy.HeadersConfigProperty): any;
export declare function awsCachePolicyQueryStringsPropertyToTerraform(struct?: AwsCachePolicy.QueryStringsPropertyOutputReference | AwsCachePolicy.QueryStringsProperty): any;
export declare function awsCachePolicyQueryStringsPropertyToHclTerraform(struct?: AwsCachePolicy.QueryStringsPropertyOutputReference | AwsCachePolicy.QueryStringsProperty): any;
export declare function awsCachePolicyQueryStringsConfigPropertyToTerraform(struct?: AwsCachePolicy.QueryStringsConfigPropertyOutputReference | AwsCachePolicy.QueryStringsConfigProperty): any;
export declare function awsCachePolicyQueryStringsConfigPropertyToHclTerraform(struct?: AwsCachePolicy.QueryStringsConfigPropertyOutputReference | AwsCachePolicy.QueryStringsConfigProperty): any;
export declare function awsCachePolicyParametersInCacheKeyAndForwardedToOriginPropertyToTerraform(struct?: AwsCachePolicy.ParametersInCacheKeyAndForwardedToOriginPropertyOutputReference | AwsCachePolicy.ParametersInCacheKeyAndForwardedToOriginProperty): any;
export declare function awsCachePolicyParametersInCacheKeyAndForwardedToOriginPropertyToHclTerraform(struct?: AwsCachePolicy.ParametersInCacheKeyAndForwardedToOriginPropertyOutputReference | AwsCachePolicy.ParametersInCacheKeyAndForwardedToOriginProperty): any;
export declare namespace AwsCachePolicy {
    interface CookiesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_cache_policy#items AwsCachePolicy#items}
        */
        readonly items?: string[];
    }
    class CookiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CookiesProperty | undefined;
        set internalValue(value: CookiesProperty | undefined);
        private _items?;
        get items(): string[];
        set items(value: string[]);
        resetItems(): void;
        get itemsInput(): string[] | undefined;
    }
    interface CookiesConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_cache_policy#cookie_behavior AwsCachePolicy#cookie_behavior}
        */
        readonly cookieBehavior: string;
        /**
        * cookies block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_cache_policy#cookies AwsCachePolicy#cookies}
        */
        readonly cookies?: CookiesProperty;
    }
    class CookiesConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CookiesConfigProperty | undefined;
        set internalValue(value: CookiesConfigProperty | undefined);
        private _cookieBehavior?;
        get cookieBehavior(): string;
        set cookieBehavior(value: string);
        get cookieBehaviorInput(): string | undefined;
        private _cookies;
        get cookies(): CookiesPropertyOutputReference;
        putCookies(value: CookiesProperty): void;
        resetCookies(): void;
        get cookiesInput(): CookiesProperty | undefined;
    }
    interface HeadersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_cache_policy#items AwsCachePolicy#items}
        */
        readonly items?: string[];
    }
    class HeadersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HeadersProperty | undefined;
        set internalValue(value: HeadersProperty | undefined);
        private _items?;
        get items(): string[];
        set items(value: string[]);
        resetItems(): void;
        get itemsInput(): string[] | undefined;
    }
    interface HeadersConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_cache_policy#header_behavior AwsCachePolicy#header_behavior}
        */
        readonly headerBehavior?: string;
        /**
        * headers block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_cache_policy#headers AwsCachePolicy#headers}
        */
        readonly headers?: HeadersProperty;
    }
    class HeadersConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HeadersConfigProperty | undefined;
        set internalValue(value: HeadersConfigProperty | undefined);
        private _headerBehavior?;
        get headerBehavior(): string;
        set headerBehavior(value: string);
        resetHeaderBehavior(): void;
        get headerBehaviorInput(): string | undefined;
        private _headers;
        get headers(): HeadersPropertyOutputReference;
        putHeaders(value: HeadersProperty): void;
        resetHeaders(): void;
        get headersInput(): HeadersProperty | undefined;
    }
    interface QueryStringsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_cache_policy#items AwsCachePolicy#items}
        */
        readonly items?: string[];
    }
    class QueryStringsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): QueryStringsProperty | undefined;
        set internalValue(value: QueryStringsProperty | undefined);
        private _items?;
        get items(): string[];
        set items(value: string[]);
        resetItems(): void;
        get itemsInput(): string[] | undefined;
    }
    interface QueryStringsConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_cache_policy#query_string_behavior AwsCachePolicy#query_string_behavior}
        */
        readonly queryStringBehavior: string;
        /**
        * query_strings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_cache_policy#query_strings AwsCachePolicy#query_strings}
        */
        readonly queryStrings?: QueryStringsProperty;
    }
    class QueryStringsConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): QueryStringsConfigProperty | undefined;
        set internalValue(value: QueryStringsConfigProperty | undefined);
        private _queryStringBehavior?;
        get queryStringBehavior(): string;
        set queryStringBehavior(value: string);
        get queryStringBehaviorInput(): string | undefined;
        private _queryStrings;
        get queryStrings(): QueryStringsPropertyOutputReference;
        putQueryStrings(value: QueryStringsProperty): void;
        resetQueryStrings(): void;
        get queryStringsInput(): QueryStringsProperty | undefined;
    }
    interface ParametersInCacheKeyAndForwardedToOriginProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_cache_policy#enable_accept_encoding_brotli AwsCachePolicy#enable_accept_encoding_brotli}
        */
        readonly enableAcceptEncodingBrotli?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_cache_policy#enable_accept_encoding_gzip AwsCachePolicy#enable_accept_encoding_gzip}
        */
        readonly enableAcceptEncodingGzip?: boolean | cdktn.IResolvable;
        /**
        * cookies_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_cache_policy#cookies_config AwsCachePolicy#cookies_config}
        */
        readonly cookiesConfig: CookiesConfigProperty;
        /**
        * headers_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_cache_policy#headers_config AwsCachePolicy#headers_config}
        */
        readonly headersConfig: HeadersConfigProperty;
        /**
        * query_strings_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_cache_policy#query_strings_config AwsCachePolicy#query_strings_config}
        */
        readonly queryStringsConfig: QueryStringsConfigProperty;
    }
    class ParametersInCacheKeyAndForwardedToOriginPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ParametersInCacheKeyAndForwardedToOriginProperty | undefined;
        set internalValue(value: ParametersInCacheKeyAndForwardedToOriginProperty | undefined);
        private _enableAcceptEncodingBrotli?;
        get enableAcceptEncodingBrotli(): boolean | cdktn.IResolvable;
        set enableAcceptEncodingBrotli(value: boolean | cdktn.IResolvable);
        resetEnableAcceptEncodingBrotli(): void;
        get enableAcceptEncodingBrotliInput(): boolean | cdktn.IResolvable | undefined;
        private _enableAcceptEncodingGzip?;
        get enableAcceptEncodingGzip(): boolean | cdktn.IResolvable;
        set enableAcceptEncodingGzip(value: boolean | cdktn.IResolvable);
        resetEnableAcceptEncodingGzip(): void;
        get enableAcceptEncodingGzipInput(): boolean | cdktn.IResolvable | undefined;
        private _cookiesConfig;
        get cookiesConfig(): CookiesConfigPropertyOutputReference;
        putCookiesConfig(value: CookiesConfigProperty): void;
        get cookiesConfigInput(): CookiesConfigProperty | undefined;
        private _headersConfig;
        get headersConfig(): HeadersConfigPropertyOutputReference;
        putHeadersConfig(value: HeadersConfigProperty): void;
        get headersConfigInput(): HeadersConfigProperty | undefined;
        private _queryStringsConfig;
        get queryStringsConfig(): QueryStringsConfigPropertyOutputReference;
        putQueryStringsConfig(value: QueryStringsConfigProperty): void;
        get queryStringsConfigInput(): QueryStringsConfigProperty | undefined;
    }
}
