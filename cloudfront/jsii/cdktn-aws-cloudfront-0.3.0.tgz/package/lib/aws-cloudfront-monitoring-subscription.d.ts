import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsMonitoringSubscriptionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_monitoring_subscription#distribution_id AwsMonitoringSubscription#distribution_id}
    */
    readonly distributionId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_monitoring_subscription#id AwsMonitoringSubscription#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * monitoring_subscription block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_monitoring_subscription#monitoring_subscription AwsMonitoringSubscription#monitoring_subscription}
    */
    readonly monitoringSubscription: AwsMonitoringSubscription.MonitoringSubscriptionProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_monitoring_subscription aws_cloudfront_monitoring_subscription}
*/
export declare class AwsMonitoringSubscription extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudfront_monitoring_subscription";
    /**
    * Generates CDKTN code for importing a AwsMonitoringSubscription resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsMonitoringSubscription to import
    * @param importFromId The id of the existing AwsMonitoringSubscription that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_monitoring_subscription#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsMonitoringSubscription to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_monitoring_subscription aws_cloudfront_monitoring_subscription} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsMonitoringSubscriptionConfig
    */
    constructor(scope: Construct, id: string, config: AwsMonitoringSubscriptionConfig);
    private _distributionId?;
    get distributionId(): string;
    set distributionId(value: string);
    get distributionIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _monitoringSubscription;
    get monitoringSubscription(): AwsMonitoringSubscription.MonitoringSubscriptionPropertyOutputReference;
    putMonitoringSubscription(value: AwsMonitoringSubscription.MonitoringSubscriptionProperty): void;
    get monitoringSubscriptionInput(): AwsMonitoringSubscription.MonitoringSubscriptionProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsMonitoringSubscriptionRealtimeMetricsSubscriptionConfigPropertyToTerraform(struct?: AwsMonitoringSubscription.RealtimeMetricsSubscriptionConfigPropertyOutputReference | AwsMonitoringSubscription.RealtimeMetricsSubscriptionConfigProperty): any;
export declare function awsMonitoringSubscriptionRealtimeMetricsSubscriptionConfigPropertyToHclTerraform(struct?: AwsMonitoringSubscription.RealtimeMetricsSubscriptionConfigPropertyOutputReference | AwsMonitoringSubscription.RealtimeMetricsSubscriptionConfigProperty): any;
export declare function awsMonitoringSubscriptionMonitoringSubscriptionPropertyToTerraform(struct?: AwsMonitoringSubscription.MonitoringSubscriptionPropertyOutputReference | AwsMonitoringSubscription.MonitoringSubscriptionProperty): any;
export declare function awsMonitoringSubscriptionMonitoringSubscriptionPropertyToHclTerraform(struct?: AwsMonitoringSubscription.MonitoringSubscriptionPropertyOutputReference | AwsMonitoringSubscription.MonitoringSubscriptionProperty): any;
export declare namespace AwsMonitoringSubscription {
    interface RealtimeMetricsSubscriptionConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_monitoring_subscription#realtime_metrics_subscription_status AwsMonitoringSubscription#realtime_metrics_subscription_status}
        */
        readonly realtimeMetricsSubscriptionStatus: string;
    }
    class RealtimeMetricsSubscriptionConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RealtimeMetricsSubscriptionConfigProperty | undefined;
        set internalValue(value: RealtimeMetricsSubscriptionConfigProperty | undefined);
        private _realtimeMetricsSubscriptionStatus?;
        get realtimeMetricsSubscriptionStatus(): string;
        set realtimeMetricsSubscriptionStatus(value: string);
        get realtimeMetricsSubscriptionStatusInput(): string | undefined;
    }
    interface MonitoringSubscriptionProperty {
        /**
        * realtime_metrics_subscription_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_monitoring_subscription#realtime_metrics_subscription_config AwsMonitoringSubscription#realtime_metrics_subscription_config}
        */
        readonly realtimeMetricsSubscriptionConfig: RealtimeMetricsSubscriptionConfigProperty;
    }
    class MonitoringSubscriptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MonitoringSubscriptionProperty | undefined;
        set internalValue(value: MonitoringSubscriptionProperty | undefined);
        private _realtimeMetricsSubscriptionConfig;
        get realtimeMetricsSubscriptionConfig(): RealtimeMetricsSubscriptionConfigPropertyOutputReference;
        putRealtimeMetricsSubscriptionConfig(value: RealtimeMetricsSubscriptionConfigProperty): void;
        get realtimeMetricsSubscriptionConfigInput(): RealtimeMetricsSubscriptionConfigProperty | undefined;
    }
}
