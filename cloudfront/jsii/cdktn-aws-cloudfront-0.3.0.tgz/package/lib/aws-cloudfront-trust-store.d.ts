import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsTrustStoreConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_trust_store#name AwsTrustStore#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_trust_store#tags AwsTrustStore#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * ca_certificates_bundle_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_trust_store#ca_certificates_bundle_source AwsTrustStore#ca_certificates_bundle_source}
    */
    readonly caCertificatesBundleSource?: AwsTrustStore.CaCertificatesBundleSourceProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_trust_store#timeouts AwsTrustStore#timeouts}
    */
    readonly timeouts?: AwsTrustStore.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_trust_store aws_cloudfront_trust_store}
*/
export declare class AwsTrustStore extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudfront_trust_store";
    /**
    * Generates CDKTN code for importing a AwsTrustStore resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsTrustStore to import
    * @param importFromId The id of the existing AwsTrustStore that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_trust_store#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsTrustStore to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_trust_store aws_cloudfront_trust_store} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsTrustStoreConfig
    */
    constructor(scope: Construct, id: string, config: AwsTrustStoreConfig);
    get arn(): string;
    get etag(): string;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get numberOfCaCertificates(): number;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _caCertificatesBundleSource;
    get caCertificatesBundleSource(): AwsTrustStore.CaCertificatesBundleSourcePropertyList;
    putCaCertificatesBundleSource(value: AwsTrustStore.CaCertificatesBundleSourceProperty[] | cdktn.IResolvable): void;
    resetCaCertificatesBundleSource(): void;
    get caCertificatesBundleSourceInput(): cdktn.IResolvable | AwsTrustStore.CaCertificatesBundleSourceProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsTrustStore.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsTrustStore.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsTrustStore.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsTrustStoreCaCertificatesBundleS3LocationPropertyToTerraform(struct?: AwsTrustStore.CaCertificatesBundleS3LocationProperty | cdktn.IResolvable): any;
export declare function awsTrustStoreCaCertificatesBundleS3LocationPropertyToHclTerraform(struct?: AwsTrustStore.CaCertificatesBundleS3LocationProperty | cdktn.IResolvable): any;
export declare function awsTrustStoreCaCertificatesBundleSourcePropertyToTerraform(struct?: AwsTrustStore.CaCertificatesBundleSourceProperty | cdktn.IResolvable): any;
export declare function awsTrustStoreCaCertificatesBundleSourcePropertyToHclTerraform(struct?: AwsTrustStore.CaCertificatesBundleSourceProperty | cdktn.IResolvable): any;
export declare function awsTrustStoreTimeoutsPropertyToTerraform(struct?: AwsTrustStore.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsTrustStoreTimeoutsPropertyToHclTerraform(struct?: AwsTrustStore.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsTrustStore {
    interface CaCertificatesBundleS3LocationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_trust_store#bucket AwsTrustStore#bucket}
        */
        readonly bucket: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_trust_store#key AwsTrustStore#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_trust_store#region AwsTrustStore#region}
        */
        readonly region: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_trust_store#version AwsTrustStore#version}
        */
        readonly version?: string;
    }
    class CaCertificatesBundleS3LocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CaCertificatesBundleS3LocationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CaCertificatesBundleS3LocationProperty | cdktn.IResolvable | undefined);
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        get bucketInput(): string | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _region?;
        get region(): string;
        set region(value: string);
        get regionInput(): string | undefined;
        private _version?;
        get version(): string;
        set version(value: string);
        resetVersion(): void;
        get versionInput(): string | undefined;
    }
    class CaCertificatesBundleS3LocationPropertyList extends cdktn.ComplexList {
        internalValue?: CaCertificatesBundleS3LocationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CaCertificatesBundleS3LocationPropertyOutputReference;
    }
    interface CaCertificatesBundleSourceProperty {
        /**
        * ca_certificates_bundle_s3_location block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_trust_store#ca_certificates_bundle_s3_location AwsTrustStore#ca_certificates_bundle_s3_location}
        */
        readonly caCertificatesBundleS3Location?: CaCertificatesBundleS3LocationProperty[] | cdktn.IResolvable;
    }
    class CaCertificatesBundleSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CaCertificatesBundleSourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CaCertificatesBundleSourceProperty | cdktn.IResolvable | undefined);
        private _caCertificatesBundleS3Location;
        get caCertificatesBundleS3Location(): CaCertificatesBundleS3LocationPropertyList;
        putCaCertificatesBundleS3Location(value: CaCertificatesBundleS3LocationProperty[] | cdktn.IResolvable): void;
        resetCaCertificatesBundleS3Location(): void;
        get caCertificatesBundleS3LocationInput(): cdktn.IResolvable | CaCertificatesBundleS3LocationProperty[] | undefined;
    }
    class CaCertificatesBundleSourcePropertyList extends cdktn.ComplexList {
        internalValue?: CaCertificatesBundleSourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CaCertificatesBundleSourcePropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_trust_store#create AwsTrustStore#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_trust_store#delete AwsTrustStore#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_trust_store#update AwsTrustStore#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
