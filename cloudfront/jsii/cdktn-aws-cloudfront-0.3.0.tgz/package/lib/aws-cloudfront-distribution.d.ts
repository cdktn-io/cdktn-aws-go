import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDistributionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#aliases AwsDistribution#aliases}
    */
    readonly aliases?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#anycast_ip_list_id AwsDistribution#anycast_ip_list_id}
    */
    readonly anycastIpListId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#comment AwsDistribution#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#continuous_deployment_policy_id AwsDistribution#continuous_deployment_policy_id}
    */
    readonly continuousDeploymentPolicyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#default_root_object AwsDistribution#default_root_object}
    */
    readonly defaultRootObject?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#enabled AwsDistribution#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#http_version AwsDistribution#http_version}
    */
    readonly httpVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#id AwsDistribution#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#is_ipv6_enabled AwsDistribution#is_ipv6_enabled}
    */
    readonly isIpv6Enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#price_class AwsDistribution#price_class}
    */
    readonly priceClass?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#retain_on_delete AwsDistribution#retain_on_delete}
    */
    readonly retainOnDelete?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#staging AwsDistribution#staging}
    */
    readonly staging?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#tags AwsDistribution#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#tags_all AwsDistribution#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#wait_for_deployment AwsDistribution#wait_for_deployment}
    */
    readonly waitForDeployment?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#web_acl_id AwsDistribution#web_acl_id}
    */
    readonly webAclId?: string;
    /**
    * cache_tag_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#cache_tag_config AwsDistribution#cache_tag_config}
    */
    readonly cacheTagConfig?: AwsDistribution.CacheTagConfigProperty;
    /**
    * connection_function_association block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#connection_function_association AwsDistribution#connection_function_association}
    */
    readonly connectionFunctionAssociation?: AwsDistribution.ConnectionFunctionAssociationProperty;
    /**
    * custom_error_response block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#custom_error_response AwsDistribution#custom_error_response}
    */
    readonly customErrorResponse?: AwsDistribution.CustomErrorResponseProperty[] | cdktn.IResolvable;
    /**
    * default_cache_behavior block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#default_cache_behavior AwsDistribution#default_cache_behavior}
    */
    readonly defaultCacheBehavior: AwsDistribution.DefaultCacheBehaviorProperty;
    /**
    * logging_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#logging_config AwsDistribution#logging_config}
    */
    readonly loggingConfig?: AwsDistribution.LoggingConfigProperty;
    /**
    * ordered_cache_behavior block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#ordered_cache_behavior AwsDistribution#ordered_cache_behavior}
    */
    readonly orderedCacheBehavior?: AwsDistribution.OrderedCacheBehaviorProperty[] | cdktn.IResolvable;
    /**
    * origin block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin AwsDistribution#origin}
    */
    readonly origin: AwsDistribution.OriginProperty[] | cdktn.IResolvable;
    /**
    * origin_group block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_group AwsDistribution#origin_group}
    */
    readonly originGroup?: AwsDistribution.OriginGroupProperty[] | cdktn.IResolvable;
    /**
    * restrictions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#restrictions AwsDistribution#restrictions}
    */
    readonly restrictions: AwsDistribution.RestrictionsProperty;
    /**
    * viewer_certificate block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#viewer_certificate AwsDistribution#viewer_certificate}
    */
    readonly viewerCertificate: AwsDistribution.ViewerCertificateProperty;
    /**
    * viewer_mtls_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#viewer_mtls_config AwsDistribution#viewer_mtls_config}
    */
    readonly viewerMtlsConfig?: AwsDistribution.ViewerMtlsConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution aws_cloudfront_distribution}
*/
export declare class AwsDistribution extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudfront_distribution";
    /**
    * Generates CDKTN code for importing a AwsDistribution resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDistribution to import
    * @param importFromId The id of the existing AwsDistribution that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDistribution to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution aws_cloudfront_distribution} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDistributionConfig
    */
    constructor(scope: Construct, id: string, config: AwsDistributionConfig);
    private _aliases?;
    get aliases(): string[];
    set aliases(value: string[]);
    resetAliases(): void;
    get aliasesInput(): string[] | undefined;
    private _anycastIpListId?;
    get anycastIpListId(): string;
    set anycastIpListId(value: string);
    resetAnycastIpListId(): void;
    get anycastIpListIdInput(): string | undefined;
    get arn(): string;
    get callerReference(): string;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _continuousDeploymentPolicyId?;
    get continuousDeploymentPolicyId(): string;
    set continuousDeploymentPolicyId(value: string);
    resetContinuousDeploymentPolicyId(): void;
    get continuousDeploymentPolicyIdInput(): string | undefined;
    private _defaultRootObject?;
    get defaultRootObject(): string;
    set defaultRootObject(value: string);
    resetDefaultRootObject(): void;
    get defaultRootObjectInput(): string | undefined;
    get domainName(): string;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get etag(): string;
    get hostedZoneId(): string;
    private _httpVersion?;
    get httpVersion(): string;
    set httpVersion(value: string);
    resetHttpVersion(): void;
    get httpVersionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get inProgressValidationBatches(): number;
    private _isIpv6Enabled?;
    get isIpv6Enabled(): boolean | cdktn.IResolvable;
    set isIpv6Enabled(value: boolean | cdktn.IResolvable);
    resetIsIpv6Enabled(): void;
    get isIpv6EnabledInput(): boolean | cdktn.IResolvable | undefined;
    get lastModifiedTime(): string;
    get loggingV1Enabled(): cdktn.IResolvable;
    private _priceClass?;
    get priceClass(): string;
    set priceClass(value: string);
    resetPriceClass(): void;
    get priceClassInput(): string | undefined;
    private _retainOnDelete?;
    get retainOnDelete(): boolean | cdktn.IResolvable;
    set retainOnDelete(value: boolean | cdktn.IResolvable);
    resetRetainOnDelete(): void;
    get retainOnDeleteInput(): boolean | cdktn.IResolvable | undefined;
    private _staging?;
    get staging(): boolean | cdktn.IResolvable;
    set staging(value: boolean | cdktn.IResolvable);
    resetStaging(): void;
    get stagingInput(): boolean | cdktn.IResolvable | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _trustedKeyGroups;
    get trustedKeyGroups(): AwsDistribution.TrustedKeyGroupsPropertyList;
    private _trustedSigners;
    get trustedSigners(): AwsDistribution.TrustedSignersPropertyList;
    private _waitForDeployment?;
    get waitForDeployment(): boolean | cdktn.IResolvable;
    set waitForDeployment(value: boolean | cdktn.IResolvable);
    resetWaitForDeployment(): void;
    get waitForDeploymentInput(): boolean | cdktn.IResolvable | undefined;
    private _webAclId?;
    get webAclId(): string;
    set webAclId(value: string);
    resetWebAclId(): void;
    get webAclIdInput(): string | undefined;
    private _cacheTagConfig;
    get cacheTagConfig(): AwsDistribution.CacheTagConfigPropertyOutputReference;
    putCacheTagConfig(value: AwsDistribution.CacheTagConfigProperty): void;
    resetCacheTagConfig(): void;
    get cacheTagConfigInput(): AwsDistribution.CacheTagConfigProperty | undefined;
    private _connectionFunctionAssociation;
    get connectionFunctionAssociation(): AwsDistribution.ConnectionFunctionAssociationPropertyOutputReference;
    putConnectionFunctionAssociation(value: AwsDistribution.ConnectionFunctionAssociationProperty): void;
    resetConnectionFunctionAssociation(): void;
    get connectionFunctionAssociationInput(): AwsDistribution.ConnectionFunctionAssociationProperty | undefined;
    private _customErrorResponse;
    get customErrorResponse(): AwsDistribution.CustomErrorResponsePropertyList;
    putCustomErrorResponse(value: AwsDistribution.CustomErrorResponseProperty[] | cdktn.IResolvable): void;
    resetCustomErrorResponse(): void;
    get customErrorResponseInput(): cdktn.IResolvable | AwsDistribution.CustomErrorResponseProperty[] | undefined;
    private _defaultCacheBehavior;
    get defaultCacheBehavior(): AwsDistribution.DefaultCacheBehaviorPropertyOutputReference;
    putDefaultCacheBehavior(value: AwsDistribution.DefaultCacheBehaviorProperty): void;
    get defaultCacheBehaviorInput(): AwsDistribution.DefaultCacheBehaviorProperty | undefined;
    private _loggingConfig;
    get loggingConfig(): AwsDistribution.LoggingConfigPropertyOutputReference;
    putLoggingConfig(value: AwsDistribution.LoggingConfigProperty): void;
    resetLoggingConfig(): void;
    get loggingConfigInput(): AwsDistribution.LoggingConfigProperty | undefined;
    private _orderedCacheBehavior;
    get orderedCacheBehavior(): AwsDistribution.OrderedCacheBehaviorPropertyList;
    putOrderedCacheBehavior(value: AwsDistribution.OrderedCacheBehaviorProperty[] | cdktn.IResolvable): void;
    resetOrderedCacheBehavior(): void;
    get orderedCacheBehaviorInput(): cdktn.IResolvable | AwsDistribution.OrderedCacheBehaviorProperty[] | undefined;
    private _origin;
    get origin(): AwsDistribution.OriginPropertyList;
    putOrigin(value: AwsDistribution.OriginProperty[] | cdktn.IResolvable): void;
    get originInput(): cdktn.IResolvable | AwsDistribution.OriginProperty[] | undefined;
    private _originGroup;
    get originGroup(): AwsDistribution.OriginGroupPropertyList;
    putOriginGroup(value: AwsDistribution.OriginGroupProperty[] | cdktn.IResolvable): void;
    resetOriginGroup(): void;
    get originGroupInput(): cdktn.IResolvable | AwsDistribution.OriginGroupProperty[] | undefined;
    private _restrictions;
    get restrictions(): AwsDistribution.RestrictionsPropertyOutputReference;
    putRestrictions(value: AwsDistribution.RestrictionsProperty): void;
    get restrictionsInput(): AwsDistribution.RestrictionsProperty | undefined;
    private _viewerCertificate;
    get viewerCertificate(): AwsDistribution.ViewerCertificatePropertyOutputReference;
    putViewerCertificate(value: AwsDistribution.ViewerCertificateProperty): void;
    get viewerCertificateInput(): AwsDistribution.ViewerCertificateProperty | undefined;
    private _viewerMtlsConfig;
    get viewerMtlsConfig(): AwsDistribution.ViewerMtlsConfigPropertyOutputReference;
    putViewerMtlsConfig(value: AwsDistribution.ViewerMtlsConfigProperty): void;
    resetViewerMtlsConfig(): void;
    get viewerMtlsConfigInput(): AwsDistribution.ViewerMtlsConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsDistributionTrustedKeyGroupsItemsPropertyToTerraform(struct?: AwsDistribution.TrustedKeyGroupsItemsProperty): any;
export declare function awsDistributionTrustedKeyGroupsItemsPropertyToHclTerraform(struct?: AwsDistribution.TrustedKeyGroupsItemsProperty): any;
export declare function awsDistributionTrustedKeyGroupsPropertyToTerraform(struct?: AwsDistribution.TrustedKeyGroupsProperty): any;
export declare function awsDistributionTrustedKeyGroupsPropertyToHclTerraform(struct?: AwsDistribution.TrustedKeyGroupsProperty): any;
export declare function awsDistributionTrustedSignersItemsPropertyToTerraform(struct?: AwsDistribution.TrustedSignersItemsProperty): any;
export declare function awsDistributionTrustedSignersItemsPropertyToHclTerraform(struct?: AwsDistribution.TrustedSignersItemsProperty): any;
export declare function awsDistributionTrustedSignersPropertyToTerraform(struct?: AwsDistribution.TrustedSignersProperty): any;
export declare function awsDistributionTrustedSignersPropertyToHclTerraform(struct?: AwsDistribution.TrustedSignersProperty): any;
export declare function awsDistributionCacheTagConfigPropertyToTerraform(struct?: AwsDistribution.CacheTagConfigPropertyOutputReference | AwsDistribution.CacheTagConfigProperty): any;
export declare function awsDistributionCacheTagConfigPropertyToHclTerraform(struct?: AwsDistribution.CacheTagConfigPropertyOutputReference | AwsDistribution.CacheTagConfigProperty): any;
export declare function awsDistributionConnectionFunctionAssociationPropertyToTerraform(struct?: AwsDistribution.ConnectionFunctionAssociationPropertyOutputReference | AwsDistribution.ConnectionFunctionAssociationProperty): any;
export declare function awsDistributionConnectionFunctionAssociationPropertyToHclTerraform(struct?: AwsDistribution.ConnectionFunctionAssociationPropertyOutputReference | AwsDistribution.ConnectionFunctionAssociationProperty): any;
export declare function awsDistributionCustomErrorResponsePropertyToTerraform(struct?: AwsDistribution.CustomErrorResponseProperty | cdktn.IResolvable): any;
export declare function awsDistributionCustomErrorResponsePropertyToHclTerraform(struct?: AwsDistribution.CustomErrorResponseProperty | cdktn.IResolvable): any;
export declare function awsDistributionDefaultCacheBehaviorForwardedValuesCookiesPropertyToTerraform(struct?: AwsDistribution.DefaultCacheBehaviorForwardedValuesCookiesPropertyOutputReference | AwsDistribution.DefaultCacheBehaviorForwardedValuesCookiesProperty): any;
export declare function awsDistributionDefaultCacheBehaviorForwardedValuesCookiesPropertyToHclTerraform(struct?: AwsDistribution.DefaultCacheBehaviorForwardedValuesCookiesPropertyOutputReference | AwsDistribution.DefaultCacheBehaviorForwardedValuesCookiesProperty): any;
export declare function awsDistributionDefaultCacheBehaviorForwardedValuesPropertyToTerraform(struct?: AwsDistribution.DefaultCacheBehaviorForwardedValuesPropertyOutputReference | AwsDistribution.DefaultCacheBehaviorForwardedValuesProperty): any;
export declare function awsDistributionDefaultCacheBehaviorForwardedValuesPropertyToHclTerraform(struct?: AwsDistribution.DefaultCacheBehaviorForwardedValuesPropertyOutputReference | AwsDistribution.DefaultCacheBehaviorForwardedValuesProperty): any;
export declare function awsDistributionDefaultCacheBehaviorFunctionAssociationPropertyToTerraform(struct?: AwsDistribution.DefaultCacheBehaviorFunctionAssociationProperty | cdktn.IResolvable): any;
export declare function awsDistributionDefaultCacheBehaviorFunctionAssociationPropertyToHclTerraform(struct?: AwsDistribution.DefaultCacheBehaviorFunctionAssociationProperty | cdktn.IResolvable): any;
export declare function awsDistributionDefaultCacheBehaviorGrpcConfigPropertyToTerraform(struct?: AwsDistribution.DefaultCacheBehaviorGrpcConfigPropertyOutputReference | AwsDistribution.DefaultCacheBehaviorGrpcConfigProperty): any;
export declare function awsDistributionDefaultCacheBehaviorGrpcConfigPropertyToHclTerraform(struct?: AwsDistribution.DefaultCacheBehaviorGrpcConfigPropertyOutputReference | AwsDistribution.DefaultCacheBehaviorGrpcConfigProperty): any;
export declare function awsDistributionDefaultCacheBehaviorLambdaFunctionAssociationPropertyToTerraform(struct?: AwsDistribution.DefaultCacheBehaviorLambdaFunctionAssociationProperty | cdktn.IResolvable): any;
export declare function awsDistributionDefaultCacheBehaviorLambdaFunctionAssociationPropertyToHclTerraform(struct?: AwsDistribution.DefaultCacheBehaviorLambdaFunctionAssociationProperty | cdktn.IResolvable): any;
export declare function awsDistributionDefaultCacheBehaviorPropertyToTerraform(struct?: AwsDistribution.DefaultCacheBehaviorPropertyOutputReference | AwsDistribution.DefaultCacheBehaviorProperty): any;
export declare function awsDistributionDefaultCacheBehaviorPropertyToHclTerraform(struct?: AwsDistribution.DefaultCacheBehaviorPropertyOutputReference | AwsDistribution.DefaultCacheBehaviorProperty): any;
export declare function awsDistributionLoggingConfigPropertyToTerraform(struct?: AwsDistribution.LoggingConfigPropertyOutputReference | AwsDistribution.LoggingConfigProperty): any;
export declare function awsDistributionLoggingConfigPropertyToHclTerraform(struct?: AwsDistribution.LoggingConfigPropertyOutputReference | AwsDistribution.LoggingConfigProperty): any;
export declare function awsDistributionOrderedCacheBehaviorForwardedValuesCookiesPropertyToTerraform(struct?: AwsDistribution.OrderedCacheBehaviorForwardedValuesCookiesPropertyOutputReference | AwsDistribution.OrderedCacheBehaviorForwardedValuesCookiesProperty): any;
export declare function awsDistributionOrderedCacheBehaviorForwardedValuesCookiesPropertyToHclTerraform(struct?: AwsDistribution.OrderedCacheBehaviorForwardedValuesCookiesPropertyOutputReference | AwsDistribution.OrderedCacheBehaviorForwardedValuesCookiesProperty): any;
export declare function awsDistributionOrderedCacheBehaviorForwardedValuesPropertyToTerraform(struct?: AwsDistribution.OrderedCacheBehaviorForwardedValuesPropertyOutputReference | AwsDistribution.OrderedCacheBehaviorForwardedValuesProperty): any;
export declare function awsDistributionOrderedCacheBehaviorForwardedValuesPropertyToHclTerraform(struct?: AwsDistribution.OrderedCacheBehaviorForwardedValuesPropertyOutputReference | AwsDistribution.OrderedCacheBehaviorForwardedValuesProperty): any;
export declare function awsDistributionOrderedCacheBehaviorFunctionAssociationPropertyToTerraform(struct?: AwsDistribution.OrderedCacheBehaviorFunctionAssociationProperty | cdktn.IResolvable): any;
export declare function awsDistributionOrderedCacheBehaviorFunctionAssociationPropertyToHclTerraform(struct?: AwsDistribution.OrderedCacheBehaviorFunctionAssociationProperty | cdktn.IResolvable): any;
export declare function awsDistributionOrderedCacheBehaviorGrpcConfigPropertyToTerraform(struct?: AwsDistribution.OrderedCacheBehaviorGrpcConfigPropertyOutputReference | AwsDistribution.OrderedCacheBehaviorGrpcConfigProperty): any;
export declare function awsDistributionOrderedCacheBehaviorGrpcConfigPropertyToHclTerraform(struct?: AwsDistribution.OrderedCacheBehaviorGrpcConfigPropertyOutputReference | AwsDistribution.OrderedCacheBehaviorGrpcConfigProperty): any;
export declare function awsDistributionOrderedCacheBehaviorLambdaFunctionAssociationPropertyToTerraform(struct?: AwsDistribution.OrderedCacheBehaviorLambdaFunctionAssociationProperty | cdktn.IResolvable): any;
export declare function awsDistributionOrderedCacheBehaviorLambdaFunctionAssociationPropertyToHclTerraform(struct?: AwsDistribution.OrderedCacheBehaviorLambdaFunctionAssociationProperty | cdktn.IResolvable): any;
export declare function awsDistributionOrderedCacheBehaviorPropertyToTerraform(struct?: AwsDistribution.OrderedCacheBehaviorProperty | cdktn.IResolvable): any;
export declare function awsDistributionOrderedCacheBehaviorPropertyToHclTerraform(struct?: AwsDistribution.OrderedCacheBehaviorProperty | cdktn.IResolvable): any;
export declare function awsDistributionCustomHeaderPropertyToTerraform(struct?: AwsDistribution.CustomHeaderProperty | cdktn.IResolvable): any;
export declare function awsDistributionCustomHeaderPropertyToHclTerraform(struct?: AwsDistribution.CustomHeaderProperty | cdktn.IResolvable): any;
export declare function awsDistributionOriginMtlsConfigPropertyToTerraform(struct?: AwsDistribution.OriginMtlsConfigPropertyOutputReference | AwsDistribution.OriginMtlsConfigProperty): any;
export declare function awsDistributionOriginMtlsConfigPropertyToHclTerraform(struct?: AwsDistribution.OriginMtlsConfigPropertyOutputReference | AwsDistribution.OriginMtlsConfigProperty): any;
export declare function awsDistributionCustomOriginConfigPropertyToTerraform(struct?: AwsDistribution.CustomOriginConfigPropertyOutputReference | AwsDistribution.CustomOriginConfigProperty): any;
export declare function awsDistributionCustomOriginConfigPropertyToHclTerraform(struct?: AwsDistribution.CustomOriginConfigPropertyOutputReference | AwsDistribution.CustomOriginConfigProperty): any;
export declare function awsDistributionOriginShieldPropertyToTerraform(struct?: AwsDistribution.OriginShieldPropertyOutputReference | AwsDistribution.OriginShieldProperty): any;
export declare function awsDistributionOriginShieldPropertyToHclTerraform(struct?: AwsDistribution.OriginShieldPropertyOutputReference | AwsDistribution.OriginShieldProperty): any;
export declare function awsDistributionS3OriginConfigPropertyToTerraform(struct?: AwsDistribution.S3OriginConfigPropertyOutputReference | AwsDistribution.S3OriginConfigProperty): any;
export declare function awsDistributionS3OriginConfigPropertyToHclTerraform(struct?: AwsDistribution.S3OriginConfigPropertyOutputReference | AwsDistribution.S3OriginConfigProperty): any;
export declare function awsDistributionVpcOriginConfigPropertyToTerraform(struct?: AwsDistribution.VpcOriginConfigPropertyOutputReference | AwsDistribution.VpcOriginConfigProperty): any;
export declare function awsDistributionVpcOriginConfigPropertyToHclTerraform(struct?: AwsDistribution.VpcOriginConfigPropertyOutputReference | AwsDistribution.VpcOriginConfigProperty): any;
export declare function awsDistributionOriginPropertyToTerraform(struct?: AwsDistribution.OriginProperty | cdktn.IResolvable): any;
export declare function awsDistributionOriginPropertyToHclTerraform(struct?: AwsDistribution.OriginProperty | cdktn.IResolvable): any;
export declare function awsDistributionFailoverCriteriaPropertyToTerraform(struct?: AwsDistribution.FailoverCriteriaPropertyOutputReference | AwsDistribution.FailoverCriteriaProperty): any;
export declare function awsDistributionFailoverCriteriaPropertyToHclTerraform(struct?: AwsDistribution.FailoverCriteriaPropertyOutputReference | AwsDistribution.FailoverCriteriaProperty): any;
export declare function awsDistributionMemberPropertyToTerraform(struct?: AwsDistribution.MemberProperty | cdktn.IResolvable): any;
export declare function awsDistributionMemberPropertyToHclTerraform(struct?: AwsDistribution.MemberProperty | cdktn.IResolvable): any;
export declare function awsDistributionOriginGroupPropertyToTerraform(struct?: AwsDistribution.OriginGroupProperty | cdktn.IResolvable): any;
export declare function awsDistributionOriginGroupPropertyToHclTerraform(struct?: AwsDistribution.OriginGroupProperty | cdktn.IResolvable): any;
export declare function awsDistributionGeoRestrictionPropertyToTerraform(struct?: AwsDistribution.GeoRestrictionPropertyOutputReference | AwsDistribution.GeoRestrictionProperty): any;
export declare function awsDistributionGeoRestrictionPropertyToHclTerraform(struct?: AwsDistribution.GeoRestrictionPropertyOutputReference | AwsDistribution.GeoRestrictionProperty): any;
export declare function awsDistributionRestrictionsPropertyToTerraform(struct?: AwsDistribution.RestrictionsPropertyOutputReference | AwsDistribution.RestrictionsProperty): any;
export declare function awsDistributionRestrictionsPropertyToHclTerraform(struct?: AwsDistribution.RestrictionsPropertyOutputReference | AwsDistribution.RestrictionsProperty): any;
export declare function awsDistributionViewerCertificatePropertyToTerraform(struct?: AwsDistribution.ViewerCertificatePropertyOutputReference | AwsDistribution.ViewerCertificateProperty): any;
export declare function awsDistributionViewerCertificatePropertyToHclTerraform(struct?: AwsDistribution.ViewerCertificatePropertyOutputReference | AwsDistribution.ViewerCertificateProperty): any;
export declare function awsDistributionTrustStoreConfigPropertyToTerraform(struct?: AwsDistribution.TrustStoreConfigPropertyOutputReference | AwsDistribution.TrustStoreConfigProperty): any;
export declare function awsDistributionTrustStoreConfigPropertyToHclTerraform(struct?: AwsDistribution.TrustStoreConfigPropertyOutputReference | AwsDistribution.TrustStoreConfigProperty): any;
export declare function awsDistributionViewerMtlsConfigPropertyToTerraform(struct?: AwsDistribution.ViewerMtlsConfigPropertyOutputReference | AwsDistribution.ViewerMtlsConfigProperty): any;
export declare function awsDistributionViewerMtlsConfigPropertyToHclTerraform(struct?: AwsDistribution.ViewerMtlsConfigPropertyOutputReference | AwsDistribution.ViewerMtlsConfigProperty): any;
export declare namespace AwsDistribution {
    interface TrustedKeyGroupsItemsProperty {
    }
    class TrustedKeyGroupsItemsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrustedKeyGroupsItemsProperty | undefined;
        set internalValue(value: TrustedKeyGroupsItemsProperty | undefined);
        get keyGroupId(): string;
        get keyPairIds(): string[];
    }
    class TrustedKeyGroupsItemsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrustedKeyGroupsItemsPropertyOutputReference;
    }
    interface TrustedKeyGroupsProperty {
    }
    class TrustedKeyGroupsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrustedKeyGroupsProperty | undefined;
        set internalValue(value: TrustedKeyGroupsProperty | undefined);
        get enabled(): cdktn.IResolvable;
        private _items;
        get items(): TrustedKeyGroupsItemsPropertyList;
    }
    class TrustedKeyGroupsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrustedKeyGroupsPropertyOutputReference;
    }
    interface TrustedSignersItemsProperty {
    }
    class TrustedSignersItemsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrustedSignersItemsProperty | undefined;
        set internalValue(value: TrustedSignersItemsProperty | undefined);
        get awsAccountNumber(): string;
        get keyPairIds(): string[];
    }
    class TrustedSignersItemsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrustedSignersItemsPropertyOutputReference;
    }
    interface TrustedSignersProperty {
    }
    class TrustedSignersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrustedSignersProperty | undefined;
        set internalValue(value: TrustedSignersProperty | undefined);
        get enabled(): cdktn.IResolvable;
        private _items;
        get items(): TrustedSignersItemsPropertyList;
    }
    class TrustedSignersPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrustedSignersPropertyOutputReference;
    }
    interface CacheTagConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#header_name AwsDistribution#header_name}
        */
        readonly headerName: string;
    }
    class CacheTagConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CacheTagConfigProperty | undefined;
        set internalValue(value: CacheTagConfigProperty | undefined);
        private _headerName?;
        get headerName(): string;
        set headerName(value: string);
        get headerNameInput(): string | undefined;
    }
    interface ConnectionFunctionAssociationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#id AwsDistribution#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id: string;
    }
    class ConnectionFunctionAssociationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConnectionFunctionAssociationProperty | undefined;
        set internalValue(value: ConnectionFunctionAssociationProperty | undefined);
        private _id?;
        get id(): string;
        set id(value: string);
        get idInput(): string | undefined;
    }
    interface CustomErrorResponseProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#error_caching_min_ttl AwsDistribution#error_caching_min_ttl}
        */
        readonly errorCachingMinTtl?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#error_code AwsDistribution#error_code}
        */
        readonly errorCode: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#response_code AwsDistribution#response_code}
        */
        readonly responseCode?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#response_page_path AwsDistribution#response_page_path}
        */
        readonly responsePagePath?: string;
    }
    class CustomErrorResponsePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomErrorResponseProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CustomErrorResponseProperty | cdktn.IResolvable | undefined);
        private _errorCachingMinTtl?;
        get errorCachingMinTtl(): number;
        set errorCachingMinTtl(value: number);
        resetErrorCachingMinTtl(): void;
        get errorCachingMinTtlInput(): number | undefined;
        private _errorCode?;
        get errorCode(): number;
        set errorCode(value: number);
        get errorCodeInput(): number | undefined;
        private _responseCode?;
        get responseCode(): number;
        set responseCode(value: number);
        resetResponseCode(): void;
        get responseCodeInput(): number | undefined;
        private _responsePagePath?;
        get responsePagePath(): string;
        set responsePagePath(value: string);
        resetResponsePagePath(): void;
        get responsePagePathInput(): string | undefined;
    }
    class CustomErrorResponsePropertyList extends cdktn.ComplexList {
        internalValue?: CustomErrorResponseProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomErrorResponsePropertyOutputReference;
    }
    interface DefaultCacheBehaviorForwardedValuesCookiesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#forward AwsDistribution#forward}
        */
        readonly forward: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#whitelisted_names AwsDistribution#whitelisted_names}
        */
        readonly whitelistedNames?: string[];
    }
    class DefaultCacheBehaviorForwardedValuesCookiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultCacheBehaviorForwardedValuesCookiesProperty | undefined;
        set internalValue(value: DefaultCacheBehaviorForwardedValuesCookiesProperty | undefined);
        private _forward?;
        get forward(): string;
        set forward(value: string);
        get forwardInput(): string | undefined;
        private _whitelistedNames?;
        get whitelistedNames(): string[];
        set whitelistedNames(value: string[]);
        resetWhitelistedNames(): void;
        get whitelistedNamesInput(): string[] | undefined;
    }
    interface DefaultCacheBehaviorForwardedValuesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#headers AwsDistribution#headers}
        */
        readonly headers?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#query_string AwsDistribution#query_string}
        */
        readonly queryString: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#query_string_cache_keys AwsDistribution#query_string_cache_keys}
        */
        readonly queryStringCacheKeys?: string[];
        /**
        * cookies block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#cookies AwsDistribution#cookies}
        */
        readonly cookies: DefaultCacheBehaviorForwardedValuesCookiesProperty;
    }
    class DefaultCacheBehaviorForwardedValuesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultCacheBehaviorForwardedValuesProperty | undefined;
        set internalValue(value: DefaultCacheBehaviorForwardedValuesProperty | undefined);
        private _headers?;
        get headers(): string[];
        set headers(value: string[]);
        resetHeaders(): void;
        get headersInput(): string[] | undefined;
        private _queryString?;
        get queryString(): boolean | cdktn.IResolvable;
        set queryString(value: boolean | cdktn.IResolvable);
        get queryStringInput(): boolean | cdktn.IResolvable | undefined;
        private _queryStringCacheKeys?;
        get queryStringCacheKeys(): string[];
        set queryStringCacheKeys(value: string[]);
        resetQueryStringCacheKeys(): void;
        get queryStringCacheKeysInput(): string[] | undefined;
        private _cookies;
        get cookies(): DefaultCacheBehaviorForwardedValuesCookiesPropertyOutputReference;
        putCookies(value: DefaultCacheBehaviorForwardedValuesCookiesProperty): void;
        get cookiesInput(): DefaultCacheBehaviorForwardedValuesCookiesProperty | undefined;
    }
    interface DefaultCacheBehaviorFunctionAssociationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#event_type AwsDistribution#event_type}
        */
        readonly eventType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#function_arn AwsDistribution#function_arn}
        */
        readonly functionArn: string;
    }
    class DefaultCacheBehaviorFunctionAssociationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefaultCacheBehaviorFunctionAssociationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefaultCacheBehaviorFunctionAssociationProperty | cdktn.IResolvable | undefined);
        private _eventType?;
        get eventType(): string;
        set eventType(value: string);
        get eventTypeInput(): string | undefined;
        private _functionArn?;
        get functionArn(): string;
        set functionArn(value: string);
        get functionArnInput(): string | undefined;
    }
    class DefaultCacheBehaviorFunctionAssociationPropertyList extends cdktn.ComplexList {
        internalValue?: DefaultCacheBehaviorFunctionAssociationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefaultCacheBehaviorFunctionAssociationPropertyOutputReference;
    }
    interface DefaultCacheBehaviorGrpcConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#enabled AwsDistribution#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
    }
    class DefaultCacheBehaviorGrpcConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultCacheBehaviorGrpcConfigProperty | undefined;
        set internalValue(value: DefaultCacheBehaviorGrpcConfigProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface DefaultCacheBehaviorLambdaFunctionAssociationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#event_type AwsDistribution#event_type}
        */
        readonly eventType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#include_body AwsDistribution#include_body}
        */
        readonly includeBody?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#lambda_arn AwsDistribution#lambda_arn}
        */
        readonly lambdaArn: string;
    }
    class DefaultCacheBehaviorLambdaFunctionAssociationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefaultCacheBehaviorLambdaFunctionAssociationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefaultCacheBehaviorLambdaFunctionAssociationProperty | cdktn.IResolvable | undefined);
        private _eventType?;
        get eventType(): string;
        set eventType(value: string);
        get eventTypeInput(): string | undefined;
        private _includeBody?;
        get includeBody(): boolean | cdktn.IResolvable;
        set includeBody(value: boolean | cdktn.IResolvable);
        resetIncludeBody(): void;
        get includeBodyInput(): boolean | cdktn.IResolvable | undefined;
        private _lambdaArn?;
        get lambdaArn(): string;
        set lambdaArn(value: string);
        get lambdaArnInput(): string | undefined;
    }
    class DefaultCacheBehaviorLambdaFunctionAssociationPropertyList extends cdktn.ComplexList {
        internalValue?: DefaultCacheBehaviorLambdaFunctionAssociationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefaultCacheBehaviorLambdaFunctionAssociationPropertyOutputReference;
    }
    interface DefaultCacheBehaviorProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#allowed_methods AwsDistribution#allowed_methods}
        */
        readonly allowedMethods: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#cache_policy_id AwsDistribution#cache_policy_id}
        */
        readonly cachePolicyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#cached_methods AwsDistribution#cached_methods}
        */
        readonly cachedMethods: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#compress AwsDistribution#compress}
        */
        readonly compress?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#default_ttl AwsDistribution#default_ttl}
        */
        readonly defaultTtl?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#field_level_encryption_id AwsDistribution#field_level_encryption_id}
        */
        readonly fieldLevelEncryptionId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#max_ttl AwsDistribution#max_ttl}
        */
        readonly maxTtl?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#min_ttl AwsDistribution#min_ttl}
        */
        readonly minTtl?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_request_policy_id AwsDistribution#origin_request_policy_id}
        */
        readonly originRequestPolicyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#realtime_log_config_arn AwsDistribution#realtime_log_config_arn}
        */
        readonly realtimeLogConfigArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#response_headers_policy_id AwsDistribution#response_headers_policy_id}
        */
        readonly responseHeadersPolicyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#smooth_streaming AwsDistribution#smooth_streaming}
        */
        readonly smoothStreaming?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#target_origin_id AwsDistribution#target_origin_id}
        */
        readonly targetOriginId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#trusted_key_groups AwsDistribution#trusted_key_groups}
        */
        readonly trustedKeyGroups?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#trusted_signers AwsDistribution#trusted_signers}
        */
        readonly trustedSigners?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#viewer_protocol_policy AwsDistribution#viewer_protocol_policy}
        */
        readonly viewerProtocolPolicy: string;
        /**
        * forwarded_values block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#forwarded_values AwsDistribution#forwarded_values}
        */
        readonly forwardedValues?: DefaultCacheBehaviorForwardedValuesProperty;
        /**
        * function_association block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#function_association AwsDistribution#function_association}
        */
        readonly functionAssociation?: DefaultCacheBehaviorFunctionAssociationProperty[] | cdktn.IResolvable;
        /**
        * grpc_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#grpc_config AwsDistribution#grpc_config}
        */
        readonly grpcConfig?: DefaultCacheBehaviorGrpcConfigProperty;
        /**
        * lambda_function_association block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#lambda_function_association AwsDistribution#lambda_function_association}
        */
        readonly lambdaFunctionAssociation?: DefaultCacheBehaviorLambdaFunctionAssociationProperty[] | cdktn.IResolvable;
    }
    class DefaultCacheBehaviorPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultCacheBehaviorProperty | undefined;
        set internalValue(value: DefaultCacheBehaviorProperty | undefined);
        private _allowedMethods?;
        get allowedMethods(): string[];
        set allowedMethods(value: string[]);
        get allowedMethodsInput(): string[] | undefined;
        private _cachePolicyId?;
        get cachePolicyId(): string;
        set cachePolicyId(value: string);
        resetCachePolicyId(): void;
        get cachePolicyIdInput(): string | undefined;
        private _cachedMethods?;
        get cachedMethods(): string[];
        set cachedMethods(value: string[]);
        get cachedMethodsInput(): string[] | undefined;
        private _compress?;
        get compress(): boolean | cdktn.IResolvable;
        set compress(value: boolean | cdktn.IResolvable);
        resetCompress(): void;
        get compressInput(): boolean | cdktn.IResolvable | undefined;
        private _defaultTtl?;
        get defaultTtl(): number;
        set defaultTtl(value: number);
        resetDefaultTtl(): void;
        get defaultTtlInput(): number | undefined;
        private _fieldLevelEncryptionId?;
        get fieldLevelEncryptionId(): string;
        set fieldLevelEncryptionId(value: string);
        resetFieldLevelEncryptionId(): void;
        get fieldLevelEncryptionIdInput(): string | undefined;
        private _maxTtl?;
        get maxTtl(): number;
        set maxTtl(value: number);
        resetMaxTtl(): void;
        get maxTtlInput(): number | undefined;
        private _minTtl?;
        get minTtl(): number;
        set minTtl(value: number);
        resetMinTtl(): void;
        get minTtlInput(): number | undefined;
        private _originRequestPolicyId?;
        get originRequestPolicyId(): string;
        set originRequestPolicyId(value: string);
        resetOriginRequestPolicyId(): void;
        get originRequestPolicyIdInput(): string | undefined;
        private _realtimeLogConfigArn?;
        get realtimeLogConfigArn(): string;
        set realtimeLogConfigArn(value: string);
        resetRealtimeLogConfigArn(): void;
        get realtimeLogConfigArnInput(): string | undefined;
        private _responseHeadersPolicyId?;
        get responseHeadersPolicyId(): string;
        set responseHeadersPolicyId(value: string);
        resetResponseHeadersPolicyId(): void;
        get responseHeadersPolicyIdInput(): string | undefined;
        private _smoothStreaming?;
        get smoothStreaming(): boolean | cdktn.IResolvable;
        set smoothStreaming(value: boolean | cdktn.IResolvable);
        resetSmoothStreaming(): void;
        get smoothStreamingInput(): boolean | cdktn.IResolvable | undefined;
        private _targetOriginId?;
        get targetOriginId(): string;
        set targetOriginId(value: string);
        get targetOriginIdInput(): string | undefined;
        private _trustedKeyGroups?;
        get trustedKeyGroups(): string[];
        set trustedKeyGroups(value: string[]);
        resetTrustedKeyGroups(): void;
        get trustedKeyGroupsInput(): string[] | undefined;
        private _trustedSigners?;
        get trustedSigners(): string[];
        set trustedSigners(value: string[]);
        resetTrustedSigners(): void;
        get trustedSignersInput(): string[] | undefined;
        private _viewerProtocolPolicy?;
        get viewerProtocolPolicy(): string;
        set viewerProtocolPolicy(value: string);
        get viewerProtocolPolicyInput(): string | undefined;
        private _forwardedValues;
        get forwardedValues(): DefaultCacheBehaviorForwardedValuesPropertyOutputReference;
        putForwardedValues(value: DefaultCacheBehaviorForwardedValuesProperty): void;
        resetForwardedValues(): void;
        get forwardedValuesInput(): DefaultCacheBehaviorForwardedValuesProperty | undefined;
        private _functionAssociation;
        get functionAssociation(): DefaultCacheBehaviorFunctionAssociationPropertyList;
        putFunctionAssociation(value: DefaultCacheBehaviorFunctionAssociationProperty[] | cdktn.IResolvable): void;
        resetFunctionAssociation(): void;
        get functionAssociationInput(): cdktn.IResolvable | DefaultCacheBehaviorFunctionAssociationProperty[] | undefined;
        private _grpcConfig;
        get grpcConfig(): DefaultCacheBehaviorGrpcConfigPropertyOutputReference;
        putGrpcConfig(value: DefaultCacheBehaviorGrpcConfigProperty): void;
        resetGrpcConfig(): void;
        get grpcConfigInput(): DefaultCacheBehaviorGrpcConfigProperty | undefined;
        private _lambdaFunctionAssociation;
        get lambdaFunctionAssociation(): DefaultCacheBehaviorLambdaFunctionAssociationPropertyList;
        putLambdaFunctionAssociation(value: DefaultCacheBehaviorLambdaFunctionAssociationProperty[] | cdktn.IResolvable): void;
        resetLambdaFunctionAssociation(): void;
        get lambdaFunctionAssociationInput(): cdktn.IResolvable | DefaultCacheBehaviorLambdaFunctionAssociationProperty[] | undefined;
    }
    interface LoggingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#bucket AwsDistribution#bucket}
        */
        readonly bucket?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#include_cookies AwsDistribution#include_cookies}
        */
        readonly includeCookies?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#prefix AwsDistribution#prefix}
        */
        readonly prefix?: string;
    }
    class LoggingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LoggingConfigProperty | undefined;
        set internalValue(value: LoggingConfigProperty | undefined);
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        resetBucket(): void;
        get bucketInput(): string | undefined;
        private _includeCookies?;
        get includeCookies(): boolean | cdktn.IResolvable;
        set includeCookies(value: boolean | cdktn.IResolvable);
        resetIncludeCookies(): void;
        get includeCookiesInput(): boolean | cdktn.IResolvable | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
    }
    interface OrderedCacheBehaviorForwardedValuesCookiesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#forward AwsDistribution#forward}
        */
        readonly forward: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#whitelisted_names AwsDistribution#whitelisted_names}
        */
        readonly whitelistedNames?: string[];
    }
    class OrderedCacheBehaviorForwardedValuesCookiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OrderedCacheBehaviorForwardedValuesCookiesProperty | undefined;
        set internalValue(value: OrderedCacheBehaviorForwardedValuesCookiesProperty | undefined);
        private _forward?;
        get forward(): string;
        set forward(value: string);
        get forwardInput(): string | undefined;
        private _whitelistedNames?;
        get whitelistedNames(): string[];
        set whitelistedNames(value: string[]);
        resetWhitelistedNames(): void;
        get whitelistedNamesInput(): string[] | undefined;
    }
    interface OrderedCacheBehaviorForwardedValuesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#headers AwsDistribution#headers}
        */
        readonly headers?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#query_string AwsDistribution#query_string}
        */
        readonly queryString: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#query_string_cache_keys AwsDistribution#query_string_cache_keys}
        */
        readonly queryStringCacheKeys?: string[];
        /**
        * cookies block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#cookies AwsDistribution#cookies}
        */
        readonly cookies: OrderedCacheBehaviorForwardedValuesCookiesProperty;
    }
    class OrderedCacheBehaviorForwardedValuesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OrderedCacheBehaviorForwardedValuesProperty | undefined;
        set internalValue(value: OrderedCacheBehaviorForwardedValuesProperty | undefined);
        private _headers?;
        get headers(): string[];
        set headers(value: string[]);
        resetHeaders(): void;
        get headersInput(): string[] | undefined;
        private _queryString?;
        get queryString(): boolean | cdktn.IResolvable;
        set queryString(value: boolean | cdktn.IResolvable);
        get queryStringInput(): boolean | cdktn.IResolvable | undefined;
        private _queryStringCacheKeys?;
        get queryStringCacheKeys(): string[];
        set queryStringCacheKeys(value: string[]);
        resetQueryStringCacheKeys(): void;
        get queryStringCacheKeysInput(): string[] | undefined;
        private _cookies;
        get cookies(): OrderedCacheBehaviorForwardedValuesCookiesPropertyOutputReference;
        putCookies(value: OrderedCacheBehaviorForwardedValuesCookiesProperty): void;
        get cookiesInput(): OrderedCacheBehaviorForwardedValuesCookiesProperty | undefined;
    }
    interface OrderedCacheBehaviorFunctionAssociationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#event_type AwsDistribution#event_type}
        */
        readonly eventType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#function_arn AwsDistribution#function_arn}
        */
        readonly functionArn: string;
    }
    class OrderedCacheBehaviorFunctionAssociationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OrderedCacheBehaviorFunctionAssociationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OrderedCacheBehaviorFunctionAssociationProperty | cdktn.IResolvable | undefined);
        private _eventType?;
        get eventType(): string;
        set eventType(value: string);
        get eventTypeInput(): string | undefined;
        private _functionArn?;
        get functionArn(): string;
        set functionArn(value: string);
        get functionArnInput(): string | undefined;
    }
    class OrderedCacheBehaviorFunctionAssociationPropertyList extends cdktn.ComplexList {
        internalValue?: OrderedCacheBehaviorFunctionAssociationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OrderedCacheBehaviorFunctionAssociationPropertyOutputReference;
    }
    interface OrderedCacheBehaviorGrpcConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#enabled AwsDistribution#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
    }
    class OrderedCacheBehaviorGrpcConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OrderedCacheBehaviorGrpcConfigProperty | undefined;
        set internalValue(value: OrderedCacheBehaviorGrpcConfigProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface OrderedCacheBehaviorLambdaFunctionAssociationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#event_type AwsDistribution#event_type}
        */
        readonly eventType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#include_body AwsDistribution#include_body}
        */
        readonly includeBody?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#lambda_arn AwsDistribution#lambda_arn}
        */
        readonly lambdaArn: string;
    }
    class OrderedCacheBehaviorLambdaFunctionAssociationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OrderedCacheBehaviorLambdaFunctionAssociationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OrderedCacheBehaviorLambdaFunctionAssociationProperty | cdktn.IResolvable | undefined);
        private _eventType?;
        get eventType(): string;
        set eventType(value: string);
        get eventTypeInput(): string | undefined;
        private _includeBody?;
        get includeBody(): boolean | cdktn.IResolvable;
        set includeBody(value: boolean | cdktn.IResolvable);
        resetIncludeBody(): void;
        get includeBodyInput(): boolean | cdktn.IResolvable | undefined;
        private _lambdaArn?;
        get lambdaArn(): string;
        set lambdaArn(value: string);
        get lambdaArnInput(): string | undefined;
    }
    class OrderedCacheBehaviorLambdaFunctionAssociationPropertyList extends cdktn.ComplexList {
        internalValue?: OrderedCacheBehaviorLambdaFunctionAssociationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OrderedCacheBehaviorLambdaFunctionAssociationPropertyOutputReference;
    }
    interface OrderedCacheBehaviorProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#allowed_methods AwsDistribution#allowed_methods}
        */
        readonly allowedMethods: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#cache_policy_id AwsDistribution#cache_policy_id}
        */
        readonly cachePolicyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#cached_methods AwsDistribution#cached_methods}
        */
        readonly cachedMethods: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#compress AwsDistribution#compress}
        */
        readonly compress?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#default_ttl AwsDistribution#default_ttl}
        */
        readonly defaultTtl?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#field_level_encryption_id AwsDistribution#field_level_encryption_id}
        */
        readonly fieldLevelEncryptionId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#max_ttl AwsDistribution#max_ttl}
        */
        readonly maxTtl?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#min_ttl AwsDistribution#min_ttl}
        */
        readonly minTtl?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_request_policy_id AwsDistribution#origin_request_policy_id}
        */
        readonly originRequestPolicyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#path_pattern AwsDistribution#path_pattern}
        */
        readonly pathPattern: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#realtime_log_config_arn AwsDistribution#realtime_log_config_arn}
        */
        readonly realtimeLogConfigArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#response_headers_policy_id AwsDistribution#response_headers_policy_id}
        */
        readonly responseHeadersPolicyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#smooth_streaming AwsDistribution#smooth_streaming}
        */
        readonly smoothStreaming?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#target_origin_id AwsDistribution#target_origin_id}
        */
        readonly targetOriginId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#trusted_key_groups AwsDistribution#trusted_key_groups}
        */
        readonly trustedKeyGroups?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#trusted_signers AwsDistribution#trusted_signers}
        */
        readonly trustedSigners?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#viewer_protocol_policy AwsDistribution#viewer_protocol_policy}
        */
        readonly viewerProtocolPolicy: string;
        /**
        * forwarded_values block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#forwarded_values AwsDistribution#forwarded_values}
        */
        readonly forwardedValues?: OrderedCacheBehaviorForwardedValuesProperty;
        /**
        * function_association block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#function_association AwsDistribution#function_association}
        */
        readonly functionAssociation?: OrderedCacheBehaviorFunctionAssociationProperty[] | cdktn.IResolvable;
        /**
        * grpc_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#grpc_config AwsDistribution#grpc_config}
        */
        readonly grpcConfig?: OrderedCacheBehaviorGrpcConfigProperty;
        /**
        * lambda_function_association block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#lambda_function_association AwsDistribution#lambda_function_association}
        */
        readonly lambdaFunctionAssociation?: OrderedCacheBehaviorLambdaFunctionAssociationProperty[] | cdktn.IResolvable;
    }
    class OrderedCacheBehaviorPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OrderedCacheBehaviorProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OrderedCacheBehaviorProperty | cdktn.IResolvable | undefined);
        private _allowedMethods?;
        get allowedMethods(): string[];
        set allowedMethods(value: string[]);
        get allowedMethodsInput(): string[] | undefined;
        private _cachePolicyId?;
        get cachePolicyId(): string;
        set cachePolicyId(value: string);
        resetCachePolicyId(): void;
        get cachePolicyIdInput(): string | undefined;
        private _cachedMethods?;
        get cachedMethods(): string[];
        set cachedMethods(value: string[]);
        get cachedMethodsInput(): string[] | undefined;
        private _compress?;
        get compress(): boolean | cdktn.IResolvable;
        set compress(value: boolean | cdktn.IResolvable);
        resetCompress(): void;
        get compressInput(): boolean | cdktn.IResolvable | undefined;
        private _defaultTtl?;
        get defaultTtl(): number;
        set defaultTtl(value: number);
        resetDefaultTtl(): void;
        get defaultTtlInput(): number | undefined;
        private _fieldLevelEncryptionId?;
        get fieldLevelEncryptionId(): string;
        set fieldLevelEncryptionId(value: string);
        resetFieldLevelEncryptionId(): void;
        get fieldLevelEncryptionIdInput(): string | undefined;
        private _maxTtl?;
        get maxTtl(): number;
        set maxTtl(value: number);
        resetMaxTtl(): void;
        get maxTtlInput(): number | undefined;
        private _minTtl?;
        get minTtl(): number;
        set minTtl(value: number);
        resetMinTtl(): void;
        get minTtlInput(): number | undefined;
        private _originRequestPolicyId?;
        get originRequestPolicyId(): string;
        set originRequestPolicyId(value: string);
        resetOriginRequestPolicyId(): void;
        get originRequestPolicyIdInput(): string | undefined;
        private _pathPattern?;
        get pathPattern(): string;
        set pathPattern(value: string);
        get pathPatternInput(): string | undefined;
        private _realtimeLogConfigArn?;
        get realtimeLogConfigArn(): string;
        set realtimeLogConfigArn(value: string);
        resetRealtimeLogConfigArn(): void;
        get realtimeLogConfigArnInput(): string | undefined;
        private _responseHeadersPolicyId?;
        get responseHeadersPolicyId(): string;
        set responseHeadersPolicyId(value: string);
        resetResponseHeadersPolicyId(): void;
        get responseHeadersPolicyIdInput(): string | undefined;
        private _smoothStreaming?;
        get smoothStreaming(): boolean | cdktn.IResolvable;
        set smoothStreaming(value: boolean | cdktn.IResolvable);
        resetSmoothStreaming(): void;
        get smoothStreamingInput(): boolean | cdktn.IResolvable | undefined;
        private _targetOriginId?;
        get targetOriginId(): string;
        set targetOriginId(value: string);
        get targetOriginIdInput(): string | undefined;
        private _trustedKeyGroups?;
        get trustedKeyGroups(): string[];
        set trustedKeyGroups(value: string[]);
        resetTrustedKeyGroups(): void;
        get trustedKeyGroupsInput(): string[] | undefined;
        private _trustedSigners?;
        get trustedSigners(): string[];
        set trustedSigners(value: string[]);
        resetTrustedSigners(): void;
        get trustedSignersInput(): string[] | undefined;
        private _viewerProtocolPolicy?;
        get viewerProtocolPolicy(): string;
        set viewerProtocolPolicy(value: string);
        get viewerProtocolPolicyInput(): string | undefined;
        private _forwardedValues;
        get forwardedValues(): OrderedCacheBehaviorForwardedValuesPropertyOutputReference;
        putForwardedValues(value: OrderedCacheBehaviorForwardedValuesProperty): void;
        resetForwardedValues(): void;
        get forwardedValuesInput(): OrderedCacheBehaviorForwardedValuesProperty | undefined;
        private _functionAssociation;
        get functionAssociation(): OrderedCacheBehaviorFunctionAssociationPropertyList;
        putFunctionAssociation(value: OrderedCacheBehaviorFunctionAssociationProperty[] | cdktn.IResolvable): void;
        resetFunctionAssociation(): void;
        get functionAssociationInput(): cdktn.IResolvable | OrderedCacheBehaviorFunctionAssociationProperty[] | undefined;
        private _grpcConfig;
        get grpcConfig(): OrderedCacheBehaviorGrpcConfigPropertyOutputReference;
        putGrpcConfig(value: OrderedCacheBehaviorGrpcConfigProperty): void;
        resetGrpcConfig(): void;
        get grpcConfigInput(): OrderedCacheBehaviorGrpcConfigProperty | undefined;
        private _lambdaFunctionAssociation;
        get lambdaFunctionAssociation(): OrderedCacheBehaviorLambdaFunctionAssociationPropertyList;
        putLambdaFunctionAssociation(value: OrderedCacheBehaviorLambdaFunctionAssociationProperty[] | cdktn.IResolvable): void;
        resetLambdaFunctionAssociation(): void;
        get lambdaFunctionAssociationInput(): cdktn.IResolvable | OrderedCacheBehaviorLambdaFunctionAssociationProperty[] | undefined;
    }
    class OrderedCacheBehaviorPropertyList extends cdktn.ComplexList {
        internalValue?: OrderedCacheBehaviorProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OrderedCacheBehaviorPropertyOutputReference;
    }
    interface CustomHeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#name AwsDistribution#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#value AwsDistribution#value}
        */
        readonly value: string;
    }
    class CustomHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomHeaderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CustomHeaderProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class CustomHeaderPropertyList extends cdktn.ComplexList {
        internalValue?: CustomHeaderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomHeaderPropertyOutputReference;
    }
    interface OriginMtlsConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#client_certificate_arn AwsDistribution#client_certificate_arn}
        */
        readonly clientCertificateArn: string;
    }
    class OriginMtlsConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OriginMtlsConfigProperty | undefined;
        set internalValue(value: OriginMtlsConfigProperty | undefined);
        private _clientCertificateArn?;
        get clientCertificateArn(): string;
        set clientCertificateArn(value: string);
        get clientCertificateArnInput(): string | undefined;
    }
    interface CustomOriginConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#http_port AwsDistribution#http_port}
        */
        readonly httpPort: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#https_port AwsDistribution#https_port}
        */
        readonly httpsPort: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#ip_address_type AwsDistribution#ip_address_type}
        */
        readonly ipAddressType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_keepalive_timeout AwsDistribution#origin_keepalive_timeout}
        */
        readonly originKeepaliveTimeout?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_protocol_policy AwsDistribution#origin_protocol_policy}
        */
        readonly originProtocolPolicy: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_read_timeout AwsDistribution#origin_read_timeout}
        */
        readonly originReadTimeout?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_ssl_protocols AwsDistribution#origin_ssl_protocols}
        */
        readonly originSslProtocols: string[];
        /**
        * origin_mtls_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_mtls_config AwsDistribution#origin_mtls_config}
        */
        readonly originMtlsConfig?: OriginMtlsConfigProperty;
    }
    class CustomOriginConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CustomOriginConfigProperty | undefined;
        set internalValue(value: CustomOriginConfigProperty | undefined);
        private _httpPort?;
        get httpPort(): number;
        set httpPort(value: number);
        get httpPortInput(): number | undefined;
        private _httpsPort?;
        get httpsPort(): number;
        set httpsPort(value: number);
        get httpsPortInput(): number | undefined;
        private _ipAddressType?;
        get ipAddressType(): string;
        set ipAddressType(value: string);
        resetIpAddressType(): void;
        get ipAddressTypeInput(): string | undefined;
        private _originKeepaliveTimeout?;
        get originKeepaliveTimeout(): number;
        set originKeepaliveTimeout(value: number);
        resetOriginKeepaliveTimeout(): void;
        get originKeepaliveTimeoutInput(): number | undefined;
        private _originProtocolPolicy?;
        get originProtocolPolicy(): string;
        set originProtocolPolicy(value: string);
        get originProtocolPolicyInput(): string | undefined;
        private _originReadTimeout?;
        get originReadTimeout(): number;
        set originReadTimeout(value: number);
        resetOriginReadTimeout(): void;
        get originReadTimeoutInput(): number | undefined;
        private _originSslProtocols?;
        get originSslProtocols(): string[];
        set originSslProtocols(value: string[]);
        get originSslProtocolsInput(): string[] | undefined;
        private _originMtlsConfig;
        get originMtlsConfig(): OriginMtlsConfigPropertyOutputReference;
        putOriginMtlsConfig(value: OriginMtlsConfigProperty): void;
        resetOriginMtlsConfig(): void;
        get originMtlsConfigInput(): OriginMtlsConfigProperty | undefined;
    }
    interface OriginShieldProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#enabled AwsDistribution#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_shield_region AwsDistribution#origin_shield_region}
        */
        readonly originShieldRegion?: string;
    }
    class OriginShieldPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OriginShieldProperty | undefined;
        set internalValue(value: OriginShieldProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _originShieldRegion?;
        get originShieldRegion(): string;
        set originShieldRegion(value: string);
        resetOriginShieldRegion(): void;
        get originShieldRegionInput(): string | undefined;
    }
    interface S3OriginConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_access_identity AwsDistribution#origin_access_identity}
        */
        readonly originAccessIdentity: string;
    }
    class S3OriginConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3OriginConfigProperty | undefined;
        set internalValue(value: S3OriginConfigProperty | undefined);
        private _originAccessIdentity?;
        get originAccessIdentity(): string;
        set originAccessIdentity(value: string);
        get originAccessIdentityInput(): string | undefined;
    }
    interface VpcOriginConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_keepalive_timeout AwsDistribution#origin_keepalive_timeout}
        */
        readonly originKeepaliveTimeout?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_read_timeout AwsDistribution#origin_read_timeout}
        */
        readonly originReadTimeout?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#owner_account_id AwsDistribution#owner_account_id}
        */
        readonly ownerAccountId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#vpc_origin_id AwsDistribution#vpc_origin_id}
        */
        readonly vpcOriginId: string;
    }
    class VpcOriginConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VpcOriginConfigProperty | undefined;
        set internalValue(value: VpcOriginConfigProperty | undefined);
        private _originKeepaliveTimeout?;
        get originKeepaliveTimeout(): number;
        set originKeepaliveTimeout(value: number);
        resetOriginKeepaliveTimeout(): void;
        get originKeepaliveTimeoutInput(): number | undefined;
        private _originReadTimeout?;
        get originReadTimeout(): number;
        set originReadTimeout(value: number);
        resetOriginReadTimeout(): void;
        get originReadTimeoutInput(): number | undefined;
        private _ownerAccountId?;
        get ownerAccountId(): string;
        set ownerAccountId(value: string);
        resetOwnerAccountId(): void;
        get ownerAccountIdInput(): string | undefined;
        private _vpcOriginId?;
        get vpcOriginId(): string;
        set vpcOriginId(value: string);
        get vpcOriginIdInput(): string | undefined;
    }
    interface OriginProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#connection_attempts AwsDistribution#connection_attempts}
        */
        readonly connectionAttempts?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#connection_timeout AwsDistribution#connection_timeout}
        */
        readonly connectionTimeout?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#domain_name AwsDistribution#domain_name}
        */
        readonly domainName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_access_control_id AwsDistribution#origin_access_control_id}
        */
        readonly originAccessControlId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_id AwsDistribution#origin_id}
        */
        readonly originId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_path AwsDistribution#origin_path}
        */
        readonly originPath?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#response_completion_timeout AwsDistribution#response_completion_timeout}
        */
        readonly responseCompletionTimeout?: number;
        /**
        * custom_header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#custom_header AwsDistribution#custom_header}
        */
        readonly customHeader?: CustomHeaderProperty[] | cdktn.IResolvable;
        /**
        * custom_origin_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#custom_origin_config AwsDistribution#custom_origin_config}
        */
        readonly customOriginConfig?: CustomOriginConfigProperty;
        /**
        * origin_shield block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_shield AwsDistribution#origin_shield}
        */
        readonly originShield?: OriginShieldProperty;
        /**
        * s3_origin_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#s3_origin_config AwsDistribution#s3_origin_config}
        */
        readonly s3OriginConfig?: S3OriginConfigProperty;
        /**
        * vpc_origin_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#vpc_origin_config AwsDistribution#vpc_origin_config}
        */
        readonly vpcOriginConfig?: VpcOriginConfigProperty;
    }
    class OriginPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OriginProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OriginProperty | cdktn.IResolvable | undefined);
        private _connectionAttempts?;
        get connectionAttempts(): number;
        set connectionAttempts(value: number);
        resetConnectionAttempts(): void;
        get connectionAttemptsInput(): number | undefined;
        private _connectionTimeout?;
        get connectionTimeout(): number;
        set connectionTimeout(value: number);
        resetConnectionTimeout(): void;
        get connectionTimeoutInput(): number | undefined;
        private _domainName?;
        get domainName(): string;
        set domainName(value: string);
        get domainNameInput(): string | undefined;
        private _originAccessControlId?;
        get originAccessControlId(): string;
        set originAccessControlId(value: string);
        resetOriginAccessControlId(): void;
        get originAccessControlIdInput(): string | undefined;
        private _originId?;
        get originId(): string;
        set originId(value: string);
        get originIdInput(): string | undefined;
        private _originPath?;
        get originPath(): string;
        set originPath(value: string);
        resetOriginPath(): void;
        get originPathInput(): string | undefined;
        private _responseCompletionTimeout?;
        get responseCompletionTimeout(): number;
        set responseCompletionTimeout(value: number);
        resetResponseCompletionTimeout(): void;
        get responseCompletionTimeoutInput(): number | undefined;
        private _customHeader;
        get customHeader(): CustomHeaderPropertyList;
        putCustomHeader(value: CustomHeaderProperty[] | cdktn.IResolvable): void;
        resetCustomHeader(): void;
        get customHeaderInput(): cdktn.IResolvable | CustomHeaderProperty[] | undefined;
        private _customOriginConfig;
        get customOriginConfig(): CustomOriginConfigPropertyOutputReference;
        putCustomOriginConfig(value: CustomOriginConfigProperty): void;
        resetCustomOriginConfig(): void;
        get customOriginConfigInput(): CustomOriginConfigProperty | undefined;
        private _originShield;
        get originShield(): OriginShieldPropertyOutputReference;
        putOriginShield(value: OriginShieldProperty): void;
        resetOriginShield(): void;
        get originShieldInput(): OriginShieldProperty | undefined;
        private _s3OriginConfig;
        get s3OriginConfig(): S3OriginConfigPropertyOutputReference;
        putS3OriginConfig(value: S3OriginConfigProperty): void;
        resetS3OriginConfig(): void;
        get s3OriginConfigInput(): S3OriginConfigProperty | undefined;
        private _vpcOriginConfig;
        get vpcOriginConfig(): VpcOriginConfigPropertyOutputReference;
        putVpcOriginConfig(value: VpcOriginConfigProperty): void;
        resetVpcOriginConfig(): void;
        get vpcOriginConfigInput(): VpcOriginConfigProperty | undefined;
    }
    class OriginPropertyList extends cdktn.ComplexList {
        internalValue?: OriginProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OriginPropertyOutputReference;
    }
    interface FailoverCriteriaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#status_codes AwsDistribution#status_codes}
        */
        readonly statusCodes: number[];
    }
    class FailoverCriteriaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FailoverCriteriaProperty | undefined;
        set internalValue(value: FailoverCriteriaProperty | undefined);
        private _statusCodes?;
        get statusCodes(): number[];
        set statusCodes(value: number[]);
        get statusCodesInput(): number[] | undefined;
    }
    interface MemberProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_id AwsDistribution#origin_id}
        */
        readonly originId: string;
    }
    class MemberPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MemberProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MemberProperty | cdktn.IResolvable | undefined);
        private _originId?;
        get originId(): string;
        set originId(value: string);
        get originIdInput(): string | undefined;
    }
    class MemberPropertyList extends cdktn.ComplexList {
        internalValue?: MemberProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MemberPropertyOutputReference;
    }
    interface OriginGroupProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_id AwsDistribution#origin_id}
        */
        readonly originId: string;
        /**
        * failover_criteria block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#failover_criteria AwsDistribution#failover_criteria}
        */
        readonly failoverCriteria: FailoverCriteriaProperty;
        /**
        * member block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#member AwsDistribution#member}
        */
        readonly member: MemberProperty[] | cdktn.IResolvable;
    }
    class OriginGroupPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OriginGroupProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OriginGroupProperty | cdktn.IResolvable | undefined);
        private _originId?;
        get originId(): string;
        set originId(value: string);
        get originIdInput(): string | undefined;
        private _failoverCriteria;
        get failoverCriteria(): FailoverCriteriaPropertyOutputReference;
        putFailoverCriteria(value: FailoverCriteriaProperty): void;
        get failoverCriteriaInput(): FailoverCriteriaProperty | undefined;
        private _member;
        get member(): MemberPropertyList;
        putMember(value: MemberProperty[] | cdktn.IResolvable): void;
        get memberInput(): cdktn.IResolvable | MemberProperty[] | undefined;
    }
    class OriginGroupPropertyList extends cdktn.ComplexList {
        internalValue?: OriginGroupProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OriginGroupPropertyOutputReference;
    }
    interface GeoRestrictionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#locations AwsDistribution#locations}
        */
        readonly locations?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#restriction_type AwsDistribution#restriction_type}
        */
        readonly restrictionType: string;
    }
    class GeoRestrictionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): GeoRestrictionProperty | undefined;
        set internalValue(value: GeoRestrictionProperty | undefined);
        private _locations?;
        get locations(): string[];
        set locations(value: string[]);
        resetLocations(): void;
        get locationsInput(): string[] | undefined;
        private _restrictionType?;
        get restrictionType(): string;
        set restrictionType(value: string);
        get restrictionTypeInput(): string | undefined;
    }
    interface RestrictionsProperty {
        /**
        * geo_restriction block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#geo_restriction AwsDistribution#geo_restriction}
        */
        readonly geoRestriction: GeoRestrictionProperty;
    }
    class RestrictionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RestrictionsProperty | undefined;
        set internalValue(value: RestrictionsProperty | undefined);
        private _geoRestriction;
        get geoRestriction(): GeoRestrictionPropertyOutputReference;
        putGeoRestriction(value: GeoRestrictionProperty): void;
        get geoRestrictionInput(): GeoRestrictionProperty | undefined;
    }
    interface ViewerCertificateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#acm_certificate_arn AwsDistribution#acm_certificate_arn}
        */
        readonly acmCertificateArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#cloudfront_default_certificate AwsDistribution#cloudfront_default_certificate}
        */
        readonly cloudfrontDefaultCertificate?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#iam_certificate_id AwsDistribution#iam_certificate_id}
        */
        readonly iamCertificateId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#minimum_protocol_version AwsDistribution#minimum_protocol_version}
        */
        readonly minimumProtocolVersion?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#ssl_support_method AwsDistribution#ssl_support_method}
        */
        readonly sslSupportMethod?: string;
    }
    class ViewerCertificatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ViewerCertificateProperty | undefined;
        set internalValue(value: ViewerCertificateProperty | undefined);
        private _acmCertificateArn?;
        get acmCertificateArn(): string;
        set acmCertificateArn(value: string);
        resetAcmCertificateArn(): void;
        get acmCertificateArnInput(): string | undefined;
        private _cloudfrontDefaultCertificate?;
        get cloudfrontDefaultCertificate(): boolean | cdktn.IResolvable;
        set cloudfrontDefaultCertificate(value: boolean | cdktn.IResolvable);
        resetCloudfrontDefaultCertificate(): void;
        get cloudfrontDefaultCertificateInput(): boolean | cdktn.IResolvable | undefined;
        private _iamCertificateId?;
        get iamCertificateId(): string;
        set iamCertificateId(value: string);
        resetIamCertificateId(): void;
        get iamCertificateIdInput(): string | undefined;
        private _minimumProtocolVersion?;
        get minimumProtocolVersion(): string;
        set minimumProtocolVersion(value: string);
        resetMinimumProtocolVersion(): void;
        get minimumProtocolVersionInput(): string | undefined;
        private _sslSupportMethod?;
        get sslSupportMethod(): string;
        set sslSupportMethod(value: string);
        resetSslSupportMethod(): void;
        get sslSupportMethodInput(): string | undefined;
    }
    interface TrustStoreConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#advertise_trust_store_ca_names AwsDistribution#advertise_trust_store_ca_names}
        */
        readonly advertiseTrustStoreCaNames?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#ignore_certificate_expiry AwsDistribution#ignore_certificate_expiry}
        */
        readonly ignoreCertificateExpiry?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#trust_store_id AwsDistribution#trust_store_id}
        */
        readonly trustStoreId: string;
    }
    class TrustStoreConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TrustStoreConfigProperty | undefined;
        set internalValue(value: TrustStoreConfigProperty | undefined);
        private _advertiseTrustStoreCaNames?;
        get advertiseTrustStoreCaNames(): boolean | cdktn.IResolvable;
        set advertiseTrustStoreCaNames(value: boolean | cdktn.IResolvable);
        resetAdvertiseTrustStoreCaNames(): void;
        get advertiseTrustStoreCaNamesInput(): boolean | cdktn.IResolvable | undefined;
        private _ignoreCertificateExpiry?;
        get ignoreCertificateExpiry(): boolean | cdktn.IResolvable;
        set ignoreCertificateExpiry(value: boolean | cdktn.IResolvable);
        resetIgnoreCertificateExpiry(): void;
        get ignoreCertificateExpiryInput(): boolean | cdktn.IResolvable | undefined;
        private _trustStoreId?;
        get trustStoreId(): string;
        set trustStoreId(value: string);
        get trustStoreIdInput(): string | undefined;
    }
    interface ViewerMtlsConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#mode AwsDistribution#mode}
        */
        readonly mode?: string;
        /**
        * trust_store_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#trust_store_config AwsDistribution#trust_store_config}
        */
        readonly trustStoreConfig?: TrustStoreConfigProperty;
    }
    class ViewerMtlsConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ViewerMtlsConfigProperty | undefined;
        set internalValue(value: ViewerMtlsConfigProperty | undefined);
        private _mode?;
        get mode(): string;
        set mode(value: string);
        resetMode(): void;
        get modeInput(): string | undefined;
        private _trustStoreConfig;
        get trustStoreConfig(): TrustStoreConfigPropertyOutputReference;
        putTrustStoreConfig(value: TrustStoreConfigProperty): void;
        resetTrustStoreConfig(): void;
        get trustStoreConfigInput(): TrustStoreConfigProperty | undefined;
    }
}
