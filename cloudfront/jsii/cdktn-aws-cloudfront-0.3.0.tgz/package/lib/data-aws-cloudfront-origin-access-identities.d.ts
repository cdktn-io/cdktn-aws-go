import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsOriginAccessIdentitiesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudfront_origin_access_identities#comments DataAwsOriginAccessIdentities#comments}
    */
    readonly comments?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudfront_origin_access_identities#id DataAwsOriginAccessIdentities#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudfront_origin_access_identities aws_cloudfront_origin_access_identities}
*/
export declare class DataAwsOriginAccessIdentities extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_cloudfront_origin_access_identities";
    /**
    * Generates CDKTN code for importing a DataAwsOriginAccessIdentities resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsOriginAccessIdentities to import
    * @param importFromId The id of the existing DataAwsOriginAccessIdentities that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudfront_origin_access_identities#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsOriginAccessIdentities to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudfront_origin_access_identities aws_cloudfront_origin_access_identities} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsOriginAccessIdentitiesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsOriginAccessIdentitiesConfig);
    private _comments?;
    get comments(): string[];
    set comments(value: string[]);
    resetComments(): void;
    get commentsInput(): string[] | undefined;
    get iamArns(): string[];
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get ids(): string[];
    get s3CanonicalUserIds(): string[];
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
