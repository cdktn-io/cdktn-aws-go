import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsFieldLevelEncryptionProfileConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_field_level_encryption_profile#comment AwsFieldLevelEncryptionProfile#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_field_level_encryption_profile#id AwsFieldLevelEncryptionProfile#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_field_level_encryption_profile#name AwsFieldLevelEncryptionProfile#name}
    */
    readonly name: string;
    /**
    * encryption_entities block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_field_level_encryption_profile#encryption_entities AwsFieldLevelEncryptionProfile#encryption_entities}
    */
    readonly encryptionEntities: AwsFieldLevelEncryptionProfile.EncryptionEntitiesProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_field_level_encryption_profile aws_cloudfront_field_level_encryption_profile}
*/
export declare class AwsFieldLevelEncryptionProfile extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudfront_field_level_encryption_profile";
    /**
    * Generates CDKTN code for importing a AwsFieldLevelEncryptionProfile resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsFieldLevelEncryptionProfile to import
    * @param importFromId The id of the existing AwsFieldLevelEncryptionProfile that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_field_level_encryption_profile#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsFieldLevelEncryptionProfile to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_field_level_encryption_profile aws_cloudfront_field_level_encryption_profile} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsFieldLevelEncryptionProfileConfig
    */
    constructor(scope: Construct, id: string, config: AwsFieldLevelEncryptionProfileConfig);
    get arn(): string;
    get callerReference(): string;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    get etag(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _encryptionEntities;
    get encryptionEntities(): AwsFieldLevelEncryptionProfile.EncryptionEntitiesPropertyOutputReference;
    putEncryptionEntities(value: AwsFieldLevelEncryptionProfile.EncryptionEntitiesProperty): void;
    get encryptionEntitiesInput(): AwsFieldLevelEncryptionProfile.EncryptionEntitiesProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsFieldLevelEncryptionProfileFieldPatternsPropertyToTerraform(struct?: AwsFieldLevelEncryptionProfile.FieldPatternsPropertyOutputReference | AwsFieldLevelEncryptionProfile.FieldPatternsProperty): any;
export declare function awsFieldLevelEncryptionProfileFieldPatternsPropertyToHclTerraform(struct?: AwsFieldLevelEncryptionProfile.FieldPatternsPropertyOutputReference | AwsFieldLevelEncryptionProfile.FieldPatternsProperty): any;
export declare function awsFieldLevelEncryptionProfileItemsPropertyToTerraform(struct?: AwsFieldLevelEncryptionProfile.ItemsProperty | cdktn.IResolvable): any;
export declare function awsFieldLevelEncryptionProfileItemsPropertyToHclTerraform(struct?: AwsFieldLevelEncryptionProfile.ItemsProperty | cdktn.IResolvable): any;
export declare function awsFieldLevelEncryptionProfileEncryptionEntitiesPropertyToTerraform(struct?: AwsFieldLevelEncryptionProfile.EncryptionEntitiesPropertyOutputReference | AwsFieldLevelEncryptionProfile.EncryptionEntitiesProperty): any;
export declare function awsFieldLevelEncryptionProfileEncryptionEntitiesPropertyToHclTerraform(struct?: AwsFieldLevelEncryptionProfile.EncryptionEntitiesPropertyOutputReference | AwsFieldLevelEncryptionProfile.EncryptionEntitiesProperty): any;
export declare namespace AwsFieldLevelEncryptionProfile {
    interface FieldPatternsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_field_level_encryption_profile#items AwsFieldLevelEncryptionProfile#items}
        */
        readonly items?: string[];
    }
    class FieldPatternsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FieldPatternsProperty | undefined;
        set internalValue(value: FieldPatternsProperty | undefined);
        private _items?;
        get items(): string[];
        set items(value: string[]);
        resetItems(): void;
        get itemsInput(): string[] | undefined;
    }
    interface ItemsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_field_level_encryption_profile#provider_id AwsFieldLevelEncryptionProfile#provider_id}
        */
        readonly providerId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_field_level_encryption_profile#public_key_id AwsFieldLevelEncryptionProfile#public_key_id}
        */
        readonly publicKeyId: string;
        /**
        * field_patterns block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_field_level_encryption_profile#field_patterns AwsFieldLevelEncryptionProfile#field_patterns}
        */
        readonly fieldPatterns: FieldPatternsProperty;
    }
    class ItemsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ItemsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ItemsProperty | cdktn.IResolvable | undefined);
        private _providerId?;
        get providerId(): string;
        set providerId(value: string);
        get providerIdInput(): string | undefined;
        private _publicKeyId?;
        get publicKeyId(): string;
        set publicKeyId(value: string);
        get publicKeyIdInput(): string | undefined;
        private _fieldPatterns;
        get fieldPatterns(): FieldPatternsPropertyOutputReference;
        putFieldPatterns(value: FieldPatternsProperty): void;
        get fieldPatternsInput(): FieldPatternsProperty | undefined;
    }
    class ItemsPropertyList extends cdktn.ComplexList {
        internalValue?: ItemsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ItemsPropertyOutputReference;
    }
    interface EncryptionEntitiesProperty {
        /**
        * items block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_field_level_encryption_profile#items AwsFieldLevelEncryptionProfile#items}
        */
        readonly items?: ItemsProperty[] | cdktn.IResolvable;
    }
    class EncryptionEntitiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncryptionEntitiesProperty | undefined;
        set internalValue(value: EncryptionEntitiesProperty | undefined);
        private _items;
        get items(): ItemsPropertyList;
        putItems(value: ItemsProperty[] | cdktn.IResolvable): void;
        resetItems(): void;
        get itemsInput(): cdktn.IResolvable | ItemsProperty[] | undefined;
    }
}
