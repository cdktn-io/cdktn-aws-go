import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsOriginAccessControlConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_access_control#description AwsOriginAccessControl#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_access_control#id AwsOriginAccessControl#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_access_control#name AwsOriginAccessControl#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_access_control#origin_access_control_origin_type AwsOriginAccessControl#origin_access_control_origin_type}
    */
    readonly originAccessControlOriginType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_access_control#signing_behavior AwsOriginAccessControl#signing_behavior}
    */
    readonly signingBehavior: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_access_control#signing_protocol AwsOriginAccessControl#signing_protocol}
    */
    readonly signingProtocol: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_access_control aws_cloudfront_origin_access_control}
*/
export declare class AwsOriginAccessControl extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudfront_origin_access_control";
    /**
    * Generates CDKTN code for importing a AwsOriginAccessControl resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsOriginAccessControl to import
    * @param importFromId The id of the existing AwsOriginAccessControl that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_access_control#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsOriginAccessControl to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_access_control aws_cloudfront_origin_access_control} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsOriginAccessControlConfig
    */
    constructor(scope: Construct, id: string, config: AwsOriginAccessControlConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get etag(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _originAccessControlOriginType?;
    get originAccessControlOriginType(): string;
    set originAccessControlOriginType(value: string);
    get originAccessControlOriginTypeInput(): string | undefined;
    private _signingBehavior?;
    get signingBehavior(): string;
    set signingBehavior(value: string);
    get signingBehaviorInput(): string | undefined;
    private _signingProtocol?;
    get signingProtocol(): string;
    set signingProtocol(value: string);
    get signingProtocolInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
