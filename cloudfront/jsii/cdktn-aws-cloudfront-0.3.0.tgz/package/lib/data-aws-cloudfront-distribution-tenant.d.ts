import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsDistributionTenantConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudfront_distribution_tenant#arn DataAwsDistributionTenant#arn}
    */
    readonly arn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudfront_distribution_tenant#domain DataAwsDistributionTenant#domain}
    */
    readonly domain?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudfront_distribution_tenant#id DataAwsDistributionTenant#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudfront_distribution_tenant#name DataAwsDistributionTenant#name}
    */
    readonly name?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudfront_distribution_tenant aws_cloudfront_distribution_tenant}
*/
export declare class DataAwsDistributionTenant extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_cloudfront_distribution_tenant";
    /**
    * Generates CDKTN code for importing a DataAwsDistributionTenant resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsDistributionTenant to import
    * @param importFromId The id of the existing DataAwsDistributionTenant that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudfront_distribution_tenant#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsDistributionTenant to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudfront_distribution_tenant aws_cloudfront_distribution_tenant} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsDistributionTenantConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsDistributionTenantConfig);
    private _arn?;
    get arn(): string;
    set arn(value: string);
    resetArn(): void;
    get arnInput(): string | undefined;
    get connectionGroupId(): string;
    private _customizations;
    get customizations(): DataAwsDistributionTenant.CustomizationsPropertyList;
    get distributionId(): string;
    private _domain?;
    get domain(): string;
    set domain(value: string);
    resetDomain(): void;
    get domainInput(): string | undefined;
    private _domains;
    get domains(): DataAwsDistributionTenant.DomainsPropertyList;
    get enabled(): cdktn.IResolvable;
    get etag(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _managedCertificateRequest;
    get managedCertificateRequest(): DataAwsDistributionTenant.ManagedCertificateRequestPropertyList;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _parameters;
    get parameters(): DataAwsDistributionTenant.ParametersPropertyList;
    get status(): string;
    private _tags;
    get tags(): cdktn.StringMap;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsDistributionTenantCertificatePropertyToTerraform(struct?: DataAwsDistributionTenant.CertificateProperty): any;
export declare function dataAwsDistributionTenantCertificatePropertyToHclTerraform(struct?: DataAwsDistributionTenant.CertificateProperty): any;
export declare function dataAwsDistributionTenantGeoRestrictionPropertyToTerraform(struct?: DataAwsDistributionTenant.GeoRestrictionProperty): any;
export declare function dataAwsDistributionTenantGeoRestrictionPropertyToHclTerraform(struct?: DataAwsDistributionTenant.GeoRestrictionProperty): any;
export declare function dataAwsDistributionTenantWebAclPropertyToTerraform(struct?: DataAwsDistributionTenant.WebAclProperty): any;
export declare function dataAwsDistributionTenantWebAclPropertyToHclTerraform(struct?: DataAwsDistributionTenant.WebAclProperty): any;
export declare function dataAwsDistributionTenantCustomizationsPropertyToTerraform(struct?: DataAwsDistributionTenant.CustomizationsProperty): any;
export declare function dataAwsDistributionTenantCustomizationsPropertyToHclTerraform(struct?: DataAwsDistributionTenant.CustomizationsProperty): any;
export declare function dataAwsDistributionTenantDomainsPropertyToTerraform(struct?: DataAwsDistributionTenant.DomainsProperty): any;
export declare function dataAwsDistributionTenantDomainsPropertyToHclTerraform(struct?: DataAwsDistributionTenant.DomainsProperty): any;
export declare function dataAwsDistributionTenantManagedCertificateRequestPropertyToTerraform(struct?: DataAwsDistributionTenant.ManagedCertificateRequestProperty): any;
export declare function dataAwsDistributionTenantManagedCertificateRequestPropertyToHclTerraform(struct?: DataAwsDistributionTenant.ManagedCertificateRequestProperty): any;
export declare function dataAwsDistributionTenantParametersPropertyToTerraform(struct?: DataAwsDistributionTenant.ParametersProperty): any;
export declare function dataAwsDistributionTenantParametersPropertyToHclTerraform(struct?: DataAwsDistributionTenant.ParametersProperty): any;
export declare namespace DataAwsDistributionTenant {
    interface CertificateProperty {
    }
    class CertificatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CertificateProperty | undefined;
        set internalValue(value: CertificateProperty | undefined);
        get arn(): string;
    }
    class CertificatePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CertificatePropertyOutputReference;
    }
    interface GeoRestrictionProperty {
    }
    class GeoRestrictionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GeoRestrictionProperty | undefined;
        set internalValue(value: GeoRestrictionProperty | undefined);
        get locations(): string[];
        get restrictionType(): string;
    }
    class GeoRestrictionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GeoRestrictionPropertyOutputReference;
    }
    interface WebAclProperty {
    }
    class WebAclPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WebAclProperty | undefined;
        set internalValue(value: WebAclProperty | undefined);
        get action(): string;
        get arn(): string;
    }
    class WebAclPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WebAclPropertyOutputReference;
    }
    interface CustomizationsProperty {
    }
    class CustomizationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomizationsProperty | undefined;
        set internalValue(value: CustomizationsProperty | undefined);
        private _certificate;
        get certificate(): CertificatePropertyList;
        private _geoRestriction;
        get geoRestriction(): GeoRestrictionPropertyList;
        private _webAcl;
        get webAcl(): WebAclPropertyList;
    }
    class CustomizationsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomizationsPropertyOutputReference;
    }
    interface DomainsProperty {
    }
    class DomainsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DomainsProperty | undefined;
        set internalValue(value: DomainsProperty | undefined);
        get domain(): string;
        get status(): string;
    }
    class DomainsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DomainsPropertyOutputReference;
    }
    interface ManagedCertificateRequestProperty {
    }
    class ManagedCertificateRequestPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ManagedCertificateRequestProperty | undefined;
        set internalValue(value: ManagedCertificateRequestProperty | undefined);
        get certificateTransparencyLoggingPreference(): string;
        get primaryDomainName(): string;
        get validationTokenHost(): string;
    }
    class ManagedCertificateRequestPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ManagedCertificateRequestPropertyOutputReference;
    }
    interface ParametersProperty {
    }
    class ParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ParametersProperty | undefined;
        set internalValue(value: ParametersProperty | undefined);
        get name(): string;
        get value(): string;
    }
    class ParametersPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ParametersPropertyOutputReference;
    }
}
