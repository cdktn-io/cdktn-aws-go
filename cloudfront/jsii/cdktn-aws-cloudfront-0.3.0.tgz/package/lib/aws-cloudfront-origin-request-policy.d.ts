import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsOriginRequestPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy#comment AwsOriginRequestPolicy#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy#id AwsOriginRequestPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy#name AwsOriginRequestPolicy#name}
    */
    readonly name: string;
    /**
    * cookies_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy#cookies_config AwsOriginRequestPolicy#cookies_config}
    */
    readonly cookiesConfig: AwsOriginRequestPolicy.CookiesConfigProperty;
    /**
    * headers_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy#headers_config AwsOriginRequestPolicy#headers_config}
    */
    readonly headersConfig: AwsOriginRequestPolicy.HeadersConfigProperty;
    /**
    * query_strings_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy#query_strings_config AwsOriginRequestPolicy#query_strings_config}
    */
    readonly queryStringsConfig: AwsOriginRequestPolicy.QueryStringsConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy aws_cloudfront_origin_request_policy}
*/
export declare class AwsOriginRequestPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudfront_origin_request_policy";
    /**
    * Generates CDKTN code for importing a AwsOriginRequestPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsOriginRequestPolicy to import
    * @param importFromId The id of the existing AwsOriginRequestPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsOriginRequestPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy aws_cloudfront_origin_request_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsOriginRequestPolicyConfig
    */
    constructor(scope: Construct, id: string, config: AwsOriginRequestPolicyConfig);
    get arn(): string;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    get etag(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _cookiesConfig;
    get cookiesConfig(): AwsOriginRequestPolicy.CookiesConfigPropertyOutputReference;
    putCookiesConfig(value: AwsOriginRequestPolicy.CookiesConfigProperty): void;
    get cookiesConfigInput(): AwsOriginRequestPolicy.CookiesConfigProperty | undefined;
    private _headersConfig;
    get headersConfig(): AwsOriginRequestPolicy.HeadersConfigPropertyOutputReference;
    putHeadersConfig(value: AwsOriginRequestPolicy.HeadersConfigProperty): void;
    get headersConfigInput(): AwsOriginRequestPolicy.HeadersConfigProperty | undefined;
    private _queryStringsConfig;
    get queryStringsConfig(): AwsOriginRequestPolicy.QueryStringsConfigPropertyOutputReference;
    putQueryStringsConfig(value: AwsOriginRequestPolicy.QueryStringsConfigProperty): void;
    get queryStringsConfigInput(): AwsOriginRequestPolicy.QueryStringsConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsOriginRequestPolicyCookiesPropertyToTerraform(struct?: AwsOriginRequestPolicy.CookiesPropertyOutputReference | AwsOriginRequestPolicy.CookiesProperty): any;
export declare function awsOriginRequestPolicyCookiesPropertyToHclTerraform(struct?: AwsOriginRequestPolicy.CookiesPropertyOutputReference | AwsOriginRequestPolicy.CookiesProperty): any;
export declare function awsOriginRequestPolicyCookiesConfigPropertyToTerraform(struct?: AwsOriginRequestPolicy.CookiesConfigPropertyOutputReference | AwsOriginRequestPolicy.CookiesConfigProperty): any;
export declare function awsOriginRequestPolicyCookiesConfigPropertyToHclTerraform(struct?: AwsOriginRequestPolicy.CookiesConfigPropertyOutputReference | AwsOriginRequestPolicy.CookiesConfigProperty): any;
export declare function awsOriginRequestPolicyHeadersPropertyToTerraform(struct?: AwsOriginRequestPolicy.HeadersPropertyOutputReference | AwsOriginRequestPolicy.HeadersProperty): any;
export declare function awsOriginRequestPolicyHeadersPropertyToHclTerraform(struct?: AwsOriginRequestPolicy.HeadersPropertyOutputReference | AwsOriginRequestPolicy.HeadersProperty): any;
export declare function awsOriginRequestPolicyHeadersConfigPropertyToTerraform(struct?: AwsOriginRequestPolicy.HeadersConfigPropertyOutputReference | AwsOriginRequestPolicy.HeadersConfigProperty): any;
export declare function awsOriginRequestPolicyHeadersConfigPropertyToHclTerraform(struct?: AwsOriginRequestPolicy.HeadersConfigPropertyOutputReference | AwsOriginRequestPolicy.HeadersConfigProperty): any;
export declare function awsOriginRequestPolicyQueryStringsPropertyToTerraform(struct?: AwsOriginRequestPolicy.QueryStringsPropertyOutputReference | AwsOriginRequestPolicy.QueryStringsProperty): any;
export declare function awsOriginRequestPolicyQueryStringsPropertyToHclTerraform(struct?: AwsOriginRequestPolicy.QueryStringsPropertyOutputReference | AwsOriginRequestPolicy.QueryStringsProperty): any;
export declare function awsOriginRequestPolicyQueryStringsConfigPropertyToTerraform(struct?: AwsOriginRequestPolicy.QueryStringsConfigPropertyOutputReference | AwsOriginRequestPolicy.QueryStringsConfigProperty): any;
export declare function awsOriginRequestPolicyQueryStringsConfigPropertyToHclTerraform(struct?: AwsOriginRequestPolicy.QueryStringsConfigPropertyOutputReference | AwsOriginRequestPolicy.QueryStringsConfigProperty): any;
export declare namespace AwsOriginRequestPolicy {
    interface CookiesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy#items AwsOriginRequestPolicy#items}
        */
        readonly items?: string[];
    }
    class CookiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CookiesProperty | undefined;
        set internalValue(value: CookiesProperty | undefined);
        private _items?;
        get items(): string[];
        set items(value: string[]);
        resetItems(): void;
        get itemsInput(): string[] | undefined;
    }
    interface CookiesConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy#cookie_behavior AwsOriginRequestPolicy#cookie_behavior}
        */
        readonly cookieBehavior: string;
        /**
        * cookies block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy#cookies AwsOriginRequestPolicy#cookies}
        */
        readonly cookies?: CookiesProperty;
    }
    class CookiesConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CookiesConfigProperty | undefined;
        set internalValue(value: CookiesConfigProperty | undefined);
        private _cookieBehavior?;
        get cookieBehavior(): string;
        set cookieBehavior(value: string);
        get cookieBehaviorInput(): string | undefined;
        private _cookies;
        get cookies(): CookiesPropertyOutputReference;
        putCookies(value: CookiesProperty): void;
        resetCookies(): void;
        get cookiesInput(): CookiesProperty | undefined;
    }
    interface HeadersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy#items AwsOriginRequestPolicy#items}
        */
        readonly items?: string[];
    }
    class HeadersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HeadersProperty | undefined;
        set internalValue(value: HeadersProperty | undefined);
        private _items?;
        get items(): string[];
        set items(value: string[]);
        resetItems(): void;
        get itemsInput(): string[] | undefined;
    }
    interface HeadersConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy#header_behavior AwsOriginRequestPolicy#header_behavior}
        */
        readonly headerBehavior?: string;
        /**
        * headers block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy#headers AwsOriginRequestPolicy#headers}
        */
        readonly headers?: HeadersProperty;
    }
    class HeadersConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HeadersConfigProperty | undefined;
        set internalValue(value: HeadersConfigProperty | undefined);
        private _headerBehavior?;
        get headerBehavior(): string;
        set headerBehavior(value: string);
        resetHeaderBehavior(): void;
        get headerBehaviorInput(): string | undefined;
        private _headers;
        get headers(): HeadersPropertyOutputReference;
        putHeaders(value: HeadersProperty): void;
        resetHeaders(): void;
        get headersInput(): HeadersProperty | undefined;
    }
    interface QueryStringsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy#items AwsOriginRequestPolicy#items}
        */
        readonly items?: string[];
    }
    class QueryStringsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): QueryStringsProperty | undefined;
        set internalValue(value: QueryStringsProperty | undefined);
        private _items?;
        get items(): string[];
        set items(value: string[]);
        resetItems(): void;
        get itemsInput(): string[] | undefined;
    }
    interface QueryStringsConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy#query_string_behavior AwsOriginRequestPolicy#query_string_behavior}
        */
        readonly queryStringBehavior: string;
        /**
        * query_strings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy#query_strings AwsOriginRequestPolicy#query_strings}
        */
        readonly queryStrings?: QueryStringsProperty;
    }
    class QueryStringsConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): QueryStringsConfigProperty | undefined;
        set internalValue(value: QueryStringsConfigProperty | undefined);
        private _queryStringBehavior?;
        get queryStringBehavior(): string;
        set queryStringBehavior(value: string);
        get queryStringBehaviorInput(): string | undefined;
        private _queryStrings;
        get queryStrings(): QueryStringsPropertyOutputReference;
        putQueryStrings(value: QueryStringsProperty): void;
        resetQueryStrings(): void;
        get queryStringsInput(): QueryStringsProperty | undefined;
    }
}
