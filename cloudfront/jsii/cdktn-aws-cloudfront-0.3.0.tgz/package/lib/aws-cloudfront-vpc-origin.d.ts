import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsVpcOriginConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_vpc_origin#tags AwsVpcOrigin#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_vpc_origin#timeouts AwsVpcOrigin#timeouts}
    */
    readonly timeouts?: AwsVpcOrigin.TimeoutsProperty;
    /**
    * vpc_origin_endpoint_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_vpc_origin#vpc_origin_endpoint_config AwsVpcOrigin#vpc_origin_endpoint_config}
    */
    readonly vpcOriginEndpointConfig?: AwsVpcOrigin.VpcOriginEndpointConfigProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_vpc_origin aws_cloudfront_vpc_origin}
*/
export declare class AwsVpcOrigin extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudfront_vpc_origin";
    /**
    * Generates CDKTN code for importing a AwsVpcOrigin resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsVpcOrigin to import
    * @param importFromId The id of the existing AwsVpcOrigin that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_vpc_origin#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsVpcOrigin to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_vpc_origin aws_cloudfront_vpc_origin} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsVpcOriginConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AwsVpcOriginConfig);
    get arn(): string;
    get etag(): string;
    get id(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _timeouts;
    get timeouts(): AwsVpcOrigin.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsVpcOrigin.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsVpcOrigin.TimeoutsProperty | undefined;
    private _vpcOriginEndpointConfig;
    get vpcOriginEndpointConfig(): AwsVpcOrigin.VpcOriginEndpointConfigPropertyList;
    putVpcOriginEndpointConfig(value: AwsVpcOrigin.VpcOriginEndpointConfigProperty[] | cdktn.IResolvable): void;
    resetVpcOriginEndpointConfig(): void;
    get vpcOriginEndpointConfigInput(): cdktn.IResolvable | AwsVpcOrigin.VpcOriginEndpointConfigProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsVpcOriginTimeoutsPropertyToTerraform(struct?: AwsVpcOrigin.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsVpcOriginTimeoutsPropertyToHclTerraform(struct?: AwsVpcOrigin.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsVpcOriginOriginSslProtocolsPropertyToTerraform(struct?: AwsVpcOrigin.OriginSslProtocolsProperty | cdktn.IResolvable): any;
export declare function awsVpcOriginOriginSslProtocolsPropertyToHclTerraform(struct?: AwsVpcOrigin.OriginSslProtocolsProperty | cdktn.IResolvable): any;
export declare function awsVpcOriginVpcOriginEndpointConfigPropertyToTerraform(struct?: AwsVpcOrigin.VpcOriginEndpointConfigProperty | cdktn.IResolvable): any;
export declare function awsVpcOriginVpcOriginEndpointConfigPropertyToHclTerraform(struct?: AwsVpcOrigin.VpcOriginEndpointConfigProperty | cdktn.IResolvable): any;
export declare namespace AwsVpcOrigin {
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_vpc_origin#create AwsVpcOrigin#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_vpc_origin#delete AwsVpcOrigin#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_vpc_origin#update AwsVpcOrigin#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface OriginSslProtocolsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_vpc_origin#items AwsVpcOrigin#items}
        */
        readonly items: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_vpc_origin#quantity AwsVpcOrigin#quantity}
        */
        readonly quantity: number;
    }
    class OriginSslProtocolsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OriginSslProtocolsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OriginSslProtocolsProperty | cdktn.IResolvable | undefined);
        private _items?;
        get items(): string[];
        set items(value: string[]);
        get itemsInput(): string[] | undefined;
        private _quantity?;
        get quantity(): number;
        set quantity(value: number);
        get quantityInput(): number | undefined;
    }
    class OriginSslProtocolsPropertyList extends cdktn.ComplexList {
        internalValue?: OriginSslProtocolsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OriginSslProtocolsPropertyOutputReference;
    }
    interface VpcOriginEndpointConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_vpc_origin#arn AwsVpcOrigin#arn}
        */
        readonly arn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_vpc_origin#http_port AwsVpcOrigin#http_port}
        */
        readonly httpPort: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_vpc_origin#https_port AwsVpcOrigin#https_port}
        */
        readonly httpsPort: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_vpc_origin#name AwsVpcOrigin#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_vpc_origin#origin_protocol_policy AwsVpcOrigin#origin_protocol_policy}
        */
        readonly originProtocolPolicy: string;
        /**
        * origin_ssl_protocols block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_vpc_origin#origin_ssl_protocols AwsVpcOrigin#origin_ssl_protocols}
        */
        readonly originSslProtocols?: OriginSslProtocolsProperty[] | cdktn.IResolvable;
    }
    class VpcOriginEndpointConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VpcOriginEndpointConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VpcOriginEndpointConfigProperty | cdktn.IResolvable | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
        private _httpPort?;
        get httpPort(): number;
        set httpPort(value: number);
        get httpPortInput(): number | undefined;
        private _httpsPort?;
        get httpsPort(): number;
        set httpsPort(value: number);
        get httpsPortInput(): number | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _originProtocolPolicy?;
        get originProtocolPolicy(): string;
        set originProtocolPolicy(value: string);
        get originProtocolPolicyInput(): string | undefined;
        private _originSslProtocols;
        get originSslProtocols(): OriginSslProtocolsPropertyList;
        putOriginSslProtocols(value: OriginSslProtocolsProperty[] | cdktn.IResolvable): void;
        resetOriginSslProtocols(): void;
        get originSslProtocolsInput(): cdktn.IResolvable | OriginSslProtocolsProperty[] | undefined;
    }
    class VpcOriginEndpointConfigPropertyList extends cdktn.ComplexList {
        internalValue?: VpcOriginEndpointConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VpcOriginEndpointConfigPropertyOutputReference;
    }
}
