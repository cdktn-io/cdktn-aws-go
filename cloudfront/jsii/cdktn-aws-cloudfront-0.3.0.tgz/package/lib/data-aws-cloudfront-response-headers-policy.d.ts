import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsResponseHeadersPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudfront_response_headers_policy#id DataAwsResponseHeadersPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudfront_response_headers_policy#name DataAwsResponseHeadersPolicy#name}
    */
    readonly name?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudfront_response_headers_policy aws_cloudfront_response_headers_policy}
*/
export declare class DataAwsResponseHeadersPolicy extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_cloudfront_response_headers_policy";
    /**
    * Generates CDKTN code for importing a DataAwsResponseHeadersPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsResponseHeadersPolicy to import
    * @param importFromId The id of the existing DataAwsResponseHeadersPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudfront_response_headers_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsResponseHeadersPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudfront_response_headers_policy aws_cloudfront_response_headers_policy} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsResponseHeadersPolicyConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsResponseHeadersPolicyConfig);
    get arn(): string;
    get comment(): string;
    private _corsConfig;
    get corsConfig(): DataAwsResponseHeadersPolicy.CorsConfigPropertyList;
    private _customHeadersConfig;
    get customHeadersConfig(): DataAwsResponseHeadersPolicy.CustomHeadersConfigPropertyList;
    get etag(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _removeHeadersConfig;
    get removeHeadersConfig(): DataAwsResponseHeadersPolicy.RemoveHeadersConfigPropertyList;
    private _securityHeadersConfig;
    get securityHeadersConfig(): DataAwsResponseHeadersPolicy.SecurityHeadersConfigPropertyList;
    private _serverTimingHeadersConfig;
    get serverTimingHeadersConfig(): DataAwsResponseHeadersPolicy.ServerTimingHeadersConfigPropertyList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsResponseHeadersPolicyAccessControlAllowHeadersPropertyToTerraform(struct?: DataAwsResponseHeadersPolicy.AccessControlAllowHeadersProperty): any;
export declare function dataAwsResponseHeadersPolicyAccessControlAllowHeadersPropertyToHclTerraform(struct?: DataAwsResponseHeadersPolicy.AccessControlAllowHeadersProperty): any;
export declare function dataAwsResponseHeadersPolicyAccessControlAllowMethodsPropertyToTerraform(struct?: DataAwsResponseHeadersPolicy.AccessControlAllowMethodsProperty): any;
export declare function dataAwsResponseHeadersPolicyAccessControlAllowMethodsPropertyToHclTerraform(struct?: DataAwsResponseHeadersPolicy.AccessControlAllowMethodsProperty): any;
export declare function dataAwsResponseHeadersPolicyAccessControlAllowOriginsPropertyToTerraform(struct?: DataAwsResponseHeadersPolicy.AccessControlAllowOriginsProperty): any;
export declare function dataAwsResponseHeadersPolicyAccessControlAllowOriginsPropertyToHclTerraform(struct?: DataAwsResponseHeadersPolicy.AccessControlAllowOriginsProperty): any;
export declare function dataAwsResponseHeadersPolicyAccessControlExposeHeadersPropertyToTerraform(struct?: DataAwsResponseHeadersPolicy.AccessControlExposeHeadersProperty): any;
export declare function dataAwsResponseHeadersPolicyAccessControlExposeHeadersPropertyToHclTerraform(struct?: DataAwsResponseHeadersPolicy.AccessControlExposeHeadersProperty): any;
export declare function dataAwsResponseHeadersPolicyCorsConfigPropertyToTerraform(struct?: DataAwsResponseHeadersPolicy.CorsConfigProperty): any;
export declare function dataAwsResponseHeadersPolicyCorsConfigPropertyToHclTerraform(struct?: DataAwsResponseHeadersPolicy.CorsConfigProperty): any;
export declare function dataAwsResponseHeadersPolicyCustomHeadersConfigItemsPropertyToTerraform(struct?: DataAwsResponseHeadersPolicy.CustomHeadersConfigItemsProperty): any;
export declare function dataAwsResponseHeadersPolicyCustomHeadersConfigItemsPropertyToHclTerraform(struct?: DataAwsResponseHeadersPolicy.CustomHeadersConfigItemsProperty): any;
export declare function dataAwsResponseHeadersPolicyCustomHeadersConfigPropertyToTerraform(struct?: DataAwsResponseHeadersPolicy.CustomHeadersConfigProperty): any;
export declare function dataAwsResponseHeadersPolicyCustomHeadersConfigPropertyToHclTerraform(struct?: DataAwsResponseHeadersPolicy.CustomHeadersConfigProperty): any;
export declare function dataAwsResponseHeadersPolicyRemoveHeadersConfigItemsPropertyToTerraform(struct?: DataAwsResponseHeadersPolicy.RemoveHeadersConfigItemsProperty): any;
export declare function dataAwsResponseHeadersPolicyRemoveHeadersConfigItemsPropertyToHclTerraform(struct?: DataAwsResponseHeadersPolicy.RemoveHeadersConfigItemsProperty): any;
export declare function dataAwsResponseHeadersPolicyRemoveHeadersConfigPropertyToTerraform(struct?: DataAwsResponseHeadersPolicy.RemoveHeadersConfigProperty): any;
export declare function dataAwsResponseHeadersPolicyRemoveHeadersConfigPropertyToHclTerraform(struct?: DataAwsResponseHeadersPolicy.RemoveHeadersConfigProperty): any;
export declare function dataAwsResponseHeadersPolicyContentSecurityPolicyPropertyToTerraform(struct?: DataAwsResponseHeadersPolicy.ContentSecurityPolicyProperty): any;
export declare function dataAwsResponseHeadersPolicyContentSecurityPolicyPropertyToHclTerraform(struct?: DataAwsResponseHeadersPolicy.ContentSecurityPolicyProperty): any;
export declare function dataAwsResponseHeadersPolicyContentTypeOptionsPropertyToTerraform(struct?: DataAwsResponseHeadersPolicy.ContentTypeOptionsProperty): any;
export declare function dataAwsResponseHeadersPolicyContentTypeOptionsPropertyToHclTerraform(struct?: DataAwsResponseHeadersPolicy.ContentTypeOptionsProperty): any;
export declare function dataAwsResponseHeadersPolicyFrameOptionsPropertyToTerraform(struct?: DataAwsResponseHeadersPolicy.FrameOptionsProperty): any;
export declare function dataAwsResponseHeadersPolicyFrameOptionsPropertyToHclTerraform(struct?: DataAwsResponseHeadersPolicy.FrameOptionsProperty): any;
export declare function dataAwsResponseHeadersPolicyReferrerPolicyPropertyToTerraform(struct?: DataAwsResponseHeadersPolicy.ReferrerPolicyProperty): any;
export declare function dataAwsResponseHeadersPolicyReferrerPolicyPropertyToHclTerraform(struct?: DataAwsResponseHeadersPolicy.ReferrerPolicyProperty): any;
export declare function dataAwsResponseHeadersPolicyStrictTransportSecurityPropertyToTerraform(struct?: DataAwsResponseHeadersPolicy.StrictTransportSecurityProperty): any;
export declare function dataAwsResponseHeadersPolicyStrictTransportSecurityPropertyToHclTerraform(struct?: DataAwsResponseHeadersPolicy.StrictTransportSecurityProperty): any;
export declare function dataAwsResponseHeadersPolicyXssProtectionPropertyToTerraform(struct?: DataAwsResponseHeadersPolicy.XssProtectionProperty): any;
export declare function dataAwsResponseHeadersPolicyXssProtectionPropertyToHclTerraform(struct?: DataAwsResponseHeadersPolicy.XssProtectionProperty): any;
export declare function dataAwsResponseHeadersPolicySecurityHeadersConfigPropertyToTerraform(struct?: DataAwsResponseHeadersPolicy.SecurityHeadersConfigProperty): any;
export declare function dataAwsResponseHeadersPolicySecurityHeadersConfigPropertyToHclTerraform(struct?: DataAwsResponseHeadersPolicy.SecurityHeadersConfigProperty): any;
export declare function dataAwsResponseHeadersPolicyServerTimingHeadersConfigPropertyToTerraform(struct?: DataAwsResponseHeadersPolicy.ServerTimingHeadersConfigProperty): any;
export declare function dataAwsResponseHeadersPolicyServerTimingHeadersConfigPropertyToHclTerraform(struct?: DataAwsResponseHeadersPolicy.ServerTimingHeadersConfigProperty): any;
export declare namespace DataAwsResponseHeadersPolicy {
    interface AccessControlAllowHeadersProperty {
    }
    class AccessControlAllowHeadersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AccessControlAllowHeadersProperty | undefined;
        set internalValue(value: AccessControlAllowHeadersProperty | undefined);
        get items(): string[];
    }
    class AccessControlAllowHeadersPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AccessControlAllowHeadersPropertyOutputReference;
    }
    interface AccessControlAllowMethodsProperty {
    }
    class AccessControlAllowMethodsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AccessControlAllowMethodsProperty | undefined;
        set internalValue(value: AccessControlAllowMethodsProperty | undefined);
        get items(): string[];
    }
    class AccessControlAllowMethodsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AccessControlAllowMethodsPropertyOutputReference;
    }
    interface AccessControlAllowOriginsProperty {
    }
    class AccessControlAllowOriginsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AccessControlAllowOriginsProperty | undefined;
        set internalValue(value: AccessControlAllowOriginsProperty | undefined);
        get items(): string[];
    }
    class AccessControlAllowOriginsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AccessControlAllowOriginsPropertyOutputReference;
    }
    interface AccessControlExposeHeadersProperty {
    }
    class AccessControlExposeHeadersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AccessControlExposeHeadersProperty | undefined;
        set internalValue(value: AccessControlExposeHeadersProperty | undefined);
        get items(): string[];
    }
    class AccessControlExposeHeadersPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AccessControlExposeHeadersPropertyOutputReference;
    }
    interface CorsConfigProperty {
    }
    class CorsConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CorsConfigProperty | undefined;
        set internalValue(value: CorsConfigProperty | undefined);
        get accessControlAllowCredentials(): cdktn.IResolvable;
        private _accessControlAllowHeaders;
        get accessControlAllowHeaders(): AccessControlAllowHeadersPropertyList;
        private _accessControlAllowMethods;
        get accessControlAllowMethods(): AccessControlAllowMethodsPropertyList;
        private _accessControlAllowOrigins;
        get accessControlAllowOrigins(): AccessControlAllowOriginsPropertyList;
        private _accessControlExposeHeaders;
        get accessControlExposeHeaders(): AccessControlExposeHeadersPropertyList;
        get accessControlMaxAgeSec(): number;
        get originOverride(): cdktn.IResolvable;
    }
    class CorsConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CorsConfigPropertyOutputReference;
    }
    interface CustomHeadersConfigItemsProperty {
    }
    class CustomHeadersConfigItemsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomHeadersConfigItemsProperty | undefined;
        set internalValue(value: CustomHeadersConfigItemsProperty | undefined);
        get header(): string;
        get override(): cdktn.IResolvable;
        get value(): string;
    }
    class CustomHeadersConfigItemsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomHeadersConfigItemsPropertyOutputReference;
    }
    interface CustomHeadersConfigProperty {
    }
    class CustomHeadersConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomHeadersConfigProperty | undefined;
        set internalValue(value: CustomHeadersConfigProperty | undefined);
        private _items;
        get items(): CustomHeadersConfigItemsPropertyList;
    }
    class CustomHeadersConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomHeadersConfigPropertyOutputReference;
    }
    interface RemoveHeadersConfigItemsProperty {
    }
    class RemoveHeadersConfigItemsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RemoveHeadersConfigItemsProperty | undefined;
        set internalValue(value: RemoveHeadersConfigItemsProperty | undefined);
        get header(): string;
    }
    class RemoveHeadersConfigItemsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RemoveHeadersConfigItemsPropertyOutputReference;
    }
    interface RemoveHeadersConfigProperty {
    }
    class RemoveHeadersConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RemoveHeadersConfigProperty | undefined;
        set internalValue(value: RemoveHeadersConfigProperty | undefined);
        private _items;
        get items(): RemoveHeadersConfigItemsPropertyList;
    }
    class RemoveHeadersConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RemoveHeadersConfigPropertyOutputReference;
    }
    interface ContentSecurityPolicyProperty {
    }
    class ContentSecurityPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ContentSecurityPolicyProperty | undefined;
        set internalValue(value: ContentSecurityPolicyProperty | undefined);
        get contentSecurityPolicy(): string;
        get override(): cdktn.IResolvable;
    }
    class ContentSecurityPolicyPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ContentSecurityPolicyPropertyOutputReference;
    }
    interface ContentTypeOptionsProperty {
    }
    class ContentTypeOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ContentTypeOptionsProperty | undefined;
        set internalValue(value: ContentTypeOptionsProperty | undefined);
        get override(): cdktn.IResolvable;
    }
    class ContentTypeOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ContentTypeOptionsPropertyOutputReference;
    }
    interface FrameOptionsProperty {
    }
    class FrameOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FrameOptionsProperty | undefined;
        set internalValue(value: FrameOptionsProperty | undefined);
        get frameOption(): string;
        get override(): cdktn.IResolvable;
    }
    class FrameOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FrameOptionsPropertyOutputReference;
    }
    interface ReferrerPolicyProperty {
    }
    class ReferrerPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReferrerPolicyProperty | undefined;
        set internalValue(value: ReferrerPolicyProperty | undefined);
        get override(): cdktn.IResolvable;
        get referrerPolicy(): string;
    }
    class ReferrerPolicyPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReferrerPolicyPropertyOutputReference;
    }
    interface StrictTransportSecurityProperty {
    }
    class StrictTransportSecurityPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StrictTransportSecurityProperty | undefined;
        set internalValue(value: StrictTransportSecurityProperty | undefined);
        get accessControlMaxAgeSec(): number;
        get includeSubdomains(): cdktn.IResolvable;
        get override(): cdktn.IResolvable;
        get preload(): cdktn.IResolvable;
    }
    class StrictTransportSecurityPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StrictTransportSecurityPropertyOutputReference;
    }
    interface XssProtectionProperty {
    }
    class XssProtectionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): XssProtectionProperty | undefined;
        set internalValue(value: XssProtectionProperty | undefined);
        get modeBlock(): cdktn.IResolvable;
        get override(): cdktn.IResolvable;
        get protection(): cdktn.IResolvable;
        get reportUri(): string;
    }
    class XssProtectionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): XssProtectionPropertyOutputReference;
    }
    interface SecurityHeadersConfigProperty {
    }
    class SecurityHeadersConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SecurityHeadersConfigProperty | undefined;
        set internalValue(value: SecurityHeadersConfigProperty | undefined);
        private _contentSecurityPolicy;
        get contentSecurityPolicy(): ContentSecurityPolicyPropertyList;
        private _contentTypeOptions;
        get contentTypeOptions(): ContentTypeOptionsPropertyList;
        private _frameOptions;
        get frameOptions(): FrameOptionsPropertyList;
        private _referrerPolicy;
        get referrerPolicy(): ReferrerPolicyPropertyList;
        private _strictTransportSecurity;
        get strictTransportSecurity(): StrictTransportSecurityPropertyList;
        private _xssProtection;
        get xssProtection(): XssProtectionPropertyList;
    }
    class SecurityHeadersConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SecurityHeadersConfigPropertyOutputReference;
    }
    interface ServerTimingHeadersConfigProperty {
    }
    class ServerTimingHeadersConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ServerTimingHeadersConfigProperty | undefined;
        set internalValue(value: ServerTimingHeadersConfigProperty | undefined);
        get enabled(): cdktn.IResolvable;
        get samplingRate(): number;
    }
    class ServerTimingHeadersConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ServerTimingHeadersConfigPropertyOutputReference;
    }
}
