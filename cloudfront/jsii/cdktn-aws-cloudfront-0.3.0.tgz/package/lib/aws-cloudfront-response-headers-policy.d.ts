import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsResponseHeadersPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#comment AwsResponseHeadersPolicy#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#id AwsResponseHeadersPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#name AwsResponseHeadersPolicy#name}
    */
    readonly name: string;
    /**
    * cors_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#cors_config AwsResponseHeadersPolicy#cors_config}
    */
    readonly corsConfig?: AwsResponseHeadersPolicy.CorsConfigProperty;
    /**
    * custom_headers_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#custom_headers_config AwsResponseHeadersPolicy#custom_headers_config}
    */
    readonly customHeadersConfig?: AwsResponseHeadersPolicy.CustomHeadersConfigProperty;
    /**
    * remove_headers_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#remove_headers_config AwsResponseHeadersPolicy#remove_headers_config}
    */
    readonly removeHeadersConfig?: AwsResponseHeadersPolicy.RemoveHeadersConfigProperty;
    /**
    * security_headers_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#security_headers_config AwsResponseHeadersPolicy#security_headers_config}
    */
    readonly securityHeadersConfig?: AwsResponseHeadersPolicy.SecurityHeadersConfigProperty;
    /**
    * server_timing_headers_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#server_timing_headers_config AwsResponseHeadersPolicy#server_timing_headers_config}
    */
    readonly serverTimingHeadersConfig?: AwsResponseHeadersPolicy.ServerTimingHeadersConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy aws_cloudfront_response_headers_policy}
*/
export declare class AwsResponseHeadersPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudfront_response_headers_policy";
    /**
    * Generates CDKTN code for importing a AwsResponseHeadersPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsResponseHeadersPolicy to import
    * @param importFromId The id of the existing AwsResponseHeadersPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsResponseHeadersPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy aws_cloudfront_response_headers_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsResponseHeadersPolicyConfig
    */
    constructor(scope: Construct, id: string, config: AwsResponseHeadersPolicyConfig);
    get arn(): string;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    get etag(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _corsConfig;
    get corsConfig(): AwsResponseHeadersPolicy.CorsConfigPropertyOutputReference;
    putCorsConfig(value: AwsResponseHeadersPolicy.CorsConfigProperty): void;
    resetCorsConfig(): void;
    get corsConfigInput(): AwsResponseHeadersPolicy.CorsConfigProperty | undefined;
    private _customHeadersConfig;
    get customHeadersConfig(): AwsResponseHeadersPolicy.CustomHeadersConfigPropertyOutputReference;
    putCustomHeadersConfig(value: AwsResponseHeadersPolicy.CustomHeadersConfigProperty): void;
    resetCustomHeadersConfig(): void;
    get customHeadersConfigInput(): AwsResponseHeadersPolicy.CustomHeadersConfigProperty | undefined;
    private _removeHeadersConfig;
    get removeHeadersConfig(): AwsResponseHeadersPolicy.RemoveHeadersConfigPropertyOutputReference;
    putRemoveHeadersConfig(value: AwsResponseHeadersPolicy.RemoveHeadersConfigProperty): void;
    resetRemoveHeadersConfig(): void;
    get removeHeadersConfigInput(): AwsResponseHeadersPolicy.RemoveHeadersConfigProperty | undefined;
    private _securityHeadersConfig;
    get securityHeadersConfig(): AwsResponseHeadersPolicy.SecurityHeadersConfigPropertyOutputReference;
    putSecurityHeadersConfig(value: AwsResponseHeadersPolicy.SecurityHeadersConfigProperty): void;
    resetSecurityHeadersConfig(): void;
    get securityHeadersConfigInput(): AwsResponseHeadersPolicy.SecurityHeadersConfigProperty | undefined;
    private _serverTimingHeadersConfig;
    get serverTimingHeadersConfig(): AwsResponseHeadersPolicy.ServerTimingHeadersConfigPropertyOutputReference;
    putServerTimingHeadersConfig(value: AwsResponseHeadersPolicy.ServerTimingHeadersConfigProperty): void;
    resetServerTimingHeadersConfig(): void;
    get serverTimingHeadersConfigInput(): AwsResponseHeadersPolicy.ServerTimingHeadersConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsResponseHeadersPolicyAccessControlAllowHeadersPropertyToTerraform(struct?: AwsResponseHeadersPolicy.AccessControlAllowHeadersPropertyOutputReference | AwsResponseHeadersPolicy.AccessControlAllowHeadersProperty): any;
export declare function awsResponseHeadersPolicyAccessControlAllowHeadersPropertyToHclTerraform(struct?: AwsResponseHeadersPolicy.AccessControlAllowHeadersPropertyOutputReference | AwsResponseHeadersPolicy.AccessControlAllowHeadersProperty): any;
export declare function awsResponseHeadersPolicyAccessControlAllowMethodsPropertyToTerraform(struct?: AwsResponseHeadersPolicy.AccessControlAllowMethodsPropertyOutputReference | AwsResponseHeadersPolicy.AccessControlAllowMethodsProperty): any;
export declare function awsResponseHeadersPolicyAccessControlAllowMethodsPropertyToHclTerraform(struct?: AwsResponseHeadersPolicy.AccessControlAllowMethodsPropertyOutputReference | AwsResponseHeadersPolicy.AccessControlAllowMethodsProperty): any;
export declare function awsResponseHeadersPolicyAccessControlAllowOriginsPropertyToTerraform(struct?: AwsResponseHeadersPolicy.AccessControlAllowOriginsPropertyOutputReference | AwsResponseHeadersPolicy.AccessControlAllowOriginsProperty): any;
export declare function awsResponseHeadersPolicyAccessControlAllowOriginsPropertyToHclTerraform(struct?: AwsResponseHeadersPolicy.AccessControlAllowOriginsPropertyOutputReference | AwsResponseHeadersPolicy.AccessControlAllowOriginsProperty): any;
export declare function awsResponseHeadersPolicyAccessControlExposeHeadersPropertyToTerraform(struct?: AwsResponseHeadersPolicy.AccessControlExposeHeadersPropertyOutputReference | AwsResponseHeadersPolicy.AccessControlExposeHeadersProperty): any;
export declare function awsResponseHeadersPolicyAccessControlExposeHeadersPropertyToHclTerraform(struct?: AwsResponseHeadersPolicy.AccessControlExposeHeadersPropertyOutputReference | AwsResponseHeadersPolicy.AccessControlExposeHeadersProperty): any;
export declare function awsResponseHeadersPolicyCorsConfigPropertyToTerraform(struct?: AwsResponseHeadersPolicy.CorsConfigPropertyOutputReference | AwsResponseHeadersPolicy.CorsConfigProperty): any;
export declare function awsResponseHeadersPolicyCorsConfigPropertyToHclTerraform(struct?: AwsResponseHeadersPolicy.CorsConfigPropertyOutputReference | AwsResponseHeadersPolicy.CorsConfigProperty): any;
export declare function awsResponseHeadersPolicyCustomHeadersConfigItemsPropertyToTerraform(struct?: AwsResponseHeadersPolicy.CustomHeadersConfigItemsProperty | cdktn.IResolvable): any;
export declare function awsResponseHeadersPolicyCustomHeadersConfigItemsPropertyToHclTerraform(struct?: AwsResponseHeadersPolicy.CustomHeadersConfigItemsProperty | cdktn.IResolvable): any;
export declare function awsResponseHeadersPolicyCustomHeadersConfigPropertyToTerraform(struct?: AwsResponseHeadersPolicy.CustomHeadersConfigPropertyOutputReference | AwsResponseHeadersPolicy.CustomHeadersConfigProperty): any;
export declare function awsResponseHeadersPolicyCustomHeadersConfigPropertyToHclTerraform(struct?: AwsResponseHeadersPolicy.CustomHeadersConfigPropertyOutputReference | AwsResponseHeadersPolicy.CustomHeadersConfigProperty): any;
export declare function awsResponseHeadersPolicyRemoveHeadersConfigItemsPropertyToTerraform(struct?: AwsResponseHeadersPolicy.RemoveHeadersConfigItemsProperty | cdktn.IResolvable): any;
export declare function awsResponseHeadersPolicyRemoveHeadersConfigItemsPropertyToHclTerraform(struct?: AwsResponseHeadersPolicy.RemoveHeadersConfigItemsProperty | cdktn.IResolvable): any;
export declare function awsResponseHeadersPolicyRemoveHeadersConfigPropertyToTerraform(struct?: AwsResponseHeadersPolicy.RemoveHeadersConfigPropertyOutputReference | AwsResponseHeadersPolicy.RemoveHeadersConfigProperty): any;
export declare function awsResponseHeadersPolicyRemoveHeadersConfigPropertyToHclTerraform(struct?: AwsResponseHeadersPolicy.RemoveHeadersConfigPropertyOutputReference | AwsResponseHeadersPolicy.RemoveHeadersConfigProperty): any;
export declare function awsResponseHeadersPolicyContentSecurityPolicyPropertyToTerraform(struct?: AwsResponseHeadersPolicy.ContentSecurityPolicyPropertyOutputReference | AwsResponseHeadersPolicy.ContentSecurityPolicyProperty): any;
export declare function awsResponseHeadersPolicyContentSecurityPolicyPropertyToHclTerraform(struct?: AwsResponseHeadersPolicy.ContentSecurityPolicyPropertyOutputReference | AwsResponseHeadersPolicy.ContentSecurityPolicyProperty): any;
export declare function awsResponseHeadersPolicyContentTypeOptionsPropertyToTerraform(struct?: AwsResponseHeadersPolicy.ContentTypeOptionsPropertyOutputReference | AwsResponseHeadersPolicy.ContentTypeOptionsProperty): any;
export declare function awsResponseHeadersPolicyContentTypeOptionsPropertyToHclTerraform(struct?: AwsResponseHeadersPolicy.ContentTypeOptionsPropertyOutputReference | AwsResponseHeadersPolicy.ContentTypeOptionsProperty): any;
export declare function awsResponseHeadersPolicyFrameOptionsPropertyToTerraform(struct?: AwsResponseHeadersPolicy.FrameOptionsPropertyOutputReference | AwsResponseHeadersPolicy.FrameOptionsProperty): any;
export declare function awsResponseHeadersPolicyFrameOptionsPropertyToHclTerraform(struct?: AwsResponseHeadersPolicy.FrameOptionsPropertyOutputReference | AwsResponseHeadersPolicy.FrameOptionsProperty): any;
export declare function awsResponseHeadersPolicyReferrerPolicyPropertyToTerraform(struct?: AwsResponseHeadersPolicy.ReferrerPolicyPropertyOutputReference | AwsResponseHeadersPolicy.ReferrerPolicyProperty): any;
export declare function awsResponseHeadersPolicyReferrerPolicyPropertyToHclTerraform(struct?: AwsResponseHeadersPolicy.ReferrerPolicyPropertyOutputReference | AwsResponseHeadersPolicy.ReferrerPolicyProperty): any;
export declare function awsResponseHeadersPolicyStrictTransportSecurityPropertyToTerraform(struct?: AwsResponseHeadersPolicy.StrictTransportSecurityPropertyOutputReference | AwsResponseHeadersPolicy.StrictTransportSecurityProperty): any;
export declare function awsResponseHeadersPolicyStrictTransportSecurityPropertyToHclTerraform(struct?: AwsResponseHeadersPolicy.StrictTransportSecurityPropertyOutputReference | AwsResponseHeadersPolicy.StrictTransportSecurityProperty): any;
export declare function awsResponseHeadersPolicyXssProtectionPropertyToTerraform(struct?: AwsResponseHeadersPolicy.XssProtectionPropertyOutputReference | AwsResponseHeadersPolicy.XssProtectionProperty): any;
export declare function awsResponseHeadersPolicyXssProtectionPropertyToHclTerraform(struct?: AwsResponseHeadersPolicy.XssProtectionPropertyOutputReference | AwsResponseHeadersPolicy.XssProtectionProperty): any;
export declare function awsResponseHeadersPolicySecurityHeadersConfigPropertyToTerraform(struct?: AwsResponseHeadersPolicy.SecurityHeadersConfigPropertyOutputReference | AwsResponseHeadersPolicy.SecurityHeadersConfigProperty): any;
export declare function awsResponseHeadersPolicySecurityHeadersConfigPropertyToHclTerraform(struct?: AwsResponseHeadersPolicy.SecurityHeadersConfigPropertyOutputReference | AwsResponseHeadersPolicy.SecurityHeadersConfigProperty): any;
export declare function awsResponseHeadersPolicyServerTimingHeadersConfigPropertyToTerraform(struct?: AwsResponseHeadersPolicy.ServerTimingHeadersConfigPropertyOutputReference | AwsResponseHeadersPolicy.ServerTimingHeadersConfigProperty): any;
export declare function awsResponseHeadersPolicyServerTimingHeadersConfigPropertyToHclTerraform(struct?: AwsResponseHeadersPolicy.ServerTimingHeadersConfigPropertyOutputReference | AwsResponseHeadersPolicy.ServerTimingHeadersConfigProperty): any;
export declare namespace AwsResponseHeadersPolicy {
    interface AccessControlAllowHeadersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#items AwsResponseHeadersPolicy#items}
        */
        readonly items?: string[];
    }
    class AccessControlAllowHeadersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AccessControlAllowHeadersProperty | undefined;
        set internalValue(value: AccessControlAllowHeadersProperty | undefined);
        private _items?;
        get items(): string[];
        set items(value: string[]);
        resetItems(): void;
        get itemsInput(): string[] | undefined;
    }
    interface AccessControlAllowMethodsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#items AwsResponseHeadersPolicy#items}
        */
        readonly items?: string[];
    }
    class AccessControlAllowMethodsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AccessControlAllowMethodsProperty | undefined;
        set internalValue(value: AccessControlAllowMethodsProperty | undefined);
        private _items?;
        get items(): string[];
        set items(value: string[]);
        resetItems(): void;
        get itemsInput(): string[] | undefined;
    }
    interface AccessControlAllowOriginsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#items AwsResponseHeadersPolicy#items}
        */
        readonly items?: string[];
    }
    class AccessControlAllowOriginsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AccessControlAllowOriginsProperty | undefined;
        set internalValue(value: AccessControlAllowOriginsProperty | undefined);
        private _items?;
        get items(): string[];
        set items(value: string[]);
        resetItems(): void;
        get itemsInput(): string[] | undefined;
    }
    interface AccessControlExposeHeadersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#items AwsResponseHeadersPolicy#items}
        */
        readonly items?: string[];
    }
    class AccessControlExposeHeadersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AccessControlExposeHeadersProperty | undefined;
        set internalValue(value: AccessControlExposeHeadersProperty | undefined);
        private _items?;
        get items(): string[];
        set items(value: string[]);
        resetItems(): void;
        get itemsInput(): string[] | undefined;
    }
    interface CorsConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#access_control_allow_credentials AwsResponseHeadersPolicy#access_control_allow_credentials}
        */
        readonly accessControlAllowCredentials: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#access_control_max_age_sec AwsResponseHeadersPolicy#access_control_max_age_sec}
        */
        readonly accessControlMaxAgeSec?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#origin_override AwsResponseHeadersPolicy#origin_override}
        */
        readonly originOverride: boolean | cdktn.IResolvable;
        /**
        * access_control_allow_headers block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#access_control_allow_headers AwsResponseHeadersPolicy#access_control_allow_headers}
        */
        readonly accessControlAllowHeaders: AccessControlAllowHeadersProperty;
        /**
        * access_control_allow_methods block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#access_control_allow_methods AwsResponseHeadersPolicy#access_control_allow_methods}
        */
        readonly accessControlAllowMethods: AccessControlAllowMethodsProperty;
        /**
        * access_control_allow_origins block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#access_control_allow_origins AwsResponseHeadersPolicy#access_control_allow_origins}
        */
        readonly accessControlAllowOrigins: AccessControlAllowOriginsProperty;
        /**
        * access_control_expose_headers block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#access_control_expose_headers AwsResponseHeadersPolicy#access_control_expose_headers}
        */
        readonly accessControlExposeHeaders?: AccessControlExposeHeadersProperty;
    }
    class CorsConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CorsConfigProperty | undefined;
        set internalValue(value: CorsConfigProperty | undefined);
        private _accessControlAllowCredentials?;
        get accessControlAllowCredentials(): boolean | cdktn.IResolvable;
        set accessControlAllowCredentials(value: boolean | cdktn.IResolvable);
        get accessControlAllowCredentialsInput(): boolean | cdktn.IResolvable | undefined;
        private _accessControlMaxAgeSec?;
        get accessControlMaxAgeSec(): number;
        set accessControlMaxAgeSec(value: number);
        resetAccessControlMaxAgeSec(): void;
        get accessControlMaxAgeSecInput(): number | undefined;
        private _originOverride?;
        get originOverride(): boolean | cdktn.IResolvable;
        set originOverride(value: boolean | cdktn.IResolvable);
        get originOverrideInput(): boolean | cdktn.IResolvable | undefined;
        private _accessControlAllowHeaders;
        get accessControlAllowHeaders(): AccessControlAllowHeadersPropertyOutputReference;
        putAccessControlAllowHeaders(value: AccessControlAllowHeadersProperty): void;
        get accessControlAllowHeadersInput(): AccessControlAllowHeadersProperty | undefined;
        private _accessControlAllowMethods;
        get accessControlAllowMethods(): AccessControlAllowMethodsPropertyOutputReference;
        putAccessControlAllowMethods(value: AccessControlAllowMethodsProperty): void;
        get accessControlAllowMethodsInput(): AccessControlAllowMethodsProperty | undefined;
        private _accessControlAllowOrigins;
        get accessControlAllowOrigins(): AccessControlAllowOriginsPropertyOutputReference;
        putAccessControlAllowOrigins(value: AccessControlAllowOriginsProperty): void;
        get accessControlAllowOriginsInput(): AccessControlAllowOriginsProperty | undefined;
        private _accessControlExposeHeaders;
        get accessControlExposeHeaders(): AccessControlExposeHeadersPropertyOutputReference;
        putAccessControlExposeHeaders(value: AccessControlExposeHeadersProperty): void;
        resetAccessControlExposeHeaders(): void;
        get accessControlExposeHeadersInput(): AccessControlExposeHeadersProperty | undefined;
    }
    interface CustomHeadersConfigItemsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#header AwsResponseHeadersPolicy#header}
        */
        readonly header: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#override AwsResponseHeadersPolicy#override}
        */
        readonly override: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#value AwsResponseHeadersPolicy#value}
        */
        readonly value: string;
    }
    class CustomHeadersConfigItemsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomHeadersConfigItemsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CustomHeadersConfigItemsProperty | cdktn.IResolvable | undefined);
        private _header?;
        get header(): string;
        set header(value: string);
        get headerInput(): string | undefined;
        private _override?;
        get override(): boolean | cdktn.IResolvable;
        set override(value: boolean | cdktn.IResolvable);
        get overrideInput(): boolean | cdktn.IResolvable | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class CustomHeadersConfigItemsPropertyList extends cdktn.ComplexList {
        internalValue?: CustomHeadersConfigItemsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomHeadersConfigItemsPropertyOutputReference;
    }
    interface CustomHeadersConfigProperty {
        /**
        * items block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#items AwsResponseHeadersPolicy#items}
        */
        readonly items?: CustomHeadersConfigItemsProperty[] | cdktn.IResolvable;
    }
    class CustomHeadersConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CustomHeadersConfigProperty | undefined;
        set internalValue(value: CustomHeadersConfigProperty | undefined);
        private _items;
        get items(): CustomHeadersConfigItemsPropertyList;
        putItems(value: CustomHeadersConfigItemsProperty[] | cdktn.IResolvable): void;
        resetItems(): void;
        get itemsInput(): cdktn.IResolvable | CustomHeadersConfigItemsProperty[] | undefined;
    }
    interface RemoveHeadersConfigItemsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#header AwsResponseHeadersPolicy#header}
        */
        readonly header: string;
    }
    class RemoveHeadersConfigItemsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RemoveHeadersConfigItemsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RemoveHeadersConfigItemsProperty | cdktn.IResolvable | undefined);
        private _header?;
        get header(): string;
        set header(value: string);
        get headerInput(): string | undefined;
    }
    class RemoveHeadersConfigItemsPropertyList extends cdktn.ComplexList {
        internalValue?: RemoveHeadersConfigItemsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RemoveHeadersConfigItemsPropertyOutputReference;
    }
    interface RemoveHeadersConfigProperty {
        /**
        * items block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#items AwsResponseHeadersPolicy#items}
        */
        readonly items?: RemoveHeadersConfigItemsProperty[] | cdktn.IResolvable;
    }
    class RemoveHeadersConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RemoveHeadersConfigProperty | undefined;
        set internalValue(value: RemoveHeadersConfigProperty | undefined);
        private _items;
        get items(): RemoveHeadersConfigItemsPropertyList;
        putItems(value: RemoveHeadersConfigItemsProperty[] | cdktn.IResolvable): void;
        resetItems(): void;
        get itemsInput(): cdktn.IResolvable | RemoveHeadersConfigItemsProperty[] | undefined;
    }
    interface ContentSecurityPolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#content_security_policy AwsResponseHeadersPolicy#content_security_policy}
        */
        readonly contentSecurityPolicy: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#override AwsResponseHeadersPolicy#override}
        */
        readonly override: boolean | cdktn.IResolvable;
    }
    class ContentSecurityPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ContentSecurityPolicyProperty | undefined;
        set internalValue(value: ContentSecurityPolicyProperty | undefined);
        private _contentSecurityPolicy?;
        get contentSecurityPolicy(): string;
        set contentSecurityPolicy(value: string);
        get contentSecurityPolicyInput(): string | undefined;
        private _override?;
        get override(): boolean | cdktn.IResolvable;
        set override(value: boolean | cdktn.IResolvable);
        get overrideInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface ContentTypeOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#override AwsResponseHeadersPolicy#override}
        */
        readonly override: boolean | cdktn.IResolvable;
    }
    class ContentTypeOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ContentTypeOptionsProperty | undefined;
        set internalValue(value: ContentTypeOptionsProperty | undefined);
        private _override?;
        get override(): boolean | cdktn.IResolvable;
        set override(value: boolean | cdktn.IResolvable);
        get overrideInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface FrameOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#frame_option AwsResponseHeadersPolicy#frame_option}
        */
        readonly frameOption: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#override AwsResponseHeadersPolicy#override}
        */
        readonly override: boolean | cdktn.IResolvable;
    }
    class FrameOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FrameOptionsProperty | undefined;
        set internalValue(value: FrameOptionsProperty | undefined);
        private _frameOption?;
        get frameOption(): string;
        set frameOption(value: string);
        get frameOptionInput(): string | undefined;
        private _override?;
        get override(): boolean | cdktn.IResolvable;
        set override(value: boolean | cdktn.IResolvable);
        get overrideInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface ReferrerPolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#override AwsResponseHeadersPolicy#override}
        */
        readonly override: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#referrer_policy AwsResponseHeadersPolicy#referrer_policy}
        */
        readonly referrerPolicy: string;
    }
    class ReferrerPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ReferrerPolicyProperty | undefined;
        set internalValue(value: ReferrerPolicyProperty | undefined);
        private _override?;
        get override(): boolean | cdktn.IResolvable;
        set override(value: boolean | cdktn.IResolvable);
        get overrideInput(): boolean | cdktn.IResolvable | undefined;
        private _referrerPolicy?;
        get referrerPolicy(): string;
        set referrerPolicy(value: string);
        get referrerPolicyInput(): string | undefined;
    }
    interface StrictTransportSecurityProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#access_control_max_age_sec AwsResponseHeadersPolicy#access_control_max_age_sec}
        */
        readonly accessControlMaxAgeSec: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#include_subdomains AwsResponseHeadersPolicy#include_subdomains}
        */
        readonly includeSubdomains?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#override AwsResponseHeadersPolicy#override}
        */
        readonly override: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#preload AwsResponseHeadersPolicy#preload}
        */
        readonly preload?: boolean | cdktn.IResolvable;
    }
    class StrictTransportSecurityPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StrictTransportSecurityProperty | undefined;
        set internalValue(value: StrictTransportSecurityProperty | undefined);
        private _accessControlMaxAgeSec?;
        get accessControlMaxAgeSec(): number;
        set accessControlMaxAgeSec(value: number);
        get accessControlMaxAgeSecInput(): number | undefined;
        private _includeSubdomains?;
        get includeSubdomains(): boolean | cdktn.IResolvable;
        set includeSubdomains(value: boolean | cdktn.IResolvable);
        resetIncludeSubdomains(): void;
        get includeSubdomainsInput(): boolean | cdktn.IResolvable | undefined;
        private _override?;
        get override(): boolean | cdktn.IResolvable;
        set override(value: boolean | cdktn.IResolvable);
        get overrideInput(): boolean | cdktn.IResolvable | undefined;
        private _preload?;
        get preload(): boolean | cdktn.IResolvable;
        set preload(value: boolean | cdktn.IResolvable);
        resetPreload(): void;
        get preloadInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface XssProtectionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#mode_block AwsResponseHeadersPolicy#mode_block}
        */
        readonly modeBlock?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#override AwsResponseHeadersPolicy#override}
        */
        readonly override: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#protection AwsResponseHeadersPolicy#protection}
        */
        readonly protection: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#report_uri AwsResponseHeadersPolicy#report_uri}
        */
        readonly reportUri?: string;
    }
    class XssProtectionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): XssProtectionProperty | undefined;
        set internalValue(value: XssProtectionProperty | undefined);
        private _modeBlock?;
        get modeBlock(): boolean | cdktn.IResolvable;
        set modeBlock(value: boolean | cdktn.IResolvable);
        resetModeBlock(): void;
        get modeBlockInput(): boolean | cdktn.IResolvable | undefined;
        private _override?;
        get override(): boolean | cdktn.IResolvable;
        set override(value: boolean | cdktn.IResolvable);
        get overrideInput(): boolean | cdktn.IResolvable | undefined;
        private _protection?;
        get protection(): boolean | cdktn.IResolvable;
        set protection(value: boolean | cdktn.IResolvable);
        get protectionInput(): boolean | cdktn.IResolvable | undefined;
        private _reportUri?;
        get reportUri(): string;
        set reportUri(value: string);
        resetReportUri(): void;
        get reportUriInput(): string | undefined;
    }
    interface SecurityHeadersConfigProperty {
        /**
        * content_security_policy block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#content_security_policy AwsResponseHeadersPolicy#content_security_policy}
        */
        readonly contentSecurityPolicy?: ContentSecurityPolicyProperty;
        /**
        * content_type_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#content_type_options AwsResponseHeadersPolicy#content_type_options}
        */
        readonly contentTypeOptions?: ContentTypeOptionsProperty;
        /**
        * frame_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#frame_options AwsResponseHeadersPolicy#frame_options}
        */
        readonly frameOptions?: FrameOptionsProperty;
        /**
        * referrer_policy block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#referrer_policy AwsResponseHeadersPolicy#referrer_policy}
        */
        readonly referrerPolicy?: ReferrerPolicyProperty;
        /**
        * strict_transport_security block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#strict_transport_security AwsResponseHeadersPolicy#strict_transport_security}
        */
        readonly strictTransportSecurity?: StrictTransportSecurityProperty;
        /**
        * xss_protection block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#xss_protection AwsResponseHeadersPolicy#xss_protection}
        */
        readonly xssProtection?: XssProtectionProperty;
    }
    class SecurityHeadersConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SecurityHeadersConfigProperty | undefined;
        set internalValue(value: SecurityHeadersConfigProperty | undefined);
        private _contentSecurityPolicy;
        get contentSecurityPolicy(): ContentSecurityPolicyPropertyOutputReference;
        putContentSecurityPolicy(value: ContentSecurityPolicyProperty): void;
        resetContentSecurityPolicy(): void;
        get contentSecurityPolicyInput(): ContentSecurityPolicyProperty | undefined;
        private _contentTypeOptions;
        get contentTypeOptions(): ContentTypeOptionsPropertyOutputReference;
        putContentTypeOptions(value: ContentTypeOptionsProperty): void;
        resetContentTypeOptions(): void;
        get contentTypeOptionsInput(): ContentTypeOptionsProperty | undefined;
        private _frameOptions;
        get frameOptions(): FrameOptionsPropertyOutputReference;
        putFrameOptions(value: FrameOptionsProperty): void;
        resetFrameOptions(): void;
        get frameOptionsInput(): FrameOptionsProperty | undefined;
        private _referrerPolicy;
        get referrerPolicy(): ReferrerPolicyPropertyOutputReference;
        putReferrerPolicy(value: ReferrerPolicyProperty): void;
        resetReferrerPolicy(): void;
        get referrerPolicyInput(): ReferrerPolicyProperty | undefined;
        private _strictTransportSecurity;
        get strictTransportSecurity(): StrictTransportSecurityPropertyOutputReference;
        putStrictTransportSecurity(value: StrictTransportSecurityProperty): void;
        resetStrictTransportSecurity(): void;
        get strictTransportSecurityInput(): StrictTransportSecurityProperty | undefined;
        private _xssProtection;
        get xssProtection(): XssProtectionPropertyOutputReference;
        putXssProtection(value: XssProtectionProperty): void;
        resetXssProtection(): void;
        get xssProtectionInput(): XssProtectionProperty | undefined;
    }
    interface ServerTimingHeadersConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#enabled AwsResponseHeadersPolicy#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#sampling_rate AwsResponseHeadersPolicy#sampling_rate}
        */
        readonly samplingRate: number;
    }
    class ServerTimingHeadersConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ServerTimingHeadersConfigProperty | undefined;
        set internalValue(value: ServerTimingHeadersConfigProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _samplingRate?;
        get samplingRate(): number;
        set samplingRate(value: number);
        get samplingRateInput(): number | undefined;
    }
}
