import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAnycastIpListConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_anycast_ip_list#ip_count AwsAnycastIpList#ip_count}
    */
    readonly ipCount: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_anycast_ip_list#name AwsAnycastIpList#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_anycast_ip_list#tags AwsAnycastIpList#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_anycast_ip_list#timeouts AwsAnycastIpList#timeouts}
    */
    readonly timeouts?: AwsAnycastIpList.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_anycast_ip_list aws_cloudfront_anycast_ip_list}
*/
export declare class AwsAnycastIpList extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudfront_anycast_ip_list";
    /**
    * Generates CDKTN code for importing a AwsAnycastIpList resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsAnycastIpList to import
    * @param importFromId The id of the existing AwsAnycastIpList that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_anycast_ip_list#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsAnycastIpList to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_anycast_ip_list aws_cloudfront_anycast_ip_list} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAnycastIpListConfig
    */
    constructor(scope: Construct, id: string, config: AwsAnycastIpListConfig);
    get anycastIps(): string[];
    get arn(): string;
    get etag(): string;
    get id(): string;
    private _ipCount?;
    get ipCount(): number;
    set ipCount(value: number);
    get ipCountInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _timeouts;
    get timeouts(): AwsAnycastIpList.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsAnycastIpList.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): AwsAnycastIpList.TimeoutsProperty | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsAnycastIpListTimeoutsPropertyToTerraform(struct?: AwsAnycastIpList.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsAnycastIpListTimeoutsPropertyToHclTerraform(struct?: AwsAnycastIpList.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsAnycastIpList {
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_anycast_ip_list#create AwsAnycastIpList#create}
        */
        readonly create?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
    }
}
