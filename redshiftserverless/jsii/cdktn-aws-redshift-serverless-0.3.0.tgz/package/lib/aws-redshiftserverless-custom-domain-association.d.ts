import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsCustomDomainAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshiftserverless_custom_domain_association#custom_domain_certificate_arn AwsCustomDomainAssociation#custom_domain_certificate_arn}
    */
    readonly customDomainCertificateArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshiftserverless_custom_domain_association#custom_domain_name AwsCustomDomainAssociation#custom_domain_name}
    */
    readonly customDomainName: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshiftserverless_custom_domain_association#region AwsCustomDomainAssociation#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshiftserverless_custom_domain_association#workgroup_name AwsCustomDomainAssociation#workgroup_name}
    */
    readonly workgroupName: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshiftserverless_custom_domain_association aws_redshiftserverless_custom_domain_association}
*/
export declare class AwsCustomDomainAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_redshiftserverless_custom_domain_association";
    /**
    * Generates CDKTN code for importing a AwsCustomDomainAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsCustomDomainAssociation to import
    * @param importFromId The id of the existing AwsCustomDomainAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshiftserverless_custom_domain_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsCustomDomainAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshiftserverless_custom_domain_association aws_redshiftserverless_custom_domain_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsCustomDomainAssociationConfig
    */
    constructor(scope: Construct, id: string, config: AwsCustomDomainAssociationConfig);
    private _customDomainCertificateArn?;
    get customDomainCertificateArn(): string;
    set customDomainCertificateArn(value: string);
    get customDomainCertificateArnInput(): string | undefined;
    get customDomainCertificateExpiryTime(): string;
    private _customDomainName?;
    get customDomainName(): string;
    set customDomainName(value: string);
    get customDomainNameInput(): string | undefined;
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _workgroupName?;
    get workgroupName(): string;
    set workgroupName(value: string);
    get workgroupNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
