import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsWorkgroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/redshiftserverless_workgroup#id DataAwsWorkgroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/redshiftserverless_workgroup#region DataAwsWorkgroup#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/redshiftserverless_workgroup#workgroup_name DataAwsWorkgroup#workgroup_name}
    */
    readonly workgroupName: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/redshiftserverless_workgroup aws_redshiftserverless_workgroup}
*/
export declare class DataAwsWorkgroup extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_redshiftserverless_workgroup";
    /**
    * Generates CDKTN code for importing a DataAwsWorkgroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsWorkgroup to import
    * @param importFromId The id of the existing DataAwsWorkgroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/redshiftserverless_workgroup#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsWorkgroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/redshiftserverless_workgroup aws_redshiftserverless_workgroup} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsWorkgroupConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsWorkgroupConfig);
    get arn(): string;
    private _endpoint;
    get endpoint(): DataAwsWorkgroup.EndpointPropertyList;
    get enhancedVpcRouting(): cdktn.IResolvable;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get namespaceName(): string;
    get publiclyAccessible(): cdktn.IResolvable;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get securityGroupIds(): string[];
    get subnetIds(): string[];
    get trackName(): string;
    get workgroupId(): string;
    private _workgroupName?;
    get workgroupName(): string;
    set workgroupName(value: string);
    get workgroupNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsWorkgroupNetworkInterfacePropertyToTerraform(struct?: DataAwsWorkgroup.NetworkInterfaceProperty): any;
export declare function dataAwsWorkgroupNetworkInterfacePropertyToHclTerraform(struct?: DataAwsWorkgroup.NetworkInterfaceProperty): any;
export declare function dataAwsWorkgroupVpcEndpointPropertyToTerraform(struct?: DataAwsWorkgroup.VpcEndpointProperty): any;
export declare function dataAwsWorkgroupVpcEndpointPropertyToHclTerraform(struct?: DataAwsWorkgroup.VpcEndpointProperty): any;
export declare function dataAwsWorkgroupEndpointPropertyToTerraform(struct?: DataAwsWorkgroup.EndpointProperty): any;
export declare function dataAwsWorkgroupEndpointPropertyToHclTerraform(struct?: DataAwsWorkgroup.EndpointProperty): any;
export declare namespace DataAwsWorkgroup {
    interface NetworkInterfaceProperty {
    }
    class NetworkInterfacePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NetworkInterfaceProperty | undefined;
        set internalValue(value: NetworkInterfaceProperty | undefined);
        get availabilityZone(): string;
        get networkInterfaceId(): string;
        get privateIpAddress(): string;
        get subnetId(): string;
    }
    class NetworkInterfacePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NetworkInterfacePropertyOutputReference;
    }
    interface VpcEndpointProperty {
    }
    class VpcEndpointPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VpcEndpointProperty | undefined;
        set internalValue(value: VpcEndpointProperty | undefined);
        private _networkInterface;
        get networkInterface(): NetworkInterfacePropertyList;
        get vpcEndpointId(): string;
        get vpcId(): string;
    }
    class VpcEndpointPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VpcEndpointPropertyOutputReference;
    }
    interface EndpointProperty {
    }
    class EndpointPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EndpointProperty | undefined;
        set internalValue(value: EndpointProperty | undefined);
        get address(): string;
        get port(): number;
        private _vpcEndpoint;
        get vpcEndpoint(): VpcEndpointPropertyList;
    }
    class EndpointPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EndpointPropertyOutputReference;
    }
}
