import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfIntentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#create_version TfIntent#create_version}
    */
    readonly createVersion?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#description TfIntent#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#id TfIntent#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#name TfIntent#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#parent_intent_signature TfIntent#parent_intent_signature}
    */
    readonly parentIntentSignature?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#region TfIntent#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#sample_utterances TfIntent#sample_utterances}
    */
    readonly sampleUtterances?: string[];
    /**
    * conclusion_statement block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#conclusion_statement TfIntent#conclusion_statement}
    */
    readonly conclusionStatement?: TfIntent.ConclusionStatementProperty;
    /**
    * confirmation_prompt block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#confirmation_prompt TfIntent#confirmation_prompt}
    */
    readonly confirmationPrompt?: TfIntent.ConfirmationPromptProperty;
    /**
    * dialog_code_hook block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#dialog_code_hook TfIntent#dialog_code_hook}
    */
    readonly dialogCodeHook?: TfIntent.DialogCodeHookProperty;
    /**
    * follow_up_prompt block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#follow_up_prompt TfIntent#follow_up_prompt}
    */
    readonly followUpPrompt?: TfIntent.FollowUpPromptProperty;
    /**
    * fulfillment_activity block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#fulfillment_activity TfIntent#fulfillment_activity}
    */
    readonly fulfillmentActivity: TfIntent.FulfillmentActivityProperty;
    /**
    * rejection_statement block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#rejection_statement TfIntent#rejection_statement}
    */
    readonly rejectionStatement?: TfIntent.RejectionStatementProperty;
    /**
    * slot block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#slot TfIntent#slot}
    */
    readonly slot?: TfIntent.SlotProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#timeouts TfIntent#timeouts}
    */
    readonly timeouts?: TfIntent.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent aws_lex_intent}
*/
export declare class TfIntent extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_lex_intent";
    /**
    * Generates CDKTN code for importing a TfIntent resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfIntent to import
    * @param importFromId The id of the existing TfIntent that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfIntent to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent aws_lex_intent} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfIntentConfig
    */
    constructor(scope: Construct, id: string, config: TfIntentConfig);
    get arn(): string;
    get checksum(): string;
    private _createVersion?;
    get createVersion(): boolean | cdktn.IResolvable;
    set createVersion(value: boolean | cdktn.IResolvable);
    resetCreateVersion(): void;
    get createVersionInput(): boolean | cdktn.IResolvable | undefined;
    get createdDate(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastUpdatedDate(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parentIntentSignature?;
    get parentIntentSignature(): string;
    set parentIntentSignature(value: string);
    resetParentIntentSignature(): void;
    get parentIntentSignatureInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _sampleUtterances?;
    get sampleUtterances(): string[];
    set sampleUtterances(value: string[]);
    resetSampleUtterances(): void;
    get sampleUtterancesInput(): string[] | undefined;
    get version(): string;
    private _conclusionStatement;
    get conclusionStatement(): TfIntent.ConclusionStatementPropertyOutputReference;
    putConclusionStatement(value: TfIntent.ConclusionStatementProperty): void;
    resetConclusionStatement(): void;
    get conclusionStatementInput(): TfIntent.ConclusionStatementProperty | undefined;
    private _confirmationPrompt;
    get confirmationPrompt(): TfIntent.ConfirmationPromptPropertyOutputReference;
    putConfirmationPrompt(value: TfIntent.ConfirmationPromptProperty): void;
    resetConfirmationPrompt(): void;
    get confirmationPromptInput(): TfIntent.ConfirmationPromptProperty | undefined;
    private _dialogCodeHook;
    get dialogCodeHook(): TfIntent.DialogCodeHookPropertyOutputReference;
    putDialogCodeHook(value: TfIntent.DialogCodeHookProperty): void;
    resetDialogCodeHook(): void;
    get dialogCodeHookInput(): TfIntent.DialogCodeHookProperty | undefined;
    private _followUpPrompt;
    get followUpPrompt(): TfIntent.FollowUpPromptPropertyOutputReference;
    putFollowUpPrompt(value: TfIntent.FollowUpPromptProperty): void;
    resetFollowUpPrompt(): void;
    get followUpPromptInput(): TfIntent.FollowUpPromptProperty | undefined;
    private _fulfillmentActivity;
    get fulfillmentActivity(): TfIntent.FulfillmentActivityPropertyOutputReference;
    putFulfillmentActivity(value: TfIntent.FulfillmentActivityProperty): void;
    get fulfillmentActivityInput(): TfIntent.FulfillmentActivityProperty | undefined;
    private _rejectionStatement;
    get rejectionStatement(): TfIntent.RejectionStatementPropertyOutputReference;
    putRejectionStatement(value: TfIntent.RejectionStatementProperty): void;
    resetRejectionStatement(): void;
    get rejectionStatementInput(): TfIntent.RejectionStatementProperty | undefined;
    private _slot;
    get slot(): TfIntent.SlotPropertyList;
    putSlot(value: TfIntent.SlotProperty[] | cdktn.IResolvable): void;
    resetSlot(): void;
    get slotInput(): cdktn.IResolvable | TfIntent.SlotProperty[] | undefined;
    private _timeouts;
    get timeouts(): TfIntent.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfIntent.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfIntent.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfIntentConclusionStatementMessagePropertyToTerraform(struct?: TfIntent.ConclusionStatementMessageProperty | cdktn.IResolvable): any;
export declare function tfIntentConclusionStatementMessagePropertyToHclTerraform(struct?: TfIntent.ConclusionStatementMessageProperty | cdktn.IResolvable): any;
export declare function tfIntentConclusionStatementPropertyToTerraform(struct?: TfIntent.ConclusionStatementPropertyOutputReference | TfIntent.ConclusionStatementProperty): any;
export declare function tfIntentConclusionStatementPropertyToHclTerraform(struct?: TfIntent.ConclusionStatementPropertyOutputReference | TfIntent.ConclusionStatementProperty): any;
export declare function tfIntentConfirmationPromptMessagePropertyToTerraform(struct?: TfIntent.ConfirmationPromptMessageProperty | cdktn.IResolvable): any;
export declare function tfIntentConfirmationPromptMessagePropertyToHclTerraform(struct?: TfIntent.ConfirmationPromptMessageProperty | cdktn.IResolvable): any;
export declare function tfIntentConfirmationPromptPropertyToTerraform(struct?: TfIntent.ConfirmationPromptPropertyOutputReference | TfIntent.ConfirmationPromptProperty): any;
export declare function tfIntentConfirmationPromptPropertyToHclTerraform(struct?: TfIntent.ConfirmationPromptPropertyOutputReference | TfIntent.ConfirmationPromptProperty): any;
export declare function tfIntentDialogCodeHookPropertyToTerraform(struct?: TfIntent.DialogCodeHookPropertyOutputReference | TfIntent.DialogCodeHookProperty): any;
export declare function tfIntentDialogCodeHookPropertyToHclTerraform(struct?: TfIntent.DialogCodeHookPropertyOutputReference | TfIntent.DialogCodeHookProperty): any;
export declare function tfIntentFollowUpPromptPromptMessagePropertyToTerraform(struct?: TfIntent.FollowUpPromptPromptMessageProperty | cdktn.IResolvable): any;
export declare function tfIntentFollowUpPromptPromptMessagePropertyToHclTerraform(struct?: TfIntent.FollowUpPromptPromptMessageProperty | cdktn.IResolvable): any;
export declare function tfIntentPromptPropertyToTerraform(struct?: TfIntent.PromptPropertyOutputReference | TfIntent.PromptProperty): any;
export declare function tfIntentPromptPropertyToHclTerraform(struct?: TfIntent.PromptPropertyOutputReference | TfIntent.PromptProperty): any;
export declare function tfIntentFollowUpPromptRejectionStatementMessagePropertyToTerraform(struct?: TfIntent.FollowUpPromptRejectionStatementMessageProperty | cdktn.IResolvable): any;
export declare function tfIntentFollowUpPromptRejectionStatementMessagePropertyToHclTerraform(struct?: TfIntent.FollowUpPromptRejectionStatementMessageProperty | cdktn.IResolvable): any;
export declare function tfIntentFollowUpPromptRejectionStatementPropertyToTerraform(struct?: TfIntent.FollowUpPromptRejectionStatementPropertyOutputReference | TfIntent.FollowUpPromptRejectionStatementProperty): any;
export declare function tfIntentFollowUpPromptRejectionStatementPropertyToHclTerraform(struct?: TfIntent.FollowUpPromptRejectionStatementPropertyOutputReference | TfIntent.FollowUpPromptRejectionStatementProperty): any;
export declare function tfIntentFollowUpPromptPropertyToTerraform(struct?: TfIntent.FollowUpPromptPropertyOutputReference | TfIntent.FollowUpPromptProperty): any;
export declare function tfIntentFollowUpPromptPropertyToHclTerraform(struct?: TfIntent.FollowUpPromptPropertyOutputReference | TfIntent.FollowUpPromptProperty): any;
export declare function tfIntentCodeHookPropertyToTerraform(struct?: TfIntent.CodeHookPropertyOutputReference | TfIntent.CodeHookProperty): any;
export declare function tfIntentCodeHookPropertyToHclTerraform(struct?: TfIntent.CodeHookPropertyOutputReference | TfIntent.CodeHookProperty): any;
export declare function tfIntentFulfillmentActivityPropertyToTerraform(struct?: TfIntent.FulfillmentActivityPropertyOutputReference | TfIntent.FulfillmentActivityProperty): any;
export declare function tfIntentFulfillmentActivityPropertyToHclTerraform(struct?: TfIntent.FulfillmentActivityPropertyOutputReference | TfIntent.FulfillmentActivityProperty): any;
export declare function tfIntentRejectionStatementMessagePropertyToTerraform(struct?: TfIntent.RejectionStatementMessageProperty | cdktn.IResolvable): any;
export declare function tfIntentRejectionStatementMessagePropertyToHclTerraform(struct?: TfIntent.RejectionStatementMessageProperty | cdktn.IResolvable): any;
export declare function tfIntentRejectionStatementPropertyToTerraform(struct?: TfIntent.RejectionStatementPropertyOutputReference | TfIntent.RejectionStatementProperty): any;
export declare function tfIntentRejectionStatementPropertyToHclTerraform(struct?: TfIntent.RejectionStatementPropertyOutputReference | TfIntent.RejectionStatementProperty): any;
export declare function tfIntentSlotValueElicitationPromptMessagePropertyToTerraform(struct?: TfIntent.SlotValueElicitationPromptMessageProperty | cdktn.IResolvable): any;
export declare function tfIntentSlotValueElicitationPromptMessagePropertyToHclTerraform(struct?: TfIntent.SlotValueElicitationPromptMessageProperty | cdktn.IResolvable): any;
export declare function tfIntentValueElicitationPromptPropertyToTerraform(struct?: TfIntent.ValueElicitationPromptPropertyOutputReference | TfIntent.ValueElicitationPromptProperty): any;
export declare function tfIntentValueElicitationPromptPropertyToHclTerraform(struct?: TfIntent.ValueElicitationPromptPropertyOutputReference | TfIntent.ValueElicitationPromptProperty): any;
export declare function tfIntentSlotPropertyToTerraform(struct?: TfIntent.SlotProperty | cdktn.IResolvable): any;
export declare function tfIntentSlotPropertyToHclTerraform(struct?: TfIntent.SlotProperty | cdktn.IResolvable): any;
export declare function tfIntentTimeoutsPropertyToTerraform(struct?: TfIntent.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfIntentTimeoutsPropertyToHclTerraform(struct?: TfIntent.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfIntent {
    interface ConclusionStatementMessageProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#content TfIntent#content}
        */
        readonly content: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#content_type TfIntent#content_type}
        */
        readonly contentType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#group_number TfIntent#group_number}
        */
        readonly groupNumber?: number;
    }
    class ConclusionStatementMessagePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConclusionStatementMessageProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConclusionStatementMessageProperty | cdktn.IResolvable | undefined);
        private _content?;
        get content(): string;
        set content(value: string);
        get contentInput(): string | undefined;
        private _contentType?;
        get contentType(): string;
        set contentType(value: string);
        get contentTypeInput(): string | undefined;
        private _groupNumber?;
        get groupNumber(): number;
        set groupNumber(value: number);
        resetGroupNumber(): void;
        get groupNumberInput(): number | undefined;
    }
    class ConclusionStatementMessagePropertyList extends cdktn.ComplexList {
        internalValue?: ConclusionStatementMessageProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConclusionStatementMessagePropertyOutputReference;
    }
    interface ConclusionStatementProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#response_card TfIntent#response_card}
        */
        readonly responseCard?: string;
        /**
        * message block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#message TfIntent#message}
        */
        readonly message: ConclusionStatementMessageProperty[] | cdktn.IResolvable;
    }
    class ConclusionStatementPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConclusionStatementProperty | undefined;
        set internalValue(value: ConclusionStatementProperty | undefined);
        private _responseCard?;
        get responseCard(): string;
        set responseCard(value: string);
        resetResponseCard(): void;
        get responseCardInput(): string | undefined;
        private _message;
        get message(): ConclusionStatementMessagePropertyList;
        putMessage(value: ConclusionStatementMessageProperty[] | cdktn.IResolvable): void;
        get messageInput(): cdktn.IResolvable | ConclusionStatementMessageProperty[] | undefined;
    }
    interface ConfirmationPromptMessageProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#content TfIntent#content}
        */
        readonly content: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#content_type TfIntent#content_type}
        */
        readonly contentType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#group_number TfIntent#group_number}
        */
        readonly groupNumber?: number;
    }
    class ConfirmationPromptMessagePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConfirmationPromptMessageProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConfirmationPromptMessageProperty | cdktn.IResolvable | undefined);
        private _content?;
        get content(): string;
        set content(value: string);
        get contentInput(): string | undefined;
        private _contentType?;
        get contentType(): string;
        set contentType(value: string);
        get contentTypeInput(): string | undefined;
        private _groupNumber?;
        get groupNumber(): number;
        set groupNumber(value: number);
        resetGroupNumber(): void;
        get groupNumberInput(): number | undefined;
    }
    class ConfirmationPromptMessagePropertyList extends cdktn.ComplexList {
        internalValue?: ConfirmationPromptMessageProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConfirmationPromptMessagePropertyOutputReference;
    }
    interface ConfirmationPromptProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#max_attempts TfIntent#max_attempts}
        */
        readonly maxAttempts: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#response_card TfIntent#response_card}
        */
        readonly responseCard?: string;
        /**
        * message block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#message TfIntent#message}
        */
        readonly message: ConfirmationPromptMessageProperty[] | cdktn.IResolvable;
    }
    class ConfirmationPromptPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConfirmationPromptProperty | undefined;
        set internalValue(value: ConfirmationPromptProperty | undefined);
        private _maxAttempts?;
        get maxAttempts(): number;
        set maxAttempts(value: number);
        get maxAttemptsInput(): number | undefined;
        private _responseCard?;
        get responseCard(): string;
        set responseCard(value: string);
        resetResponseCard(): void;
        get responseCardInput(): string | undefined;
        private _message;
        get message(): ConfirmationPromptMessagePropertyList;
        putMessage(value: ConfirmationPromptMessageProperty[] | cdktn.IResolvable): void;
        get messageInput(): cdktn.IResolvable | ConfirmationPromptMessageProperty[] | undefined;
    }
    interface DialogCodeHookProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#message_version TfIntent#message_version}
        */
        readonly messageVersion: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#uri TfIntent#uri}
        */
        readonly uri: string;
    }
    class DialogCodeHookPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DialogCodeHookProperty | undefined;
        set internalValue(value: DialogCodeHookProperty | undefined);
        private _messageVersion?;
        get messageVersion(): string;
        set messageVersion(value: string);
        get messageVersionInput(): string | undefined;
        private _uri?;
        get uri(): string;
        set uri(value: string);
        get uriInput(): string | undefined;
    }
    interface FollowUpPromptPromptMessageProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#content TfIntent#content}
        */
        readonly content: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#content_type TfIntent#content_type}
        */
        readonly contentType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#group_number TfIntent#group_number}
        */
        readonly groupNumber?: number;
    }
    class FollowUpPromptPromptMessagePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FollowUpPromptPromptMessageProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FollowUpPromptPromptMessageProperty | cdktn.IResolvable | undefined);
        private _content?;
        get content(): string;
        set content(value: string);
        get contentInput(): string | undefined;
        private _contentType?;
        get contentType(): string;
        set contentType(value: string);
        get contentTypeInput(): string | undefined;
        private _groupNumber?;
        get groupNumber(): number;
        set groupNumber(value: number);
        resetGroupNumber(): void;
        get groupNumberInput(): number | undefined;
    }
    class FollowUpPromptPromptMessagePropertyList extends cdktn.ComplexList {
        internalValue?: FollowUpPromptPromptMessageProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FollowUpPromptPromptMessagePropertyOutputReference;
    }
    interface PromptProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#max_attempts TfIntent#max_attempts}
        */
        readonly maxAttempts: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#response_card TfIntent#response_card}
        */
        readonly responseCard?: string;
        /**
        * message block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#message TfIntent#message}
        */
        readonly message: FollowUpPromptPromptMessageProperty[] | cdktn.IResolvable;
    }
    class PromptPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PromptProperty | undefined;
        set internalValue(value: PromptProperty | undefined);
        private _maxAttempts?;
        get maxAttempts(): number;
        set maxAttempts(value: number);
        get maxAttemptsInput(): number | undefined;
        private _responseCard?;
        get responseCard(): string;
        set responseCard(value: string);
        resetResponseCard(): void;
        get responseCardInput(): string | undefined;
        private _message;
        get message(): FollowUpPromptPromptMessagePropertyList;
        putMessage(value: FollowUpPromptPromptMessageProperty[] | cdktn.IResolvable): void;
        get messageInput(): cdktn.IResolvable | FollowUpPromptPromptMessageProperty[] | undefined;
    }
    interface FollowUpPromptRejectionStatementMessageProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#content TfIntent#content}
        */
        readonly content: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#content_type TfIntent#content_type}
        */
        readonly contentType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#group_number TfIntent#group_number}
        */
        readonly groupNumber?: number;
    }
    class FollowUpPromptRejectionStatementMessagePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FollowUpPromptRejectionStatementMessageProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FollowUpPromptRejectionStatementMessageProperty | cdktn.IResolvable | undefined);
        private _content?;
        get content(): string;
        set content(value: string);
        get contentInput(): string | undefined;
        private _contentType?;
        get contentType(): string;
        set contentType(value: string);
        get contentTypeInput(): string | undefined;
        private _groupNumber?;
        get groupNumber(): number;
        set groupNumber(value: number);
        resetGroupNumber(): void;
        get groupNumberInput(): number | undefined;
    }
    class FollowUpPromptRejectionStatementMessagePropertyList extends cdktn.ComplexList {
        internalValue?: FollowUpPromptRejectionStatementMessageProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FollowUpPromptRejectionStatementMessagePropertyOutputReference;
    }
    interface FollowUpPromptRejectionStatementProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#response_card TfIntent#response_card}
        */
        readonly responseCard?: string;
        /**
        * message block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#message TfIntent#message}
        */
        readonly message: FollowUpPromptRejectionStatementMessageProperty[] | cdktn.IResolvable;
    }
    class FollowUpPromptRejectionStatementPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FollowUpPromptRejectionStatementProperty | undefined;
        set internalValue(value: FollowUpPromptRejectionStatementProperty | undefined);
        private _responseCard?;
        get responseCard(): string;
        set responseCard(value: string);
        resetResponseCard(): void;
        get responseCardInput(): string | undefined;
        private _message;
        get message(): FollowUpPromptRejectionStatementMessagePropertyList;
        putMessage(value: FollowUpPromptRejectionStatementMessageProperty[] | cdktn.IResolvable): void;
        get messageInput(): cdktn.IResolvable | FollowUpPromptRejectionStatementMessageProperty[] | undefined;
    }
    interface FollowUpPromptProperty {
        /**
        * prompt block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#prompt TfIntent#prompt}
        */
        readonly prompt: PromptProperty;
        /**
        * rejection_statement block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#rejection_statement TfIntent#rejection_statement}
        */
        readonly rejectionStatement: FollowUpPromptRejectionStatementProperty;
    }
    class FollowUpPromptPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FollowUpPromptProperty | undefined;
        set internalValue(value: FollowUpPromptProperty | undefined);
        private _prompt;
        get prompt(): PromptPropertyOutputReference;
        putPrompt(value: PromptProperty): void;
        get promptInput(): PromptProperty | undefined;
        private _rejectionStatement;
        get rejectionStatement(): FollowUpPromptRejectionStatementPropertyOutputReference;
        putRejectionStatement(value: FollowUpPromptRejectionStatementProperty): void;
        get rejectionStatementInput(): FollowUpPromptRejectionStatementProperty | undefined;
    }
    interface CodeHookProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#message_version TfIntent#message_version}
        */
        readonly messageVersion: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#uri TfIntent#uri}
        */
        readonly uri: string;
    }
    class CodeHookPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CodeHookProperty | undefined;
        set internalValue(value: CodeHookProperty | undefined);
        private _messageVersion?;
        get messageVersion(): string;
        set messageVersion(value: string);
        get messageVersionInput(): string | undefined;
        private _uri?;
        get uri(): string;
        set uri(value: string);
        get uriInput(): string | undefined;
    }
    interface FulfillmentActivityProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#type TfIntent#type}
        */
        readonly type: string;
        /**
        * code_hook block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#code_hook TfIntent#code_hook}
        */
        readonly codeHook?: CodeHookProperty;
    }
    class FulfillmentActivityPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FulfillmentActivityProperty | undefined;
        set internalValue(value: FulfillmentActivityProperty | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _codeHook;
        get codeHook(): CodeHookPropertyOutputReference;
        putCodeHook(value: CodeHookProperty): void;
        resetCodeHook(): void;
        get codeHookInput(): CodeHookProperty | undefined;
    }
    interface RejectionStatementMessageProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#content TfIntent#content}
        */
        readonly content: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#content_type TfIntent#content_type}
        */
        readonly contentType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#group_number TfIntent#group_number}
        */
        readonly groupNumber?: number;
    }
    class RejectionStatementMessagePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RejectionStatementMessageProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RejectionStatementMessageProperty | cdktn.IResolvable | undefined);
        private _content?;
        get content(): string;
        set content(value: string);
        get contentInput(): string | undefined;
        private _contentType?;
        get contentType(): string;
        set contentType(value: string);
        get contentTypeInput(): string | undefined;
        private _groupNumber?;
        get groupNumber(): number;
        set groupNumber(value: number);
        resetGroupNumber(): void;
        get groupNumberInput(): number | undefined;
    }
    class RejectionStatementMessagePropertyList extends cdktn.ComplexList {
        internalValue?: RejectionStatementMessageProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RejectionStatementMessagePropertyOutputReference;
    }
    interface RejectionStatementProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#response_card TfIntent#response_card}
        */
        readonly responseCard?: string;
        /**
        * message block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#message TfIntent#message}
        */
        readonly message: RejectionStatementMessageProperty[] | cdktn.IResolvable;
    }
    class RejectionStatementPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RejectionStatementProperty | undefined;
        set internalValue(value: RejectionStatementProperty | undefined);
        private _responseCard?;
        get responseCard(): string;
        set responseCard(value: string);
        resetResponseCard(): void;
        get responseCardInput(): string | undefined;
        private _message;
        get message(): RejectionStatementMessagePropertyList;
        putMessage(value: RejectionStatementMessageProperty[] | cdktn.IResolvable): void;
        get messageInput(): cdktn.IResolvable | RejectionStatementMessageProperty[] | undefined;
    }
    interface SlotValueElicitationPromptMessageProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#content TfIntent#content}
        */
        readonly content: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#content_type TfIntent#content_type}
        */
        readonly contentType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#group_number TfIntent#group_number}
        */
        readonly groupNumber?: number;
    }
    class SlotValueElicitationPromptMessagePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SlotValueElicitationPromptMessageProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SlotValueElicitationPromptMessageProperty | cdktn.IResolvable | undefined);
        private _content?;
        get content(): string;
        set content(value: string);
        get contentInput(): string | undefined;
        private _contentType?;
        get contentType(): string;
        set contentType(value: string);
        get contentTypeInput(): string | undefined;
        private _groupNumber?;
        get groupNumber(): number;
        set groupNumber(value: number);
        resetGroupNumber(): void;
        get groupNumberInput(): number | undefined;
    }
    class SlotValueElicitationPromptMessagePropertyList extends cdktn.ComplexList {
        internalValue?: SlotValueElicitationPromptMessageProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SlotValueElicitationPromptMessagePropertyOutputReference;
    }
    interface ValueElicitationPromptProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#max_attempts TfIntent#max_attempts}
        */
        readonly maxAttempts: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#response_card TfIntent#response_card}
        */
        readonly responseCard?: string;
        /**
        * message block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#message TfIntent#message}
        */
        readonly message: SlotValueElicitationPromptMessageProperty[] | cdktn.IResolvable;
    }
    class ValueElicitationPromptPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ValueElicitationPromptProperty | undefined;
        set internalValue(value: ValueElicitationPromptProperty | undefined);
        private _maxAttempts?;
        get maxAttempts(): number;
        set maxAttempts(value: number);
        get maxAttemptsInput(): number | undefined;
        private _responseCard?;
        get responseCard(): string;
        set responseCard(value: string);
        resetResponseCard(): void;
        get responseCardInput(): string | undefined;
        private _message;
        get message(): SlotValueElicitationPromptMessagePropertyList;
        putMessage(value: SlotValueElicitationPromptMessageProperty[] | cdktn.IResolvable): void;
        get messageInput(): cdktn.IResolvable | SlotValueElicitationPromptMessageProperty[] | undefined;
    }
    interface SlotProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#description TfIntent#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#name TfIntent#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#priority TfIntent#priority}
        */
        readonly priority?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#response_card TfIntent#response_card}
        */
        readonly responseCard?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#sample_utterances TfIntent#sample_utterances}
        */
        readonly sampleUtterances?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#slot_constraint TfIntent#slot_constraint}
        */
        readonly slotConstraint: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#slot_type TfIntent#slot_type}
        */
        readonly slotType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#slot_type_version TfIntent#slot_type_version}
        */
        readonly slotTypeVersion?: string;
        /**
        * value_elicitation_prompt block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#value_elicitation_prompt TfIntent#value_elicitation_prompt}
        */
        readonly valueElicitationPrompt?: ValueElicitationPromptProperty;
    }
    class SlotPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SlotProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SlotProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _priority?;
        get priority(): number;
        set priority(value: number);
        resetPriority(): void;
        get priorityInput(): number | undefined;
        private _responseCard?;
        get responseCard(): string;
        set responseCard(value: string);
        resetResponseCard(): void;
        get responseCardInput(): string | undefined;
        private _sampleUtterances?;
        get sampleUtterances(): string[];
        set sampleUtterances(value: string[]);
        resetSampleUtterances(): void;
        get sampleUtterancesInput(): string[] | undefined;
        private _slotConstraint?;
        get slotConstraint(): string;
        set slotConstraint(value: string);
        get slotConstraintInput(): string | undefined;
        private _slotType?;
        get slotType(): string;
        set slotType(value: string);
        get slotTypeInput(): string | undefined;
        private _slotTypeVersion?;
        get slotTypeVersion(): string;
        set slotTypeVersion(value: string);
        resetSlotTypeVersion(): void;
        get slotTypeVersionInput(): string | undefined;
        private _valueElicitationPrompt;
        get valueElicitationPrompt(): ValueElicitationPromptPropertyOutputReference;
        putValueElicitationPrompt(value: ValueElicitationPromptProperty): void;
        resetValueElicitationPrompt(): void;
        get valueElicitationPromptInput(): ValueElicitationPromptProperty | undefined;
    }
    class SlotPropertyList extends cdktn.ComplexList {
        internalValue?: SlotProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SlotPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#create TfIntent#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#delete TfIntent#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#update TfIntent#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
