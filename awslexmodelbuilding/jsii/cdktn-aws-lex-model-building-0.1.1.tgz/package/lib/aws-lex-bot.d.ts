import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsLexBotConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot#child_directed AwsLexBot#child_directed}
    */
    readonly childDirected: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot#create_version AwsLexBot#create_version}
    */
    readonly createVersion?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot#description AwsLexBot#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot#detect_sentiment AwsLexBot#detect_sentiment}
    */
    readonly detectSentiment?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot#enable_model_improvements AwsLexBot#enable_model_improvements}
    */
    readonly enableModelImprovements?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot#id AwsLexBot#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot#idle_session_ttl_in_seconds AwsLexBot#idle_session_ttl_in_seconds}
    */
    readonly idleSessionTtlInSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot#locale AwsLexBot#locale}
    */
    readonly locale?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot#name AwsLexBot#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot#nlu_intent_confidence_threshold AwsLexBot#nlu_intent_confidence_threshold}
    */
    readonly nluIntentConfidenceThreshold?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot#process_behavior AwsLexBot#process_behavior}
    */
    readonly processBehavior?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot#region AwsLexBot#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot#voice_id AwsLexBot#voice_id}
    */
    readonly voiceId?: string;
    /**
    * abort_statement block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot#abort_statement AwsLexBot#abort_statement}
    */
    readonly abortStatement: AwsLexBot.AbortStatementProperty;
    /**
    * clarification_prompt block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot#clarification_prompt AwsLexBot#clarification_prompt}
    */
    readonly clarificationPrompt?: AwsLexBot.ClarificationPromptProperty;
    /**
    * intent block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot#intent AwsLexBot#intent}
    */
    readonly intent: AwsLexBot.IntentProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot#timeouts AwsLexBot#timeouts}
    */
    readonly timeouts?: AwsLexBot.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot aws_lex_bot}
*/
export declare class AwsLexBot extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_lex_bot";
    /**
    * Generates CDKTN code for importing a AwsLexBot resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsLexBot to import
    * @param importFromId The id of the existing AwsLexBot that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsLexBot to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot aws_lex_bot} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsLexBotConfig
    */
    constructor(scope: Construct, id: string, config: AwsLexBotConfig);
    get arn(): string;
    get checksum(): string;
    private _childDirected?;
    get childDirected(): boolean | cdktn.IResolvable;
    set childDirected(value: boolean | cdktn.IResolvable);
    get childDirectedInput(): boolean | cdktn.IResolvable | undefined;
    private _createVersion?;
    get createVersion(): boolean | cdktn.IResolvable;
    set createVersion(value: boolean | cdktn.IResolvable);
    resetCreateVersion(): void;
    get createVersionInput(): boolean | cdktn.IResolvable | undefined;
    get createdDate(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _detectSentiment?;
    get detectSentiment(): boolean | cdktn.IResolvable;
    set detectSentiment(value: boolean | cdktn.IResolvable);
    resetDetectSentiment(): void;
    get detectSentimentInput(): boolean | cdktn.IResolvable | undefined;
    private _enableModelImprovements?;
    get enableModelImprovements(): boolean | cdktn.IResolvable;
    set enableModelImprovements(value: boolean | cdktn.IResolvable);
    resetEnableModelImprovements(): void;
    get enableModelImprovementsInput(): boolean | cdktn.IResolvable | undefined;
    get failureReason(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _idleSessionTtlInSeconds?;
    get idleSessionTtlInSeconds(): number;
    set idleSessionTtlInSeconds(value: number);
    resetIdleSessionTtlInSeconds(): void;
    get idleSessionTtlInSecondsInput(): number | undefined;
    get lastUpdatedDate(): string;
    private _locale?;
    get locale(): string;
    set locale(value: string);
    resetLocale(): void;
    get localeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _nluIntentConfidenceThreshold?;
    get nluIntentConfidenceThreshold(): number;
    set nluIntentConfidenceThreshold(value: number);
    resetNluIntentConfidenceThreshold(): void;
    get nluIntentConfidenceThresholdInput(): number | undefined;
    private _processBehavior?;
    get processBehavior(): string;
    set processBehavior(value: string);
    resetProcessBehavior(): void;
    get processBehaviorInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    get version(): string;
    private _voiceId?;
    get voiceId(): string;
    set voiceId(value: string);
    resetVoiceId(): void;
    get voiceIdInput(): string | undefined;
    private _abortStatement;
    get abortStatement(): AwsLexBot.AbortStatementPropertyOutputReference;
    putAbortStatement(value: AwsLexBot.AbortStatementProperty): void;
    get abortStatementInput(): AwsLexBot.AbortStatementProperty | undefined;
    private _clarificationPrompt;
    get clarificationPrompt(): AwsLexBot.ClarificationPromptPropertyOutputReference;
    putClarificationPrompt(value: AwsLexBot.ClarificationPromptProperty): void;
    resetClarificationPrompt(): void;
    get clarificationPromptInput(): AwsLexBot.ClarificationPromptProperty | undefined;
    private _intent;
    get intent(): AwsLexBot.IntentPropertyList;
    putIntent(value: AwsLexBot.IntentProperty[] | cdktn.IResolvable): void;
    get intentInput(): cdktn.IResolvable | AwsLexBot.IntentProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsLexBot.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsLexBot.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsLexBot.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsLexBotAbortStatementMessagePropertyToTerraform(struct?: AwsLexBot.AbortStatementMessageProperty | cdktn.IResolvable): any;
export declare function awsLexBotAbortStatementMessagePropertyToHclTerraform(struct?: AwsLexBot.AbortStatementMessageProperty | cdktn.IResolvable): any;
export declare function awsLexBotAbortStatementPropertyToTerraform(struct?: AwsLexBot.AbortStatementPropertyOutputReference | AwsLexBot.AbortStatementProperty): any;
export declare function awsLexBotAbortStatementPropertyToHclTerraform(struct?: AwsLexBot.AbortStatementPropertyOutputReference | AwsLexBot.AbortStatementProperty): any;
export declare function awsLexBotClarificationPromptMessagePropertyToTerraform(struct?: AwsLexBot.ClarificationPromptMessageProperty | cdktn.IResolvable): any;
export declare function awsLexBotClarificationPromptMessagePropertyToHclTerraform(struct?: AwsLexBot.ClarificationPromptMessageProperty | cdktn.IResolvable): any;
export declare function awsLexBotClarificationPromptPropertyToTerraform(struct?: AwsLexBot.ClarificationPromptPropertyOutputReference | AwsLexBot.ClarificationPromptProperty): any;
export declare function awsLexBotClarificationPromptPropertyToHclTerraform(struct?: AwsLexBot.ClarificationPromptPropertyOutputReference | AwsLexBot.ClarificationPromptProperty): any;
export declare function awsLexBotIntentPropertyToTerraform(struct?: AwsLexBot.IntentProperty | cdktn.IResolvable): any;
export declare function awsLexBotIntentPropertyToHclTerraform(struct?: AwsLexBot.IntentProperty | cdktn.IResolvable): any;
export declare function awsLexBotTimeoutsPropertyToTerraform(struct?: AwsLexBot.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsLexBotTimeoutsPropertyToHclTerraform(struct?: AwsLexBot.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsLexBot {
    interface AbortStatementMessageProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot#content AwsLexBot#content}
        */
        readonly content: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot#content_type AwsLexBot#content_type}
        */
        readonly contentType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot#group_number AwsLexBot#group_number}
        */
        readonly groupNumber?: number;
    }
    class AbortStatementMessagePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AbortStatementMessageProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AbortStatementMessageProperty | cdktn.IResolvable | undefined);
        private _content?;
        get content(): string;
        set content(value: string);
        get contentInput(): string | undefined;
        private _contentType?;
        get contentType(): string;
        set contentType(value: string);
        get contentTypeInput(): string | undefined;
        private _groupNumber?;
        get groupNumber(): number;
        set groupNumber(value: number);
        resetGroupNumber(): void;
        get groupNumberInput(): number | undefined;
    }
    class AbortStatementMessagePropertyList extends cdktn.ComplexList {
        internalValue?: AbortStatementMessageProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AbortStatementMessagePropertyOutputReference;
    }
    interface AbortStatementProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot#response_card AwsLexBot#response_card}
        */
        readonly responseCard?: string;
        /**
        * message block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot#message AwsLexBot#message}
        */
        readonly message: AbortStatementMessageProperty[] | cdktn.IResolvable;
    }
    class AbortStatementPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AbortStatementProperty | undefined;
        set internalValue(value: AbortStatementProperty | undefined);
        private _responseCard?;
        get responseCard(): string;
        set responseCard(value: string);
        resetResponseCard(): void;
        get responseCardInput(): string | undefined;
        private _message;
        get message(): AbortStatementMessagePropertyList;
        putMessage(value: AbortStatementMessageProperty[] | cdktn.IResolvable): void;
        get messageInput(): cdktn.IResolvable | AbortStatementMessageProperty[] | undefined;
    }
    interface ClarificationPromptMessageProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot#content AwsLexBot#content}
        */
        readonly content: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot#content_type AwsLexBot#content_type}
        */
        readonly contentType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot#group_number AwsLexBot#group_number}
        */
        readonly groupNumber?: number;
    }
    class ClarificationPromptMessagePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ClarificationPromptMessageProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ClarificationPromptMessageProperty | cdktn.IResolvable | undefined);
        private _content?;
        get content(): string;
        set content(value: string);
        get contentInput(): string | undefined;
        private _contentType?;
        get contentType(): string;
        set contentType(value: string);
        get contentTypeInput(): string | undefined;
        private _groupNumber?;
        get groupNumber(): number;
        set groupNumber(value: number);
        resetGroupNumber(): void;
        get groupNumberInput(): number | undefined;
    }
    class ClarificationPromptMessagePropertyList extends cdktn.ComplexList {
        internalValue?: ClarificationPromptMessageProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ClarificationPromptMessagePropertyOutputReference;
    }
    interface ClarificationPromptProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot#max_attempts AwsLexBot#max_attempts}
        */
        readonly maxAttempts: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot#response_card AwsLexBot#response_card}
        */
        readonly responseCard?: string;
        /**
        * message block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot#message AwsLexBot#message}
        */
        readonly message: ClarificationPromptMessageProperty[] | cdktn.IResolvable;
    }
    class ClarificationPromptPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ClarificationPromptProperty | undefined;
        set internalValue(value: ClarificationPromptProperty | undefined);
        private _maxAttempts?;
        get maxAttempts(): number;
        set maxAttempts(value: number);
        get maxAttemptsInput(): number | undefined;
        private _responseCard?;
        get responseCard(): string;
        set responseCard(value: string);
        resetResponseCard(): void;
        get responseCardInput(): string | undefined;
        private _message;
        get message(): ClarificationPromptMessagePropertyList;
        putMessage(value: ClarificationPromptMessageProperty[] | cdktn.IResolvable): void;
        get messageInput(): cdktn.IResolvable | ClarificationPromptMessageProperty[] | undefined;
    }
    interface IntentProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot#intent_name AwsLexBot#intent_name}
        */
        readonly intentName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot#intent_version AwsLexBot#intent_version}
        */
        readonly intentVersion: string;
    }
    class IntentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IntentProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IntentProperty | cdktn.IResolvable | undefined);
        private _intentName?;
        get intentName(): string;
        set intentName(value: string);
        get intentNameInput(): string | undefined;
        private _intentVersion?;
        get intentVersion(): string;
        set intentVersion(value: string);
        get intentVersionInput(): string | undefined;
    }
    class IntentPropertyList extends cdktn.ComplexList {
        internalValue?: IntentProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IntentPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot#create AwsLexBot#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot#delete AwsLexBot#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot#update AwsLexBot#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
