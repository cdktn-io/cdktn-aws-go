import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsLexIntentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#create_version AwsLexIntent#create_version}
    */
    readonly createVersion?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#description AwsLexIntent#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#id AwsLexIntent#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#name AwsLexIntent#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#parent_intent_signature AwsLexIntent#parent_intent_signature}
    */
    readonly parentIntentSignature?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#region AwsLexIntent#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#sample_utterances AwsLexIntent#sample_utterances}
    */
    readonly sampleUtterances?: string[];
    /**
    * conclusion_statement block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#conclusion_statement AwsLexIntent#conclusion_statement}
    */
    readonly conclusionStatement?: AwsLexIntent.ConclusionStatementProperty;
    /**
    * confirmation_prompt block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#confirmation_prompt AwsLexIntent#confirmation_prompt}
    */
    readonly confirmationPrompt?: AwsLexIntent.ConfirmationPromptProperty;
    /**
    * dialog_code_hook block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#dialog_code_hook AwsLexIntent#dialog_code_hook}
    */
    readonly dialogCodeHook?: AwsLexIntent.DialogCodeHookProperty;
    /**
    * follow_up_prompt block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#follow_up_prompt AwsLexIntent#follow_up_prompt}
    */
    readonly followUpPrompt?: AwsLexIntent.FollowUpPromptProperty;
    /**
    * fulfillment_activity block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#fulfillment_activity AwsLexIntent#fulfillment_activity}
    */
    readonly fulfillmentActivity: AwsLexIntent.FulfillmentActivityProperty;
    /**
    * rejection_statement block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#rejection_statement AwsLexIntent#rejection_statement}
    */
    readonly rejectionStatement?: AwsLexIntent.RejectionStatementProperty;
    /**
    * slot block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#slot AwsLexIntent#slot}
    */
    readonly slot?: AwsLexIntent.SlotProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#timeouts AwsLexIntent#timeouts}
    */
    readonly timeouts?: AwsLexIntent.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent aws_lex_intent}
*/
export declare class AwsLexIntent extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_lex_intent";
    /**
    * Generates CDKTN code for importing a AwsLexIntent resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsLexIntent to import
    * @param importFromId The id of the existing AwsLexIntent that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsLexIntent to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent aws_lex_intent} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsLexIntentConfig
    */
    constructor(scope: Construct, id: string, config: AwsLexIntentConfig);
    get arn(): string;
    get checksum(): string;
    private _createVersion?;
    get createVersion(): boolean | cdktn.IResolvable;
    set createVersion(value: boolean | cdktn.IResolvable);
    resetCreateVersion(): void;
    get createVersionInput(): boolean | cdktn.IResolvable | undefined;
    get createdDate(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastUpdatedDate(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parentIntentSignature?;
    get parentIntentSignature(): string;
    set parentIntentSignature(value: string);
    resetParentIntentSignature(): void;
    get parentIntentSignatureInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _sampleUtterances?;
    get sampleUtterances(): string[];
    set sampleUtterances(value: string[]);
    resetSampleUtterances(): void;
    get sampleUtterancesInput(): string[] | undefined;
    get version(): string;
    private _conclusionStatement;
    get conclusionStatement(): AwsLexIntent.ConclusionStatementPropertyOutputReference;
    putConclusionStatement(value: AwsLexIntent.ConclusionStatementProperty): void;
    resetConclusionStatement(): void;
    get conclusionStatementInput(): AwsLexIntent.ConclusionStatementProperty | undefined;
    private _confirmationPrompt;
    get confirmationPrompt(): AwsLexIntent.ConfirmationPromptPropertyOutputReference;
    putConfirmationPrompt(value: AwsLexIntent.ConfirmationPromptProperty): void;
    resetConfirmationPrompt(): void;
    get confirmationPromptInput(): AwsLexIntent.ConfirmationPromptProperty | undefined;
    private _dialogCodeHook;
    get dialogCodeHook(): AwsLexIntent.DialogCodeHookPropertyOutputReference;
    putDialogCodeHook(value: AwsLexIntent.DialogCodeHookProperty): void;
    resetDialogCodeHook(): void;
    get dialogCodeHookInput(): AwsLexIntent.DialogCodeHookProperty | undefined;
    private _followUpPrompt;
    get followUpPrompt(): AwsLexIntent.FollowUpPromptPropertyOutputReference;
    putFollowUpPrompt(value: AwsLexIntent.FollowUpPromptProperty): void;
    resetFollowUpPrompt(): void;
    get followUpPromptInput(): AwsLexIntent.FollowUpPromptProperty | undefined;
    private _fulfillmentActivity;
    get fulfillmentActivity(): AwsLexIntent.FulfillmentActivityPropertyOutputReference;
    putFulfillmentActivity(value: AwsLexIntent.FulfillmentActivityProperty): void;
    get fulfillmentActivityInput(): AwsLexIntent.FulfillmentActivityProperty | undefined;
    private _rejectionStatement;
    get rejectionStatement(): AwsLexIntent.RejectionStatementPropertyOutputReference;
    putRejectionStatement(value: AwsLexIntent.RejectionStatementProperty): void;
    resetRejectionStatement(): void;
    get rejectionStatementInput(): AwsLexIntent.RejectionStatementProperty | undefined;
    private _slot;
    get slot(): AwsLexIntent.SlotPropertyList;
    putSlot(value: AwsLexIntent.SlotProperty[] | cdktn.IResolvable): void;
    resetSlot(): void;
    get slotInput(): cdktn.IResolvable | AwsLexIntent.SlotProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsLexIntent.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsLexIntent.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsLexIntent.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsLexIntentConclusionStatementMessagePropertyToTerraform(struct?: AwsLexIntent.ConclusionStatementMessageProperty | cdktn.IResolvable): any;
export declare function awsLexIntentConclusionStatementMessagePropertyToHclTerraform(struct?: AwsLexIntent.ConclusionStatementMessageProperty | cdktn.IResolvable): any;
export declare function awsLexIntentConclusionStatementPropertyToTerraform(struct?: AwsLexIntent.ConclusionStatementPropertyOutputReference | AwsLexIntent.ConclusionStatementProperty): any;
export declare function awsLexIntentConclusionStatementPropertyToHclTerraform(struct?: AwsLexIntent.ConclusionStatementPropertyOutputReference | AwsLexIntent.ConclusionStatementProperty): any;
export declare function awsLexIntentConfirmationPromptMessagePropertyToTerraform(struct?: AwsLexIntent.ConfirmationPromptMessageProperty | cdktn.IResolvable): any;
export declare function awsLexIntentConfirmationPromptMessagePropertyToHclTerraform(struct?: AwsLexIntent.ConfirmationPromptMessageProperty | cdktn.IResolvable): any;
export declare function awsLexIntentConfirmationPromptPropertyToTerraform(struct?: AwsLexIntent.ConfirmationPromptPropertyOutputReference | AwsLexIntent.ConfirmationPromptProperty): any;
export declare function awsLexIntentConfirmationPromptPropertyToHclTerraform(struct?: AwsLexIntent.ConfirmationPromptPropertyOutputReference | AwsLexIntent.ConfirmationPromptProperty): any;
export declare function awsLexIntentDialogCodeHookPropertyToTerraform(struct?: AwsLexIntent.DialogCodeHookPropertyOutputReference | AwsLexIntent.DialogCodeHookProperty): any;
export declare function awsLexIntentDialogCodeHookPropertyToHclTerraform(struct?: AwsLexIntent.DialogCodeHookPropertyOutputReference | AwsLexIntent.DialogCodeHookProperty): any;
export declare function awsLexIntentFollowUpPromptPromptMessagePropertyToTerraform(struct?: AwsLexIntent.FollowUpPromptPromptMessageProperty | cdktn.IResolvable): any;
export declare function awsLexIntentFollowUpPromptPromptMessagePropertyToHclTerraform(struct?: AwsLexIntent.FollowUpPromptPromptMessageProperty | cdktn.IResolvable): any;
export declare function awsLexIntentPromptPropertyToTerraform(struct?: AwsLexIntent.PromptPropertyOutputReference | AwsLexIntent.PromptProperty): any;
export declare function awsLexIntentPromptPropertyToHclTerraform(struct?: AwsLexIntent.PromptPropertyOutputReference | AwsLexIntent.PromptProperty): any;
export declare function awsLexIntentFollowUpPromptRejectionStatementMessagePropertyToTerraform(struct?: AwsLexIntent.FollowUpPromptRejectionStatementMessageProperty | cdktn.IResolvable): any;
export declare function awsLexIntentFollowUpPromptRejectionStatementMessagePropertyToHclTerraform(struct?: AwsLexIntent.FollowUpPromptRejectionStatementMessageProperty | cdktn.IResolvable): any;
export declare function awsLexIntentFollowUpPromptRejectionStatementPropertyToTerraform(struct?: AwsLexIntent.FollowUpPromptRejectionStatementPropertyOutputReference | AwsLexIntent.FollowUpPromptRejectionStatementProperty): any;
export declare function awsLexIntentFollowUpPromptRejectionStatementPropertyToHclTerraform(struct?: AwsLexIntent.FollowUpPromptRejectionStatementPropertyOutputReference | AwsLexIntent.FollowUpPromptRejectionStatementProperty): any;
export declare function awsLexIntentFollowUpPromptPropertyToTerraform(struct?: AwsLexIntent.FollowUpPromptPropertyOutputReference | AwsLexIntent.FollowUpPromptProperty): any;
export declare function awsLexIntentFollowUpPromptPropertyToHclTerraform(struct?: AwsLexIntent.FollowUpPromptPropertyOutputReference | AwsLexIntent.FollowUpPromptProperty): any;
export declare function awsLexIntentCodeHookPropertyToTerraform(struct?: AwsLexIntent.CodeHookPropertyOutputReference | AwsLexIntent.CodeHookProperty): any;
export declare function awsLexIntentCodeHookPropertyToHclTerraform(struct?: AwsLexIntent.CodeHookPropertyOutputReference | AwsLexIntent.CodeHookProperty): any;
export declare function awsLexIntentFulfillmentActivityPropertyToTerraform(struct?: AwsLexIntent.FulfillmentActivityPropertyOutputReference | AwsLexIntent.FulfillmentActivityProperty): any;
export declare function awsLexIntentFulfillmentActivityPropertyToHclTerraform(struct?: AwsLexIntent.FulfillmentActivityPropertyOutputReference | AwsLexIntent.FulfillmentActivityProperty): any;
export declare function awsLexIntentRejectionStatementMessagePropertyToTerraform(struct?: AwsLexIntent.RejectionStatementMessageProperty | cdktn.IResolvable): any;
export declare function awsLexIntentRejectionStatementMessagePropertyToHclTerraform(struct?: AwsLexIntent.RejectionStatementMessageProperty | cdktn.IResolvable): any;
export declare function awsLexIntentRejectionStatementPropertyToTerraform(struct?: AwsLexIntent.RejectionStatementPropertyOutputReference | AwsLexIntent.RejectionStatementProperty): any;
export declare function awsLexIntentRejectionStatementPropertyToHclTerraform(struct?: AwsLexIntent.RejectionStatementPropertyOutputReference | AwsLexIntent.RejectionStatementProperty): any;
export declare function awsLexIntentSlotValueElicitationPromptMessagePropertyToTerraform(struct?: AwsLexIntent.SlotValueElicitationPromptMessageProperty | cdktn.IResolvable): any;
export declare function awsLexIntentSlotValueElicitationPromptMessagePropertyToHclTerraform(struct?: AwsLexIntent.SlotValueElicitationPromptMessageProperty | cdktn.IResolvable): any;
export declare function awsLexIntentValueElicitationPromptPropertyToTerraform(struct?: AwsLexIntent.ValueElicitationPromptPropertyOutputReference | AwsLexIntent.ValueElicitationPromptProperty): any;
export declare function awsLexIntentValueElicitationPromptPropertyToHclTerraform(struct?: AwsLexIntent.ValueElicitationPromptPropertyOutputReference | AwsLexIntent.ValueElicitationPromptProperty): any;
export declare function awsLexIntentSlotPropertyToTerraform(struct?: AwsLexIntent.SlotProperty | cdktn.IResolvable): any;
export declare function awsLexIntentSlotPropertyToHclTerraform(struct?: AwsLexIntent.SlotProperty | cdktn.IResolvable): any;
export declare function awsLexIntentTimeoutsPropertyToTerraform(struct?: AwsLexIntent.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsLexIntentTimeoutsPropertyToHclTerraform(struct?: AwsLexIntent.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsLexIntent {
    interface ConclusionStatementMessageProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#content AwsLexIntent#content}
        */
        readonly content: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#content_type AwsLexIntent#content_type}
        */
        readonly contentType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#group_number AwsLexIntent#group_number}
        */
        readonly groupNumber?: number;
    }
    class ConclusionStatementMessagePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConclusionStatementMessageProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConclusionStatementMessageProperty | cdktn.IResolvable | undefined);
        private _content?;
        get content(): string;
        set content(value: string);
        get contentInput(): string | undefined;
        private _contentType?;
        get contentType(): string;
        set contentType(value: string);
        get contentTypeInput(): string | undefined;
        private _groupNumber?;
        get groupNumber(): number;
        set groupNumber(value: number);
        resetGroupNumber(): void;
        get groupNumberInput(): number | undefined;
    }
    class ConclusionStatementMessagePropertyList extends cdktn.ComplexList {
        internalValue?: ConclusionStatementMessageProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConclusionStatementMessagePropertyOutputReference;
    }
    interface ConclusionStatementProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#response_card AwsLexIntent#response_card}
        */
        readonly responseCard?: string;
        /**
        * message block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#message AwsLexIntent#message}
        */
        readonly message: ConclusionStatementMessageProperty[] | cdktn.IResolvable;
    }
    class ConclusionStatementPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConclusionStatementProperty | undefined;
        set internalValue(value: ConclusionStatementProperty | undefined);
        private _responseCard?;
        get responseCard(): string;
        set responseCard(value: string);
        resetResponseCard(): void;
        get responseCardInput(): string | undefined;
        private _message;
        get message(): ConclusionStatementMessagePropertyList;
        putMessage(value: ConclusionStatementMessageProperty[] | cdktn.IResolvable): void;
        get messageInput(): cdktn.IResolvable | ConclusionStatementMessageProperty[] | undefined;
    }
    interface ConfirmationPromptMessageProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#content AwsLexIntent#content}
        */
        readonly content: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#content_type AwsLexIntent#content_type}
        */
        readonly contentType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#group_number AwsLexIntent#group_number}
        */
        readonly groupNumber?: number;
    }
    class ConfirmationPromptMessagePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConfirmationPromptMessageProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConfirmationPromptMessageProperty | cdktn.IResolvable | undefined);
        private _content?;
        get content(): string;
        set content(value: string);
        get contentInput(): string | undefined;
        private _contentType?;
        get contentType(): string;
        set contentType(value: string);
        get contentTypeInput(): string | undefined;
        private _groupNumber?;
        get groupNumber(): number;
        set groupNumber(value: number);
        resetGroupNumber(): void;
        get groupNumberInput(): number | undefined;
    }
    class ConfirmationPromptMessagePropertyList extends cdktn.ComplexList {
        internalValue?: ConfirmationPromptMessageProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConfirmationPromptMessagePropertyOutputReference;
    }
    interface ConfirmationPromptProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#max_attempts AwsLexIntent#max_attempts}
        */
        readonly maxAttempts: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#response_card AwsLexIntent#response_card}
        */
        readonly responseCard?: string;
        /**
        * message block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#message AwsLexIntent#message}
        */
        readonly message: ConfirmationPromptMessageProperty[] | cdktn.IResolvable;
    }
    class ConfirmationPromptPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConfirmationPromptProperty | undefined;
        set internalValue(value: ConfirmationPromptProperty | undefined);
        private _maxAttempts?;
        get maxAttempts(): number;
        set maxAttempts(value: number);
        get maxAttemptsInput(): number | undefined;
        private _responseCard?;
        get responseCard(): string;
        set responseCard(value: string);
        resetResponseCard(): void;
        get responseCardInput(): string | undefined;
        private _message;
        get message(): ConfirmationPromptMessagePropertyList;
        putMessage(value: ConfirmationPromptMessageProperty[] | cdktn.IResolvable): void;
        get messageInput(): cdktn.IResolvable | ConfirmationPromptMessageProperty[] | undefined;
    }
    interface DialogCodeHookProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#message_version AwsLexIntent#message_version}
        */
        readonly messageVersion: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#uri AwsLexIntent#uri}
        */
        readonly uri: string;
    }
    class DialogCodeHookPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DialogCodeHookProperty | undefined;
        set internalValue(value: DialogCodeHookProperty | undefined);
        private _messageVersion?;
        get messageVersion(): string;
        set messageVersion(value: string);
        get messageVersionInput(): string | undefined;
        private _uri?;
        get uri(): string;
        set uri(value: string);
        get uriInput(): string | undefined;
    }
    interface FollowUpPromptPromptMessageProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#content AwsLexIntent#content}
        */
        readonly content: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#content_type AwsLexIntent#content_type}
        */
        readonly contentType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#group_number AwsLexIntent#group_number}
        */
        readonly groupNumber?: number;
    }
    class FollowUpPromptPromptMessagePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FollowUpPromptPromptMessageProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FollowUpPromptPromptMessageProperty | cdktn.IResolvable | undefined);
        private _content?;
        get content(): string;
        set content(value: string);
        get contentInput(): string | undefined;
        private _contentType?;
        get contentType(): string;
        set contentType(value: string);
        get contentTypeInput(): string | undefined;
        private _groupNumber?;
        get groupNumber(): number;
        set groupNumber(value: number);
        resetGroupNumber(): void;
        get groupNumberInput(): number | undefined;
    }
    class FollowUpPromptPromptMessagePropertyList extends cdktn.ComplexList {
        internalValue?: FollowUpPromptPromptMessageProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FollowUpPromptPromptMessagePropertyOutputReference;
    }
    interface PromptProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#max_attempts AwsLexIntent#max_attempts}
        */
        readonly maxAttempts: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#response_card AwsLexIntent#response_card}
        */
        readonly responseCard?: string;
        /**
        * message block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#message AwsLexIntent#message}
        */
        readonly message: FollowUpPromptPromptMessageProperty[] | cdktn.IResolvable;
    }
    class PromptPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PromptProperty | undefined;
        set internalValue(value: PromptProperty | undefined);
        private _maxAttempts?;
        get maxAttempts(): number;
        set maxAttempts(value: number);
        get maxAttemptsInput(): number | undefined;
        private _responseCard?;
        get responseCard(): string;
        set responseCard(value: string);
        resetResponseCard(): void;
        get responseCardInput(): string | undefined;
        private _message;
        get message(): FollowUpPromptPromptMessagePropertyList;
        putMessage(value: FollowUpPromptPromptMessageProperty[] | cdktn.IResolvable): void;
        get messageInput(): cdktn.IResolvable | FollowUpPromptPromptMessageProperty[] | undefined;
    }
    interface FollowUpPromptRejectionStatementMessageProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#content AwsLexIntent#content}
        */
        readonly content: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#content_type AwsLexIntent#content_type}
        */
        readonly contentType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#group_number AwsLexIntent#group_number}
        */
        readonly groupNumber?: number;
    }
    class FollowUpPromptRejectionStatementMessagePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FollowUpPromptRejectionStatementMessageProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FollowUpPromptRejectionStatementMessageProperty | cdktn.IResolvable | undefined);
        private _content?;
        get content(): string;
        set content(value: string);
        get contentInput(): string | undefined;
        private _contentType?;
        get contentType(): string;
        set contentType(value: string);
        get contentTypeInput(): string | undefined;
        private _groupNumber?;
        get groupNumber(): number;
        set groupNumber(value: number);
        resetGroupNumber(): void;
        get groupNumberInput(): number | undefined;
    }
    class FollowUpPromptRejectionStatementMessagePropertyList extends cdktn.ComplexList {
        internalValue?: FollowUpPromptRejectionStatementMessageProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FollowUpPromptRejectionStatementMessagePropertyOutputReference;
    }
    interface FollowUpPromptRejectionStatementProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#response_card AwsLexIntent#response_card}
        */
        readonly responseCard?: string;
        /**
        * message block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#message AwsLexIntent#message}
        */
        readonly message: FollowUpPromptRejectionStatementMessageProperty[] | cdktn.IResolvable;
    }
    class FollowUpPromptRejectionStatementPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FollowUpPromptRejectionStatementProperty | undefined;
        set internalValue(value: FollowUpPromptRejectionStatementProperty | undefined);
        private _responseCard?;
        get responseCard(): string;
        set responseCard(value: string);
        resetResponseCard(): void;
        get responseCardInput(): string | undefined;
        private _message;
        get message(): FollowUpPromptRejectionStatementMessagePropertyList;
        putMessage(value: FollowUpPromptRejectionStatementMessageProperty[] | cdktn.IResolvable): void;
        get messageInput(): cdktn.IResolvable | FollowUpPromptRejectionStatementMessageProperty[] | undefined;
    }
    interface FollowUpPromptProperty {
        /**
        * prompt block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#prompt AwsLexIntent#prompt}
        */
        readonly prompt: PromptProperty;
        /**
        * rejection_statement block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#rejection_statement AwsLexIntent#rejection_statement}
        */
        readonly rejectionStatement: FollowUpPromptRejectionStatementProperty;
    }
    class FollowUpPromptPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FollowUpPromptProperty | undefined;
        set internalValue(value: FollowUpPromptProperty | undefined);
        private _prompt;
        get prompt(): PromptPropertyOutputReference;
        putPrompt(value: PromptProperty): void;
        get promptInput(): PromptProperty | undefined;
        private _rejectionStatement;
        get rejectionStatement(): FollowUpPromptRejectionStatementPropertyOutputReference;
        putRejectionStatement(value: FollowUpPromptRejectionStatementProperty): void;
        get rejectionStatementInput(): FollowUpPromptRejectionStatementProperty | undefined;
    }
    interface CodeHookProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#message_version AwsLexIntent#message_version}
        */
        readonly messageVersion: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#uri AwsLexIntent#uri}
        */
        readonly uri: string;
    }
    class CodeHookPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CodeHookProperty | undefined;
        set internalValue(value: CodeHookProperty | undefined);
        private _messageVersion?;
        get messageVersion(): string;
        set messageVersion(value: string);
        get messageVersionInput(): string | undefined;
        private _uri?;
        get uri(): string;
        set uri(value: string);
        get uriInput(): string | undefined;
    }
    interface FulfillmentActivityProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#type AwsLexIntent#type}
        */
        readonly type: string;
        /**
        * code_hook block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#code_hook AwsLexIntent#code_hook}
        */
        readonly codeHook?: CodeHookProperty;
    }
    class FulfillmentActivityPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FulfillmentActivityProperty | undefined;
        set internalValue(value: FulfillmentActivityProperty | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _codeHook;
        get codeHook(): CodeHookPropertyOutputReference;
        putCodeHook(value: CodeHookProperty): void;
        resetCodeHook(): void;
        get codeHookInput(): CodeHookProperty | undefined;
    }
    interface RejectionStatementMessageProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#content AwsLexIntent#content}
        */
        readonly content: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#content_type AwsLexIntent#content_type}
        */
        readonly contentType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#group_number AwsLexIntent#group_number}
        */
        readonly groupNumber?: number;
    }
    class RejectionStatementMessagePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RejectionStatementMessageProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RejectionStatementMessageProperty | cdktn.IResolvable | undefined);
        private _content?;
        get content(): string;
        set content(value: string);
        get contentInput(): string | undefined;
        private _contentType?;
        get contentType(): string;
        set contentType(value: string);
        get contentTypeInput(): string | undefined;
        private _groupNumber?;
        get groupNumber(): number;
        set groupNumber(value: number);
        resetGroupNumber(): void;
        get groupNumberInput(): number | undefined;
    }
    class RejectionStatementMessagePropertyList extends cdktn.ComplexList {
        internalValue?: RejectionStatementMessageProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RejectionStatementMessagePropertyOutputReference;
    }
    interface RejectionStatementProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#response_card AwsLexIntent#response_card}
        */
        readonly responseCard?: string;
        /**
        * message block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#message AwsLexIntent#message}
        */
        readonly message: RejectionStatementMessageProperty[] | cdktn.IResolvable;
    }
    class RejectionStatementPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RejectionStatementProperty | undefined;
        set internalValue(value: RejectionStatementProperty | undefined);
        private _responseCard?;
        get responseCard(): string;
        set responseCard(value: string);
        resetResponseCard(): void;
        get responseCardInput(): string | undefined;
        private _message;
        get message(): RejectionStatementMessagePropertyList;
        putMessage(value: RejectionStatementMessageProperty[] | cdktn.IResolvable): void;
        get messageInput(): cdktn.IResolvable | RejectionStatementMessageProperty[] | undefined;
    }
    interface SlotValueElicitationPromptMessageProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#content AwsLexIntent#content}
        */
        readonly content: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#content_type AwsLexIntent#content_type}
        */
        readonly contentType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#group_number AwsLexIntent#group_number}
        */
        readonly groupNumber?: number;
    }
    class SlotValueElicitationPromptMessagePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SlotValueElicitationPromptMessageProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SlotValueElicitationPromptMessageProperty | cdktn.IResolvable | undefined);
        private _content?;
        get content(): string;
        set content(value: string);
        get contentInput(): string | undefined;
        private _contentType?;
        get contentType(): string;
        set contentType(value: string);
        get contentTypeInput(): string | undefined;
        private _groupNumber?;
        get groupNumber(): number;
        set groupNumber(value: number);
        resetGroupNumber(): void;
        get groupNumberInput(): number | undefined;
    }
    class SlotValueElicitationPromptMessagePropertyList extends cdktn.ComplexList {
        internalValue?: SlotValueElicitationPromptMessageProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SlotValueElicitationPromptMessagePropertyOutputReference;
    }
    interface ValueElicitationPromptProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#max_attempts AwsLexIntent#max_attempts}
        */
        readonly maxAttempts: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#response_card AwsLexIntent#response_card}
        */
        readonly responseCard?: string;
        /**
        * message block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#message AwsLexIntent#message}
        */
        readonly message: SlotValueElicitationPromptMessageProperty[] | cdktn.IResolvable;
    }
    class ValueElicitationPromptPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ValueElicitationPromptProperty | undefined;
        set internalValue(value: ValueElicitationPromptProperty | undefined);
        private _maxAttempts?;
        get maxAttempts(): number;
        set maxAttempts(value: number);
        get maxAttemptsInput(): number | undefined;
        private _responseCard?;
        get responseCard(): string;
        set responseCard(value: string);
        resetResponseCard(): void;
        get responseCardInput(): string | undefined;
        private _message;
        get message(): SlotValueElicitationPromptMessagePropertyList;
        putMessage(value: SlotValueElicitationPromptMessageProperty[] | cdktn.IResolvable): void;
        get messageInput(): cdktn.IResolvable | SlotValueElicitationPromptMessageProperty[] | undefined;
    }
    interface SlotProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#description AwsLexIntent#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#name AwsLexIntent#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#priority AwsLexIntent#priority}
        */
        readonly priority?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#response_card AwsLexIntent#response_card}
        */
        readonly responseCard?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#sample_utterances AwsLexIntent#sample_utterances}
        */
        readonly sampleUtterances?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#slot_constraint AwsLexIntent#slot_constraint}
        */
        readonly slotConstraint: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#slot_type AwsLexIntent#slot_type}
        */
        readonly slotType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#slot_type_version AwsLexIntent#slot_type_version}
        */
        readonly slotTypeVersion?: string;
        /**
        * value_elicitation_prompt block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#value_elicitation_prompt AwsLexIntent#value_elicitation_prompt}
        */
        readonly valueElicitationPrompt?: ValueElicitationPromptProperty;
    }
    class SlotPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SlotProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SlotProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _priority?;
        get priority(): number;
        set priority(value: number);
        resetPriority(): void;
        get priorityInput(): number | undefined;
        private _responseCard?;
        get responseCard(): string;
        set responseCard(value: string);
        resetResponseCard(): void;
        get responseCardInput(): string | undefined;
        private _sampleUtterances?;
        get sampleUtterances(): string[];
        set sampleUtterances(value: string[]);
        resetSampleUtterances(): void;
        get sampleUtterancesInput(): string[] | undefined;
        private _slotConstraint?;
        get slotConstraint(): string;
        set slotConstraint(value: string);
        get slotConstraintInput(): string | undefined;
        private _slotType?;
        get slotType(): string;
        set slotType(value: string);
        get slotTypeInput(): string | undefined;
        private _slotTypeVersion?;
        get slotTypeVersion(): string;
        set slotTypeVersion(value: string);
        resetSlotTypeVersion(): void;
        get slotTypeVersionInput(): string | undefined;
        private _valueElicitationPrompt;
        get valueElicitationPrompt(): ValueElicitationPromptPropertyOutputReference;
        putValueElicitationPrompt(value: ValueElicitationPromptProperty): void;
        resetValueElicitationPrompt(): void;
        get valueElicitationPromptInput(): ValueElicitationPromptProperty | undefined;
    }
    class SlotPropertyList extends cdktn.ComplexList {
        internalValue?: SlotProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SlotPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#create AwsLexIntent#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#delete AwsLexIntent#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_intent#update AwsLexIntent#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
