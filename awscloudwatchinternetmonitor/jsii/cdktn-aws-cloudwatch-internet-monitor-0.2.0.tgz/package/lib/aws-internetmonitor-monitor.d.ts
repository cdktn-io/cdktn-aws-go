import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfMonitorConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/internetmonitor_monitor#id TfMonitor#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/internetmonitor_monitor#max_city_networks_to_monitor TfMonitor#max_city_networks_to_monitor}
    */
    readonly maxCityNetworksToMonitor?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/internetmonitor_monitor#monitor_name TfMonitor#monitor_name}
    */
    readonly monitorName: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/internetmonitor_monitor#region TfMonitor#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/internetmonitor_monitor#resources TfMonitor#resources}
    */
    readonly resources?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/internetmonitor_monitor#status TfMonitor#status}
    */
    readonly status?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/internetmonitor_monitor#tags TfMonitor#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/internetmonitor_monitor#tags_all TfMonitor#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/internetmonitor_monitor#traffic_percentage_to_monitor TfMonitor#traffic_percentage_to_monitor}
    */
    readonly trafficPercentageToMonitor?: number;
    /**
    * health_events_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/internetmonitor_monitor#health_events_config TfMonitor#health_events_config}
    */
    readonly healthEventsConfig?: TfMonitor.HealthEventsConfigProperty;
    /**
    * internet_measurements_log_delivery block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/internetmonitor_monitor#internet_measurements_log_delivery TfMonitor#internet_measurements_log_delivery}
    */
    readonly internetMeasurementsLogDelivery?: TfMonitor.InternetMeasurementsLogDeliveryProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/internetmonitor_monitor aws_internetmonitor_monitor}
*/
export declare class TfMonitor extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_internetmonitor_monitor";
    /**
    * Generates CDKTN code for importing a TfMonitor resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfMonitor to import
    * @param importFromId The id of the existing TfMonitor that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/internetmonitor_monitor#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfMonitor to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/internetmonitor_monitor aws_internetmonitor_monitor} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfMonitorConfig
    */
    constructor(scope: Construct, id: string, config: TfMonitorConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _maxCityNetworksToMonitor?;
    get maxCityNetworksToMonitor(): number;
    set maxCityNetworksToMonitor(value: number);
    resetMaxCityNetworksToMonitor(): void;
    get maxCityNetworksToMonitorInput(): number | undefined;
    private _monitorName?;
    get monitorName(): string;
    set monitorName(value: string);
    get monitorNameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resources?;
    get resources(): string[];
    set resources(value: string[]);
    resetResources(): void;
    get resourcesInput(): string[] | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _trafficPercentageToMonitor?;
    get trafficPercentageToMonitor(): number;
    set trafficPercentageToMonitor(value: number);
    resetTrafficPercentageToMonitor(): void;
    get trafficPercentageToMonitorInput(): number | undefined;
    private _healthEventsConfig;
    get healthEventsConfig(): TfMonitor.HealthEventsConfigPropertyOutputReference;
    putHealthEventsConfig(value: TfMonitor.HealthEventsConfigProperty): void;
    resetHealthEventsConfig(): void;
    get healthEventsConfigInput(): TfMonitor.HealthEventsConfigProperty | undefined;
    private _internetMeasurementsLogDelivery;
    get internetMeasurementsLogDelivery(): TfMonitor.InternetMeasurementsLogDeliveryPropertyOutputReference;
    putInternetMeasurementsLogDelivery(value: TfMonitor.InternetMeasurementsLogDeliveryProperty): void;
    resetInternetMeasurementsLogDelivery(): void;
    get internetMeasurementsLogDeliveryInput(): TfMonitor.InternetMeasurementsLogDeliveryProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfMonitorHealthEventsConfigPropertyToTerraform(struct?: TfMonitor.HealthEventsConfigPropertyOutputReference | TfMonitor.HealthEventsConfigProperty): any;
export declare function tfMonitorHealthEventsConfigPropertyToHclTerraform(struct?: TfMonitor.HealthEventsConfigPropertyOutputReference | TfMonitor.HealthEventsConfigProperty): any;
export declare function tfMonitorS3ConfigPropertyToTerraform(struct?: TfMonitor.S3ConfigPropertyOutputReference | TfMonitor.S3ConfigProperty): any;
export declare function tfMonitorS3ConfigPropertyToHclTerraform(struct?: TfMonitor.S3ConfigPropertyOutputReference | TfMonitor.S3ConfigProperty): any;
export declare function tfMonitorInternetMeasurementsLogDeliveryPropertyToTerraform(struct?: TfMonitor.InternetMeasurementsLogDeliveryPropertyOutputReference | TfMonitor.InternetMeasurementsLogDeliveryProperty): any;
export declare function tfMonitorInternetMeasurementsLogDeliveryPropertyToHclTerraform(struct?: TfMonitor.InternetMeasurementsLogDeliveryPropertyOutputReference | TfMonitor.InternetMeasurementsLogDeliveryProperty): any;
export declare namespace TfMonitor {
    interface HealthEventsConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/internetmonitor_monitor#availability_score_threshold TfMonitor#availability_score_threshold}
        */
        readonly availabilityScoreThreshold?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/internetmonitor_monitor#performance_score_threshold TfMonitor#performance_score_threshold}
        */
        readonly performanceScoreThreshold?: number;
    }
    class HealthEventsConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HealthEventsConfigProperty | undefined;
        set internalValue(value: HealthEventsConfigProperty | undefined);
        private _availabilityScoreThreshold?;
        get availabilityScoreThreshold(): number;
        set availabilityScoreThreshold(value: number);
        resetAvailabilityScoreThreshold(): void;
        get availabilityScoreThresholdInput(): number | undefined;
        private _performanceScoreThreshold?;
        get performanceScoreThreshold(): number;
        set performanceScoreThreshold(value: number);
        resetPerformanceScoreThreshold(): void;
        get performanceScoreThresholdInput(): number | undefined;
    }
    interface S3ConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/internetmonitor_monitor#bucket_name TfMonitor#bucket_name}
        */
        readonly bucketName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/internetmonitor_monitor#bucket_prefix TfMonitor#bucket_prefix}
        */
        readonly bucketPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/internetmonitor_monitor#log_delivery_status TfMonitor#log_delivery_status}
        */
        readonly logDeliveryStatus?: string;
    }
    class S3ConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3ConfigProperty | undefined;
        set internalValue(value: S3ConfigProperty | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        get bucketNameInput(): string | undefined;
        private _bucketPrefix?;
        get bucketPrefix(): string;
        set bucketPrefix(value: string);
        resetBucketPrefix(): void;
        get bucketPrefixInput(): string | undefined;
        private _logDeliveryStatus?;
        get logDeliveryStatus(): string;
        set logDeliveryStatus(value: string);
        resetLogDeliveryStatus(): void;
        get logDeliveryStatusInput(): string | undefined;
    }
    interface InternetMeasurementsLogDeliveryProperty {
        /**
        * s3_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/internetmonitor_monitor#s3_config TfMonitor#s3_config}
        */
        readonly s3Config?: S3ConfigProperty;
    }
    class InternetMeasurementsLogDeliveryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InternetMeasurementsLogDeliveryProperty | undefined;
        set internalValue(value: InternetMeasurementsLogDeliveryProperty | undefined);
        private _s3Config;
        get s3Config(): S3ConfigPropertyOutputReference;
        putS3Config(value: S3ConfigProperty): void;
        resetS3Config(): void;
        get s3ConfigInput(): S3ConfigProperty | undefined;
    }
}
