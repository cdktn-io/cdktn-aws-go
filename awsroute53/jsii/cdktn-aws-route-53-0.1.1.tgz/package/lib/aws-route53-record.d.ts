import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsRoute53RecordConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_record#allow_overwrite AwsRoute53Record#allow_overwrite}
    */
    readonly allowOverwrite?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_record#health_check_id AwsRoute53Record#health_check_id}
    */
    readonly healthCheckId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_record#id AwsRoute53Record#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_record#multivalue_answer_routing_policy AwsRoute53Record#multivalue_answer_routing_policy}
    */
    readonly multivalueAnswerRoutingPolicy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_record#name AwsRoute53Record#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_record#records AwsRoute53Record#records}
    */
    readonly records?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_record#set_identifier AwsRoute53Record#set_identifier}
    */
    readonly setIdentifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_record#ttl AwsRoute53Record#ttl}
    */
    readonly ttl?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_record#type AwsRoute53Record#type}
    */
    readonly type: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_record#zone_id AwsRoute53Record#zone_id}
    */
    readonly zoneId: string;
    /**
    * alias block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_record#alias AwsRoute53Record#alias}
    */
    readonly alias?: AwsRoute53Record.AliasProperty;
    /**
    * cidr_routing_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_record#cidr_routing_policy AwsRoute53Record#cidr_routing_policy}
    */
    readonly cidrRoutingPolicy?: AwsRoute53Record.CidrRoutingPolicyProperty;
    /**
    * failover_routing_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_record#failover_routing_policy AwsRoute53Record#failover_routing_policy}
    */
    readonly failoverRoutingPolicy?: AwsRoute53Record.FailoverRoutingPolicyProperty;
    /**
    * geolocation_routing_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_record#geolocation_routing_policy AwsRoute53Record#geolocation_routing_policy}
    */
    readonly geolocationRoutingPolicy?: AwsRoute53Record.GeolocationRoutingPolicyProperty;
    /**
    * geoproximity_routing_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_record#geoproximity_routing_policy AwsRoute53Record#geoproximity_routing_policy}
    */
    readonly geoproximityRoutingPolicy?: AwsRoute53Record.GeoproximityRoutingPolicyProperty;
    /**
    * latency_routing_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_record#latency_routing_policy AwsRoute53Record#latency_routing_policy}
    */
    readonly latencyRoutingPolicy?: AwsRoute53Record.LatencyRoutingPolicyProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_record#timeouts AwsRoute53Record#timeouts}
    */
    readonly timeouts?: AwsRoute53Record.TimeoutsProperty;
    /**
    * weighted_routing_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_record#weighted_routing_policy AwsRoute53Record#weighted_routing_policy}
    */
    readonly weightedRoutingPolicy?: AwsRoute53Record.WeightedRoutingPolicyProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_record aws_route53_record}
*/
export declare class AwsRoute53Record extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_route53_record";
    /**
    * Generates CDKTN code for importing a AwsRoute53Record resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsRoute53Record to import
    * @param importFromId The id of the existing AwsRoute53Record that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_record#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsRoute53Record to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_record aws_route53_record} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsRoute53RecordConfig
    */
    constructor(scope: Construct, id: string, config: AwsRoute53RecordConfig);
    private _allowOverwrite?;
    get allowOverwrite(): boolean | cdktn.IResolvable;
    set allowOverwrite(value: boolean | cdktn.IResolvable);
    resetAllowOverwrite(): void;
    get allowOverwriteInput(): boolean | cdktn.IResolvable | undefined;
    get fqdn(): string;
    private _healthCheckId?;
    get healthCheckId(): string;
    set healthCheckId(value: string);
    resetHealthCheckId(): void;
    get healthCheckIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _multivalueAnswerRoutingPolicy?;
    get multivalueAnswerRoutingPolicy(): boolean | cdktn.IResolvable;
    set multivalueAnswerRoutingPolicy(value: boolean | cdktn.IResolvable);
    resetMultivalueAnswerRoutingPolicy(): void;
    get multivalueAnswerRoutingPolicyInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _records?;
    get records(): string[];
    set records(value: string[]);
    resetRecords(): void;
    get recordsInput(): string[] | undefined;
    private _setIdentifier?;
    get setIdentifier(): string;
    set setIdentifier(value: string);
    resetSetIdentifier(): void;
    get setIdentifierInput(): string | undefined;
    private _ttl?;
    get ttl(): number;
    set ttl(value: number);
    resetTtl(): void;
    get ttlInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    get zoneIdInput(): string | undefined;
    private _alias;
    get alias(): AwsRoute53Record.AliasPropertyOutputReference;
    putAlias(value: AwsRoute53Record.AliasProperty): void;
    resetAlias(): void;
    get aliasInput(): AwsRoute53Record.AliasProperty | undefined;
    private _cidrRoutingPolicy;
    get cidrRoutingPolicy(): AwsRoute53Record.CidrRoutingPolicyPropertyOutputReference;
    putCidrRoutingPolicy(value: AwsRoute53Record.CidrRoutingPolicyProperty): void;
    resetCidrRoutingPolicy(): void;
    get cidrRoutingPolicyInput(): AwsRoute53Record.CidrRoutingPolicyProperty | undefined;
    private _failoverRoutingPolicy;
    get failoverRoutingPolicy(): AwsRoute53Record.FailoverRoutingPolicyPropertyOutputReference;
    putFailoverRoutingPolicy(value: AwsRoute53Record.FailoverRoutingPolicyProperty): void;
    resetFailoverRoutingPolicy(): void;
    get failoverRoutingPolicyInput(): AwsRoute53Record.FailoverRoutingPolicyProperty | undefined;
    private _geolocationRoutingPolicy;
    get geolocationRoutingPolicy(): AwsRoute53Record.GeolocationRoutingPolicyPropertyOutputReference;
    putGeolocationRoutingPolicy(value: AwsRoute53Record.GeolocationRoutingPolicyProperty): void;
    resetGeolocationRoutingPolicy(): void;
    get geolocationRoutingPolicyInput(): AwsRoute53Record.GeolocationRoutingPolicyProperty | undefined;
    private _geoproximityRoutingPolicy;
    get geoproximityRoutingPolicy(): AwsRoute53Record.GeoproximityRoutingPolicyPropertyOutputReference;
    putGeoproximityRoutingPolicy(value: AwsRoute53Record.GeoproximityRoutingPolicyProperty): void;
    resetGeoproximityRoutingPolicy(): void;
    get geoproximityRoutingPolicyInput(): AwsRoute53Record.GeoproximityRoutingPolicyProperty | undefined;
    private _latencyRoutingPolicy;
    get latencyRoutingPolicy(): AwsRoute53Record.LatencyRoutingPolicyPropertyOutputReference;
    putLatencyRoutingPolicy(value: AwsRoute53Record.LatencyRoutingPolicyProperty): void;
    resetLatencyRoutingPolicy(): void;
    get latencyRoutingPolicyInput(): AwsRoute53Record.LatencyRoutingPolicyProperty | undefined;
    private _timeouts;
    get timeouts(): AwsRoute53Record.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsRoute53Record.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsRoute53Record.TimeoutsProperty | undefined;
    private _weightedRoutingPolicy;
    get weightedRoutingPolicy(): AwsRoute53Record.WeightedRoutingPolicyPropertyOutputReference;
    putWeightedRoutingPolicy(value: AwsRoute53Record.WeightedRoutingPolicyProperty): void;
    resetWeightedRoutingPolicy(): void;
    get weightedRoutingPolicyInput(): AwsRoute53Record.WeightedRoutingPolicyProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsRoute53RecordAliasPropertyToTerraform(struct?: AwsRoute53Record.AliasPropertyOutputReference | AwsRoute53Record.AliasProperty): any;
export declare function awsRoute53RecordAliasPropertyToHclTerraform(struct?: AwsRoute53Record.AliasPropertyOutputReference | AwsRoute53Record.AliasProperty): any;
export declare function awsRoute53RecordCidrRoutingPolicyPropertyToTerraform(struct?: AwsRoute53Record.CidrRoutingPolicyPropertyOutputReference | AwsRoute53Record.CidrRoutingPolicyProperty): any;
export declare function awsRoute53RecordCidrRoutingPolicyPropertyToHclTerraform(struct?: AwsRoute53Record.CidrRoutingPolicyPropertyOutputReference | AwsRoute53Record.CidrRoutingPolicyProperty): any;
export declare function awsRoute53RecordFailoverRoutingPolicyPropertyToTerraform(struct?: AwsRoute53Record.FailoverRoutingPolicyPropertyOutputReference | AwsRoute53Record.FailoverRoutingPolicyProperty): any;
export declare function awsRoute53RecordFailoverRoutingPolicyPropertyToHclTerraform(struct?: AwsRoute53Record.FailoverRoutingPolicyPropertyOutputReference | AwsRoute53Record.FailoverRoutingPolicyProperty): any;
export declare function awsRoute53RecordGeolocationRoutingPolicyPropertyToTerraform(struct?: AwsRoute53Record.GeolocationRoutingPolicyPropertyOutputReference | AwsRoute53Record.GeolocationRoutingPolicyProperty): any;
export declare function awsRoute53RecordGeolocationRoutingPolicyPropertyToHclTerraform(struct?: AwsRoute53Record.GeolocationRoutingPolicyPropertyOutputReference | AwsRoute53Record.GeolocationRoutingPolicyProperty): any;
export declare function awsRoute53RecordCoordinatesPropertyToTerraform(struct?: AwsRoute53Record.CoordinatesProperty | cdktn.IResolvable): any;
export declare function awsRoute53RecordCoordinatesPropertyToHclTerraform(struct?: AwsRoute53Record.CoordinatesProperty | cdktn.IResolvable): any;
export declare function awsRoute53RecordGeoproximityRoutingPolicyPropertyToTerraform(struct?: AwsRoute53Record.GeoproximityRoutingPolicyPropertyOutputReference | AwsRoute53Record.GeoproximityRoutingPolicyProperty): any;
export declare function awsRoute53RecordGeoproximityRoutingPolicyPropertyToHclTerraform(struct?: AwsRoute53Record.GeoproximityRoutingPolicyPropertyOutputReference | AwsRoute53Record.GeoproximityRoutingPolicyProperty): any;
export declare function awsRoute53RecordLatencyRoutingPolicyPropertyToTerraform(struct?: AwsRoute53Record.LatencyRoutingPolicyPropertyOutputReference | AwsRoute53Record.LatencyRoutingPolicyProperty): any;
export declare function awsRoute53RecordLatencyRoutingPolicyPropertyToHclTerraform(struct?: AwsRoute53Record.LatencyRoutingPolicyPropertyOutputReference | AwsRoute53Record.LatencyRoutingPolicyProperty): any;
export declare function awsRoute53RecordTimeoutsPropertyToTerraform(struct?: AwsRoute53Record.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsRoute53RecordTimeoutsPropertyToHclTerraform(struct?: AwsRoute53Record.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsRoute53RecordWeightedRoutingPolicyPropertyToTerraform(struct?: AwsRoute53Record.WeightedRoutingPolicyPropertyOutputReference | AwsRoute53Record.WeightedRoutingPolicyProperty): any;
export declare function awsRoute53RecordWeightedRoutingPolicyPropertyToHclTerraform(struct?: AwsRoute53Record.WeightedRoutingPolicyPropertyOutputReference | AwsRoute53Record.WeightedRoutingPolicyProperty): any;
export declare namespace AwsRoute53Record {
    interface AliasProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_record#evaluate_target_health AwsRoute53Record#evaluate_target_health}
        */
        readonly evaluateTargetHealth: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_record#name AwsRoute53Record#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_record#zone_id AwsRoute53Record#zone_id}
        */
        readonly zoneId: string;
    }
    class AliasPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AliasProperty | undefined;
        set internalValue(value: AliasProperty | undefined);
        private _evaluateTargetHealth?;
        get evaluateTargetHealth(): boolean | cdktn.IResolvable;
        set evaluateTargetHealth(value: boolean | cdktn.IResolvable);
        get evaluateTargetHealthInput(): boolean | cdktn.IResolvable | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _zoneId?;
        get zoneId(): string;
        set zoneId(value: string);
        get zoneIdInput(): string | undefined;
    }
    interface CidrRoutingPolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_record#collection_id AwsRoute53Record#collection_id}
        */
        readonly collectionId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_record#location_name AwsRoute53Record#location_name}
        */
        readonly locationName: string;
    }
    class CidrRoutingPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CidrRoutingPolicyProperty | undefined;
        set internalValue(value: CidrRoutingPolicyProperty | undefined);
        private _collectionId?;
        get collectionId(): string;
        set collectionId(value: string);
        get collectionIdInput(): string | undefined;
        private _locationName?;
        get locationName(): string;
        set locationName(value: string);
        get locationNameInput(): string | undefined;
    }
    interface FailoverRoutingPolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_record#type AwsRoute53Record#type}
        */
        readonly type: string;
    }
    class FailoverRoutingPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FailoverRoutingPolicyProperty | undefined;
        set internalValue(value: FailoverRoutingPolicyProperty | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    interface GeolocationRoutingPolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_record#continent AwsRoute53Record#continent}
        */
        readonly continent?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_record#country AwsRoute53Record#country}
        */
        readonly country?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_record#subdivision AwsRoute53Record#subdivision}
        */
        readonly subdivision?: string;
    }
    class GeolocationRoutingPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): GeolocationRoutingPolicyProperty | undefined;
        set internalValue(value: GeolocationRoutingPolicyProperty | undefined);
        private _continent?;
        get continent(): string;
        set continent(value: string);
        resetContinent(): void;
        get continentInput(): string | undefined;
        private _country?;
        get country(): string;
        set country(value: string);
        resetCountry(): void;
        get countryInput(): string | undefined;
        private _subdivision?;
        get subdivision(): string;
        set subdivision(value: string);
        resetSubdivision(): void;
        get subdivisionInput(): string | undefined;
    }
    interface CoordinatesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_record#latitude AwsRoute53Record#latitude}
        */
        readonly latitude: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_record#longitude AwsRoute53Record#longitude}
        */
        readonly longitude: string;
    }
    class CoordinatesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CoordinatesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CoordinatesProperty | cdktn.IResolvable | undefined);
        private _latitude?;
        get latitude(): string;
        set latitude(value: string);
        get latitudeInput(): string | undefined;
        private _longitude?;
        get longitude(): string;
        set longitude(value: string);
        get longitudeInput(): string | undefined;
    }
    class CoordinatesPropertyList extends cdktn.ComplexList {
        internalValue?: CoordinatesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CoordinatesPropertyOutputReference;
    }
    interface GeoproximityRoutingPolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_record#aws_region AwsRoute53Record#aws_region}
        */
        readonly awsRegion?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_record#bias AwsRoute53Record#bias}
        */
        readonly bias?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_record#local_zone_group AwsRoute53Record#local_zone_group}
        */
        readonly localZoneGroup?: string;
        /**
        * coordinates block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_record#coordinates AwsRoute53Record#coordinates}
        */
        readonly coordinates?: CoordinatesProperty[] | cdktn.IResolvable;
    }
    class GeoproximityRoutingPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): GeoproximityRoutingPolicyProperty | undefined;
        set internalValue(value: GeoproximityRoutingPolicyProperty | undefined);
        private _awsRegion?;
        get awsRegion(): string;
        set awsRegion(value: string);
        resetAwsRegion(): void;
        get awsRegionInput(): string | undefined;
        private _bias?;
        get bias(): number;
        set bias(value: number);
        resetBias(): void;
        get biasInput(): number | undefined;
        private _localZoneGroup?;
        get localZoneGroup(): string;
        set localZoneGroup(value: string);
        resetLocalZoneGroup(): void;
        get localZoneGroupInput(): string | undefined;
        private _coordinates;
        get coordinates(): CoordinatesPropertyList;
        putCoordinates(value: CoordinatesProperty[] | cdktn.IResolvable): void;
        resetCoordinates(): void;
        get coordinatesInput(): cdktn.IResolvable | CoordinatesProperty[] | undefined;
    }
    interface LatencyRoutingPolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_record#region AwsRoute53Record#region}
        */
        readonly region: string;
    }
    class LatencyRoutingPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LatencyRoutingPolicyProperty | undefined;
        set internalValue(value: LatencyRoutingPolicyProperty | undefined);
        private _region?;
        get region(): string;
        set region(value: string);
        get regionInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_record#create AwsRoute53Record#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_record#delete AwsRoute53Record#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_record#update AwsRoute53Record#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface WeightedRoutingPolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_record#weight AwsRoute53Record#weight}
        */
        readonly weight: number;
    }
    class WeightedRoutingPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): WeightedRoutingPolicyProperty | undefined;
        set internalValue(value: WeightedRoutingPolicyProperty | undefined);
        private _weight?;
        get weight(): number;
        set weight(value: number);
        get weightInput(): number | undefined;
    }
}
