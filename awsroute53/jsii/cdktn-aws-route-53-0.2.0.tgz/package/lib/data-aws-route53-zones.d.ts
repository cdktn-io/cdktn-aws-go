import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfZonesConfig extends cdktn.TerraformMetaArguments {
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_zones aws_route53_zones}
*/
export declare class DataTfZones extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_route53_zones";
    /**
    * Generates CDKTN code for importing a DataTfZones resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfZones to import
    * @param importFromId The id of the existing DataTfZones that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_zones#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfZones to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_zones aws_route53_zones} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfZonesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataTfZonesConfig);
    get id(): string;
    get ids(): string[];
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
