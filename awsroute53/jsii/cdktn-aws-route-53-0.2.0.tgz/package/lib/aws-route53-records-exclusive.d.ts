import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfRecordsExclusiveConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#zone_id TfRecordsExclusive#zone_id}
    */
    readonly zoneId: string;
    /**
    * resource_record_set block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#resource_record_set TfRecordsExclusive#resource_record_set}
    */
    readonly resourceRecordSet?: TfRecordsExclusive.ResourceRecordSetProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#timeouts TfRecordsExclusive#timeouts}
    */
    readonly timeouts?: TfRecordsExclusive.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive aws_route53_records_exclusive}
*/
export declare class TfRecordsExclusive extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_route53_records_exclusive";
    /**
    * Generates CDKTN code for importing a TfRecordsExclusive resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfRecordsExclusive to import
    * @param importFromId The id of the existing TfRecordsExclusive that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfRecordsExclusive to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive aws_route53_records_exclusive} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfRecordsExclusiveConfig
    */
    constructor(scope: Construct, id: string, config: TfRecordsExclusiveConfig);
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    get zoneIdInput(): string | undefined;
    private _resourceRecordSet;
    get resourceRecordSet(): TfRecordsExclusive.ResourceRecordSetPropertyList;
    putResourceRecordSet(value: TfRecordsExclusive.ResourceRecordSetProperty[] | cdktn.IResolvable): void;
    resetResourceRecordSet(): void;
    get resourceRecordSetInput(): cdktn.IResolvable | TfRecordsExclusive.ResourceRecordSetProperty[] | undefined;
    private _timeouts;
    get timeouts(): TfRecordsExclusive.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfRecordsExclusive.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfRecordsExclusive.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfRecordsExclusiveAliasTargetPropertyToTerraform(struct?: TfRecordsExclusive.AliasTargetProperty | cdktn.IResolvable): any;
export declare function tfRecordsExclusiveAliasTargetPropertyToHclTerraform(struct?: TfRecordsExclusive.AliasTargetProperty | cdktn.IResolvable): any;
export declare function tfRecordsExclusiveCidrRoutingConfigPropertyToTerraform(struct?: TfRecordsExclusive.CidrRoutingConfigProperty | cdktn.IResolvable): any;
export declare function tfRecordsExclusiveCidrRoutingConfigPropertyToHclTerraform(struct?: TfRecordsExclusive.CidrRoutingConfigProperty | cdktn.IResolvable): any;
export declare function tfRecordsExclusiveGeolocationPropertyToTerraform(struct?: TfRecordsExclusive.GeolocationProperty | cdktn.IResolvable): any;
export declare function tfRecordsExclusiveGeolocationPropertyToHclTerraform(struct?: TfRecordsExclusive.GeolocationProperty | cdktn.IResolvable): any;
export declare function tfRecordsExclusiveCoordinatesPropertyToTerraform(struct?: TfRecordsExclusive.CoordinatesProperty | cdktn.IResolvable): any;
export declare function tfRecordsExclusiveCoordinatesPropertyToHclTerraform(struct?: TfRecordsExclusive.CoordinatesProperty | cdktn.IResolvable): any;
export declare function tfRecordsExclusiveGeoproximityLocationPropertyToTerraform(struct?: TfRecordsExclusive.GeoproximityLocationProperty | cdktn.IResolvable): any;
export declare function tfRecordsExclusiveGeoproximityLocationPropertyToHclTerraform(struct?: TfRecordsExclusive.GeoproximityLocationProperty | cdktn.IResolvable): any;
export declare function tfRecordsExclusiveResourceRecordsPropertyToTerraform(struct?: TfRecordsExclusive.ResourceRecordsProperty | cdktn.IResolvable): any;
export declare function tfRecordsExclusiveResourceRecordsPropertyToHclTerraform(struct?: TfRecordsExclusive.ResourceRecordsProperty | cdktn.IResolvable): any;
export declare function tfRecordsExclusiveResourceRecordSetPropertyToTerraform(struct?: TfRecordsExclusive.ResourceRecordSetProperty | cdktn.IResolvable): any;
export declare function tfRecordsExclusiveResourceRecordSetPropertyToHclTerraform(struct?: TfRecordsExclusive.ResourceRecordSetProperty | cdktn.IResolvable): any;
export declare function tfRecordsExclusiveTimeoutsPropertyToTerraform(struct?: TfRecordsExclusive.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfRecordsExclusiveTimeoutsPropertyToHclTerraform(struct?: TfRecordsExclusive.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfRecordsExclusive {
    interface AliasTargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#dns_name TfRecordsExclusive#dns_name}
        */
        readonly dnsName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#evaluate_target_health TfRecordsExclusive#evaluate_target_health}
        */
        readonly evaluateTargetHealth: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#hosted_zone_id TfRecordsExclusive#hosted_zone_id}
        */
        readonly hostedZoneId: string;
    }
    class AliasTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AliasTargetProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AliasTargetProperty | cdktn.IResolvable | undefined);
        private _dnsName?;
        get dnsName(): string;
        set dnsName(value: string);
        get dnsNameInput(): string | undefined;
        private _evaluateTargetHealth?;
        get evaluateTargetHealth(): boolean | cdktn.IResolvable;
        set evaluateTargetHealth(value: boolean | cdktn.IResolvable);
        get evaluateTargetHealthInput(): boolean | cdktn.IResolvable | undefined;
        private _hostedZoneId?;
        get hostedZoneId(): string;
        set hostedZoneId(value: string);
        get hostedZoneIdInput(): string | undefined;
    }
    class AliasTargetPropertyList extends cdktn.ComplexList {
        internalValue?: AliasTargetProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AliasTargetPropertyOutputReference;
    }
    interface CidrRoutingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#collection_id TfRecordsExclusive#collection_id}
        */
        readonly collectionId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#location_name TfRecordsExclusive#location_name}
        */
        readonly locationName: string;
    }
    class CidrRoutingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CidrRoutingConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CidrRoutingConfigProperty | cdktn.IResolvable | undefined);
        private _collectionId?;
        get collectionId(): string;
        set collectionId(value: string);
        get collectionIdInput(): string | undefined;
        private _locationName?;
        get locationName(): string;
        set locationName(value: string);
        get locationNameInput(): string | undefined;
    }
    class CidrRoutingConfigPropertyList extends cdktn.ComplexList {
        internalValue?: CidrRoutingConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CidrRoutingConfigPropertyOutputReference;
    }
    interface GeolocationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#continent_code TfRecordsExclusive#continent_code}
        */
        readonly continentCode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#country_code TfRecordsExclusive#country_code}
        */
        readonly countryCode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#subdivision_code TfRecordsExclusive#subdivision_code}
        */
        readonly subdivisionCode?: string;
    }
    class GeolocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GeolocationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: GeolocationProperty | cdktn.IResolvable | undefined);
        private _continentCode?;
        get continentCode(): string;
        set continentCode(value: string);
        resetContinentCode(): void;
        get continentCodeInput(): string | undefined;
        private _countryCode?;
        get countryCode(): string;
        set countryCode(value: string);
        resetCountryCode(): void;
        get countryCodeInput(): string | undefined;
        private _subdivisionCode?;
        get subdivisionCode(): string;
        set subdivisionCode(value: string);
        resetSubdivisionCode(): void;
        get subdivisionCodeInput(): string | undefined;
    }
    class GeolocationPropertyList extends cdktn.ComplexList {
        internalValue?: GeolocationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GeolocationPropertyOutputReference;
    }
    interface CoordinatesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#latitude TfRecordsExclusive#latitude}
        */
        readonly latitude: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#longitude TfRecordsExclusive#longitude}
        */
        readonly longitude: string;
    }
    class CoordinatesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CoordinatesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CoordinatesProperty | cdktn.IResolvable | undefined);
        private _latitude?;
        get latitude(): string;
        set latitude(value: string);
        get latitudeInput(): string | undefined;
        private _longitude?;
        get longitude(): string;
        set longitude(value: string);
        get longitudeInput(): string | undefined;
    }
    class CoordinatesPropertyList extends cdktn.ComplexList {
        internalValue?: CoordinatesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CoordinatesPropertyOutputReference;
    }
    interface GeoproximityLocationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#aws_region TfRecordsExclusive#aws_region}
        */
        readonly awsRegion?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#bias TfRecordsExclusive#bias}
        */
        readonly bias?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#local_zone_group TfRecordsExclusive#local_zone_group}
        */
        readonly localZoneGroup?: string;
        /**
        * coordinates block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#coordinates TfRecordsExclusive#coordinates}
        */
        readonly coordinates?: CoordinatesProperty[] | cdktn.IResolvable;
    }
    class GeoproximityLocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GeoproximityLocationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: GeoproximityLocationProperty | cdktn.IResolvable | undefined);
        private _awsRegion?;
        get awsRegion(): string;
        set awsRegion(value: string);
        resetAwsRegion(): void;
        get awsRegionInput(): string | undefined;
        private _bias?;
        get bias(): number;
        set bias(value: number);
        resetBias(): void;
        get biasInput(): number | undefined;
        private _localZoneGroup?;
        get localZoneGroup(): string;
        set localZoneGroup(value: string);
        resetLocalZoneGroup(): void;
        get localZoneGroupInput(): string | undefined;
        private _coordinates;
        get coordinates(): CoordinatesPropertyList;
        putCoordinates(value: CoordinatesProperty[] | cdktn.IResolvable): void;
        resetCoordinates(): void;
        get coordinatesInput(): cdktn.IResolvable | CoordinatesProperty[] | undefined;
    }
    class GeoproximityLocationPropertyList extends cdktn.ComplexList {
        internalValue?: GeoproximityLocationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GeoproximityLocationPropertyOutputReference;
    }
    interface ResourceRecordsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#value TfRecordsExclusive#value}
        */
        readonly value: string;
    }
    class ResourceRecordsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceRecordsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceRecordsProperty | cdktn.IResolvable | undefined);
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ResourceRecordsPropertyList extends cdktn.ComplexList {
        internalValue?: ResourceRecordsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceRecordsPropertyOutputReference;
    }
    interface ResourceRecordSetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#failover TfRecordsExclusive#failover}
        */
        readonly failover?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#health_check_id TfRecordsExclusive#health_check_id}
        */
        readonly healthCheckId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#multi_value_answer TfRecordsExclusive#multi_value_answer}
        */
        readonly multiValueAnswer?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#name TfRecordsExclusive#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#region TfRecordsExclusive#region}
        */
        readonly region?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#set_identifier TfRecordsExclusive#set_identifier}
        */
        readonly setIdentifier?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#traffic_policy_instance_id TfRecordsExclusive#traffic_policy_instance_id}
        */
        readonly trafficPolicyInstanceId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#ttl TfRecordsExclusive#ttl}
        */
        readonly ttl?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#type TfRecordsExclusive#type}
        */
        readonly type?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#weight TfRecordsExclusive#weight}
        */
        readonly weight?: number;
        /**
        * alias_target block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#alias_target TfRecordsExclusive#alias_target}
        */
        readonly aliasTarget?: AliasTargetProperty[] | cdktn.IResolvable;
        /**
        * cidr_routing_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#cidr_routing_config TfRecordsExclusive#cidr_routing_config}
        */
        readonly cidrRoutingConfig?: CidrRoutingConfigProperty[] | cdktn.IResolvable;
        /**
        * geolocation block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#geolocation TfRecordsExclusive#geolocation}
        */
        readonly geolocation?: GeolocationProperty[] | cdktn.IResolvable;
        /**
        * geoproximity_location block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#geoproximity_location TfRecordsExclusive#geoproximity_location}
        */
        readonly geoproximityLocation?: GeoproximityLocationProperty[] | cdktn.IResolvable;
        /**
        * resource_records block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#resource_records TfRecordsExclusive#resource_records}
        */
        readonly resourceRecords?: ResourceRecordsProperty[] | cdktn.IResolvable;
    }
    class ResourceRecordSetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceRecordSetProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceRecordSetProperty | cdktn.IResolvable | undefined);
        private _failover?;
        get failover(): string;
        set failover(value: string);
        resetFailover(): void;
        get failoverInput(): string | undefined;
        private _healthCheckId?;
        get healthCheckId(): string;
        set healthCheckId(value: string);
        resetHealthCheckId(): void;
        get healthCheckIdInput(): string | undefined;
        private _multiValueAnswer?;
        get multiValueAnswer(): boolean | cdktn.IResolvable;
        set multiValueAnswer(value: boolean | cdktn.IResolvable);
        resetMultiValueAnswer(): void;
        get multiValueAnswerInput(): boolean | cdktn.IResolvable | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _region?;
        get region(): string;
        set region(value: string);
        resetRegion(): void;
        get regionInput(): string | undefined;
        private _setIdentifier?;
        get setIdentifier(): string;
        set setIdentifier(value: string);
        resetSetIdentifier(): void;
        get setIdentifierInput(): string | undefined;
        private _trafficPolicyInstanceId?;
        get trafficPolicyInstanceId(): string;
        set trafficPolicyInstanceId(value: string);
        resetTrafficPolicyInstanceId(): void;
        get trafficPolicyInstanceIdInput(): string | undefined;
        private _ttl?;
        get ttl(): number;
        set ttl(value: number);
        resetTtl(): void;
        get ttlInput(): number | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
        private _weight?;
        get weight(): number;
        set weight(value: number);
        resetWeight(): void;
        get weightInput(): number | undefined;
        private _aliasTarget;
        get aliasTarget(): AliasTargetPropertyList;
        putAliasTarget(value: AliasTargetProperty[] | cdktn.IResolvable): void;
        resetAliasTarget(): void;
        get aliasTargetInput(): cdktn.IResolvable | AliasTargetProperty[] | undefined;
        private _cidrRoutingConfig;
        get cidrRoutingConfig(): CidrRoutingConfigPropertyList;
        putCidrRoutingConfig(value: CidrRoutingConfigProperty[] | cdktn.IResolvable): void;
        resetCidrRoutingConfig(): void;
        get cidrRoutingConfigInput(): cdktn.IResolvable | CidrRoutingConfigProperty[] | undefined;
        private _geolocation;
        get geolocation(): GeolocationPropertyList;
        putGeolocation(value: GeolocationProperty[] | cdktn.IResolvable): void;
        resetGeolocation(): void;
        get geolocationInput(): cdktn.IResolvable | GeolocationProperty[] | undefined;
        private _geoproximityLocation;
        get geoproximityLocation(): GeoproximityLocationPropertyList;
        putGeoproximityLocation(value: GeoproximityLocationProperty[] | cdktn.IResolvable): void;
        resetGeoproximityLocation(): void;
        get geoproximityLocationInput(): cdktn.IResolvable | GeoproximityLocationProperty[] | undefined;
        private _resourceRecords;
        get resourceRecords(): ResourceRecordsPropertyList;
        putResourceRecords(value: ResourceRecordsProperty[] | cdktn.IResolvable): void;
        resetResourceRecords(): void;
        get resourceRecordsInput(): cdktn.IResolvable | ResourceRecordsProperty[] | undefined;
    }
    class ResourceRecordSetPropertyList extends cdktn.ComplexList {
        internalValue?: ResourceRecordSetProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceRecordSetPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#create TfRecordsExclusive#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#update TfRecordsExclusive#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
