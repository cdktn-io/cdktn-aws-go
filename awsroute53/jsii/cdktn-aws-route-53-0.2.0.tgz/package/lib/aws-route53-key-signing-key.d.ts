import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfKeySigningKeyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_key_signing_key#hosted_zone_id TfKeySigningKey#hosted_zone_id}
    */
    readonly hostedZoneId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_key_signing_key#id TfKeySigningKey#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_key_signing_key#key_management_service_arn TfKeySigningKey#key_management_service_arn}
    */
    readonly keyManagementServiceArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_key_signing_key#name TfKeySigningKey#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_key_signing_key#status TfKeySigningKey#status}
    */
    readonly status?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_key_signing_key#timeouts TfKeySigningKey#timeouts}
    */
    readonly timeouts?: TfKeySigningKey.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_key_signing_key aws_route53_key_signing_key}
*/
export declare class TfKeySigningKey extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_route53_key_signing_key";
    /**
    * Generates CDKTN code for importing a TfKeySigningKey resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfKeySigningKey to import
    * @param importFromId The id of the existing TfKeySigningKey that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_key_signing_key#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfKeySigningKey to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_key_signing_key aws_route53_key_signing_key} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfKeySigningKeyConfig
    */
    constructor(scope: Construct, id: string, config: TfKeySigningKeyConfig);
    get digestAlgorithmMnemonic(): string;
    get digestAlgorithmType(): number;
    get digestValue(): string;
    get dnskeyRecord(): string;
    get dsRecord(): string;
    get flag(): number;
    private _hostedZoneId?;
    get hostedZoneId(): string;
    set hostedZoneId(value: string);
    get hostedZoneIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _keyManagementServiceArn?;
    get keyManagementServiceArn(): string;
    set keyManagementServiceArn(value: string);
    get keyManagementServiceArnInput(): string | undefined;
    get keyTag(): number;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get publicKey(): string;
    get signingAlgorithmMnemonic(): string;
    get signingAlgorithmType(): number;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _timeouts;
    get timeouts(): TfKeySigningKey.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfKeySigningKey.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfKeySigningKey.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfKeySigningKeyTimeoutsPropertyToTerraform(struct?: TfKeySigningKey.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfKeySigningKeyTimeoutsPropertyToHclTerraform(struct?: TfKeySigningKey.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfKeySigningKey {
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_key_signing_key#create TfKeySigningKey#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_key_signing_key#delete TfKeySigningKey#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_key_signing_key#update TfKeySigningKey#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
