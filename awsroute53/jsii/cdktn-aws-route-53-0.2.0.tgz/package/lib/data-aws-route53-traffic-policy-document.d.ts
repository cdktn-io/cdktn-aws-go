import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfTrafficPolicyDocumentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document#id DataTfTrafficPolicyDocument#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document#record_type DataTfTrafficPolicyDocument#record_type}
    */
    readonly recordType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document#start_endpoint DataTfTrafficPolicyDocument#start_endpoint}
    */
    readonly startEndpoint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document#start_rule DataTfTrafficPolicyDocument#start_rule}
    */
    readonly startRule?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document#version DataTfTrafficPolicyDocument#version}
    */
    readonly version?: string;
    /**
    * endpoint block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document#endpoint DataTfTrafficPolicyDocument#endpoint}
    */
    readonly endpoint?: DataTfTrafficPolicyDocument.EndpointProperty[] | cdktn.IResolvable;
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document#rule DataTfTrafficPolicyDocument#rule}
    */
    readonly rule?: DataTfTrafficPolicyDocument.RuleProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document aws_route53_traffic_policy_document}
*/
export declare class DataTfTrafficPolicyDocument extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_route53_traffic_policy_document";
    /**
    * Generates CDKTN code for importing a DataTfTrafficPolicyDocument resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfTrafficPolicyDocument to import
    * @param importFromId The id of the existing DataTfTrafficPolicyDocument that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfTrafficPolicyDocument to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document aws_route53_traffic_policy_document} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfTrafficPolicyDocumentConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataTfTrafficPolicyDocumentConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get json(): string;
    private _recordType?;
    get recordType(): string;
    set recordType(value: string);
    resetRecordType(): void;
    get recordTypeInput(): string | undefined;
    private _startEndpoint?;
    get startEndpoint(): string;
    set startEndpoint(value: string);
    resetStartEndpoint(): void;
    get startEndpointInput(): string | undefined;
    private _startRule?;
    get startRule(): string;
    set startRule(value: string);
    resetStartRule(): void;
    get startRuleInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
    private _endpoint;
    get endpoint(): DataTfTrafficPolicyDocument.EndpointPropertyList;
    putEndpoint(value: DataTfTrafficPolicyDocument.EndpointProperty[] | cdktn.IResolvable): void;
    resetEndpoint(): void;
    get endpointInput(): cdktn.IResolvable | DataTfTrafficPolicyDocument.EndpointProperty[] | undefined;
    private _rule;
    get rule(): DataTfTrafficPolicyDocument.RulePropertyList;
    putRule(value: DataTfTrafficPolicyDocument.RuleProperty[] | cdktn.IResolvable): void;
    resetRule(): void;
    get ruleInput(): cdktn.IResolvable | DataTfTrafficPolicyDocument.RuleProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfTrafficPolicyDocumentEndpointPropertyToTerraform(struct?: DataTfTrafficPolicyDocument.EndpointProperty | cdktn.IResolvable): any;
export declare function dataTfTrafficPolicyDocumentEndpointPropertyToHclTerraform(struct?: DataTfTrafficPolicyDocument.EndpointProperty | cdktn.IResolvable): any;
export declare function dataTfTrafficPolicyDocumentGeoProximityLocationPropertyToTerraform(struct?: DataTfTrafficPolicyDocument.GeoProximityLocationProperty | cdktn.IResolvable): any;
export declare function dataTfTrafficPolicyDocumentGeoProximityLocationPropertyToHclTerraform(struct?: DataTfTrafficPolicyDocument.GeoProximityLocationProperty | cdktn.IResolvable): any;
export declare function dataTfTrafficPolicyDocumentItemsPropertyToTerraform(struct?: DataTfTrafficPolicyDocument.ItemsProperty | cdktn.IResolvable): any;
export declare function dataTfTrafficPolicyDocumentItemsPropertyToHclTerraform(struct?: DataTfTrafficPolicyDocument.ItemsProperty | cdktn.IResolvable): any;
export declare function dataTfTrafficPolicyDocumentLocationPropertyToTerraform(struct?: DataTfTrafficPolicyDocument.LocationProperty | cdktn.IResolvable): any;
export declare function dataTfTrafficPolicyDocumentLocationPropertyToHclTerraform(struct?: DataTfTrafficPolicyDocument.LocationProperty | cdktn.IResolvable): any;
export declare function dataTfTrafficPolicyDocumentPrimaryPropertyToTerraform(struct?: DataTfTrafficPolicyDocument.PrimaryPropertyOutputReference | DataTfTrafficPolicyDocument.PrimaryProperty): any;
export declare function dataTfTrafficPolicyDocumentPrimaryPropertyToHclTerraform(struct?: DataTfTrafficPolicyDocument.PrimaryPropertyOutputReference | DataTfTrafficPolicyDocument.PrimaryProperty): any;
export declare function dataTfTrafficPolicyDocumentRegionPropertyToTerraform(struct?: DataTfTrafficPolicyDocument.RegionProperty | cdktn.IResolvable): any;
export declare function dataTfTrafficPolicyDocumentRegionPropertyToHclTerraform(struct?: DataTfTrafficPolicyDocument.RegionProperty | cdktn.IResolvable): any;
export declare function dataTfTrafficPolicyDocumentSecondaryPropertyToTerraform(struct?: DataTfTrafficPolicyDocument.SecondaryPropertyOutputReference | DataTfTrafficPolicyDocument.SecondaryProperty): any;
export declare function dataTfTrafficPolicyDocumentSecondaryPropertyToHclTerraform(struct?: DataTfTrafficPolicyDocument.SecondaryPropertyOutputReference | DataTfTrafficPolicyDocument.SecondaryProperty): any;
export declare function dataTfTrafficPolicyDocumentRulePropertyToTerraform(struct?: DataTfTrafficPolicyDocument.RuleProperty | cdktn.IResolvable): any;
export declare function dataTfTrafficPolicyDocumentRulePropertyToHclTerraform(struct?: DataTfTrafficPolicyDocument.RuleProperty | cdktn.IResolvable): any;
export declare namespace DataTfTrafficPolicyDocument {
    interface EndpointProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document#id DataTfTrafficPolicyDocument#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document#region DataTfTrafficPolicyDocument#region}
        */
        readonly region?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document#type DataTfTrafficPolicyDocument#type}
        */
        readonly type?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document#value DataTfTrafficPolicyDocument#value}
        */
        readonly value?: string;
    }
    class EndpointPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EndpointProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EndpointProperty | cdktn.IResolvable | undefined);
        private _id?;
        get id(): string;
        set id(value: string);
        get idInput(): string | undefined;
        private _region?;
        get region(): string;
        set region(value: string);
        resetRegion(): void;
        get regionInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        resetValue(): void;
        get valueInput(): string | undefined;
    }
    class EndpointPropertyList extends cdktn.ComplexList {
        internalValue?: EndpointProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EndpointPropertyOutputReference;
    }
    interface GeoProximityLocationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document#bias DataTfTrafficPolicyDocument#bias}
        */
        readonly bias?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document#endpoint_reference DataTfTrafficPolicyDocument#endpoint_reference}
        */
        readonly endpointReference?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document#evaluate_target_health DataTfTrafficPolicyDocument#evaluate_target_health}
        */
        readonly evaluateTargetHealth?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document#health_check DataTfTrafficPolicyDocument#health_check}
        */
        readonly healthCheck?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document#latitude DataTfTrafficPolicyDocument#latitude}
        */
        readonly latitude?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document#longitude DataTfTrafficPolicyDocument#longitude}
        */
        readonly longitude?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document#region DataTfTrafficPolicyDocument#region}
        */
        readonly region?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document#rule_reference DataTfTrafficPolicyDocument#rule_reference}
        */
        readonly ruleReference?: string;
    }
    class GeoProximityLocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GeoProximityLocationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: GeoProximityLocationProperty | cdktn.IResolvable | undefined);
        private _bias?;
        get bias(): string;
        set bias(value: string);
        resetBias(): void;
        get biasInput(): string | undefined;
        private _endpointReference?;
        get endpointReference(): string;
        set endpointReference(value: string);
        resetEndpointReference(): void;
        get endpointReferenceInput(): string | undefined;
        private _evaluateTargetHealth?;
        get evaluateTargetHealth(): boolean | cdktn.IResolvable;
        set evaluateTargetHealth(value: boolean | cdktn.IResolvable);
        resetEvaluateTargetHealth(): void;
        get evaluateTargetHealthInput(): boolean | cdktn.IResolvable | undefined;
        private _healthCheck?;
        get healthCheck(): string;
        set healthCheck(value: string);
        resetHealthCheck(): void;
        get healthCheckInput(): string | undefined;
        private _latitude?;
        get latitude(): string;
        set latitude(value: string);
        resetLatitude(): void;
        get latitudeInput(): string | undefined;
        private _longitude?;
        get longitude(): string;
        set longitude(value: string);
        resetLongitude(): void;
        get longitudeInput(): string | undefined;
        private _region?;
        get region(): string;
        set region(value: string);
        resetRegion(): void;
        get regionInput(): string | undefined;
        private _ruleReference?;
        get ruleReference(): string;
        set ruleReference(value: string);
        resetRuleReference(): void;
        get ruleReferenceInput(): string | undefined;
    }
    class GeoProximityLocationPropertyList extends cdktn.ComplexList {
        internalValue?: GeoProximityLocationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GeoProximityLocationPropertyOutputReference;
    }
    interface ItemsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document#endpoint_reference DataTfTrafficPolicyDocument#endpoint_reference}
        */
        readonly endpointReference?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document#health_check DataTfTrafficPolicyDocument#health_check}
        */
        readonly healthCheck?: string;
    }
    class ItemsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ItemsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ItemsProperty | cdktn.IResolvable | undefined);
        private _endpointReference?;
        get endpointReference(): string;
        set endpointReference(value: string);
        resetEndpointReference(): void;
        get endpointReferenceInput(): string | undefined;
        private _healthCheck?;
        get healthCheck(): string;
        set healthCheck(value: string);
        resetHealthCheck(): void;
        get healthCheckInput(): string | undefined;
    }
    class ItemsPropertyList extends cdktn.ComplexList {
        internalValue?: ItemsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ItemsPropertyOutputReference;
    }
    interface LocationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document#continent DataTfTrafficPolicyDocument#continent}
        */
        readonly continent?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document#country DataTfTrafficPolicyDocument#country}
        */
        readonly country?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document#endpoint_reference DataTfTrafficPolicyDocument#endpoint_reference}
        */
        readonly endpointReference?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document#evaluate_target_health DataTfTrafficPolicyDocument#evaluate_target_health}
        */
        readonly evaluateTargetHealth?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document#health_check DataTfTrafficPolicyDocument#health_check}
        */
        readonly healthCheck?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document#is_default DataTfTrafficPolicyDocument#is_default}
        */
        readonly isDefault?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document#rule_reference DataTfTrafficPolicyDocument#rule_reference}
        */
        readonly ruleReference?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document#subdivision DataTfTrafficPolicyDocument#subdivision}
        */
        readonly subdivision?: string;
    }
    class LocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LocationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LocationProperty | cdktn.IResolvable | undefined);
        private _continent?;
        get continent(): string;
        set continent(value: string);
        resetContinent(): void;
        get continentInput(): string | undefined;
        private _country?;
        get country(): string;
        set country(value: string);
        resetCountry(): void;
        get countryInput(): string | undefined;
        private _endpointReference?;
        get endpointReference(): string;
        set endpointReference(value: string);
        resetEndpointReference(): void;
        get endpointReferenceInput(): string | undefined;
        private _evaluateTargetHealth?;
        get evaluateTargetHealth(): boolean | cdktn.IResolvable;
        set evaluateTargetHealth(value: boolean | cdktn.IResolvable);
        resetEvaluateTargetHealth(): void;
        get evaluateTargetHealthInput(): boolean | cdktn.IResolvable | undefined;
        private _healthCheck?;
        get healthCheck(): string;
        set healthCheck(value: string);
        resetHealthCheck(): void;
        get healthCheckInput(): string | undefined;
        private _isDefault?;
        get isDefault(): boolean | cdktn.IResolvable;
        set isDefault(value: boolean | cdktn.IResolvable);
        resetIsDefault(): void;
        get isDefaultInput(): boolean | cdktn.IResolvable | undefined;
        private _ruleReference?;
        get ruleReference(): string;
        set ruleReference(value: string);
        resetRuleReference(): void;
        get ruleReferenceInput(): string | undefined;
        private _subdivision?;
        get subdivision(): string;
        set subdivision(value: string);
        resetSubdivision(): void;
        get subdivisionInput(): string | undefined;
    }
    class LocationPropertyList extends cdktn.ComplexList {
        internalValue?: LocationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LocationPropertyOutputReference;
    }
    interface PrimaryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document#endpoint_reference DataTfTrafficPolicyDocument#endpoint_reference}
        */
        readonly endpointReference?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document#evaluate_target_health DataTfTrafficPolicyDocument#evaluate_target_health}
        */
        readonly evaluateTargetHealth?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document#health_check DataTfTrafficPolicyDocument#health_check}
        */
        readonly healthCheck?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document#rule_reference DataTfTrafficPolicyDocument#rule_reference}
        */
        readonly ruleReference?: string;
    }
    class PrimaryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PrimaryProperty | undefined;
        set internalValue(value: PrimaryProperty | undefined);
        private _endpointReference?;
        get endpointReference(): string;
        set endpointReference(value: string);
        resetEndpointReference(): void;
        get endpointReferenceInput(): string | undefined;
        private _evaluateTargetHealth?;
        get evaluateTargetHealth(): boolean | cdktn.IResolvable;
        set evaluateTargetHealth(value: boolean | cdktn.IResolvable);
        resetEvaluateTargetHealth(): void;
        get evaluateTargetHealthInput(): boolean | cdktn.IResolvable | undefined;
        private _healthCheck?;
        get healthCheck(): string;
        set healthCheck(value: string);
        resetHealthCheck(): void;
        get healthCheckInput(): string | undefined;
        private _ruleReference?;
        get ruleReference(): string;
        set ruleReference(value: string);
        resetRuleReference(): void;
        get ruleReferenceInput(): string | undefined;
    }
    interface RegionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document#endpoint_reference DataTfTrafficPolicyDocument#endpoint_reference}
        */
        readonly endpointReference?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document#evaluate_target_health DataTfTrafficPolicyDocument#evaluate_target_health}
        */
        readonly evaluateTargetHealth?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document#health_check DataTfTrafficPolicyDocument#health_check}
        */
        readonly healthCheck?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document#region DataTfTrafficPolicyDocument#region}
        */
        readonly region?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document#rule_reference DataTfTrafficPolicyDocument#rule_reference}
        */
        readonly ruleReference?: string;
    }
    class RegionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RegionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RegionProperty | cdktn.IResolvable | undefined);
        private _endpointReference?;
        get endpointReference(): string;
        set endpointReference(value: string);
        resetEndpointReference(): void;
        get endpointReferenceInput(): string | undefined;
        private _evaluateTargetHealth?;
        get evaluateTargetHealth(): boolean | cdktn.IResolvable;
        set evaluateTargetHealth(value: boolean | cdktn.IResolvable);
        resetEvaluateTargetHealth(): void;
        get evaluateTargetHealthInput(): boolean | cdktn.IResolvable | undefined;
        private _healthCheck?;
        get healthCheck(): string;
        set healthCheck(value: string);
        resetHealthCheck(): void;
        get healthCheckInput(): string | undefined;
        private _region?;
        get region(): string;
        set region(value: string);
        resetRegion(): void;
        get regionInput(): string | undefined;
        private _ruleReference?;
        get ruleReference(): string;
        set ruleReference(value: string);
        resetRuleReference(): void;
        get ruleReferenceInput(): string | undefined;
    }
    class RegionPropertyList extends cdktn.ComplexList {
        internalValue?: RegionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RegionPropertyOutputReference;
    }
    interface SecondaryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document#endpoint_reference DataTfTrafficPolicyDocument#endpoint_reference}
        */
        readonly endpointReference?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document#evaluate_target_health DataTfTrafficPolicyDocument#evaluate_target_health}
        */
        readonly evaluateTargetHealth?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document#health_check DataTfTrafficPolicyDocument#health_check}
        */
        readonly healthCheck?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document#rule_reference DataTfTrafficPolicyDocument#rule_reference}
        */
        readonly ruleReference?: string;
    }
    class SecondaryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SecondaryProperty | undefined;
        set internalValue(value: SecondaryProperty | undefined);
        private _endpointReference?;
        get endpointReference(): string;
        set endpointReference(value: string);
        resetEndpointReference(): void;
        get endpointReferenceInput(): string | undefined;
        private _evaluateTargetHealth?;
        get evaluateTargetHealth(): boolean | cdktn.IResolvable;
        set evaluateTargetHealth(value: boolean | cdktn.IResolvable);
        resetEvaluateTargetHealth(): void;
        get evaluateTargetHealthInput(): boolean | cdktn.IResolvable | undefined;
        private _healthCheck?;
        get healthCheck(): string;
        set healthCheck(value: string);
        resetHealthCheck(): void;
        get healthCheckInput(): string | undefined;
        private _ruleReference?;
        get ruleReference(): string;
        set ruleReference(value: string);
        resetRuleReference(): void;
        get ruleReferenceInput(): string | undefined;
    }
    interface RuleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document#id DataTfTrafficPolicyDocument#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document#type DataTfTrafficPolicyDocument#type}
        */
        readonly type?: string;
        /**
        * geo_proximity_location block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document#geo_proximity_location DataTfTrafficPolicyDocument#geo_proximity_location}
        */
        readonly geoProximityLocation?: GeoProximityLocationProperty[] | cdktn.IResolvable;
        /**
        * items block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document#items DataTfTrafficPolicyDocument#items}
        */
        readonly items?: ItemsProperty[] | cdktn.IResolvable;
        /**
        * location block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document#location DataTfTrafficPolicyDocument#location}
        */
        readonly location?: LocationProperty[] | cdktn.IResolvable;
        /**
        * primary block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document#primary DataTfTrafficPolicyDocument#primary}
        */
        readonly primary?: PrimaryProperty;
        /**
        * region block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document#region DataTfTrafficPolicyDocument#region}
        */
        readonly region?: RegionProperty[] | cdktn.IResolvable;
        /**
        * secondary block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_traffic_policy_document#secondary DataTfTrafficPolicyDocument#secondary}
        */
        readonly secondary?: SecondaryProperty;
    }
    class RulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleProperty | cdktn.IResolvable | undefined);
        private _id?;
        get id(): string;
        set id(value: string);
        get idInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
        private _geoProximityLocation;
        get geoProximityLocation(): GeoProximityLocationPropertyList;
        putGeoProximityLocation(value: GeoProximityLocationProperty[] | cdktn.IResolvable): void;
        resetGeoProximityLocation(): void;
        get geoProximityLocationInput(): cdktn.IResolvable | GeoProximityLocationProperty[] | undefined;
        private _items;
        get items(): ItemsPropertyList;
        putItems(value: ItemsProperty[] | cdktn.IResolvable): void;
        resetItems(): void;
        get itemsInput(): cdktn.IResolvable | ItemsProperty[] | undefined;
        private _location;
        get location(): LocationPropertyList;
        putLocation(value: LocationProperty[] | cdktn.IResolvable): void;
        resetLocation(): void;
        get locationInput(): cdktn.IResolvable | LocationProperty[] | undefined;
        private _primary;
        get primary(): PrimaryPropertyOutputReference;
        putPrimary(value: PrimaryProperty): void;
        resetPrimary(): void;
        get primaryInput(): PrimaryProperty | undefined;
        private _region;
        get region(): RegionPropertyList;
        putRegion(value: RegionProperty[] | cdktn.IResolvable): void;
        resetRegion(): void;
        get regionInput(): cdktn.IResolvable | RegionProperty[] | undefined;
        private _secondary;
        get secondary(): SecondaryPropertyOutputReference;
        putSecondary(value: SecondaryProperty): void;
        resetSecondary(): void;
        get secondaryInput(): SecondaryProperty | undefined;
    }
    class RulePropertyList extends cdktn.ComplexList {
        internalValue?: RuleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RulePropertyOutputReference;
    }
}
