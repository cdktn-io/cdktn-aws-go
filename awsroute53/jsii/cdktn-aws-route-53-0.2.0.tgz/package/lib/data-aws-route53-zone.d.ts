import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfZoneConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_zone#enable_accelerated_recovery DataTfZone#enable_accelerated_recovery}
    */
    readonly enableAcceleratedRecovery?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_zone#id DataTfZone#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_zone#name DataTfZone#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_zone#private_zone DataTfZone#private_zone}
    */
    readonly privateZone?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_zone#tags DataTfZone#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_zone#vpc_id DataTfZone#vpc_id}
    */
    readonly vpcId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_zone#zone_id DataTfZone#zone_id}
    */
    readonly zoneId?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_zone aws_route53_zone}
*/
export declare class DataTfZone extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_route53_zone";
    /**
    * Generates CDKTN code for importing a DataTfZone resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfZone to import
    * @param importFromId The id of the existing DataTfZone that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_zone#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfZone to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_zone aws_route53_zone} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfZoneConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataTfZoneConfig);
    get arn(): string;
    get callerReference(): string;
    get comment(): string;
    private _enableAcceleratedRecovery?;
    get enableAcceleratedRecovery(): boolean | cdktn.IResolvable;
    set enableAcceleratedRecovery(value: boolean | cdktn.IResolvable);
    resetEnableAcceleratedRecovery(): void;
    get enableAcceleratedRecoveryInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get linkedServiceDescription(): string;
    get linkedServicePrincipal(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get nameServers(): string[];
    get primaryNameServer(): string;
    private _privateZone?;
    get privateZone(): boolean | cdktn.IResolvable;
    set privateZone(value: boolean | cdktn.IResolvable);
    resetPrivateZone(): void;
    get privateZoneInput(): boolean | cdktn.IResolvable | undefined;
    get resourceRecordSetCount(): number;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _vpcId?;
    get vpcId(): string;
    set vpcId(value: string);
    resetVpcId(): void;
    get vpcIdInput(): string | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
