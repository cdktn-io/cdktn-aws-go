import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfMultiRegionClusterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/memorydb_multi_region_cluster#description TfMultiRegionCluster#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/memorydb_multi_region_cluster#engine TfMultiRegionCluster#engine}
    */
    readonly engine?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/memorydb_multi_region_cluster#engine_version TfMultiRegionCluster#engine_version}
    */
    readonly engineVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/memorydb_multi_region_cluster#multi_region_cluster_name_suffix TfMultiRegionCluster#multi_region_cluster_name_suffix}
    */
    readonly multiRegionClusterNameSuffix: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/memorydb_multi_region_cluster#multi_region_parameter_group_name TfMultiRegionCluster#multi_region_parameter_group_name}
    */
    readonly multiRegionParameterGroupName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/memorydb_multi_region_cluster#node_type TfMultiRegionCluster#node_type}
    */
    readonly nodeType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/memorydb_multi_region_cluster#num_shards TfMultiRegionCluster#num_shards}
    */
    readonly numShards?: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/memorydb_multi_region_cluster#region TfMultiRegionCluster#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/memorydb_multi_region_cluster#tags TfMultiRegionCluster#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/memorydb_multi_region_cluster#tls_enabled TfMultiRegionCluster#tls_enabled}
    */
    readonly tlsEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/memorydb_multi_region_cluster#update_strategy TfMultiRegionCluster#update_strategy}
    */
    readonly updateStrategy?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/memorydb_multi_region_cluster#timeouts TfMultiRegionCluster#timeouts}
    */
    readonly timeouts?: TfMultiRegionCluster.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/memorydb_multi_region_cluster aws_memorydb_multi_region_cluster}
*/
export declare class TfMultiRegionCluster extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_memorydb_multi_region_cluster";
    /**
    * Generates CDKTN code for importing a TfMultiRegionCluster resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfMultiRegionCluster to import
    * @param importFromId The id of the existing TfMultiRegionCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/memorydb_multi_region_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfMultiRegionCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/memorydb_multi_region_cluster aws_memorydb_multi_region_cluster} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfMultiRegionClusterConfig
    */
    constructor(scope: Construct, id: string, config: TfMultiRegionClusterConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _engine?;
    get engine(): string;
    set engine(value: string);
    resetEngine(): void;
    get engineInput(): string | undefined;
    private _engineVersion?;
    get engineVersion(): string;
    set engineVersion(value: string);
    resetEngineVersion(): void;
    get engineVersionInput(): string | undefined;
    get multiRegionClusterName(): string;
    private _multiRegionClusterNameSuffix?;
    get multiRegionClusterNameSuffix(): string;
    set multiRegionClusterNameSuffix(value: string);
    get multiRegionClusterNameSuffixInput(): string | undefined;
    private _multiRegionParameterGroupName?;
    get multiRegionParameterGroupName(): string;
    set multiRegionParameterGroupName(value: string);
    resetMultiRegionParameterGroupName(): void;
    get multiRegionParameterGroupNameInput(): string | undefined;
    private _nodeType?;
    get nodeType(): string;
    set nodeType(value: string);
    get nodeTypeInput(): string | undefined;
    private _numShards?;
    get numShards(): number;
    set numShards(value: number);
    resetNumShards(): void;
    get numShardsInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _tlsEnabled?;
    get tlsEnabled(): boolean | cdktn.IResolvable;
    set tlsEnabled(value: boolean | cdktn.IResolvable);
    resetTlsEnabled(): void;
    get tlsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _updateStrategy?;
    get updateStrategy(): string;
    set updateStrategy(value: string);
    resetUpdateStrategy(): void;
    get updateStrategyInput(): string | undefined;
    private _timeouts;
    get timeouts(): TfMultiRegionCluster.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfMultiRegionCluster.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfMultiRegionCluster.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfMultiRegionClusterTimeoutsPropertyToTerraform(struct?: TfMultiRegionCluster.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfMultiRegionClusterTimeoutsPropertyToHclTerraform(struct?: TfMultiRegionCluster.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfMultiRegionCluster {
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/memorydb_multi_region_cluster#create TfMultiRegionCluster#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/memorydb_multi_region_cluster#delete TfMultiRegionCluster#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/memorydb_multi_region_cluster#update TfMultiRegionCluster#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
