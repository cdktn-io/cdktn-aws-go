import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsMemorydbSnapshotConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/memorydb_snapshot#id DataAwsMemorydbSnapshot#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/memorydb_snapshot#name DataAwsMemorydbSnapshot#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/memorydb_snapshot#region DataAwsMemorydbSnapshot#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/memorydb_snapshot#tags DataAwsMemorydbSnapshot#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/memorydb_snapshot aws_memorydb_snapshot}
*/
export declare class DataAwsMemorydbSnapshot extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_memorydb_snapshot";
    /**
    * Generates CDKTN code for importing a DataAwsMemorydbSnapshot resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsMemorydbSnapshot to import
    * @param importFromId The id of the existing DataAwsMemorydbSnapshot that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/memorydb_snapshot#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsMemorydbSnapshot to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/memorydb_snapshot aws_memorydb_snapshot} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsMemorydbSnapshotConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsMemorydbSnapshotConfig);
    get arn(): string;
    private _clusterConfiguration;
    get clusterConfiguration(): DataAwsMemorydbSnapshot.ClusterConfigurationPropertyList;
    get clusterName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get kmsKeyArn(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get source(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsMemorydbSnapshotClusterConfigurationPropertyToTerraform(struct?: DataAwsMemorydbSnapshot.ClusterConfigurationProperty): any;
export declare function dataAwsMemorydbSnapshotClusterConfigurationPropertyToHclTerraform(struct?: DataAwsMemorydbSnapshot.ClusterConfigurationProperty): any;
export declare namespace DataAwsMemorydbSnapshot {
    interface ClusterConfigurationProperty {
    }
    class ClusterConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ClusterConfigurationProperty | undefined;
        set internalValue(value: ClusterConfigurationProperty | undefined);
        get description(): string;
        get engine(): string;
        get engineVersion(): string;
        get maintenanceWindow(): string;
        get name(): string;
        get nodeType(): string;
        get numShards(): number;
        get parameterGroupName(): string;
        get port(): number;
        get snapshotRetentionLimit(): number;
        get snapshotWindow(): string;
        get subnetGroupName(): string;
        get topicArn(): string;
        get vpcId(): string;
    }
    class ClusterConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ClusterConfigurationPropertyOutputReference;
    }
}
