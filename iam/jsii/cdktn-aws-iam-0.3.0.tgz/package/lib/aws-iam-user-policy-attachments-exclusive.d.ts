import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsUserPolicyAttachmentsExclusiveConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iam_user_policy_attachments_exclusive#policy_arns AwsUserPolicyAttachmentsExclusive#policy_arns}
    */
    readonly policyArns: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iam_user_policy_attachments_exclusive#user_name AwsUserPolicyAttachmentsExclusive#user_name}
    */
    readonly userName: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iam_user_policy_attachments_exclusive aws_iam_user_policy_attachments_exclusive}
*/
export declare class AwsUserPolicyAttachmentsExclusive extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_iam_user_policy_attachments_exclusive";
    /**
    * Generates CDKTN code for importing a AwsUserPolicyAttachmentsExclusive resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsUserPolicyAttachmentsExclusive to import
    * @param importFromId The id of the existing AwsUserPolicyAttachmentsExclusive that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iam_user_policy_attachments_exclusive#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsUserPolicyAttachmentsExclusive to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iam_user_policy_attachments_exclusive aws_iam_user_policy_attachments_exclusive} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsUserPolicyAttachmentsExclusiveConfig
    */
    constructor(scope: Construct, id: string, config: AwsUserPolicyAttachmentsExclusiveConfig);
    private _policyArns?;
    get policyArns(): string[];
    set policyArns(value: string[]);
    get policyArnsInput(): string[] | undefined;
    private _userName?;
    get userName(): string;
    set userName(value: string);
    get userNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
