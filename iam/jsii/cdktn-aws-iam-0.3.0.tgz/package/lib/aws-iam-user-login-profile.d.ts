import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsUserLoginProfileConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iam_user_login_profile#id AwsUserLoginProfile#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iam_user_login_profile#password_length AwsUserLoginProfile#password_length}
    */
    readonly passwordLength?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iam_user_login_profile#password_reset_required AwsUserLoginProfile#password_reset_required}
    */
    readonly passwordResetRequired?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iam_user_login_profile#pgp_key AwsUserLoginProfile#pgp_key}
    */
    readonly pgpKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iam_user_login_profile#user AwsUserLoginProfile#user}
    */
    readonly user: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iam_user_login_profile aws_iam_user_login_profile}
*/
export declare class AwsUserLoginProfile extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_iam_user_login_profile";
    /**
    * Generates CDKTN code for importing a AwsUserLoginProfile resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsUserLoginProfile to import
    * @param importFromId The id of the existing AwsUserLoginProfile that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iam_user_login_profile#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsUserLoginProfile to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iam_user_login_profile aws_iam_user_login_profile} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsUserLoginProfileConfig
    */
    constructor(scope: Construct, id: string, config: AwsUserLoginProfileConfig);
    get encryptedPassword(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get keyFingerprint(): string;
    get password(): string;
    private _passwordLength?;
    get passwordLength(): number;
    set passwordLength(value: number);
    resetPasswordLength(): void;
    get passwordLengthInput(): number | undefined;
    private _passwordResetRequired?;
    get passwordResetRequired(): boolean | cdktn.IResolvable;
    set passwordResetRequired(value: boolean | cdktn.IResolvable);
    resetPasswordResetRequired(): void;
    get passwordResetRequiredInput(): boolean | cdktn.IResolvable | undefined;
    private _pgpKey?;
    get pgpKey(): string;
    set pgpKey(value: string);
    resetPgpKey(): void;
    get pgpKeyInput(): string | undefined;
    private _user?;
    get user(): string;
    set user(value: string);
    get userInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
