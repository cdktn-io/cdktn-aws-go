import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsPolicyDocumentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/iam_policy_document#id DataAwsPolicyDocument#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/iam_policy_document#override_json DataAwsPolicyDocument#override_json}
    */
    readonly overrideJson?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/iam_policy_document#override_policy_documents DataAwsPolicyDocument#override_policy_documents}
    */
    readonly overridePolicyDocuments?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/iam_policy_document#policy_id DataAwsPolicyDocument#policy_id}
    */
    readonly policyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/iam_policy_document#source_json DataAwsPolicyDocument#source_json}
    */
    readonly sourceJson?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/iam_policy_document#source_policy_documents DataAwsPolicyDocument#source_policy_documents}
    */
    readonly sourcePolicyDocuments?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/iam_policy_document#version DataAwsPolicyDocument#version}
    */
    readonly version?: string;
    /**
    * statement block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/iam_policy_document#statement DataAwsPolicyDocument#statement}
    */
    readonly statement?: DataAwsPolicyDocument.StatementProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/iam_policy_document aws_iam_policy_document}
*/
export declare class DataAwsPolicyDocument extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_iam_policy_document";
    /**
    * Generates CDKTN code for importing a DataAwsPolicyDocument resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsPolicyDocument to import
    * @param importFromId The id of the existing DataAwsPolicyDocument that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/iam_policy_document#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsPolicyDocument to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/iam_policy_document aws_iam_policy_document} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsPolicyDocumentConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsPolicyDocumentConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get json(): string;
    get minifiedJson(): string;
    private _overrideJson?;
    get overrideJson(): string;
    set overrideJson(value: string);
    resetOverrideJson(): void;
    get overrideJsonInput(): string | undefined;
    private _overridePolicyDocuments?;
    get overridePolicyDocuments(): string[];
    set overridePolicyDocuments(value: string[]);
    resetOverridePolicyDocuments(): void;
    get overridePolicyDocumentsInput(): string[] | undefined;
    private _policyId?;
    get policyId(): string;
    set policyId(value: string);
    resetPolicyId(): void;
    get policyIdInput(): string | undefined;
    private _sourceJson?;
    get sourceJson(): string;
    set sourceJson(value: string);
    resetSourceJson(): void;
    get sourceJsonInput(): string | undefined;
    private _sourcePolicyDocuments?;
    get sourcePolicyDocuments(): string[];
    set sourcePolicyDocuments(value: string[]);
    resetSourcePolicyDocuments(): void;
    get sourcePolicyDocumentsInput(): string[] | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
    private _statement;
    get statement(): DataAwsPolicyDocument.StatementPropertyList;
    putStatement(value: DataAwsPolicyDocument.StatementProperty[] | cdktn.IResolvable): void;
    resetStatement(): void;
    get statementInput(): cdktn.IResolvable | DataAwsPolicyDocument.StatementProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsPolicyDocumentConditionPropertyToTerraform(struct?: DataAwsPolicyDocument.ConditionProperty | cdktn.IResolvable): any;
export declare function dataAwsPolicyDocumentConditionPropertyToHclTerraform(struct?: DataAwsPolicyDocument.ConditionProperty | cdktn.IResolvable): any;
export declare function dataAwsPolicyDocumentNotPrincipalsPropertyToTerraform(struct?: DataAwsPolicyDocument.NotPrincipalsProperty | cdktn.IResolvable): any;
export declare function dataAwsPolicyDocumentNotPrincipalsPropertyToHclTerraform(struct?: DataAwsPolicyDocument.NotPrincipalsProperty | cdktn.IResolvable): any;
export declare function dataAwsPolicyDocumentPrincipalsPropertyToTerraform(struct?: DataAwsPolicyDocument.PrincipalsProperty | cdktn.IResolvable): any;
export declare function dataAwsPolicyDocumentPrincipalsPropertyToHclTerraform(struct?: DataAwsPolicyDocument.PrincipalsProperty | cdktn.IResolvable): any;
export declare function dataAwsPolicyDocumentStatementPropertyToTerraform(struct?: DataAwsPolicyDocument.StatementProperty | cdktn.IResolvable): any;
export declare function dataAwsPolicyDocumentStatementPropertyToHclTerraform(struct?: DataAwsPolicyDocument.StatementProperty | cdktn.IResolvable): any;
export declare namespace DataAwsPolicyDocument {
    interface ConditionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/iam_policy_document#test DataAwsPolicyDocument#test}
        */
        readonly test: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/iam_policy_document#values DataAwsPolicyDocument#values}
        */
        readonly values: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/iam_policy_document#variable DataAwsPolicyDocument#variable}
        */
        readonly variable: string;
    }
    class ConditionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConditionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConditionProperty | cdktn.IResolvable | undefined);
        private _test?;
        get test(): string;
        set test(value: string);
        get testInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
        private _variable?;
        get variable(): string;
        set variable(value: string);
        get variableInput(): string | undefined;
    }
    class ConditionPropertyList extends cdktn.ComplexList {
        internalValue?: ConditionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConditionPropertyOutputReference;
    }
    interface NotPrincipalsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/iam_policy_document#identifiers DataAwsPolicyDocument#identifiers}
        */
        readonly identifiers: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/iam_policy_document#type DataAwsPolicyDocument#type}
        */
        readonly type: string;
    }
    class NotPrincipalsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NotPrincipalsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NotPrincipalsProperty | cdktn.IResolvable | undefined);
        private _identifiers?;
        get identifiers(): string[];
        set identifiers(value: string[]);
        get identifiersInput(): string[] | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class NotPrincipalsPropertyList extends cdktn.ComplexList {
        internalValue?: NotPrincipalsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NotPrincipalsPropertyOutputReference;
    }
    interface PrincipalsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/iam_policy_document#identifiers DataAwsPolicyDocument#identifiers}
        */
        readonly identifiers: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/iam_policy_document#type DataAwsPolicyDocument#type}
        */
        readonly type: string;
    }
    class PrincipalsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PrincipalsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PrincipalsProperty | cdktn.IResolvable | undefined);
        private _identifiers?;
        get identifiers(): string[];
        set identifiers(value: string[]);
        get identifiersInput(): string[] | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class PrincipalsPropertyList extends cdktn.ComplexList {
        internalValue?: PrincipalsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PrincipalsPropertyOutputReference;
    }
    interface StatementProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/iam_policy_document#actions DataAwsPolicyDocument#actions}
        */
        readonly actions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/iam_policy_document#effect DataAwsPolicyDocument#effect}
        */
        readonly effect?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/iam_policy_document#not_actions DataAwsPolicyDocument#not_actions}
        */
        readonly notActions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/iam_policy_document#not_resources DataAwsPolicyDocument#not_resources}
        */
        readonly notResources?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/iam_policy_document#resources DataAwsPolicyDocument#resources}
        */
        readonly resources?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/iam_policy_document#sid DataAwsPolicyDocument#sid}
        */
        readonly sid?: string;
        /**
        * condition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/iam_policy_document#condition DataAwsPolicyDocument#condition}
        */
        readonly condition?: ConditionProperty[] | cdktn.IResolvable;
        /**
        * not_principals block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/iam_policy_document#not_principals DataAwsPolicyDocument#not_principals}
        */
        readonly notPrincipals?: NotPrincipalsProperty[] | cdktn.IResolvable;
        /**
        * principals block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/iam_policy_document#principals DataAwsPolicyDocument#principals}
        */
        readonly principals?: PrincipalsProperty[] | cdktn.IResolvable;
    }
    class StatementPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StatementProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StatementProperty | cdktn.IResolvable | undefined);
        private _actions?;
        get actions(): string[];
        set actions(value: string[]);
        resetActions(): void;
        get actionsInput(): string[] | undefined;
        private _effect?;
        get effect(): string;
        set effect(value: string);
        resetEffect(): void;
        get effectInput(): string | undefined;
        private _notActions?;
        get notActions(): string[];
        set notActions(value: string[]);
        resetNotActions(): void;
        get notActionsInput(): string[] | undefined;
        private _notResources?;
        get notResources(): string[];
        set notResources(value: string[]);
        resetNotResources(): void;
        get notResourcesInput(): string[] | undefined;
        private _resources?;
        get resources(): string[];
        set resources(value: string[]);
        resetResources(): void;
        get resourcesInput(): string[] | undefined;
        private _sid?;
        get sid(): string;
        set sid(value: string);
        resetSid(): void;
        get sidInput(): string | undefined;
        private _condition;
        get condition(): ConditionPropertyList;
        putCondition(value: ConditionProperty[] | cdktn.IResolvable): void;
        resetCondition(): void;
        get conditionInput(): cdktn.IResolvable | ConditionProperty[] | undefined;
        private _notPrincipals;
        get notPrincipals(): NotPrincipalsPropertyList;
        putNotPrincipals(value: NotPrincipalsProperty[] | cdktn.IResolvable): void;
        resetNotPrincipals(): void;
        get notPrincipalsInput(): cdktn.IResolvable | NotPrincipalsProperty[] | undefined;
        private _principals;
        get principals(): PrincipalsPropertyList;
        putPrincipals(value: PrincipalsProperty[] | cdktn.IResolvable): void;
        resetPrincipals(): void;
        get principalsInput(): cdktn.IResolvable | PrincipalsProperty[] | undefined;
    }
    class StatementPropertyList extends cdktn.ComplexList {
        internalValue?: StatementProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StatementPropertyOutputReference;
    }
}
