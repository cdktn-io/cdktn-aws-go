import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAccountAliasConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iam_account_alias#account_alias AwsAccountAlias#account_alias}
    */
    readonly accountAlias: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iam_account_alias#id AwsAccountAlias#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iam_account_alias aws_iam_account_alias}
*/
export declare class AwsAccountAlias extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_iam_account_alias";
    /**
    * Generates CDKTN code for importing a AwsAccountAlias resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsAccountAlias to import
    * @param importFromId The id of the existing AwsAccountAlias that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iam_account_alias#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsAccountAlias to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iam_account_alias aws_iam_account_alias} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAccountAliasConfig
    */
    constructor(scope: Construct, id: string, config: AwsAccountAliasConfig);
    private _accountAlias?;
    get accountAlias(): string;
    set accountAlias(value: string);
    get accountAliasInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
