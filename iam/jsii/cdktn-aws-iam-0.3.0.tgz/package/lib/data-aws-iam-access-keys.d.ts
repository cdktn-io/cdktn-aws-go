import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsAccessKeysConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/iam_access_keys#id DataAwsAccessKeys#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/iam_access_keys#user DataAwsAccessKeys#user}
    */
    readonly user: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/iam_access_keys aws_iam_access_keys}
*/
export declare class DataAwsAccessKeys extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_iam_access_keys";
    /**
    * Generates CDKTN code for importing a DataAwsAccessKeys resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsAccessKeys to import
    * @param importFromId The id of the existing DataAwsAccessKeys that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/iam_access_keys#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsAccessKeys to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/iam_access_keys aws_iam_access_keys} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsAccessKeysConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsAccessKeysConfig);
    private _accessKeys;
    get accessKeys(): DataAwsAccessKeys.AccessKeysPropertyList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _user?;
    get user(): string;
    set user(value: string);
    get userInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsAccessKeysAccessKeysPropertyToTerraform(struct?: DataAwsAccessKeys.AccessKeysProperty): any;
export declare function dataAwsAccessKeysAccessKeysPropertyToHclTerraform(struct?: DataAwsAccessKeys.AccessKeysProperty): any;
export declare namespace DataAwsAccessKeys {
    interface AccessKeysProperty {
    }
    class AccessKeysPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AccessKeysProperty | undefined;
        set internalValue(value: AccessKeysProperty | undefined);
        get accessKeyId(): string;
        get createDate(): string;
        get status(): string;
    }
    class AccessKeysPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AccessKeysPropertyOutputReference;
    }
}
