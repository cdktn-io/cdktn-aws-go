import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsZonalAutoshiftConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * List of time windows during which practice runs are allowed, in the format `Day:HH:MM-Day:HH:MM` (e.g., `Mon:09:00-Mon:17:00`). Cannot be used together with `blocked_windows`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arczonalshift_zonal_autoshift_configuration#allowed_windows AwsZonalAutoshiftConfiguration#allowed_windows}
    */
    readonly allowedWindows?: string[];
    /**
    * List of dates when practice runs should not be started, in the format `YYYY-MM-DD`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arczonalshift_zonal_autoshift_configuration#blocked_dates AwsZonalAutoshiftConfiguration#blocked_dates}
    */
    readonly blockedDates?: string[];
    /**
    * List of time windows during which practice runs should not be started, in the format `Day:HH:MM-Day:HH:MM` (e.g., `Mon:00:00-Mon:08:00`). Cannot be used together with `allowed_windows`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arczonalshift_zonal_autoshift_configuration#blocked_windows AwsZonalAutoshiftConfiguration#blocked_windows}
    */
    readonly blockedWindows?: string[];
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arczonalshift_zonal_autoshift_configuration#region AwsZonalAutoshiftConfiguration#region}
    */
    readonly region?: string;
    /**
    * The ARN of the managed resource to configure zonal autoshift for (e.g., an Application Load Balancer). Changing this creates a new resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arczonalshift_zonal_autoshift_configuration#resource_arn AwsZonalAutoshiftConfiguration#resource_arn}
    */
    readonly resourceArn: string;
    /**
    * The status of zonal autoshift. Valid values: `ENABLED`, `DISABLED`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arczonalshift_zonal_autoshift_configuration#zonal_autoshift_status AwsZonalAutoshiftConfiguration#zonal_autoshift_status}
    */
    readonly zonalAutoshiftStatus: string;
    /**
    * blocking_alarms block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arczonalshift_zonal_autoshift_configuration#blocking_alarms AwsZonalAutoshiftConfiguration#blocking_alarms}
    */
    readonly blockingAlarms?: AwsZonalAutoshiftConfiguration.BlockingAlarmsProperty[] | cdktn.IResolvable;
    /**
    * outcome_alarms block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arczonalshift_zonal_autoshift_configuration#outcome_alarms AwsZonalAutoshiftConfiguration#outcome_alarms}
    */
    readonly outcomeAlarms?: AwsZonalAutoshiftConfiguration.OutcomeAlarmsProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arczonalshift_zonal_autoshift_configuration aws_arczonalshift_zonal_autoshift_configuration}
*/
export declare class AwsZonalAutoshiftConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_arczonalshift_zonal_autoshift_configuration";
    /**
    * Generates CDKTN code for importing a AwsZonalAutoshiftConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsZonalAutoshiftConfiguration to import
    * @param importFromId The id of the existing AwsZonalAutoshiftConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arczonalshift_zonal_autoshift_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsZonalAutoshiftConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arczonalshift_zonal_autoshift_configuration aws_arczonalshift_zonal_autoshift_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsZonalAutoshiftConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AwsZonalAutoshiftConfigurationConfig);
    private _allowedWindows?;
    get allowedWindows(): string[];
    set allowedWindows(value: string[]);
    resetAllowedWindows(): void;
    get allowedWindowsInput(): string[] | undefined;
    private _blockedDates?;
    get blockedDates(): string[];
    set blockedDates(value: string[]);
    resetBlockedDates(): void;
    get blockedDatesInput(): string[] | undefined;
    private _blockedWindows?;
    get blockedWindows(): string[];
    set blockedWindows(value: string[]);
    resetBlockedWindows(): void;
    get blockedWindowsInput(): string[] | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resourceArn?;
    get resourceArn(): string;
    set resourceArn(value: string);
    get resourceArnInput(): string | undefined;
    private _zonalAutoshiftStatus?;
    get zonalAutoshiftStatus(): string;
    set zonalAutoshiftStatus(value: string);
    get zonalAutoshiftStatusInput(): string | undefined;
    private _blockingAlarms;
    get blockingAlarms(): AwsZonalAutoshiftConfiguration.BlockingAlarmsPropertyList;
    putBlockingAlarms(value: AwsZonalAutoshiftConfiguration.BlockingAlarmsProperty[] | cdktn.IResolvable): void;
    resetBlockingAlarms(): void;
    get blockingAlarmsInput(): cdktn.IResolvable | AwsZonalAutoshiftConfiguration.BlockingAlarmsProperty[] | undefined;
    private _outcomeAlarms;
    get outcomeAlarms(): AwsZonalAutoshiftConfiguration.OutcomeAlarmsPropertyList;
    putOutcomeAlarms(value: AwsZonalAutoshiftConfiguration.OutcomeAlarmsProperty[] | cdktn.IResolvable): void;
    resetOutcomeAlarms(): void;
    get outcomeAlarmsInput(): cdktn.IResolvable | AwsZonalAutoshiftConfiguration.OutcomeAlarmsProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsZonalAutoshiftConfigurationBlockingAlarmsPropertyToTerraform(struct?: AwsZonalAutoshiftConfiguration.BlockingAlarmsProperty | cdktn.IResolvable): any;
export declare function awsZonalAutoshiftConfigurationBlockingAlarmsPropertyToHclTerraform(struct?: AwsZonalAutoshiftConfiguration.BlockingAlarmsProperty | cdktn.IResolvable): any;
export declare function awsZonalAutoshiftConfigurationOutcomeAlarmsPropertyToTerraform(struct?: AwsZonalAutoshiftConfiguration.OutcomeAlarmsProperty | cdktn.IResolvable): any;
export declare function awsZonalAutoshiftConfigurationOutcomeAlarmsPropertyToHclTerraform(struct?: AwsZonalAutoshiftConfiguration.OutcomeAlarmsProperty | cdktn.IResolvable): any;
export declare namespace AwsZonalAutoshiftConfiguration {
    interface BlockingAlarmsProperty {
        /**
        * ARN of the CloudWatch alarm.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arczonalshift_zonal_autoshift_configuration#alarm_identifier AwsZonalAutoshiftConfiguration#alarm_identifier}
        */
        readonly alarmIdentifier: string;
        /**
        * Type of control condition. Valid value: `CLOUDWATCH`.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arczonalshift_zonal_autoshift_configuration#type AwsZonalAutoshiftConfiguration#type}
        */
        readonly type: string;
    }
    class BlockingAlarmsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BlockingAlarmsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: BlockingAlarmsProperty | cdktn.IResolvable | undefined);
        private _alarmIdentifier?;
        get alarmIdentifier(): string;
        set alarmIdentifier(value: string);
        get alarmIdentifierInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class BlockingAlarmsPropertyList extends cdktn.ComplexList {
        internalValue?: BlockingAlarmsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BlockingAlarmsPropertyOutputReference;
    }
    interface OutcomeAlarmsProperty {
        /**
        * ARN of the CloudWatch alarm.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arczonalshift_zonal_autoshift_configuration#alarm_identifier AwsZonalAutoshiftConfiguration#alarm_identifier}
        */
        readonly alarmIdentifier: string;
        /**
        * Type of control condition. Valid value: `CLOUDWATCH`.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arczonalshift_zonal_autoshift_configuration#type AwsZonalAutoshiftConfiguration#type}
        */
        readonly type: string;
    }
    class OutcomeAlarmsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OutcomeAlarmsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OutcomeAlarmsProperty | cdktn.IResolvable | undefined);
        private _alarmIdentifier?;
        get alarmIdentifier(): string;
        set alarmIdentifier(value: string);
        get alarmIdentifierInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class OutcomeAlarmsPropertyList extends cdktn.ComplexList {
        internalValue?: OutcomeAlarmsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OutcomeAlarmsPropertyOutputReference;
    }
}
