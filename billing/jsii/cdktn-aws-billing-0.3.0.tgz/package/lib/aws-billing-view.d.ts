import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsViewConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/billing_view#description AwsView#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/billing_view#name AwsView#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/billing_view#source_views AwsView#source_views}
    */
    readonly sourceViews?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/billing_view#tags AwsView#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * data_filter_expression block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/billing_view#data_filter_expression AwsView#data_filter_expression}
    */
    readonly dataFilterExpression?: AwsView.DataFilterExpressionProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/billing_view#timeouts AwsView#timeouts}
    */
    readonly timeouts?: AwsView.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/billing_view aws_billing_view}
*/
export declare class AwsView extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_billing_view";
    /**
    * Generates CDKTN code for importing a AwsView resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsView to import
    * @param importFromId The id of the existing AwsView that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/billing_view#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsView to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/billing_view aws_billing_view} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsViewConfig
    */
    constructor(scope: Construct, id: string, config: AwsViewConfig);
    get arn(): string;
    get billingViewType(): string;
    get createdAt(): string;
    get derivedViewCount(): number;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get ownerAccountId(): string;
    get sourceAccountId(): string;
    get sourceViewCount(): number;
    private _sourceViews?;
    get sourceViews(): string[];
    set sourceViews(value: string[]);
    resetSourceViews(): void;
    get sourceViewsInput(): string[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    get updatedAt(): string;
    get viewDefinitionLastUpdatedAt(): string;
    private _dataFilterExpression;
    get dataFilterExpression(): AwsView.DataFilterExpressionPropertyList;
    putDataFilterExpression(value: AwsView.DataFilterExpressionProperty[] | cdktn.IResolvable): void;
    resetDataFilterExpression(): void;
    get dataFilterExpressionInput(): cdktn.IResolvable | AwsView.DataFilterExpressionProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsView.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsView.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsView.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsViewDimensionsPropertyToTerraform(struct?: AwsView.DimensionsProperty | cdktn.IResolvable): any;
export declare function awsViewDimensionsPropertyToHclTerraform(struct?: AwsView.DimensionsProperty | cdktn.IResolvable): any;
export declare function awsViewTagsPropertyToTerraform(struct?: AwsView.TagsProperty | cdktn.IResolvable): any;
export declare function awsViewTagsPropertyToHclTerraform(struct?: AwsView.TagsProperty | cdktn.IResolvable): any;
export declare function awsViewTimeRangePropertyToTerraform(struct?: AwsView.TimeRangeProperty | cdktn.IResolvable): any;
export declare function awsViewTimeRangePropertyToHclTerraform(struct?: AwsView.TimeRangeProperty | cdktn.IResolvable): any;
export declare function awsViewDataFilterExpressionPropertyToTerraform(struct?: AwsView.DataFilterExpressionProperty | cdktn.IResolvable): any;
export declare function awsViewDataFilterExpressionPropertyToHclTerraform(struct?: AwsView.DataFilterExpressionProperty | cdktn.IResolvable): any;
export declare function awsViewTimeoutsPropertyToTerraform(struct?: AwsView.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsViewTimeoutsPropertyToHclTerraform(struct?: AwsView.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsView {
    interface DimensionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/billing_view#key AwsView#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/billing_view#values AwsView#values}
        */
        readonly values: string[];
    }
    class DimensionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DimensionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DimensionsProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class DimensionsPropertyList extends cdktn.ComplexList {
        internalValue?: DimensionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DimensionsPropertyOutputReference;
    }
    interface TagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/billing_view#key AwsView#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/billing_view#values AwsView#values}
        */
        readonly values: string[];
    }
    class TagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TagsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TagsProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class TagsPropertyList extends cdktn.ComplexList {
        internalValue?: TagsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TagsPropertyOutputReference;
    }
    interface TimeRangeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/billing_view#begin_date_inclusive AwsView#begin_date_inclusive}
        */
        readonly beginDateInclusive: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/billing_view#end_date_inclusive AwsView#end_date_inclusive}
        */
        readonly endDateInclusive: string;
    }
    class TimeRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TimeRangeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeRangeProperty | cdktn.IResolvable | undefined);
        private _beginDateInclusive?;
        get beginDateInclusive(): string;
        set beginDateInclusive(value: string);
        get beginDateInclusiveInput(): string | undefined;
        private _endDateInclusive?;
        get endDateInclusive(): string;
        set endDateInclusive(value: string);
        get endDateInclusiveInput(): string | undefined;
    }
    class TimeRangePropertyList extends cdktn.ComplexList {
        internalValue?: TimeRangeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TimeRangePropertyOutputReference;
    }
    interface DataFilterExpressionProperty {
        /**
        * dimensions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/billing_view#dimensions AwsView#dimensions}
        */
        readonly dimensions?: DimensionsProperty[] | cdktn.IResolvable;
        /**
        * tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/billing_view#tags AwsView#tags}
        */
        readonly tags?: TagsProperty[] | cdktn.IResolvable;
        /**
        * time_range block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/billing_view#time_range AwsView#time_range}
        */
        readonly timeRange?: TimeRangeProperty[] | cdktn.IResolvable;
    }
    class DataFilterExpressionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataFilterExpressionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DataFilterExpressionProperty | cdktn.IResolvable | undefined);
        private _dimensions;
        get dimensions(): DimensionsPropertyList;
        putDimensions(value: DimensionsProperty[] | cdktn.IResolvable): void;
        resetDimensions(): void;
        get dimensionsInput(): cdktn.IResolvable | DimensionsProperty[] | undefined;
        private _tags;
        get tags(): TagsPropertyList;
        putTags(value: TagsProperty[] | cdktn.IResolvable): void;
        resetTags(): void;
        get tagsInput(): cdktn.IResolvable | TagsProperty[] | undefined;
        private _timeRange;
        get timeRange(): TimeRangePropertyList;
        putTimeRange(value: TimeRangeProperty[] | cdktn.IResolvable): void;
        resetTimeRange(): void;
        get timeRangeInput(): cdktn.IResolvable | TimeRangeProperty[] | undefined;
    }
    class DataFilterExpressionPropertyList extends cdktn.ComplexList {
        internalValue?: DataFilterExpressionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataFilterExpressionPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/billing_view#create AwsView#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/billing_view#delete AwsView#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/billing_view#update AwsView#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
