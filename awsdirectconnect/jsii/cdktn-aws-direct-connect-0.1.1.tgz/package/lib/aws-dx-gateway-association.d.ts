import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDxGatewayAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dx_gateway_association#allowed_prefixes AwsDxGatewayAssociation#allowed_prefixes}
    */
    readonly allowedPrefixes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dx_gateway_association#associated_gateway_id AwsDxGatewayAssociation#associated_gateway_id}
    */
    readonly associatedGatewayId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dx_gateway_association#associated_gateway_owner_account_id AwsDxGatewayAssociation#associated_gateway_owner_account_id}
    */
    readonly associatedGatewayOwnerAccountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dx_gateway_association#dx_gateway_id AwsDxGatewayAssociation#dx_gateway_id}
    */
    readonly dxGatewayId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dx_gateway_association#id AwsDxGatewayAssociation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dx_gateway_association#proposal_id AwsDxGatewayAssociation#proposal_id}
    */
    readonly proposalId?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dx_gateway_association#region AwsDxGatewayAssociation#region}
    */
    readonly region?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dx_gateway_association#timeouts AwsDxGatewayAssociation#timeouts}
    */
    readonly timeouts?: AwsDxGatewayAssociation.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dx_gateway_association aws_dx_gateway_association}
*/
export declare class AwsDxGatewayAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_dx_gateway_association";
    /**
    * Generates CDKTN code for importing a AwsDxGatewayAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDxGatewayAssociation to import
    * @param importFromId The id of the existing AwsDxGatewayAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dx_gateway_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDxGatewayAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dx_gateway_association aws_dx_gateway_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDxGatewayAssociationConfig
    */
    constructor(scope: Construct, id: string, config: AwsDxGatewayAssociationConfig);
    private _allowedPrefixes?;
    get allowedPrefixes(): string[];
    set allowedPrefixes(value: string[]);
    resetAllowedPrefixes(): void;
    get allowedPrefixesInput(): string[] | undefined;
    private _associatedGatewayId?;
    get associatedGatewayId(): string;
    set associatedGatewayId(value: string);
    resetAssociatedGatewayId(): void;
    get associatedGatewayIdInput(): string | undefined;
    private _associatedGatewayOwnerAccountId?;
    get associatedGatewayOwnerAccountId(): string;
    set associatedGatewayOwnerAccountId(value: string);
    resetAssociatedGatewayOwnerAccountId(): void;
    get associatedGatewayOwnerAccountIdInput(): string | undefined;
    get associatedGatewayType(): string;
    get dxGatewayAssociationId(): string;
    private _dxGatewayId?;
    get dxGatewayId(): string;
    set dxGatewayId(value: string);
    get dxGatewayIdInput(): string | undefined;
    get dxGatewayOwnerAccountId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _proposalId?;
    get proposalId(): string;
    set proposalId(value: string);
    resetProposalId(): void;
    get proposalIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get transitGatewayAttachmentId(): string;
    private _timeouts;
    get timeouts(): AwsDxGatewayAssociation.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsDxGatewayAssociation.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsDxGatewayAssociation.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsDxGatewayAssociationTimeoutsPropertyToTerraform(struct?: AwsDxGatewayAssociation.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsDxGatewayAssociationTimeoutsPropertyToHclTerraform(struct?: AwsDxGatewayAssociation.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsDxGatewayAssociation {
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dx_gateway_association#create AwsDxGatewayAssociation#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dx_gateway_association#delete AwsDxGatewayAssociation#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dx_gateway_association#update AwsDxGatewayAssociation#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
