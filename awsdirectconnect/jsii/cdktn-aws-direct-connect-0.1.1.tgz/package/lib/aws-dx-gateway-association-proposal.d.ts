import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDxGatewayAssociationProposalConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dx_gateway_association_proposal#allowed_prefixes AwsDxGatewayAssociationProposal#allowed_prefixes}
    */
    readonly allowedPrefixes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dx_gateway_association_proposal#associated_gateway_id AwsDxGatewayAssociationProposal#associated_gateway_id}
    */
    readonly associatedGatewayId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dx_gateway_association_proposal#dx_gateway_id AwsDxGatewayAssociationProposal#dx_gateway_id}
    */
    readonly dxGatewayId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dx_gateway_association_proposal#dx_gateway_owner_account_id AwsDxGatewayAssociationProposal#dx_gateway_owner_account_id}
    */
    readonly dxGatewayOwnerAccountId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dx_gateway_association_proposal#id AwsDxGatewayAssociationProposal#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dx_gateway_association_proposal#region AwsDxGatewayAssociationProposal#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dx_gateway_association_proposal aws_dx_gateway_association_proposal}
*/
export declare class AwsDxGatewayAssociationProposal extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_dx_gateway_association_proposal";
    /**
    * Generates CDKTN code for importing a AwsDxGatewayAssociationProposal resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDxGatewayAssociationProposal to import
    * @param importFromId The id of the existing AwsDxGatewayAssociationProposal that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dx_gateway_association_proposal#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDxGatewayAssociationProposal to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dx_gateway_association_proposal aws_dx_gateway_association_proposal} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDxGatewayAssociationProposalConfig
    */
    constructor(scope: Construct, id: string, config: AwsDxGatewayAssociationProposalConfig);
    private _allowedPrefixes?;
    get allowedPrefixes(): string[];
    set allowedPrefixes(value: string[]);
    resetAllowedPrefixes(): void;
    get allowedPrefixesInput(): string[] | undefined;
    private _associatedGatewayId?;
    get associatedGatewayId(): string;
    set associatedGatewayId(value: string);
    get associatedGatewayIdInput(): string | undefined;
    get associatedGatewayOwnerAccountId(): string;
    get associatedGatewayType(): string;
    private _dxGatewayId?;
    get dxGatewayId(): string;
    set dxGatewayId(value: string);
    get dxGatewayIdInput(): string | undefined;
    private _dxGatewayOwnerAccountId?;
    get dxGatewayOwnerAccountId(): string;
    set dxGatewayOwnerAccountId(value: string);
    get dxGatewayOwnerAccountIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
