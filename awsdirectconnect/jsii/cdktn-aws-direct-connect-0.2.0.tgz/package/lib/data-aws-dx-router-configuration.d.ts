import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfRouterConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/dx_router_configuration#id DataTfRouterConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/dx_router_configuration#region DataTfRouterConfiguration#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/dx_router_configuration#router_type_identifier DataTfRouterConfiguration#router_type_identifier}
    */
    readonly routerTypeIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/dx_router_configuration#virtual_interface_id DataTfRouterConfiguration#virtual_interface_id}
    */
    readonly virtualInterfaceId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/dx_router_configuration aws_dx_router_configuration}
*/
export declare class DataTfRouterConfiguration extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_dx_router_configuration";
    /**
    * Generates CDKTN code for importing a DataTfRouterConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfRouterConfiguration to import
    * @param importFromId The id of the existing DataTfRouterConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/dx_router_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfRouterConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/dx_router_configuration aws_dx_router_configuration} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfRouterConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: DataTfRouterConfigurationConfig);
    get customerRouterConfig(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _router;
    get router(): DataTfRouterConfiguration.RouterPropertyList;
    private _routerTypeIdentifier?;
    get routerTypeIdentifier(): string;
    set routerTypeIdentifier(value: string);
    get routerTypeIdentifierInput(): string | undefined;
    private _virtualInterfaceId?;
    get virtualInterfaceId(): string;
    set virtualInterfaceId(value: string);
    get virtualInterfaceIdInput(): string | undefined;
    get virtualInterfaceName(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfRouterConfigurationRouterPropertyToTerraform(struct?: DataTfRouterConfiguration.RouterProperty): any;
export declare function dataTfRouterConfigurationRouterPropertyToHclTerraform(struct?: DataTfRouterConfiguration.RouterProperty): any;
export declare namespace DataTfRouterConfiguration {
    interface RouterProperty {
    }
    class RouterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RouterProperty | undefined;
        set internalValue(value: RouterProperty | undefined);
        get platform(): string;
        get routerTypeIdentifier(): string;
        get softwareAttribute(): string;
        get vendor(): string;
        get xsltTemplateName(): string;
        get xsltTemplateNameForMacSec(): string;
    }
    class RouterPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RouterPropertyOutputReference;
    }
}
