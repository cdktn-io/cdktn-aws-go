import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsWafByteMatchSetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_byte_match_set#id AwsWafByteMatchSet#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_byte_match_set#name AwsWafByteMatchSet#name}
    */
    readonly name: string;
    /**
    * byte_match_tuples block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_byte_match_set#byte_match_tuples AwsWafByteMatchSet#byte_match_tuples}
    */
    readonly byteMatchTuples?: AwsWafByteMatchSet.ByteMatchTuplesProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_byte_match_set aws_waf_byte_match_set}
*/
export declare class AwsWafByteMatchSet extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_waf_byte_match_set";
    /**
    * Generates CDKTN code for importing a AwsWafByteMatchSet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsWafByteMatchSet to import
    * @param importFromId The id of the existing AwsWafByteMatchSet that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_byte_match_set#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsWafByteMatchSet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_byte_match_set aws_waf_byte_match_set} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsWafByteMatchSetConfig
    */
    constructor(scope: Construct, id: string, config: AwsWafByteMatchSetConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _byteMatchTuples;
    get byteMatchTuples(): AwsWafByteMatchSet.ByteMatchTuplesPropertyList;
    putByteMatchTuples(value: AwsWafByteMatchSet.ByteMatchTuplesProperty[] | cdktn.IResolvable): void;
    resetByteMatchTuples(): void;
    get byteMatchTuplesInput(): cdktn.IResolvable | AwsWafByteMatchSet.ByteMatchTuplesProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsWafByteMatchSetFieldToMatchPropertyToTerraform(struct?: AwsWafByteMatchSet.FieldToMatchPropertyOutputReference | AwsWafByteMatchSet.FieldToMatchProperty): any;
export declare function awsWafByteMatchSetFieldToMatchPropertyToHclTerraform(struct?: AwsWafByteMatchSet.FieldToMatchPropertyOutputReference | AwsWafByteMatchSet.FieldToMatchProperty): any;
export declare function awsWafByteMatchSetByteMatchTuplesPropertyToTerraform(struct?: AwsWafByteMatchSet.ByteMatchTuplesProperty | cdktn.IResolvable): any;
export declare function awsWafByteMatchSetByteMatchTuplesPropertyToHclTerraform(struct?: AwsWafByteMatchSet.ByteMatchTuplesProperty | cdktn.IResolvable): any;
export declare namespace AwsWafByteMatchSet {
    interface FieldToMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_byte_match_set#data AwsWafByteMatchSet#data}
        */
        readonly data?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_byte_match_set#type AwsWafByteMatchSet#type}
        */
        readonly type: string;
    }
    class FieldToMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FieldToMatchProperty | undefined;
        set internalValue(value: FieldToMatchProperty | undefined);
        private _data?;
        get data(): string;
        set data(value: string);
        resetData(): void;
        get dataInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    interface ByteMatchTuplesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_byte_match_set#positional_constraint AwsWafByteMatchSet#positional_constraint}
        */
        readonly positionalConstraint: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_byte_match_set#target_string AwsWafByteMatchSet#target_string}
        */
        readonly targetString?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_byte_match_set#text_transformation AwsWafByteMatchSet#text_transformation}
        */
        readonly textTransformation: string;
        /**
        * field_to_match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_byte_match_set#field_to_match AwsWafByteMatchSet#field_to_match}
        */
        readonly fieldToMatch: FieldToMatchProperty;
    }
    class ByteMatchTuplesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ByteMatchTuplesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ByteMatchTuplesProperty | cdktn.IResolvable | undefined);
        private _positionalConstraint?;
        get positionalConstraint(): string;
        set positionalConstraint(value: string);
        get positionalConstraintInput(): string | undefined;
        private _targetString?;
        get targetString(): string;
        set targetString(value: string);
        resetTargetString(): void;
        get targetStringInput(): string | undefined;
        private _textTransformation?;
        get textTransformation(): string;
        set textTransformation(value: string);
        get textTransformationInput(): string | undefined;
        private _fieldToMatch;
        get fieldToMatch(): FieldToMatchPropertyOutputReference;
        putFieldToMatch(value: FieldToMatchProperty): void;
        get fieldToMatchInput(): FieldToMatchProperty | undefined;
    }
    class ByteMatchTuplesPropertyList extends cdktn.ComplexList {
        internalValue?: ByteMatchTuplesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ByteMatchTuplesPropertyOutputReference;
    }
}
