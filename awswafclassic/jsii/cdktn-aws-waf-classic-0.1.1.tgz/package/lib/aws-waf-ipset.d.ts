import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsWafIpsetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_ipset#id AwsWafIpset#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_ipset#name AwsWafIpset#name}
    */
    readonly name: string;
    /**
    * ip_set_descriptors block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_ipset#ip_set_descriptors AwsWafIpset#ip_set_descriptors}
    */
    readonly ipSetDescriptors?: AwsWafIpset.IpSetDescriptorsProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_ipset aws_waf_ipset}
*/
export declare class AwsWafIpset extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_waf_ipset";
    /**
    * Generates CDKTN code for importing a AwsWafIpset resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsWafIpset to import
    * @param importFromId The id of the existing AwsWafIpset that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_ipset#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsWafIpset to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_ipset aws_waf_ipset} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsWafIpsetConfig
    */
    constructor(scope: Construct, id: string, config: AwsWafIpsetConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _ipSetDescriptors;
    get ipSetDescriptors(): AwsWafIpset.IpSetDescriptorsPropertyList;
    putIpSetDescriptors(value: AwsWafIpset.IpSetDescriptorsProperty[] | cdktn.IResolvable): void;
    resetIpSetDescriptors(): void;
    get ipSetDescriptorsInput(): cdktn.IResolvable | AwsWafIpset.IpSetDescriptorsProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsWafIpsetIpSetDescriptorsPropertyToTerraform(struct?: AwsWafIpset.IpSetDescriptorsProperty | cdktn.IResolvable): any;
export declare function awsWafIpsetIpSetDescriptorsPropertyToHclTerraform(struct?: AwsWafIpset.IpSetDescriptorsProperty | cdktn.IResolvable): any;
export declare namespace AwsWafIpset {
    interface IpSetDescriptorsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_ipset#type AwsWafIpset#type}
        */
        readonly type: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_ipset#value AwsWafIpset#value}
        */
        readonly value: string;
    }
    class IpSetDescriptorsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IpSetDescriptorsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IpSetDescriptorsProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class IpSetDescriptorsPropertyList extends cdktn.ComplexList {
        internalValue?: IpSetDescriptorsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IpSetDescriptorsPropertyOutputReference;
    }
}
