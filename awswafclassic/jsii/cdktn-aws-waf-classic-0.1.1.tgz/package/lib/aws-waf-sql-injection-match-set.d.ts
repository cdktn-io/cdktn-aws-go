import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsWafSqlInjectionMatchSetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_sql_injection_match_set#id AwsWafSqlInjectionMatchSet#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_sql_injection_match_set#name AwsWafSqlInjectionMatchSet#name}
    */
    readonly name: string;
    /**
    * sql_injection_match_tuples block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_sql_injection_match_set#sql_injection_match_tuples AwsWafSqlInjectionMatchSet#sql_injection_match_tuples}
    */
    readonly sqlInjectionMatchTuples?: AwsWafSqlInjectionMatchSet.SqlInjectionMatchTuplesProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_sql_injection_match_set aws_waf_sql_injection_match_set}
*/
export declare class AwsWafSqlInjectionMatchSet extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_waf_sql_injection_match_set";
    /**
    * Generates CDKTN code for importing a AwsWafSqlInjectionMatchSet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsWafSqlInjectionMatchSet to import
    * @param importFromId The id of the existing AwsWafSqlInjectionMatchSet that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_sql_injection_match_set#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsWafSqlInjectionMatchSet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_sql_injection_match_set aws_waf_sql_injection_match_set} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsWafSqlInjectionMatchSetConfig
    */
    constructor(scope: Construct, id: string, config: AwsWafSqlInjectionMatchSetConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _sqlInjectionMatchTuples;
    get sqlInjectionMatchTuples(): AwsWafSqlInjectionMatchSet.SqlInjectionMatchTuplesPropertyList;
    putSqlInjectionMatchTuples(value: AwsWafSqlInjectionMatchSet.SqlInjectionMatchTuplesProperty[] | cdktn.IResolvable): void;
    resetSqlInjectionMatchTuples(): void;
    get sqlInjectionMatchTuplesInput(): cdktn.IResolvable | AwsWafSqlInjectionMatchSet.SqlInjectionMatchTuplesProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsWafSqlInjectionMatchSetFieldToMatchPropertyToTerraform(struct?: AwsWafSqlInjectionMatchSet.FieldToMatchPropertyOutputReference | AwsWafSqlInjectionMatchSet.FieldToMatchProperty): any;
export declare function awsWafSqlInjectionMatchSetFieldToMatchPropertyToHclTerraform(struct?: AwsWafSqlInjectionMatchSet.FieldToMatchPropertyOutputReference | AwsWafSqlInjectionMatchSet.FieldToMatchProperty): any;
export declare function awsWafSqlInjectionMatchSetSqlInjectionMatchTuplesPropertyToTerraform(struct?: AwsWafSqlInjectionMatchSet.SqlInjectionMatchTuplesProperty | cdktn.IResolvable): any;
export declare function awsWafSqlInjectionMatchSetSqlInjectionMatchTuplesPropertyToHclTerraform(struct?: AwsWafSqlInjectionMatchSet.SqlInjectionMatchTuplesProperty | cdktn.IResolvable): any;
export declare namespace AwsWafSqlInjectionMatchSet {
    interface FieldToMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_sql_injection_match_set#data AwsWafSqlInjectionMatchSet#data}
        */
        readonly data?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_sql_injection_match_set#type AwsWafSqlInjectionMatchSet#type}
        */
        readonly type: string;
    }
    class FieldToMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FieldToMatchProperty | undefined;
        set internalValue(value: FieldToMatchProperty | undefined);
        private _data?;
        get data(): string;
        set data(value: string);
        resetData(): void;
        get dataInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    interface SqlInjectionMatchTuplesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_sql_injection_match_set#text_transformation AwsWafSqlInjectionMatchSet#text_transformation}
        */
        readonly textTransformation: string;
        /**
        * field_to_match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_sql_injection_match_set#field_to_match AwsWafSqlInjectionMatchSet#field_to_match}
        */
        readonly fieldToMatch: FieldToMatchProperty;
    }
    class SqlInjectionMatchTuplesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SqlInjectionMatchTuplesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SqlInjectionMatchTuplesProperty | cdktn.IResolvable | undefined);
        private _textTransformation?;
        get textTransformation(): string;
        set textTransformation(value: string);
        get textTransformationInput(): string | undefined;
        private _fieldToMatch;
        get fieldToMatch(): FieldToMatchPropertyOutputReference;
        putFieldToMatch(value: FieldToMatchProperty): void;
        get fieldToMatchInput(): FieldToMatchProperty | undefined;
    }
    class SqlInjectionMatchTuplesPropertyList extends cdktn.ComplexList {
        internalValue?: SqlInjectionMatchTuplesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SqlInjectionMatchTuplesPropertyOutputReference;
    }
}
