import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsWafRateBasedRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_rate_based_rule#id AwsWafRateBasedRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_rate_based_rule#metric_name AwsWafRateBasedRule#metric_name}
    */
    readonly metricName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_rate_based_rule#name AwsWafRateBasedRule#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_rate_based_rule#rate_key AwsWafRateBasedRule#rate_key}
    */
    readonly rateKey: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_rate_based_rule#rate_limit AwsWafRateBasedRule#rate_limit}
    */
    readonly rateLimit: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_rate_based_rule#tags AwsWafRateBasedRule#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_rate_based_rule#tags_all AwsWafRateBasedRule#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * predicates block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_rate_based_rule#predicates AwsWafRateBasedRule#predicates}
    */
    readonly predicates?: AwsWafRateBasedRule.PredicatesProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_rate_based_rule aws_waf_rate_based_rule}
*/
export declare class AwsWafRateBasedRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_waf_rate_based_rule";
    /**
    * Generates CDKTN code for importing a AwsWafRateBasedRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsWafRateBasedRule to import
    * @param importFromId The id of the existing AwsWafRateBasedRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_rate_based_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsWafRateBasedRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_rate_based_rule aws_waf_rate_based_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsWafRateBasedRuleConfig
    */
    constructor(scope: Construct, id: string, config: AwsWafRateBasedRuleConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _metricName?;
    get metricName(): string;
    set metricName(value: string);
    get metricNameInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _rateKey?;
    get rateKey(): string;
    set rateKey(value: string);
    get rateKeyInput(): string | undefined;
    private _rateLimit?;
    get rateLimit(): number;
    set rateLimit(value: number);
    get rateLimitInput(): number | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _predicates;
    get predicates(): AwsWafRateBasedRule.PredicatesPropertyList;
    putPredicates(value: AwsWafRateBasedRule.PredicatesProperty[] | cdktn.IResolvable): void;
    resetPredicates(): void;
    get predicatesInput(): cdktn.IResolvable | AwsWafRateBasedRule.PredicatesProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsWafRateBasedRulePredicatesPropertyToTerraform(struct?: AwsWafRateBasedRule.PredicatesProperty | cdktn.IResolvable): any;
export declare function awsWafRateBasedRulePredicatesPropertyToHclTerraform(struct?: AwsWafRateBasedRule.PredicatesProperty | cdktn.IResolvable): any;
export declare namespace AwsWafRateBasedRule {
    interface PredicatesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_rate_based_rule#data_id AwsWafRateBasedRule#data_id}
        */
        readonly dataId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_rate_based_rule#negated AwsWafRateBasedRule#negated}
        */
        readonly negated: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_rate_based_rule#type AwsWafRateBasedRule#type}
        */
        readonly type: string;
    }
    class PredicatesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PredicatesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PredicatesProperty | cdktn.IResolvable | undefined);
        private _dataId?;
        get dataId(): string;
        set dataId(value: string);
        get dataIdInput(): string | undefined;
        private _negated?;
        get negated(): boolean | cdktn.IResolvable;
        set negated(value: boolean | cdktn.IResolvable);
        get negatedInput(): boolean | cdktn.IResolvable | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class PredicatesPropertyList extends cdktn.ComplexList {
        internalValue?: PredicatesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PredicatesPropertyOutputReference;
    }
}
