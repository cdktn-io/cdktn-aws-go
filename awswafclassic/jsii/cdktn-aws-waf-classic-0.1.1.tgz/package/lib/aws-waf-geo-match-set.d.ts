import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsWafGeoMatchSetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_geo_match_set#id AwsWafGeoMatchSet#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_geo_match_set#name AwsWafGeoMatchSet#name}
    */
    readonly name: string;
    /**
    * geo_match_constraint block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_geo_match_set#geo_match_constraint AwsWafGeoMatchSet#geo_match_constraint}
    */
    readonly geoMatchConstraint?: AwsWafGeoMatchSet.GeoMatchConstraintProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_geo_match_set aws_waf_geo_match_set}
*/
export declare class AwsWafGeoMatchSet extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_waf_geo_match_set";
    /**
    * Generates CDKTN code for importing a AwsWafGeoMatchSet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsWafGeoMatchSet to import
    * @param importFromId The id of the existing AwsWafGeoMatchSet that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_geo_match_set#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsWafGeoMatchSet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_geo_match_set aws_waf_geo_match_set} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsWafGeoMatchSetConfig
    */
    constructor(scope: Construct, id: string, config: AwsWafGeoMatchSetConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _geoMatchConstraint;
    get geoMatchConstraint(): AwsWafGeoMatchSet.GeoMatchConstraintPropertyList;
    putGeoMatchConstraint(value: AwsWafGeoMatchSet.GeoMatchConstraintProperty[] | cdktn.IResolvable): void;
    resetGeoMatchConstraint(): void;
    get geoMatchConstraintInput(): cdktn.IResolvable | AwsWafGeoMatchSet.GeoMatchConstraintProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsWafGeoMatchSetGeoMatchConstraintPropertyToTerraform(struct?: AwsWafGeoMatchSet.GeoMatchConstraintProperty | cdktn.IResolvable): any;
export declare function awsWafGeoMatchSetGeoMatchConstraintPropertyToHclTerraform(struct?: AwsWafGeoMatchSet.GeoMatchConstraintProperty | cdktn.IResolvable): any;
export declare namespace AwsWafGeoMatchSet {
    interface GeoMatchConstraintProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_geo_match_set#type AwsWafGeoMatchSet#type}
        */
        readonly type: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_geo_match_set#value AwsWafGeoMatchSet#value}
        */
        readonly value: string;
    }
    class GeoMatchConstraintPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GeoMatchConstraintProperty | cdktn.IResolvable | undefined;
        set internalValue(value: GeoMatchConstraintProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class GeoMatchConstraintPropertyList extends cdktn.ComplexList {
        internalValue?: GeoMatchConstraintProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GeoMatchConstraintPropertyOutputReference;
    }
}
