import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsWafRuleGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_rule_group#id AwsWafRuleGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_rule_group#metric_name AwsWafRuleGroup#metric_name}
    */
    readonly metricName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_rule_group#name AwsWafRuleGroup#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_rule_group#tags AwsWafRuleGroup#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_rule_group#tags_all AwsWafRuleGroup#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * activated_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_rule_group#activated_rule AwsWafRuleGroup#activated_rule}
    */
    readonly activatedRule?: AwsWafRuleGroup.ActivatedRuleProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_rule_group aws_waf_rule_group}
*/
export declare class AwsWafRuleGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_waf_rule_group";
    /**
    * Generates CDKTN code for importing a AwsWafRuleGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsWafRuleGroup to import
    * @param importFromId The id of the existing AwsWafRuleGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_rule_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsWafRuleGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_rule_group aws_waf_rule_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsWafRuleGroupConfig
    */
    constructor(scope: Construct, id: string, config: AwsWafRuleGroupConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _metricName?;
    get metricName(): string;
    set metricName(value: string);
    get metricNameInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _activatedRule;
    get activatedRule(): AwsWafRuleGroup.ActivatedRulePropertyList;
    putActivatedRule(value: AwsWafRuleGroup.ActivatedRuleProperty[] | cdktn.IResolvable): void;
    resetActivatedRule(): void;
    get activatedRuleInput(): cdktn.IResolvable | AwsWafRuleGroup.ActivatedRuleProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsWafRuleGroupActionPropertyToTerraform(struct?: AwsWafRuleGroup.ActionPropertyOutputReference | AwsWafRuleGroup.ActionProperty): any;
export declare function awsWafRuleGroupActionPropertyToHclTerraform(struct?: AwsWafRuleGroup.ActionPropertyOutputReference | AwsWafRuleGroup.ActionProperty): any;
export declare function awsWafRuleGroupActivatedRulePropertyToTerraform(struct?: AwsWafRuleGroup.ActivatedRuleProperty | cdktn.IResolvable): any;
export declare function awsWafRuleGroupActivatedRulePropertyToHclTerraform(struct?: AwsWafRuleGroup.ActivatedRuleProperty | cdktn.IResolvable): any;
export declare namespace AwsWafRuleGroup {
    interface ActionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_rule_group#type AwsWafRuleGroup#type}
        */
        readonly type: string;
    }
    class ActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ActionProperty | undefined;
        set internalValue(value: ActionProperty | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    interface ActivatedRuleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_rule_group#priority AwsWafRuleGroup#priority}
        */
        readonly priority: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_rule_group#rule_id AwsWafRuleGroup#rule_id}
        */
        readonly ruleId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_rule_group#type AwsWafRuleGroup#type}
        */
        readonly type?: string;
        /**
        * action block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_rule_group#action AwsWafRuleGroup#action}
        */
        readonly action: ActionProperty;
    }
    class ActivatedRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ActivatedRuleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ActivatedRuleProperty | cdktn.IResolvable | undefined);
        private _priority?;
        get priority(): number;
        set priority(value: number);
        get priorityInput(): number | undefined;
        private _ruleId?;
        get ruleId(): string;
        set ruleId(value: string);
        get ruleIdInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
        private _action;
        get action(): ActionPropertyOutputReference;
        putAction(value: ActionProperty): void;
        get actionInput(): ActionProperty | undefined;
    }
    class ActivatedRulePropertyList extends cdktn.ComplexList {
        internalValue?: ActivatedRuleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ActivatedRulePropertyOutputReference;
    }
}
