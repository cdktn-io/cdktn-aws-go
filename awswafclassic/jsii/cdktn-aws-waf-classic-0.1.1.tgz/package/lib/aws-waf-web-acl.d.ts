import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsWafWebAclConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_web_acl#id AwsWafWebAcl#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_web_acl#metric_name AwsWafWebAcl#metric_name}
    */
    readonly metricName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_web_acl#name AwsWafWebAcl#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_web_acl#tags AwsWafWebAcl#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_web_acl#tags_all AwsWafWebAcl#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * default_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_web_acl#default_action AwsWafWebAcl#default_action}
    */
    readonly defaultAction: AwsWafWebAcl.DefaultActionProperty;
    /**
    * logging_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_web_acl#logging_configuration AwsWafWebAcl#logging_configuration}
    */
    readonly loggingConfiguration?: AwsWafWebAcl.LoggingConfigurationProperty;
    /**
    * rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_web_acl#rules AwsWafWebAcl#rules}
    */
    readonly rules?: AwsWafWebAcl.RulesProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_web_acl aws_waf_web_acl}
*/
export declare class AwsWafWebAcl extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_waf_web_acl";
    /**
    * Generates CDKTN code for importing a AwsWafWebAcl resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsWafWebAcl to import
    * @param importFromId The id of the existing AwsWafWebAcl that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_web_acl#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsWafWebAcl to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_web_acl aws_waf_web_acl} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsWafWebAclConfig
    */
    constructor(scope: Construct, id: string, config: AwsWafWebAclConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _metricName?;
    get metricName(): string;
    set metricName(value: string);
    get metricNameInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _defaultAction;
    get defaultAction(): AwsWafWebAcl.DefaultActionPropertyOutputReference;
    putDefaultAction(value: AwsWafWebAcl.DefaultActionProperty): void;
    get defaultActionInput(): AwsWafWebAcl.DefaultActionProperty | undefined;
    private _loggingConfiguration;
    get loggingConfiguration(): AwsWafWebAcl.LoggingConfigurationPropertyOutputReference;
    putLoggingConfiguration(value: AwsWafWebAcl.LoggingConfigurationProperty): void;
    resetLoggingConfiguration(): void;
    get loggingConfigurationInput(): AwsWafWebAcl.LoggingConfigurationProperty | undefined;
    private _rules;
    get rules(): AwsWafWebAcl.RulesPropertyList;
    putRules(value: AwsWafWebAcl.RulesProperty[] | cdktn.IResolvable): void;
    resetRules(): void;
    get rulesInput(): cdktn.IResolvable | AwsWafWebAcl.RulesProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsWafWebAclDefaultActionPropertyToTerraform(struct?: AwsWafWebAcl.DefaultActionPropertyOutputReference | AwsWafWebAcl.DefaultActionProperty): any;
export declare function awsWafWebAclDefaultActionPropertyToHclTerraform(struct?: AwsWafWebAcl.DefaultActionPropertyOutputReference | AwsWafWebAcl.DefaultActionProperty): any;
export declare function awsWafWebAclFieldToMatchPropertyToTerraform(struct?: AwsWafWebAcl.FieldToMatchProperty | cdktn.IResolvable): any;
export declare function awsWafWebAclFieldToMatchPropertyToHclTerraform(struct?: AwsWafWebAcl.FieldToMatchProperty | cdktn.IResolvable): any;
export declare function awsWafWebAclRedactedFieldsPropertyToTerraform(struct?: AwsWafWebAcl.RedactedFieldsPropertyOutputReference | AwsWafWebAcl.RedactedFieldsProperty): any;
export declare function awsWafWebAclRedactedFieldsPropertyToHclTerraform(struct?: AwsWafWebAcl.RedactedFieldsPropertyOutputReference | AwsWafWebAcl.RedactedFieldsProperty): any;
export declare function awsWafWebAclLoggingConfigurationPropertyToTerraform(struct?: AwsWafWebAcl.LoggingConfigurationPropertyOutputReference | AwsWafWebAcl.LoggingConfigurationProperty): any;
export declare function awsWafWebAclLoggingConfigurationPropertyToHclTerraform(struct?: AwsWafWebAcl.LoggingConfigurationPropertyOutputReference | AwsWafWebAcl.LoggingConfigurationProperty): any;
export declare function awsWafWebAclActionPropertyToTerraform(struct?: AwsWafWebAcl.ActionPropertyOutputReference | AwsWafWebAcl.ActionProperty): any;
export declare function awsWafWebAclActionPropertyToHclTerraform(struct?: AwsWafWebAcl.ActionPropertyOutputReference | AwsWafWebAcl.ActionProperty): any;
export declare function awsWafWebAclOverrideActionPropertyToTerraform(struct?: AwsWafWebAcl.OverrideActionPropertyOutputReference | AwsWafWebAcl.OverrideActionProperty): any;
export declare function awsWafWebAclOverrideActionPropertyToHclTerraform(struct?: AwsWafWebAcl.OverrideActionPropertyOutputReference | AwsWafWebAcl.OverrideActionProperty): any;
export declare function awsWafWebAclRulesPropertyToTerraform(struct?: AwsWafWebAcl.RulesProperty | cdktn.IResolvable): any;
export declare function awsWafWebAclRulesPropertyToHclTerraform(struct?: AwsWafWebAcl.RulesProperty | cdktn.IResolvable): any;
export declare namespace AwsWafWebAcl {
    interface DefaultActionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_web_acl#type AwsWafWebAcl#type}
        */
        readonly type: string;
    }
    class DefaultActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultActionProperty | undefined;
        set internalValue(value: DefaultActionProperty | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    interface FieldToMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_web_acl#data AwsWafWebAcl#data}
        */
        readonly data?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_web_acl#type AwsWafWebAcl#type}
        */
        readonly type: string;
    }
    class FieldToMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FieldToMatchProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FieldToMatchProperty | cdktn.IResolvable | undefined);
        private _data?;
        get data(): string;
        set data(value: string);
        resetData(): void;
        get dataInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class FieldToMatchPropertyList extends cdktn.ComplexList {
        internalValue?: FieldToMatchProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FieldToMatchPropertyOutputReference;
    }
    interface RedactedFieldsProperty {
        /**
        * field_to_match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_web_acl#field_to_match AwsWafWebAcl#field_to_match}
        */
        readonly fieldToMatch: FieldToMatchProperty[] | cdktn.IResolvable;
    }
    class RedactedFieldsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RedactedFieldsProperty | undefined;
        set internalValue(value: RedactedFieldsProperty | undefined);
        private _fieldToMatch;
        get fieldToMatch(): FieldToMatchPropertyList;
        putFieldToMatch(value: FieldToMatchProperty[] | cdktn.IResolvable): void;
        get fieldToMatchInput(): cdktn.IResolvable | FieldToMatchProperty[] | undefined;
    }
    interface LoggingConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_web_acl#log_destination AwsWafWebAcl#log_destination}
        */
        readonly logDestination: string;
        /**
        * redacted_fields block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_web_acl#redacted_fields AwsWafWebAcl#redacted_fields}
        */
        readonly redactedFields?: RedactedFieldsProperty;
    }
    class LoggingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LoggingConfigurationProperty | undefined;
        set internalValue(value: LoggingConfigurationProperty | undefined);
        private _logDestination?;
        get logDestination(): string;
        set logDestination(value: string);
        get logDestinationInput(): string | undefined;
        private _redactedFields;
        get redactedFields(): RedactedFieldsPropertyOutputReference;
        putRedactedFields(value: RedactedFieldsProperty): void;
        resetRedactedFields(): void;
        get redactedFieldsInput(): RedactedFieldsProperty | undefined;
    }
    interface ActionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_web_acl#type AwsWafWebAcl#type}
        */
        readonly type: string;
    }
    class ActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ActionProperty | undefined;
        set internalValue(value: ActionProperty | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    interface OverrideActionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_web_acl#type AwsWafWebAcl#type}
        */
        readonly type: string;
    }
    class OverrideActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OverrideActionProperty | undefined;
        set internalValue(value: OverrideActionProperty | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    interface RulesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_web_acl#priority AwsWafWebAcl#priority}
        */
        readonly priority: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_web_acl#rule_id AwsWafWebAcl#rule_id}
        */
        readonly ruleId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_web_acl#type AwsWafWebAcl#type}
        */
        readonly type?: string;
        /**
        * action block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_web_acl#action AwsWafWebAcl#action}
        */
        readonly action?: ActionProperty;
        /**
        * override_action block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_web_acl#override_action AwsWafWebAcl#override_action}
        */
        readonly overrideAction?: OverrideActionProperty;
    }
    class RulesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RulesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RulesProperty | cdktn.IResolvable | undefined);
        private _priority?;
        get priority(): number;
        set priority(value: number);
        get priorityInput(): number | undefined;
        private _ruleId?;
        get ruleId(): string;
        set ruleId(value: string);
        get ruleIdInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
        private _action;
        get action(): ActionPropertyOutputReference;
        putAction(value: ActionProperty): void;
        resetAction(): void;
        get actionInput(): ActionProperty | undefined;
        private _overrideAction;
        get overrideAction(): OverrideActionPropertyOutputReference;
        putOverrideAction(value: OverrideActionProperty): void;
        resetOverrideAction(): void;
        get overrideActionInput(): OverrideActionProperty | undefined;
    }
    class RulesPropertyList extends cdktn.ComplexList {
        internalValue?: RulesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RulesPropertyOutputReference;
    }
}
