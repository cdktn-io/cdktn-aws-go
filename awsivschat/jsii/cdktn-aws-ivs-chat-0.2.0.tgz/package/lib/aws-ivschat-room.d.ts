import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfRoomConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivschat_room#id TfRoom#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivschat_room#logging_configuration_identifiers TfRoom#logging_configuration_identifiers}
    */
    readonly loggingConfigurationIdentifiers?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivschat_room#maximum_message_length TfRoom#maximum_message_length}
    */
    readonly maximumMessageLength?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivschat_room#maximum_message_rate_per_second TfRoom#maximum_message_rate_per_second}
    */
    readonly maximumMessageRatePerSecond?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivschat_room#name TfRoom#name}
    */
    readonly name?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivschat_room#region TfRoom#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivschat_room#tags TfRoom#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivschat_room#tags_all TfRoom#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * message_review_handler block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivschat_room#message_review_handler TfRoom#message_review_handler}
    */
    readonly messageReviewHandler?: TfRoom.MessageReviewHandlerProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivschat_room#timeouts TfRoom#timeouts}
    */
    readonly timeouts?: TfRoom.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivschat_room aws_ivschat_room}
*/
export declare class TfRoom extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ivschat_room";
    /**
    * Generates CDKTN code for importing a TfRoom resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfRoom to import
    * @param importFromId The id of the existing TfRoom that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivschat_room#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfRoom to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivschat_room aws_ivschat_room} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfRoomConfig = {}
    */
    constructor(scope: Construct, id: string, config?: TfRoomConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _loggingConfigurationIdentifiers?;
    get loggingConfigurationIdentifiers(): string[];
    set loggingConfigurationIdentifiers(value: string[]);
    resetLoggingConfigurationIdentifiers(): void;
    get loggingConfigurationIdentifiersInput(): string[] | undefined;
    private _maximumMessageLength?;
    get maximumMessageLength(): number;
    set maximumMessageLength(value: number);
    resetMaximumMessageLength(): void;
    get maximumMessageLengthInput(): number | undefined;
    private _maximumMessageRatePerSecond?;
    get maximumMessageRatePerSecond(): number;
    set maximumMessageRatePerSecond(value: number);
    resetMaximumMessageRatePerSecond(): void;
    get maximumMessageRatePerSecondInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _messageReviewHandler;
    get messageReviewHandler(): TfRoom.MessageReviewHandlerPropertyOutputReference;
    putMessageReviewHandler(value: TfRoom.MessageReviewHandlerProperty): void;
    resetMessageReviewHandler(): void;
    get messageReviewHandlerInput(): TfRoom.MessageReviewHandlerProperty | undefined;
    private _timeouts;
    get timeouts(): TfRoom.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfRoom.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfRoom.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfRoomMessageReviewHandlerPropertyToTerraform(struct?: TfRoom.MessageReviewHandlerPropertyOutputReference | TfRoom.MessageReviewHandlerProperty): any;
export declare function tfRoomMessageReviewHandlerPropertyToHclTerraform(struct?: TfRoom.MessageReviewHandlerPropertyOutputReference | TfRoom.MessageReviewHandlerProperty): any;
export declare function tfRoomTimeoutsPropertyToTerraform(struct?: TfRoom.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfRoomTimeoutsPropertyToHclTerraform(struct?: TfRoom.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfRoom {
    interface MessageReviewHandlerProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivschat_room#fallback_result TfRoom#fallback_result}
        */
        readonly fallbackResult?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivschat_room#uri TfRoom#uri}
        */
        readonly uri?: string;
    }
    class MessageReviewHandlerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MessageReviewHandlerProperty | undefined;
        set internalValue(value: MessageReviewHandlerProperty | undefined);
        private _fallbackResult?;
        get fallbackResult(): string;
        set fallbackResult(value: string);
        resetFallbackResult(): void;
        get fallbackResultInput(): string | undefined;
        private _uri?;
        get uri(): string;
        set uri(value: string);
        resetUri(): void;
        get uriInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivschat_room#create TfRoom#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivschat_room#delete TfRoom#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivschat_room#update TfRoom#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
