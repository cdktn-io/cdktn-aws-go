import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsIvschatLoggingConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivschat_logging_configuration#id AwsIvschatLoggingConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivschat_logging_configuration#name AwsIvschatLoggingConfiguration#name}
    */
    readonly name?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivschat_logging_configuration#region AwsIvschatLoggingConfiguration#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivschat_logging_configuration#tags AwsIvschatLoggingConfiguration#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivschat_logging_configuration#tags_all AwsIvschatLoggingConfiguration#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * destination_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivschat_logging_configuration#destination_configuration AwsIvschatLoggingConfiguration#destination_configuration}
    */
    readonly destinationConfiguration?: AwsIvschatLoggingConfiguration.DestinationConfigurationProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivschat_logging_configuration#timeouts AwsIvschatLoggingConfiguration#timeouts}
    */
    readonly timeouts?: AwsIvschatLoggingConfiguration.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivschat_logging_configuration aws_ivschat_logging_configuration}
*/
export declare class AwsIvschatLoggingConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ivschat_logging_configuration";
    /**
    * Generates CDKTN code for importing a AwsIvschatLoggingConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsIvschatLoggingConfiguration to import
    * @param importFromId The id of the existing AwsIvschatLoggingConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivschat_logging_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsIvschatLoggingConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivschat_logging_configuration aws_ivschat_logging_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsIvschatLoggingConfigurationConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AwsIvschatLoggingConfigurationConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get state(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _destinationConfiguration;
    get destinationConfiguration(): AwsIvschatLoggingConfiguration.DestinationConfigurationPropertyOutputReference;
    putDestinationConfiguration(value: AwsIvschatLoggingConfiguration.DestinationConfigurationProperty): void;
    resetDestinationConfiguration(): void;
    get destinationConfigurationInput(): AwsIvschatLoggingConfiguration.DestinationConfigurationProperty | undefined;
    private _timeouts;
    get timeouts(): AwsIvschatLoggingConfiguration.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsIvschatLoggingConfiguration.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): AwsIvschatLoggingConfiguration.TimeoutsProperty | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsIvschatLoggingConfigurationCloudwatchLogsPropertyToTerraform(struct?: AwsIvschatLoggingConfiguration.CloudwatchLogsPropertyOutputReference | AwsIvschatLoggingConfiguration.CloudwatchLogsProperty): any;
export declare function awsIvschatLoggingConfigurationCloudwatchLogsPropertyToHclTerraform(struct?: AwsIvschatLoggingConfiguration.CloudwatchLogsPropertyOutputReference | AwsIvschatLoggingConfiguration.CloudwatchLogsProperty): any;
export declare function awsIvschatLoggingConfigurationFirehosePropertyToTerraform(struct?: AwsIvschatLoggingConfiguration.FirehosePropertyOutputReference | AwsIvschatLoggingConfiguration.FirehoseProperty): any;
export declare function awsIvschatLoggingConfigurationFirehosePropertyToHclTerraform(struct?: AwsIvschatLoggingConfiguration.FirehosePropertyOutputReference | AwsIvschatLoggingConfiguration.FirehoseProperty): any;
export declare function awsIvschatLoggingConfigurationS3PropertyToTerraform(struct?: AwsIvschatLoggingConfiguration.S3PropertyOutputReference | AwsIvschatLoggingConfiguration.S3Property): any;
export declare function awsIvschatLoggingConfigurationS3PropertyToHclTerraform(struct?: AwsIvschatLoggingConfiguration.S3PropertyOutputReference | AwsIvschatLoggingConfiguration.S3Property): any;
export declare function awsIvschatLoggingConfigurationDestinationConfigurationPropertyToTerraform(struct?: AwsIvschatLoggingConfiguration.DestinationConfigurationPropertyOutputReference | AwsIvschatLoggingConfiguration.DestinationConfigurationProperty): any;
export declare function awsIvschatLoggingConfigurationDestinationConfigurationPropertyToHclTerraform(struct?: AwsIvschatLoggingConfiguration.DestinationConfigurationPropertyOutputReference | AwsIvschatLoggingConfiguration.DestinationConfigurationProperty): any;
export declare function awsIvschatLoggingConfigurationTimeoutsPropertyToTerraform(struct?: AwsIvschatLoggingConfiguration.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsIvschatLoggingConfigurationTimeoutsPropertyToHclTerraform(struct?: AwsIvschatLoggingConfiguration.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsIvschatLoggingConfiguration {
    interface CloudwatchLogsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivschat_logging_configuration#log_group_name AwsIvschatLoggingConfiguration#log_group_name}
        */
        readonly logGroupName: string;
    }
    class CloudwatchLogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CloudwatchLogsProperty | undefined;
        set internalValue(value: CloudwatchLogsProperty | undefined);
        private _logGroupName?;
        get logGroupName(): string;
        set logGroupName(value: string);
        get logGroupNameInput(): string | undefined;
    }
    interface FirehoseProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivschat_logging_configuration#delivery_stream_name AwsIvschatLoggingConfiguration#delivery_stream_name}
        */
        readonly deliveryStreamName: string;
    }
    class FirehosePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FirehoseProperty | undefined;
        set internalValue(value: FirehoseProperty | undefined);
        private _deliveryStreamName?;
        get deliveryStreamName(): string;
        set deliveryStreamName(value: string);
        get deliveryStreamNameInput(): string | undefined;
    }
    interface S3Property {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivschat_logging_configuration#bucket_name AwsIvschatLoggingConfiguration#bucket_name}
        */
        readonly bucketName: string;
    }
    class S3PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3Property | undefined;
        set internalValue(value: S3Property | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        get bucketNameInput(): string | undefined;
    }
    interface DestinationConfigurationProperty {
        /**
        * cloudwatch_logs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivschat_logging_configuration#cloudwatch_logs AwsIvschatLoggingConfiguration#cloudwatch_logs}
        */
        readonly cloudwatchLogs?: CloudwatchLogsProperty;
        /**
        * firehose block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivschat_logging_configuration#firehose AwsIvschatLoggingConfiguration#firehose}
        */
        readonly firehose?: FirehoseProperty;
        /**
        * s3 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivschat_logging_configuration#s3 AwsIvschatLoggingConfiguration#s3}
        */
        readonly s3?: S3Property;
    }
    class DestinationConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationConfigurationProperty | undefined;
        set internalValue(value: DestinationConfigurationProperty | undefined);
        private _cloudwatchLogs;
        get cloudwatchLogs(): CloudwatchLogsPropertyOutputReference;
        putCloudwatchLogs(value: CloudwatchLogsProperty): void;
        resetCloudwatchLogs(): void;
        get cloudwatchLogsInput(): CloudwatchLogsProperty | undefined;
        private _firehose;
        get firehose(): FirehosePropertyOutputReference;
        putFirehose(value: FirehoseProperty): void;
        resetFirehose(): void;
        get firehoseInput(): FirehoseProperty | undefined;
        private _s3;
        get s3(): S3PropertyOutputReference;
        putS3(value: S3Property): void;
        resetS3(): void;
        get s3Input(): S3Property | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivschat_logging_configuration#create AwsIvschatLoggingConfiguration#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivschat_logging_configuration#delete AwsIvschatLoggingConfiguration#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivschat_logging_configuration#update AwsIvschatLoggingConfiguration#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
