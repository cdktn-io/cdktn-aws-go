import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsFmsResourceSetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_resource_set#region AwsFmsResourceSet#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_resource_set#tags AwsFmsResourceSet#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * resource_set block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_resource_set#resource_set AwsFmsResourceSet#resource_set}
    */
    readonly resourceSet?: AwsFmsResourceSet.ResourceSetProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_resource_set#timeouts AwsFmsResourceSet#timeouts}
    */
    readonly timeouts?: AwsFmsResourceSet.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_resource_set aws_fms_resource_set}
*/
export declare class AwsFmsResourceSet extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_fms_resource_set";
    /**
    * Generates CDKTN code for importing a AwsFmsResourceSet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsFmsResourceSet to import
    * @param importFromId The id of the existing AwsFmsResourceSet that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_resource_set#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsFmsResourceSet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_resource_set aws_fms_resource_set} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsFmsResourceSetConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AwsFmsResourceSetConfig);
    get arn(): string;
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _resourceSet;
    get resourceSet(): AwsFmsResourceSet.ResourceSetPropertyList;
    putResourceSet(value: AwsFmsResourceSet.ResourceSetProperty[] | cdktn.IResolvable): void;
    resetResourceSet(): void;
    get resourceSetInput(): cdktn.IResolvable | AwsFmsResourceSet.ResourceSetProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsFmsResourceSet.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsFmsResourceSet.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsFmsResourceSet.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsFmsResourceSetResourceSetPropertyToTerraform(struct?: AwsFmsResourceSet.ResourceSetProperty | cdktn.IResolvable): any;
export declare function awsFmsResourceSetResourceSetPropertyToHclTerraform(struct?: AwsFmsResourceSet.ResourceSetProperty | cdktn.IResolvable): any;
export declare function awsFmsResourceSetTimeoutsPropertyToTerraform(struct?: AwsFmsResourceSet.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsFmsResourceSetTimeoutsPropertyToHclTerraform(struct?: AwsFmsResourceSet.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsFmsResourceSet {
    interface ResourceSetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_resource_set#description AwsFmsResourceSet#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_resource_set#name AwsFmsResourceSet#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_resource_set#resource_set_status AwsFmsResourceSet#resource_set_status}
        */
        readonly resourceSetStatus?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_resource_set#resource_type_list AwsFmsResourceSet#resource_type_list}
        */
        readonly resourceTypeList?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_resource_set#update_token AwsFmsResourceSet#update_token}
        */
        readonly updateToken?: string;
    }
    class ResourceSetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceSetProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceSetProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        get id(): string;
        get lastUpdateTime(): string;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _resourceSetStatus?;
        get resourceSetStatus(): string;
        set resourceSetStatus(value: string);
        resetResourceSetStatus(): void;
        get resourceSetStatusInput(): string | undefined;
        private _resourceTypeList?;
        get resourceTypeList(): string[];
        set resourceTypeList(value: string[]);
        resetResourceTypeList(): void;
        get resourceTypeListInput(): string[] | undefined;
        private _updateToken?;
        get updateToken(): string;
        set updateToken(value: string);
        resetUpdateToken(): void;
        get updateTokenInput(): string | undefined;
    }
    class ResourceSetPropertyList extends cdktn.ComplexList {
        internalValue?: ResourceSetProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceSetPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_resource_set#create AwsFmsResourceSet#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_resource_set#delete AwsFmsResourceSet#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_resource_set#update AwsFmsResourceSet#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
