import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsFmsPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#delete_all_policy_resources AwsFmsPolicy#delete_all_policy_resources}
    */
    readonly deleteAllPolicyResources?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#delete_unused_fm_managed_resources AwsFmsPolicy#delete_unused_fm_managed_resources}
    */
    readonly deleteUnusedFmManagedResources?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#description AwsFmsPolicy#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#exclude_resource_tags AwsFmsPolicy#exclude_resource_tags}
    */
    readonly excludeResourceTags: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#id AwsFmsPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#name AwsFmsPolicy#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#region AwsFmsPolicy#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#remediation_enabled AwsFmsPolicy#remediation_enabled}
    */
    readonly remediationEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#resource_set_ids AwsFmsPolicy#resource_set_ids}
    */
    readonly resourceSetIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#resource_tag_logical_operator AwsFmsPolicy#resource_tag_logical_operator}
    */
    readonly resourceTagLogicalOperator?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#resource_tags AwsFmsPolicy#resource_tags}
    */
    readonly resourceTags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#resource_type AwsFmsPolicy#resource_type}
    */
    readonly resourceType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#resource_type_list AwsFmsPolicy#resource_type_list}
    */
    readonly resourceTypeList?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#tags AwsFmsPolicy#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#tags_all AwsFmsPolicy#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * exclude_map block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#exclude_map AwsFmsPolicy#exclude_map}
    */
    readonly excludeMap?: AwsFmsPolicy.ExcludeMapProperty;
    /**
    * include_map block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#include_map AwsFmsPolicy#include_map}
    */
    readonly includeMap?: AwsFmsPolicy.IncludeMapProperty;
    /**
    * security_service_policy_data block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#security_service_policy_data AwsFmsPolicy#security_service_policy_data}
    */
    readonly securityServicePolicyData: AwsFmsPolicy.SecurityServicePolicyDataProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy aws_fms_policy}
*/
export declare class AwsFmsPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_fms_policy";
    /**
    * Generates CDKTN code for importing a AwsFmsPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsFmsPolicy to import
    * @param importFromId The id of the existing AwsFmsPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsFmsPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy aws_fms_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsFmsPolicyConfig
    */
    constructor(scope: Construct, id: string, config: AwsFmsPolicyConfig);
    get arn(): string;
    private _deleteAllPolicyResources?;
    get deleteAllPolicyResources(): boolean | cdktn.IResolvable;
    set deleteAllPolicyResources(value: boolean | cdktn.IResolvable);
    resetDeleteAllPolicyResources(): void;
    get deleteAllPolicyResourcesInput(): boolean | cdktn.IResolvable | undefined;
    private _deleteUnusedFmManagedResources?;
    get deleteUnusedFmManagedResources(): boolean | cdktn.IResolvable;
    set deleteUnusedFmManagedResources(value: boolean | cdktn.IResolvable);
    resetDeleteUnusedFmManagedResources(): void;
    get deleteUnusedFmManagedResourcesInput(): boolean | cdktn.IResolvable | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _excludeResourceTags?;
    get excludeResourceTags(): boolean | cdktn.IResolvable;
    set excludeResourceTags(value: boolean | cdktn.IResolvable);
    get excludeResourceTagsInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get policyUpdateToken(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _remediationEnabled?;
    get remediationEnabled(): boolean | cdktn.IResolvable;
    set remediationEnabled(value: boolean | cdktn.IResolvable);
    resetRemediationEnabled(): void;
    get remediationEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _resourceSetIds?;
    get resourceSetIds(): string[];
    set resourceSetIds(value: string[]);
    resetResourceSetIds(): void;
    get resourceSetIdsInput(): string[] | undefined;
    private _resourceTagLogicalOperator?;
    get resourceTagLogicalOperator(): string;
    set resourceTagLogicalOperator(value: string);
    resetResourceTagLogicalOperator(): void;
    get resourceTagLogicalOperatorInput(): string | undefined;
    private _resourceTags?;
    get resourceTags(): {
        [key: string]: string;
    };
    set resourceTags(value: {
        [key: string]: string;
    });
    resetResourceTags(): void;
    get resourceTagsInput(): {
        [key: string]: string;
    } | undefined;
    private _resourceType?;
    get resourceType(): string;
    set resourceType(value: string);
    resetResourceType(): void;
    get resourceTypeInput(): string | undefined;
    private _resourceTypeList?;
    get resourceTypeList(): string[];
    set resourceTypeList(value: string[]);
    resetResourceTypeList(): void;
    get resourceTypeListInput(): string[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _excludeMap;
    get excludeMap(): AwsFmsPolicy.ExcludeMapPropertyOutputReference;
    putExcludeMap(value: AwsFmsPolicy.ExcludeMapProperty): void;
    resetExcludeMap(): void;
    get excludeMapInput(): AwsFmsPolicy.ExcludeMapProperty | undefined;
    private _includeMap;
    get includeMap(): AwsFmsPolicy.IncludeMapPropertyOutputReference;
    putIncludeMap(value: AwsFmsPolicy.IncludeMapProperty): void;
    resetIncludeMap(): void;
    get includeMapInput(): AwsFmsPolicy.IncludeMapProperty | undefined;
    private _securityServicePolicyData;
    get securityServicePolicyData(): AwsFmsPolicy.SecurityServicePolicyDataPropertyOutputReference;
    putSecurityServicePolicyData(value: AwsFmsPolicy.SecurityServicePolicyDataProperty): void;
    get securityServicePolicyDataInput(): AwsFmsPolicy.SecurityServicePolicyDataProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsFmsPolicyExcludeMapPropertyToTerraform(struct?: AwsFmsPolicy.ExcludeMapPropertyOutputReference | AwsFmsPolicy.ExcludeMapProperty): any;
export declare function awsFmsPolicyExcludeMapPropertyToHclTerraform(struct?: AwsFmsPolicy.ExcludeMapPropertyOutputReference | AwsFmsPolicy.ExcludeMapProperty): any;
export declare function awsFmsPolicyIncludeMapPropertyToTerraform(struct?: AwsFmsPolicy.IncludeMapPropertyOutputReference | AwsFmsPolicy.IncludeMapProperty): any;
export declare function awsFmsPolicyIncludeMapPropertyToHclTerraform(struct?: AwsFmsPolicy.IncludeMapPropertyOutputReference | AwsFmsPolicy.IncludeMapProperty): any;
export declare function awsFmsPolicySecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetFirstEntryIcmpTypeCodePropertyToTerraform(struct?: AwsFmsPolicy.SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetFirstEntryIcmpTypeCodeProperty | cdktn.IResolvable): any;
export declare function awsFmsPolicySecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetFirstEntryIcmpTypeCodePropertyToHclTerraform(struct?: AwsFmsPolicy.SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetFirstEntryIcmpTypeCodeProperty | cdktn.IResolvable): any;
export declare function awsFmsPolicySecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetFirstEntryPortRangePropertyToTerraform(struct?: AwsFmsPolicy.SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetFirstEntryPortRangeProperty | cdktn.IResolvable): any;
export declare function awsFmsPolicySecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetFirstEntryPortRangePropertyToHclTerraform(struct?: AwsFmsPolicy.SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetFirstEntryPortRangeProperty | cdktn.IResolvable): any;
export declare function awsFmsPolicyFirstEntryPropertyToTerraform(struct?: AwsFmsPolicy.FirstEntryProperty | cdktn.IResolvable): any;
export declare function awsFmsPolicyFirstEntryPropertyToHclTerraform(struct?: AwsFmsPolicy.FirstEntryProperty | cdktn.IResolvable): any;
export declare function awsFmsPolicySecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetLastEntryIcmpTypeCodePropertyToTerraform(struct?: AwsFmsPolicy.SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetLastEntryIcmpTypeCodeProperty | cdktn.IResolvable): any;
export declare function awsFmsPolicySecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetLastEntryIcmpTypeCodePropertyToHclTerraform(struct?: AwsFmsPolicy.SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetLastEntryIcmpTypeCodeProperty | cdktn.IResolvable): any;
export declare function awsFmsPolicySecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetLastEntryPortRangePropertyToTerraform(struct?: AwsFmsPolicy.SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetLastEntryPortRangeProperty | cdktn.IResolvable): any;
export declare function awsFmsPolicySecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetLastEntryPortRangePropertyToHclTerraform(struct?: AwsFmsPolicy.SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetLastEntryPortRangeProperty | cdktn.IResolvable): any;
export declare function awsFmsPolicyLastEntryPropertyToTerraform(struct?: AwsFmsPolicy.LastEntryProperty | cdktn.IResolvable): any;
export declare function awsFmsPolicyLastEntryPropertyToHclTerraform(struct?: AwsFmsPolicy.LastEntryProperty | cdktn.IResolvable): any;
export declare function awsFmsPolicyNetworkAclEntrySetPropertyToTerraform(struct?: AwsFmsPolicy.NetworkAclEntrySetPropertyOutputReference | AwsFmsPolicy.NetworkAclEntrySetProperty): any;
export declare function awsFmsPolicyNetworkAclEntrySetPropertyToHclTerraform(struct?: AwsFmsPolicy.NetworkAclEntrySetPropertyOutputReference | AwsFmsPolicy.NetworkAclEntrySetProperty): any;
export declare function awsFmsPolicyNetworkAclCommonPolicyPropertyToTerraform(struct?: AwsFmsPolicy.NetworkAclCommonPolicyPropertyOutputReference | AwsFmsPolicy.NetworkAclCommonPolicyProperty): any;
export declare function awsFmsPolicyNetworkAclCommonPolicyPropertyToHclTerraform(struct?: AwsFmsPolicy.NetworkAclCommonPolicyPropertyOutputReference | AwsFmsPolicy.NetworkAclCommonPolicyProperty): any;
export declare function awsFmsPolicyNetworkFirewallPolicyPropertyToTerraform(struct?: AwsFmsPolicy.NetworkFirewallPolicyPropertyOutputReference | AwsFmsPolicy.NetworkFirewallPolicyProperty): any;
export declare function awsFmsPolicyNetworkFirewallPolicyPropertyToHclTerraform(struct?: AwsFmsPolicy.NetworkFirewallPolicyPropertyOutputReference | AwsFmsPolicy.NetworkFirewallPolicyProperty): any;
export declare function awsFmsPolicyThirdPartyFirewallPolicyPropertyToTerraform(struct?: AwsFmsPolicy.ThirdPartyFirewallPolicyPropertyOutputReference | AwsFmsPolicy.ThirdPartyFirewallPolicyProperty): any;
export declare function awsFmsPolicyThirdPartyFirewallPolicyPropertyToHclTerraform(struct?: AwsFmsPolicy.ThirdPartyFirewallPolicyPropertyOutputReference | AwsFmsPolicy.ThirdPartyFirewallPolicyProperty): any;
export declare function awsFmsPolicyPolicyOptionPropertyToTerraform(struct?: AwsFmsPolicy.PolicyOptionPropertyOutputReference | AwsFmsPolicy.PolicyOptionProperty): any;
export declare function awsFmsPolicyPolicyOptionPropertyToHclTerraform(struct?: AwsFmsPolicy.PolicyOptionPropertyOutputReference | AwsFmsPolicy.PolicyOptionProperty): any;
export declare function awsFmsPolicySecurityServicePolicyDataPropertyToTerraform(struct?: AwsFmsPolicy.SecurityServicePolicyDataPropertyOutputReference | AwsFmsPolicy.SecurityServicePolicyDataProperty): any;
export declare function awsFmsPolicySecurityServicePolicyDataPropertyToHclTerraform(struct?: AwsFmsPolicy.SecurityServicePolicyDataPropertyOutputReference | AwsFmsPolicy.SecurityServicePolicyDataProperty): any;
export declare namespace AwsFmsPolicy {
    interface ExcludeMapProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#account AwsFmsPolicy#account}
        */
        readonly account?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#orgunit AwsFmsPolicy#orgunit}
        */
        readonly orgunit?: string[];
    }
    class ExcludeMapPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ExcludeMapProperty | undefined;
        set internalValue(value: ExcludeMapProperty | undefined);
        private _account?;
        get account(): string[];
        set account(value: string[]);
        resetAccount(): void;
        get accountInput(): string[] | undefined;
        private _orgunit?;
        get orgunit(): string[];
        set orgunit(value: string[]);
        resetOrgunit(): void;
        get orgunitInput(): string[] | undefined;
    }
    interface IncludeMapProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#account AwsFmsPolicy#account}
        */
        readonly account?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#orgunit AwsFmsPolicy#orgunit}
        */
        readonly orgunit?: string[];
    }
    class IncludeMapPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IncludeMapProperty | undefined;
        set internalValue(value: IncludeMapProperty | undefined);
        private _account?;
        get account(): string[];
        set account(value: string[]);
        resetAccount(): void;
        get accountInput(): string[] | undefined;
        private _orgunit?;
        get orgunit(): string[];
        set orgunit(value: string[]);
        resetOrgunit(): void;
        get orgunitInput(): string[] | undefined;
    }
    interface SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetFirstEntryIcmpTypeCodeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#code AwsFmsPolicy#code}
        */
        readonly code?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#type AwsFmsPolicy#type}
        */
        readonly type?: number;
    }
    class SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetFirstEntryIcmpTypeCodePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetFirstEntryIcmpTypeCodeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetFirstEntryIcmpTypeCodeProperty | cdktn.IResolvable | undefined);
        private _code?;
        get code(): number;
        set code(value: number);
        resetCode(): void;
        get codeInput(): number | undefined;
        private _type?;
        get type(): number;
        set type(value: number);
        resetType(): void;
        get typeInput(): number | undefined;
    }
    class SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetFirstEntryIcmpTypeCodePropertyList extends cdktn.ComplexList {
        internalValue?: SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetFirstEntryIcmpTypeCodeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetFirstEntryIcmpTypeCodePropertyOutputReference;
    }
    interface SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetFirstEntryPortRangeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#from AwsFmsPolicy#from}
        */
        readonly from?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#to AwsFmsPolicy#to}
        */
        readonly to?: number;
    }
    class SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetFirstEntryPortRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetFirstEntryPortRangeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetFirstEntryPortRangeProperty | cdktn.IResolvable | undefined);
        private _from?;
        get from(): number;
        set from(value: number);
        resetFrom(): void;
        get fromInput(): number | undefined;
        private _to?;
        get to(): number;
        set to(value: number);
        resetTo(): void;
        get toInput(): number | undefined;
    }
    class SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetFirstEntryPortRangePropertyList extends cdktn.ComplexList {
        internalValue?: SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetFirstEntryPortRangeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetFirstEntryPortRangePropertyOutputReference;
    }
    interface FirstEntryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#cidr_block AwsFmsPolicy#cidr_block}
        */
        readonly cidrBlock?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#egress AwsFmsPolicy#egress}
        */
        readonly egress: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#ipv6_cidr_block AwsFmsPolicy#ipv6_cidr_block}
        */
        readonly ipv6CidrBlock?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#protocol AwsFmsPolicy#protocol}
        */
        readonly protocol: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#rule_action AwsFmsPolicy#rule_action}
        */
        readonly ruleAction: string;
        /**
        * icmp_type_code block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#icmp_type_code AwsFmsPolicy#icmp_type_code}
        */
        readonly icmpTypeCode?: SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetFirstEntryIcmpTypeCodeProperty[] | cdktn.IResolvable;
        /**
        * port_range block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#port_range AwsFmsPolicy#port_range}
        */
        readonly portRange?: SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetFirstEntryPortRangeProperty[] | cdktn.IResolvable;
    }
    class FirstEntryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FirstEntryProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FirstEntryProperty | cdktn.IResolvable | undefined);
        private _cidrBlock?;
        get cidrBlock(): string;
        set cidrBlock(value: string);
        resetCidrBlock(): void;
        get cidrBlockInput(): string | undefined;
        private _egress?;
        get egress(): boolean | cdktn.IResolvable;
        set egress(value: boolean | cdktn.IResolvable);
        get egressInput(): boolean | cdktn.IResolvable | undefined;
        private _ipv6CidrBlock?;
        get ipv6CidrBlock(): string;
        set ipv6CidrBlock(value: string);
        resetIpv6CidrBlock(): void;
        get ipv6CidrBlockInput(): string | undefined;
        private _protocol?;
        get protocol(): string;
        set protocol(value: string);
        get protocolInput(): string | undefined;
        private _ruleAction?;
        get ruleAction(): string;
        set ruleAction(value: string);
        get ruleActionInput(): string | undefined;
        private _icmpTypeCode;
        get icmpTypeCode(): SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetFirstEntryIcmpTypeCodePropertyList;
        putIcmpTypeCode(value: SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetFirstEntryIcmpTypeCodeProperty[] | cdktn.IResolvable): void;
        resetIcmpTypeCode(): void;
        get icmpTypeCodeInput(): cdktn.IResolvable | SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetFirstEntryIcmpTypeCodeProperty[] | undefined;
        private _portRange;
        get portRange(): SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetFirstEntryPortRangePropertyList;
        putPortRange(value: SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetFirstEntryPortRangeProperty[] | cdktn.IResolvable): void;
        resetPortRange(): void;
        get portRangeInput(): cdktn.IResolvable | SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetFirstEntryPortRangeProperty[] | undefined;
    }
    class FirstEntryPropertyList extends cdktn.ComplexList {
        internalValue?: FirstEntryProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FirstEntryPropertyOutputReference;
    }
    interface SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetLastEntryIcmpTypeCodeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#code AwsFmsPolicy#code}
        */
        readonly code?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#type AwsFmsPolicy#type}
        */
        readonly type?: number;
    }
    class SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetLastEntryIcmpTypeCodePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetLastEntryIcmpTypeCodeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetLastEntryIcmpTypeCodeProperty | cdktn.IResolvable | undefined);
        private _code?;
        get code(): number;
        set code(value: number);
        resetCode(): void;
        get codeInput(): number | undefined;
        private _type?;
        get type(): number;
        set type(value: number);
        resetType(): void;
        get typeInput(): number | undefined;
    }
    class SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetLastEntryIcmpTypeCodePropertyList extends cdktn.ComplexList {
        internalValue?: SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetLastEntryIcmpTypeCodeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetLastEntryIcmpTypeCodePropertyOutputReference;
    }
    interface SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetLastEntryPortRangeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#from AwsFmsPolicy#from}
        */
        readonly from?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#to AwsFmsPolicy#to}
        */
        readonly to?: number;
    }
    class SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetLastEntryPortRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetLastEntryPortRangeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetLastEntryPortRangeProperty | cdktn.IResolvable | undefined);
        private _from?;
        get from(): number;
        set from(value: number);
        resetFrom(): void;
        get fromInput(): number | undefined;
        private _to?;
        get to(): number;
        set to(value: number);
        resetTo(): void;
        get toInput(): number | undefined;
    }
    class SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetLastEntryPortRangePropertyList extends cdktn.ComplexList {
        internalValue?: SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetLastEntryPortRangeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetLastEntryPortRangePropertyOutputReference;
    }
    interface LastEntryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#cidr_block AwsFmsPolicy#cidr_block}
        */
        readonly cidrBlock?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#egress AwsFmsPolicy#egress}
        */
        readonly egress: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#ipv6_cidr_block AwsFmsPolicy#ipv6_cidr_block}
        */
        readonly ipv6CidrBlock?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#protocol AwsFmsPolicy#protocol}
        */
        readonly protocol: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#rule_action AwsFmsPolicy#rule_action}
        */
        readonly ruleAction: string;
        /**
        * icmp_type_code block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#icmp_type_code AwsFmsPolicy#icmp_type_code}
        */
        readonly icmpTypeCode?: SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetLastEntryIcmpTypeCodeProperty[] | cdktn.IResolvable;
        /**
        * port_range block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#port_range AwsFmsPolicy#port_range}
        */
        readonly portRange?: SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetLastEntryPortRangeProperty[] | cdktn.IResolvable;
    }
    class LastEntryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LastEntryProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LastEntryProperty | cdktn.IResolvable | undefined);
        private _cidrBlock?;
        get cidrBlock(): string;
        set cidrBlock(value: string);
        resetCidrBlock(): void;
        get cidrBlockInput(): string | undefined;
        private _egress?;
        get egress(): boolean | cdktn.IResolvable;
        set egress(value: boolean | cdktn.IResolvable);
        get egressInput(): boolean | cdktn.IResolvable | undefined;
        private _ipv6CidrBlock?;
        get ipv6CidrBlock(): string;
        set ipv6CidrBlock(value: string);
        resetIpv6CidrBlock(): void;
        get ipv6CidrBlockInput(): string | undefined;
        private _protocol?;
        get protocol(): string;
        set protocol(value: string);
        get protocolInput(): string | undefined;
        private _ruleAction?;
        get ruleAction(): string;
        set ruleAction(value: string);
        get ruleActionInput(): string | undefined;
        private _icmpTypeCode;
        get icmpTypeCode(): SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetLastEntryIcmpTypeCodePropertyList;
        putIcmpTypeCode(value: SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetLastEntryIcmpTypeCodeProperty[] | cdktn.IResolvable): void;
        resetIcmpTypeCode(): void;
        get icmpTypeCodeInput(): cdktn.IResolvable | SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetLastEntryIcmpTypeCodeProperty[] | undefined;
        private _portRange;
        get portRange(): SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetLastEntryPortRangePropertyList;
        putPortRange(value: SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetLastEntryPortRangeProperty[] | cdktn.IResolvable): void;
        resetPortRange(): void;
        get portRangeInput(): cdktn.IResolvable | SecurityServicePolicyDataPolicyOptionNetworkAclCommonPolicyNetworkAclEntrySetLastEntryPortRangeProperty[] | undefined;
    }
    class LastEntryPropertyList extends cdktn.ComplexList {
        internalValue?: LastEntryProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LastEntryPropertyOutputReference;
    }
    interface NetworkAclEntrySetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#force_remediate_for_first_entries AwsFmsPolicy#force_remediate_for_first_entries}
        */
        readonly forceRemediateForFirstEntries: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#force_remediate_for_last_entries AwsFmsPolicy#force_remediate_for_last_entries}
        */
        readonly forceRemediateForLastEntries: boolean | cdktn.IResolvable;
        /**
        * first_entry block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#first_entry AwsFmsPolicy#first_entry}
        */
        readonly firstEntry?: FirstEntryProperty[] | cdktn.IResolvable;
        /**
        * last_entry block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#last_entry AwsFmsPolicy#last_entry}
        */
        readonly lastEntry?: LastEntryProperty[] | cdktn.IResolvable;
    }
    class NetworkAclEntrySetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NetworkAclEntrySetProperty | undefined;
        set internalValue(value: NetworkAclEntrySetProperty | undefined);
        private _forceRemediateForFirstEntries?;
        get forceRemediateForFirstEntries(): boolean | cdktn.IResolvable;
        set forceRemediateForFirstEntries(value: boolean | cdktn.IResolvable);
        get forceRemediateForFirstEntriesInput(): boolean | cdktn.IResolvable | undefined;
        private _forceRemediateForLastEntries?;
        get forceRemediateForLastEntries(): boolean | cdktn.IResolvable;
        set forceRemediateForLastEntries(value: boolean | cdktn.IResolvable);
        get forceRemediateForLastEntriesInput(): boolean | cdktn.IResolvable | undefined;
        private _firstEntry;
        get firstEntry(): FirstEntryPropertyList;
        putFirstEntry(value: FirstEntryProperty[] | cdktn.IResolvable): void;
        resetFirstEntry(): void;
        get firstEntryInput(): cdktn.IResolvable | FirstEntryProperty[] | undefined;
        private _lastEntry;
        get lastEntry(): LastEntryPropertyList;
        putLastEntry(value: LastEntryProperty[] | cdktn.IResolvable): void;
        resetLastEntry(): void;
        get lastEntryInput(): cdktn.IResolvable | LastEntryProperty[] | undefined;
    }
    interface NetworkAclCommonPolicyProperty {
        /**
        * network_acl_entry_set block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#network_acl_entry_set AwsFmsPolicy#network_acl_entry_set}
        */
        readonly networkAclEntrySet?: NetworkAclEntrySetProperty;
    }
    class NetworkAclCommonPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NetworkAclCommonPolicyProperty | undefined;
        set internalValue(value: NetworkAclCommonPolicyProperty | undefined);
        private _networkAclEntrySet;
        get networkAclEntrySet(): NetworkAclEntrySetPropertyOutputReference;
        putNetworkAclEntrySet(value: NetworkAclEntrySetProperty): void;
        resetNetworkAclEntrySet(): void;
        get networkAclEntrySetInput(): NetworkAclEntrySetProperty | undefined;
    }
    interface NetworkFirewallPolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#firewall_deployment_model AwsFmsPolicy#firewall_deployment_model}
        */
        readonly firewallDeploymentModel?: string;
    }
    class NetworkFirewallPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NetworkFirewallPolicyProperty | undefined;
        set internalValue(value: NetworkFirewallPolicyProperty | undefined);
        private _firewallDeploymentModel?;
        get firewallDeploymentModel(): string;
        set firewallDeploymentModel(value: string);
        resetFirewallDeploymentModel(): void;
        get firewallDeploymentModelInput(): string | undefined;
    }
    interface ThirdPartyFirewallPolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#firewall_deployment_model AwsFmsPolicy#firewall_deployment_model}
        */
        readonly firewallDeploymentModel?: string;
    }
    class ThirdPartyFirewallPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ThirdPartyFirewallPolicyProperty | undefined;
        set internalValue(value: ThirdPartyFirewallPolicyProperty | undefined);
        private _firewallDeploymentModel?;
        get firewallDeploymentModel(): string;
        set firewallDeploymentModel(value: string);
        resetFirewallDeploymentModel(): void;
        get firewallDeploymentModelInput(): string | undefined;
    }
    interface PolicyOptionProperty {
        /**
        * network_acl_common_policy block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#network_acl_common_policy AwsFmsPolicy#network_acl_common_policy}
        */
        readonly networkAclCommonPolicy?: NetworkAclCommonPolicyProperty;
        /**
        * network_firewall_policy block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#network_firewall_policy AwsFmsPolicy#network_firewall_policy}
        */
        readonly networkFirewallPolicy?: NetworkFirewallPolicyProperty;
        /**
        * third_party_firewall_policy block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#third_party_firewall_policy AwsFmsPolicy#third_party_firewall_policy}
        */
        readonly thirdPartyFirewallPolicy?: ThirdPartyFirewallPolicyProperty;
    }
    class PolicyOptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PolicyOptionProperty | undefined;
        set internalValue(value: PolicyOptionProperty | undefined);
        private _networkAclCommonPolicy;
        get networkAclCommonPolicy(): NetworkAclCommonPolicyPropertyOutputReference;
        putNetworkAclCommonPolicy(value: NetworkAclCommonPolicyProperty): void;
        resetNetworkAclCommonPolicy(): void;
        get networkAclCommonPolicyInput(): NetworkAclCommonPolicyProperty | undefined;
        private _networkFirewallPolicy;
        get networkFirewallPolicy(): NetworkFirewallPolicyPropertyOutputReference;
        putNetworkFirewallPolicy(value: NetworkFirewallPolicyProperty): void;
        resetNetworkFirewallPolicy(): void;
        get networkFirewallPolicyInput(): NetworkFirewallPolicyProperty | undefined;
        private _thirdPartyFirewallPolicy;
        get thirdPartyFirewallPolicy(): ThirdPartyFirewallPolicyPropertyOutputReference;
        putThirdPartyFirewallPolicy(value: ThirdPartyFirewallPolicyProperty): void;
        resetThirdPartyFirewallPolicy(): void;
        get thirdPartyFirewallPolicyInput(): ThirdPartyFirewallPolicyProperty | undefined;
    }
    interface SecurityServicePolicyDataProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#managed_service_data AwsFmsPolicy#managed_service_data}
        */
        readonly managedServiceData?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#type AwsFmsPolicy#type}
        */
        readonly type: string;
        /**
        * policy_option block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_policy#policy_option AwsFmsPolicy#policy_option}
        */
        readonly policyOption?: PolicyOptionProperty;
    }
    class SecurityServicePolicyDataPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SecurityServicePolicyDataProperty | undefined;
        set internalValue(value: SecurityServicePolicyDataProperty | undefined);
        private _managedServiceData?;
        get managedServiceData(): string;
        set managedServiceData(value: string);
        resetManagedServiceData(): void;
        get managedServiceDataInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _policyOption;
        get policyOption(): PolicyOptionPropertyOutputReference;
        putPolicyOption(value: PolicyOptionProperty): void;
        resetPolicyOption(): void;
        get policyOptionInput(): PolicyOptionProperty | undefined;
    }
}
