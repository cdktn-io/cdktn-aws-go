import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsFmsAdminAccountConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_admin_account#account_id AwsFmsAdminAccount#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_admin_account#id AwsFmsAdminAccount#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_admin_account#timeouts AwsFmsAdminAccount#timeouts}
    */
    readonly timeouts?: AwsFmsAdminAccount.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_admin_account aws_fms_admin_account}
*/
export declare class AwsFmsAdminAccount extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_fms_admin_account";
    /**
    * Generates CDKTN code for importing a AwsFmsAdminAccount resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsFmsAdminAccount to import
    * @param importFromId The id of the existing AwsFmsAdminAccount that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_admin_account#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsFmsAdminAccount to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_admin_account aws_fms_admin_account} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsFmsAdminAccountConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AwsFmsAdminAccountConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _timeouts;
    get timeouts(): AwsFmsAdminAccount.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsFmsAdminAccount.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): AwsFmsAdminAccount.TimeoutsProperty | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsFmsAdminAccountTimeoutsPropertyToTerraform(struct?: AwsFmsAdminAccount.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsFmsAdminAccountTimeoutsPropertyToHclTerraform(struct?: AwsFmsAdminAccount.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsFmsAdminAccount {
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_admin_account#create AwsFmsAdminAccount#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fms_admin_account#delete AwsFmsAdminAccount#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
