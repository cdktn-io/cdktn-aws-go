import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsRelayConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_relay#name AwsRelay#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_relay#region AwsRelay#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_relay#server_name AwsRelay#server_name}
    */
    readonly serverName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_relay#server_port AwsRelay#server_port}
    */
    readonly serverPort: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_relay#tags AwsRelay#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * authentication block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_relay#authentication AwsRelay#authentication}
    */
    readonly authentication?: AwsRelay.AuthenticationProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_relay aws_mailmanager_relay}
*/
export declare class AwsRelay extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_mailmanager_relay";
    /**
    * Generates CDKTN code for importing a AwsRelay resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsRelay to import
    * @param importFromId The id of the existing AwsRelay that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_relay#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsRelay to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_relay aws_mailmanager_relay} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsRelayConfig
    */
    constructor(scope: Construct, id: string, config: AwsRelayConfig);
    get arn(): string;
    get createdTimestamp(): string;
    get id(): string;
    get lastModifiedTimestamp(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _serverName?;
    get serverName(): string;
    set serverName(value: string);
    get serverNameInput(): string | undefined;
    private _serverPort?;
    get serverPort(): number;
    set serverPort(value: number);
    get serverPortInput(): number | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _authentication;
    get authentication(): AwsRelay.AuthenticationPropertyList;
    putAuthentication(value: AwsRelay.AuthenticationProperty[] | cdktn.IResolvable): void;
    resetAuthentication(): void;
    get authenticationInput(): cdktn.IResolvable | AwsRelay.AuthenticationProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsRelayNoAuthenticationPropertyToTerraform(struct?: AwsRelay.NoAuthenticationProperty | cdktn.IResolvable): any;
export declare function awsRelayNoAuthenticationPropertyToHclTerraform(struct?: AwsRelay.NoAuthenticationProperty | cdktn.IResolvable): any;
export declare function awsRelayAuthenticationPropertyToTerraform(struct?: AwsRelay.AuthenticationProperty | cdktn.IResolvable): any;
export declare function awsRelayAuthenticationPropertyToHclTerraform(struct?: AwsRelay.AuthenticationProperty | cdktn.IResolvable): any;
export declare namespace AwsRelay {
    interface NoAuthenticationProperty {
    }
    class NoAuthenticationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NoAuthenticationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NoAuthenticationProperty | cdktn.IResolvable | undefined);
    }
    class NoAuthenticationPropertyList extends cdktn.ComplexList {
        internalValue?: NoAuthenticationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NoAuthenticationPropertyOutputReference;
    }
    interface AuthenticationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_relay#secret_arn AwsRelay#secret_arn}
        */
        readonly secretArn?: string;
        /**
        * no_authentication block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_relay#no_authentication AwsRelay#no_authentication}
        */
        readonly noAuthentication?: NoAuthenticationProperty[] | cdktn.IResolvable;
    }
    class AuthenticationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthenticationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AuthenticationProperty | cdktn.IResolvable | undefined);
        private _secretArn?;
        get secretArn(): string;
        set secretArn(value: string);
        resetSecretArn(): void;
        get secretArnInput(): string | undefined;
        private _noAuthentication;
        get noAuthentication(): NoAuthenticationPropertyList;
        putNoAuthentication(value: NoAuthenticationProperty[] | cdktn.IResolvable): void;
        resetNoAuthentication(): void;
        get noAuthenticationInput(): cdktn.IResolvable | NoAuthenticationProperty[] | undefined;
    }
    class AuthenticationPropertyList extends cdktn.ComplexList {
        internalValue?: AuthenticationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthenticationPropertyOutputReference;
    }
}
