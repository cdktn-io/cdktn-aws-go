import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsRuleSetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#name AwsRuleSet#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#region AwsRuleSet#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#tags AwsRuleSet#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#rule AwsRuleSet#rule}
    */
    readonly rule?: AwsRuleSet.RuleProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set aws_mailmanager_rule_set}
*/
export declare class AwsRuleSet extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_mailmanager_rule_set";
    /**
    * Generates CDKTN code for importing a AwsRuleSet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsRuleSet to import
    * @param importFromId The id of the existing AwsRuleSet that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsRuleSet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set aws_mailmanager_rule_set} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsRuleSetConfig
    */
    constructor(scope: Construct, id: string, config: AwsRuleSetConfig);
    get arn(): string;
    get createdDate(): string;
    get id(): string;
    get lastModificationDate(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _rule;
    get rule(): AwsRuleSet.RulePropertyList;
    putRule(value: AwsRuleSet.RuleProperty[] | cdktn.IResolvable): void;
    resetRule(): void;
    get ruleInput(): cdktn.IResolvable | AwsRuleSet.RuleProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsRuleSetAddHeaderPropertyToTerraform(struct?: AwsRuleSet.AddHeaderProperty | cdktn.IResolvable): any;
export declare function awsRuleSetAddHeaderPropertyToHclTerraform(struct?: AwsRuleSet.AddHeaderProperty | cdktn.IResolvable): any;
export declare function awsRuleSetArchivePropertyToTerraform(struct?: AwsRuleSet.ArchiveProperty | cdktn.IResolvable): any;
export declare function awsRuleSetArchivePropertyToHclTerraform(struct?: AwsRuleSet.ArchiveProperty | cdktn.IResolvable): any;
export declare function awsRuleSetBouncePropertyToTerraform(struct?: AwsRuleSet.BounceProperty | cdktn.IResolvable): any;
export declare function awsRuleSetBouncePropertyToHclTerraform(struct?: AwsRuleSet.BounceProperty | cdktn.IResolvable): any;
export declare function awsRuleSetDeliverToMailboxPropertyToTerraform(struct?: AwsRuleSet.DeliverToMailboxProperty | cdktn.IResolvable): any;
export declare function awsRuleSetDeliverToMailboxPropertyToHclTerraform(struct?: AwsRuleSet.DeliverToMailboxProperty | cdktn.IResolvable): any;
export declare function awsRuleSetDeliverToQBusinessPropertyToTerraform(struct?: AwsRuleSet.DeliverToQBusinessProperty | cdktn.IResolvable): any;
export declare function awsRuleSetDeliverToQBusinessPropertyToHclTerraform(struct?: AwsRuleSet.DeliverToQBusinessProperty | cdktn.IResolvable): any;
export declare function awsRuleSetDropPropertyToTerraform(struct?: AwsRuleSet.DropProperty | cdktn.IResolvable): any;
export declare function awsRuleSetDropPropertyToHclTerraform(struct?: AwsRuleSet.DropProperty | cdktn.IResolvable): any;
export declare function awsRuleSetInvokeLambdaPropertyToTerraform(struct?: AwsRuleSet.InvokeLambdaProperty | cdktn.IResolvable): any;
export declare function awsRuleSetInvokeLambdaPropertyToHclTerraform(struct?: AwsRuleSet.InvokeLambdaProperty | cdktn.IResolvable): any;
export declare function awsRuleSetPublishToSnsPropertyToTerraform(struct?: AwsRuleSet.PublishToSnsProperty | cdktn.IResolvable): any;
export declare function awsRuleSetPublishToSnsPropertyToHclTerraform(struct?: AwsRuleSet.PublishToSnsProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRelayPropertyToTerraform(struct?: AwsRuleSet.RelayProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRelayPropertyToHclTerraform(struct?: AwsRuleSet.RelayProperty | cdktn.IResolvable): any;
export declare function awsRuleSetReplaceRecipientPropertyToTerraform(struct?: AwsRuleSet.ReplaceRecipientProperty | cdktn.IResolvable): any;
export declare function awsRuleSetReplaceRecipientPropertyToHclTerraform(struct?: AwsRuleSet.ReplaceRecipientProperty | cdktn.IResolvable): any;
export declare function awsRuleSetSendPropertyToTerraform(struct?: AwsRuleSet.SendProperty | cdktn.IResolvable): any;
export declare function awsRuleSetSendPropertyToHclTerraform(struct?: AwsRuleSet.SendProperty | cdktn.IResolvable): any;
export declare function awsRuleSetWriteToS3PropertyToTerraform(struct?: AwsRuleSet.WriteToS3Property | cdktn.IResolvable): any;
export declare function awsRuleSetWriteToS3PropertyToHclTerraform(struct?: AwsRuleSet.WriteToS3Property | cdktn.IResolvable): any;
export declare function awsRuleSetActionPropertyToTerraform(struct?: AwsRuleSet.ActionProperty | cdktn.IResolvable): any;
export declare function awsRuleSetActionPropertyToHclTerraform(struct?: AwsRuleSet.ActionProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleConditionBooleanExpressionEvaluateAnalysisPropertyToTerraform(struct?: AwsRuleSet.RuleConditionBooleanExpressionEvaluateAnalysisProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleConditionBooleanExpressionEvaluateAnalysisPropertyToHclTerraform(struct?: AwsRuleSet.RuleConditionBooleanExpressionEvaluateAnalysisProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleConditionBooleanExpressionEvaluateIsInAddressListPropertyToTerraform(struct?: AwsRuleSet.RuleConditionBooleanExpressionEvaluateIsInAddressListProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleConditionBooleanExpressionEvaluateIsInAddressListPropertyToHclTerraform(struct?: AwsRuleSet.RuleConditionBooleanExpressionEvaluateIsInAddressListProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleConditionBooleanExpressionEvaluatePropertyToTerraform(struct?: AwsRuleSet.RuleConditionBooleanExpressionEvaluateProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleConditionBooleanExpressionEvaluatePropertyToHclTerraform(struct?: AwsRuleSet.RuleConditionBooleanExpressionEvaluateProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleConditionBooleanExpressionPropertyToTerraform(struct?: AwsRuleSet.RuleConditionBooleanExpressionProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleConditionBooleanExpressionPropertyToHclTerraform(struct?: AwsRuleSet.RuleConditionBooleanExpressionProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleConditionDmarcExpressionPropertyToTerraform(struct?: AwsRuleSet.RuleConditionDmarcExpressionProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleConditionDmarcExpressionPropertyToHclTerraform(struct?: AwsRuleSet.RuleConditionDmarcExpressionProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleConditionIpExpressionEvaluatePropertyToTerraform(struct?: AwsRuleSet.RuleConditionIpExpressionEvaluateProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleConditionIpExpressionEvaluatePropertyToHclTerraform(struct?: AwsRuleSet.RuleConditionIpExpressionEvaluateProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleConditionIpExpressionPropertyToTerraform(struct?: AwsRuleSet.RuleConditionIpExpressionProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleConditionIpExpressionPropertyToHclTerraform(struct?: AwsRuleSet.RuleConditionIpExpressionProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleConditionNumberExpressionEvaluatePropertyToTerraform(struct?: AwsRuleSet.RuleConditionNumberExpressionEvaluateProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleConditionNumberExpressionEvaluatePropertyToHclTerraform(struct?: AwsRuleSet.RuleConditionNumberExpressionEvaluateProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleConditionNumberExpressionPropertyToTerraform(struct?: AwsRuleSet.RuleConditionNumberExpressionProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleConditionNumberExpressionPropertyToHclTerraform(struct?: AwsRuleSet.RuleConditionNumberExpressionProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleConditionStringExpressionEvaluateAnalysisPropertyToTerraform(struct?: AwsRuleSet.RuleConditionStringExpressionEvaluateAnalysisProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleConditionStringExpressionEvaluateAnalysisPropertyToHclTerraform(struct?: AwsRuleSet.RuleConditionStringExpressionEvaluateAnalysisProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleConditionStringExpressionEvaluatePropertyToTerraform(struct?: AwsRuleSet.RuleConditionStringExpressionEvaluateProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleConditionStringExpressionEvaluatePropertyToHclTerraform(struct?: AwsRuleSet.RuleConditionStringExpressionEvaluateProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleConditionStringExpressionPropertyToTerraform(struct?: AwsRuleSet.RuleConditionStringExpressionProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleConditionStringExpressionPropertyToHclTerraform(struct?: AwsRuleSet.RuleConditionStringExpressionProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleConditionVerdictExpressionEvaluateAnalysisPropertyToTerraform(struct?: AwsRuleSet.RuleConditionVerdictExpressionEvaluateAnalysisProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleConditionVerdictExpressionEvaluateAnalysisPropertyToHclTerraform(struct?: AwsRuleSet.RuleConditionVerdictExpressionEvaluateAnalysisProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleConditionVerdictExpressionEvaluatePropertyToTerraform(struct?: AwsRuleSet.RuleConditionVerdictExpressionEvaluateProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleConditionVerdictExpressionEvaluatePropertyToHclTerraform(struct?: AwsRuleSet.RuleConditionVerdictExpressionEvaluateProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleConditionVerdictExpressionPropertyToTerraform(struct?: AwsRuleSet.RuleConditionVerdictExpressionProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleConditionVerdictExpressionPropertyToHclTerraform(struct?: AwsRuleSet.RuleConditionVerdictExpressionProperty | cdktn.IResolvable): any;
export declare function awsRuleSetConditionPropertyToTerraform(struct?: AwsRuleSet.ConditionProperty | cdktn.IResolvable): any;
export declare function awsRuleSetConditionPropertyToHclTerraform(struct?: AwsRuleSet.ConditionProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleUnlessBooleanExpressionEvaluateAnalysisPropertyToTerraform(struct?: AwsRuleSet.RuleUnlessBooleanExpressionEvaluateAnalysisProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleUnlessBooleanExpressionEvaluateAnalysisPropertyToHclTerraform(struct?: AwsRuleSet.RuleUnlessBooleanExpressionEvaluateAnalysisProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleUnlessBooleanExpressionEvaluateIsInAddressListPropertyToTerraform(struct?: AwsRuleSet.RuleUnlessBooleanExpressionEvaluateIsInAddressListProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleUnlessBooleanExpressionEvaluateIsInAddressListPropertyToHclTerraform(struct?: AwsRuleSet.RuleUnlessBooleanExpressionEvaluateIsInAddressListProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleUnlessBooleanExpressionEvaluatePropertyToTerraform(struct?: AwsRuleSet.RuleUnlessBooleanExpressionEvaluateProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleUnlessBooleanExpressionEvaluatePropertyToHclTerraform(struct?: AwsRuleSet.RuleUnlessBooleanExpressionEvaluateProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleUnlessBooleanExpressionPropertyToTerraform(struct?: AwsRuleSet.RuleUnlessBooleanExpressionProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleUnlessBooleanExpressionPropertyToHclTerraform(struct?: AwsRuleSet.RuleUnlessBooleanExpressionProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleUnlessDmarcExpressionPropertyToTerraform(struct?: AwsRuleSet.RuleUnlessDmarcExpressionProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleUnlessDmarcExpressionPropertyToHclTerraform(struct?: AwsRuleSet.RuleUnlessDmarcExpressionProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleUnlessIpExpressionEvaluatePropertyToTerraform(struct?: AwsRuleSet.RuleUnlessIpExpressionEvaluateProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleUnlessIpExpressionEvaluatePropertyToHclTerraform(struct?: AwsRuleSet.RuleUnlessIpExpressionEvaluateProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleUnlessIpExpressionPropertyToTerraform(struct?: AwsRuleSet.RuleUnlessIpExpressionProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleUnlessIpExpressionPropertyToHclTerraform(struct?: AwsRuleSet.RuleUnlessIpExpressionProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleUnlessNumberExpressionEvaluatePropertyToTerraform(struct?: AwsRuleSet.RuleUnlessNumberExpressionEvaluateProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleUnlessNumberExpressionEvaluatePropertyToHclTerraform(struct?: AwsRuleSet.RuleUnlessNumberExpressionEvaluateProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleUnlessNumberExpressionPropertyToTerraform(struct?: AwsRuleSet.RuleUnlessNumberExpressionProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleUnlessNumberExpressionPropertyToHclTerraform(struct?: AwsRuleSet.RuleUnlessNumberExpressionProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleUnlessStringExpressionEvaluateAnalysisPropertyToTerraform(struct?: AwsRuleSet.RuleUnlessStringExpressionEvaluateAnalysisProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleUnlessStringExpressionEvaluateAnalysisPropertyToHclTerraform(struct?: AwsRuleSet.RuleUnlessStringExpressionEvaluateAnalysisProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleUnlessStringExpressionEvaluatePropertyToTerraform(struct?: AwsRuleSet.RuleUnlessStringExpressionEvaluateProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleUnlessStringExpressionEvaluatePropertyToHclTerraform(struct?: AwsRuleSet.RuleUnlessStringExpressionEvaluateProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleUnlessStringExpressionPropertyToTerraform(struct?: AwsRuleSet.RuleUnlessStringExpressionProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleUnlessStringExpressionPropertyToHclTerraform(struct?: AwsRuleSet.RuleUnlessStringExpressionProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleUnlessVerdictExpressionEvaluateAnalysisPropertyToTerraform(struct?: AwsRuleSet.RuleUnlessVerdictExpressionEvaluateAnalysisProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleUnlessVerdictExpressionEvaluateAnalysisPropertyToHclTerraform(struct?: AwsRuleSet.RuleUnlessVerdictExpressionEvaluateAnalysisProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleUnlessVerdictExpressionEvaluatePropertyToTerraform(struct?: AwsRuleSet.RuleUnlessVerdictExpressionEvaluateProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleUnlessVerdictExpressionEvaluatePropertyToHclTerraform(struct?: AwsRuleSet.RuleUnlessVerdictExpressionEvaluateProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleUnlessVerdictExpressionPropertyToTerraform(struct?: AwsRuleSet.RuleUnlessVerdictExpressionProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRuleUnlessVerdictExpressionPropertyToHclTerraform(struct?: AwsRuleSet.RuleUnlessVerdictExpressionProperty | cdktn.IResolvable): any;
export declare function awsRuleSetUnlessPropertyToTerraform(struct?: AwsRuleSet.UnlessProperty | cdktn.IResolvable): any;
export declare function awsRuleSetUnlessPropertyToHclTerraform(struct?: AwsRuleSet.UnlessProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRulePropertyToTerraform(struct?: AwsRuleSet.RuleProperty | cdktn.IResolvable): any;
export declare function awsRuleSetRulePropertyToHclTerraform(struct?: AwsRuleSet.RuleProperty | cdktn.IResolvable): any;
export declare namespace AwsRuleSet {
    interface AddHeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#header_name AwsRuleSet#header_name}
        */
        readonly headerName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#header_value AwsRuleSet#header_value}
        */
        readonly headerValue: string;
    }
    class AddHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AddHeaderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AddHeaderProperty | cdktn.IResolvable | undefined);
        private _headerName?;
        get headerName(): string;
        set headerName(value: string);
        get headerNameInput(): string | undefined;
        private _headerValue?;
        get headerValue(): string;
        set headerValue(value: string);
        get headerValueInput(): string | undefined;
    }
    class AddHeaderPropertyList extends cdktn.ComplexList {
        internalValue?: AddHeaderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AddHeaderPropertyOutputReference;
    }
    interface ArchiveProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#action_failure_policy AwsRuleSet#action_failure_policy}
        */
        readonly actionFailurePolicy?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#target_archive AwsRuleSet#target_archive}
        */
        readonly targetArchive: string;
    }
    class ArchivePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ArchiveProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ArchiveProperty | cdktn.IResolvable | undefined);
        private _actionFailurePolicy?;
        get actionFailurePolicy(): string;
        set actionFailurePolicy(value: string);
        resetActionFailurePolicy(): void;
        get actionFailurePolicyInput(): string | undefined;
        private _targetArchive?;
        get targetArchive(): string;
        set targetArchive(value: string);
        get targetArchiveInput(): string | undefined;
    }
    class ArchivePropertyList extends cdktn.ComplexList {
        internalValue?: ArchiveProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ArchivePropertyOutputReference;
    }
    interface BounceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#action_failure_policy AwsRuleSet#action_failure_policy}
        */
        readonly actionFailurePolicy?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#diagnostic_message AwsRuleSet#diagnostic_message}
        */
        readonly diagnosticMessage: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#message AwsRuleSet#message}
        */
        readonly message?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#role_arn AwsRuleSet#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#sender AwsRuleSet#sender}
        */
        readonly sender: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#smtp_reply_code AwsRuleSet#smtp_reply_code}
        */
        readonly smtpReplyCode: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#status_code AwsRuleSet#status_code}
        */
        readonly statusCode: string;
    }
    class BouncePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BounceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: BounceProperty | cdktn.IResolvable | undefined);
        private _actionFailurePolicy?;
        get actionFailurePolicy(): string;
        set actionFailurePolicy(value: string);
        resetActionFailurePolicy(): void;
        get actionFailurePolicyInput(): string | undefined;
        private _diagnosticMessage?;
        get diagnosticMessage(): string;
        set diagnosticMessage(value: string);
        get diagnosticMessageInput(): string | undefined;
        private _message?;
        get message(): string;
        set message(value: string);
        resetMessage(): void;
        get messageInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _sender?;
        get sender(): string;
        set sender(value: string);
        get senderInput(): string | undefined;
        private _smtpReplyCode?;
        get smtpReplyCode(): string;
        set smtpReplyCode(value: string);
        get smtpReplyCodeInput(): string | undefined;
        private _statusCode?;
        get statusCode(): string;
        set statusCode(value: string);
        get statusCodeInput(): string | undefined;
    }
    class BouncePropertyList extends cdktn.ComplexList {
        internalValue?: BounceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BouncePropertyOutputReference;
    }
    interface DeliverToMailboxProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#action_failure_policy AwsRuleSet#action_failure_policy}
        */
        readonly actionFailurePolicy?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#mailbox_arn AwsRuleSet#mailbox_arn}
        */
        readonly mailboxArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#role_arn AwsRuleSet#role_arn}
        */
        readonly roleArn: string;
    }
    class DeliverToMailboxPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DeliverToMailboxProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DeliverToMailboxProperty | cdktn.IResolvable | undefined);
        private _actionFailurePolicy?;
        get actionFailurePolicy(): string;
        set actionFailurePolicy(value: string);
        resetActionFailurePolicy(): void;
        get actionFailurePolicyInput(): string | undefined;
        private _mailboxArn?;
        get mailboxArn(): string;
        set mailboxArn(value: string);
        get mailboxArnInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
    }
    class DeliverToMailboxPropertyList extends cdktn.ComplexList {
        internalValue?: DeliverToMailboxProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DeliverToMailboxPropertyOutputReference;
    }
    interface DeliverToQBusinessProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#action_failure_policy AwsRuleSet#action_failure_policy}
        */
        readonly actionFailurePolicy?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#application_id AwsRuleSet#application_id}
        */
        readonly applicationId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#index_id AwsRuleSet#index_id}
        */
        readonly indexId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#role_arn AwsRuleSet#role_arn}
        */
        readonly roleArn: string;
    }
    class DeliverToQBusinessPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DeliverToQBusinessProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DeliverToQBusinessProperty | cdktn.IResolvable | undefined);
        private _actionFailurePolicy?;
        get actionFailurePolicy(): string;
        set actionFailurePolicy(value: string);
        resetActionFailurePolicy(): void;
        get actionFailurePolicyInput(): string | undefined;
        private _applicationId?;
        get applicationId(): string;
        set applicationId(value: string);
        get applicationIdInput(): string | undefined;
        private _indexId?;
        get indexId(): string;
        set indexId(value: string);
        get indexIdInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
    }
    class DeliverToQBusinessPropertyList extends cdktn.ComplexList {
        internalValue?: DeliverToQBusinessProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DeliverToQBusinessPropertyOutputReference;
    }
    interface DropProperty {
    }
    class DropPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DropProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DropProperty | cdktn.IResolvable | undefined);
    }
    class DropPropertyList extends cdktn.ComplexList {
        internalValue?: DropProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DropPropertyOutputReference;
    }
    interface InvokeLambdaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#action_failure_policy AwsRuleSet#action_failure_policy}
        */
        readonly actionFailurePolicy?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#function_arn AwsRuleSet#function_arn}
        */
        readonly functionArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#invocation_type AwsRuleSet#invocation_type}
        */
        readonly invocationType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#retry_time_minutes AwsRuleSet#retry_time_minutes}
        */
        readonly retryTimeMinutes?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#role_arn AwsRuleSet#role_arn}
        */
        readonly roleArn: string;
    }
    class InvokeLambdaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InvokeLambdaProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InvokeLambdaProperty | cdktn.IResolvable | undefined);
        private _actionFailurePolicy?;
        get actionFailurePolicy(): string;
        set actionFailurePolicy(value: string);
        resetActionFailurePolicy(): void;
        get actionFailurePolicyInput(): string | undefined;
        private _functionArn?;
        get functionArn(): string;
        set functionArn(value: string);
        get functionArnInput(): string | undefined;
        private _invocationType?;
        get invocationType(): string;
        set invocationType(value: string);
        get invocationTypeInput(): string | undefined;
        private _retryTimeMinutes?;
        get retryTimeMinutes(): number;
        set retryTimeMinutes(value: number);
        resetRetryTimeMinutes(): void;
        get retryTimeMinutesInput(): number | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
    }
    class InvokeLambdaPropertyList extends cdktn.ComplexList {
        internalValue?: InvokeLambdaProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InvokeLambdaPropertyOutputReference;
    }
    interface PublishToSnsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#action_failure_policy AwsRuleSet#action_failure_policy}
        */
        readonly actionFailurePolicy?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#encoding AwsRuleSet#encoding}
        */
        readonly encoding?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#payload_type AwsRuleSet#payload_type}
        */
        readonly payloadType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#role_arn AwsRuleSet#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#topic_arn AwsRuleSet#topic_arn}
        */
        readonly topicArn: string;
    }
    class PublishToSnsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PublishToSnsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PublishToSnsProperty | cdktn.IResolvable | undefined);
        private _actionFailurePolicy?;
        get actionFailurePolicy(): string;
        set actionFailurePolicy(value: string);
        resetActionFailurePolicy(): void;
        get actionFailurePolicyInput(): string | undefined;
        private _encoding?;
        get encoding(): string;
        set encoding(value: string);
        resetEncoding(): void;
        get encodingInput(): string | undefined;
        private _payloadType?;
        get payloadType(): string;
        set payloadType(value: string);
        resetPayloadType(): void;
        get payloadTypeInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _topicArn?;
        get topicArn(): string;
        set topicArn(value: string);
        get topicArnInput(): string | undefined;
    }
    class PublishToSnsPropertyList extends cdktn.ComplexList {
        internalValue?: PublishToSnsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PublishToSnsPropertyOutputReference;
    }
    interface RelayProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#action_failure_policy AwsRuleSet#action_failure_policy}
        */
        readonly actionFailurePolicy?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#mail_from AwsRuleSet#mail_from}
        */
        readonly mailFrom?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#relay AwsRuleSet#relay}
        */
        readonly relay: string;
    }
    class RelayPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RelayProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RelayProperty | cdktn.IResolvable | undefined);
        private _actionFailurePolicy?;
        get actionFailurePolicy(): string;
        set actionFailurePolicy(value: string);
        resetActionFailurePolicy(): void;
        get actionFailurePolicyInput(): string | undefined;
        private _mailFrom?;
        get mailFrom(): string;
        set mailFrom(value: string);
        resetMailFrom(): void;
        get mailFromInput(): string | undefined;
        private _relay?;
        get relay(): string;
        set relay(value: string);
        get relayInput(): string | undefined;
    }
    class RelayPropertyList extends cdktn.ComplexList {
        internalValue?: RelayProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RelayPropertyOutputReference;
    }
    interface ReplaceRecipientProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#replace_with AwsRuleSet#replace_with}
        */
        readonly replaceWith?: string[];
    }
    class ReplaceRecipientPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReplaceRecipientProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ReplaceRecipientProperty | cdktn.IResolvable | undefined);
        private _replaceWith?;
        get replaceWith(): string[];
        set replaceWith(value: string[]);
        resetReplaceWith(): void;
        get replaceWithInput(): string[] | undefined;
    }
    class ReplaceRecipientPropertyList extends cdktn.ComplexList {
        internalValue?: ReplaceRecipientProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReplaceRecipientPropertyOutputReference;
    }
    interface SendProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#action_failure_policy AwsRuleSet#action_failure_policy}
        */
        readonly actionFailurePolicy?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#role_arn AwsRuleSet#role_arn}
        */
        readonly roleArn: string;
    }
    class SendPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SendProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SendProperty | cdktn.IResolvable | undefined);
        private _actionFailurePolicy?;
        get actionFailurePolicy(): string;
        set actionFailurePolicy(value: string);
        resetActionFailurePolicy(): void;
        get actionFailurePolicyInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
    }
    class SendPropertyList extends cdktn.ComplexList {
        internalValue?: SendProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SendPropertyOutputReference;
    }
    interface WriteToS3Property {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#action_failure_policy AwsRuleSet#action_failure_policy}
        */
        readonly actionFailurePolicy?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#role_arn AwsRuleSet#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#s3_bucket AwsRuleSet#s3_bucket}
        */
        readonly s3Bucket: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#s3_prefix AwsRuleSet#s3_prefix}
        */
        readonly s3Prefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#s3_sse_kms_key_id AwsRuleSet#s3_sse_kms_key_id}
        */
        readonly s3SseKmsKeyId?: string;
    }
    class WriteToS3PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WriteToS3Property | cdktn.IResolvable | undefined;
        set internalValue(value: WriteToS3Property | cdktn.IResolvable | undefined);
        private _actionFailurePolicy?;
        get actionFailurePolicy(): string;
        set actionFailurePolicy(value: string);
        resetActionFailurePolicy(): void;
        get actionFailurePolicyInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _s3Bucket?;
        get s3Bucket(): string;
        set s3Bucket(value: string);
        get s3BucketInput(): string | undefined;
        private _s3Prefix?;
        get s3Prefix(): string;
        set s3Prefix(value: string);
        resetS3Prefix(): void;
        get s3PrefixInput(): string | undefined;
        private _s3SseKmsKeyId?;
        get s3SseKmsKeyId(): string;
        set s3SseKmsKeyId(value: string);
        resetS3SseKmsKeyId(): void;
        get s3SseKmsKeyIdInput(): string | undefined;
    }
    class WriteToS3PropertyList extends cdktn.ComplexList {
        internalValue?: WriteToS3Property[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WriteToS3PropertyOutputReference;
    }
    interface ActionProperty {
        /**
        * add_header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#add_header AwsRuleSet#add_header}
        */
        readonly addHeader?: AddHeaderProperty[] | cdktn.IResolvable;
        /**
        * archive block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#archive AwsRuleSet#archive}
        */
        readonly archive?: ArchiveProperty[] | cdktn.IResolvable;
        /**
        * bounce block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#bounce AwsRuleSet#bounce}
        */
        readonly bounce?: BounceProperty[] | cdktn.IResolvable;
        /**
        * deliver_to_mailbox block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#deliver_to_mailbox AwsRuleSet#deliver_to_mailbox}
        */
        readonly deliverToMailbox?: DeliverToMailboxProperty[] | cdktn.IResolvable;
        /**
        * deliver_to_q_business block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#deliver_to_q_business AwsRuleSet#deliver_to_q_business}
        */
        readonly deliverToQBusiness?: DeliverToQBusinessProperty[] | cdktn.IResolvable;
        /**
        * drop block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#drop AwsRuleSet#drop}
        */
        readonly drop?: DropProperty[] | cdktn.IResolvable;
        /**
        * invoke_lambda block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#invoke_lambda AwsRuleSet#invoke_lambda}
        */
        readonly invokeLambda?: InvokeLambdaProperty[] | cdktn.IResolvable;
        /**
        * publish_to_sns block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#publish_to_sns AwsRuleSet#publish_to_sns}
        */
        readonly publishToSns?: PublishToSnsProperty[] | cdktn.IResolvable;
        /**
        * relay block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#relay AwsRuleSet#relay}
        */
        readonly relay?: RelayProperty[] | cdktn.IResolvable;
        /**
        * replace_recipient block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#replace_recipient AwsRuleSet#replace_recipient}
        */
        readonly replaceRecipient?: ReplaceRecipientProperty[] | cdktn.IResolvable;
        /**
        * send block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#send AwsRuleSet#send}
        */
        readonly send?: SendProperty[] | cdktn.IResolvable;
        /**
        * write_to_s3 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#write_to_s3 AwsRuleSet#write_to_s3}
        */
        readonly writeToS3?: WriteToS3Property[] | cdktn.IResolvable;
    }
    class ActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ActionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ActionProperty | cdktn.IResolvable | undefined);
        private _addHeader;
        get addHeader(): AddHeaderPropertyList;
        putAddHeader(value: AddHeaderProperty[] | cdktn.IResolvable): void;
        resetAddHeader(): void;
        get addHeaderInput(): cdktn.IResolvable | AddHeaderProperty[] | undefined;
        private _archive;
        get archive(): ArchivePropertyList;
        putArchive(value: ArchiveProperty[] | cdktn.IResolvable): void;
        resetArchive(): void;
        get archiveInput(): cdktn.IResolvable | ArchiveProperty[] | undefined;
        private _bounce;
        get bounce(): BouncePropertyList;
        putBounce(value: BounceProperty[] | cdktn.IResolvable): void;
        resetBounce(): void;
        get bounceInput(): cdktn.IResolvable | BounceProperty[] | undefined;
        private _deliverToMailbox;
        get deliverToMailbox(): DeliverToMailboxPropertyList;
        putDeliverToMailbox(value: DeliverToMailboxProperty[] | cdktn.IResolvable): void;
        resetDeliverToMailbox(): void;
        get deliverToMailboxInput(): cdktn.IResolvable | DeliverToMailboxProperty[] | undefined;
        private _deliverToQBusiness;
        get deliverToQBusiness(): DeliverToQBusinessPropertyList;
        putDeliverToQBusiness(value: DeliverToQBusinessProperty[] | cdktn.IResolvable): void;
        resetDeliverToQBusiness(): void;
        get deliverToQBusinessInput(): cdktn.IResolvable | DeliverToQBusinessProperty[] | undefined;
        private _drop;
        get drop(): DropPropertyList;
        putDrop(value: DropProperty[] | cdktn.IResolvable): void;
        resetDrop(): void;
        get dropInput(): cdktn.IResolvable | DropProperty[] | undefined;
        private _invokeLambda;
        get invokeLambda(): InvokeLambdaPropertyList;
        putInvokeLambda(value: InvokeLambdaProperty[] | cdktn.IResolvable): void;
        resetInvokeLambda(): void;
        get invokeLambdaInput(): cdktn.IResolvable | InvokeLambdaProperty[] | undefined;
        private _publishToSns;
        get publishToSns(): PublishToSnsPropertyList;
        putPublishToSns(value: PublishToSnsProperty[] | cdktn.IResolvable): void;
        resetPublishToSns(): void;
        get publishToSnsInput(): cdktn.IResolvable | PublishToSnsProperty[] | undefined;
        private _relay;
        get relay(): RelayPropertyList;
        putRelay(value: RelayProperty[] | cdktn.IResolvable): void;
        resetRelay(): void;
        get relayInput(): cdktn.IResolvable | RelayProperty[] | undefined;
        private _replaceRecipient;
        get replaceRecipient(): ReplaceRecipientPropertyList;
        putReplaceRecipient(value: ReplaceRecipientProperty[] | cdktn.IResolvable): void;
        resetReplaceRecipient(): void;
        get replaceRecipientInput(): cdktn.IResolvable | ReplaceRecipientProperty[] | undefined;
        private _send;
        get send(): SendPropertyList;
        putSend(value: SendProperty[] | cdktn.IResolvable): void;
        resetSend(): void;
        get sendInput(): cdktn.IResolvable | SendProperty[] | undefined;
        private _writeToS3;
        get writeToS3(): WriteToS3PropertyList;
        putWriteToS3(value: WriteToS3Property[] | cdktn.IResolvable): void;
        resetWriteToS3(): void;
        get writeToS3Input(): cdktn.IResolvable | WriteToS3Property[] | undefined;
    }
    class ActionPropertyList extends cdktn.ComplexList {
        internalValue?: ActionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ActionPropertyOutputReference;
    }
    interface RuleConditionBooleanExpressionEvaluateAnalysisProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#analyzer AwsRuleSet#analyzer}
        */
        readonly analyzer: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#result_field AwsRuleSet#result_field}
        */
        readonly resultField: string;
    }
    class RuleConditionBooleanExpressionEvaluateAnalysisPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleConditionBooleanExpressionEvaluateAnalysisProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleConditionBooleanExpressionEvaluateAnalysisProperty | cdktn.IResolvable | undefined);
        private _analyzer?;
        get analyzer(): string;
        set analyzer(value: string);
        get analyzerInput(): string | undefined;
        private _resultField?;
        get resultField(): string;
        set resultField(value: string);
        get resultFieldInput(): string | undefined;
    }
    class RuleConditionBooleanExpressionEvaluateAnalysisPropertyList extends cdktn.ComplexList {
        internalValue?: RuleConditionBooleanExpressionEvaluateAnalysisProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleConditionBooleanExpressionEvaluateAnalysisPropertyOutputReference;
    }
    interface RuleConditionBooleanExpressionEvaluateIsInAddressListProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#address_lists AwsRuleSet#address_lists}
        */
        readonly addressLists: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#attribute AwsRuleSet#attribute}
        */
        readonly attribute: string;
    }
    class RuleConditionBooleanExpressionEvaluateIsInAddressListPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleConditionBooleanExpressionEvaluateIsInAddressListProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleConditionBooleanExpressionEvaluateIsInAddressListProperty | cdktn.IResolvable | undefined);
        private _addressLists?;
        get addressLists(): string[];
        set addressLists(value: string[]);
        get addressListsInput(): string[] | undefined;
        private _attribute?;
        get attribute(): string;
        set attribute(value: string);
        get attributeInput(): string | undefined;
    }
    class RuleConditionBooleanExpressionEvaluateIsInAddressListPropertyList extends cdktn.ComplexList {
        internalValue?: RuleConditionBooleanExpressionEvaluateIsInAddressListProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleConditionBooleanExpressionEvaluateIsInAddressListPropertyOutputReference;
    }
    interface RuleConditionBooleanExpressionEvaluateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#attribute AwsRuleSet#attribute}
        */
        readonly attribute?: string;
        /**
        * analysis block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#analysis AwsRuleSet#analysis}
        */
        readonly analysis?: RuleConditionBooleanExpressionEvaluateAnalysisProperty[] | cdktn.IResolvable;
        /**
        * is_in_address_list block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#is_in_address_list AwsRuleSet#is_in_address_list}
        */
        readonly isInAddressList?: RuleConditionBooleanExpressionEvaluateIsInAddressListProperty[] | cdktn.IResolvable;
    }
    class RuleConditionBooleanExpressionEvaluatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleConditionBooleanExpressionEvaluateProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleConditionBooleanExpressionEvaluateProperty | cdktn.IResolvable | undefined);
        private _attribute?;
        get attribute(): string;
        set attribute(value: string);
        resetAttribute(): void;
        get attributeInput(): string | undefined;
        private _analysis;
        get analysis(): RuleConditionBooleanExpressionEvaluateAnalysisPropertyList;
        putAnalysis(value: RuleConditionBooleanExpressionEvaluateAnalysisProperty[] | cdktn.IResolvable): void;
        resetAnalysis(): void;
        get analysisInput(): cdktn.IResolvable | RuleConditionBooleanExpressionEvaluateAnalysisProperty[] | undefined;
        private _isInAddressList;
        get isInAddressList(): RuleConditionBooleanExpressionEvaluateIsInAddressListPropertyList;
        putIsInAddressList(value: RuleConditionBooleanExpressionEvaluateIsInAddressListProperty[] | cdktn.IResolvable): void;
        resetIsInAddressList(): void;
        get isInAddressListInput(): cdktn.IResolvable | RuleConditionBooleanExpressionEvaluateIsInAddressListProperty[] | undefined;
    }
    class RuleConditionBooleanExpressionEvaluatePropertyList extends cdktn.ComplexList {
        internalValue?: RuleConditionBooleanExpressionEvaluateProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleConditionBooleanExpressionEvaluatePropertyOutputReference;
    }
    interface RuleConditionBooleanExpressionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#operator AwsRuleSet#operator}
        */
        readonly operator: string;
        /**
        * evaluate block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#evaluate AwsRuleSet#evaluate}
        */
        readonly evaluate?: RuleConditionBooleanExpressionEvaluateProperty[] | cdktn.IResolvable;
    }
    class RuleConditionBooleanExpressionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleConditionBooleanExpressionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleConditionBooleanExpressionProperty | cdktn.IResolvable | undefined);
        private _operator?;
        get operator(): string;
        set operator(value: string);
        get operatorInput(): string | undefined;
        private _evaluate;
        get evaluate(): RuleConditionBooleanExpressionEvaluatePropertyList;
        putEvaluate(value: RuleConditionBooleanExpressionEvaluateProperty[] | cdktn.IResolvable): void;
        resetEvaluate(): void;
        get evaluateInput(): cdktn.IResolvable | RuleConditionBooleanExpressionEvaluateProperty[] | undefined;
    }
    class RuleConditionBooleanExpressionPropertyList extends cdktn.ComplexList {
        internalValue?: RuleConditionBooleanExpressionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleConditionBooleanExpressionPropertyOutputReference;
    }
    interface RuleConditionDmarcExpressionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#operator AwsRuleSet#operator}
        */
        readonly operator: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#values AwsRuleSet#values}
        */
        readonly values: string[];
    }
    class RuleConditionDmarcExpressionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleConditionDmarcExpressionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleConditionDmarcExpressionProperty | cdktn.IResolvable | undefined);
        private _operator?;
        get operator(): string;
        set operator(value: string);
        get operatorInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class RuleConditionDmarcExpressionPropertyList extends cdktn.ComplexList {
        internalValue?: RuleConditionDmarcExpressionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleConditionDmarcExpressionPropertyOutputReference;
    }
    interface RuleConditionIpExpressionEvaluateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#attribute AwsRuleSet#attribute}
        */
        readonly attribute: string;
    }
    class RuleConditionIpExpressionEvaluatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleConditionIpExpressionEvaluateProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleConditionIpExpressionEvaluateProperty | cdktn.IResolvable | undefined);
        private _attribute?;
        get attribute(): string;
        set attribute(value: string);
        get attributeInput(): string | undefined;
    }
    class RuleConditionIpExpressionEvaluatePropertyList extends cdktn.ComplexList {
        internalValue?: RuleConditionIpExpressionEvaluateProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleConditionIpExpressionEvaluatePropertyOutputReference;
    }
    interface RuleConditionIpExpressionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#operator AwsRuleSet#operator}
        */
        readonly operator: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#values AwsRuleSet#values}
        */
        readonly values: string[];
        /**
        * evaluate block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#evaluate AwsRuleSet#evaluate}
        */
        readonly evaluate?: RuleConditionIpExpressionEvaluateProperty[] | cdktn.IResolvable;
    }
    class RuleConditionIpExpressionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleConditionIpExpressionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleConditionIpExpressionProperty | cdktn.IResolvable | undefined);
        private _operator?;
        get operator(): string;
        set operator(value: string);
        get operatorInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
        private _evaluate;
        get evaluate(): RuleConditionIpExpressionEvaluatePropertyList;
        putEvaluate(value: RuleConditionIpExpressionEvaluateProperty[] | cdktn.IResolvable): void;
        resetEvaluate(): void;
        get evaluateInput(): cdktn.IResolvable | RuleConditionIpExpressionEvaluateProperty[] | undefined;
    }
    class RuleConditionIpExpressionPropertyList extends cdktn.ComplexList {
        internalValue?: RuleConditionIpExpressionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleConditionIpExpressionPropertyOutputReference;
    }
    interface RuleConditionNumberExpressionEvaluateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#attribute AwsRuleSet#attribute}
        */
        readonly attribute: string;
    }
    class RuleConditionNumberExpressionEvaluatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleConditionNumberExpressionEvaluateProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleConditionNumberExpressionEvaluateProperty | cdktn.IResolvable | undefined);
        private _attribute?;
        get attribute(): string;
        set attribute(value: string);
        get attributeInput(): string | undefined;
    }
    class RuleConditionNumberExpressionEvaluatePropertyList extends cdktn.ComplexList {
        internalValue?: RuleConditionNumberExpressionEvaluateProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleConditionNumberExpressionEvaluatePropertyOutputReference;
    }
    interface RuleConditionNumberExpressionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#operator AwsRuleSet#operator}
        */
        readonly operator: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#value AwsRuleSet#value}
        */
        readonly value: number;
        /**
        * evaluate block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#evaluate AwsRuleSet#evaluate}
        */
        readonly evaluate?: RuleConditionNumberExpressionEvaluateProperty[] | cdktn.IResolvable;
    }
    class RuleConditionNumberExpressionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleConditionNumberExpressionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleConditionNumberExpressionProperty | cdktn.IResolvable | undefined);
        private _operator?;
        get operator(): string;
        set operator(value: string);
        get operatorInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
        private _evaluate;
        get evaluate(): RuleConditionNumberExpressionEvaluatePropertyList;
        putEvaluate(value: RuleConditionNumberExpressionEvaluateProperty[] | cdktn.IResolvable): void;
        resetEvaluate(): void;
        get evaluateInput(): cdktn.IResolvable | RuleConditionNumberExpressionEvaluateProperty[] | undefined;
    }
    class RuleConditionNumberExpressionPropertyList extends cdktn.ComplexList {
        internalValue?: RuleConditionNumberExpressionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleConditionNumberExpressionPropertyOutputReference;
    }
    interface RuleConditionStringExpressionEvaluateAnalysisProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#analyzer AwsRuleSet#analyzer}
        */
        readonly analyzer: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#result_field AwsRuleSet#result_field}
        */
        readonly resultField: string;
    }
    class RuleConditionStringExpressionEvaluateAnalysisPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleConditionStringExpressionEvaluateAnalysisProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleConditionStringExpressionEvaluateAnalysisProperty | cdktn.IResolvable | undefined);
        private _analyzer?;
        get analyzer(): string;
        set analyzer(value: string);
        get analyzerInput(): string | undefined;
        private _resultField?;
        get resultField(): string;
        set resultField(value: string);
        get resultFieldInput(): string | undefined;
    }
    class RuleConditionStringExpressionEvaluateAnalysisPropertyList extends cdktn.ComplexList {
        internalValue?: RuleConditionStringExpressionEvaluateAnalysisProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleConditionStringExpressionEvaluateAnalysisPropertyOutputReference;
    }
    interface RuleConditionStringExpressionEvaluateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#attribute AwsRuleSet#attribute}
        */
        readonly attribute?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#client_certificate_attribute AwsRuleSet#client_certificate_attribute}
        */
        readonly clientCertificateAttribute?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#mime_header_attribute AwsRuleSet#mime_header_attribute}
        */
        readonly mimeHeaderAttribute?: string;
        /**
        * analysis block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#analysis AwsRuleSet#analysis}
        */
        readonly analysis?: RuleConditionStringExpressionEvaluateAnalysisProperty[] | cdktn.IResolvable;
    }
    class RuleConditionStringExpressionEvaluatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleConditionStringExpressionEvaluateProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleConditionStringExpressionEvaluateProperty | cdktn.IResolvable | undefined);
        private _attribute?;
        get attribute(): string;
        set attribute(value: string);
        resetAttribute(): void;
        get attributeInput(): string | undefined;
        private _clientCertificateAttribute?;
        get clientCertificateAttribute(): string;
        set clientCertificateAttribute(value: string);
        resetClientCertificateAttribute(): void;
        get clientCertificateAttributeInput(): string | undefined;
        private _mimeHeaderAttribute?;
        get mimeHeaderAttribute(): string;
        set mimeHeaderAttribute(value: string);
        resetMimeHeaderAttribute(): void;
        get mimeHeaderAttributeInput(): string | undefined;
        private _analysis;
        get analysis(): RuleConditionStringExpressionEvaluateAnalysisPropertyList;
        putAnalysis(value: RuleConditionStringExpressionEvaluateAnalysisProperty[] | cdktn.IResolvable): void;
        resetAnalysis(): void;
        get analysisInput(): cdktn.IResolvable | RuleConditionStringExpressionEvaluateAnalysisProperty[] | undefined;
    }
    class RuleConditionStringExpressionEvaluatePropertyList extends cdktn.ComplexList {
        internalValue?: RuleConditionStringExpressionEvaluateProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleConditionStringExpressionEvaluatePropertyOutputReference;
    }
    interface RuleConditionStringExpressionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#operator AwsRuleSet#operator}
        */
        readonly operator: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#values AwsRuleSet#values}
        */
        readonly values: string[];
        /**
        * evaluate block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#evaluate AwsRuleSet#evaluate}
        */
        readonly evaluate?: RuleConditionStringExpressionEvaluateProperty[] | cdktn.IResolvable;
    }
    class RuleConditionStringExpressionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleConditionStringExpressionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleConditionStringExpressionProperty | cdktn.IResolvable | undefined);
        private _operator?;
        get operator(): string;
        set operator(value: string);
        get operatorInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
        private _evaluate;
        get evaluate(): RuleConditionStringExpressionEvaluatePropertyList;
        putEvaluate(value: RuleConditionStringExpressionEvaluateProperty[] | cdktn.IResolvable): void;
        resetEvaluate(): void;
        get evaluateInput(): cdktn.IResolvable | RuleConditionStringExpressionEvaluateProperty[] | undefined;
    }
    class RuleConditionStringExpressionPropertyList extends cdktn.ComplexList {
        internalValue?: RuleConditionStringExpressionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleConditionStringExpressionPropertyOutputReference;
    }
    interface RuleConditionVerdictExpressionEvaluateAnalysisProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#analyzer AwsRuleSet#analyzer}
        */
        readonly analyzer: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#result_field AwsRuleSet#result_field}
        */
        readonly resultField: string;
    }
    class RuleConditionVerdictExpressionEvaluateAnalysisPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleConditionVerdictExpressionEvaluateAnalysisProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleConditionVerdictExpressionEvaluateAnalysisProperty | cdktn.IResolvable | undefined);
        private _analyzer?;
        get analyzer(): string;
        set analyzer(value: string);
        get analyzerInput(): string | undefined;
        private _resultField?;
        get resultField(): string;
        set resultField(value: string);
        get resultFieldInput(): string | undefined;
    }
    class RuleConditionVerdictExpressionEvaluateAnalysisPropertyList extends cdktn.ComplexList {
        internalValue?: RuleConditionVerdictExpressionEvaluateAnalysisProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleConditionVerdictExpressionEvaluateAnalysisPropertyOutputReference;
    }
    interface RuleConditionVerdictExpressionEvaluateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#attribute AwsRuleSet#attribute}
        */
        readonly attribute?: string;
        /**
        * analysis block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#analysis AwsRuleSet#analysis}
        */
        readonly analysis?: RuleConditionVerdictExpressionEvaluateAnalysisProperty[] | cdktn.IResolvable;
    }
    class RuleConditionVerdictExpressionEvaluatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleConditionVerdictExpressionEvaluateProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleConditionVerdictExpressionEvaluateProperty | cdktn.IResolvable | undefined);
        private _attribute?;
        get attribute(): string;
        set attribute(value: string);
        resetAttribute(): void;
        get attributeInput(): string | undefined;
        private _analysis;
        get analysis(): RuleConditionVerdictExpressionEvaluateAnalysisPropertyList;
        putAnalysis(value: RuleConditionVerdictExpressionEvaluateAnalysisProperty[] | cdktn.IResolvable): void;
        resetAnalysis(): void;
        get analysisInput(): cdktn.IResolvable | RuleConditionVerdictExpressionEvaluateAnalysisProperty[] | undefined;
    }
    class RuleConditionVerdictExpressionEvaluatePropertyList extends cdktn.ComplexList {
        internalValue?: RuleConditionVerdictExpressionEvaluateProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleConditionVerdictExpressionEvaluatePropertyOutputReference;
    }
    interface RuleConditionVerdictExpressionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#operator AwsRuleSet#operator}
        */
        readonly operator: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#values AwsRuleSet#values}
        */
        readonly values: string[];
        /**
        * evaluate block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#evaluate AwsRuleSet#evaluate}
        */
        readonly evaluate?: RuleConditionVerdictExpressionEvaluateProperty[] | cdktn.IResolvable;
    }
    class RuleConditionVerdictExpressionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleConditionVerdictExpressionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleConditionVerdictExpressionProperty | cdktn.IResolvable | undefined);
        private _operator?;
        get operator(): string;
        set operator(value: string);
        get operatorInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
        private _evaluate;
        get evaluate(): RuleConditionVerdictExpressionEvaluatePropertyList;
        putEvaluate(value: RuleConditionVerdictExpressionEvaluateProperty[] | cdktn.IResolvable): void;
        resetEvaluate(): void;
        get evaluateInput(): cdktn.IResolvable | RuleConditionVerdictExpressionEvaluateProperty[] | undefined;
    }
    class RuleConditionVerdictExpressionPropertyList extends cdktn.ComplexList {
        internalValue?: RuleConditionVerdictExpressionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleConditionVerdictExpressionPropertyOutputReference;
    }
    interface ConditionProperty {
        /**
        * boolean_expression block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#boolean_expression AwsRuleSet#boolean_expression}
        */
        readonly booleanExpression?: RuleConditionBooleanExpressionProperty[] | cdktn.IResolvable;
        /**
        * dmarc_expression block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#dmarc_expression AwsRuleSet#dmarc_expression}
        */
        readonly dmarcExpression?: RuleConditionDmarcExpressionProperty[] | cdktn.IResolvable;
        /**
        * ip_expression block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#ip_expression AwsRuleSet#ip_expression}
        */
        readonly ipExpression?: RuleConditionIpExpressionProperty[] | cdktn.IResolvable;
        /**
        * number_expression block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#number_expression AwsRuleSet#number_expression}
        */
        readonly numberExpression?: RuleConditionNumberExpressionProperty[] | cdktn.IResolvable;
        /**
        * string_expression block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#string_expression AwsRuleSet#string_expression}
        */
        readonly stringExpression?: RuleConditionStringExpressionProperty[] | cdktn.IResolvable;
        /**
        * verdict_expression block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#verdict_expression AwsRuleSet#verdict_expression}
        */
        readonly verdictExpression?: RuleConditionVerdictExpressionProperty[] | cdktn.IResolvable;
    }
    class ConditionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConditionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConditionProperty | cdktn.IResolvable | undefined);
        private _booleanExpression;
        get booleanExpression(): RuleConditionBooleanExpressionPropertyList;
        putBooleanExpression(value: RuleConditionBooleanExpressionProperty[] | cdktn.IResolvable): void;
        resetBooleanExpression(): void;
        get booleanExpressionInput(): cdktn.IResolvable | RuleConditionBooleanExpressionProperty[] | undefined;
        private _dmarcExpression;
        get dmarcExpression(): RuleConditionDmarcExpressionPropertyList;
        putDmarcExpression(value: RuleConditionDmarcExpressionProperty[] | cdktn.IResolvable): void;
        resetDmarcExpression(): void;
        get dmarcExpressionInput(): cdktn.IResolvable | RuleConditionDmarcExpressionProperty[] | undefined;
        private _ipExpression;
        get ipExpression(): RuleConditionIpExpressionPropertyList;
        putIpExpression(value: RuleConditionIpExpressionProperty[] | cdktn.IResolvable): void;
        resetIpExpression(): void;
        get ipExpressionInput(): cdktn.IResolvable | RuleConditionIpExpressionProperty[] | undefined;
        private _numberExpression;
        get numberExpression(): RuleConditionNumberExpressionPropertyList;
        putNumberExpression(value: RuleConditionNumberExpressionProperty[] | cdktn.IResolvable): void;
        resetNumberExpression(): void;
        get numberExpressionInput(): cdktn.IResolvable | RuleConditionNumberExpressionProperty[] | undefined;
        private _stringExpression;
        get stringExpression(): RuleConditionStringExpressionPropertyList;
        putStringExpression(value: RuleConditionStringExpressionProperty[] | cdktn.IResolvable): void;
        resetStringExpression(): void;
        get stringExpressionInput(): cdktn.IResolvable | RuleConditionStringExpressionProperty[] | undefined;
        private _verdictExpression;
        get verdictExpression(): RuleConditionVerdictExpressionPropertyList;
        putVerdictExpression(value: RuleConditionVerdictExpressionProperty[] | cdktn.IResolvable): void;
        resetVerdictExpression(): void;
        get verdictExpressionInput(): cdktn.IResolvable | RuleConditionVerdictExpressionProperty[] | undefined;
    }
    class ConditionPropertyList extends cdktn.ComplexList {
        internalValue?: ConditionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConditionPropertyOutputReference;
    }
    interface RuleUnlessBooleanExpressionEvaluateAnalysisProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#analyzer AwsRuleSet#analyzer}
        */
        readonly analyzer: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#result_field AwsRuleSet#result_field}
        */
        readonly resultField: string;
    }
    class RuleUnlessBooleanExpressionEvaluateAnalysisPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleUnlessBooleanExpressionEvaluateAnalysisProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleUnlessBooleanExpressionEvaluateAnalysisProperty | cdktn.IResolvable | undefined);
        private _analyzer?;
        get analyzer(): string;
        set analyzer(value: string);
        get analyzerInput(): string | undefined;
        private _resultField?;
        get resultField(): string;
        set resultField(value: string);
        get resultFieldInput(): string | undefined;
    }
    class RuleUnlessBooleanExpressionEvaluateAnalysisPropertyList extends cdktn.ComplexList {
        internalValue?: RuleUnlessBooleanExpressionEvaluateAnalysisProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleUnlessBooleanExpressionEvaluateAnalysisPropertyOutputReference;
    }
    interface RuleUnlessBooleanExpressionEvaluateIsInAddressListProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#address_lists AwsRuleSet#address_lists}
        */
        readonly addressLists: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#attribute AwsRuleSet#attribute}
        */
        readonly attribute: string;
    }
    class RuleUnlessBooleanExpressionEvaluateIsInAddressListPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleUnlessBooleanExpressionEvaluateIsInAddressListProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleUnlessBooleanExpressionEvaluateIsInAddressListProperty | cdktn.IResolvable | undefined);
        private _addressLists?;
        get addressLists(): string[];
        set addressLists(value: string[]);
        get addressListsInput(): string[] | undefined;
        private _attribute?;
        get attribute(): string;
        set attribute(value: string);
        get attributeInput(): string | undefined;
    }
    class RuleUnlessBooleanExpressionEvaluateIsInAddressListPropertyList extends cdktn.ComplexList {
        internalValue?: RuleUnlessBooleanExpressionEvaluateIsInAddressListProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleUnlessBooleanExpressionEvaluateIsInAddressListPropertyOutputReference;
    }
    interface RuleUnlessBooleanExpressionEvaluateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#attribute AwsRuleSet#attribute}
        */
        readonly attribute?: string;
        /**
        * analysis block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#analysis AwsRuleSet#analysis}
        */
        readonly analysis?: RuleUnlessBooleanExpressionEvaluateAnalysisProperty[] | cdktn.IResolvable;
        /**
        * is_in_address_list block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#is_in_address_list AwsRuleSet#is_in_address_list}
        */
        readonly isInAddressList?: RuleUnlessBooleanExpressionEvaluateIsInAddressListProperty[] | cdktn.IResolvable;
    }
    class RuleUnlessBooleanExpressionEvaluatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleUnlessBooleanExpressionEvaluateProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleUnlessBooleanExpressionEvaluateProperty | cdktn.IResolvable | undefined);
        private _attribute?;
        get attribute(): string;
        set attribute(value: string);
        resetAttribute(): void;
        get attributeInput(): string | undefined;
        private _analysis;
        get analysis(): RuleUnlessBooleanExpressionEvaluateAnalysisPropertyList;
        putAnalysis(value: RuleUnlessBooleanExpressionEvaluateAnalysisProperty[] | cdktn.IResolvable): void;
        resetAnalysis(): void;
        get analysisInput(): cdktn.IResolvable | RuleUnlessBooleanExpressionEvaluateAnalysisProperty[] | undefined;
        private _isInAddressList;
        get isInAddressList(): RuleUnlessBooleanExpressionEvaluateIsInAddressListPropertyList;
        putIsInAddressList(value: RuleUnlessBooleanExpressionEvaluateIsInAddressListProperty[] | cdktn.IResolvable): void;
        resetIsInAddressList(): void;
        get isInAddressListInput(): cdktn.IResolvable | RuleUnlessBooleanExpressionEvaluateIsInAddressListProperty[] | undefined;
    }
    class RuleUnlessBooleanExpressionEvaluatePropertyList extends cdktn.ComplexList {
        internalValue?: RuleUnlessBooleanExpressionEvaluateProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleUnlessBooleanExpressionEvaluatePropertyOutputReference;
    }
    interface RuleUnlessBooleanExpressionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#operator AwsRuleSet#operator}
        */
        readonly operator: string;
        /**
        * evaluate block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#evaluate AwsRuleSet#evaluate}
        */
        readonly evaluate?: RuleUnlessBooleanExpressionEvaluateProperty[] | cdktn.IResolvable;
    }
    class RuleUnlessBooleanExpressionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleUnlessBooleanExpressionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleUnlessBooleanExpressionProperty | cdktn.IResolvable | undefined);
        private _operator?;
        get operator(): string;
        set operator(value: string);
        get operatorInput(): string | undefined;
        private _evaluate;
        get evaluate(): RuleUnlessBooleanExpressionEvaluatePropertyList;
        putEvaluate(value: RuleUnlessBooleanExpressionEvaluateProperty[] | cdktn.IResolvable): void;
        resetEvaluate(): void;
        get evaluateInput(): cdktn.IResolvable | RuleUnlessBooleanExpressionEvaluateProperty[] | undefined;
    }
    class RuleUnlessBooleanExpressionPropertyList extends cdktn.ComplexList {
        internalValue?: RuleUnlessBooleanExpressionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleUnlessBooleanExpressionPropertyOutputReference;
    }
    interface RuleUnlessDmarcExpressionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#operator AwsRuleSet#operator}
        */
        readonly operator: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#values AwsRuleSet#values}
        */
        readonly values: string[];
    }
    class RuleUnlessDmarcExpressionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleUnlessDmarcExpressionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleUnlessDmarcExpressionProperty | cdktn.IResolvable | undefined);
        private _operator?;
        get operator(): string;
        set operator(value: string);
        get operatorInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class RuleUnlessDmarcExpressionPropertyList extends cdktn.ComplexList {
        internalValue?: RuleUnlessDmarcExpressionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleUnlessDmarcExpressionPropertyOutputReference;
    }
    interface RuleUnlessIpExpressionEvaluateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#attribute AwsRuleSet#attribute}
        */
        readonly attribute: string;
    }
    class RuleUnlessIpExpressionEvaluatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleUnlessIpExpressionEvaluateProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleUnlessIpExpressionEvaluateProperty | cdktn.IResolvable | undefined);
        private _attribute?;
        get attribute(): string;
        set attribute(value: string);
        get attributeInput(): string | undefined;
    }
    class RuleUnlessIpExpressionEvaluatePropertyList extends cdktn.ComplexList {
        internalValue?: RuleUnlessIpExpressionEvaluateProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleUnlessIpExpressionEvaluatePropertyOutputReference;
    }
    interface RuleUnlessIpExpressionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#operator AwsRuleSet#operator}
        */
        readonly operator: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#values AwsRuleSet#values}
        */
        readonly values: string[];
        /**
        * evaluate block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#evaluate AwsRuleSet#evaluate}
        */
        readonly evaluate?: RuleUnlessIpExpressionEvaluateProperty[] | cdktn.IResolvable;
    }
    class RuleUnlessIpExpressionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleUnlessIpExpressionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleUnlessIpExpressionProperty | cdktn.IResolvable | undefined);
        private _operator?;
        get operator(): string;
        set operator(value: string);
        get operatorInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
        private _evaluate;
        get evaluate(): RuleUnlessIpExpressionEvaluatePropertyList;
        putEvaluate(value: RuleUnlessIpExpressionEvaluateProperty[] | cdktn.IResolvable): void;
        resetEvaluate(): void;
        get evaluateInput(): cdktn.IResolvable | RuleUnlessIpExpressionEvaluateProperty[] | undefined;
    }
    class RuleUnlessIpExpressionPropertyList extends cdktn.ComplexList {
        internalValue?: RuleUnlessIpExpressionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleUnlessIpExpressionPropertyOutputReference;
    }
    interface RuleUnlessNumberExpressionEvaluateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#attribute AwsRuleSet#attribute}
        */
        readonly attribute: string;
    }
    class RuleUnlessNumberExpressionEvaluatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleUnlessNumberExpressionEvaluateProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleUnlessNumberExpressionEvaluateProperty | cdktn.IResolvable | undefined);
        private _attribute?;
        get attribute(): string;
        set attribute(value: string);
        get attributeInput(): string | undefined;
    }
    class RuleUnlessNumberExpressionEvaluatePropertyList extends cdktn.ComplexList {
        internalValue?: RuleUnlessNumberExpressionEvaluateProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleUnlessNumberExpressionEvaluatePropertyOutputReference;
    }
    interface RuleUnlessNumberExpressionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#operator AwsRuleSet#operator}
        */
        readonly operator: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#value AwsRuleSet#value}
        */
        readonly value: number;
        /**
        * evaluate block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#evaluate AwsRuleSet#evaluate}
        */
        readonly evaluate?: RuleUnlessNumberExpressionEvaluateProperty[] | cdktn.IResolvable;
    }
    class RuleUnlessNumberExpressionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleUnlessNumberExpressionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleUnlessNumberExpressionProperty | cdktn.IResolvable | undefined);
        private _operator?;
        get operator(): string;
        set operator(value: string);
        get operatorInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
        private _evaluate;
        get evaluate(): RuleUnlessNumberExpressionEvaluatePropertyList;
        putEvaluate(value: RuleUnlessNumberExpressionEvaluateProperty[] | cdktn.IResolvable): void;
        resetEvaluate(): void;
        get evaluateInput(): cdktn.IResolvable | RuleUnlessNumberExpressionEvaluateProperty[] | undefined;
    }
    class RuleUnlessNumberExpressionPropertyList extends cdktn.ComplexList {
        internalValue?: RuleUnlessNumberExpressionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleUnlessNumberExpressionPropertyOutputReference;
    }
    interface RuleUnlessStringExpressionEvaluateAnalysisProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#analyzer AwsRuleSet#analyzer}
        */
        readonly analyzer: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#result_field AwsRuleSet#result_field}
        */
        readonly resultField: string;
    }
    class RuleUnlessStringExpressionEvaluateAnalysisPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleUnlessStringExpressionEvaluateAnalysisProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleUnlessStringExpressionEvaluateAnalysisProperty | cdktn.IResolvable | undefined);
        private _analyzer?;
        get analyzer(): string;
        set analyzer(value: string);
        get analyzerInput(): string | undefined;
        private _resultField?;
        get resultField(): string;
        set resultField(value: string);
        get resultFieldInput(): string | undefined;
    }
    class RuleUnlessStringExpressionEvaluateAnalysisPropertyList extends cdktn.ComplexList {
        internalValue?: RuleUnlessStringExpressionEvaluateAnalysisProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleUnlessStringExpressionEvaluateAnalysisPropertyOutputReference;
    }
    interface RuleUnlessStringExpressionEvaluateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#attribute AwsRuleSet#attribute}
        */
        readonly attribute?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#client_certificate_attribute AwsRuleSet#client_certificate_attribute}
        */
        readonly clientCertificateAttribute?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#mime_header_attribute AwsRuleSet#mime_header_attribute}
        */
        readonly mimeHeaderAttribute?: string;
        /**
        * analysis block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#analysis AwsRuleSet#analysis}
        */
        readonly analysis?: RuleUnlessStringExpressionEvaluateAnalysisProperty[] | cdktn.IResolvable;
    }
    class RuleUnlessStringExpressionEvaluatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleUnlessStringExpressionEvaluateProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleUnlessStringExpressionEvaluateProperty | cdktn.IResolvable | undefined);
        private _attribute?;
        get attribute(): string;
        set attribute(value: string);
        resetAttribute(): void;
        get attributeInput(): string | undefined;
        private _clientCertificateAttribute?;
        get clientCertificateAttribute(): string;
        set clientCertificateAttribute(value: string);
        resetClientCertificateAttribute(): void;
        get clientCertificateAttributeInput(): string | undefined;
        private _mimeHeaderAttribute?;
        get mimeHeaderAttribute(): string;
        set mimeHeaderAttribute(value: string);
        resetMimeHeaderAttribute(): void;
        get mimeHeaderAttributeInput(): string | undefined;
        private _analysis;
        get analysis(): RuleUnlessStringExpressionEvaluateAnalysisPropertyList;
        putAnalysis(value: RuleUnlessStringExpressionEvaluateAnalysisProperty[] | cdktn.IResolvable): void;
        resetAnalysis(): void;
        get analysisInput(): cdktn.IResolvable | RuleUnlessStringExpressionEvaluateAnalysisProperty[] | undefined;
    }
    class RuleUnlessStringExpressionEvaluatePropertyList extends cdktn.ComplexList {
        internalValue?: RuleUnlessStringExpressionEvaluateProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleUnlessStringExpressionEvaluatePropertyOutputReference;
    }
    interface RuleUnlessStringExpressionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#operator AwsRuleSet#operator}
        */
        readonly operator: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#values AwsRuleSet#values}
        */
        readonly values: string[];
        /**
        * evaluate block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#evaluate AwsRuleSet#evaluate}
        */
        readonly evaluate?: RuleUnlessStringExpressionEvaluateProperty[] | cdktn.IResolvable;
    }
    class RuleUnlessStringExpressionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleUnlessStringExpressionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleUnlessStringExpressionProperty | cdktn.IResolvable | undefined);
        private _operator?;
        get operator(): string;
        set operator(value: string);
        get operatorInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
        private _evaluate;
        get evaluate(): RuleUnlessStringExpressionEvaluatePropertyList;
        putEvaluate(value: RuleUnlessStringExpressionEvaluateProperty[] | cdktn.IResolvable): void;
        resetEvaluate(): void;
        get evaluateInput(): cdktn.IResolvable | RuleUnlessStringExpressionEvaluateProperty[] | undefined;
    }
    class RuleUnlessStringExpressionPropertyList extends cdktn.ComplexList {
        internalValue?: RuleUnlessStringExpressionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleUnlessStringExpressionPropertyOutputReference;
    }
    interface RuleUnlessVerdictExpressionEvaluateAnalysisProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#analyzer AwsRuleSet#analyzer}
        */
        readonly analyzer: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#result_field AwsRuleSet#result_field}
        */
        readonly resultField: string;
    }
    class RuleUnlessVerdictExpressionEvaluateAnalysisPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleUnlessVerdictExpressionEvaluateAnalysisProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleUnlessVerdictExpressionEvaluateAnalysisProperty | cdktn.IResolvable | undefined);
        private _analyzer?;
        get analyzer(): string;
        set analyzer(value: string);
        get analyzerInput(): string | undefined;
        private _resultField?;
        get resultField(): string;
        set resultField(value: string);
        get resultFieldInput(): string | undefined;
    }
    class RuleUnlessVerdictExpressionEvaluateAnalysisPropertyList extends cdktn.ComplexList {
        internalValue?: RuleUnlessVerdictExpressionEvaluateAnalysisProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleUnlessVerdictExpressionEvaluateAnalysisPropertyOutputReference;
    }
    interface RuleUnlessVerdictExpressionEvaluateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#attribute AwsRuleSet#attribute}
        */
        readonly attribute?: string;
        /**
        * analysis block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#analysis AwsRuleSet#analysis}
        */
        readonly analysis?: RuleUnlessVerdictExpressionEvaluateAnalysisProperty[] | cdktn.IResolvable;
    }
    class RuleUnlessVerdictExpressionEvaluatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleUnlessVerdictExpressionEvaluateProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleUnlessVerdictExpressionEvaluateProperty | cdktn.IResolvable | undefined);
        private _attribute?;
        get attribute(): string;
        set attribute(value: string);
        resetAttribute(): void;
        get attributeInput(): string | undefined;
        private _analysis;
        get analysis(): RuleUnlessVerdictExpressionEvaluateAnalysisPropertyList;
        putAnalysis(value: RuleUnlessVerdictExpressionEvaluateAnalysisProperty[] | cdktn.IResolvable): void;
        resetAnalysis(): void;
        get analysisInput(): cdktn.IResolvable | RuleUnlessVerdictExpressionEvaluateAnalysisProperty[] | undefined;
    }
    class RuleUnlessVerdictExpressionEvaluatePropertyList extends cdktn.ComplexList {
        internalValue?: RuleUnlessVerdictExpressionEvaluateProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleUnlessVerdictExpressionEvaluatePropertyOutputReference;
    }
    interface RuleUnlessVerdictExpressionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#operator AwsRuleSet#operator}
        */
        readonly operator: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#values AwsRuleSet#values}
        */
        readonly values: string[];
        /**
        * evaluate block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#evaluate AwsRuleSet#evaluate}
        */
        readonly evaluate?: RuleUnlessVerdictExpressionEvaluateProperty[] | cdktn.IResolvable;
    }
    class RuleUnlessVerdictExpressionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleUnlessVerdictExpressionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleUnlessVerdictExpressionProperty | cdktn.IResolvable | undefined);
        private _operator?;
        get operator(): string;
        set operator(value: string);
        get operatorInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
        private _evaluate;
        get evaluate(): RuleUnlessVerdictExpressionEvaluatePropertyList;
        putEvaluate(value: RuleUnlessVerdictExpressionEvaluateProperty[] | cdktn.IResolvable): void;
        resetEvaluate(): void;
        get evaluateInput(): cdktn.IResolvable | RuleUnlessVerdictExpressionEvaluateProperty[] | undefined;
    }
    class RuleUnlessVerdictExpressionPropertyList extends cdktn.ComplexList {
        internalValue?: RuleUnlessVerdictExpressionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleUnlessVerdictExpressionPropertyOutputReference;
    }
    interface UnlessProperty {
        /**
        * boolean_expression block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#boolean_expression AwsRuleSet#boolean_expression}
        */
        readonly booleanExpression?: RuleUnlessBooleanExpressionProperty[] | cdktn.IResolvable;
        /**
        * dmarc_expression block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#dmarc_expression AwsRuleSet#dmarc_expression}
        */
        readonly dmarcExpression?: RuleUnlessDmarcExpressionProperty[] | cdktn.IResolvable;
        /**
        * ip_expression block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#ip_expression AwsRuleSet#ip_expression}
        */
        readonly ipExpression?: RuleUnlessIpExpressionProperty[] | cdktn.IResolvable;
        /**
        * number_expression block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#number_expression AwsRuleSet#number_expression}
        */
        readonly numberExpression?: RuleUnlessNumberExpressionProperty[] | cdktn.IResolvable;
        /**
        * string_expression block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#string_expression AwsRuleSet#string_expression}
        */
        readonly stringExpression?: RuleUnlessStringExpressionProperty[] | cdktn.IResolvable;
        /**
        * verdict_expression block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#verdict_expression AwsRuleSet#verdict_expression}
        */
        readonly verdictExpression?: RuleUnlessVerdictExpressionProperty[] | cdktn.IResolvable;
    }
    class UnlessPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): UnlessProperty | cdktn.IResolvable | undefined;
        set internalValue(value: UnlessProperty | cdktn.IResolvable | undefined);
        private _booleanExpression;
        get booleanExpression(): RuleUnlessBooleanExpressionPropertyList;
        putBooleanExpression(value: RuleUnlessBooleanExpressionProperty[] | cdktn.IResolvable): void;
        resetBooleanExpression(): void;
        get booleanExpressionInput(): cdktn.IResolvable | RuleUnlessBooleanExpressionProperty[] | undefined;
        private _dmarcExpression;
        get dmarcExpression(): RuleUnlessDmarcExpressionPropertyList;
        putDmarcExpression(value: RuleUnlessDmarcExpressionProperty[] | cdktn.IResolvable): void;
        resetDmarcExpression(): void;
        get dmarcExpressionInput(): cdktn.IResolvable | RuleUnlessDmarcExpressionProperty[] | undefined;
        private _ipExpression;
        get ipExpression(): RuleUnlessIpExpressionPropertyList;
        putIpExpression(value: RuleUnlessIpExpressionProperty[] | cdktn.IResolvable): void;
        resetIpExpression(): void;
        get ipExpressionInput(): cdktn.IResolvable | RuleUnlessIpExpressionProperty[] | undefined;
        private _numberExpression;
        get numberExpression(): RuleUnlessNumberExpressionPropertyList;
        putNumberExpression(value: RuleUnlessNumberExpressionProperty[] | cdktn.IResolvable): void;
        resetNumberExpression(): void;
        get numberExpressionInput(): cdktn.IResolvable | RuleUnlessNumberExpressionProperty[] | undefined;
        private _stringExpression;
        get stringExpression(): RuleUnlessStringExpressionPropertyList;
        putStringExpression(value: RuleUnlessStringExpressionProperty[] | cdktn.IResolvable): void;
        resetStringExpression(): void;
        get stringExpressionInput(): cdktn.IResolvable | RuleUnlessStringExpressionProperty[] | undefined;
        private _verdictExpression;
        get verdictExpression(): RuleUnlessVerdictExpressionPropertyList;
        putVerdictExpression(value: RuleUnlessVerdictExpressionProperty[] | cdktn.IResolvable): void;
        resetVerdictExpression(): void;
        get verdictExpressionInput(): cdktn.IResolvable | RuleUnlessVerdictExpressionProperty[] | undefined;
    }
    class UnlessPropertyList extends cdktn.ComplexList {
        internalValue?: UnlessProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): UnlessPropertyOutputReference;
    }
    interface RuleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#name AwsRuleSet#name}
        */
        readonly name?: string;
        /**
        * action block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#action AwsRuleSet#action}
        */
        readonly action?: ActionProperty[] | cdktn.IResolvable;
        /**
        * condition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#condition AwsRuleSet#condition}
        */
        readonly condition?: ConditionProperty[] | cdktn.IResolvable;
        /**
        * unless block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#unless AwsRuleSet#unless}
        */
        readonly unless?: UnlessProperty[] | cdktn.IResolvable;
    }
    class RulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _action;
        get action(): ActionPropertyList;
        putAction(value: ActionProperty[] | cdktn.IResolvable): void;
        resetAction(): void;
        get actionInput(): cdktn.IResolvable | ActionProperty[] | undefined;
        private _condition;
        get condition(): ConditionPropertyList;
        putCondition(value: ConditionProperty[] | cdktn.IResolvable): void;
        resetCondition(): void;
        get conditionInput(): cdktn.IResolvable | ConditionProperty[] | undefined;
        private _unless;
        get unless(): UnlessPropertyList;
        putUnless(value: UnlessProperty[] | cdktn.IResolvable): void;
        resetUnless(): void;
        get unlessInput(): cdktn.IResolvable | UnlessProperty[] | undefined;
    }
    class RulePropertyList extends cdktn.ComplexList {
        internalValue?: RuleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RulePropertyOutputReference;
    }
}
