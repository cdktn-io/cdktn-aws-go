import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsTrafficPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_traffic_policy#default_action AwsTrafficPolicy#default_action}
    */
    readonly defaultAction: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_traffic_policy#max_message_size_bytes AwsTrafficPolicy#max_message_size_bytes}
    */
    readonly maxMessageSizeBytes?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_traffic_policy#name AwsTrafficPolicy#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_traffic_policy#region AwsTrafficPolicy#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_traffic_policy#tags AwsTrafficPolicy#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * policy_statement block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_traffic_policy#policy_statement AwsTrafficPolicy#policy_statement}
    */
    readonly policyStatement?: AwsTrafficPolicy.PolicyStatementProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_traffic_policy aws_mailmanager_traffic_policy}
*/
export declare class AwsTrafficPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_mailmanager_traffic_policy";
    /**
    * Generates CDKTN code for importing a AwsTrafficPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsTrafficPolicy to import
    * @param importFromId The id of the existing AwsTrafficPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_traffic_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsTrafficPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_traffic_policy aws_mailmanager_traffic_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsTrafficPolicyConfig
    */
    constructor(scope: Construct, id: string, config: AwsTrafficPolicyConfig);
    get arn(): string;
    get createdTimestamp(): string;
    private _defaultAction?;
    get defaultAction(): string;
    set defaultAction(value: string);
    get defaultActionInput(): string | undefined;
    get id(): string;
    get lastUpdatedTimestamp(): string;
    private _maxMessageSizeBytes?;
    get maxMessageSizeBytes(): number;
    set maxMessageSizeBytes(value: number);
    resetMaxMessageSizeBytes(): void;
    get maxMessageSizeBytesInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _policyStatement;
    get policyStatement(): AwsTrafficPolicy.PolicyStatementPropertyList;
    putPolicyStatement(value: AwsTrafficPolicy.PolicyStatementProperty[] | cdktn.IResolvable): void;
    resetPolicyStatement(): void;
    get policyStatementInput(): cdktn.IResolvable | AwsTrafficPolicy.PolicyStatementProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsTrafficPolicyPolicyStatementConditionBooleanExpressionEvaluateAnalysisPropertyToTerraform(struct?: AwsTrafficPolicy.PolicyStatementConditionBooleanExpressionEvaluateAnalysisProperty | cdktn.IResolvable): any;
export declare function awsTrafficPolicyPolicyStatementConditionBooleanExpressionEvaluateAnalysisPropertyToHclTerraform(struct?: AwsTrafficPolicy.PolicyStatementConditionBooleanExpressionEvaluateAnalysisProperty | cdktn.IResolvable): any;
export declare function awsTrafficPolicyIsInAddressListPropertyToTerraform(struct?: AwsTrafficPolicy.IsInAddressListProperty | cdktn.IResolvable): any;
export declare function awsTrafficPolicyIsInAddressListPropertyToHclTerraform(struct?: AwsTrafficPolicy.IsInAddressListProperty | cdktn.IResolvable): any;
export declare function awsTrafficPolicyPolicyStatementConditionBooleanExpressionEvaluatePropertyToTerraform(struct?: AwsTrafficPolicy.PolicyStatementConditionBooleanExpressionEvaluateProperty | cdktn.IResolvable): any;
export declare function awsTrafficPolicyPolicyStatementConditionBooleanExpressionEvaluatePropertyToHclTerraform(struct?: AwsTrafficPolicy.PolicyStatementConditionBooleanExpressionEvaluateProperty | cdktn.IResolvable): any;
export declare function awsTrafficPolicyBooleanExpressionPropertyToTerraform(struct?: AwsTrafficPolicy.BooleanExpressionProperty | cdktn.IResolvable): any;
export declare function awsTrafficPolicyBooleanExpressionPropertyToHclTerraform(struct?: AwsTrafficPolicy.BooleanExpressionProperty | cdktn.IResolvable): any;
export declare function awsTrafficPolicyPolicyStatementConditionIpExpressionEvaluatePropertyToTerraform(struct?: AwsTrafficPolicy.PolicyStatementConditionIpExpressionEvaluateProperty | cdktn.IResolvable): any;
export declare function awsTrafficPolicyPolicyStatementConditionIpExpressionEvaluatePropertyToHclTerraform(struct?: AwsTrafficPolicy.PolicyStatementConditionIpExpressionEvaluateProperty | cdktn.IResolvable): any;
export declare function awsTrafficPolicyIpExpressionPropertyToTerraform(struct?: AwsTrafficPolicy.IpExpressionProperty | cdktn.IResolvable): any;
export declare function awsTrafficPolicyIpExpressionPropertyToHclTerraform(struct?: AwsTrafficPolicy.IpExpressionProperty | cdktn.IResolvable): any;
export declare function awsTrafficPolicyPolicyStatementConditionIpv6ExpressionEvaluatePropertyToTerraform(struct?: AwsTrafficPolicy.PolicyStatementConditionIpv6ExpressionEvaluateProperty | cdktn.IResolvable): any;
export declare function awsTrafficPolicyPolicyStatementConditionIpv6ExpressionEvaluatePropertyToHclTerraform(struct?: AwsTrafficPolicy.PolicyStatementConditionIpv6ExpressionEvaluateProperty | cdktn.IResolvable): any;
export declare function awsTrafficPolicyIpv6ExpressionPropertyToTerraform(struct?: AwsTrafficPolicy.Ipv6ExpressionProperty | cdktn.IResolvable): any;
export declare function awsTrafficPolicyIpv6ExpressionPropertyToHclTerraform(struct?: AwsTrafficPolicy.Ipv6ExpressionProperty | cdktn.IResolvable): any;
export declare function awsTrafficPolicyPolicyStatementConditionStringExpressionEvaluateAnalysisPropertyToTerraform(struct?: AwsTrafficPolicy.PolicyStatementConditionStringExpressionEvaluateAnalysisProperty | cdktn.IResolvable): any;
export declare function awsTrafficPolicyPolicyStatementConditionStringExpressionEvaluateAnalysisPropertyToHclTerraform(struct?: AwsTrafficPolicy.PolicyStatementConditionStringExpressionEvaluateAnalysisProperty | cdktn.IResolvable): any;
export declare function awsTrafficPolicyPolicyStatementConditionStringExpressionEvaluatePropertyToTerraform(struct?: AwsTrafficPolicy.PolicyStatementConditionStringExpressionEvaluateProperty | cdktn.IResolvable): any;
export declare function awsTrafficPolicyPolicyStatementConditionStringExpressionEvaluatePropertyToHclTerraform(struct?: AwsTrafficPolicy.PolicyStatementConditionStringExpressionEvaluateProperty | cdktn.IResolvable): any;
export declare function awsTrafficPolicyStringExpressionPropertyToTerraform(struct?: AwsTrafficPolicy.StringExpressionProperty | cdktn.IResolvable): any;
export declare function awsTrafficPolicyStringExpressionPropertyToHclTerraform(struct?: AwsTrafficPolicy.StringExpressionProperty | cdktn.IResolvable): any;
export declare function awsTrafficPolicyPolicyStatementConditionTlsExpressionEvaluatePropertyToTerraform(struct?: AwsTrafficPolicy.PolicyStatementConditionTlsExpressionEvaluateProperty | cdktn.IResolvable): any;
export declare function awsTrafficPolicyPolicyStatementConditionTlsExpressionEvaluatePropertyToHclTerraform(struct?: AwsTrafficPolicy.PolicyStatementConditionTlsExpressionEvaluateProperty | cdktn.IResolvable): any;
export declare function awsTrafficPolicyTlsExpressionPropertyToTerraform(struct?: AwsTrafficPolicy.TlsExpressionProperty | cdktn.IResolvable): any;
export declare function awsTrafficPolicyTlsExpressionPropertyToHclTerraform(struct?: AwsTrafficPolicy.TlsExpressionProperty | cdktn.IResolvable): any;
export declare function awsTrafficPolicyConditionPropertyToTerraform(struct?: AwsTrafficPolicy.ConditionProperty | cdktn.IResolvable): any;
export declare function awsTrafficPolicyConditionPropertyToHclTerraform(struct?: AwsTrafficPolicy.ConditionProperty | cdktn.IResolvable): any;
export declare function awsTrafficPolicyPolicyStatementPropertyToTerraform(struct?: AwsTrafficPolicy.PolicyStatementProperty | cdktn.IResolvable): any;
export declare function awsTrafficPolicyPolicyStatementPropertyToHclTerraform(struct?: AwsTrafficPolicy.PolicyStatementProperty | cdktn.IResolvable): any;
export declare namespace AwsTrafficPolicy {
    interface PolicyStatementConditionBooleanExpressionEvaluateAnalysisProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_traffic_policy#analyzer AwsTrafficPolicy#analyzer}
        */
        readonly analyzer: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_traffic_policy#result_field AwsTrafficPolicy#result_field}
        */
        readonly resultField: string;
    }
    class PolicyStatementConditionBooleanExpressionEvaluateAnalysisPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PolicyStatementConditionBooleanExpressionEvaluateAnalysisProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PolicyStatementConditionBooleanExpressionEvaluateAnalysisProperty | cdktn.IResolvable | undefined);
        private _analyzer?;
        get analyzer(): string;
        set analyzer(value: string);
        get analyzerInput(): string | undefined;
        private _resultField?;
        get resultField(): string;
        set resultField(value: string);
        get resultFieldInput(): string | undefined;
    }
    class PolicyStatementConditionBooleanExpressionEvaluateAnalysisPropertyList extends cdktn.ComplexList {
        internalValue?: PolicyStatementConditionBooleanExpressionEvaluateAnalysisProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PolicyStatementConditionBooleanExpressionEvaluateAnalysisPropertyOutputReference;
    }
    interface IsInAddressListProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_traffic_policy#address_lists AwsTrafficPolicy#address_lists}
        */
        readonly addressLists: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_traffic_policy#attribute AwsTrafficPolicy#attribute}
        */
        readonly attribute: string;
    }
    class IsInAddressListPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IsInAddressListProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IsInAddressListProperty | cdktn.IResolvable | undefined);
        private _addressLists?;
        get addressLists(): string[];
        set addressLists(value: string[]);
        get addressListsInput(): string[] | undefined;
        private _attribute?;
        get attribute(): string;
        set attribute(value: string);
        get attributeInput(): string | undefined;
    }
    class IsInAddressListPropertyList extends cdktn.ComplexList {
        internalValue?: IsInAddressListProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IsInAddressListPropertyOutputReference;
    }
    interface PolicyStatementConditionBooleanExpressionEvaluateProperty {
        /**
        * analysis block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_traffic_policy#analysis AwsTrafficPolicy#analysis}
        */
        readonly analysis?: PolicyStatementConditionBooleanExpressionEvaluateAnalysisProperty[] | cdktn.IResolvable;
        /**
        * is_in_address_list block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_traffic_policy#is_in_address_list AwsTrafficPolicy#is_in_address_list}
        */
        readonly isInAddressList?: IsInAddressListProperty[] | cdktn.IResolvable;
    }
    class PolicyStatementConditionBooleanExpressionEvaluatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PolicyStatementConditionBooleanExpressionEvaluateProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PolicyStatementConditionBooleanExpressionEvaluateProperty | cdktn.IResolvable | undefined);
        private _analysis;
        get analysis(): PolicyStatementConditionBooleanExpressionEvaluateAnalysisPropertyList;
        putAnalysis(value: PolicyStatementConditionBooleanExpressionEvaluateAnalysisProperty[] | cdktn.IResolvable): void;
        resetAnalysis(): void;
        get analysisInput(): cdktn.IResolvable | PolicyStatementConditionBooleanExpressionEvaluateAnalysisProperty[] | undefined;
        private _isInAddressList;
        get isInAddressList(): IsInAddressListPropertyList;
        putIsInAddressList(value: IsInAddressListProperty[] | cdktn.IResolvable): void;
        resetIsInAddressList(): void;
        get isInAddressListInput(): cdktn.IResolvable | IsInAddressListProperty[] | undefined;
    }
    class PolicyStatementConditionBooleanExpressionEvaluatePropertyList extends cdktn.ComplexList {
        internalValue?: PolicyStatementConditionBooleanExpressionEvaluateProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PolicyStatementConditionBooleanExpressionEvaluatePropertyOutputReference;
    }
    interface BooleanExpressionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_traffic_policy#operator AwsTrafficPolicy#operator}
        */
        readonly operator: string;
        /**
        * evaluate block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_traffic_policy#evaluate AwsTrafficPolicy#evaluate}
        */
        readonly evaluate?: PolicyStatementConditionBooleanExpressionEvaluateProperty[] | cdktn.IResolvable;
    }
    class BooleanExpressionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BooleanExpressionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: BooleanExpressionProperty | cdktn.IResolvable | undefined);
        private _operator?;
        get operator(): string;
        set operator(value: string);
        get operatorInput(): string | undefined;
        private _evaluate;
        get evaluate(): PolicyStatementConditionBooleanExpressionEvaluatePropertyList;
        putEvaluate(value: PolicyStatementConditionBooleanExpressionEvaluateProperty[] | cdktn.IResolvable): void;
        resetEvaluate(): void;
        get evaluateInput(): cdktn.IResolvable | PolicyStatementConditionBooleanExpressionEvaluateProperty[] | undefined;
    }
    class BooleanExpressionPropertyList extends cdktn.ComplexList {
        internalValue?: BooleanExpressionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BooleanExpressionPropertyOutputReference;
    }
    interface PolicyStatementConditionIpExpressionEvaluateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_traffic_policy#attribute AwsTrafficPolicy#attribute}
        */
        readonly attribute: string;
    }
    class PolicyStatementConditionIpExpressionEvaluatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PolicyStatementConditionIpExpressionEvaluateProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PolicyStatementConditionIpExpressionEvaluateProperty | cdktn.IResolvable | undefined);
        private _attribute?;
        get attribute(): string;
        set attribute(value: string);
        get attributeInput(): string | undefined;
    }
    class PolicyStatementConditionIpExpressionEvaluatePropertyList extends cdktn.ComplexList {
        internalValue?: PolicyStatementConditionIpExpressionEvaluateProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PolicyStatementConditionIpExpressionEvaluatePropertyOutputReference;
    }
    interface IpExpressionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_traffic_policy#operator AwsTrafficPolicy#operator}
        */
        readonly operator: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_traffic_policy#values AwsTrafficPolicy#values}
        */
        readonly values: string[];
        /**
        * evaluate block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_traffic_policy#evaluate AwsTrafficPolicy#evaluate}
        */
        readonly evaluate?: PolicyStatementConditionIpExpressionEvaluateProperty[] | cdktn.IResolvable;
    }
    class IpExpressionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IpExpressionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IpExpressionProperty | cdktn.IResolvable | undefined);
        private _operator?;
        get operator(): string;
        set operator(value: string);
        get operatorInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
        private _evaluate;
        get evaluate(): PolicyStatementConditionIpExpressionEvaluatePropertyList;
        putEvaluate(value: PolicyStatementConditionIpExpressionEvaluateProperty[] | cdktn.IResolvable): void;
        resetEvaluate(): void;
        get evaluateInput(): cdktn.IResolvable | PolicyStatementConditionIpExpressionEvaluateProperty[] | undefined;
    }
    class IpExpressionPropertyList extends cdktn.ComplexList {
        internalValue?: IpExpressionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IpExpressionPropertyOutputReference;
    }
    interface PolicyStatementConditionIpv6ExpressionEvaluateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_traffic_policy#attribute AwsTrafficPolicy#attribute}
        */
        readonly attribute: string;
    }
    class PolicyStatementConditionIpv6ExpressionEvaluatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PolicyStatementConditionIpv6ExpressionEvaluateProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PolicyStatementConditionIpv6ExpressionEvaluateProperty | cdktn.IResolvable | undefined);
        private _attribute?;
        get attribute(): string;
        set attribute(value: string);
        get attributeInput(): string | undefined;
    }
    class PolicyStatementConditionIpv6ExpressionEvaluatePropertyList extends cdktn.ComplexList {
        internalValue?: PolicyStatementConditionIpv6ExpressionEvaluateProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PolicyStatementConditionIpv6ExpressionEvaluatePropertyOutputReference;
    }
    interface Ipv6ExpressionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_traffic_policy#operator AwsTrafficPolicy#operator}
        */
        readonly operator: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_traffic_policy#values AwsTrafficPolicy#values}
        */
        readonly values: string[];
        /**
        * evaluate block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_traffic_policy#evaluate AwsTrafficPolicy#evaluate}
        */
        readonly evaluate?: PolicyStatementConditionIpv6ExpressionEvaluateProperty[] | cdktn.IResolvable;
    }
    class Ipv6ExpressionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): Ipv6ExpressionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: Ipv6ExpressionProperty | cdktn.IResolvable | undefined);
        private _operator?;
        get operator(): string;
        set operator(value: string);
        get operatorInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
        private _evaluate;
        get evaluate(): PolicyStatementConditionIpv6ExpressionEvaluatePropertyList;
        putEvaluate(value: PolicyStatementConditionIpv6ExpressionEvaluateProperty[] | cdktn.IResolvable): void;
        resetEvaluate(): void;
        get evaluateInput(): cdktn.IResolvable | PolicyStatementConditionIpv6ExpressionEvaluateProperty[] | undefined;
    }
    class Ipv6ExpressionPropertyList extends cdktn.ComplexList {
        internalValue?: Ipv6ExpressionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): Ipv6ExpressionPropertyOutputReference;
    }
    interface PolicyStatementConditionStringExpressionEvaluateAnalysisProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_traffic_policy#analyzer AwsTrafficPolicy#analyzer}
        */
        readonly analyzer: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_traffic_policy#result_field AwsTrafficPolicy#result_field}
        */
        readonly resultField: string;
    }
    class PolicyStatementConditionStringExpressionEvaluateAnalysisPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PolicyStatementConditionStringExpressionEvaluateAnalysisProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PolicyStatementConditionStringExpressionEvaluateAnalysisProperty | cdktn.IResolvable | undefined);
        private _analyzer?;
        get analyzer(): string;
        set analyzer(value: string);
        get analyzerInput(): string | undefined;
        private _resultField?;
        get resultField(): string;
        set resultField(value: string);
        get resultFieldInput(): string | undefined;
    }
    class PolicyStatementConditionStringExpressionEvaluateAnalysisPropertyList extends cdktn.ComplexList {
        internalValue?: PolicyStatementConditionStringExpressionEvaluateAnalysisProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PolicyStatementConditionStringExpressionEvaluateAnalysisPropertyOutputReference;
    }
    interface PolicyStatementConditionStringExpressionEvaluateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_traffic_policy#attribute AwsTrafficPolicy#attribute}
        */
        readonly attribute?: string;
        /**
        * analysis block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_traffic_policy#analysis AwsTrafficPolicy#analysis}
        */
        readonly analysis?: PolicyStatementConditionStringExpressionEvaluateAnalysisProperty[] | cdktn.IResolvable;
    }
    class PolicyStatementConditionStringExpressionEvaluatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PolicyStatementConditionStringExpressionEvaluateProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PolicyStatementConditionStringExpressionEvaluateProperty | cdktn.IResolvable | undefined);
        private _attribute?;
        get attribute(): string;
        set attribute(value: string);
        resetAttribute(): void;
        get attributeInput(): string | undefined;
        private _analysis;
        get analysis(): PolicyStatementConditionStringExpressionEvaluateAnalysisPropertyList;
        putAnalysis(value: PolicyStatementConditionStringExpressionEvaluateAnalysisProperty[] | cdktn.IResolvable): void;
        resetAnalysis(): void;
        get analysisInput(): cdktn.IResolvable | PolicyStatementConditionStringExpressionEvaluateAnalysisProperty[] | undefined;
    }
    class PolicyStatementConditionStringExpressionEvaluatePropertyList extends cdktn.ComplexList {
        internalValue?: PolicyStatementConditionStringExpressionEvaluateProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PolicyStatementConditionStringExpressionEvaluatePropertyOutputReference;
    }
    interface StringExpressionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_traffic_policy#operator AwsTrafficPolicy#operator}
        */
        readonly operator: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_traffic_policy#values AwsTrafficPolicy#values}
        */
        readonly values: string[];
        /**
        * evaluate block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_traffic_policy#evaluate AwsTrafficPolicy#evaluate}
        */
        readonly evaluate?: PolicyStatementConditionStringExpressionEvaluateProperty[] | cdktn.IResolvable;
    }
    class StringExpressionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StringExpressionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StringExpressionProperty | cdktn.IResolvable | undefined);
        private _operator?;
        get operator(): string;
        set operator(value: string);
        get operatorInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
        private _evaluate;
        get evaluate(): PolicyStatementConditionStringExpressionEvaluatePropertyList;
        putEvaluate(value: PolicyStatementConditionStringExpressionEvaluateProperty[] | cdktn.IResolvable): void;
        resetEvaluate(): void;
        get evaluateInput(): cdktn.IResolvable | PolicyStatementConditionStringExpressionEvaluateProperty[] | undefined;
    }
    class StringExpressionPropertyList extends cdktn.ComplexList {
        internalValue?: StringExpressionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StringExpressionPropertyOutputReference;
    }
    interface PolicyStatementConditionTlsExpressionEvaluateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_traffic_policy#attribute AwsTrafficPolicy#attribute}
        */
        readonly attribute: string;
    }
    class PolicyStatementConditionTlsExpressionEvaluatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PolicyStatementConditionTlsExpressionEvaluateProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PolicyStatementConditionTlsExpressionEvaluateProperty | cdktn.IResolvable | undefined);
        private _attribute?;
        get attribute(): string;
        set attribute(value: string);
        get attributeInput(): string | undefined;
    }
    class PolicyStatementConditionTlsExpressionEvaluatePropertyList extends cdktn.ComplexList {
        internalValue?: PolicyStatementConditionTlsExpressionEvaluateProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PolicyStatementConditionTlsExpressionEvaluatePropertyOutputReference;
    }
    interface TlsExpressionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_traffic_policy#operator AwsTrafficPolicy#operator}
        */
        readonly operator: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_traffic_policy#value AwsTrafficPolicy#value}
        */
        readonly value: string;
        /**
        * evaluate block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_traffic_policy#evaluate AwsTrafficPolicy#evaluate}
        */
        readonly evaluate?: PolicyStatementConditionTlsExpressionEvaluateProperty[] | cdktn.IResolvable;
    }
    class TlsExpressionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TlsExpressionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TlsExpressionProperty | cdktn.IResolvable | undefined);
        private _operator?;
        get operator(): string;
        set operator(value: string);
        get operatorInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
        private _evaluate;
        get evaluate(): PolicyStatementConditionTlsExpressionEvaluatePropertyList;
        putEvaluate(value: PolicyStatementConditionTlsExpressionEvaluateProperty[] | cdktn.IResolvable): void;
        resetEvaluate(): void;
        get evaluateInput(): cdktn.IResolvable | PolicyStatementConditionTlsExpressionEvaluateProperty[] | undefined;
    }
    class TlsExpressionPropertyList extends cdktn.ComplexList {
        internalValue?: TlsExpressionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TlsExpressionPropertyOutputReference;
    }
    interface ConditionProperty {
        /**
        * boolean_expression block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_traffic_policy#boolean_expression AwsTrafficPolicy#boolean_expression}
        */
        readonly booleanExpression?: BooleanExpressionProperty[] | cdktn.IResolvable;
        /**
        * ip_expression block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_traffic_policy#ip_expression AwsTrafficPolicy#ip_expression}
        */
        readonly ipExpression?: IpExpressionProperty[] | cdktn.IResolvable;
        /**
        * ipv6_expression block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_traffic_policy#ipv6_expression AwsTrafficPolicy#ipv6_expression}
        */
        readonly ipv6Expression?: Ipv6ExpressionProperty[] | cdktn.IResolvable;
        /**
        * string_expression block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_traffic_policy#string_expression AwsTrafficPolicy#string_expression}
        */
        readonly stringExpression?: StringExpressionProperty[] | cdktn.IResolvable;
        /**
        * tls_expression block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_traffic_policy#tls_expression AwsTrafficPolicy#tls_expression}
        */
        readonly tlsExpression?: TlsExpressionProperty[] | cdktn.IResolvable;
    }
    class ConditionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConditionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConditionProperty | cdktn.IResolvable | undefined);
        private _booleanExpression;
        get booleanExpression(): BooleanExpressionPropertyList;
        putBooleanExpression(value: BooleanExpressionProperty[] | cdktn.IResolvable): void;
        resetBooleanExpression(): void;
        get booleanExpressionInput(): cdktn.IResolvable | BooleanExpressionProperty[] | undefined;
        private _ipExpression;
        get ipExpression(): IpExpressionPropertyList;
        putIpExpression(value: IpExpressionProperty[] | cdktn.IResolvable): void;
        resetIpExpression(): void;
        get ipExpressionInput(): cdktn.IResolvable | IpExpressionProperty[] | undefined;
        private _ipv6Expression;
        get ipv6Expression(): Ipv6ExpressionPropertyList;
        putIpv6Expression(value: Ipv6ExpressionProperty[] | cdktn.IResolvable): void;
        resetIpv6Expression(): void;
        get ipv6ExpressionInput(): cdktn.IResolvable | Ipv6ExpressionProperty[] | undefined;
        private _stringExpression;
        get stringExpression(): StringExpressionPropertyList;
        putStringExpression(value: StringExpressionProperty[] | cdktn.IResolvable): void;
        resetStringExpression(): void;
        get stringExpressionInput(): cdktn.IResolvable | StringExpressionProperty[] | undefined;
        private _tlsExpression;
        get tlsExpression(): TlsExpressionPropertyList;
        putTlsExpression(value: TlsExpressionProperty[] | cdktn.IResolvable): void;
        resetTlsExpression(): void;
        get tlsExpressionInput(): cdktn.IResolvable | TlsExpressionProperty[] | undefined;
    }
    class ConditionPropertyList extends cdktn.ComplexList {
        internalValue?: ConditionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConditionPropertyOutputReference;
    }
    interface PolicyStatementProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_traffic_policy#action AwsTrafficPolicy#action}
        */
        readonly action: string;
        /**
        * condition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_traffic_policy#condition AwsTrafficPolicy#condition}
        */
        readonly condition?: ConditionProperty[] | cdktn.IResolvable;
    }
    class PolicyStatementPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PolicyStatementProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PolicyStatementProperty | cdktn.IResolvable | undefined);
        private _action?;
        get action(): string;
        set action(value: string);
        get actionInput(): string | undefined;
        private _condition;
        get condition(): ConditionPropertyList;
        putCondition(value: ConditionProperty[] | cdktn.IResolvable): void;
        resetCondition(): void;
        get conditionInput(): cdktn.IResolvable | ConditionProperty[] | undefined;
    }
    class PolicyStatementPropertyList extends cdktn.ComplexList {
        internalValue?: PolicyStatementProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PolicyStatementPropertyOutputReference;
    }
}
