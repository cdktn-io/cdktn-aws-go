import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsIngressPointConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_ingress_point#name AwsIngressPoint#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_ingress_point#region AwsIngressPoint#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_ingress_point#rule_set_id AwsIngressPoint#rule_set_id}
    */
    readonly ruleSetId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_ingress_point#tags AwsIngressPoint#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_ingress_point#tls_policy AwsIngressPoint#tls_policy}
    */
    readonly tlsPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_ingress_point#traffic_policy_id AwsIngressPoint#traffic_policy_id}
    */
    readonly trafficPolicyId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_ingress_point#type AwsIngressPoint#type}
    */
    readonly type: string;
    /**
    * ingress_point_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_ingress_point#ingress_point_configuration AwsIngressPoint#ingress_point_configuration}
    */
    readonly ingressPointConfiguration?: AwsIngressPoint.IngressPointConfigurationProperty[] | cdktn.IResolvable;
    /**
    * network_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_ingress_point#network_configuration AwsIngressPoint#network_configuration}
    */
    readonly networkConfiguration?: AwsIngressPoint.NetworkConfigurationProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_ingress_point#timeouts AwsIngressPoint#timeouts}
    */
    readonly timeouts?: AwsIngressPoint.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_ingress_point aws_mailmanager_ingress_point}
*/
export declare class AwsIngressPoint extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_mailmanager_ingress_point";
    /**
    * Generates CDKTN code for importing a AwsIngressPoint resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsIngressPoint to import
    * @param importFromId The id of the existing AwsIngressPoint that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_ingress_point#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsIngressPoint to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_ingress_point aws_mailmanager_ingress_point} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsIngressPointConfig
    */
    constructor(scope: Construct, id: string, config: AwsIngressPointConfig);
    get aRecord(): string;
    get arn(): string;
    get createdTimestamp(): string;
    get id(): string;
    get lastUpdatedTimestamp(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _ruleSetId?;
    get ruleSetId(): string;
    set ruleSetId(value: string);
    get ruleSetIdInput(): string | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _tlsPolicy?;
    get tlsPolicy(): string;
    set tlsPolicy(value: string);
    resetTlsPolicy(): void;
    get tlsPolicyInput(): string | undefined;
    private _trafficPolicyId?;
    get trafficPolicyId(): string;
    set trafficPolicyId(value: string);
    get trafficPolicyIdInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _ingressPointConfiguration;
    get ingressPointConfiguration(): AwsIngressPoint.IngressPointConfigurationPropertyList;
    putIngressPointConfiguration(value: AwsIngressPoint.IngressPointConfigurationProperty[] | cdktn.IResolvable): void;
    resetIngressPointConfiguration(): void;
    get ingressPointConfigurationInput(): cdktn.IResolvable | AwsIngressPoint.IngressPointConfigurationProperty[] | undefined;
    private _networkConfiguration;
    get networkConfiguration(): AwsIngressPoint.NetworkConfigurationPropertyList;
    putNetworkConfiguration(value: AwsIngressPoint.NetworkConfigurationProperty[] | cdktn.IResolvable): void;
    resetNetworkConfiguration(): void;
    get networkConfigurationInput(): cdktn.IResolvable | AwsIngressPoint.NetworkConfigurationProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsIngressPoint.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsIngressPoint.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsIngressPoint.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsIngressPointTrustStorePropertyToTerraform(struct?: AwsIngressPoint.TrustStoreProperty | cdktn.IResolvable): any;
export declare function awsIngressPointTrustStorePropertyToHclTerraform(struct?: AwsIngressPoint.TrustStoreProperty | cdktn.IResolvable): any;
export declare function awsIngressPointTlsAuthConfigurationPropertyToTerraform(struct?: AwsIngressPoint.TlsAuthConfigurationProperty | cdktn.IResolvable): any;
export declare function awsIngressPointTlsAuthConfigurationPropertyToHclTerraform(struct?: AwsIngressPoint.TlsAuthConfigurationProperty | cdktn.IResolvable): any;
export declare function awsIngressPointIngressPointConfigurationPropertyToTerraform(struct?: AwsIngressPoint.IngressPointConfigurationProperty | cdktn.IResolvable): any;
export declare function awsIngressPointIngressPointConfigurationPropertyToHclTerraform(struct?: AwsIngressPoint.IngressPointConfigurationProperty | cdktn.IResolvable): any;
export declare function awsIngressPointPrivateNetworkConfigurationPropertyToTerraform(struct?: AwsIngressPoint.PrivateNetworkConfigurationProperty | cdktn.IResolvable): any;
export declare function awsIngressPointPrivateNetworkConfigurationPropertyToHclTerraform(struct?: AwsIngressPoint.PrivateNetworkConfigurationProperty | cdktn.IResolvable): any;
export declare function awsIngressPointPublicNetworkConfigurationPropertyToTerraform(struct?: AwsIngressPoint.PublicNetworkConfigurationProperty | cdktn.IResolvable): any;
export declare function awsIngressPointPublicNetworkConfigurationPropertyToHclTerraform(struct?: AwsIngressPoint.PublicNetworkConfigurationProperty | cdktn.IResolvable): any;
export declare function awsIngressPointNetworkConfigurationPropertyToTerraform(struct?: AwsIngressPoint.NetworkConfigurationProperty | cdktn.IResolvable): any;
export declare function awsIngressPointNetworkConfigurationPropertyToHclTerraform(struct?: AwsIngressPoint.NetworkConfigurationProperty | cdktn.IResolvable): any;
export declare function awsIngressPointTimeoutsPropertyToTerraform(struct?: AwsIngressPoint.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsIngressPointTimeoutsPropertyToHclTerraform(struct?: AwsIngressPoint.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsIngressPoint {
    interface TrustStoreProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_ingress_point#ca_content AwsIngressPoint#ca_content}
        */
        readonly caContent: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_ingress_point#crl_content AwsIngressPoint#crl_content}
        */
        readonly crlContent?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_ingress_point#kms_key_arn AwsIngressPoint#kms_key_arn}
        */
        readonly kmsKeyArn?: string;
    }
    class TrustStorePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrustStoreProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrustStoreProperty | cdktn.IResolvable | undefined);
        private _caContent?;
        get caContent(): string;
        set caContent(value: string);
        get caContentInput(): string | undefined;
        private _crlContent?;
        get crlContent(): string;
        set crlContent(value: string);
        resetCrlContent(): void;
        get crlContentInput(): string | undefined;
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        resetKmsKeyArn(): void;
        get kmsKeyArnInput(): string | undefined;
    }
    class TrustStorePropertyList extends cdktn.ComplexList {
        internalValue?: TrustStoreProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrustStorePropertyOutputReference;
    }
    interface TlsAuthConfigurationProperty {
        /**
        * trust_store block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_ingress_point#trust_store AwsIngressPoint#trust_store}
        */
        readonly trustStore?: TrustStoreProperty[] | cdktn.IResolvable;
    }
    class TlsAuthConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TlsAuthConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TlsAuthConfigurationProperty | cdktn.IResolvable | undefined);
        private _trustStore;
        get trustStore(): TrustStorePropertyList;
        putTrustStore(value: TrustStoreProperty[] | cdktn.IResolvable): void;
        resetTrustStore(): void;
        get trustStoreInput(): cdktn.IResolvable | TrustStoreProperty[] | undefined;
    }
    class TlsAuthConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: TlsAuthConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TlsAuthConfigurationPropertyOutputReference;
    }
    interface IngressPointConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_ingress_point#secret_arn AwsIngressPoint#secret_arn}
        */
        readonly secretArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_ingress_point#smtp_password_wo AwsIngressPoint#smtp_password_wo}
        */
        readonly smtpPasswordWo?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_ingress_point#smtp_password_wo_version AwsIngressPoint#smtp_password_wo_version}
        */
        readonly smtpPasswordWoVersion?: number;
        /**
        * tls_auth_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_ingress_point#tls_auth_configuration AwsIngressPoint#tls_auth_configuration}
        */
        readonly tlsAuthConfiguration?: TlsAuthConfigurationProperty[] | cdktn.IResolvable;
    }
    class IngressPointConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IngressPointConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IngressPointConfigurationProperty | cdktn.IResolvable | undefined);
        private _secretArn?;
        get secretArn(): string;
        set secretArn(value: string);
        resetSecretArn(): void;
        get secretArnInput(): string | undefined;
        private _smtpPasswordWo?;
        /**
        * @deprecated Write-only: the provider never returns this value; reading it always yields null by protocol contract. The getter remains for compatibility and will be removed in a future prebuilt-provider major.
        */
        get smtpPasswordWo(): string;
        set smtpPasswordWo(value: string);
        resetSmtpPasswordWo(): void;
        get smtpPasswordWoInput(): string | undefined;
        private _smtpPasswordWoVersion?;
        get smtpPasswordWoVersion(): number;
        set smtpPasswordWoVersion(value: number);
        resetSmtpPasswordWoVersion(): void;
        get smtpPasswordWoVersionInput(): number | undefined;
        private _tlsAuthConfiguration;
        get tlsAuthConfiguration(): TlsAuthConfigurationPropertyList;
        putTlsAuthConfiguration(value: TlsAuthConfigurationProperty[] | cdktn.IResolvable): void;
        resetTlsAuthConfiguration(): void;
        get tlsAuthConfigurationInput(): cdktn.IResolvable | TlsAuthConfigurationProperty[] | undefined;
    }
    class IngressPointConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: IngressPointConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IngressPointConfigurationPropertyOutputReference;
    }
    interface PrivateNetworkConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_ingress_point#vpc_endpoint_id AwsIngressPoint#vpc_endpoint_id}
        */
        readonly vpcEndpointId: string;
    }
    class PrivateNetworkConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PrivateNetworkConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PrivateNetworkConfigurationProperty | cdktn.IResolvable | undefined);
        private _vpcEndpointId?;
        get vpcEndpointId(): string;
        set vpcEndpointId(value: string);
        get vpcEndpointIdInput(): string | undefined;
    }
    class PrivateNetworkConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: PrivateNetworkConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PrivateNetworkConfigurationPropertyOutputReference;
    }
    interface PublicNetworkConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_ingress_point#ip_type AwsIngressPoint#ip_type}
        */
        readonly ipType: string;
    }
    class PublicNetworkConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PublicNetworkConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PublicNetworkConfigurationProperty | cdktn.IResolvable | undefined);
        private _ipType?;
        get ipType(): string;
        set ipType(value: string);
        get ipTypeInput(): string | undefined;
    }
    class PublicNetworkConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: PublicNetworkConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PublicNetworkConfigurationPropertyOutputReference;
    }
    interface NetworkConfigurationProperty {
        /**
        * private_network_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_ingress_point#private_network_configuration AwsIngressPoint#private_network_configuration}
        */
        readonly privateNetworkConfiguration?: PrivateNetworkConfigurationProperty[] | cdktn.IResolvable;
        /**
        * public_network_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_ingress_point#public_network_configuration AwsIngressPoint#public_network_configuration}
        */
        readonly publicNetworkConfiguration?: PublicNetworkConfigurationProperty[] | cdktn.IResolvable;
    }
    class NetworkConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NetworkConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NetworkConfigurationProperty | cdktn.IResolvable | undefined);
        private _privateNetworkConfiguration;
        get privateNetworkConfiguration(): PrivateNetworkConfigurationPropertyList;
        putPrivateNetworkConfiguration(value: PrivateNetworkConfigurationProperty[] | cdktn.IResolvable): void;
        resetPrivateNetworkConfiguration(): void;
        get privateNetworkConfigurationInput(): cdktn.IResolvable | PrivateNetworkConfigurationProperty[] | undefined;
        private _publicNetworkConfiguration;
        get publicNetworkConfiguration(): PublicNetworkConfigurationPropertyList;
        putPublicNetworkConfiguration(value: PublicNetworkConfigurationProperty[] | cdktn.IResolvable): void;
        resetPublicNetworkConfiguration(): void;
        get publicNetworkConfigurationInput(): cdktn.IResolvable | PublicNetworkConfigurationProperty[] | undefined;
    }
    class NetworkConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: NetworkConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NetworkConfigurationPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_ingress_point#create AwsIngressPoint#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_ingress_point#delete AwsIngressPoint#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_ingress_point#update AwsIngressPoint#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
