import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDomainConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudsearch_domain#id AwsDomain#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudsearch_domain#multi_az AwsDomain#multi_az}
    */
    readonly multiAz?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudsearch_domain#name AwsDomain#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudsearch_domain#region AwsDomain#region}
    */
    readonly region?: string;
    /**
    * endpoint_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudsearch_domain#endpoint_options AwsDomain#endpoint_options}
    */
    readonly endpointOptions?: AwsDomain.EndpointOptionsProperty;
    /**
    * index_field block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudsearch_domain#index_field AwsDomain#index_field}
    */
    readonly indexField?: AwsDomain.IndexFieldProperty[] | cdktn.IResolvable;
    /**
    * scaling_parameters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudsearch_domain#scaling_parameters AwsDomain#scaling_parameters}
    */
    readonly scalingParameters?: AwsDomain.ScalingParametersProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudsearch_domain#timeouts AwsDomain#timeouts}
    */
    readonly timeouts?: AwsDomain.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudsearch_domain aws_cloudsearch_domain}
*/
export declare class AwsDomain extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudsearch_domain";
    /**
    * Generates CDKTN code for importing a AwsDomain resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDomain to import
    * @param importFromId The id of the existing AwsDomain that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudsearch_domain#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDomain to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudsearch_domain aws_cloudsearch_domain} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDomainConfig
    */
    constructor(scope: Construct, id: string, config: AwsDomainConfig);
    get arn(): string;
    get documentServiceEndpoint(): string;
    get domainId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _multiAz?;
    get multiAz(): boolean | cdktn.IResolvable;
    set multiAz(value: boolean | cdktn.IResolvable);
    resetMultiAz(): void;
    get multiAzInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get searchServiceEndpoint(): string;
    private _endpointOptions;
    get endpointOptions(): AwsDomain.EndpointOptionsPropertyOutputReference;
    putEndpointOptions(value: AwsDomain.EndpointOptionsProperty): void;
    resetEndpointOptions(): void;
    get endpointOptionsInput(): AwsDomain.EndpointOptionsProperty | undefined;
    private _indexField;
    get indexField(): AwsDomain.IndexFieldPropertyList;
    putIndexField(value: AwsDomain.IndexFieldProperty[] | cdktn.IResolvable): void;
    resetIndexField(): void;
    get indexFieldInput(): cdktn.IResolvable | AwsDomain.IndexFieldProperty[] | undefined;
    private _scalingParameters;
    get scalingParameters(): AwsDomain.ScalingParametersPropertyOutputReference;
    putScalingParameters(value: AwsDomain.ScalingParametersProperty): void;
    resetScalingParameters(): void;
    get scalingParametersInput(): AwsDomain.ScalingParametersProperty | undefined;
    private _timeouts;
    get timeouts(): AwsDomain.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsDomain.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsDomain.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsDomainEndpointOptionsPropertyToTerraform(struct?: AwsDomain.EndpointOptionsPropertyOutputReference | AwsDomain.EndpointOptionsProperty): any;
export declare function awsDomainEndpointOptionsPropertyToHclTerraform(struct?: AwsDomain.EndpointOptionsPropertyOutputReference | AwsDomain.EndpointOptionsProperty): any;
export declare function awsDomainIndexFieldPropertyToTerraform(struct?: AwsDomain.IndexFieldProperty | cdktn.IResolvable): any;
export declare function awsDomainIndexFieldPropertyToHclTerraform(struct?: AwsDomain.IndexFieldProperty | cdktn.IResolvable): any;
export declare function awsDomainScalingParametersPropertyToTerraform(struct?: AwsDomain.ScalingParametersPropertyOutputReference | AwsDomain.ScalingParametersProperty): any;
export declare function awsDomainScalingParametersPropertyToHclTerraform(struct?: AwsDomain.ScalingParametersPropertyOutputReference | AwsDomain.ScalingParametersProperty): any;
export declare function awsDomainTimeoutsPropertyToTerraform(struct?: AwsDomain.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsDomainTimeoutsPropertyToHclTerraform(struct?: AwsDomain.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsDomain {
    interface EndpointOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudsearch_domain#enforce_https AwsDomain#enforce_https}
        */
        readonly enforceHttps?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudsearch_domain#tls_security_policy AwsDomain#tls_security_policy}
        */
        readonly tlsSecurityPolicy?: string;
    }
    class EndpointOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EndpointOptionsProperty | undefined;
        set internalValue(value: EndpointOptionsProperty | undefined);
        private _enforceHttps?;
        get enforceHttps(): boolean | cdktn.IResolvable;
        set enforceHttps(value: boolean | cdktn.IResolvable);
        resetEnforceHttps(): void;
        get enforceHttpsInput(): boolean | cdktn.IResolvable | undefined;
        private _tlsSecurityPolicy?;
        get tlsSecurityPolicy(): string;
        set tlsSecurityPolicy(value: string);
        resetTlsSecurityPolicy(): void;
        get tlsSecurityPolicyInput(): string | undefined;
    }
    interface IndexFieldProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudsearch_domain#analysis_scheme AwsDomain#analysis_scheme}
        */
        readonly analysisScheme?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudsearch_domain#default_value AwsDomain#default_value}
        */
        readonly defaultValue?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudsearch_domain#facet AwsDomain#facet}
        */
        readonly facet?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudsearch_domain#highlight AwsDomain#highlight}
        */
        readonly highlight?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudsearch_domain#name AwsDomain#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudsearch_domain#return AwsDomain#return}
        */
        readonly return?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudsearch_domain#search AwsDomain#search}
        */
        readonly search?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudsearch_domain#sort AwsDomain#sort}
        */
        readonly sort?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudsearch_domain#source_fields AwsDomain#source_fields}
        */
        readonly sourceFields?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudsearch_domain#type AwsDomain#type}
        */
        readonly type: string;
    }
    class IndexFieldPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IndexFieldProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IndexFieldProperty | cdktn.IResolvable | undefined);
        private _analysisScheme?;
        get analysisScheme(): string;
        set analysisScheme(value: string);
        resetAnalysisScheme(): void;
        get analysisSchemeInput(): string | undefined;
        private _defaultValue?;
        get defaultValue(): string;
        set defaultValue(value: string);
        resetDefaultValue(): void;
        get defaultValueInput(): string | undefined;
        private _facet?;
        get facet(): boolean | cdktn.IResolvable;
        set facet(value: boolean | cdktn.IResolvable);
        resetFacet(): void;
        get facetInput(): boolean | cdktn.IResolvable | undefined;
        private _highlight?;
        get highlight(): boolean | cdktn.IResolvable;
        set highlight(value: boolean | cdktn.IResolvable);
        resetHighlight(): void;
        get highlightInput(): boolean | cdktn.IResolvable | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _return?;
        get return(): boolean | cdktn.IResolvable;
        set return(value: boolean | cdktn.IResolvable);
        resetReturn(): void;
        get returnInput(): boolean | cdktn.IResolvable | undefined;
        private _search?;
        get search(): boolean | cdktn.IResolvable;
        set search(value: boolean | cdktn.IResolvable);
        resetSearch(): void;
        get searchInput(): boolean | cdktn.IResolvable | undefined;
        private _sort?;
        get sort(): boolean | cdktn.IResolvable;
        set sort(value: boolean | cdktn.IResolvable);
        resetSort(): void;
        get sortInput(): boolean | cdktn.IResolvable | undefined;
        private _sourceFields?;
        get sourceFields(): string;
        set sourceFields(value: string);
        resetSourceFields(): void;
        get sourceFieldsInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class IndexFieldPropertyList extends cdktn.ComplexList {
        internalValue?: IndexFieldProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IndexFieldPropertyOutputReference;
    }
    interface ScalingParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudsearch_domain#desired_instance_type AwsDomain#desired_instance_type}
        */
        readonly desiredInstanceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudsearch_domain#desired_partition_count AwsDomain#desired_partition_count}
        */
        readonly desiredPartitionCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudsearch_domain#desired_replication_count AwsDomain#desired_replication_count}
        */
        readonly desiredReplicationCount?: number;
    }
    class ScalingParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ScalingParametersProperty | undefined;
        set internalValue(value: ScalingParametersProperty | undefined);
        private _desiredInstanceType?;
        get desiredInstanceType(): string;
        set desiredInstanceType(value: string);
        resetDesiredInstanceType(): void;
        get desiredInstanceTypeInput(): string | undefined;
        private _desiredPartitionCount?;
        get desiredPartitionCount(): number;
        set desiredPartitionCount(value: number);
        resetDesiredPartitionCount(): void;
        get desiredPartitionCountInput(): number | undefined;
        private _desiredReplicationCount?;
        get desiredReplicationCount(): number;
        set desiredReplicationCount(value: number);
        resetDesiredReplicationCount(): void;
        get desiredReplicationCountInput(): number | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudsearch_domain#create AwsDomain#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudsearch_domain#delete AwsDomain#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudsearch_domain#update AwsDomain#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
