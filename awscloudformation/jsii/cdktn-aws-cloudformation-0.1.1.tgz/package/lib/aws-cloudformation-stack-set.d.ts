import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsCloudformationStackSetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set#administration_role_arn AwsCloudformationStackSet#administration_role_arn}
    */
    readonly administrationRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set#call_as AwsCloudformationStackSet#call_as}
    */
    readonly callAs?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set#capabilities AwsCloudformationStackSet#capabilities}
    */
    readonly capabilities?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set#description AwsCloudformationStackSet#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set#execution_role_name AwsCloudformationStackSet#execution_role_name}
    */
    readonly executionRoleName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set#id AwsCloudformationStackSet#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set#name AwsCloudformationStackSet#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set#parameters AwsCloudformationStackSet#parameters}
    */
    readonly parameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set#permission_model AwsCloudformationStackSet#permission_model}
    */
    readonly permissionModel?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set#region AwsCloudformationStackSet#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set#tags AwsCloudformationStackSet#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set#tags_all AwsCloudformationStackSet#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set#template_body AwsCloudformationStackSet#template_body}
    */
    readonly templateBody?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set#template_url AwsCloudformationStackSet#template_url}
    */
    readonly templateUrl?: string;
    /**
    * auto_deployment block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set#auto_deployment AwsCloudformationStackSet#auto_deployment}
    */
    readonly autoDeployment?: AwsCloudformationStackSet.AutoDeploymentProperty;
    /**
    * managed_execution block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set#managed_execution AwsCloudformationStackSet#managed_execution}
    */
    readonly managedExecution?: AwsCloudformationStackSet.ManagedExecutionProperty;
    /**
    * operation_preferences block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set#operation_preferences AwsCloudformationStackSet#operation_preferences}
    */
    readonly operationPreferences?: AwsCloudformationStackSet.OperationPreferencesProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set#timeouts AwsCloudformationStackSet#timeouts}
    */
    readonly timeouts?: AwsCloudformationStackSet.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set aws_cloudformation_stack_set}
*/
export declare class AwsCloudformationStackSet extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudformation_stack_set";
    /**
    * Generates CDKTN code for importing a AwsCloudformationStackSet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsCloudformationStackSet to import
    * @param importFromId The id of the existing AwsCloudformationStackSet that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsCloudformationStackSet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set aws_cloudformation_stack_set} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsCloudformationStackSetConfig
    */
    constructor(scope: Construct, id: string, config: AwsCloudformationStackSetConfig);
    private _administrationRoleArn?;
    get administrationRoleArn(): string;
    set administrationRoleArn(value: string);
    resetAdministrationRoleArn(): void;
    get administrationRoleArnInput(): string | undefined;
    get arn(): string;
    private _callAs?;
    get callAs(): string;
    set callAs(value: string);
    resetCallAs(): void;
    get callAsInput(): string | undefined;
    private _capabilities?;
    get capabilities(): string[];
    set capabilities(value: string[]);
    resetCapabilities(): void;
    get capabilitiesInput(): string[] | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _executionRoleName?;
    get executionRoleName(): string;
    set executionRoleName(value: string);
    resetExecutionRoleName(): void;
    get executionRoleNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parameters?;
    get parameters(): {
        [key: string]: string;
    };
    set parameters(value: {
        [key: string]: string;
    });
    resetParameters(): void;
    get parametersInput(): {
        [key: string]: string;
    } | undefined;
    private _permissionModel?;
    get permissionModel(): string;
    set permissionModel(value: string);
    resetPermissionModel(): void;
    get permissionModelInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get stackSetId(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _templateBody?;
    get templateBody(): string;
    set templateBody(value: string);
    resetTemplateBody(): void;
    get templateBodyInput(): string | undefined;
    private _templateUrl?;
    get templateUrl(): string;
    set templateUrl(value: string);
    resetTemplateUrl(): void;
    get templateUrlInput(): string | undefined;
    private _autoDeployment;
    get autoDeployment(): AwsCloudformationStackSet.AutoDeploymentPropertyOutputReference;
    putAutoDeployment(value: AwsCloudformationStackSet.AutoDeploymentProperty): void;
    resetAutoDeployment(): void;
    get autoDeploymentInput(): AwsCloudformationStackSet.AutoDeploymentProperty | undefined;
    private _managedExecution;
    get managedExecution(): AwsCloudformationStackSet.ManagedExecutionPropertyOutputReference;
    putManagedExecution(value: AwsCloudformationStackSet.ManagedExecutionProperty): void;
    resetManagedExecution(): void;
    get managedExecutionInput(): AwsCloudformationStackSet.ManagedExecutionProperty | undefined;
    private _operationPreferences;
    get operationPreferences(): AwsCloudformationStackSet.OperationPreferencesPropertyOutputReference;
    putOperationPreferences(value: AwsCloudformationStackSet.OperationPreferencesProperty): void;
    resetOperationPreferences(): void;
    get operationPreferencesInput(): AwsCloudformationStackSet.OperationPreferencesProperty | undefined;
    private _timeouts;
    get timeouts(): AwsCloudformationStackSet.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsCloudformationStackSet.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsCloudformationStackSet.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsCloudformationStackSetAutoDeploymentPropertyToTerraform(struct?: AwsCloudformationStackSet.AutoDeploymentPropertyOutputReference | AwsCloudformationStackSet.AutoDeploymentProperty): any;
export declare function awsCloudformationStackSetAutoDeploymentPropertyToHclTerraform(struct?: AwsCloudformationStackSet.AutoDeploymentPropertyOutputReference | AwsCloudformationStackSet.AutoDeploymentProperty): any;
export declare function awsCloudformationStackSetManagedExecutionPropertyToTerraform(struct?: AwsCloudformationStackSet.ManagedExecutionPropertyOutputReference | AwsCloudformationStackSet.ManagedExecutionProperty): any;
export declare function awsCloudformationStackSetManagedExecutionPropertyToHclTerraform(struct?: AwsCloudformationStackSet.ManagedExecutionPropertyOutputReference | AwsCloudformationStackSet.ManagedExecutionProperty): any;
export declare function awsCloudformationStackSetOperationPreferencesPropertyToTerraform(struct?: AwsCloudformationStackSet.OperationPreferencesPropertyOutputReference | AwsCloudformationStackSet.OperationPreferencesProperty): any;
export declare function awsCloudformationStackSetOperationPreferencesPropertyToHclTerraform(struct?: AwsCloudformationStackSet.OperationPreferencesPropertyOutputReference | AwsCloudformationStackSet.OperationPreferencesProperty): any;
export declare function awsCloudformationStackSetTimeoutsPropertyToTerraform(struct?: AwsCloudformationStackSet.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsCloudformationStackSetTimeoutsPropertyToHclTerraform(struct?: AwsCloudformationStackSet.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsCloudformationStackSet {
    interface AutoDeploymentProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set#depends_on_stack_sets AwsCloudformationStackSet#depends_on_stack_sets}
        */
        readonly dependsOnStackSets?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set#enabled AwsCloudformationStackSet#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set#retain_stacks_on_account_removal AwsCloudformationStackSet#retain_stacks_on_account_removal}
        */
        readonly retainStacksOnAccountRemoval?: boolean | cdktn.IResolvable;
    }
    class AutoDeploymentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AutoDeploymentProperty | undefined;
        set internalValue(value: AutoDeploymentProperty | undefined);
        private _dependsOnStackSets?;
        get dependsOnStackSets(): string[];
        set dependsOnStackSets(value: string[]);
        resetDependsOnStackSets(): void;
        get dependsOnStackSetsInput(): string[] | undefined;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _retainStacksOnAccountRemoval?;
        get retainStacksOnAccountRemoval(): boolean | cdktn.IResolvable;
        set retainStacksOnAccountRemoval(value: boolean | cdktn.IResolvable);
        resetRetainStacksOnAccountRemoval(): void;
        get retainStacksOnAccountRemovalInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface ManagedExecutionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set#active AwsCloudformationStackSet#active}
        */
        readonly active?: boolean | cdktn.IResolvable;
    }
    class ManagedExecutionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ManagedExecutionProperty | undefined;
        set internalValue(value: ManagedExecutionProperty | undefined);
        private _active?;
        get active(): boolean | cdktn.IResolvable;
        set active(value: boolean | cdktn.IResolvable);
        resetActive(): void;
        get activeInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface OperationPreferencesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set#failure_tolerance_count AwsCloudformationStackSet#failure_tolerance_count}
        */
        readonly failureToleranceCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set#failure_tolerance_percentage AwsCloudformationStackSet#failure_tolerance_percentage}
        */
        readonly failureTolerancePercentage?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set#max_concurrent_count AwsCloudformationStackSet#max_concurrent_count}
        */
        readonly maxConcurrentCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set#max_concurrent_percentage AwsCloudformationStackSet#max_concurrent_percentage}
        */
        readonly maxConcurrentPercentage?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set#region_concurrency_type AwsCloudformationStackSet#region_concurrency_type}
        */
        readonly regionConcurrencyType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set#region_order AwsCloudformationStackSet#region_order}
        */
        readonly regionOrder?: string[];
    }
    class OperationPreferencesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OperationPreferencesProperty | undefined;
        set internalValue(value: OperationPreferencesProperty | undefined);
        private _failureToleranceCount?;
        get failureToleranceCount(): number;
        set failureToleranceCount(value: number);
        resetFailureToleranceCount(): void;
        get failureToleranceCountInput(): number | undefined;
        private _failureTolerancePercentage?;
        get failureTolerancePercentage(): number;
        set failureTolerancePercentage(value: number);
        resetFailureTolerancePercentage(): void;
        get failureTolerancePercentageInput(): number | undefined;
        private _maxConcurrentCount?;
        get maxConcurrentCount(): number;
        set maxConcurrentCount(value: number);
        resetMaxConcurrentCount(): void;
        get maxConcurrentCountInput(): number | undefined;
        private _maxConcurrentPercentage?;
        get maxConcurrentPercentage(): number;
        set maxConcurrentPercentage(value: number);
        resetMaxConcurrentPercentage(): void;
        get maxConcurrentPercentageInput(): number | undefined;
        private _regionConcurrencyType?;
        get regionConcurrencyType(): string;
        set regionConcurrencyType(value: string);
        resetRegionConcurrencyType(): void;
        get regionConcurrencyTypeInput(): string | undefined;
        private _regionOrder?;
        get regionOrder(): string[];
        set regionOrder(value: string[]);
        resetRegionOrder(): void;
        get regionOrderInput(): string[] | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set#update AwsCloudformationStackSet#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
