import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfStackSetInstanceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set_instance#account_id TfStackSetInstance#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set_instance#call_as TfStackSetInstance#call_as}
    */
    readonly callAs?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set_instance#id TfStackSetInstance#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set_instance#parameter_overrides TfStackSetInstance#parameter_overrides}
    */
    readonly parameterOverrides?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set_instance#region TfStackSetInstance#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set_instance#retain_stack TfStackSetInstance#retain_stack}
    */
    readonly retainStack?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set_instance#stack_set_instance_region TfStackSetInstance#stack_set_instance_region}
    */
    readonly stackSetInstanceRegion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set_instance#stack_set_name TfStackSetInstance#stack_set_name}
    */
    readonly stackSetName: string;
    /**
    * deployment_targets block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set_instance#deployment_targets TfStackSetInstance#deployment_targets}
    */
    readonly deploymentTargets?: TfStackSetInstance.DeploymentTargetsProperty;
    /**
    * operation_preferences block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set_instance#operation_preferences TfStackSetInstance#operation_preferences}
    */
    readonly operationPreferences?: TfStackSetInstance.OperationPreferencesProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set_instance#timeouts TfStackSetInstance#timeouts}
    */
    readonly timeouts?: TfStackSetInstance.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set_instance aws_cloudformation_stack_set_instance}
*/
export declare class TfStackSetInstance extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudformation_stack_set_instance";
    /**
    * Generates CDKTN code for importing a TfStackSetInstance resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfStackSetInstance to import
    * @param importFromId The id of the existing TfStackSetInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfStackSetInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set_instance aws_cloudformation_stack_set_instance} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfStackSetInstanceConfig
    */
    constructor(scope: Construct, id: string, config: TfStackSetInstanceConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _callAs?;
    get callAs(): string;
    set callAs(value: string);
    resetCallAs(): void;
    get callAsInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get organizationalUnitId(): string;
    private _parameterOverrides?;
    get parameterOverrides(): {
        [key: string]: string;
    };
    set parameterOverrides(value: {
        [key: string]: string;
    });
    resetParameterOverrides(): void;
    get parameterOverridesInput(): {
        [key: string]: string;
    } | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _retainStack?;
    get retainStack(): boolean | cdktn.IResolvable;
    set retainStack(value: boolean | cdktn.IResolvable);
    resetRetainStack(): void;
    get retainStackInput(): boolean | cdktn.IResolvable | undefined;
    get stackId(): string;
    private _stackInstanceSummaries;
    get stackInstanceSummaries(): TfStackSetInstance.StackInstanceSummariesPropertyList;
    private _stackSetInstanceRegion?;
    get stackSetInstanceRegion(): string;
    set stackSetInstanceRegion(value: string);
    resetStackSetInstanceRegion(): void;
    get stackSetInstanceRegionInput(): string | undefined;
    private _stackSetName?;
    get stackSetName(): string;
    set stackSetName(value: string);
    get stackSetNameInput(): string | undefined;
    private _deploymentTargets;
    get deploymentTargets(): TfStackSetInstance.DeploymentTargetsPropertyOutputReference;
    putDeploymentTargets(value: TfStackSetInstance.DeploymentTargetsProperty): void;
    resetDeploymentTargets(): void;
    get deploymentTargetsInput(): TfStackSetInstance.DeploymentTargetsProperty | undefined;
    private _operationPreferences;
    get operationPreferences(): TfStackSetInstance.OperationPreferencesPropertyOutputReference;
    putOperationPreferences(value: TfStackSetInstance.OperationPreferencesProperty): void;
    resetOperationPreferences(): void;
    get operationPreferencesInput(): TfStackSetInstance.OperationPreferencesProperty | undefined;
    private _timeouts;
    get timeouts(): TfStackSetInstance.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfStackSetInstance.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfStackSetInstance.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfStackSetInstanceStackInstanceSummariesPropertyToTerraform(struct?: TfStackSetInstance.StackInstanceSummariesProperty): any;
export declare function tfStackSetInstanceStackInstanceSummariesPropertyToHclTerraform(struct?: TfStackSetInstance.StackInstanceSummariesProperty): any;
export declare function tfStackSetInstanceDeploymentTargetsPropertyToTerraform(struct?: TfStackSetInstance.DeploymentTargetsPropertyOutputReference | TfStackSetInstance.DeploymentTargetsProperty): any;
export declare function tfStackSetInstanceDeploymentTargetsPropertyToHclTerraform(struct?: TfStackSetInstance.DeploymentTargetsPropertyOutputReference | TfStackSetInstance.DeploymentTargetsProperty): any;
export declare function tfStackSetInstanceOperationPreferencesPropertyToTerraform(struct?: TfStackSetInstance.OperationPreferencesPropertyOutputReference | TfStackSetInstance.OperationPreferencesProperty): any;
export declare function tfStackSetInstanceOperationPreferencesPropertyToHclTerraform(struct?: TfStackSetInstance.OperationPreferencesPropertyOutputReference | TfStackSetInstance.OperationPreferencesProperty): any;
export declare function tfStackSetInstanceTimeoutsPropertyToTerraform(struct?: TfStackSetInstance.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfStackSetInstanceTimeoutsPropertyToHclTerraform(struct?: TfStackSetInstance.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfStackSetInstance {
    interface StackInstanceSummariesProperty {
    }
    class StackInstanceSummariesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StackInstanceSummariesProperty | undefined;
        set internalValue(value: StackInstanceSummariesProperty | undefined);
        get accountId(): string;
        get organizationalUnitId(): string;
        get stackId(): string;
    }
    class StackInstanceSummariesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StackInstanceSummariesPropertyOutputReference;
    }
    interface DeploymentTargetsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set_instance#account_filter_type TfStackSetInstance#account_filter_type}
        */
        readonly accountFilterType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set_instance#accounts TfStackSetInstance#accounts}
        */
        readonly accounts?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set_instance#accounts_url TfStackSetInstance#accounts_url}
        */
        readonly accountsUrl?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set_instance#organizational_unit_ids TfStackSetInstance#organizational_unit_ids}
        */
        readonly organizationalUnitIds?: string[];
    }
    class DeploymentTargetsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DeploymentTargetsProperty | undefined;
        set internalValue(value: DeploymentTargetsProperty | undefined);
        private _accountFilterType?;
        get accountFilterType(): string;
        set accountFilterType(value: string);
        resetAccountFilterType(): void;
        get accountFilterTypeInput(): string | undefined;
        private _accounts?;
        get accounts(): string[];
        set accounts(value: string[]);
        resetAccounts(): void;
        get accountsInput(): string[] | undefined;
        private _accountsUrl?;
        get accountsUrl(): string;
        set accountsUrl(value: string);
        resetAccountsUrl(): void;
        get accountsUrlInput(): string | undefined;
        private _organizationalUnitIds?;
        get organizationalUnitIds(): string[];
        set organizationalUnitIds(value: string[]);
        resetOrganizationalUnitIds(): void;
        get organizationalUnitIdsInput(): string[] | undefined;
    }
    interface OperationPreferencesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set_instance#concurrency_mode TfStackSetInstance#concurrency_mode}
        */
        readonly concurrencyMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set_instance#failure_tolerance_count TfStackSetInstance#failure_tolerance_count}
        */
        readonly failureToleranceCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set_instance#failure_tolerance_percentage TfStackSetInstance#failure_tolerance_percentage}
        */
        readonly failureTolerancePercentage?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set_instance#max_concurrent_count TfStackSetInstance#max_concurrent_count}
        */
        readonly maxConcurrentCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set_instance#max_concurrent_percentage TfStackSetInstance#max_concurrent_percentage}
        */
        readonly maxConcurrentPercentage?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set_instance#region_concurrency_type TfStackSetInstance#region_concurrency_type}
        */
        readonly regionConcurrencyType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set_instance#region_order TfStackSetInstance#region_order}
        */
        readonly regionOrder?: string[];
    }
    class OperationPreferencesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OperationPreferencesProperty | undefined;
        set internalValue(value: OperationPreferencesProperty | undefined);
        private _concurrencyMode?;
        get concurrencyMode(): string;
        set concurrencyMode(value: string);
        resetConcurrencyMode(): void;
        get concurrencyModeInput(): string | undefined;
        private _failureToleranceCount?;
        get failureToleranceCount(): number;
        set failureToleranceCount(value: number);
        resetFailureToleranceCount(): void;
        get failureToleranceCountInput(): number | undefined;
        private _failureTolerancePercentage?;
        get failureTolerancePercentage(): number;
        set failureTolerancePercentage(value: number);
        resetFailureTolerancePercentage(): void;
        get failureTolerancePercentageInput(): number | undefined;
        private _maxConcurrentCount?;
        get maxConcurrentCount(): number;
        set maxConcurrentCount(value: number);
        resetMaxConcurrentCount(): void;
        get maxConcurrentCountInput(): number | undefined;
        private _maxConcurrentPercentage?;
        get maxConcurrentPercentage(): number;
        set maxConcurrentPercentage(value: number);
        resetMaxConcurrentPercentage(): void;
        get maxConcurrentPercentageInput(): number | undefined;
        private _regionConcurrencyType?;
        get regionConcurrencyType(): string;
        set regionConcurrencyType(value: string);
        resetRegionConcurrencyType(): void;
        get regionConcurrencyTypeInput(): string | undefined;
        private _regionOrder?;
        get regionOrder(): string[];
        set regionOrder(value: string[]);
        resetRegionOrder(): void;
        get regionOrderInput(): string[] | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set_instance#create TfStackSetInstance#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set_instance#delete TfStackSetInstance#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_set_instance#update TfStackSetInstance#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
