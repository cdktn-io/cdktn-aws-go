import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsPipelineDefinitionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datapipeline_pipeline_definition#id AwsPipelineDefinition#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datapipeline_pipeline_definition#pipeline_id AwsPipelineDefinition#pipeline_id}
    */
    readonly pipelineId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datapipeline_pipeline_definition#region AwsPipelineDefinition#region}
    */
    readonly region?: string;
    /**
    * parameter_object block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datapipeline_pipeline_definition#parameter_object AwsPipelineDefinition#parameter_object}
    */
    readonly parameterObject?: AwsPipelineDefinition.ParameterObjectProperty[] | cdktn.IResolvable;
    /**
    * parameter_value block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datapipeline_pipeline_definition#parameter_value AwsPipelineDefinition#parameter_value}
    */
    readonly parameterValue?: AwsPipelineDefinition.ParameterValueProperty[] | cdktn.IResolvable;
    /**
    * pipeline_object block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datapipeline_pipeline_definition#pipeline_object AwsPipelineDefinition#pipeline_object}
    */
    readonly pipelineObject: AwsPipelineDefinition.PipelineObjectProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datapipeline_pipeline_definition aws_datapipeline_pipeline_definition}
*/
export declare class AwsPipelineDefinition extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_datapipeline_pipeline_definition";
    /**
    * Generates CDKTN code for importing a AwsPipelineDefinition resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsPipelineDefinition to import
    * @param importFromId The id of the existing AwsPipelineDefinition that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datapipeline_pipeline_definition#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsPipelineDefinition to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datapipeline_pipeline_definition aws_datapipeline_pipeline_definition} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsPipelineDefinitionConfig
    */
    constructor(scope: Construct, id: string, config: AwsPipelineDefinitionConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _pipelineId?;
    get pipelineId(): string;
    set pipelineId(value: string);
    get pipelineIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _parameterObject;
    get parameterObject(): AwsPipelineDefinition.ParameterObjectPropertyList;
    putParameterObject(value: AwsPipelineDefinition.ParameterObjectProperty[] | cdktn.IResolvable): void;
    resetParameterObject(): void;
    get parameterObjectInput(): cdktn.IResolvable | AwsPipelineDefinition.ParameterObjectProperty[] | undefined;
    private _parameterValue;
    get parameterValue(): AwsPipelineDefinition.ParameterValuePropertyList;
    putParameterValue(value: AwsPipelineDefinition.ParameterValueProperty[] | cdktn.IResolvable): void;
    resetParameterValue(): void;
    get parameterValueInput(): cdktn.IResolvable | AwsPipelineDefinition.ParameterValueProperty[] | undefined;
    private _pipelineObject;
    get pipelineObject(): AwsPipelineDefinition.PipelineObjectPropertyList;
    putPipelineObject(value: AwsPipelineDefinition.PipelineObjectProperty[] | cdktn.IResolvable): void;
    get pipelineObjectInput(): cdktn.IResolvable | AwsPipelineDefinition.PipelineObjectProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsPipelineDefinitionAttributePropertyToTerraform(struct?: AwsPipelineDefinition.AttributeProperty | cdktn.IResolvable): any;
export declare function awsPipelineDefinitionAttributePropertyToHclTerraform(struct?: AwsPipelineDefinition.AttributeProperty | cdktn.IResolvable): any;
export declare function awsPipelineDefinitionParameterObjectPropertyToTerraform(struct?: AwsPipelineDefinition.ParameterObjectProperty | cdktn.IResolvable): any;
export declare function awsPipelineDefinitionParameterObjectPropertyToHclTerraform(struct?: AwsPipelineDefinition.ParameterObjectProperty | cdktn.IResolvable): any;
export declare function awsPipelineDefinitionParameterValuePropertyToTerraform(struct?: AwsPipelineDefinition.ParameterValueProperty | cdktn.IResolvable): any;
export declare function awsPipelineDefinitionParameterValuePropertyToHclTerraform(struct?: AwsPipelineDefinition.ParameterValueProperty | cdktn.IResolvable): any;
export declare function awsPipelineDefinitionFieldPropertyToTerraform(struct?: AwsPipelineDefinition.FieldProperty | cdktn.IResolvable): any;
export declare function awsPipelineDefinitionFieldPropertyToHclTerraform(struct?: AwsPipelineDefinition.FieldProperty | cdktn.IResolvable): any;
export declare function awsPipelineDefinitionPipelineObjectPropertyToTerraform(struct?: AwsPipelineDefinition.PipelineObjectProperty | cdktn.IResolvable): any;
export declare function awsPipelineDefinitionPipelineObjectPropertyToHclTerraform(struct?: AwsPipelineDefinition.PipelineObjectProperty | cdktn.IResolvable): any;
export declare namespace AwsPipelineDefinition {
    interface AttributeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datapipeline_pipeline_definition#key AwsPipelineDefinition#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datapipeline_pipeline_definition#string_value AwsPipelineDefinition#string_value}
        */
        readonly stringValue: string;
    }
    class AttributePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AttributeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AttributeProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _stringValue?;
        get stringValue(): string;
        set stringValue(value: string);
        get stringValueInput(): string | undefined;
    }
    class AttributePropertyList extends cdktn.ComplexList {
        internalValue?: AttributeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AttributePropertyOutputReference;
    }
    interface ParameterObjectProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datapipeline_pipeline_definition#id AwsPipelineDefinition#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id: string;
        /**
        * attribute block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datapipeline_pipeline_definition#attribute AwsPipelineDefinition#attribute}
        */
        readonly attribute?: AttributeProperty[] | cdktn.IResolvable;
    }
    class ParameterObjectPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ParameterObjectProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ParameterObjectProperty | cdktn.IResolvable | undefined);
        private _id?;
        get id(): string;
        set id(value: string);
        get idInput(): string | undefined;
        private _attribute;
        get attribute(): AttributePropertyList;
        putAttribute(value: AttributeProperty[] | cdktn.IResolvable): void;
        resetAttribute(): void;
        get attributeInput(): cdktn.IResolvable | AttributeProperty[] | undefined;
    }
    class ParameterObjectPropertyList extends cdktn.ComplexList {
        internalValue?: ParameterObjectProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ParameterObjectPropertyOutputReference;
    }
    interface ParameterValueProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datapipeline_pipeline_definition#id AwsPipelineDefinition#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datapipeline_pipeline_definition#string_value AwsPipelineDefinition#string_value}
        */
        readonly stringValue: string;
    }
    class ParameterValuePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ParameterValueProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ParameterValueProperty | cdktn.IResolvable | undefined);
        private _id?;
        get id(): string;
        set id(value: string);
        get idInput(): string | undefined;
        private _stringValue?;
        get stringValue(): string;
        set stringValue(value: string);
        get stringValueInput(): string | undefined;
    }
    class ParameterValuePropertyList extends cdktn.ComplexList {
        internalValue?: ParameterValueProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ParameterValuePropertyOutputReference;
    }
    interface FieldProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datapipeline_pipeline_definition#key AwsPipelineDefinition#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datapipeline_pipeline_definition#ref_value AwsPipelineDefinition#ref_value}
        */
        readonly refValue?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datapipeline_pipeline_definition#string_value AwsPipelineDefinition#string_value}
        */
        readonly stringValue?: string;
    }
    class FieldPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FieldProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FieldProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _refValue?;
        get refValue(): string;
        set refValue(value: string);
        resetRefValue(): void;
        get refValueInput(): string | undefined;
        private _stringValue?;
        get stringValue(): string;
        set stringValue(value: string);
        resetStringValue(): void;
        get stringValueInput(): string | undefined;
    }
    class FieldPropertyList extends cdktn.ComplexList {
        internalValue?: FieldProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FieldPropertyOutputReference;
    }
    interface PipelineObjectProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datapipeline_pipeline_definition#id AwsPipelineDefinition#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datapipeline_pipeline_definition#name AwsPipelineDefinition#name}
        */
        readonly name: string;
        /**
        * field block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datapipeline_pipeline_definition#field AwsPipelineDefinition#field}
        */
        readonly field?: FieldProperty[] | cdktn.IResolvable;
    }
    class PipelineObjectPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PipelineObjectProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PipelineObjectProperty | cdktn.IResolvable | undefined);
        private _id?;
        get id(): string;
        set id(value: string);
        get idInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _field;
        get field(): FieldPropertyList;
        putField(value: FieldProperty[] | cdktn.IResolvable): void;
        resetField(): void;
        get fieldInput(): cdktn.IResolvable | FieldProperty[] | undefined;
    }
    class PipelineObjectPropertyList extends cdktn.ComplexList {
        internalValue?: PipelineObjectProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PipelineObjectPropertyOutputReference;
    }
}
