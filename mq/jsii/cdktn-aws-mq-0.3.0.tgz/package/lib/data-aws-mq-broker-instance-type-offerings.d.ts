import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsBrokerInstanceTypeOfferingsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/mq_broker_instance_type_offerings#engine_type DataAwsBrokerInstanceTypeOfferings#engine_type}
    */
    readonly engineType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/mq_broker_instance_type_offerings#host_instance_type DataAwsBrokerInstanceTypeOfferings#host_instance_type}
    */
    readonly hostInstanceType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/mq_broker_instance_type_offerings#id DataAwsBrokerInstanceTypeOfferings#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/mq_broker_instance_type_offerings#region DataAwsBrokerInstanceTypeOfferings#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/mq_broker_instance_type_offerings#storage_type DataAwsBrokerInstanceTypeOfferings#storage_type}
    */
    readonly storageType?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/mq_broker_instance_type_offerings aws_mq_broker_instance_type_offerings}
*/
export declare class DataAwsBrokerInstanceTypeOfferings extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_mq_broker_instance_type_offerings";
    /**
    * Generates CDKTN code for importing a DataAwsBrokerInstanceTypeOfferings resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsBrokerInstanceTypeOfferings to import
    * @param importFromId The id of the existing DataAwsBrokerInstanceTypeOfferings that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/mq_broker_instance_type_offerings#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsBrokerInstanceTypeOfferings to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/mq_broker_instance_type_offerings aws_mq_broker_instance_type_offerings} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsBrokerInstanceTypeOfferingsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsBrokerInstanceTypeOfferingsConfig);
    private _brokerInstanceOptions;
    get brokerInstanceOptions(): DataAwsBrokerInstanceTypeOfferings.BrokerInstanceOptionsPropertyList;
    private _engineType?;
    get engineType(): string;
    set engineType(value: string);
    resetEngineType(): void;
    get engineTypeInput(): string | undefined;
    private _hostInstanceType?;
    get hostInstanceType(): string;
    set hostInstanceType(value: string);
    resetHostInstanceType(): void;
    get hostInstanceTypeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _storageType?;
    get storageType(): string;
    set storageType(value: string);
    resetStorageType(): void;
    get storageTypeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsBrokerInstanceTypeOfferingsAvailabilityZonesPropertyToTerraform(struct?: DataAwsBrokerInstanceTypeOfferings.AvailabilityZonesProperty): any;
export declare function dataAwsBrokerInstanceTypeOfferingsAvailabilityZonesPropertyToHclTerraform(struct?: DataAwsBrokerInstanceTypeOfferings.AvailabilityZonesProperty): any;
export declare function dataAwsBrokerInstanceTypeOfferingsBrokerInstanceOptionsPropertyToTerraform(struct?: DataAwsBrokerInstanceTypeOfferings.BrokerInstanceOptionsProperty): any;
export declare function dataAwsBrokerInstanceTypeOfferingsBrokerInstanceOptionsPropertyToHclTerraform(struct?: DataAwsBrokerInstanceTypeOfferings.BrokerInstanceOptionsProperty): any;
export declare namespace DataAwsBrokerInstanceTypeOfferings {
    interface AvailabilityZonesProperty {
    }
    class AvailabilityZonesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AvailabilityZonesProperty | undefined;
        set internalValue(value: AvailabilityZonesProperty | undefined);
        get name(): string;
    }
    class AvailabilityZonesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AvailabilityZonesPropertyOutputReference;
    }
    interface BrokerInstanceOptionsProperty {
    }
    class BrokerInstanceOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BrokerInstanceOptionsProperty | undefined;
        set internalValue(value: BrokerInstanceOptionsProperty | undefined);
        private _availabilityZones;
        get availabilityZones(): AvailabilityZonesPropertyList;
        get engineType(): string;
        get hostInstanceType(): string;
        get storageType(): string;
        get supportedDeploymentModes(): string[];
        get supportedEngineVersions(): string[];
    }
    class BrokerInstanceOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BrokerInstanceOptionsPropertyOutputReference;
    }
}
