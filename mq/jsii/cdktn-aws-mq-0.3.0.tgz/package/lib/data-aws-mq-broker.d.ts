import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsBrokerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/mq_broker#broker_id DataAwsBroker#broker_id}
    */
    readonly brokerId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/mq_broker#broker_name DataAwsBroker#broker_name}
    */
    readonly brokerName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/mq_broker#id DataAwsBroker#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/mq_broker#region DataAwsBroker#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/mq_broker#tags DataAwsBroker#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/mq_broker aws_mq_broker}
*/
export declare class DataAwsBroker extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_mq_broker";
    /**
    * Generates CDKTN code for importing a DataAwsBroker resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsBroker to import
    * @param importFromId The id of the existing DataAwsBroker that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/mq_broker#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsBroker to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/mq_broker aws_mq_broker} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsBrokerConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsBrokerConfig);
    get arn(): string;
    get authenticationStrategy(): string;
    get autoMinorVersionUpgrade(): cdktn.IResolvable;
    private _brokerId?;
    get brokerId(): string;
    set brokerId(value: string);
    resetBrokerId(): void;
    get brokerIdInput(): string | undefined;
    private _brokerName?;
    get brokerName(): string;
    set brokerName(value: string);
    resetBrokerName(): void;
    get brokerNameInput(): string | undefined;
    private _configuration;
    get configuration(): DataAwsBroker.ConfigurationPropertyList;
    get deploymentMode(): string;
    private _encryptionOptions;
    get encryptionOptions(): DataAwsBroker.EncryptionOptionsPropertyList;
    get engineType(): string;
    get engineVersion(): string;
    get hostInstanceType(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instances;
    get instances(): DataAwsBroker.InstancesPropertyList;
    private _ldapServerMetadata;
    get ldapServerMetadata(): DataAwsBroker.LdapServerMetadataPropertyList;
    private _logs;
    get logs(): DataAwsBroker.LogsPropertyList;
    private _maintenanceWindowStartTime;
    get maintenanceWindowStartTime(): DataAwsBroker.MaintenanceWindowStartTimePropertyList;
    get publiclyAccessible(): cdktn.IResolvable;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get resourceShareArns(): string[];
    get securityGroups(): string[];
    private _sharedResources;
    get sharedResources(): DataAwsBroker.SharedResourcesPropertyList;
    get storageType(): string;
    get subnetIds(): string[];
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _user;
    get user(): DataAwsBroker.UserPropertyList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsBrokerConfigurationPropertyToTerraform(struct?: DataAwsBroker.ConfigurationProperty): any;
export declare function dataAwsBrokerConfigurationPropertyToHclTerraform(struct?: DataAwsBroker.ConfigurationProperty): any;
export declare function dataAwsBrokerEncryptionOptionsPropertyToTerraform(struct?: DataAwsBroker.EncryptionOptionsProperty): any;
export declare function dataAwsBrokerEncryptionOptionsPropertyToHclTerraform(struct?: DataAwsBroker.EncryptionOptionsProperty): any;
export declare function dataAwsBrokerInstancesPropertyToTerraform(struct?: DataAwsBroker.InstancesProperty): any;
export declare function dataAwsBrokerInstancesPropertyToHclTerraform(struct?: DataAwsBroker.InstancesProperty): any;
export declare function dataAwsBrokerLdapServerMetadataPropertyToTerraform(struct?: DataAwsBroker.LdapServerMetadataProperty): any;
export declare function dataAwsBrokerLdapServerMetadataPropertyToHclTerraform(struct?: DataAwsBroker.LdapServerMetadataProperty): any;
export declare function dataAwsBrokerLogsPropertyToTerraform(struct?: DataAwsBroker.LogsProperty): any;
export declare function dataAwsBrokerLogsPropertyToHclTerraform(struct?: DataAwsBroker.LogsProperty): any;
export declare function dataAwsBrokerMaintenanceWindowStartTimePropertyToTerraform(struct?: DataAwsBroker.MaintenanceWindowStartTimeProperty): any;
export declare function dataAwsBrokerMaintenanceWindowStartTimePropertyToHclTerraform(struct?: DataAwsBroker.MaintenanceWindowStartTimeProperty): any;
export declare function dataAwsBrokerSharedResourcesPropertyToTerraform(struct?: DataAwsBroker.SharedResourcesProperty): any;
export declare function dataAwsBrokerSharedResourcesPropertyToHclTerraform(struct?: DataAwsBroker.SharedResourcesProperty): any;
export declare function dataAwsBrokerUserPropertyToTerraform(struct?: DataAwsBroker.UserProperty): any;
export declare function dataAwsBrokerUserPropertyToHclTerraform(struct?: DataAwsBroker.UserProperty): any;
export declare namespace DataAwsBroker {
    interface ConfigurationProperty {
    }
    class ConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConfigurationProperty | undefined;
        set internalValue(value: ConfigurationProperty | undefined);
        get id(): string;
        get revision(): number;
    }
    class ConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConfigurationPropertyOutputReference;
    }
    interface EncryptionOptionsProperty {
    }
    class EncryptionOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EncryptionOptionsProperty | undefined;
        set internalValue(value: EncryptionOptionsProperty | undefined);
        get kmsKeyId(): string;
        get useAwsOwnedKey(): cdktn.IResolvable;
    }
    class EncryptionOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EncryptionOptionsPropertyOutputReference;
    }
    interface InstancesProperty {
    }
    class InstancesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InstancesProperty | undefined;
        set internalValue(value: InstancesProperty | undefined);
        get consoleUrl(): string;
        get endpoints(): string[];
        get ipAddress(): string;
    }
    class InstancesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InstancesPropertyOutputReference;
    }
    interface LdapServerMetadataProperty {
    }
    class LdapServerMetadataPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LdapServerMetadataProperty | undefined;
        set internalValue(value: LdapServerMetadataProperty | undefined);
        get hosts(): string[];
        get roleBase(): string;
        get roleName(): string;
        get roleSearchMatching(): string;
        get roleSearchSubtree(): cdktn.IResolvable;
        get serviceAccountPassword(): string;
        get serviceAccountUsername(): string;
        get userBase(): string;
        get userRoleName(): string;
        get userSearchMatching(): string;
        get userSearchSubtree(): cdktn.IResolvable;
    }
    class LdapServerMetadataPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LdapServerMetadataPropertyOutputReference;
    }
    interface LogsProperty {
    }
    class LogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LogsProperty | undefined;
        set internalValue(value: LogsProperty | undefined);
        get audit(): string;
        get general(): cdktn.IResolvable;
    }
    class LogsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LogsPropertyOutputReference;
    }
    interface MaintenanceWindowStartTimeProperty {
    }
    class MaintenanceWindowStartTimePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MaintenanceWindowStartTimeProperty | undefined;
        set internalValue(value: MaintenanceWindowStartTimeProperty | undefined);
        get dayOfWeek(): string;
        get timeOfDay(): string;
        get timeZone(): string;
    }
    class MaintenanceWindowStartTimePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MaintenanceWindowStartTimePropertyOutputReference;
    }
    interface SharedResourcesProperty {
    }
    class SharedResourcesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SharedResourcesProperty | undefined;
        set internalValue(value: SharedResourcesProperty | undefined);
        get dnsNames(): string[];
        get resourceArn(): string;
        get status(): string;
        get type(): string;
    }
    class SharedResourcesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SharedResourcesPropertyOutputReference;
    }
    interface UserProperty {
    }
    class UserPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): UserProperty | undefined;
        set internalValue(value: UserProperty | undefined);
        get consoleAccess(): cdktn.IResolvable;
        get groups(): string[];
        get replicationUser(): cdktn.IResolvable;
        get username(): string;
    }
    class UserPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): UserPropertyOutputReference;
    }
}
