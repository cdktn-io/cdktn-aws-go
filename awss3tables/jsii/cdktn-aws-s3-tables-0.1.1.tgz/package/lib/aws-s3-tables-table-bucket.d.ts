import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsS3TablesTableBucketConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3tables_table_bucket#encryption_configuration AwsS3TablesTableBucket#encryption_configuration}
    */
    readonly encryptionConfiguration?: AwsS3TablesTableBucket.EncryptionConfigurationProperty;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3tables_table_bucket#force_destroy AwsS3TablesTableBucket#force_destroy}
    */
    readonly forceDestroy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3tables_table_bucket#maintenance_configuration AwsS3TablesTableBucket#maintenance_configuration}
    */
    readonly maintenanceConfiguration?: AwsS3TablesTableBucket.MaintenanceConfigurationProperty;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3tables_table_bucket#name AwsS3TablesTableBucket#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3tables_table_bucket#region AwsS3TablesTableBucket#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3tables_table_bucket#tags AwsS3TablesTableBucket#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3tables_table_bucket aws_s3tables_table_bucket}
*/
export declare class AwsS3TablesTableBucket extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_s3tables_table_bucket";
    /**
    * Generates CDKTN code for importing a AwsS3TablesTableBucket resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsS3TablesTableBucket to import
    * @param importFromId The id of the existing AwsS3TablesTableBucket that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3tables_table_bucket#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsS3TablesTableBucket to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3tables_table_bucket aws_s3tables_table_bucket} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsS3TablesTableBucketConfig
    */
    constructor(scope: Construct, id: string, config: AwsS3TablesTableBucketConfig);
    get arn(): string;
    get createdAt(): string;
    private _encryptionConfiguration;
    get encryptionConfiguration(): AwsS3TablesTableBucket.EncryptionConfigurationPropertyOutputReference;
    putEncryptionConfiguration(value: AwsS3TablesTableBucket.EncryptionConfigurationProperty): void;
    resetEncryptionConfiguration(): void;
    get encryptionConfigurationInput(): cdktn.IResolvable | AwsS3TablesTableBucket.EncryptionConfigurationProperty | undefined;
    private _forceDestroy?;
    get forceDestroy(): boolean | cdktn.IResolvable;
    set forceDestroy(value: boolean | cdktn.IResolvable);
    resetForceDestroy(): void;
    get forceDestroyInput(): boolean | cdktn.IResolvable | undefined;
    private _maintenanceConfiguration;
    get maintenanceConfiguration(): AwsS3TablesTableBucket.MaintenanceConfigurationPropertyOutputReference;
    putMaintenanceConfiguration(value: AwsS3TablesTableBucket.MaintenanceConfigurationProperty): void;
    resetMaintenanceConfiguration(): void;
    get maintenanceConfigurationInput(): cdktn.IResolvable | AwsS3TablesTableBucket.MaintenanceConfigurationProperty | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get ownerAccountId(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsS3TablesTableBucketEncryptionConfigurationPropertyToTerraform(struct?: AwsS3TablesTableBucket.EncryptionConfigurationProperty | cdktn.IResolvable): any;
export declare function awsS3TablesTableBucketEncryptionConfigurationPropertyToHclTerraform(struct?: AwsS3TablesTableBucket.EncryptionConfigurationProperty | cdktn.IResolvable): any;
export declare function awsS3TablesTableBucketSettingsPropertyToTerraform(struct?: AwsS3TablesTableBucket.SettingsProperty | cdktn.IResolvable): any;
export declare function awsS3TablesTableBucketSettingsPropertyToHclTerraform(struct?: AwsS3TablesTableBucket.SettingsProperty | cdktn.IResolvable): any;
export declare function awsS3TablesTableBucketIcebergUnreferencedFileRemovalPropertyToTerraform(struct?: AwsS3TablesTableBucket.IcebergUnreferencedFileRemovalProperty | cdktn.IResolvable): any;
export declare function awsS3TablesTableBucketIcebergUnreferencedFileRemovalPropertyToHclTerraform(struct?: AwsS3TablesTableBucket.IcebergUnreferencedFileRemovalProperty | cdktn.IResolvable): any;
export declare function awsS3TablesTableBucketMaintenanceConfigurationPropertyToTerraform(struct?: AwsS3TablesTableBucket.MaintenanceConfigurationProperty | cdktn.IResolvable): any;
export declare function awsS3TablesTableBucketMaintenanceConfigurationPropertyToHclTerraform(struct?: AwsS3TablesTableBucket.MaintenanceConfigurationProperty | cdktn.IResolvable): any;
export declare namespace AwsS3TablesTableBucket {
    interface EncryptionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3tables_table_bucket#kms_key_arn AwsS3TablesTableBucket#kms_key_arn}
        */
        readonly kmsKeyArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3tables_table_bucket#sse_algorithm AwsS3TablesTableBucket#sse_algorithm}
        */
        readonly sseAlgorithm?: string;
    }
    class EncryptionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncryptionConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EncryptionConfigurationProperty | cdktn.IResolvable | undefined);
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        resetKmsKeyArn(): void;
        get kmsKeyArnInput(): string | undefined;
        private _sseAlgorithm?;
        get sseAlgorithm(): string;
        set sseAlgorithm(value: string);
        resetSseAlgorithm(): void;
        get sseAlgorithmInput(): string | undefined;
    }
    interface SettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3tables_table_bucket#non_current_days AwsS3TablesTableBucket#non_current_days}
        */
        readonly nonCurrentDays?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3tables_table_bucket#unreferenced_days AwsS3TablesTableBucket#unreferenced_days}
        */
        readonly unreferencedDays?: number;
    }
    class SettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SettingsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SettingsProperty | cdktn.IResolvable | undefined);
        private _nonCurrentDays?;
        get nonCurrentDays(): number;
        set nonCurrentDays(value: number);
        resetNonCurrentDays(): void;
        get nonCurrentDaysInput(): number | undefined;
        private _unreferencedDays?;
        get unreferencedDays(): number;
        set unreferencedDays(value: number);
        resetUnreferencedDays(): void;
        get unreferencedDaysInput(): number | undefined;
    }
    interface IcebergUnreferencedFileRemovalProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3tables_table_bucket#settings AwsS3TablesTableBucket#settings}
        */
        readonly settings?: SettingsProperty;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3tables_table_bucket#status AwsS3TablesTableBucket#status}
        */
        readonly status?: string;
    }
    class IcebergUnreferencedFileRemovalPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IcebergUnreferencedFileRemovalProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IcebergUnreferencedFileRemovalProperty | cdktn.IResolvable | undefined);
        private _settings;
        get settings(): SettingsPropertyOutputReference;
        putSettings(value: SettingsProperty): void;
        resetSettings(): void;
        get settingsInput(): cdktn.IResolvable | SettingsProperty | undefined;
        private _status?;
        get status(): string;
        set status(value: string);
        resetStatus(): void;
        get statusInput(): string | undefined;
    }
    interface MaintenanceConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3tables_table_bucket#iceberg_unreferenced_file_removal AwsS3TablesTableBucket#iceberg_unreferenced_file_removal}
        */
        readonly icebergUnreferencedFileRemoval?: IcebergUnreferencedFileRemovalProperty;
    }
    class MaintenanceConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MaintenanceConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MaintenanceConfigurationProperty | cdktn.IResolvable | undefined);
        private _icebergUnreferencedFileRemoval;
        get icebergUnreferencedFileRemoval(): IcebergUnreferencedFileRemovalPropertyOutputReference;
        putIcebergUnreferencedFileRemoval(value: IcebergUnreferencedFileRemovalProperty): void;
        resetIcebergUnreferencedFileRemoval(): void;
        get icebergUnreferencedFileRemovalInput(): cdktn.IResolvable | IcebergUnreferencedFileRemovalProperty | undefined;
    }
}
