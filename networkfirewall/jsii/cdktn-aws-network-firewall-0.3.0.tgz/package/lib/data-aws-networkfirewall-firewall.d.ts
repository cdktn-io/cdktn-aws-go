import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsFirewallConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkfirewall_firewall#arn DataAwsFirewall#arn}
    */
    readonly arn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkfirewall_firewall#id DataAwsFirewall#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkfirewall_firewall#name DataAwsFirewall#name}
    */
    readonly name?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkfirewall_firewall#region DataAwsFirewall#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkfirewall_firewall#tags DataAwsFirewall#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkfirewall_firewall aws_networkfirewall_firewall}
*/
export declare class DataAwsFirewall extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_networkfirewall_firewall";
    /**
    * Generates CDKTN code for importing a DataAwsFirewall resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsFirewall to import
    * @param importFromId The id of the existing DataAwsFirewall that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkfirewall_firewall#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsFirewall to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkfirewall_firewall aws_networkfirewall_firewall} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsFirewallConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsFirewallConfig);
    private _arn?;
    get arn(): string;
    set arn(value: string);
    resetArn(): void;
    get arnInput(): string | undefined;
    get availabilityZoneChangeProtection(): cdktn.IResolvable;
    private _availabilityZoneMapping;
    get availabilityZoneMapping(): DataAwsFirewall.AvailabilityZoneMappingPropertyList;
    get deleteProtection(): cdktn.IResolvable;
    get description(): string;
    get enabledAnalysisTypes(): string[];
    private _encryptionConfiguration;
    get encryptionConfiguration(): DataAwsFirewall.EncryptionConfigurationPropertyList;
    get firewallPolicyArn(): string;
    get firewallPolicyChangeProtection(): cdktn.IResolvable;
    private _firewallStatus;
    get firewallStatus(): DataAwsFirewall.FirewallStatusPropertyList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get subnetChangeProtection(): cdktn.IResolvable;
    private _subnetMapping;
    get subnetMapping(): DataAwsFirewall.SubnetMappingPropertyList;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    get transitGatewayId(): string;
    get transitGatewayOwnerAccountId(): string;
    get updateToken(): string;
    get vpcId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsFirewallAvailabilityZoneMappingPropertyToTerraform(struct?: DataAwsFirewall.AvailabilityZoneMappingProperty): any;
export declare function dataAwsFirewallAvailabilityZoneMappingPropertyToHclTerraform(struct?: DataAwsFirewall.AvailabilityZoneMappingProperty): any;
export declare function dataAwsFirewallEncryptionConfigurationPropertyToTerraform(struct?: DataAwsFirewall.EncryptionConfigurationProperty): any;
export declare function dataAwsFirewallEncryptionConfigurationPropertyToHclTerraform(struct?: DataAwsFirewall.EncryptionConfigurationProperty): any;
export declare function dataAwsFirewallIpSetReferencesPropertyToTerraform(struct?: DataAwsFirewall.IpSetReferencesProperty): any;
export declare function dataAwsFirewallIpSetReferencesPropertyToHclTerraform(struct?: DataAwsFirewall.IpSetReferencesProperty): any;
export declare function dataAwsFirewallCidrsPropertyToTerraform(struct?: DataAwsFirewall.CidrsProperty): any;
export declare function dataAwsFirewallCidrsPropertyToHclTerraform(struct?: DataAwsFirewall.CidrsProperty): any;
export declare function dataAwsFirewallCapacityUsageSummaryPropertyToTerraform(struct?: DataAwsFirewall.CapacityUsageSummaryProperty): any;
export declare function dataAwsFirewallCapacityUsageSummaryPropertyToHclTerraform(struct?: DataAwsFirewall.CapacityUsageSummaryProperty): any;
export declare function dataAwsFirewallAttachmentPropertyToTerraform(struct?: DataAwsFirewall.AttachmentProperty): any;
export declare function dataAwsFirewallAttachmentPropertyToHclTerraform(struct?: DataAwsFirewall.AttachmentProperty): any;
export declare function dataAwsFirewallSyncStatesPropertyToTerraform(struct?: DataAwsFirewall.SyncStatesProperty): any;
export declare function dataAwsFirewallSyncStatesPropertyToHclTerraform(struct?: DataAwsFirewall.SyncStatesProperty): any;
export declare function dataAwsFirewallTransitGatewayAttachmentSyncStatesPropertyToTerraform(struct?: DataAwsFirewall.TransitGatewayAttachmentSyncStatesProperty): any;
export declare function dataAwsFirewallTransitGatewayAttachmentSyncStatesPropertyToHclTerraform(struct?: DataAwsFirewall.TransitGatewayAttachmentSyncStatesProperty): any;
export declare function dataAwsFirewallFirewallStatusPropertyToTerraform(struct?: DataAwsFirewall.FirewallStatusProperty): any;
export declare function dataAwsFirewallFirewallStatusPropertyToHclTerraform(struct?: DataAwsFirewall.FirewallStatusProperty): any;
export declare function dataAwsFirewallSubnetMappingPropertyToTerraform(struct?: DataAwsFirewall.SubnetMappingProperty): any;
export declare function dataAwsFirewallSubnetMappingPropertyToHclTerraform(struct?: DataAwsFirewall.SubnetMappingProperty): any;
export declare namespace DataAwsFirewall {
    interface AvailabilityZoneMappingProperty {
    }
    class AvailabilityZoneMappingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AvailabilityZoneMappingProperty | undefined;
        set internalValue(value: AvailabilityZoneMappingProperty | undefined);
        get availabilityZoneId(): string;
    }
    class AvailabilityZoneMappingPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AvailabilityZoneMappingPropertyOutputReference;
    }
    interface EncryptionConfigurationProperty {
    }
    class EncryptionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EncryptionConfigurationProperty | undefined;
        set internalValue(value: EncryptionConfigurationProperty | undefined);
        get keyId(): string;
        get type(): string;
    }
    class EncryptionConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EncryptionConfigurationPropertyOutputReference;
    }
    interface IpSetReferencesProperty {
    }
    class IpSetReferencesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IpSetReferencesProperty | undefined;
        set internalValue(value: IpSetReferencesProperty | undefined);
        get resolvedCidrCount(): number;
    }
    class IpSetReferencesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IpSetReferencesPropertyOutputReference;
    }
    interface CidrsProperty {
    }
    class CidrsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CidrsProperty | undefined;
        set internalValue(value: CidrsProperty | undefined);
        get availableCidrCount(): number;
        private _ipSetReferences;
        get ipSetReferences(): IpSetReferencesPropertyList;
        get utilizedCidrCount(): number;
    }
    class CidrsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CidrsPropertyOutputReference;
    }
    interface CapacityUsageSummaryProperty {
    }
    class CapacityUsageSummaryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CapacityUsageSummaryProperty | undefined;
        set internalValue(value: CapacityUsageSummaryProperty | undefined);
        private _cidrs;
        get cidrs(): CidrsPropertyList;
    }
    class CapacityUsageSummaryPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CapacityUsageSummaryPropertyOutputReference;
    }
    interface AttachmentProperty {
    }
    class AttachmentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AttachmentProperty | undefined;
        set internalValue(value: AttachmentProperty | undefined);
        get endpointId(): string;
        get status(): string;
        get statusMessage(): string;
        get subnetId(): string;
    }
    class AttachmentPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AttachmentPropertyOutputReference;
    }
    interface SyncStatesProperty {
    }
    class SyncStatesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SyncStatesProperty | undefined;
        set internalValue(value: SyncStatesProperty | undefined);
        private _attachment;
        get attachment(): AttachmentPropertyList;
        get availabilityZone(): string;
    }
    class SyncStatesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SyncStatesPropertyOutputReference;
    }
    interface TransitGatewayAttachmentSyncStatesProperty {
    }
    class TransitGatewayAttachmentSyncStatesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TransitGatewayAttachmentSyncStatesProperty | undefined;
        set internalValue(value: TransitGatewayAttachmentSyncStatesProperty | undefined);
        get attachmentId(): string;
        get statusMessage(): string;
        get transitGatewayAttachmentStatus(): string;
    }
    class TransitGatewayAttachmentSyncStatesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TransitGatewayAttachmentSyncStatesPropertyOutputReference;
    }
    interface FirewallStatusProperty {
    }
    class FirewallStatusPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FirewallStatusProperty | undefined;
        set internalValue(value: FirewallStatusProperty | undefined);
        private _capacityUsageSummary;
        get capacityUsageSummary(): CapacityUsageSummaryPropertyList;
        get configurationSyncStateSummary(): string;
        get status(): string;
        private _syncStates;
        get syncStates(): SyncStatesPropertyList;
        private _transitGatewayAttachmentSyncStates;
        get transitGatewayAttachmentSyncStates(): TransitGatewayAttachmentSyncStatesPropertyList;
    }
    class FirewallStatusPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FirewallStatusPropertyOutputReference;
    }
    interface SubnetMappingProperty {
    }
    class SubnetMappingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SubnetMappingProperty | undefined;
        set internalValue(value: SubnetMappingProperty | undefined);
        get subnetId(): string;
    }
    class SubnetMappingPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SubnetMappingPropertyOutputReference;
    }
}
