import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsFirewallPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#description AwsFirewallPolicy#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#id AwsFirewallPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#name AwsFirewallPolicy#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#region AwsFirewallPolicy#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#tags AwsFirewallPolicy#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#tags_all AwsFirewallPolicy#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * encryption_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#encryption_configuration AwsFirewallPolicy#encryption_configuration}
    */
    readonly encryptionConfiguration?: AwsFirewallPolicy.EncryptionConfigurationProperty;
    /**
    * firewall_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#firewall_policy AwsFirewallPolicy#firewall_policy}
    */
    readonly firewallPolicy: AwsFirewallPolicy.FirewallPolicyProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy aws_networkfirewall_firewall_policy}
*/
export declare class AwsFirewallPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_networkfirewall_firewall_policy";
    /**
    * Generates CDKTN code for importing a AwsFirewallPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsFirewallPolicy to import
    * @param importFromId The id of the existing AwsFirewallPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsFirewallPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy aws_networkfirewall_firewall_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsFirewallPolicyConfig
    */
    constructor(scope: Construct, id: string, config: AwsFirewallPolicyConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get updateToken(): string;
    private _encryptionConfiguration;
    get encryptionConfiguration(): AwsFirewallPolicy.EncryptionConfigurationPropertyOutputReference;
    putEncryptionConfiguration(value: AwsFirewallPolicy.EncryptionConfigurationProperty): void;
    resetEncryptionConfiguration(): void;
    get encryptionConfigurationInput(): AwsFirewallPolicy.EncryptionConfigurationProperty | undefined;
    private _firewallPolicy;
    get firewallPolicy(): AwsFirewallPolicy.FirewallPolicyPropertyOutputReference;
    putFirewallPolicy(value: AwsFirewallPolicy.FirewallPolicyProperty): void;
    get firewallPolicyInput(): AwsFirewallPolicy.FirewallPolicyProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsFirewallPolicyEncryptionConfigurationPropertyToTerraform(struct?: AwsFirewallPolicy.EncryptionConfigurationPropertyOutputReference | AwsFirewallPolicy.EncryptionConfigurationProperty): any;
export declare function awsFirewallPolicyEncryptionConfigurationPropertyToHclTerraform(struct?: AwsFirewallPolicy.EncryptionConfigurationPropertyOutputReference | AwsFirewallPolicy.EncryptionConfigurationProperty): any;
export declare function awsFirewallPolicyIpSetPropertyToTerraform(struct?: AwsFirewallPolicy.IpSetPropertyOutputReference | AwsFirewallPolicy.IpSetProperty): any;
export declare function awsFirewallPolicyIpSetPropertyToHclTerraform(struct?: AwsFirewallPolicy.IpSetPropertyOutputReference | AwsFirewallPolicy.IpSetProperty): any;
export declare function awsFirewallPolicyRuleVariablesPropertyToTerraform(struct?: AwsFirewallPolicy.RuleVariablesProperty | cdktn.IResolvable): any;
export declare function awsFirewallPolicyRuleVariablesPropertyToHclTerraform(struct?: AwsFirewallPolicy.RuleVariablesProperty | cdktn.IResolvable): any;
export declare function awsFirewallPolicyPolicyVariablesPropertyToTerraform(struct?: AwsFirewallPolicy.PolicyVariablesPropertyOutputReference | AwsFirewallPolicy.PolicyVariablesProperty): any;
export declare function awsFirewallPolicyPolicyVariablesPropertyToHclTerraform(struct?: AwsFirewallPolicy.PolicyVariablesPropertyOutputReference | AwsFirewallPolicy.PolicyVariablesProperty): any;
export declare function awsFirewallPolicyFlowTimeoutsPropertyToTerraform(struct?: AwsFirewallPolicy.FlowTimeoutsPropertyOutputReference | AwsFirewallPolicy.FlowTimeoutsProperty): any;
export declare function awsFirewallPolicyFlowTimeoutsPropertyToHclTerraform(struct?: AwsFirewallPolicy.FlowTimeoutsPropertyOutputReference | AwsFirewallPolicy.FlowTimeoutsProperty): any;
export declare function awsFirewallPolicyStatefulEngineOptionsPropertyToTerraform(struct?: AwsFirewallPolicy.StatefulEngineOptionsPropertyOutputReference | AwsFirewallPolicy.StatefulEngineOptionsProperty): any;
export declare function awsFirewallPolicyStatefulEngineOptionsPropertyToHclTerraform(struct?: AwsFirewallPolicy.StatefulEngineOptionsPropertyOutputReference | AwsFirewallPolicy.StatefulEngineOptionsProperty): any;
export declare function awsFirewallPolicyOverridePropertyToTerraform(struct?: AwsFirewallPolicy.OverridePropertyOutputReference | AwsFirewallPolicy.OverrideProperty): any;
export declare function awsFirewallPolicyOverridePropertyToHclTerraform(struct?: AwsFirewallPolicy.OverridePropertyOutputReference | AwsFirewallPolicy.OverrideProperty): any;
export declare function awsFirewallPolicyStatefulRuleGroupReferencePropertyToTerraform(struct?: AwsFirewallPolicy.StatefulRuleGroupReferenceProperty | cdktn.IResolvable): any;
export declare function awsFirewallPolicyStatefulRuleGroupReferencePropertyToHclTerraform(struct?: AwsFirewallPolicy.StatefulRuleGroupReferenceProperty | cdktn.IResolvable): any;
export declare function awsFirewallPolicyDimensionPropertyToTerraform(struct?: AwsFirewallPolicy.DimensionProperty | cdktn.IResolvable): any;
export declare function awsFirewallPolicyDimensionPropertyToHclTerraform(struct?: AwsFirewallPolicy.DimensionProperty | cdktn.IResolvable): any;
export declare function awsFirewallPolicyPublishMetricActionPropertyToTerraform(struct?: AwsFirewallPolicy.PublishMetricActionPropertyOutputReference | AwsFirewallPolicy.PublishMetricActionProperty): any;
export declare function awsFirewallPolicyPublishMetricActionPropertyToHclTerraform(struct?: AwsFirewallPolicy.PublishMetricActionPropertyOutputReference | AwsFirewallPolicy.PublishMetricActionProperty): any;
export declare function awsFirewallPolicyActionDefinitionPropertyToTerraform(struct?: AwsFirewallPolicy.ActionDefinitionPropertyOutputReference | AwsFirewallPolicy.ActionDefinitionProperty): any;
export declare function awsFirewallPolicyActionDefinitionPropertyToHclTerraform(struct?: AwsFirewallPolicy.ActionDefinitionPropertyOutputReference | AwsFirewallPolicy.ActionDefinitionProperty): any;
export declare function awsFirewallPolicyStatelessCustomActionPropertyToTerraform(struct?: AwsFirewallPolicy.StatelessCustomActionProperty | cdktn.IResolvable): any;
export declare function awsFirewallPolicyStatelessCustomActionPropertyToHclTerraform(struct?: AwsFirewallPolicy.StatelessCustomActionProperty | cdktn.IResolvable): any;
export declare function awsFirewallPolicyStatelessRuleGroupReferencePropertyToTerraform(struct?: AwsFirewallPolicy.StatelessRuleGroupReferenceProperty | cdktn.IResolvable): any;
export declare function awsFirewallPolicyStatelessRuleGroupReferencePropertyToHclTerraform(struct?: AwsFirewallPolicy.StatelessRuleGroupReferenceProperty | cdktn.IResolvable): any;
export declare function awsFirewallPolicyFirewallPolicyPropertyToTerraform(struct?: AwsFirewallPolicy.FirewallPolicyPropertyOutputReference | AwsFirewallPolicy.FirewallPolicyProperty): any;
export declare function awsFirewallPolicyFirewallPolicyPropertyToHclTerraform(struct?: AwsFirewallPolicy.FirewallPolicyPropertyOutputReference | AwsFirewallPolicy.FirewallPolicyProperty): any;
export declare namespace AwsFirewallPolicy {
    interface EncryptionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#key_id AwsFirewallPolicy#key_id}
        */
        readonly keyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#type AwsFirewallPolicy#type}
        */
        readonly type: string;
    }
    class EncryptionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncryptionConfigurationProperty | undefined;
        set internalValue(value: EncryptionConfigurationProperty | undefined);
        private _keyId?;
        get keyId(): string;
        set keyId(value: string);
        resetKeyId(): void;
        get keyIdInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    interface IpSetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#definition AwsFirewallPolicy#definition}
        */
        readonly definition: string[];
    }
    class IpSetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IpSetProperty | undefined;
        set internalValue(value: IpSetProperty | undefined);
        private _definition?;
        get definition(): string[];
        set definition(value: string[]);
        get definitionInput(): string[] | undefined;
    }
    interface RuleVariablesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#key AwsFirewallPolicy#key}
        */
        readonly key: string;
        /**
        * ip_set block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#ip_set AwsFirewallPolicy#ip_set}
        */
        readonly ipSet: IpSetProperty;
    }
    class RuleVariablesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleVariablesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleVariablesProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _ipSet;
        get ipSet(): IpSetPropertyOutputReference;
        putIpSet(value: IpSetProperty): void;
        get ipSetInput(): IpSetProperty | undefined;
    }
    class RuleVariablesPropertyList extends cdktn.ComplexList {
        internalValue?: RuleVariablesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleVariablesPropertyOutputReference;
    }
    interface PolicyVariablesProperty {
        /**
        * rule_variables block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#rule_variables AwsFirewallPolicy#rule_variables}
        */
        readonly ruleVariables?: RuleVariablesProperty[] | cdktn.IResolvable;
    }
    class PolicyVariablesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PolicyVariablesProperty | undefined;
        set internalValue(value: PolicyVariablesProperty | undefined);
        private _ruleVariables;
        get ruleVariables(): RuleVariablesPropertyList;
        putRuleVariables(value: RuleVariablesProperty[] | cdktn.IResolvable): void;
        resetRuleVariables(): void;
        get ruleVariablesInput(): cdktn.IResolvable | RuleVariablesProperty[] | undefined;
    }
    interface FlowTimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#tcp_idle_timeout_seconds AwsFirewallPolicy#tcp_idle_timeout_seconds}
        */
        readonly tcpIdleTimeoutSeconds?: number;
    }
    class FlowTimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FlowTimeoutsProperty | undefined;
        set internalValue(value: FlowTimeoutsProperty | undefined);
        private _tcpIdleTimeoutSeconds?;
        get tcpIdleTimeoutSeconds(): number;
        set tcpIdleTimeoutSeconds(value: number);
        resetTcpIdleTimeoutSeconds(): void;
        get tcpIdleTimeoutSecondsInput(): number | undefined;
    }
    interface StatefulEngineOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#rule_order AwsFirewallPolicy#rule_order}
        */
        readonly ruleOrder?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#stream_exception_policy AwsFirewallPolicy#stream_exception_policy}
        */
        readonly streamExceptionPolicy?: string;
        /**
        * flow_timeouts block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#flow_timeouts AwsFirewallPolicy#flow_timeouts}
        */
        readonly flowTimeouts?: FlowTimeoutsProperty;
    }
    class StatefulEngineOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StatefulEngineOptionsProperty | undefined;
        set internalValue(value: StatefulEngineOptionsProperty | undefined);
        private _ruleOrder?;
        get ruleOrder(): string;
        set ruleOrder(value: string);
        resetRuleOrder(): void;
        get ruleOrderInput(): string | undefined;
        private _streamExceptionPolicy?;
        get streamExceptionPolicy(): string;
        set streamExceptionPolicy(value: string);
        resetStreamExceptionPolicy(): void;
        get streamExceptionPolicyInput(): string | undefined;
        private _flowTimeouts;
        get flowTimeouts(): FlowTimeoutsPropertyOutputReference;
        putFlowTimeouts(value: FlowTimeoutsProperty): void;
        resetFlowTimeouts(): void;
        get flowTimeoutsInput(): FlowTimeoutsProperty | undefined;
    }
    interface OverrideProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#action AwsFirewallPolicy#action}
        */
        readonly action?: string;
    }
    class OverridePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OverrideProperty | undefined;
        set internalValue(value: OverrideProperty | undefined);
        private _action?;
        get action(): string;
        set action(value: string);
        resetAction(): void;
        get actionInput(): string | undefined;
    }
    interface StatefulRuleGroupReferenceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#deep_threat_inspection AwsFirewallPolicy#deep_threat_inspection}
        */
        readonly deepThreatInspection?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#priority AwsFirewallPolicy#priority}
        */
        readonly priority?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#resource_arn AwsFirewallPolicy#resource_arn}
        */
        readonly resourceArn: string;
        /**
        * override block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#override AwsFirewallPolicy#override}
        */
        readonly override?: OverrideProperty;
    }
    class StatefulRuleGroupReferencePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StatefulRuleGroupReferenceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StatefulRuleGroupReferenceProperty | cdktn.IResolvable | undefined);
        private _deepThreatInspection?;
        get deepThreatInspection(): string;
        set deepThreatInspection(value: string);
        resetDeepThreatInspection(): void;
        get deepThreatInspectionInput(): string | undefined;
        private _priority?;
        get priority(): number;
        set priority(value: number);
        resetPriority(): void;
        get priorityInput(): number | undefined;
        private _resourceArn?;
        get resourceArn(): string;
        set resourceArn(value: string);
        get resourceArnInput(): string | undefined;
        private _override;
        get override(): OverridePropertyOutputReference;
        putOverride(value: OverrideProperty): void;
        resetOverride(): void;
        get overrideInput(): OverrideProperty | undefined;
    }
    class StatefulRuleGroupReferencePropertyList extends cdktn.ComplexList {
        internalValue?: StatefulRuleGroupReferenceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StatefulRuleGroupReferencePropertyOutputReference;
    }
    interface DimensionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#value AwsFirewallPolicy#value}
        */
        readonly value: string;
    }
    class DimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DimensionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DimensionProperty | cdktn.IResolvable | undefined);
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class DimensionPropertyList extends cdktn.ComplexList {
        internalValue?: DimensionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DimensionPropertyOutputReference;
    }
    interface PublishMetricActionProperty {
        /**
        * dimension block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#dimension AwsFirewallPolicy#dimension}
        */
        readonly dimension: DimensionProperty[] | cdktn.IResolvable;
    }
    class PublishMetricActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PublishMetricActionProperty | undefined;
        set internalValue(value: PublishMetricActionProperty | undefined);
        private _dimension;
        get dimension(): DimensionPropertyList;
        putDimension(value: DimensionProperty[] | cdktn.IResolvable): void;
        get dimensionInput(): cdktn.IResolvable | DimensionProperty[] | undefined;
    }
    interface ActionDefinitionProperty {
        /**
        * publish_metric_action block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#publish_metric_action AwsFirewallPolicy#publish_metric_action}
        */
        readonly publishMetricAction: PublishMetricActionProperty;
    }
    class ActionDefinitionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ActionDefinitionProperty | undefined;
        set internalValue(value: ActionDefinitionProperty | undefined);
        private _publishMetricAction;
        get publishMetricAction(): PublishMetricActionPropertyOutputReference;
        putPublishMetricAction(value: PublishMetricActionProperty): void;
        get publishMetricActionInput(): PublishMetricActionProperty | undefined;
    }
    interface StatelessCustomActionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#action_name AwsFirewallPolicy#action_name}
        */
        readonly actionName: string;
        /**
        * action_definition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#action_definition AwsFirewallPolicy#action_definition}
        */
        readonly actionDefinition: ActionDefinitionProperty;
    }
    class StatelessCustomActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StatelessCustomActionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StatelessCustomActionProperty | cdktn.IResolvable | undefined);
        private _actionName?;
        get actionName(): string;
        set actionName(value: string);
        get actionNameInput(): string | undefined;
        private _actionDefinition;
        get actionDefinition(): ActionDefinitionPropertyOutputReference;
        putActionDefinition(value: ActionDefinitionProperty): void;
        get actionDefinitionInput(): ActionDefinitionProperty | undefined;
    }
    class StatelessCustomActionPropertyList extends cdktn.ComplexList {
        internalValue?: StatelessCustomActionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StatelessCustomActionPropertyOutputReference;
    }
    interface StatelessRuleGroupReferenceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#priority AwsFirewallPolicy#priority}
        */
        readonly priority: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#resource_arn AwsFirewallPolicy#resource_arn}
        */
        readonly resourceArn: string;
    }
    class StatelessRuleGroupReferencePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StatelessRuleGroupReferenceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StatelessRuleGroupReferenceProperty | cdktn.IResolvable | undefined);
        private _priority?;
        get priority(): number;
        set priority(value: number);
        get priorityInput(): number | undefined;
        private _resourceArn?;
        get resourceArn(): string;
        set resourceArn(value: string);
        get resourceArnInput(): string | undefined;
    }
    class StatelessRuleGroupReferencePropertyList extends cdktn.ComplexList {
        internalValue?: StatelessRuleGroupReferenceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StatelessRuleGroupReferencePropertyOutputReference;
    }
    interface FirewallPolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#enable_tls_session_holding AwsFirewallPolicy#enable_tls_session_holding}
        */
        readonly enableTlsSessionHolding?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#stateful_default_actions AwsFirewallPolicy#stateful_default_actions}
        */
        readonly statefulDefaultActions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#stateless_default_actions AwsFirewallPolicy#stateless_default_actions}
        */
        readonly statelessDefaultActions: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#stateless_fragment_default_actions AwsFirewallPolicy#stateless_fragment_default_actions}
        */
        readonly statelessFragmentDefaultActions: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#tls_inspection_configuration_arn AwsFirewallPolicy#tls_inspection_configuration_arn}
        */
        readonly tlsInspectionConfigurationArn?: string;
        /**
        * policy_variables block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#policy_variables AwsFirewallPolicy#policy_variables}
        */
        readonly policyVariables?: PolicyVariablesProperty;
        /**
        * stateful_engine_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#stateful_engine_options AwsFirewallPolicy#stateful_engine_options}
        */
        readonly statefulEngineOptions?: StatefulEngineOptionsProperty;
        /**
        * stateful_rule_group_reference block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#stateful_rule_group_reference AwsFirewallPolicy#stateful_rule_group_reference}
        */
        readonly statefulRuleGroupReference?: StatefulRuleGroupReferenceProperty[] | cdktn.IResolvable;
        /**
        * stateless_custom_action block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#stateless_custom_action AwsFirewallPolicy#stateless_custom_action}
        */
        readonly statelessCustomAction?: StatelessCustomActionProperty[] | cdktn.IResolvable;
        /**
        * stateless_rule_group_reference block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#stateless_rule_group_reference AwsFirewallPolicy#stateless_rule_group_reference}
        */
        readonly statelessRuleGroupReference?: StatelessRuleGroupReferenceProperty[] | cdktn.IResolvable;
    }
    class FirewallPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FirewallPolicyProperty | undefined;
        set internalValue(value: FirewallPolicyProperty | undefined);
        private _enableTlsSessionHolding?;
        get enableTlsSessionHolding(): boolean | cdktn.IResolvable;
        set enableTlsSessionHolding(value: boolean | cdktn.IResolvable);
        resetEnableTlsSessionHolding(): void;
        get enableTlsSessionHoldingInput(): boolean | cdktn.IResolvable | undefined;
        private _statefulDefaultActions?;
        get statefulDefaultActions(): string[];
        set statefulDefaultActions(value: string[]);
        resetStatefulDefaultActions(): void;
        get statefulDefaultActionsInput(): string[] | undefined;
        private _statelessDefaultActions?;
        get statelessDefaultActions(): string[];
        set statelessDefaultActions(value: string[]);
        get statelessDefaultActionsInput(): string[] | undefined;
        private _statelessFragmentDefaultActions?;
        get statelessFragmentDefaultActions(): string[];
        set statelessFragmentDefaultActions(value: string[]);
        get statelessFragmentDefaultActionsInput(): string[] | undefined;
        private _tlsInspectionConfigurationArn?;
        get tlsInspectionConfigurationArn(): string;
        set tlsInspectionConfigurationArn(value: string);
        resetTlsInspectionConfigurationArn(): void;
        get tlsInspectionConfigurationArnInput(): string | undefined;
        private _policyVariables;
        get policyVariables(): PolicyVariablesPropertyOutputReference;
        putPolicyVariables(value: PolicyVariablesProperty): void;
        resetPolicyVariables(): void;
        get policyVariablesInput(): PolicyVariablesProperty | undefined;
        private _statefulEngineOptions;
        get statefulEngineOptions(): StatefulEngineOptionsPropertyOutputReference;
        putStatefulEngineOptions(value: StatefulEngineOptionsProperty): void;
        resetStatefulEngineOptions(): void;
        get statefulEngineOptionsInput(): StatefulEngineOptionsProperty | undefined;
        private _statefulRuleGroupReference;
        get statefulRuleGroupReference(): StatefulRuleGroupReferencePropertyList;
        putStatefulRuleGroupReference(value: StatefulRuleGroupReferenceProperty[] | cdktn.IResolvable): void;
        resetStatefulRuleGroupReference(): void;
        get statefulRuleGroupReferenceInput(): cdktn.IResolvable | StatefulRuleGroupReferenceProperty[] | undefined;
        private _statelessCustomAction;
        get statelessCustomAction(): StatelessCustomActionPropertyList;
        putStatelessCustomAction(value: StatelessCustomActionProperty[] | cdktn.IResolvable): void;
        resetStatelessCustomAction(): void;
        get statelessCustomActionInput(): cdktn.IResolvable | StatelessCustomActionProperty[] | undefined;
        private _statelessRuleGroupReference;
        get statelessRuleGroupReference(): StatelessRuleGroupReferencePropertyList;
        putStatelessRuleGroupReference(value: StatelessRuleGroupReferenceProperty[] | cdktn.IResolvable): void;
        resetStatelessRuleGroupReference(): void;
        get statelessRuleGroupReferenceInput(): cdktn.IResolvable | StatelessRuleGroupReferenceProperty[] | undefined;
    }
}
