import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsRuleGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#capacity AwsRuleGroup#capacity}
    */
    readonly capacity: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#description AwsRuleGroup#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#id AwsRuleGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#name AwsRuleGroup#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#region AwsRuleGroup#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#rules AwsRuleGroup#rules}
    */
    readonly rules?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#tags AwsRuleGroup#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#tags_all AwsRuleGroup#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#type AwsRuleGroup#type}
    */
    readonly type: string;
    /**
    * encryption_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#encryption_configuration AwsRuleGroup#encryption_configuration}
    */
    readonly encryptionConfiguration?: AwsRuleGroup.EncryptionConfigurationProperty;
    /**
    * rule_group block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#rule_group AwsRuleGroup#rule_group}
    */
    readonly ruleGroup?: AwsRuleGroup.RuleGroupProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group aws_networkfirewall_rule_group}
*/
export declare class AwsRuleGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_networkfirewall_rule_group";
    /**
    * Generates CDKTN code for importing a AwsRuleGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsRuleGroup to import
    * @param importFromId The id of the existing AwsRuleGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsRuleGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group aws_networkfirewall_rule_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsRuleGroupConfig
    */
    constructor(scope: Construct, id: string, config: AwsRuleGroupConfig);
    get arn(): string;
    private _capacity?;
    get capacity(): number;
    set capacity(value: number);
    get capacityInput(): number | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _rules?;
    get rules(): string;
    set rules(value: string);
    resetRules(): void;
    get rulesInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    get updateToken(): string;
    private _encryptionConfiguration;
    get encryptionConfiguration(): AwsRuleGroup.EncryptionConfigurationPropertyOutputReference;
    putEncryptionConfiguration(value: AwsRuleGroup.EncryptionConfigurationProperty): void;
    resetEncryptionConfiguration(): void;
    get encryptionConfigurationInput(): AwsRuleGroup.EncryptionConfigurationProperty | undefined;
    private _ruleGroup;
    get ruleGroup(): AwsRuleGroup.RuleGroupPropertyOutputReference;
    putRuleGroup(value: AwsRuleGroup.RuleGroupProperty): void;
    resetRuleGroup(): void;
    get ruleGroupInput(): AwsRuleGroup.RuleGroupProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsRuleGroupEncryptionConfigurationPropertyToTerraform(struct?: AwsRuleGroup.EncryptionConfigurationPropertyOutputReference | AwsRuleGroup.EncryptionConfigurationProperty): any;
export declare function awsRuleGroupEncryptionConfigurationPropertyToHclTerraform(struct?: AwsRuleGroup.EncryptionConfigurationPropertyOutputReference | AwsRuleGroup.EncryptionConfigurationProperty): any;
export declare function awsRuleGroupIpSetReferencePropertyToTerraform(struct?: AwsRuleGroup.IpSetReferenceProperty | cdktn.IResolvable): any;
export declare function awsRuleGroupIpSetReferencePropertyToHclTerraform(struct?: AwsRuleGroup.IpSetReferenceProperty | cdktn.IResolvable): any;
export declare function awsRuleGroupIpSetReferencesPropertyToTerraform(struct?: AwsRuleGroup.IpSetReferencesProperty | cdktn.IResolvable): any;
export declare function awsRuleGroupIpSetReferencesPropertyToHclTerraform(struct?: AwsRuleGroup.IpSetReferencesProperty | cdktn.IResolvable): any;
export declare function awsRuleGroupReferenceSetsPropertyToTerraform(struct?: AwsRuleGroup.ReferenceSetsPropertyOutputReference | AwsRuleGroup.ReferenceSetsProperty): any;
export declare function awsRuleGroupReferenceSetsPropertyToHclTerraform(struct?: AwsRuleGroup.ReferenceSetsPropertyOutputReference | AwsRuleGroup.ReferenceSetsProperty): any;
export declare function awsRuleGroupIpSetPropertyToTerraform(struct?: AwsRuleGroup.IpSetPropertyOutputReference | AwsRuleGroup.IpSetProperty): any;
export declare function awsRuleGroupIpSetPropertyToHclTerraform(struct?: AwsRuleGroup.IpSetPropertyOutputReference | AwsRuleGroup.IpSetProperty): any;
export declare function awsRuleGroupIpSetsPropertyToTerraform(struct?: AwsRuleGroup.IpSetsProperty | cdktn.IResolvable): any;
export declare function awsRuleGroupIpSetsPropertyToHclTerraform(struct?: AwsRuleGroup.IpSetsProperty | cdktn.IResolvable): any;
export declare function awsRuleGroupPortSetPropertyToTerraform(struct?: AwsRuleGroup.PortSetPropertyOutputReference | AwsRuleGroup.PortSetProperty): any;
export declare function awsRuleGroupPortSetPropertyToHclTerraform(struct?: AwsRuleGroup.PortSetPropertyOutputReference | AwsRuleGroup.PortSetProperty): any;
export declare function awsRuleGroupPortSetsPropertyToTerraform(struct?: AwsRuleGroup.PortSetsProperty | cdktn.IResolvable): any;
export declare function awsRuleGroupPortSetsPropertyToHclTerraform(struct?: AwsRuleGroup.PortSetsProperty | cdktn.IResolvable): any;
export declare function awsRuleGroupRuleVariablesPropertyToTerraform(struct?: AwsRuleGroup.RuleVariablesPropertyOutputReference | AwsRuleGroup.RuleVariablesProperty): any;
export declare function awsRuleGroupRuleVariablesPropertyToHclTerraform(struct?: AwsRuleGroup.RuleVariablesPropertyOutputReference | AwsRuleGroup.RuleVariablesProperty): any;
export declare function awsRuleGroupRulesSourceListPropertyToTerraform(struct?: AwsRuleGroup.RulesSourceListPropertyOutputReference | AwsRuleGroup.RulesSourceListProperty): any;
export declare function awsRuleGroupRulesSourceListPropertyToHclTerraform(struct?: AwsRuleGroup.RulesSourceListPropertyOutputReference | AwsRuleGroup.RulesSourceListProperty): any;
export declare function awsRuleGroupHeaderPropertyToTerraform(struct?: AwsRuleGroup.HeaderPropertyOutputReference | AwsRuleGroup.HeaderProperty): any;
export declare function awsRuleGroupHeaderPropertyToHclTerraform(struct?: AwsRuleGroup.HeaderPropertyOutputReference | AwsRuleGroup.HeaderProperty): any;
export declare function awsRuleGroupRuleOptionPropertyToTerraform(struct?: AwsRuleGroup.RuleOptionProperty | cdktn.IResolvable): any;
export declare function awsRuleGroupRuleOptionPropertyToHclTerraform(struct?: AwsRuleGroup.RuleOptionProperty | cdktn.IResolvable): any;
export declare function awsRuleGroupStatefulRulePropertyToTerraform(struct?: AwsRuleGroup.StatefulRuleProperty | cdktn.IResolvable): any;
export declare function awsRuleGroupStatefulRulePropertyToHclTerraform(struct?: AwsRuleGroup.StatefulRuleProperty | cdktn.IResolvable): any;
export declare function awsRuleGroupDimensionPropertyToTerraform(struct?: AwsRuleGroup.DimensionProperty | cdktn.IResolvable): any;
export declare function awsRuleGroupDimensionPropertyToHclTerraform(struct?: AwsRuleGroup.DimensionProperty | cdktn.IResolvable): any;
export declare function awsRuleGroupPublishMetricActionPropertyToTerraform(struct?: AwsRuleGroup.PublishMetricActionPropertyOutputReference | AwsRuleGroup.PublishMetricActionProperty): any;
export declare function awsRuleGroupPublishMetricActionPropertyToHclTerraform(struct?: AwsRuleGroup.PublishMetricActionPropertyOutputReference | AwsRuleGroup.PublishMetricActionProperty): any;
export declare function awsRuleGroupActionDefinitionPropertyToTerraform(struct?: AwsRuleGroup.ActionDefinitionPropertyOutputReference | AwsRuleGroup.ActionDefinitionProperty): any;
export declare function awsRuleGroupActionDefinitionPropertyToHclTerraform(struct?: AwsRuleGroup.ActionDefinitionPropertyOutputReference | AwsRuleGroup.ActionDefinitionProperty): any;
export declare function awsRuleGroupCustomActionPropertyToTerraform(struct?: AwsRuleGroup.CustomActionProperty | cdktn.IResolvable): any;
export declare function awsRuleGroupCustomActionPropertyToHclTerraform(struct?: AwsRuleGroup.CustomActionProperty | cdktn.IResolvable): any;
export declare function awsRuleGroupDestinationPropertyToTerraform(struct?: AwsRuleGroup.DestinationProperty | cdktn.IResolvable): any;
export declare function awsRuleGroupDestinationPropertyToHclTerraform(struct?: AwsRuleGroup.DestinationProperty | cdktn.IResolvable): any;
export declare function awsRuleGroupDestinationPortPropertyToTerraform(struct?: AwsRuleGroup.DestinationPortProperty | cdktn.IResolvable): any;
export declare function awsRuleGroupDestinationPortPropertyToHclTerraform(struct?: AwsRuleGroup.DestinationPortProperty | cdktn.IResolvable): any;
export declare function awsRuleGroupSourcePropertyToTerraform(struct?: AwsRuleGroup.SourceProperty | cdktn.IResolvable): any;
export declare function awsRuleGroupSourcePropertyToHclTerraform(struct?: AwsRuleGroup.SourceProperty | cdktn.IResolvable): any;
export declare function awsRuleGroupSourcePortPropertyToTerraform(struct?: AwsRuleGroup.SourcePortProperty | cdktn.IResolvable): any;
export declare function awsRuleGroupSourcePortPropertyToHclTerraform(struct?: AwsRuleGroup.SourcePortProperty | cdktn.IResolvable): any;
export declare function awsRuleGroupTcpFlagPropertyToTerraform(struct?: AwsRuleGroup.TcpFlagProperty | cdktn.IResolvable): any;
export declare function awsRuleGroupTcpFlagPropertyToHclTerraform(struct?: AwsRuleGroup.TcpFlagProperty | cdktn.IResolvable): any;
export declare function awsRuleGroupMatchAttributesPropertyToTerraform(struct?: AwsRuleGroup.MatchAttributesPropertyOutputReference | AwsRuleGroup.MatchAttributesProperty): any;
export declare function awsRuleGroupMatchAttributesPropertyToHclTerraform(struct?: AwsRuleGroup.MatchAttributesPropertyOutputReference | AwsRuleGroup.MatchAttributesProperty): any;
export declare function awsRuleGroupRuleDefinitionPropertyToTerraform(struct?: AwsRuleGroup.RuleDefinitionPropertyOutputReference | AwsRuleGroup.RuleDefinitionProperty): any;
export declare function awsRuleGroupRuleDefinitionPropertyToHclTerraform(struct?: AwsRuleGroup.RuleDefinitionPropertyOutputReference | AwsRuleGroup.RuleDefinitionProperty): any;
export declare function awsRuleGroupStatelessRulePropertyToTerraform(struct?: AwsRuleGroup.StatelessRuleProperty | cdktn.IResolvable): any;
export declare function awsRuleGroupStatelessRulePropertyToHclTerraform(struct?: AwsRuleGroup.StatelessRuleProperty | cdktn.IResolvable): any;
export declare function awsRuleGroupStatelessRulesAndCustomActionsPropertyToTerraform(struct?: AwsRuleGroup.StatelessRulesAndCustomActionsPropertyOutputReference | AwsRuleGroup.StatelessRulesAndCustomActionsProperty): any;
export declare function awsRuleGroupStatelessRulesAndCustomActionsPropertyToHclTerraform(struct?: AwsRuleGroup.StatelessRulesAndCustomActionsPropertyOutputReference | AwsRuleGroup.StatelessRulesAndCustomActionsProperty): any;
export declare function awsRuleGroupRulesSourcePropertyToTerraform(struct?: AwsRuleGroup.RulesSourcePropertyOutputReference | AwsRuleGroup.RulesSourceProperty): any;
export declare function awsRuleGroupRulesSourcePropertyToHclTerraform(struct?: AwsRuleGroup.RulesSourcePropertyOutputReference | AwsRuleGroup.RulesSourceProperty): any;
export declare function awsRuleGroupStatefulRuleOptionsPropertyToTerraform(struct?: AwsRuleGroup.StatefulRuleOptionsPropertyOutputReference | AwsRuleGroup.StatefulRuleOptionsProperty): any;
export declare function awsRuleGroupStatefulRuleOptionsPropertyToHclTerraform(struct?: AwsRuleGroup.StatefulRuleOptionsPropertyOutputReference | AwsRuleGroup.StatefulRuleOptionsProperty): any;
export declare function awsRuleGroupRuleGroupPropertyToTerraform(struct?: AwsRuleGroup.RuleGroupPropertyOutputReference | AwsRuleGroup.RuleGroupProperty): any;
export declare function awsRuleGroupRuleGroupPropertyToHclTerraform(struct?: AwsRuleGroup.RuleGroupPropertyOutputReference | AwsRuleGroup.RuleGroupProperty): any;
export declare namespace AwsRuleGroup {
    interface EncryptionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#key_id AwsRuleGroup#key_id}
        */
        readonly keyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#type AwsRuleGroup#type}
        */
        readonly type: string;
    }
    class EncryptionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncryptionConfigurationProperty | undefined;
        set internalValue(value: EncryptionConfigurationProperty | undefined);
        private _keyId?;
        get keyId(): string;
        set keyId(value: string);
        resetKeyId(): void;
        get keyIdInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    interface IpSetReferenceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#reference_arn AwsRuleGroup#reference_arn}
        */
        readonly referenceArn: string;
    }
    class IpSetReferencePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IpSetReferenceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IpSetReferenceProperty | cdktn.IResolvable | undefined);
        private _referenceArn?;
        get referenceArn(): string;
        set referenceArn(value: string);
        get referenceArnInput(): string | undefined;
    }
    class IpSetReferencePropertyList extends cdktn.ComplexList {
        internalValue?: IpSetReferenceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IpSetReferencePropertyOutputReference;
    }
    interface IpSetReferencesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#key AwsRuleGroup#key}
        */
        readonly key: string;
        /**
        * ip_set_reference block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#ip_set_reference AwsRuleGroup#ip_set_reference}
        */
        readonly ipSetReference: IpSetReferenceProperty[] | cdktn.IResolvable;
    }
    class IpSetReferencesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IpSetReferencesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IpSetReferencesProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _ipSetReference;
        get ipSetReference(): IpSetReferencePropertyList;
        putIpSetReference(value: IpSetReferenceProperty[] | cdktn.IResolvable): void;
        get ipSetReferenceInput(): cdktn.IResolvable | IpSetReferenceProperty[] | undefined;
    }
    class IpSetReferencesPropertyList extends cdktn.ComplexList {
        internalValue?: IpSetReferencesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IpSetReferencesPropertyOutputReference;
    }
    interface ReferenceSetsProperty {
        /**
        * ip_set_references block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#ip_set_references AwsRuleGroup#ip_set_references}
        */
        readonly ipSetReferences?: IpSetReferencesProperty[] | cdktn.IResolvable;
    }
    class ReferenceSetsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ReferenceSetsProperty | undefined;
        set internalValue(value: ReferenceSetsProperty | undefined);
        private _ipSetReferences;
        get ipSetReferences(): IpSetReferencesPropertyList;
        putIpSetReferences(value: IpSetReferencesProperty[] | cdktn.IResolvable): void;
        resetIpSetReferences(): void;
        get ipSetReferencesInput(): cdktn.IResolvable | IpSetReferencesProperty[] | undefined;
    }
    interface IpSetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#definition AwsRuleGroup#definition}
        */
        readonly definition: string[];
    }
    class IpSetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IpSetProperty | undefined;
        set internalValue(value: IpSetProperty | undefined);
        private _definition?;
        get definition(): string[];
        set definition(value: string[]);
        get definitionInput(): string[] | undefined;
    }
    interface IpSetsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#key AwsRuleGroup#key}
        */
        readonly key: string;
        /**
        * ip_set block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#ip_set AwsRuleGroup#ip_set}
        */
        readonly ipSet: IpSetProperty;
    }
    class IpSetsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IpSetsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IpSetsProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _ipSet;
        get ipSet(): IpSetPropertyOutputReference;
        putIpSet(value: IpSetProperty): void;
        get ipSetInput(): IpSetProperty | undefined;
    }
    class IpSetsPropertyList extends cdktn.ComplexList {
        internalValue?: IpSetsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IpSetsPropertyOutputReference;
    }
    interface PortSetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#definition AwsRuleGroup#definition}
        */
        readonly definition: string[];
    }
    class PortSetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PortSetProperty | undefined;
        set internalValue(value: PortSetProperty | undefined);
        private _definition?;
        get definition(): string[];
        set definition(value: string[]);
        get definitionInput(): string[] | undefined;
    }
    interface PortSetsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#key AwsRuleGroup#key}
        */
        readonly key: string;
        /**
        * port_set block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#port_set AwsRuleGroup#port_set}
        */
        readonly portSet: PortSetProperty;
    }
    class PortSetsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PortSetsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PortSetsProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _portSet;
        get portSet(): PortSetPropertyOutputReference;
        putPortSet(value: PortSetProperty): void;
        get portSetInput(): PortSetProperty | undefined;
    }
    class PortSetsPropertyList extends cdktn.ComplexList {
        internalValue?: PortSetsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PortSetsPropertyOutputReference;
    }
    interface RuleVariablesProperty {
        /**
        * ip_sets block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#ip_sets AwsRuleGroup#ip_sets}
        */
        readonly ipSets?: IpSetsProperty[] | cdktn.IResolvable;
        /**
        * port_sets block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#port_sets AwsRuleGroup#port_sets}
        */
        readonly portSets?: PortSetsProperty[] | cdktn.IResolvable;
    }
    class RuleVariablesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleVariablesProperty | undefined;
        set internalValue(value: RuleVariablesProperty | undefined);
        private _ipSets;
        get ipSets(): IpSetsPropertyList;
        putIpSets(value: IpSetsProperty[] | cdktn.IResolvable): void;
        resetIpSets(): void;
        get ipSetsInput(): cdktn.IResolvable | IpSetsProperty[] | undefined;
        private _portSets;
        get portSets(): PortSetsPropertyList;
        putPortSets(value: PortSetsProperty[] | cdktn.IResolvable): void;
        resetPortSets(): void;
        get portSetsInput(): cdktn.IResolvable | PortSetsProperty[] | undefined;
    }
    interface RulesSourceListProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#generated_rules_type AwsRuleGroup#generated_rules_type}
        */
        readonly generatedRulesType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#target_types AwsRuleGroup#target_types}
        */
        readonly targetTypes: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#targets AwsRuleGroup#targets}
        */
        readonly targets: string[];
    }
    class RulesSourceListPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RulesSourceListProperty | undefined;
        set internalValue(value: RulesSourceListProperty | undefined);
        private _generatedRulesType?;
        get generatedRulesType(): string;
        set generatedRulesType(value: string);
        get generatedRulesTypeInput(): string | undefined;
        private _targetTypes?;
        get targetTypes(): string[];
        set targetTypes(value: string[]);
        get targetTypesInput(): string[] | undefined;
        private _targets?;
        get targets(): string[];
        set targets(value: string[]);
        get targetsInput(): string[] | undefined;
    }
    interface HeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#destination AwsRuleGroup#destination}
        */
        readonly destination: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#destination_port AwsRuleGroup#destination_port}
        */
        readonly destinationPort: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#direction AwsRuleGroup#direction}
        */
        readonly direction: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#protocol AwsRuleGroup#protocol}
        */
        readonly protocol: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#source AwsRuleGroup#source}
        */
        readonly source: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#source_port AwsRuleGroup#source_port}
        */
        readonly sourcePort: string;
    }
    class HeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HeaderProperty | undefined;
        set internalValue(value: HeaderProperty | undefined);
        private _destination?;
        get destination(): string;
        set destination(value: string);
        get destinationInput(): string | undefined;
        private _destinationPort?;
        get destinationPort(): string;
        set destinationPort(value: string);
        get destinationPortInput(): string | undefined;
        private _direction?;
        get direction(): string;
        set direction(value: string);
        get directionInput(): string | undefined;
        private _protocol?;
        get protocol(): string;
        set protocol(value: string);
        get protocolInput(): string | undefined;
        private _source?;
        get source(): string;
        set source(value: string);
        get sourceInput(): string | undefined;
        private _sourcePort?;
        get sourcePort(): string;
        set sourcePort(value: string);
        get sourcePortInput(): string | undefined;
    }
    interface RuleOptionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#keyword AwsRuleGroup#keyword}
        */
        readonly keyword: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#settings AwsRuleGroup#settings}
        */
        readonly settings?: string[];
    }
    class RuleOptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleOptionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleOptionProperty | cdktn.IResolvable | undefined);
        private _keyword?;
        get keyword(): string;
        set keyword(value: string);
        get keywordInput(): string | undefined;
        private _settings?;
        get settings(): string[];
        set settings(value: string[]);
        resetSettings(): void;
        get settingsInput(): string[] | undefined;
    }
    class RuleOptionPropertyList extends cdktn.ComplexList {
        internalValue?: RuleOptionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleOptionPropertyOutputReference;
    }
    interface StatefulRuleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#action AwsRuleGroup#action}
        */
        readonly action: string;
        /**
        * header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#header AwsRuleGroup#header}
        */
        readonly header: HeaderProperty;
        /**
        * rule_option block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#rule_option AwsRuleGroup#rule_option}
        */
        readonly ruleOption: RuleOptionProperty[] | cdktn.IResolvable;
    }
    class StatefulRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StatefulRuleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StatefulRuleProperty | cdktn.IResolvable | undefined);
        private _action?;
        get action(): string;
        set action(value: string);
        get actionInput(): string | undefined;
        private _header;
        get header(): HeaderPropertyOutputReference;
        putHeader(value: HeaderProperty): void;
        get headerInput(): HeaderProperty | undefined;
        private _ruleOption;
        get ruleOption(): RuleOptionPropertyList;
        putRuleOption(value: RuleOptionProperty[] | cdktn.IResolvable): void;
        get ruleOptionInput(): cdktn.IResolvable | RuleOptionProperty[] | undefined;
    }
    class StatefulRulePropertyList extends cdktn.ComplexList {
        internalValue?: StatefulRuleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StatefulRulePropertyOutputReference;
    }
    interface DimensionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#value AwsRuleGroup#value}
        */
        readonly value: string;
    }
    class DimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DimensionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DimensionProperty | cdktn.IResolvable | undefined);
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class DimensionPropertyList extends cdktn.ComplexList {
        internalValue?: DimensionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DimensionPropertyOutputReference;
    }
    interface PublishMetricActionProperty {
        /**
        * dimension block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#dimension AwsRuleGroup#dimension}
        */
        readonly dimension: DimensionProperty[] | cdktn.IResolvable;
    }
    class PublishMetricActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PublishMetricActionProperty | undefined;
        set internalValue(value: PublishMetricActionProperty | undefined);
        private _dimension;
        get dimension(): DimensionPropertyList;
        putDimension(value: DimensionProperty[] | cdktn.IResolvable): void;
        get dimensionInput(): cdktn.IResolvable | DimensionProperty[] | undefined;
    }
    interface ActionDefinitionProperty {
        /**
        * publish_metric_action block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#publish_metric_action AwsRuleGroup#publish_metric_action}
        */
        readonly publishMetricAction: PublishMetricActionProperty;
    }
    class ActionDefinitionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ActionDefinitionProperty | undefined;
        set internalValue(value: ActionDefinitionProperty | undefined);
        private _publishMetricAction;
        get publishMetricAction(): PublishMetricActionPropertyOutputReference;
        putPublishMetricAction(value: PublishMetricActionProperty): void;
        get publishMetricActionInput(): PublishMetricActionProperty | undefined;
    }
    interface CustomActionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#action_name AwsRuleGroup#action_name}
        */
        readonly actionName: string;
        /**
        * action_definition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#action_definition AwsRuleGroup#action_definition}
        */
        readonly actionDefinition: ActionDefinitionProperty;
    }
    class CustomActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomActionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CustomActionProperty | cdktn.IResolvable | undefined);
        private _actionName?;
        get actionName(): string;
        set actionName(value: string);
        get actionNameInput(): string | undefined;
        private _actionDefinition;
        get actionDefinition(): ActionDefinitionPropertyOutputReference;
        putActionDefinition(value: ActionDefinitionProperty): void;
        get actionDefinitionInput(): ActionDefinitionProperty | undefined;
    }
    class CustomActionPropertyList extends cdktn.ComplexList {
        internalValue?: CustomActionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomActionPropertyOutputReference;
    }
    interface DestinationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#address_definition AwsRuleGroup#address_definition}
        */
        readonly addressDefinition: string;
    }
    class DestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DestinationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DestinationProperty | cdktn.IResolvable | undefined);
        private _addressDefinition?;
        get addressDefinition(): string;
        set addressDefinition(value: string);
        get addressDefinitionInput(): string | undefined;
    }
    class DestinationPropertyList extends cdktn.ComplexList {
        internalValue?: DestinationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DestinationPropertyOutputReference;
    }
    interface DestinationPortProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#from_port AwsRuleGroup#from_port}
        */
        readonly fromPort: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#to_port AwsRuleGroup#to_port}
        */
        readonly toPort?: number;
    }
    class DestinationPortPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DestinationPortProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DestinationPortProperty | cdktn.IResolvable | undefined);
        private _fromPort?;
        get fromPort(): number;
        set fromPort(value: number);
        get fromPortInput(): number | undefined;
        private _toPort?;
        get toPort(): number;
        set toPort(value: number);
        resetToPort(): void;
        get toPortInput(): number | undefined;
    }
    class DestinationPortPropertyList extends cdktn.ComplexList {
        internalValue?: DestinationPortProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DestinationPortPropertyOutputReference;
    }
    interface SourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#address_definition AwsRuleGroup#address_definition}
        */
        readonly addressDefinition: string;
    }
    class SourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SourceProperty | cdktn.IResolvable | undefined);
        private _addressDefinition?;
        get addressDefinition(): string;
        set addressDefinition(value: string);
        get addressDefinitionInput(): string | undefined;
    }
    class SourcePropertyList extends cdktn.ComplexList {
        internalValue?: SourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SourcePropertyOutputReference;
    }
    interface SourcePortProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#from_port AwsRuleGroup#from_port}
        */
        readonly fromPort: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#to_port AwsRuleGroup#to_port}
        */
        readonly toPort?: number;
    }
    class SourcePortPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SourcePortProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SourcePortProperty | cdktn.IResolvable | undefined);
        private _fromPort?;
        get fromPort(): number;
        set fromPort(value: number);
        get fromPortInput(): number | undefined;
        private _toPort?;
        get toPort(): number;
        set toPort(value: number);
        resetToPort(): void;
        get toPortInput(): number | undefined;
    }
    class SourcePortPropertyList extends cdktn.ComplexList {
        internalValue?: SourcePortProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SourcePortPropertyOutputReference;
    }
    interface TcpFlagProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#flags AwsRuleGroup#flags}
        */
        readonly flags: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#masks AwsRuleGroup#masks}
        */
        readonly masks?: string[];
    }
    class TcpFlagPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TcpFlagProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TcpFlagProperty | cdktn.IResolvable | undefined);
        private _flags?;
        get flags(): string[];
        set flags(value: string[]);
        get flagsInput(): string[] | undefined;
        private _masks?;
        get masks(): string[];
        set masks(value: string[]);
        resetMasks(): void;
        get masksInput(): string[] | undefined;
    }
    class TcpFlagPropertyList extends cdktn.ComplexList {
        internalValue?: TcpFlagProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TcpFlagPropertyOutputReference;
    }
    interface MatchAttributesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#protocols AwsRuleGroup#protocols}
        */
        readonly protocols?: number[];
        /**
        * destination block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#destination AwsRuleGroup#destination}
        */
        readonly destination?: DestinationProperty[] | cdktn.IResolvable;
        /**
        * destination_port block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#destination_port AwsRuleGroup#destination_port}
        */
        readonly destinationPort?: DestinationPortProperty[] | cdktn.IResolvable;
        /**
        * source block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#source AwsRuleGroup#source}
        */
        readonly source?: SourceProperty[] | cdktn.IResolvable;
        /**
        * source_port block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#source_port AwsRuleGroup#source_port}
        */
        readonly sourcePort?: SourcePortProperty[] | cdktn.IResolvable;
        /**
        * tcp_flag block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#tcp_flag AwsRuleGroup#tcp_flag}
        */
        readonly tcpFlag?: TcpFlagProperty[] | cdktn.IResolvable;
    }
    class MatchAttributesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MatchAttributesProperty | undefined;
        set internalValue(value: MatchAttributesProperty | undefined);
        private _protocols?;
        get protocols(): number[];
        set protocols(value: number[]);
        resetProtocols(): void;
        get protocolsInput(): number[] | undefined;
        private _destination;
        get destination(): DestinationPropertyList;
        putDestination(value: DestinationProperty[] | cdktn.IResolvable): void;
        resetDestination(): void;
        get destinationInput(): cdktn.IResolvable | DestinationProperty[] | undefined;
        private _destinationPort;
        get destinationPort(): DestinationPortPropertyList;
        putDestinationPort(value: DestinationPortProperty[] | cdktn.IResolvable): void;
        resetDestinationPort(): void;
        get destinationPortInput(): cdktn.IResolvable | DestinationPortProperty[] | undefined;
        private _source;
        get source(): SourcePropertyList;
        putSource(value: SourceProperty[] | cdktn.IResolvable): void;
        resetSource(): void;
        get sourceInput(): cdktn.IResolvable | SourceProperty[] | undefined;
        private _sourcePort;
        get sourcePort(): SourcePortPropertyList;
        putSourcePort(value: SourcePortProperty[] | cdktn.IResolvable): void;
        resetSourcePort(): void;
        get sourcePortInput(): cdktn.IResolvable | SourcePortProperty[] | undefined;
        private _tcpFlag;
        get tcpFlag(): TcpFlagPropertyList;
        putTcpFlag(value: TcpFlagProperty[] | cdktn.IResolvable): void;
        resetTcpFlag(): void;
        get tcpFlagInput(): cdktn.IResolvable | TcpFlagProperty[] | undefined;
    }
    interface RuleDefinitionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#actions AwsRuleGroup#actions}
        */
        readonly actions: string[];
        /**
        * match_attributes block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#match_attributes AwsRuleGroup#match_attributes}
        */
        readonly matchAttributes: MatchAttributesProperty;
    }
    class RuleDefinitionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleDefinitionProperty | undefined;
        set internalValue(value: RuleDefinitionProperty | undefined);
        private _actions?;
        get actions(): string[];
        set actions(value: string[]);
        get actionsInput(): string[] | undefined;
        private _matchAttributes;
        get matchAttributes(): MatchAttributesPropertyOutputReference;
        putMatchAttributes(value: MatchAttributesProperty): void;
        get matchAttributesInput(): MatchAttributesProperty | undefined;
    }
    interface StatelessRuleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#priority AwsRuleGroup#priority}
        */
        readonly priority: number;
        /**
        * rule_definition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#rule_definition AwsRuleGroup#rule_definition}
        */
        readonly ruleDefinition: RuleDefinitionProperty;
    }
    class StatelessRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StatelessRuleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StatelessRuleProperty | cdktn.IResolvable | undefined);
        private _priority?;
        get priority(): number;
        set priority(value: number);
        get priorityInput(): number | undefined;
        private _ruleDefinition;
        get ruleDefinition(): RuleDefinitionPropertyOutputReference;
        putRuleDefinition(value: RuleDefinitionProperty): void;
        get ruleDefinitionInput(): RuleDefinitionProperty | undefined;
    }
    class StatelessRulePropertyList extends cdktn.ComplexList {
        internalValue?: StatelessRuleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StatelessRulePropertyOutputReference;
    }
    interface StatelessRulesAndCustomActionsProperty {
        /**
        * custom_action block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#custom_action AwsRuleGroup#custom_action}
        */
        readonly customAction?: CustomActionProperty[] | cdktn.IResolvable;
        /**
        * stateless_rule block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#stateless_rule AwsRuleGroup#stateless_rule}
        */
        readonly statelessRule: StatelessRuleProperty[] | cdktn.IResolvable;
    }
    class StatelessRulesAndCustomActionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StatelessRulesAndCustomActionsProperty | undefined;
        set internalValue(value: StatelessRulesAndCustomActionsProperty | undefined);
        private _customAction;
        get customAction(): CustomActionPropertyList;
        putCustomAction(value: CustomActionProperty[] | cdktn.IResolvable): void;
        resetCustomAction(): void;
        get customActionInput(): cdktn.IResolvable | CustomActionProperty[] | undefined;
        private _statelessRule;
        get statelessRule(): StatelessRulePropertyList;
        putStatelessRule(value: StatelessRuleProperty[] | cdktn.IResolvable): void;
        get statelessRuleInput(): cdktn.IResolvable | StatelessRuleProperty[] | undefined;
    }
    interface RulesSourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#rules_string AwsRuleGroup#rules_string}
        */
        readonly rulesString?: string;
        /**
        * rules_source_list block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#rules_source_list AwsRuleGroup#rules_source_list}
        */
        readonly rulesSourceList?: RulesSourceListProperty;
        /**
        * stateful_rule block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#stateful_rule AwsRuleGroup#stateful_rule}
        */
        readonly statefulRule?: StatefulRuleProperty[] | cdktn.IResolvable;
        /**
        * stateless_rules_and_custom_actions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#stateless_rules_and_custom_actions AwsRuleGroup#stateless_rules_and_custom_actions}
        */
        readonly statelessRulesAndCustomActions?: StatelessRulesAndCustomActionsProperty;
    }
    class RulesSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RulesSourceProperty | undefined;
        set internalValue(value: RulesSourceProperty | undefined);
        private _rulesString?;
        get rulesString(): string;
        set rulesString(value: string);
        resetRulesString(): void;
        get rulesStringInput(): string | undefined;
        private _rulesSourceList;
        get rulesSourceList(): RulesSourceListPropertyOutputReference;
        putRulesSourceList(value: RulesSourceListProperty): void;
        resetRulesSourceList(): void;
        get rulesSourceListInput(): RulesSourceListProperty | undefined;
        private _statefulRule;
        get statefulRule(): StatefulRulePropertyList;
        putStatefulRule(value: StatefulRuleProperty[] | cdktn.IResolvable): void;
        resetStatefulRule(): void;
        get statefulRuleInput(): cdktn.IResolvable | StatefulRuleProperty[] | undefined;
        private _statelessRulesAndCustomActions;
        get statelessRulesAndCustomActions(): StatelessRulesAndCustomActionsPropertyOutputReference;
        putStatelessRulesAndCustomActions(value: StatelessRulesAndCustomActionsProperty): void;
        resetStatelessRulesAndCustomActions(): void;
        get statelessRulesAndCustomActionsInput(): StatelessRulesAndCustomActionsProperty | undefined;
    }
    interface StatefulRuleOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#rule_order AwsRuleGroup#rule_order}
        */
        readonly ruleOrder: string;
    }
    class StatefulRuleOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StatefulRuleOptionsProperty | undefined;
        set internalValue(value: StatefulRuleOptionsProperty | undefined);
        private _ruleOrder?;
        get ruleOrder(): string;
        set ruleOrder(value: string);
        get ruleOrderInput(): string | undefined;
    }
    interface RuleGroupProperty {
        /**
        * reference_sets block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#reference_sets AwsRuleGroup#reference_sets}
        */
        readonly referenceSets?: ReferenceSetsProperty;
        /**
        * rule_variables block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#rule_variables AwsRuleGroup#rule_variables}
        */
        readonly ruleVariables?: RuleVariablesProperty;
        /**
        * rules_source block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#rules_source AwsRuleGroup#rules_source}
        */
        readonly rulesSource: RulesSourceProperty;
        /**
        * stateful_rule_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_rule_group#stateful_rule_options AwsRuleGroup#stateful_rule_options}
        */
        readonly statefulRuleOptions?: StatefulRuleOptionsProperty;
    }
    class RuleGroupPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleGroupProperty | undefined;
        set internalValue(value: RuleGroupProperty | undefined);
        private _referenceSets;
        get referenceSets(): ReferenceSetsPropertyOutputReference;
        putReferenceSets(value: ReferenceSetsProperty): void;
        resetReferenceSets(): void;
        get referenceSetsInput(): ReferenceSetsProperty | undefined;
        private _ruleVariables;
        get ruleVariables(): RuleVariablesPropertyOutputReference;
        putRuleVariables(value: RuleVariablesProperty): void;
        resetRuleVariables(): void;
        get ruleVariablesInput(): RuleVariablesProperty | undefined;
        private _rulesSource;
        get rulesSource(): RulesSourcePropertyOutputReference;
        putRulesSource(value: RulesSourceProperty): void;
        get rulesSourceInput(): RulesSourceProperty | undefined;
        private _statefulRuleOptions;
        get statefulRuleOptions(): StatefulRuleOptionsPropertyOutputReference;
        putStatefulRuleOptions(value: StatefulRuleOptionsProperty): void;
        resetStatefulRuleOptions(): void;
        get statefulRuleOptionsInput(): StatefulRuleOptionsProperty | undefined;
    }
}
