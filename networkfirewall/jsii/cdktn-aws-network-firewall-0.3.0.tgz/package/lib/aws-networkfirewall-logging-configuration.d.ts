import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsLoggingConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_logging_configuration#enable_monitoring_dashboard AwsLoggingConfiguration#enable_monitoring_dashboard}
    */
    readonly enableMonitoringDashboard?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_logging_configuration#firewall_arn AwsLoggingConfiguration#firewall_arn}
    */
    readonly firewallArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_logging_configuration#id AwsLoggingConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_logging_configuration#region AwsLoggingConfiguration#region}
    */
    readonly region?: string;
    /**
    * logging_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_logging_configuration#logging_configuration AwsLoggingConfiguration#logging_configuration}
    */
    readonly loggingConfiguration: AwsLoggingConfiguration.LoggingConfigurationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_logging_configuration aws_networkfirewall_logging_configuration}
*/
export declare class AwsLoggingConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_networkfirewall_logging_configuration";
    /**
    * Generates CDKTN code for importing a AwsLoggingConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsLoggingConfiguration to import
    * @param importFromId The id of the existing AwsLoggingConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_logging_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsLoggingConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_logging_configuration aws_networkfirewall_logging_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsLoggingConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AwsLoggingConfigurationConfig);
    private _enableMonitoringDashboard?;
    get enableMonitoringDashboard(): boolean | cdktn.IResolvable;
    set enableMonitoringDashboard(value: boolean | cdktn.IResolvable);
    resetEnableMonitoringDashboard(): void;
    get enableMonitoringDashboardInput(): boolean | cdktn.IResolvable | undefined;
    private _firewallArn?;
    get firewallArn(): string;
    set firewallArn(value: string);
    get firewallArnInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _loggingConfiguration;
    get loggingConfiguration(): AwsLoggingConfiguration.LoggingConfigurationPropertyOutputReference;
    putLoggingConfiguration(value: AwsLoggingConfiguration.LoggingConfigurationProperty): void;
    get loggingConfigurationInput(): AwsLoggingConfiguration.LoggingConfigurationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsLoggingConfigurationLogDestinationConfigPropertyToTerraform(struct?: AwsLoggingConfiguration.LogDestinationConfigProperty | cdktn.IResolvable): any;
export declare function awsLoggingConfigurationLogDestinationConfigPropertyToHclTerraform(struct?: AwsLoggingConfiguration.LogDestinationConfigProperty | cdktn.IResolvable): any;
export declare function awsLoggingConfigurationLoggingConfigurationPropertyToTerraform(struct?: AwsLoggingConfiguration.LoggingConfigurationPropertyOutputReference | AwsLoggingConfiguration.LoggingConfigurationProperty): any;
export declare function awsLoggingConfigurationLoggingConfigurationPropertyToHclTerraform(struct?: AwsLoggingConfiguration.LoggingConfigurationPropertyOutputReference | AwsLoggingConfiguration.LoggingConfigurationProperty): any;
export declare namespace AwsLoggingConfiguration {
    interface LogDestinationConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_logging_configuration#log_destination AwsLoggingConfiguration#log_destination}
        */
        readonly logDestination: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_logging_configuration#log_destination_type AwsLoggingConfiguration#log_destination_type}
        */
        readonly logDestinationType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_logging_configuration#log_type AwsLoggingConfiguration#log_type}
        */
        readonly logType: string;
    }
    class LogDestinationConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LogDestinationConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LogDestinationConfigProperty | cdktn.IResolvable | undefined);
        private _logDestination?;
        get logDestination(): {
            [key: string]: string;
        };
        set logDestination(value: {
            [key: string]: string;
        });
        get logDestinationInput(): {
            [key: string]: string;
        } | undefined;
        private _logDestinationType?;
        get logDestinationType(): string;
        set logDestinationType(value: string);
        get logDestinationTypeInput(): string | undefined;
        private _logType?;
        get logType(): string;
        set logType(value: string);
        get logTypeInput(): string | undefined;
    }
    class LogDestinationConfigPropertyList extends cdktn.ComplexList {
        internalValue?: LogDestinationConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LogDestinationConfigPropertyOutputReference;
    }
    interface LoggingConfigurationProperty {
        /**
        * log_destination_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_logging_configuration#log_destination_config AwsLoggingConfiguration#log_destination_config}
        */
        readonly logDestinationConfig: LogDestinationConfigProperty[] | cdktn.IResolvable;
    }
    class LoggingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LoggingConfigurationProperty | undefined;
        set internalValue(value: LoggingConfigurationProperty | undefined);
        private _logDestinationConfig;
        get logDestinationConfig(): LogDestinationConfigPropertyList;
        putLogDestinationConfig(value: LogDestinationConfigProperty[] | cdktn.IResolvable): void;
        get logDestinationConfigInput(): cdktn.IResolvable | LogDestinationConfigProperty[] | undefined;
    }
}
