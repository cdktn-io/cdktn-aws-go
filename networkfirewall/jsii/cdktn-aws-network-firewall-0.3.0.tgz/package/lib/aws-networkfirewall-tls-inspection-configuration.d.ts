import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsTlsInspectionConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_tls_inspection_configuration#description AwsTlsInspectionConfiguration#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_tls_inspection_configuration#encryption_configuration AwsTlsInspectionConfiguration#encryption_configuration}
    */
    readonly encryptionConfiguration?: AwsTlsInspectionConfiguration.EncryptionConfigurationProperty[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_tls_inspection_configuration#name AwsTlsInspectionConfiguration#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_tls_inspection_configuration#region AwsTlsInspectionConfiguration#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_tls_inspection_configuration#tags AwsTlsInspectionConfiguration#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_tls_inspection_configuration#timeouts AwsTlsInspectionConfiguration#timeouts}
    */
    readonly timeouts?: AwsTlsInspectionConfiguration.TimeoutsProperty;
    /**
    * tls_inspection_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_tls_inspection_configuration#tls_inspection_configuration AwsTlsInspectionConfiguration#tls_inspection_configuration}
    */
    readonly tlsInspectionConfiguration?: AwsTlsInspectionConfiguration.TlsInspectionConfigurationProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_tls_inspection_configuration aws_networkfirewall_tls_inspection_configuration}
*/
export declare class AwsTlsInspectionConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_networkfirewall_tls_inspection_configuration";
    /**
    * Generates CDKTN code for importing a AwsTlsInspectionConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsTlsInspectionConfiguration to import
    * @param importFromId The id of the existing AwsTlsInspectionConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_tls_inspection_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsTlsInspectionConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_tls_inspection_configuration aws_networkfirewall_tls_inspection_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsTlsInspectionConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AwsTlsInspectionConfigurationConfig);
    get arn(): string;
    private _certificateAuthority;
    get certificateAuthority(): AwsTlsInspectionConfiguration.CertificateAuthorityPropertyList;
    private _certificates;
    get certificates(): AwsTlsInspectionConfiguration.CertificatesPropertyList;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _encryptionConfiguration;
    get encryptionConfiguration(): AwsTlsInspectionConfiguration.EncryptionConfigurationPropertyList;
    putEncryptionConfiguration(value: AwsTlsInspectionConfiguration.EncryptionConfigurationProperty[] | cdktn.IResolvable): void;
    resetEncryptionConfiguration(): void;
    get encryptionConfigurationInput(): cdktn.IResolvable | AwsTlsInspectionConfiguration.EncryptionConfigurationProperty[] | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get numberOfAssociations(): number;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    get tlsInspectionConfigurationId(): string;
    get updateToken(): string;
    private _timeouts;
    get timeouts(): AwsTlsInspectionConfiguration.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsTlsInspectionConfiguration.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsTlsInspectionConfiguration.TimeoutsProperty | undefined;
    private _tlsInspectionConfiguration;
    get tlsInspectionConfiguration(): AwsTlsInspectionConfiguration.TlsInspectionConfigurationPropertyList;
    putTlsInspectionConfiguration(value: AwsTlsInspectionConfiguration.TlsInspectionConfigurationProperty[] | cdktn.IResolvable): void;
    resetTlsInspectionConfiguration(): void;
    get tlsInspectionConfigurationInput(): cdktn.IResolvable | AwsTlsInspectionConfiguration.TlsInspectionConfigurationProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsTlsInspectionConfigurationCertificateAuthorityPropertyToTerraform(struct?: AwsTlsInspectionConfiguration.CertificateAuthorityProperty): any;
export declare function awsTlsInspectionConfigurationCertificateAuthorityPropertyToHclTerraform(struct?: AwsTlsInspectionConfiguration.CertificateAuthorityProperty): any;
export declare function awsTlsInspectionConfigurationCertificatesPropertyToTerraform(struct?: AwsTlsInspectionConfiguration.CertificatesProperty): any;
export declare function awsTlsInspectionConfigurationCertificatesPropertyToHclTerraform(struct?: AwsTlsInspectionConfiguration.CertificatesProperty): any;
export declare function awsTlsInspectionConfigurationEncryptionConfigurationPropertyToTerraform(struct?: AwsTlsInspectionConfiguration.EncryptionConfigurationProperty | cdktn.IResolvable): any;
export declare function awsTlsInspectionConfigurationEncryptionConfigurationPropertyToHclTerraform(struct?: AwsTlsInspectionConfiguration.EncryptionConfigurationProperty | cdktn.IResolvable): any;
export declare function awsTlsInspectionConfigurationTimeoutsPropertyToTerraform(struct?: AwsTlsInspectionConfiguration.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsTlsInspectionConfigurationTimeoutsPropertyToHclTerraform(struct?: AwsTlsInspectionConfiguration.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsTlsInspectionConfigurationCheckCertificateRevocationStatusPropertyToTerraform(struct?: AwsTlsInspectionConfiguration.CheckCertificateRevocationStatusProperty | cdktn.IResolvable): any;
export declare function awsTlsInspectionConfigurationCheckCertificateRevocationStatusPropertyToHclTerraform(struct?: AwsTlsInspectionConfiguration.CheckCertificateRevocationStatusProperty | cdktn.IResolvable): any;
export declare function awsTlsInspectionConfigurationDestinationPropertyToTerraform(struct?: AwsTlsInspectionConfiguration.DestinationProperty | cdktn.IResolvable): any;
export declare function awsTlsInspectionConfigurationDestinationPropertyToHclTerraform(struct?: AwsTlsInspectionConfiguration.DestinationProperty | cdktn.IResolvable): any;
export declare function awsTlsInspectionConfigurationDestinationPortsPropertyToTerraform(struct?: AwsTlsInspectionConfiguration.DestinationPortsProperty | cdktn.IResolvable): any;
export declare function awsTlsInspectionConfigurationDestinationPortsPropertyToHclTerraform(struct?: AwsTlsInspectionConfiguration.DestinationPortsProperty | cdktn.IResolvable): any;
export declare function awsTlsInspectionConfigurationSourcePropertyToTerraform(struct?: AwsTlsInspectionConfiguration.SourceProperty | cdktn.IResolvable): any;
export declare function awsTlsInspectionConfigurationSourcePropertyToHclTerraform(struct?: AwsTlsInspectionConfiguration.SourceProperty | cdktn.IResolvable): any;
export declare function awsTlsInspectionConfigurationSourcePortsPropertyToTerraform(struct?: AwsTlsInspectionConfiguration.SourcePortsProperty | cdktn.IResolvable): any;
export declare function awsTlsInspectionConfigurationSourcePortsPropertyToHclTerraform(struct?: AwsTlsInspectionConfiguration.SourcePortsProperty | cdktn.IResolvable): any;
export declare function awsTlsInspectionConfigurationScopePropertyToTerraform(struct?: AwsTlsInspectionConfiguration.ScopeProperty | cdktn.IResolvable): any;
export declare function awsTlsInspectionConfigurationScopePropertyToHclTerraform(struct?: AwsTlsInspectionConfiguration.ScopeProperty | cdktn.IResolvable): any;
export declare function awsTlsInspectionConfigurationServerCertificatePropertyToTerraform(struct?: AwsTlsInspectionConfiguration.ServerCertificateProperty | cdktn.IResolvable): any;
export declare function awsTlsInspectionConfigurationServerCertificatePropertyToHclTerraform(struct?: AwsTlsInspectionConfiguration.ServerCertificateProperty | cdktn.IResolvable): any;
export declare function awsTlsInspectionConfigurationServerCertificateConfigurationPropertyToTerraform(struct?: AwsTlsInspectionConfiguration.ServerCertificateConfigurationProperty | cdktn.IResolvable): any;
export declare function awsTlsInspectionConfigurationServerCertificateConfigurationPropertyToHclTerraform(struct?: AwsTlsInspectionConfiguration.ServerCertificateConfigurationProperty | cdktn.IResolvable): any;
export declare function awsTlsInspectionConfigurationTlsInspectionConfigurationPropertyToTerraform(struct?: AwsTlsInspectionConfiguration.TlsInspectionConfigurationProperty | cdktn.IResolvable): any;
export declare function awsTlsInspectionConfigurationTlsInspectionConfigurationPropertyToHclTerraform(struct?: AwsTlsInspectionConfiguration.TlsInspectionConfigurationProperty | cdktn.IResolvable): any;
export declare namespace AwsTlsInspectionConfiguration {
    interface CertificateAuthorityProperty {
    }
    class CertificateAuthorityPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CertificateAuthorityProperty | undefined;
        set internalValue(value: CertificateAuthorityProperty | undefined);
        get certificateArn(): string;
        get certificateSerial(): string;
        get status(): string;
        get statusMessage(): string;
    }
    class CertificateAuthorityPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CertificateAuthorityPropertyOutputReference;
    }
    interface CertificatesProperty {
    }
    class CertificatesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CertificatesProperty | undefined;
        set internalValue(value: CertificatesProperty | undefined);
        get certificateArn(): string;
        get certificateSerial(): string;
        get status(): string;
        get statusMessage(): string;
    }
    class CertificatesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CertificatesPropertyOutputReference;
    }
    interface EncryptionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_tls_inspection_configuration#key_id AwsTlsInspectionConfiguration#key_id}
        */
        readonly keyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_tls_inspection_configuration#type AwsTlsInspectionConfiguration#type}
        */
        readonly type?: string;
    }
    class EncryptionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EncryptionConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EncryptionConfigurationProperty | cdktn.IResolvable | undefined);
        private _keyId?;
        get keyId(): string;
        set keyId(value: string);
        resetKeyId(): void;
        get keyIdInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
    }
    class EncryptionConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: EncryptionConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EncryptionConfigurationPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_tls_inspection_configuration#create AwsTlsInspectionConfiguration#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_tls_inspection_configuration#delete AwsTlsInspectionConfiguration#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_tls_inspection_configuration#update AwsTlsInspectionConfiguration#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface CheckCertificateRevocationStatusProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_tls_inspection_configuration#revoked_status_action AwsTlsInspectionConfiguration#revoked_status_action}
        */
        readonly revokedStatusAction?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_tls_inspection_configuration#unknown_status_action AwsTlsInspectionConfiguration#unknown_status_action}
        */
        readonly unknownStatusAction?: string;
    }
    class CheckCertificateRevocationStatusPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CheckCertificateRevocationStatusProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CheckCertificateRevocationStatusProperty | cdktn.IResolvable | undefined);
        private _revokedStatusAction?;
        get revokedStatusAction(): string;
        set revokedStatusAction(value: string);
        resetRevokedStatusAction(): void;
        get revokedStatusActionInput(): string | undefined;
        private _unknownStatusAction?;
        get unknownStatusAction(): string;
        set unknownStatusAction(value: string);
        resetUnknownStatusAction(): void;
        get unknownStatusActionInput(): string | undefined;
    }
    class CheckCertificateRevocationStatusPropertyList extends cdktn.ComplexList {
        internalValue?: CheckCertificateRevocationStatusProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CheckCertificateRevocationStatusPropertyOutputReference;
    }
    interface DestinationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_tls_inspection_configuration#address_definition AwsTlsInspectionConfiguration#address_definition}
        */
        readonly addressDefinition: string;
    }
    class DestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DestinationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DestinationProperty | cdktn.IResolvable | undefined);
        private _addressDefinition?;
        get addressDefinition(): string;
        set addressDefinition(value: string);
        get addressDefinitionInput(): string | undefined;
    }
    class DestinationPropertyList extends cdktn.ComplexList {
        internalValue?: DestinationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DestinationPropertyOutputReference;
    }
    interface DestinationPortsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_tls_inspection_configuration#from_port AwsTlsInspectionConfiguration#from_port}
        */
        readonly fromPort: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_tls_inspection_configuration#to_port AwsTlsInspectionConfiguration#to_port}
        */
        readonly toPort: number;
    }
    class DestinationPortsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DestinationPortsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DestinationPortsProperty | cdktn.IResolvable | undefined);
        private _fromPort?;
        get fromPort(): number;
        set fromPort(value: number);
        get fromPortInput(): number | undefined;
        private _toPort?;
        get toPort(): number;
        set toPort(value: number);
        get toPortInput(): number | undefined;
    }
    class DestinationPortsPropertyList extends cdktn.ComplexList {
        internalValue?: DestinationPortsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DestinationPortsPropertyOutputReference;
    }
    interface SourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_tls_inspection_configuration#address_definition AwsTlsInspectionConfiguration#address_definition}
        */
        readonly addressDefinition: string;
    }
    class SourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SourceProperty | cdktn.IResolvable | undefined);
        private _addressDefinition?;
        get addressDefinition(): string;
        set addressDefinition(value: string);
        get addressDefinitionInput(): string | undefined;
    }
    class SourcePropertyList extends cdktn.ComplexList {
        internalValue?: SourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SourcePropertyOutputReference;
    }
    interface SourcePortsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_tls_inspection_configuration#from_port AwsTlsInspectionConfiguration#from_port}
        */
        readonly fromPort: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_tls_inspection_configuration#to_port AwsTlsInspectionConfiguration#to_port}
        */
        readonly toPort: number;
    }
    class SourcePortsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SourcePortsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SourcePortsProperty | cdktn.IResolvable | undefined);
        private _fromPort?;
        get fromPort(): number;
        set fromPort(value: number);
        get fromPortInput(): number | undefined;
        private _toPort?;
        get toPort(): number;
        set toPort(value: number);
        get toPortInput(): number | undefined;
    }
    class SourcePortsPropertyList extends cdktn.ComplexList {
        internalValue?: SourcePortsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SourcePortsPropertyOutputReference;
    }
    interface ScopeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_tls_inspection_configuration#protocols AwsTlsInspectionConfiguration#protocols}
        */
        readonly protocols: number[];
        /**
        * destination block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_tls_inspection_configuration#destination AwsTlsInspectionConfiguration#destination}
        */
        readonly destination?: DestinationProperty[] | cdktn.IResolvable;
        /**
        * destination_ports block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_tls_inspection_configuration#destination_ports AwsTlsInspectionConfiguration#destination_ports}
        */
        readonly destinationPorts?: DestinationPortsProperty[] | cdktn.IResolvable;
        /**
        * source block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_tls_inspection_configuration#source AwsTlsInspectionConfiguration#source}
        */
        readonly source?: SourceProperty[] | cdktn.IResolvable;
        /**
        * source_ports block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_tls_inspection_configuration#source_ports AwsTlsInspectionConfiguration#source_ports}
        */
        readonly sourcePorts?: SourcePortsProperty[] | cdktn.IResolvable;
    }
    class ScopePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ScopeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ScopeProperty | cdktn.IResolvable | undefined);
        private _protocols?;
        get protocols(): number[];
        set protocols(value: number[]);
        get protocolsInput(): number[] | undefined;
        private _destination;
        get destination(): DestinationPropertyList;
        putDestination(value: DestinationProperty[] | cdktn.IResolvable): void;
        resetDestination(): void;
        get destinationInput(): cdktn.IResolvable | DestinationProperty[] | undefined;
        private _destinationPorts;
        get destinationPorts(): DestinationPortsPropertyList;
        putDestinationPorts(value: DestinationPortsProperty[] | cdktn.IResolvable): void;
        resetDestinationPorts(): void;
        get destinationPortsInput(): cdktn.IResolvable | DestinationPortsProperty[] | undefined;
        private _source;
        get source(): SourcePropertyList;
        putSource(value: SourceProperty[] | cdktn.IResolvable): void;
        resetSource(): void;
        get sourceInput(): cdktn.IResolvable | SourceProperty[] | undefined;
        private _sourcePorts;
        get sourcePorts(): SourcePortsPropertyList;
        putSourcePorts(value: SourcePortsProperty[] | cdktn.IResolvable): void;
        resetSourcePorts(): void;
        get sourcePortsInput(): cdktn.IResolvable | SourcePortsProperty[] | undefined;
    }
    class ScopePropertyList extends cdktn.ComplexList {
        internalValue?: ScopeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ScopePropertyOutputReference;
    }
    interface ServerCertificateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_tls_inspection_configuration#resource_arn AwsTlsInspectionConfiguration#resource_arn}
        */
        readonly resourceArn?: string;
    }
    class ServerCertificatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ServerCertificateProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ServerCertificateProperty | cdktn.IResolvable | undefined);
        private _resourceArn?;
        get resourceArn(): string;
        set resourceArn(value: string);
        resetResourceArn(): void;
        get resourceArnInput(): string | undefined;
    }
    class ServerCertificatePropertyList extends cdktn.ComplexList {
        internalValue?: ServerCertificateProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ServerCertificatePropertyOutputReference;
    }
    interface ServerCertificateConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_tls_inspection_configuration#certificate_authority_arn AwsTlsInspectionConfiguration#certificate_authority_arn}
        */
        readonly certificateAuthorityArn?: string;
        /**
        * check_certificate_revocation_status block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_tls_inspection_configuration#check_certificate_revocation_status AwsTlsInspectionConfiguration#check_certificate_revocation_status}
        */
        readonly checkCertificateRevocationStatus?: CheckCertificateRevocationStatusProperty[] | cdktn.IResolvable;
        /**
        * scope block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_tls_inspection_configuration#scope AwsTlsInspectionConfiguration#scope}
        */
        readonly scope?: ScopeProperty[] | cdktn.IResolvable;
        /**
        * server_certificate block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_tls_inspection_configuration#server_certificate AwsTlsInspectionConfiguration#server_certificate}
        */
        readonly serverCertificate?: ServerCertificateProperty[] | cdktn.IResolvable;
    }
    class ServerCertificateConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ServerCertificateConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ServerCertificateConfigurationProperty | cdktn.IResolvable | undefined);
        private _certificateAuthorityArn?;
        get certificateAuthorityArn(): string;
        set certificateAuthorityArn(value: string);
        resetCertificateAuthorityArn(): void;
        get certificateAuthorityArnInput(): string | undefined;
        private _checkCertificateRevocationStatus;
        get checkCertificateRevocationStatus(): CheckCertificateRevocationStatusPropertyList;
        putCheckCertificateRevocationStatus(value: CheckCertificateRevocationStatusProperty[] | cdktn.IResolvable): void;
        resetCheckCertificateRevocationStatus(): void;
        get checkCertificateRevocationStatusInput(): cdktn.IResolvable | CheckCertificateRevocationStatusProperty[] | undefined;
        private _scope;
        get scope(): ScopePropertyList;
        putScope(value: ScopeProperty[] | cdktn.IResolvable): void;
        resetScope(): void;
        get scopeInput(): cdktn.IResolvable | ScopeProperty[] | undefined;
        private _serverCertificate;
        get serverCertificate(): ServerCertificatePropertyList;
        putServerCertificate(value: ServerCertificateProperty[] | cdktn.IResolvable): void;
        resetServerCertificate(): void;
        get serverCertificateInput(): cdktn.IResolvable | ServerCertificateProperty[] | undefined;
    }
    class ServerCertificateConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: ServerCertificateConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ServerCertificateConfigurationPropertyOutputReference;
    }
    interface TlsInspectionConfigurationProperty {
        /**
        * server_certificate_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_tls_inspection_configuration#server_certificate_configuration AwsTlsInspectionConfiguration#server_certificate_configuration}
        */
        readonly serverCertificateConfiguration?: ServerCertificateConfigurationProperty[] | cdktn.IResolvable;
    }
    class TlsInspectionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TlsInspectionConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TlsInspectionConfigurationProperty | cdktn.IResolvable | undefined);
        private _serverCertificateConfiguration;
        get serverCertificateConfiguration(): ServerCertificateConfigurationPropertyList;
        putServerCertificateConfiguration(value: ServerCertificateConfigurationProperty[] | cdktn.IResolvable): void;
        resetServerCertificateConfiguration(): void;
        get serverCertificateConfigurationInput(): cdktn.IResolvable | ServerCertificateConfigurationProperty[] | undefined;
    }
    class TlsInspectionConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: TlsInspectionConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TlsInspectionConfigurationPropertyOutputReference;
    }
}
