import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfTopicRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#description TfTopicRule#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#enabled TfTopicRule#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#id TfTopicRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#name TfTopicRule#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#region TfTopicRule#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#sql TfTopicRule#sql}
    */
    readonly sql: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#sql_version TfTopicRule#sql_version}
    */
    readonly sqlVersion: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#tags TfTopicRule#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#tags_all TfTopicRule#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * cloudwatch_alarm block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#cloudwatch_alarm TfTopicRule#cloudwatch_alarm}
    */
    readonly cloudwatchAlarm?: TfTopicRule.CloudwatchAlarmProperty[] | cdktn.IResolvable;
    /**
    * cloudwatch_logs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#cloudwatch_logs TfTopicRule#cloudwatch_logs}
    */
    readonly cloudwatchLogs?: TfTopicRule.CloudwatchLogsProperty[] | cdktn.IResolvable;
    /**
    * cloudwatch_metric block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#cloudwatch_metric TfTopicRule#cloudwatch_metric}
    */
    readonly cloudwatchMetric?: TfTopicRule.CloudwatchMetricProperty[] | cdktn.IResolvable;
    /**
    * dynamodb block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#dynamodb TfTopicRule#dynamodb}
    */
    readonly dynamodb?: TfTopicRule.DynamodbProperty[] | cdktn.IResolvable;
    /**
    * dynamodbv2 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#dynamodbv2 TfTopicRule#dynamodbv2}
    */
    readonly dynamodbv2?: TfTopicRule.Dynamodbv2Property[] | cdktn.IResolvable;
    /**
    * elasticsearch block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#elasticsearch TfTopicRule#elasticsearch}
    */
    readonly elasticsearch?: TfTopicRule.ElasticsearchProperty[] | cdktn.IResolvable;
    /**
    * error_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#error_action TfTopicRule#error_action}
    */
    readonly errorAction?: TfTopicRule.ErrorActionProperty;
    /**
    * firehose block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#firehose TfTopicRule#firehose}
    */
    readonly firehose?: TfTopicRule.FirehoseProperty[] | cdktn.IResolvable;
    /**
    * http block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#http TfTopicRule#http}
    */
    readonly http?: TfTopicRule.HttpProperty[] | cdktn.IResolvable;
    /**
    * iot_analytics block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#iot_analytics TfTopicRule#iot_analytics}
    */
    readonly iotAnalytics?: TfTopicRule.IotAnalyticsProperty[] | cdktn.IResolvable;
    /**
    * iot_events block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#iot_events TfTopicRule#iot_events}
    */
    readonly iotEvents?: TfTopicRule.IotEventsProperty[] | cdktn.IResolvable;
    /**
    * kafka block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#kafka TfTopicRule#kafka}
    */
    readonly kafka?: TfTopicRule.KafkaProperty[] | cdktn.IResolvable;
    /**
    * kinesis block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#kinesis TfTopicRule#kinesis}
    */
    readonly kinesis?: TfTopicRule.KinesisProperty[] | cdktn.IResolvable;
    /**
    * lambda block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#lambda TfTopicRule#lambda}
    */
    readonly lambda?: TfTopicRule.LambdaProperty[] | cdktn.IResolvable;
    /**
    * republish block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#republish TfTopicRule#republish}
    */
    readonly republish?: TfTopicRule.RepublishProperty[] | cdktn.IResolvable;
    /**
    * s3 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#s3 TfTopicRule#s3}
    */
    readonly s3?: TfTopicRule.S3Property[] | cdktn.IResolvable;
    /**
    * sns block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#sns TfTopicRule#sns}
    */
    readonly sns?: TfTopicRule.SnsProperty[] | cdktn.IResolvable;
    /**
    * sqs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#sqs TfTopicRule#sqs}
    */
    readonly sqs?: TfTopicRule.SqsProperty[] | cdktn.IResolvable;
    /**
    * step_functions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#step_functions TfTopicRule#step_functions}
    */
    readonly stepFunctions?: TfTopicRule.StepFunctionsProperty[] | cdktn.IResolvable;
    /**
    * timestream block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#timestream TfTopicRule#timestream}
    */
    readonly timestream?: TfTopicRule.TimestreamProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule aws_iot_topic_rule}
*/
export declare class TfTopicRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_iot_topic_rule";
    /**
    * Generates CDKTN code for importing a TfTopicRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfTopicRule to import
    * @param importFromId The id of the existing TfTopicRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfTopicRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule aws_iot_topic_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfTopicRuleConfig
    */
    constructor(scope: Construct, id: string, config: TfTopicRuleConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _sql?;
    get sql(): string;
    set sql(value: string);
    get sqlInput(): string | undefined;
    private _sqlVersion?;
    get sqlVersion(): string;
    set sqlVersion(value: string);
    get sqlVersionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _cloudwatchAlarm;
    get cloudwatchAlarm(): TfTopicRule.CloudwatchAlarmPropertyList;
    putCloudwatchAlarm(value: TfTopicRule.CloudwatchAlarmProperty[] | cdktn.IResolvable): void;
    resetCloudwatchAlarm(): void;
    get cloudwatchAlarmInput(): cdktn.IResolvable | TfTopicRule.CloudwatchAlarmProperty[] | undefined;
    private _cloudwatchLogs;
    get cloudwatchLogs(): TfTopicRule.CloudwatchLogsPropertyList;
    putCloudwatchLogs(value: TfTopicRule.CloudwatchLogsProperty[] | cdktn.IResolvable): void;
    resetCloudwatchLogs(): void;
    get cloudwatchLogsInput(): cdktn.IResolvable | TfTopicRule.CloudwatchLogsProperty[] | undefined;
    private _cloudwatchMetric;
    get cloudwatchMetric(): TfTopicRule.CloudwatchMetricPropertyList;
    putCloudwatchMetric(value: TfTopicRule.CloudwatchMetricProperty[] | cdktn.IResolvable): void;
    resetCloudwatchMetric(): void;
    get cloudwatchMetricInput(): cdktn.IResolvable | TfTopicRule.CloudwatchMetricProperty[] | undefined;
    private _dynamodb;
    get dynamodb(): TfTopicRule.DynamodbPropertyList;
    putDynamodb(value: TfTopicRule.DynamodbProperty[] | cdktn.IResolvable): void;
    resetDynamodb(): void;
    get dynamodbInput(): cdktn.IResolvable | TfTopicRule.DynamodbProperty[] | undefined;
    private _dynamodbv2;
    get dynamodbv2(): TfTopicRule.Dynamodbv2PropertyList;
    putDynamodbv2(value: TfTopicRule.Dynamodbv2Property[] | cdktn.IResolvable): void;
    resetDynamodbv2(): void;
    get dynamodbv2Input(): cdktn.IResolvable | TfTopicRule.Dynamodbv2Property[] | undefined;
    private _elasticsearch;
    get elasticsearch(): TfTopicRule.ElasticsearchPropertyList;
    putElasticsearch(value: TfTopicRule.ElasticsearchProperty[] | cdktn.IResolvable): void;
    resetElasticsearch(): void;
    get elasticsearchInput(): cdktn.IResolvable | TfTopicRule.ElasticsearchProperty[] | undefined;
    private _errorAction;
    get errorAction(): TfTopicRule.ErrorActionPropertyOutputReference;
    putErrorAction(value: TfTopicRule.ErrorActionProperty): void;
    resetErrorAction(): void;
    get errorActionInput(): TfTopicRule.ErrorActionProperty | undefined;
    private _firehose;
    get firehose(): TfTopicRule.FirehosePropertyList;
    putFirehose(value: TfTopicRule.FirehoseProperty[] | cdktn.IResolvable): void;
    resetFirehose(): void;
    get firehoseInput(): cdktn.IResolvable | TfTopicRule.FirehoseProperty[] | undefined;
    private _http;
    get http(): TfTopicRule.HttpPropertyList;
    putHttp(value: TfTopicRule.HttpProperty[] | cdktn.IResolvable): void;
    resetHttp(): void;
    get httpInput(): cdktn.IResolvable | TfTopicRule.HttpProperty[] | undefined;
    private _iotAnalytics;
    get iotAnalytics(): TfTopicRule.IotAnalyticsPropertyList;
    putIotAnalytics(value: TfTopicRule.IotAnalyticsProperty[] | cdktn.IResolvable): void;
    resetIotAnalytics(): void;
    get iotAnalyticsInput(): cdktn.IResolvable | TfTopicRule.IotAnalyticsProperty[] | undefined;
    private _iotEvents;
    get iotEvents(): TfTopicRule.IotEventsPropertyList;
    putIotEvents(value: TfTopicRule.IotEventsProperty[] | cdktn.IResolvable): void;
    resetIotEvents(): void;
    get iotEventsInput(): cdktn.IResolvable | TfTopicRule.IotEventsProperty[] | undefined;
    private _kafka;
    get kafka(): TfTopicRule.KafkaPropertyList;
    putKafka(value: TfTopicRule.KafkaProperty[] | cdktn.IResolvable): void;
    resetKafka(): void;
    get kafkaInput(): cdktn.IResolvable | TfTopicRule.KafkaProperty[] | undefined;
    private _kinesis;
    get kinesis(): TfTopicRule.KinesisPropertyList;
    putKinesis(value: TfTopicRule.KinesisProperty[] | cdktn.IResolvable): void;
    resetKinesis(): void;
    get kinesisInput(): cdktn.IResolvable | TfTopicRule.KinesisProperty[] | undefined;
    private _lambda;
    get lambda(): TfTopicRule.LambdaPropertyList;
    putLambda(value: TfTopicRule.LambdaProperty[] | cdktn.IResolvable): void;
    resetLambda(): void;
    get lambdaInput(): cdktn.IResolvable | TfTopicRule.LambdaProperty[] | undefined;
    private _republish;
    get republish(): TfTopicRule.RepublishPropertyList;
    putRepublish(value: TfTopicRule.RepublishProperty[] | cdktn.IResolvable): void;
    resetRepublish(): void;
    get republishInput(): cdktn.IResolvable | TfTopicRule.RepublishProperty[] | undefined;
    private _s3;
    get s3(): TfTopicRule.S3PropertyList;
    putS3(value: TfTopicRule.S3Property[] | cdktn.IResolvable): void;
    resetS3(): void;
    get s3Input(): cdktn.IResolvable | TfTopicRule.S3Property[] | undefined;
    private _sns;
    get sns(): TfTopicRule.SnsPropertyList;
    putSns(value: TfTopicRule.SnsProperty[] | cdktn.IResolvable): void;
    resetSns(): void;
    get snsInput(): cdktn.IResolvable | TfTopicRule.SnsProperty[] | undefined;
    private _sqs;
    get sqs(): TfTopicRule.SqsPropertyList;
    putSqs(value: TfTopicRule.SqsProperty[] | cdktn.IResolvable): void;
    resetSqs(): void;
    get sqsInput(): cdktn.IResolvable | TfTopicRule.SqsProperty[] | undefined;
    private _stepFunctions;
    get stepFunctions(): TfTopicRule.StepFunctionsPropertyList;
    putStepFunctions(value: TfTopicRule.StepFunctionsProperty[] | cdktn.IResolvable): void;
    resetStepFunctions(): void;
    get stepFunctionsInput(): cdktn.IResolvable | TfTopicRule.StepFunctionsProperty[] | undefined;
    private _timestream;
    get timestream(): TfTopicRule.TimestreamPropertyList;
    putTimestream(value: TfTopicRule.TimestreamProperty[] | cdktn.IResolvable): void;
    resetTimestream(): void;
    get timestreamInput(): cdktn.IResolvable | TfTopicRule.TimestreamProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfTopicRuleCloudwatchAlarmPropertyToTerraform(struct?: TfTopicRule.CloudwatchAlarmProperty | cdktn.IResolvable): any;
export declare function tfTopicRuleCloudwatchAlarmPropertyToHclTerraform(struct?: TfTopicRule.CloudwatchAlarmProperty | cdktn.IResolvable): any;
export declare function tfTopicRuleCloudwatchLogsPropertyToTerraform(struct?: TfTopicRule.CloudwatchLogsProperty | cdktn.IResolvable): any;
export declare function tfTopicRuleCloudwatchLogsPropertyToHclTerraform(struct?: TfTopicRule.CloudwatchLogsProperty | cdktn.IResolvable): any;
export declare function tfTopicRuleCloudwatchMetricPropertyToTerraform(struct?: TfTopicRule.CloudwatchMetricProperty | cdktn.IResolvable): any;
export declare function tfTopicRuleCloudwatchMetricPropertyToHclTerraform(struct?: TfTopicRule.CloudwatchMetricProperty | cdktn.IResolvable): any;
export declare function tfTopicRuleDynamodbPropertyToTerraform(struct?: TfTopicRule.DynamodbProperty | cdktn.IResolvable): any;
export declare function tfTopicRuleDynamodbPropertyToHclTerraform(struct?: TfTopicRule.DynamodbProperty | cdktn.IResolvable): any;
export declare function tfTopicRuleDynamodbv2PutItemPropertyToTerraform(struct?: TfTopicRule.Dynamodbv2PutItemPropertyOutputReference | TfTopicRule.Dynamodbv2PutItemProperty): any;
export declare function tfTopicRuleDynamodbv2PutItemPropertyToHclTerraform(struct?: TfTopicRule.Dynamodbv2PutItemPropertyOutputReference | TfTopicRule.Dynamodbv2PutItemProperty): any;
export declare function tfTopicRuleDynamodbv2PropertyToTerraform(struct?: TfTopicRule.Dynamodbv2Property | cdktn.IResolvable): any;
export declare function tfTopicRuleDynamodbv2PropertyToHclTerraform(struct?: TfTopicRule.Dynamodbv2Property | cdktn.IResolvable): any;
export declare function tfTopicRuleElasticsearchPropertyToTerraform(struct?: TfTopicRule.ElasticsearchProperty | cdktn.IResolvable): any;
export declare function tfTopicRuleElasticsearchPropertyToHclTerraform(struct?: TfTopicRule.ElasticsearchProperty | cdktn.IResolvable): any;
export declare function tfTopicRuleErrorActionCloudwatchAlarmPropertyToTerraform(struct?: TfTopicRule.ErrorActionCloudwatchAlarmPropertyOutputReference | TfTopicRule.ErrorActionCloudwatchAlarmProperty): any;
export declare function tfTopicRuleErrorActionCloudwatchAlarmPropertyToHclTerraform(struct?: TfTopicRule.ErrorActionCloudwatchAlarmPropertyOutputReference | TfTopicRule.ErrorActionCloudwatchAlarmProperty): any;
export declare function tfTopicRuleErrorActionCloudwatchLogsPropertyToTerraform(struct?: TfTopicRule.ErrorActionCloudwatchLogsPropertyOutputReference | TfTopicRule.ErrorActionCloudwatchLogsProperty): any;
export declare function tfTopicRuleErrorActionCloudwatchLogsPropertyToHclTerraform(struct?: TfTopicRule.ErrorActionCloudwatchLogsPropertyOutputReference | TfTopicRule.ErrorActionCloudwatchLogsProperty): any;
export declare function tfTopicRuleErrorActionCloudwatchMetricPropertyToTerraform(struct?: TfTopicRule.ErrorActionCloudwatchMetricPropertyOutputReference | TfTopicRule.ErrorActionCloudwatchMetricProperty): any;
export declare function tfTopicRuleErrorActionCloudwatchMetricPropertyToHclTerraform(struct?: TfTopicRule.ErrorActionCloudwatchMetricPropertyOutputReference | TfTopicRule.ErrorActionCloudwatchMetricProperty): any;
export declare function tfTopicRuleErrorActionDynamodbPropertyToTerraform(struct?: TfTopicRule.ErrorActionDynamodbPropertyOutputReference | TfTopicRule.ErrorActionDynamodbProperty): any;
export declare function tfTopicRuleErrorActionDynamodbPropertyToHclTerraform(struct?: TfTopicRule.ErrorActionDynamodbPropertyOutputReference | TfTopicRule.ErrorActionDynamodbProperty): any;
export declare function tfTopicRuleErrorActionDynamodbv2PutItemPropertyToTerraform(struct?: TfTopicRule.ErrorActionDynamodbv2PutItemPropertyOutputReference | TfTopicRule.ErrorActionDynamodbv2PutItemProperty): any;
export declare function tfTopicRuleErrorActionDynamodbv2PutItemPropertyToHclTerraform(struct?: TfTopicRule.ErrorActionDynamodbv2PutItemPropertyOutputReference | TfTopicRule.ErrorActionDynamodbv2PutItemProperty): any;
export declare function tfTopicRuleErrorActionDynamodbv2PropertyToTerraform(struct?: TfTopicRule.ErrorActionDynamodbv2PropertyOutputReference | TfTopicRule.ErrorActionDynamodbv2Property): any;
export declare function tfTopicRuleErrorActionDynamodbv2PropertyToHclTerraform(struct?: TfTopicRule.ErrorActionDynamodbv2PropertyOutputReference | TfTopicRule.ErrorActionDynamodbv2Property): any;
export declare function tfTopicRuleErrorActionElasticsearchPropertyToTerraform(struct?: TfTopicRule.ErrorActionElasticsearchPropertyOutputReference | TfTopicRule.ErrorActionElasticsearchProperty): any;
export declare function tfTopicRuleErrorActionElasticsearchPropertyToHclTerraform(struct?: TfTopicRule.ErrorActionElasticsearchPropertyOutputReference | TfTopicRule.ErrorActionElasticsearchProperty): any;
export declare function tfTopicRuleErrorActionFirehosePropertyToTerraform(struct?: TfTopicRule.ErrorActionFirehosePropertyOutputReference | TfTopicRule.ErrorActionFirehoseProperty): any;
export declare function tfTopicRuleErrorActionFirehosePropertyToHclTerraform(struct?: TfTopicRule.ErrorActionFirehosePropertyOutputReference | TfTopicRule.ErrorActionFirehoseProperty): any;
export declare function tfTopicRuleErrorActionHttpHttpHeaderPropertyToTerraform(struct?: TfTopicRule.ErrorActionHttpHttpHeaderProperty | cdktn.IResolvable): any;
export declare function tfTopicRuleErrorActionHttpHttpHeaderPropertyToHclTerraform(struct?: TfTopicRule.ErrorActionHttpHttpHeaderProperty | cdktn.IResolvable): any;
export declare function tfTopicRuleErrorActionHttpPropertyToTerraform(struct?: TfTopicRule.ErrorActionHttpPropertyOutputReference | TfTopicRule.ErrorActionHttpProperty): any;
export declare function tfTopicRuleErrorActionHttpPropertyToHclTerraform(struct?: TfTopicRule.ErrorActionHttpPropertyOutputReference | TfTopicRule.ErrorActionHttpProperty): any;
export declare function tfTopicRuleErrorActionIotAnalyticsPropertyToTerraform(struct?: TfTopicRule.ErrorActionIotAnalyticsPropertyOutputReference | TfTopicRule.ErrorActionIotAnalyticsProperty): any;
export declare function tfTopicRuleErrorActionIotAnalyticsPropertyToHclTerraform(struct?: TfTopicRule.ErrorActionIotAnalyticsPropertyOutputReference | TfTopicRule.ErrorActionIotAnalyticsProperty): any;
export declare function tfTopicRuleErrorActionIotEventsPropertyToTerraform(struct?: TfTopicRule.ErrorActionIotEventsPropertyOutputReference | TfTopicRule.ErrorActionIotEventsProperty): any;
export declare function tfTopicRuleErrorActionIotEventsPropertyToHclTerraform(struct?: TfTopicRule.ErrorActionIotEventsPropertyOutputReference | TfTopicRule.ErrorActionIotEventsProperty): any;
export declare function tfTopicRuleErrorActionKafkaHeaderPropertyToTerraform(struct?: TfTopicRule.ErrorActionKafkaHeaderProperty | cdktn.IResolvable): any;
export declare function tfTopicRuleErrorActionKafkaHeaderPropertyToHclTerraform(struct?: TfTopicRule.ErrorActionKafkaHeaderProperty | cdktn.IResolvable): any;
export declare function tfTopicRuleErrorActionKafkaPropertyToTerraform(struct?: TfTopicRule.ErrorActionKafkaPropertyOutputReference | TfTopicRule.ErrorActionKafkaProperty): any;
export declare function tfTopicRuleErrorActionKafkaPropertyToHclTerraform(struct?: TfTopicRule.ErrorActionKafkaPropertyOutputReference | TfTopicRule.ErrorActionKafkaProperty): any;
export declare function tfTopicRuleErrorActionKinesisPropertyToTerraform(struct?: TfTopicRule.ErrorActionKinesisPropertyOutputReference | TfTopicRule.ErrorActionKinesisProperty): any;
export declare function tfTopicRuleErrorActionKinesisPropertyToHclTerraform(struct?: TfTopicRule.ErrorActionKinesisPropertyOutputReference | TfTopicRule.ErrorActionKinesisProperty): any;
export declare function tfTopicRuleErrorActionLambdaPropertyToTerraform(struct?: TfTopicRule.ErrorActionLambdaPropertyOutputReference | TfTopicRule.ErrorActionLambdaProperty): any;
export declare function tfTopicRuleErrorActionLambdaPropertyToHclTerraform(struct?: TfTopicRule.ErrorActionLambdaPropertyOutputReference | TfTopicRule.ErrorActionLambdaProperty): any;
export declare function tfTopicRuleErrorActionRepublishPropertyToTerraform(struct?: TfTopicRule.ErrorActionRepublishPropertyOutputReference | TfTopicRule.ErrorActionRepublishProperty): any;
export declare function tfTopicRuleErrorActionRepublishPropertyToHclTerraform(struct?: TfTopicRule.ErrorActionRepublishPropertyOutputReference | TfTopicRule.ErrorActionRepublishProperty): any;
export declare function tfTopicRuleErrorActionS3PropertyToTerraform(struct?: TfTopicRule.ErrorActionS3PropertyOutputReference | TfTopicRule.ErrorActionS3Property): any;
export declare function tfTopicRuleErrorActionS3PropertyToHclTerraform(struct?: TfTopicRule.ErrorActionS3PropertyOutputReference | TfTopicRule.ErrorActionS3Property): any;
export declare function tfTopicRuleErrorActionSnsPropertyToTerraform(struct?: TfTopicRule.ErrorActionSnsPropertyOutputReference | TfTopicRule.ErrorActionSnsProperty): any;
export declare function tfTopicRuleErrorActionSnsPropertyToHclTerraform(struct?: TfTopicRule.ErrorActionSnsPropertyOutputReference | TfTopicRule.ErrorActionSnsProperty): any;
export declare function tfTopicRuleErrorActionSqsPropertyToTerraform(struct?: TfTopicRule.ErrorActionSqsPropertyOutputReference | TfTopicRule.ErrorActionSqsProperty): any;
export declare function tfTopicRuleErrorActionSqsPropertyToHclTerraform(struct?: TfTopicRule.ErrorActionSqsPropertyOutputReference | TfTopicRule.ErrorActionSqsProperty): any;
export declare function tfTopicRuleErrorActionStepFunctionsPropertyToTerraform(struct?: TfTopicRule.ErrorActionStepFunctionsPropertyOutputReference | TfTopicRule.ErrorActionStepFunctionsProperty): any;
export declare function tfTopicRuleErrorActionStepFunctionsPropertyToHclTerraform(struct?: TfTopicRule.ErrorActionStepFunctionsPropertyOutputReference | TfTopicRule.ErrorActionStepFunctionsProperty): any;
export declare function tfTopicRuleErrorActionTimestreamDimensionPropertyToTerraform(struct?: TfTopicRule.ErrorActionTimestreamDimensionProperty | cdktn.IResolvable): any;
export declare function tfTopicRuleErrorActionTimestreamDimensionPropertyToHclTerraform(struct?: TfTopicRule.ErrorActionTimestreamDimensionProperty | cdktn.IResolvable): any;
export declare function tfTopicRuleErrorActionTimestreamTimestampPropertyToTerraform(struct?: TfTopicRule.ErrorActionTimestreamTimestampPropertyOutputReference | TfTopicRule.ErrorActionTimestreamTimestampProperty): any;
export declare function tfTopicRuleErrorActionTimestreamTimestampPropertyToHclTerraform(struct?: TfTopicRule.ErrorActionTimestreamTimestampPropertyOutputReference | TfTopicRule.ErrorActionTimestreamTimestampProperty): any;
export declare function tfTopicRuleErrorActionTimestreamPropertyToTerraform(struct?: TfTopicRule.ErrorActionTimestreamPropertyOutputReference | TfTopicRule.ErrorActionTimestreamProperty): any;
export declare function tfTopicRuleErrorActionTimestreamPropertyToHclTerraform(struct?: TfTopicRule.ErrorActionTimestreamPropertyOutputReference | TfTopicRule.ErrorActionTimestreamProperty): any;
export declare function tfTopicRuleErrorActionPropertyToTerraform(struct?: TfTopicRule.ErrorActionPropertyOutputReference | TfTopicRule.ErrorActionProperty): any;
export declare function tfTopicRuleErrorActionPropertyToHclTerraform(struct?: TfTopicRule.ErrorActionPropertyOutputReference | TfTopicRule.ErrorActionProperty): any;
export declare function tfTopicRuleFirehosePropertyToTerraform(struct?: TfTopicRule.FirehoseProperty | cdktn.IResolvable): any;
export declare function tfTopicRuleFirehosePropertyToHclTerraform(struct?: TfTopicRule.FirehoseProperty | cdktn.IResolvable): any;
export declare function tfTopicRuleHttpHttpHeaderPropertyToTerraform(struct?: TfTopicRule.HttpHttpHeaderProperty | cdktn.IResolvable): any;
export declare function tfTopicRuleHttpHttpHeaderPropertyToHclTerraform(struct?: TfTopicRule.HttpHttpHeaderProperty | cdktn.IResolvable): any;
export declare function tfTopicRuleHttpPropertyToTerraform(struct?: TfTopicRule.HttpProperty | cdktn.IResolvable): any;
export declare function tfTopicRuleHttpPropertyToHclTerraform(struct?: TfTopicRule.HttpProperty | cdktn.IResolvable): any;
export declare function tfTopicRuleIotAnalyticsPropertyToTerraform(struct?: TfTopicRule.IotAnalyticsProperty | cdktn.IResolvable): any;
export declare function tfTopicRuleIotAnalyticsPropertyToHclTerraform(struct?: TfTopicRule.IotAnalyticsProperty | cdktn.IResolvable): any;
export declare function tfTopicRuleIotEventsPropertyToTerraform(struct?: TfTopicRule.IotEventsProperty | cdktn.IResolvable): any;
export declare function tfTopicRuleIotEventsPropertyToHclTerraform(struct?: TfTopicRule.IotEventsProperty | cdktn.IResolvable): any;
export declare function tfTopicRuleKafkaHeaderPropertyToTerraform(struct?: TfTopicRule.KafkaHeaderProperty | cdktn.IResolvable): any;
export declare function tfTopicRuleKafkaHeaderPropertyToHclTerraform(struct?: TfTopicRule.KafkaHeaderProperty | cdktn.IResolvable): any;
export declare function tfTopicRuleKafkaPropertyToTerraform(struct?: TfTopicRule.KafkaProperty | cdktn.IResolvable): any;
export declare function tfTopicRuleKafkaPropertyToHclTerraform(struct?: TfTopicRule.KafkaProperty | cdktn.IResolvable): any;
export declare function tfTopicRuleKinesisPropertyToTerraform(struct?: TfTopicRule.KinesisProperty | cdktn.IResolvable): any;
export declare function tfTopicRuleKinesisPropertyToHclTerraform(struct?: TfTopicRule.KinesisProperty | cdktn.IResolvable): any;
export declare function tfTopicRuleLambdaPropertyToTerraform(struct?: TfTopicRule.LambdaProperty | cdktn.IResolvable): any;
export declare function tfTopicRuleLambdaPropertyToHclTerraform(struct?: TfTopicRule.LambdaProperty | cdktn.IResolvable): any;
export declare function tfTopicRuleRepublishPropertyToTerraform(struct?: TfTopicRule.RepublishProperty | cdktn.IResolvable): any;
export declare function tfTopicRuleRepublishPropertyToHclTerraform(struct?: TfTopicRule.RepublishProperty | cdktn.IResolvable): any;
export declare function tfTopicRuleS3PropertyToTerraform(struct?: TfTopicRule.S3Property | cdktn.IResolvable): any;
export declare function tfTopicRuleS3PropertyToHclTerraform(struct?: TfTopicRule.S3Property | cdktn.IResolvable): any;
export declare function tfTopicRuleSnsPropertyToTerraform(struct?: TfTopicRule.SnsProperty | cdktn.IResolvable): any;
export declare function tfTopicRuleSnsPropertyToHclTerraform(struct?: TfTopicRule.SnsProperty | cdktn.IResolvable): any;
export declare function tfTopicRuleSqsPropertyToTerraform(struct?: TfTopicRule.SqsProperty | cdktn.IResolvable): any;
export declare function tfTopicRuleSqsPropertyToHclTerraform(struct?: TfTopicRule.SqsProperty | cdktn.IResolvable): any;
export declare function tfTopicRuleStepFunctionsPropertyToTerraform(struct?: TfTopicRule.StepFunctionsProperty | cdktn.IResolvable): any;
export declare function tfTopicRuleStepFunctionsPropertyToHclTerraform(struct?: TfTopicRule.StepFunctionsProperty | cdktn.IResolvable): any;
export declare function tfTopicRuleTimestreamDimensionPropertyToTerraform(struct?: TfTopicRule.TimestreamDimensionProperty | cdktn.IResolvable): any;
export declare function tfTopicRuleTimestreamDimensionPropertyToHclTerraform(struct?: TfTopicRule.TimestreamDimensionProperty | cdktn.IResolvable): any;
export declare function tfTopicRuleTimestreamTimestampPropertyToTerraform(struct?: TfTopicRule.TimestreamTimestampPropertyOutputReference | TfTopicRule.TimestreamTimestampProperty): any;
export declare function tfTopicRuleTimestreamTimestampPropertyToHclTerraform(struct?: TfTopicRule.TimestreamTimestampPropertyOutputReference | TfTopicRule.TimestreamTimestampProperty): any;
export declare function tfTopicRuleTimestreamPropertyToTerraform(struct?: TfTopicRule.TimestreamProperty | cdktn.IResolvable): any;
export declare function tfTopicRuleTimestreamPropertyToHclTerraform(struct?: TfTopicRule.TimestreamProperty | cdktn.IResolvable): any;
export declare namespace TfTopicRule {
    interface CloudwatchAlarmProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#alarm_name TfTopicRule#alarm_name}
        */
        readonly alarmName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn TfTopicRule#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#state_reason TfTopicRule#state_reason}
        */
        readonly stateReason: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#state_value TfTopicRule#state_value}
        */
        readonly stateValue: string;
    }
    class CloudwatchAlarmPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CloudwatchAlarmProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CloudwatchAlarmProperty | cdktn.IResolvable | undefined);
        private _alarmName?;
        get alarmName(): string;
        set alarmName(value: string);
        get alarmNameInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _stateReason?;
        get stateReason(): string;
        set stateReason(value: string);
        get stateReasonInput(): string | undefined;
        private _stateValue?;
        get stateValue(): string;
        set stateValue(value: string);
        get stateValueInput(): string | undefined;
    }
    class CloudwatchAlarmPropertyList extends cdktn.ComplexList {
        internalValue?: CloudwatchAlarmProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CloudwatchAlarmPropertyOutputReference;
    }
    interface CloudwatchLogsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#batch_mode TfTopicRule#batch_mode}
        */
        readonly batchMode?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#log_group_name TfTopicRule#log_group_name}
        */
        readonly logGroupName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn TfTopicRule#role_arn}
        */
        readonly roleArn: string;
    }
    class CloudwatchLogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CloudwatchLogsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CloudwatchLogsProperty | cdktn.IResolvable | undefined);
        private _batchMode?;
        get batchMode(): boolean | cdktn.IResolvable;
        set batchMode(value: boolean | cdktn.IResolvable);
        resetBatchMode(): void;
        get batchModeInput(): boolean | cdktn.IResolvable | undefined;
        private _logGroupName?;
        get logGroupName(): string;
        set logGroupName(value: string);
        get logGroupNameInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
    }
    class CloudwatchLogsPropertyList extends cdktn.ComplexList {
        internalValue?: CloudwatchLogsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CloudwatchLogsPropertyOutputReference;
    }
    interface CloudwatchMetricProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#metric_name TfTopicRule#metric_name}
        */
        readonly metricName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#metric_namespace TfTopicRule#metric_namespace}
        */
        readonly metricNamespace: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#metric_timestamp TfTopicRule#metric_timestamp}
        */
        readonly metricTimestamp?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#metric_unit TfTopicRule#metric_unit}
        */
        readonly metricUnit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#metric_value TfTopicRule#metric_value}
        */
        readonly metricValue: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn TfTopicRule#role_arn}
        */
        readonly roleArn: string;
    }
    class CloudwatchMetricPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CloudwatchMetricProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CloudwatchMetricProperty | cdktn.IResolvable | undefined);
        private _metricName?;
        get metricName(): string;
        set metricName(value: string);
        get metricNameInput(): string | undefined;
        private _metricNamespace?;
        get metricNamespace(): string;
        set metricNamespace(value: string);
        get metricNamespaceInput(): string | undefined;
        private _metricTimestamp?;
        get metricTimestamp(): string;
        set metricTimestamp(value: string);
        resetMetricTimestamp(): void;
        get metricTimestampInput(): string | undefined;
        private _metricUnit?;
        get metricUnit(): string;
        set metricUnit(value: string);
        get metricUnitInput(): string | undefined;
        private _metricValue?;
        get metricValue(): string;
        set metricValue(value: string);
        get metricValueInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
    }
    class CloudwatchMetricPropertyList extends cdktn.ComplexList {
        internalValue?: CloudwatchMetricProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CloudwatchMetricPropertyOutputReference;
    }
    interface DynamodbProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#hash_key_field TfTopicRule#hash_key_field}
        */
        readonly hashKeyField: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#hash_key_type TfTopicRule#hash_key_type}
        */
        readonly hashKeyType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#hash_key_value TfTopicRule#hash_key_value}
        */
        readonly hashKeyValue: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#operation TfTopicRule#operation}
        */
        readonly operation?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#payload_field TfTopicRule#payload_field}
        */
        readonly payloadField?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#range_key_field TfTopicRule#range_key_field}
        */
        readonly rangeKeyField?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#range_key_type TfTopicRule#range_key_type}
        */
        readonly rangeKeyType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#range_key_value TfTopicRule#range_key_value}
        */
        readonly rangeKeyValue?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn TfTopicRule#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#table_name TfTopicRule#table_name}
        */
        readonly tableName: string;
    }
    class DynamodbPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DynamodbProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DynamodbProperty | cdktn.IResolvable | undefined);
        private _hashKeyField?;
        get hashKeyField(): string;
        set hashKeyField(value: string);
        get hashKeyFieldInput(): string | undefined;
        private _hashKeyType?;
        get hashKeyType(): string;
        set hashKeyType(value: string);
        resetHashKeyType(): void;
        get hashKeyTypeInput(): string | undefined;
        private _hashKeyValue?;
        get hashKeyValue(): string;
        set hashKeyValue(value: string);
        get hashKeyValueInput(): string | undefined;
        private _operation?;
        get operation(): string;
        set operation(value: string);
        resetOperation(): void;
        get operationInput(): string | undefined;
        private _payloadField?;
        get payloadField(): string;
        set payloadField(value: string);
        resetPayloadField(): void;
        get payloadFieldInput(): string | undefined;
        private _rangeKeyField?;
        get rangeKeyField(): string;
        set rangeKeyField(value: string);
        resetRangeKeyField(): void;
        get rangeKeyFieldInput(): string | undefined;
        private _rangeKeyType?;
        get rangeKeyType(): string;
        set rangeKeyType(value: string);
        resetRangeKeyType(): void;
        get rangeKeyTypeInput(): string | undefined;
        private _rangeKeyValue?;
        get rangeKeyValue(): string;
        set rangeKeyValue(value: string);
        resetRangeKeyValue(): void;
        get rangeKeyValueInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _tableName?;
        get tableName(): string;
        set tableName(value: string);
        get tableNameInput(): string | undefined;
    }
    class DynamodbPropertyList extends cdktn.ComplexList {
        internalValue?: DynamodbProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DynamodbPropertyOutputReference;
    }
    interface Dynamodbv2PutItemProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#table_name TfTopicRule#table_name}
        */
        readonly tableName: string;
    }
    class Dynamodbv2PutItemPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): Dynamodbv2PutItemProperty | undefined;
        set internalValue(value: Dynamodbv2PutItemProperty | undefined);
        private _tableName?;
        get tableName(): string;
        set tableName(value: string);
        get tableNameInput(): string | undefined;
    }
    interface Dynamodbv2Property {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn TfTopicRule#role_arn}
        */
        readonly roleArn: string;
        /**
        * put_item block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#put_item TfTopicRule#put_item}
        */
        readonly putItem?: Dynamodbv2PutItemProperty;
    }
    class Dynamodbv2PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): Dynamodbv2Property | cdktn.IResolvable | undefined;
        set internalValue(value: Dynamodbv2Property | cdktn.IResolvable | undefined);
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _putItem;
        get putItem(): Dynamodbv2PutItemPropertyOutputReference;
        putPutItem(value: Dynamodbv2PutItemProperty): void;
        resetPutItem(): void;
        get putItemInput(): Dynamodbv2PutItemProperty | undefined;
    }
    class Dynamodbv2PropertyList extends cdktn.ComplexList {
        internalValue?: Dynamodbv2Property[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): Dynamodbv2PropertyOutputReference;
    }
    interface ElasticsearchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#endpoint TfTopicRule#endpoint}
        */
        readonly endpoint: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#id TfTopicRule#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#index TfTopicRule#index}
        */
        readonly index: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn TfTopicRule#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#type TfTopicRule#type}
        */
        readonly type: string;
    }
    class ElasticsearchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ElasticsearchProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ElasticsearchProperty | cdktn.IResolvable | undefined);
        private _endpoint?;
        get endpoint(): string;
        set endpoint(value: string);
        get endpointInput(): string | undefined;
        private _id?;
        get id(): string;
        set id(value: string);
        get idInput(): string | undefined;
        private _index?;
        get index(): string;
        set index(value: string);
        get indexInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class ElasticsearchPropertyList extends cdktn.ComplexList {
        internalValue?: ElasticsearchProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ElasticsearchPropertyOutputReference;
    }
    interface ErrorActionCloudwatchAlarmProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#alarm_name TfTopicRule#alarm_name}
        */
        readonly alarmName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn TfTopicRule#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#state_reason TfTopicRule#state_reason}
        */
        readonly stateReason: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#state_value TfTopicRule#state_value}
        */
        readonly stateValue: string;
    }
    class ErrorActionCloudwatchAlarmPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ErrorActionCloudwatchAlarmProperty | undefined;
        set internalValue(value: ErrorActionCloudwatchAlarmProperty | undefined);
        private _alarmName?;
        get alarmName(): string;
        set alarmName(value: string);
        get alarmNameInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _stateReason?;
        get stateReason(): string;
        set stateReason(value: string);
        get stateReasonInput(): string | undefined;
        private _stateValue?;
        get stateValue(): string;
        set stateValue(value: string);
        get stateValueInput(): string | undefined;
    }
    interface ErrorActionCloudwatchLogsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#batch_mode TfTopicRule#batch_mode}
        */
        readonly batchMode?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#log_group_name TfTopicRule#log_group_name}
        */
        readonly logGroupName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn TfTopicRule#role_arn}
        */
        readonly roleArn: string;
    }
    class ErrorActionCloudwatchLogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ErrorActionCloudwatchLogsProperty | undefined;
        set internalValue(value: ErrorActionCloudwatchLogsProperty | undefined);
        private _batchMode?;
        get batchMode(): boolean | cdktn.IResolvable;
        set batchMode(value: boolean | cdktn.IResolvable);
        resetBatchMode(): void;
        get batchModeInput(): boolean | cdktn.IResolvable | undefined;
        private _logGroupName?;
        get logGroupName(): string;
        set logGroupName(value: string);
        get logGroupNameInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
    }
    interface ErrorActionCloudwatchMetricProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#metric_name TfTopicRule#metric_name}
        */
        readonly metricName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#metric_namespace TfTopicRule#metric_namespace}
        */
        readonly metricNamespace: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#metric_timestamp TfTopicRule#metric_timestamp}
        */
        readonly metricTimestamp?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#metric_unit TfTopicRule#metric_unit}
        */
        readonly metricUnit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#metric_value TfTopicRule#metric_value}
        */
        readonly metricValue: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn TfTopicRule#role_arn}
        */
        readonly roleArn: string;
    }
    class ErrorActionCloudwatchMetricPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ErrorActionCloudwatchMetricProperty | undefined;
        set internalValue(value: ErrorActionCloudwatchMetricProperty | undefined);
        private _metricName?;
        get metricName(): string;
        set metricName(value: string);
        get metricNameInput(): string | undefined;
        private _metricNamespace?;
        get metricNamespace(): string;
        set metricNamespace(value: string);
        get metricNamespaceInput(): string | undefined;
        private _metricTimestamp?;
        get metricTimestamp(): string;
        set metricTimestamp(value: string);
        resetMetricTimestamp(): void;
        get metricTimestampInput(): string | undefined;
        private _metricUnit?;
        get metricUnit(): string;
        set metricUnit(value: string);
        get metricUnitInput(): string | undefined;
        private _metricValue?;
        get metricValue(): string;
        set metricValue(value: string);
        get metricValueInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
    }
    interface ErrorActionDynamodbProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#hash_key_field TfTopicRule#hash_key_field}
        */
        readonly hashKeyField: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#hash_key_type TfTopicRule#hash_key_type}
        */
        readonly hashKeyType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#hash_key_value TfTopicRule#hash_key_value}
        */
        readonly hashKeyValue: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#operation TfTopicRule#operation}
        */
        readonly operation?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#payload_field TfTopicRule#payload_field}
        */
        readonly payloadField?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#range_key_field TfTopicRule#range_key_field}
        */
        readonly rangeKeyField?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#range_key_type TfTopicRule#range_key_type}
        */
        readonly rangeKeyType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#range_key_value TfTopicRule#range_key_value}
        */
        readonly rangeKeyValue?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn TfTopicRule#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#table_name TfTopicRule#table_name}
        */
        readonly tableName: string;
    }
    class ErrorActionDynamodbPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ErrorActionDynamodbProperty | undefined;
        set internalValue(value: ErrorActionDynamodbProperty | undefined);
        private _hashKeyField?;
        get hashKeyField(): string;
        set hashKeyField(value: string);
        get hashKeyFieldInput(): string | undefined;
        private _hashKeyType?;
        get hashKeyType(): string;
        set hashKeyType(value: string);
        resetHashKeyType(): void;
        get hashKeyTypeInput(): string | undefined;
        private _hashKeyValue?;
        get hashKeyValue(): string;
        set hashKeyValue(value: string);
        get hashKeyValueInput(): string | undefined;
        private _operation?;
        get operation(): string;
        set operation(value: string);
        resetOperation(): void;
        get operationInput(): string | undefined;
        private _payloadField?;
        get payloadField(): string;
        set payloadField(value: string);
        resetPayloadField(): void;
        get payloadFieldInput(): string | undefined;
        private _rangeKeyField?;
        get rangeKeyField(): string;
        set rangeKeyField(value: string);
        resetRangeKeyField(): void;
        get rangeKeyFieldInput(): string | undefined;
        private _rangeKeyType?;
        get rangeKeyType(): string;
        set rangeKeyType(value: string);
        resetRangeKeyType(): void;
        get rangeKeyTypeInput(): string | undefined;
        private _rangeKeyValue?;
        get rangeKeyValue(): string;
        set rangeKeyValue(value: string);
        resetRangeKeyValue(): void;
        get rangeKeyValueInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _tableName?;
        get tableName(): string;
        set tableName(value: string);
        get tableNameInput(): string | undefined;
    }
    interface ErrorActionDynamodbv2PutItemProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#table_name TfTopicRule#table_name}
        */
        readonly tableName: string;
    }
    class ErrorActionDynamodbv2PutItemPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ErrorActionDynamodbv2PutItemProperty | undefined;
        set internalValue(value: ErrorActionDynamodbv2PutItemProperty | undefined);
        private _tableName?;
        get tableName(): string;
        set tableName(value: string);
        get tableNameInput(): string | undefined;
    }
    interface ErrorActionDynamodbv2Property {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn TfTopicRule#role_arn}
        */
        readonly roleArn: string;
        /**
        * put_item block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#put_item TfTopicRule#put_item}
        */
        readonly putItem?: ErrorActionDynamodbv2PutItemProperty;
    }
    class ErrorActionDynamodbv2PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ErrorActionDynamodbv2Property | undefined;
        set internalValue(value: ErrorActionDynamodbv2Property | undefined);
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _putItem;
        get putItem(): ErrorActionDynamodbv2PutItemPropertyOutputReference;
        putPutItem(value: ErrorActionDynamodbv2PutItemProperty): void;
        resetPutItem(): void;
        get putItemInput(): ErrorActionDynamodbv2PutItemProperty | undefined;
    }
    interface ErrorActionElasticsearchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#endpoint TfTopicRule#endpoint}
        */
        readonly endpoint: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#id TfTopicRule#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#index TfTopicRule#index}
        */
        readonly index: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn TfTopicRule#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#type TfTopicRule#type}
        */
        readonly type: string;
    }
    class ErrorActionElasticsearchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ErrorActionElasticsearchProperty | undefined;
        set internalValue(value: ErrorActionElasticsearchProperty | undefined);
        private _endpoint?;
        get endpoint(): string;
        set endpoint(value: string);
        get endpointInput(): string | undefined;
        private _id?;
        get id(): string;
        set id(value: string);
        get idInput(): string | undefined;
        private _index?;
        get index(): string;
        set index(value: string);
        get indexInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    interface ErrorActionFirehoseProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#batch_mode TfTopicRule#batch_mode}
        */
        readonly batchMode?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#delivery_stream_name TfTopicRule#delivery_stream_name}
        */
        readonly deliveryStreamName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn TfTopicRule#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#separator TfTopicRule#separator}
        */
        readonly separator?: string;
    }
    class ErrorActionFirehosePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ErrorActionFirehoseProperty | undefined;
        set internalValue(value: ErrorActionFirehoseProperty | undefined);
        private _batchMode?;
        get batchMode(): boolean | cdktn.IResolvable;
        set batchMode(value: boolean | cdktn.IResolvable);
        resetBatchMode(): void;
        get batchModeInput(): boolean | cdktn.IResolvable | undefined;
        private _deliveryStreamName?;
        get deliveryStreamName(): string;
        set deliveryStreamName(value: string);
        get deliveryStreamNameInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _separator?;
        get separator(): string;
        set separator(value: string);
        resetSeparator(): void;
        get separatorInput(): string | undefined;
    }
    interface ErrorActionHttpHttpHeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#key TfTopicRule#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#value TfTopicRule#value}
        */
        readonly value: string;
    }
    class ErrorActionHttpHttpHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ErrorActionHttpHttpHeaderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ErrorActionHttpHttpHeaderProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ErrorActionHttpHttpHeaderPropertyList extends cdktn.ComplexList {
        internalValue?: ErrorActionHttpHttpHeaderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ErrorActionHttpHttpHeaderPropertyOutputReference;
    }
    interface ErrorActionHttpProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#confirmation_url TfTopicRule#confirmation_url}
        */
        readonly confirmationUrl?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#url TfTopicRule#url}
        */
        readonly url: string;
        /**
        * http_header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#http_header TfTopicRule#http_header}
        */
        readonly httpHeader?: ErrorActionHttpHttpHeaderProperty[] | cdktn.IResolvable;
    }
    class ErrorActionHttpPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ErrorActionHttpProperty | undefined;
        set internalValue(value: ErrorActionHttpProperty | undefined);
        private _confirmationUrl?;
        get confirmationUrl(): string;
        set confirmationUrl(value: string);
        resetConfirmationUrl(): void;
        get confirmationUrlInput(): string | undefined;
        private _url?;
        get url(): string;
        set url(value: string);
        get urlInput(): string | undefined;
        private _httpHeader;
        get httpHeader(): ErrorActionHttpHttpHeaderPropertyList;
        putHttpHeader(value: ErrorActionHttpHttpHeaderProperty[] | cdktn.IResolvable): void;
        resetHttpHeader(): void;
        get httpHeaderInput(): cdktn.IResolvable | ErrorActionHttpHttpHeaderProperty[] | undefined;
    }
    interface ErrorActionIotAnalyticsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#batch_mode TfTopicRule#batch_mode}
        */
        readonly batchMode?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#channel_name TfTopicRule#channel_name}
        */
        readonly channelName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn TfTopicRule#role_arn}
        */
        readonly roleArn: string;
    }
    class ErrorActionIotAnalyticsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ErrorActionIotAnalyticsProperty | undefined;
        set internalValue(value: ErrorActionIotAnalyticsProperty | undefined);
        private _batchMode?;
        get batchMode(): boolean | cdktn.IResolvable;
        set batchMode(value: boolean | cdktn.IResolvable);
        resetBatchMode(): void;
        get batchModeInput(): boolean | cdktn.IResolvable | undefined;
        private _channelName?;
        get channelName(): string;
        set channelName(value: string);
        get channelNameInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
    }
    interface ErrorActionIotEventsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#batch_mode TfTopicRule#batch_mode}
        */
        readonly batchMode?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#input_name TfTopicRule#input_name}
        */
        readonly inputName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#message_id TfTopicRule#message_id}
        */
        readonly messageId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn TfTopicRule#role_arn}
        */
        readonly roleArn: string;
    }
    class ErrorActionIotEventsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ErrorActionIotEventsProperty | undefined;
        set internalValue(value: ErrorActionIotEventsProperty | undefined);
        private _batchMode?;
        get batchMode(): boolean | cdktn.IResolvable;
        set batchMode(value: boolean | cdktn.IResolvable);
        resetBatchMode(): void;
        get batchModeInput(): boolean | cdktn.IResolvable | undefined;
        private _inputName?;
        get inputName(): string;
        set inputName(value: string);
        get inputNameInput(): string | undefined;
        private _messageId?;
        get messageId(): string;
        set messageId(value: string);
        resetMessageId(): void;
        get messageIdInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
    }
    interface ErrorActionKafkaHeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#key TfTopicRule#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#value TfTopicRule#value}
        */
        readonly value: string;
    }
    class ErrorActionKafkaHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ErrorActionKafkaHeaderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ErrorActionKafkaHeaderProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ErrorActionKafkaHeaderPropertyList extends cdktn.ComplexList {
        internalValue?: ErrorActionKafkaHeaderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ErrorActionKafkaHeaderPropertyOutputReference;
    }
    interface ErrorActionKafkaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#client_properties TfTopicRule#client_properties}
        */
        readonly clientProperties: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#destination_arn TfTopicRule#destination_arn}
        */
        readonly destinationArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#key TfTopicRule#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#partition TfTopicRule#partition}
        */
        readonly partition?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#topic TfTopicRule#topic}
        */
        readonly topic: string;
        /**
        * header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#header TfTopicRule#header}
        */
        readonly header?: ErrorActionKafkaHeaderProperty[] | cdktn.IResolvable;
    }
    class ErrorActionKafkaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ErrorActionKafkaProperty | undefined;
        set internalValue(value: ErrorActionKafkaProperty | undefined);
        private _clientProperties?;
        get clientProperties(): {
            [key: string]: string;
        };
        set clientProperties(value: {
            [key: string]: string;
        });
        get clientPropertiesInput(): {
            [key: string]: string;
        } | undefined;
        private _destinationArn?;
        get destinationArn(): string;
        set destinationArn(value: string);
        get destinationArnInput(): string | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _partition?;
        get partition(): string;
        set partition(value: string);
        resetPartition(): void;
        get partitionInput(): string | undefined;
        private _topic?;
        get topic(): string;
        set topic(value: string);
        get topicInput(): string | undefined;
        private _header;
        get header(): ErrorActionKafkaHeaderPropertyList;
        putHeader(value: ErrorActionKafkaHeaderProperty[] | cdktn.IResolvable): void;
        resetHeader(): void;
        get headerInput(): cdktn.IResolvable | ErrorActionKafkaHeaderProperty[] | undefined;
    }
    interface ErrorActionKinesisProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#partition_key TfTopicRule#partition_key}
        */
        readonly partitionKey?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn TfTopicRule#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#stream_name TfTopicRule#stream_name}
        */
        readonly streamName: string;
    }
    class ErrorActionKinesisPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ErrorActionKinesisProperty | undefined;
        set internalValue(value: ErrorActionKinesisProperty | undefined);
        private _partitionKey?;
        get partitionKey(): string;
        set partitionKey(value: string);
        resetPartitionKey(): void;
        get partitionKeyInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _streamName?;
        get streamName(): string;
        set streamName(value: string);
        get streamNameInput(): string | undefined;
    }
    interface ErrorActionLambdaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#function_arn TfTopicRule#function_arn}
        */
        readonly functionArn: string;
    }
    class ErrorActionLambdaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ErrorActionLambdaProperty | undefined;
        set internalValue(value: ErrorActionLambdaProperty | undefined);
        private _functionArn?;
        get functionArn(): string;
        set functionArn(value: string);
        get functionArnInput(): string | undefined;
    }
    interface ErrorActionRepublishProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#qos TfTopicRule#qos}
        */
        readonly qos?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn TfTopicRule#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#topic TfTopicRule#topic}
        */
        readonly topic: string;
    }
    class ErrorActionRepublishPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ErrorActionRepublishProperty | undefined;
        set internalValue(value: ErrorActionRepublishProperty | undefined);
        private _qos?;
        get qos(): number;
        set qos(value: number);
        resetQos(): void;
        get qosInput(): number | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _topic?;
        get topic(): string;
        set topic(value: string);
        get topicInput(): string | undefined;
    }
    interface ErrorActionS3Property {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#bucket_name TfTopicRule#bucket_name}
        */
        readonly bucketName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#canned_acl TfTopicRule#canned_acl}
        */
        readonly cannedAcl?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#key TfTopicRule#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn TfTopicRule#role_arn}
        */
        readonly roleArn: string;
    }
    class ErrorActionS3PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ErrorActionS3Property | undefined;
        set internalValue(value: ErrorActionS3Property | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        get bucketNameInput(): string | undefined;
        private _cannedAcl?;
        get cannedAcl(): string;
        set cannedAcl(value: string);
        resetCannedAcl(): void;
        get cannedAclInput(): string | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
    }
    interface ErrorActionSnsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#message_format TfTopicRule#message_format}
        */
        readonly messageFormat?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn TfTopicRule#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#target_arn TfTopicRule#target_arn}
        */
        readonly targetArn: string;
    }
    class ErrorActionSnsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ErrorActionSnsProperty | undefined;
        set internalValue(value: ErrorActionSnsProperty | undefined);
        private _messageFormat?;
        get messageFormat(): string;
        set messageFormat(value: string);
        resetMessageFormat(): void;
        get messageFormatInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _targetArn?;
        get targetArn(): string;
        set targetArn(value: string);
        get targetArnInput(): string | undefined;
    }
    interface ErrorActionSqsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#queue_url TfTopicRule#queue_url}
        */
        readonly queueUrl: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn TfTopicRule#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#use_base64 TfTopicRule#use_base64}
        */
        readonly useBase64: boolean | cdktn.IResolvable;
    }
    class ErrorActionSqsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ErrorActionSqsProperty | undefined;
        set internalValue(value: ErrorActionSqsProperty | undefined);
        private _queueUrl?;
        get queueUrl(): string;
        set queueUrl(value: string);
        get queueUrlInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _useBase64?;
        get useBase64(): boolean | cdktn.IResolvable;
        set useBase64(value: boolean | cdktn.IResolvable);
        get useBase64Input(): boolean | cdktn.IResolvable | undefined;
    }
    interface ErrorActionStepFunctionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#execution_name_prefix TfTopicRule#execution_name_prefix}
        */
        readonly executionNamePrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn TfTopicRule#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#state_machine_name TfTopicRule#state_machine_name}
        */
        readonly stateMachineName: string;
    }
    class ErrorActionStepFunctionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ErrorActionStepFunctionsProperty | undefined;
        set internalValue(value: ErrorActionStepFunctionsProperty | undefined);
        private _executionNamePrefix?;
        get executionNamePrefix(): string;
        set executionNamePrefix(value: string);
        resetExecutionNamePrefix(): void;
        get executionNamePrefixInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _stateMachineName?;
        get stateMachineName(): string;
        set stateMachineName(value: string);
        get stateMachineNameInput(): string | undefined;
    }
    interface ErrorActionTimestreamDimensionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#name TfTopicRule#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#value TfTopicRule#value}
        */
        readonly value: string;
    }
    class ErrorActionTimestreamDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ErrorActionTimestreamDimensionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ErrorActionTimestreamDimensionProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ErrorActionTimestreamDimensionPropertyList extends cdktn.ComplexList {
        internalValue?: ErrorActionTimestreamDimensionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ErrorActionTimestreamDimensionPropertyOutputReference;
    }
    interface ErrorActionTimestreamTimestampProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#unit TfTopicRule#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#value TfTopicRule#value}
        */
        readonly value: string;
    }
    class ErrorActionTimestreamTimestampPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ErrorActionTimestreamTimestampProperty | undefined;
        set internalValue(value: ErrorActionTimestreamTimestampProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    interface ErrorActionTimestreamProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#database_name TfTopicRule#database_name}
        */
        readonly databaseName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn TfTopicRule#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#table_name TfTopicRule#table_name}
        */
        readonly tableName: string;
        /**
        * dimension block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#dimension TfTopicRule#dimension}
        */
        readonly dimension: ErrorActionTimestreamDimensionProperty[] | cdktn.IResolvable;
        /**
        * timestamp block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#timestamp TfTopicRule#timestamp}
        */
        readonly timestamp?: ErrorActionTimestreamTimestampProperty;
    }
    class ErrorActionTimestreamPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ErrorActionTimestreamProperty | undefined;
        set internalValue(value: ErrorActionTimestreamProperty | undefined);
        private _databaseName?;
        get databaseName(): string;
        set databaseName(value: string);
        get databaseNameInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _tableName?;
        get tableName(): string;
        set tableName(value: string);
        get tableNameInput(): string | undefined;
        private _dimension;
        get dimension(): ErrorActionTimestreamDimensionPropertyList;
        putDimension(value: ErrorActionTimestreamDimensionProperty[] | cdktn.IResolvable): void;
        get dimensionInput(): cdktn.IResolvable | ErrorActionTimestreamDimensionProperty[] | undefined;
        private _timestamp;
        get timestamp(): ErrorActionTimestreamTimestampPropertyOutputReference;
        putTimestamp(value: ErrorActionTimestreamTimestampProperty): void;
        resetTimestamp(): void;
        get timestampInput(): ErrorActionTimestreamTimestampProperty | undefined;
    }
    interface ErrorActionProperty {
        /**
        * cloudwatch_alarm block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#cloudwatch_alarm TfTopicRule#cloudwatch_alarm}
        */
        readonly cloudwatchAlarm?: ErrorActionCloudwatchAlarmProperty;
        /**
        * cloudwatch_logs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#cloudwatch_logs TfTopicRule#cloudwatch_logs}
        */
        readonly cloudwatchLogs?: ErrorActionCloudwatchLogsProperty;
        /**
        * cloudwatch_metric block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#cloudwatch_metric TfTopicRule#cloudwatch_metric}
        */
        readonly cloudwatchMetric?: ErrorActionCloudwatchMetricProperty;
        /**
        * dynamodb block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#dynamodb TfTopicRule#dynamodb}
        */
        readonly dynamodb?: ErrorActionDynamodbProperty;
        /**
        * dynamodbv2 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#dynamodbv2 TfTopicRule#dynamodbv2}
        */
        readonly dynamodbv2?: ErrorActionDynamodbv2Property;
        /**
        * elasticsearch block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#elasticsearch TfTopicRule#elasticsearch}
        */
        readonly elasticsearch?: ErrorActionElasticsearchProperty;
        /**
        * firehose block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#firehose TfTopicRule#firehose}
        */
        readonly firehose?: ErrorActionFirehoseProperty;
        /**
        * http block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#http TfTopicRule#http}
        */
        readonly http?: ErrorActionHttpProperty;
        /**
        * iot_analytics block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#iot_analytics TfTopicRule#iot_analytics}
        */
        readonly iotAnalytics?: ErrorActionIotAnalyticsProperty;
        /**
        * iot_events block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#iot_events TfTopicRule#iot_events}
        */
        readonly iotEvents?: ErrorActionIotEventsProperty;
        /**
        * kafka block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#kafka TfTopicRule#kafka}
        */
        readonly kafka?: ErrorActionKafkaProperty;
        /**
        * kinesis block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#kinesis TfTopicRule#kinesis}
        */
        readonly kinesis?: ErrorActionKinesisProperty;
        /**
        * lambda block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#lambda TfTopicRule#lambda}
        */
        readonly lambda?: ErrorActionLambdaProperty;
        /**
        * republish block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#republish TfTopicRule#republish}
        */
        readonly republish?: ErrorActionRepublishProperty;
        /**
        * s3 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#s3 TfTopicRule#s3}
        */
        readonly s3?: ErrorActionS3Property;
        /**
        * sns block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#sns TfTopicRule#sns}
        */
        readonly sns?: ErrorActionSnsProperty;
        /**
        * sqs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#sqs TfTopicRule#sqs}
        */
        readonly sqs?: ErrorActionSqsProperty;
        /**
        * step_functions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#step_functions TfTopicRule#step_functions}
        */
        readonly stepFunctions?: ErrorActionStepFunctionsProperty;
        /**
        * timestream block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#timestream TfTopicRule#timestream}
        */
        readonly timestream?: ErrorActionTimestreamProperty;
    }
    class ErrorActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ErrorActionProperty | undefined;
        set internalValue(value: ErrorActionProperty | undefined);
        private _cloudwatchAlarm;
        get cloudwatchAlarm(): ErrorActionCloudwatchAlarmPropertyOutputReference;
        putCloudwatchAlarm(value: ErrorActionCloudwatchAlarmProperty): void;
        resetCloudwatchAlarm(): void;
        get cloudwatchAlarmInput(): ErrorActionCloudwatchAlarmProperty | undefined;
        private _cloudwatchLogs;
        get cloudwatchLogs(): ErrorActionCloudwatchLogsPropertyOutputReference;
        putCloudwatchLogs(value: ErrorActionCloudwatchLogsProperty): void;
        resetCloudwatchLogs(): void;
        get cloudwatchLogsInput(): ErrorActionCloudwatchLogsProperty | undefined;
        private _cloudwatchMetric;
        get cloudwatchMetric(): ErrorActionCloudwatchMetricPropertyOutputReference;
        putCloudwatchMetric(value: ErrorActionCloudwatchMetricProperty): void;
        resetCloudwatchMetric(): void;
        get cloudwatchMetricInput(): ErrorActionCloudwatchMetricProperty | undefined;
        private _dynamodb;
        get dynamodb(): ErrorActionDynamodbPropertyOutputReference;
        putDynamodb(value: ErrorActionDynamodbProperty): void;
        resetDynamodb(): void;
        get dynamodbInput(): ErrorActionDynamodbProperty | undefined;
        private _dynamodbv2;
        get dynamodbv2(): ErrorActionDynamodbv2PropertyOutputReference;
        putDynamodbv2(value: ErrorActionDynamodbv2Property): void;
        resetDynamodbv2(): void;
        get dynamodbv2Input(): ErrorActionDynamodbv2Property | undefined;
        private _elasticsearch;
        get elasticsearch(): ErrorActionElasticsearchPropertyOutputReference;
        putElasticsearch(value: ErrorActionElasticsearchProperty): void;
        resetElasticsearch(): void;
        get elasticsearchInput(): ErrorActionElasticsearchProperty | undefined;
        private _firehose;
        get firehose(): ErrorActionFirehosePropertyOutputReference;
        putFirehose(value: ErrorActionFirehoseProperty): void;
        resetFirehose(): void;
        get firehoseInput(): ErrorActionFirehoseProperty | undefined;
        private _http;
        get http(): ErrorActionHttpPropertyOutputReference;
        putHttp(value: ErrorActionHttpProperty): void;
        resetHttp(): void;
        get httpInput(): ErrorActionHttpProperty | undefined;
        private _iotAnalytics;
        get iotAnalytics(): ErrorActionIotAnalyticsPropertyOutputReference;
        putIotAnalytics(value: ErrorActionIotAnalyticsProperty): void;
        resetIotAnalytics(): void;
        get iotAnalyticsInput(): ErrorActionIotAnalyticsProperty | undefined;
        private _iotEvents;
        get iotEvents(): ErrorActionIotEventsPropertyOutputReference;
        putIotEvents(value: ErrorActionIotEventsProperty): void;
        resetIotEvents(): void;
        get iotEventsInput(): ErrorActionIotEventsProperty | undefined;
        private _kafka;
        get kafka(): ErrorActionKafkaPropertyOutputReference;
        putKafka(value: ErrorActionKafkaProperty): void;
        resetKafka(): void;
        get kafkaInput(): ErrorActionKafkaProperty | undefined;
        private _kinesis;
        get kinesis(): ErrorActionKinesisPropertyOutputReference;
        putKinesis(value: ErrorActionKinesisProperty): void;
        resetKinesis(): void;
        get kinesisInput(): ErrorActionKinesisProperty | undefined;
        private _lambda;
        get lambda(): ErrorActionLambdaPropertyOutputReference;
        putLambda(value: ErrorActionLambdaProperty): void;
        resetLambda(): void;
        get lambdaInput(): ErrorActionLambdaProperty | undefined;
        private _republish;
        get republish(): ErrorActionRepublishPropertyOutputReference;
        putRepublish(value: ErrorActionRepublishProperty): void;
        resetRepublish(): void;
        get republishInput(): ErrorActionRepublishProperty | undefined;
        private _s3;
        get s3(): ErrorActionS3PropertyOutputReference;
        putS3(value: ErrorActionS3Property): void;
        resetS3(): void;
        get s3Input(): ErrorActionS3Property | undefined;
        private _sns;
        get sns(): ErrorActionSnsPropertyOutputReference;
        putSns(value: ErrorActionSnsProperty): void;
        resetSns(): void;
        get snsInput(): ErrorActionSnsProperty | undefined;
        private _sqs;
        get sqs(): ErrorActionSqsPropertyOutputReference;
        putSqs(value: ErrorActionSqsProperty): void;
        resetSqs(): void;
        get sqsInput(): ErrorActionSqsProperty | undefined;
        private _stepFunctions;
        get stepFunctions(): ErrorActionStepFunctionsPropertyOutputReference;
        putStepFunctions(value: ErrorActionStepFunctionsProperty): void;
        resetStepFunctions(): void;
        get stepFunctionsInput(): ErrorActionStepFunctionsProperty | undefined;
        private _timestream;
        get timestream(): ErrorActionTimestreamPropertyOutputReference;
        putTimestream(value: ErrorActionTimestreamProperty): void;
        resetTimestream(): void;
        get timestreamInput(): ErrorActionTimestreamProperty | undefined;
    }
    interface FirehoseProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#batch_mode TfTopicRule#batch_mode}
        */
        readonly batchMode?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#delivery_stream_name TfTopicRule#delivery_stream_name}
        */
        readonly deliveryStreamName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn TfTopicRule#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#separator TfTopicRule#separator}
        */
        readonly separator?: string;
    }
    class FirehosePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FirehoseProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FirehoseProperty | cdktn.IResolvable | undefined);
        private _batchMode?;
        get batchMode(): boolean | cdktn.IResolvable;
        set batchMode(value: boolean | cdktn.IResolvable);
        resetBatchMode(): void;
        get batchModeInput(): boolean | cdktn.IResolvable | undefined;
        private _deliveryStreamName?;
        get deliveryStreamName(): string;
        set deliveryStreamName(value: string);
        get deliveryStreamNameInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _separator?;
        get separator(): string;
        set separator(value: string);
        resetSeparator(): void;
        get separatorInput(): string | undefined;
    }
    class FirehosePropertyList extends cdktn.ComplexList {
        internalValue?: FirehoseProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FirehosePropertyOutputReference;
    }
    interface HttpHttpHeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#key TfTopicRule#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#value TfTopicRule#value}
        */
        readonly value: string;
    }
    class HttpHttpHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HttpHttpHeaderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: HttpHttpHeaderProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class HttpHttpHeaderPropertyList extends cdktn.ComplexList {
        internalValue?: HttpHttpHeaderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HttpHttpHeaderPropertyOutputReference;
    }
    interface HttpProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#confirmation_url TfTopicRule#confirmation_url}
        */
        readonly confirmationUrl?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#url TfTopicRule#url}
        */
        readonly url: string;
        /**
        * http_header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#http_header TfTopicRule#http_header}
        */
        readonly httpHeader?: HttpHttpHeaderProperty[] | cdktn.IResolvable;
    }
    class HttpPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HttpProperty | cdktn.IResolvable | undefined;
        set internalValue(value: HttpProperty | cdktn.IResolvable | undefined);
        private _confirmationUrl?;
        get confirmationUrl(): string;
        set confirmationUrl(value: string);
        resetConfirmationUrl(): void;
        get confirmationUrlInput(): string | undefined;
        private _url?;
        get url(): string;
        set url(value: string);
        get urlInput(): string | undefined;
        private _httpHeader;
        get httpHeader(): HttpHttpHeaderPropertyList;
        putHttpHeader(value: HttpHttpHeaderProperty[] | cdktn.IResolvable): void;
        resetHttpHeader(): void;
        get httpHeaderInput(): cdktn.IResolvable | HttpHttpHeaderProperty[] | undefined;
    }
    class HttpPropertyList extends cdktn.ComplexList {
        internalValue?: HttpProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HttpPropertyOutputReference;
    }
    interface IotAnalyticsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#batch_mode TfTopicRule#batch_mode}
        */
        readonly batchMode?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#channel_name TfTopicRule#channel_name}
        */
        readonly channelName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn TfTopicRule#role_arn}
        */
        readonly roleArn: string;
    }
    class IotAnalyticsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IotAnalyticsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IotAnalyticsProperty | cdktn.IResolvable | undefined);
        private _batchMode?;
        get batchMode(): boolean | cdktn.IResolvable;
        set batchMode(value: boolean | cdktn.IResolvable);
        resetBatchMode(): void;
        get batchModeInput(): boolean | cdktn.IResolvable | undefined;
        private _channelName?;
        get channelName(): string;
        set channelName(value: string);
        get channelNameInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
    }
    class IotAnalyticsPropertyList extends cdktn.ComplexList {
        internalValue?: IotAnalyticsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IotAnalyticsPropertyOutputReference;
    }
    interface IotEventsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#batch_mode TfTopicRule#batch_mode}
        */
        readonly batchMode?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#input_name TfTopicRule#input_name}
        */
        readonly inputName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#message_id TfTopicRule#message_id}
        */
        readonly messageId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn TfTopicRule#role_arn}
        */
        readonly roleArn: string;
    }
    class IotEventsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IotEventsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IotEventsProperty | cdktn.IResolvable | undefined);
        private _batchMode?;
        get batchMode(): boolean | cdktn.IResolvable;
        set batchMode(value: boolean | cdktn.IResolvable);
        resetBatchMode(): void;
        get batchModeInput(): boolean | cdktn.IResolvable | undefined;
        private _inputName?;
        get inputName(): string;
        set inputName(value: string);
        get inputNameInput(): string | undefined;
        private _messageId?;
        get messageId(): string;
        set messageId(value: string);
        resetMessageId(): void;
        get messageIdInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
    }
    class IotEventsPropertyList extends cdktn.ComplexList {
        internalValue?: IotEventsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IotEventsPropertyOutputReference;
    }
    interface KafkaHeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#key TfTopicRule#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#value TfTopicRule#value}
        */
        readonly value: string;
    }
    class KafkaHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KafkaHeaderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: KafkaHeaderProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class KafkaHeaderPropertyList extends cdktn.ComplexList {
        internalValue?: KafkaHeaderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KafkaHeaderPropertyOutputReference;
    }
    interface KafkaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#client_properties TfTopicRule#client_properties}
        */
        readonly clientProperties: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#destination_arn TfTopicRule#destination_arn}
        */
        readonly destinationArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#key TfTopicRule#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#partition TfTopicRule#partition}
        */
        readonly partition?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#topic TfTopicRule#topic}
        */
        readonly topic: string;
        /**
        * header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#header TfTopicRule#header}
        */
        readonly header?: KafkaHeaderProperty[] | cdktn.IResolvable;
    }
    class KafkaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KafkaProperty | cdktn.IResolvable | undefined;
        set internalValue(value: KafkaProperty | cdktn.IResolvable | undefined);
        private _clientProperties?;
        get clientProperties(): {
            [key: string]: string;
        };
        set clientProperties(value: {
            [key: string]: string;
        });
        get clientPropertiesInput(): {
            [key: string]: string;
        } | undefined;
        private _destinationArn?;
        get destinationArn(): string;
        set destinationArn(value: string);
        get destinationArnInput(): string | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _partition?;
        get partition(): string;
        set partition(value: string);
        resetPartition(): void;
        get partitionInput(): string | undefined;
        private _topic?;
        get topic(): string;
        set topic(value: string);
        get topicInput(): string | undefined;
        private _header;
        get header(): KafkaHeaderPropertyList;
        putHeader(value: KafkaHeaderProperty[] | cdktn.IResolvable): void;
        resetHeader(): void;
        get headerInput(): cdktn.IResolvable | KafkaHeaderProperty[] | undefined;
    }
    class KafkaPropertyList extends cdktn.ComplexList {
        internalValue?: KafkaProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KafkaPropertyOutputReference;
    }
    interface KinesisProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#partition_key TfTopicRule#partition_key}
        */
        readonly partitionKey?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn TfTopicRule#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#stream_name TfTopicRule#stream_name}
        */
        readonly streamName: string;
    }
    class KinesisPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KinesisProperty | cdktn.IResolvable | undefined;
        set internalValue(value: KinesisProperty | cdktn.IResolvable | undefined);
        private _partitionKey?;
        get partitionKey(): string;
        set partitionKey(value: string);
        resetPartitionKey(): void;
        get partitionKeyInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _streamName?;
        get streamName(): string;
        set streamName(value: string);
        get streamNameInput(): string | undefined;
    }
    class KinesisPropertyList extends cdktn.ComplexList {
        internalValue?: KinesisProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KinesisPropertyOutputReference;
    }
    interface LambdaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#function_arn TfTopicRule#function_arn}
        */
        readonly functionArn: string;
    }
    class LambdaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LambdaProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LambdaProperty | cdktn.IResolvable | undefined);
        private _functionArn?;
        get functionArn(): string;
        set functionArn(value: string);
        get functionArnInput(): string | undefined;
    }
    class LambdaPropertyList extends cdktn.ComplexList {
        internalValue?: LambdaProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LambdaPropertyOutputReference;
    }
    interface RepublishProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#qos TfTopicRule#qos}
        */
        readonly qos?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn TfTopicRule#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#topic TfTopicRule#topic}
        */
        readonly topic: string;
    }
    class RepublishPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RepublishProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RepublishProperty | cdktn.IResolvable | undefined);
        private _qos?;
        get qos(): number;
        set qos(value: number);
        resetQos(): void;
        get qosInput(): number | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _topic?;
        get topic(): string;
        set topic(value: string);
        get topicInput(): string | undefined;
    }
    class RepublishPropertyList extends cdktn.ComplexList {
        internalValue?: RepublishProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RepublishPropertyOutputReference;
    }
    interface S3Property {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#bucket_name TfTopicRule#bucket_name}
        */
        readonly bucketName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#canned_acl TfTopicRule#canned_acl}
        */
        readonly cannedAcl?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#key TfTopicRule#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn TfTopicRule#role_arn}
        */
        readonly roleArn: string;
    }
    class S3PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3Property | cdktn.IResolvable | undefined;
        set internalValue(value: S3Property | cdktn.IResolvable | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        get bucketNameInput(): string | undefined;
        private _cannedAcl?;
        get cannedAcl(): string;
        set cannedAcl(value: string);
        resetCannedAcl(): void;
        get cannedAclInput(): string | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
    }
    class S3PropertyList extends cdktn.ComplexList {
        internalValue?: S3Property[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3PropertyOutputReference;
    }
    interface SnsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#message_format TfTopicRule#message_format}
        */
        readonly messageFormat?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn TfTopicRule#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#target_arn TfTopicRule#target_arn}
        */
        readonly targetArn: string;
    }
    class SnsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SnsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SnsProperty | cdktn.IResolvable | undefined);
        private _messageFormat?;
        get messageFormat(): string;
        set messageFormat(value: string);
        resetMessageFormat(): void;
        get messageFormatInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _targetArn?;
        get targetArn(): string;
        set targetArn(value: string);
        get targetArnInput(): string | undefined;
    }
    class SnsPropertyList extends cdktn.ComplexList {
        internalValue?: SnsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SnsPropertyOutputReference;
    }
    interface SqsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#queue_url TfTopicRule#queue_url}
        */
        readonly queueUrl: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn TfTopicRule#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#use_base64 TfTopicRule#use_base64}
        */
        readonly useBase64: boolean | cdktn.IResolvable;
    }
    class SqsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SqsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SqsProperty | cdktn.IResolvable | undefined);
        private _queueUrl?;
        get queueUrl(): string;
        set queueUrl(value: string);
        get queueUrlInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _useBase64?;
        get useBase64(): boolean | cdktn.IResolvable;
        set useBase64(value: boolean | cdktn.IResolvable);
        get useBase64Input(): boolean | cdktn.IResolvable | undefined;
    }
    class SqsPropertyList extends cdktn.ComplexList {
        internalValue?: SqsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SqsPropertyOutputReference;
    }
    interface StepFunctionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#execution_name_prefix TfTopicRule#execution_name_prefix}
        */
        readonly executionNamePrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn TfTopicRule#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#state_machine_name TfTopicRule#state_machine_name}
        */
        readonly stateMachineName: string;
    }
    class StepFunctionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StepFunctionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StepFunctionsProperty | cdktn.IResolvable | undefined);
        private _executionNamePrefix?;
        get executionNamePrefix(): string;
        set executionNamePrefix(value: string);
        resetExecutionNamePrefix(): void;
        get executionNamePrefixInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _stateMachineName?;
        get stateMachineName(): string;
        set stateMachineName(value: string);
        get stateMachineNameInput(): string | undefined;
    }
    class StepFunctionsPropertyList extends cdktn.ComplexList {
        internalValue?: StepFunctionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StepFunctionsPropertyOutputReference;
    }
    interface TimestreamDimensionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#name TfTopicRule#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#value TfTopicRule#value}
        */
        readonly value: string;
    }
    class TimestreamDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TimestreamDimensionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimestreamDimensionProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class TimestreamDimensionPropertyList extends cdktn.ComplexList {
        internalValue?: TimestreamDimensionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TimestreamDimensionPropertyOutputReference;
    }
    interface TimestreamTimestampProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#unit TfTopicRule#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#value TfTopicRule#value}
        */
        readonly value: string;
    }
    class TimestreamTimestampPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimestreamTimestampProperty | undefined;
        set internalValue(value: TimestreamTimestampProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    interface TimestreamProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#database_name TfTopicRule#database_name}
        */
        readonly databaseName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn TfTopicRule#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#table_name TfTopicRule#table_name}
        */
        readonly tableName: string;
        /**
        * dimension block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#dimension TfTopicRule#dimension}
        */
        readonly dimension: TimestreamDimensionProperty[] | cdktn.IResolvable;
        /**
        * timestamp block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#timestamp TfTopicRule#timestamp}
        */
        readonly timestamp?: TimestreamTimestampProperty;
    }
    class TimestreamPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TimestreamProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimestreamProperty | cdktn.IResolvable | undefined);
        private _databaseName?;
        get databaseName(): string;
        set databaseName(value: string);
        get databaseNameInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _tableName?;
        get tableName(): string;
        set tableName(value: string);
        get tableNameInput(): string | undefined;
        private _dimension;
        get dimension(): TimestreamDimensionPropertyList;
        putDimension(value: TimestreamDimensionProperty[] | cdktn.IResolvable): void;
        get dimensionInput(): cdktn.IResolvable | TimestreamDimensionProperty[] | undefined;
        private _timestamp;
        get timestamp(): TimestreamTimestampPropertyOutputReference;
        putTimestamp(value: TimestreamTimestampProperty): void;
        resetTimestamp(): void;
        get timestampInput(): TimestreamTimestampProperty | undefined;
    }
    class TimestreamPropertyList extends cdktn.ComplexList {
        internalValue?: TimestreamProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TimestreamPropertyOutputReference;
    }
}
