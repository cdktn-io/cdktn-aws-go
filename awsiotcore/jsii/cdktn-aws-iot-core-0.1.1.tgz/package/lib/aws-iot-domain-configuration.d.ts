import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsIotDomainConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_domain_configuration#application_protocol AwsIotDomainConfiguration#application_protocol}
    */
    readonly applicationProtocol?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_domain_configuration#authentication_type AwsIotDomainConfiguration#authentication_type}
    */
    readonly authenticationType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_domain_configuration#domain_name AwsIotDomainConfiguration#domain_name}
    */
    readonly domainName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_domain_configuration#id AwsIotDomainConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_domain_configuration#name AwsIotDomainConfiguration#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_domain_configuration#region AwsIotDomainConfiguration#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_domain_configuration#server_certificate_arns AwsIotDomainConfiguration#server_certificate_arns}
    */
    readonly serverCertificateArns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_domain_configuration#service_type AwsIotDomainConfiguration#service_type}
    */
    readonly serviceType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_domain_configuration#status AwsIotDomainConfiguration#status}
    */
    readonly status?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_domain_configuration#tags AwsIotDomainConfiguration#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_domain_configuration#tags_all AwsIotDomainConfiguration#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_domain_configuration#validation_certificate_arn AwsIotDomainConfiguration#validation_certificate_arn}
    */
    readonly validationCertificateArn?: string;
    /**
    * authorizer_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_domain_configuration#authorizer_config AwsIotDomainConfiguration#authorizer_config}
    */
    readonly authorizerConfig?: AwsIotDomainConfiguration.AuthorizerConfigProperty;
    /**
    * tls_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_domain_configuration#tls_config AwsIotDomainConfiguration#tls_config}
    */
    readonly tlsConfig?: AwsIotDomainConfiguration.TlsConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_domain_configuration aws_iot_domain_configuration}
*/
export declare class AwsIotDomainConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_iot_domain_configuration";
    /**
    * Generates CDKTN code for importing a AwsIotDomainConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsIotDomainConfiguration to import
    * @param importFromId The id of the existing AwsIotDomainConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_domain_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsIotDomainConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_domain_configuration aws_iot_domain_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsIotDomainConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AwsIotDomainConfigurationConfig);
    private _applicationProtocol?;
    get applicationProtocol(): string;
    set applicationProtocol(value: string);
    resetApplicationProtocol(): void;
    get applicationProtocolInput(): string | undefined;
    get arn(): string;
    private _authenticationType?;
    get authenticationType(): string;
    set authenticationType(value: string);
    resetAuthenticationType(): void;
    get authenticationTypeInput(): string | undefined;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    resetDomainName(): void;
    get domainNameInput(): string | undefined;
    get domainType(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _serverCertificateArns?;
    get serverCertificateArns(): string[];
    set serverCertificateArns(value: string[]);
    resetServerCertificateArns(): void;
    get serverCertificateArnsInput(): string[] | undefined;
    private _serviceType?;
    get serviceType(): string;
    set serviceType(value: string);
    resetServiceType(): void;
    get serviceTypeInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _validationCertificateArn?;
    get validationCertificateArn(): string;
    set validationCertificateArn(value: string);
    resetValidationCertificateArn(): void;
    get validationCertificateArnInput(): string | undefined;
    private _authorizerConfig;
    get authorizerConfig(): AwsIotDomainConfiguration.AuthorizerConfigPropertyOutputReference;
    putAuthorizerConfig(value: AwsIotDomainConfiguration.AuthorizerConfigProperty): void;
    resetAuthorizerConfig(): void;
    get authorizerConfigInput(): AwsIotDomainConfiguration.AuthorizerConfigProperty | undefined;
    private _tlsConfig;
    get tlsConfig(): AwsIotDomainConfiguration.TlsConfigPropertyOutputReference;
    putTlsConfig(value: AwsIotDomainConfiguration.TlsConfigProperty): void;
    resetTlsConfig(): void;
    get tlsConfigInput(): AwsIotDomainConfiguration.TlsConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsIotDomainConfigurationAuthorizerConfigPropertyToTerraform(struct?: AwsIotDomainConfiguration.AuthorizerConfigPropertyOutputReference | AwsIotDomainConfiguration.AuthorizerConfigProperty): any;
export declare function awsIotDomainConfigurationAuthorizerConfigPropertyToHclTerraform(struct?: AwsIotDomainConfiguration.AuthorizerConfigPropertyOutputReference | AwsIotDomainConfiguration.AuthorizerConfigProperty): any;
export declare function awsIotDomainConfigurationTlsConfigPropertyToTerraform(struct?: AwsIotDomainConfiguration.TlsConfigPropertyOutputReference | AwsIotDomainConfiguration.TlsConfigProperty): any;
export declare function awsIotDomainConfigurationTlsConfigPropertyToHclTerraform(struct?: AwsIotDomainConfiguration.TlsConfigPropertyOutputReference | AwsIotDomainConfiguration.TlsConfigProperty): any;
export declare namespace AwsIotDomainConfiguration {
    interface AuthorizerConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_domain_configuration#allow_authorizer_override AwsIotDomainConfiguration#allow_authorizer_override}
        */
        readonly allowAuthorizerOverride?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_domain_configuration#default_authorizer_name AwsIotDomainConfiguration#default_authorizer_name}
        */
        readonly defaultAuthorizerName?: string;
    }
    class AuthorizerConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AuthorizerConfigProperty | undefined;
        set internalValue(value: AuthorizerConfigProperty | undefined);
        private _allowAuthorizerOverride?;
        get allowAuthorizerOverride(): boolean | cdktn.IResolvable;
        set allowAuthorizerOverride(value: boolean | cdktn.IResolvable);
        resetAllowAuthorizerOverride(): void;
        get allowAuthorizerOverrideInput(): boolean | cdktn.IResolvable | undefined;
        private _defaultAuthorizerName?;
        get defaultAuthorizerName(): string;
        set defaultAuthorizerName(value: string);
        resetDefaultAuthorizerName(): void;
        get defaultAuthorizerNameInput(): string | undefined;
    }
    interface TlsConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_domain_configuration#security_policy AwsIotDomainConfiguration#security_policy}
        */
        readonly securityPolicy?: string;
    }
    class TlsConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TlsConfigProperty | undefined;
        set internalValue(value: TlsConfigProperty | undefined);
        private _securityPolicy?;
        get securityPolicy(): string;
        set securityPolicy(value: string);
        resetSecurityPolicy(): void;
        get securityPolicyInput(): string | undefined;
    }
}
