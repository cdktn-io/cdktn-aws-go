import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsIotCaCertificateConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_ca_certificate#active AwsIotCaCertificate#active}
    */
    readonly active: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_ca_certificate#allow_auto_registration AwsIotCaCertificate#allow_auto_registration}
    */
    readonly allowAutoRegistration: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_ca_certificate#ca_certificate_pem AwsIotCaCertificate#ca_certificate_pem}
    */
    readonly caCertificatePem: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_ca_certificate#certificate_mode AwsIotCaCertificate#certificate_mode}
    */
    readonly certificateMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_ca_certificate#id AwsIotCaCertificate#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_ca_certificate#region AwsIotCaCertificate#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_ca_certificate#tags AwsIotCaCertificate#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_ca_certificate#tags_all AwsIotCaCertificate#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_ca_certificate#verification_certificate_pem AwsIotCaCertificate#verification_certificate_pem}
    */
    readonly verificationCertificatePem?: string;
    /**
    * registration_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_ca_certificate#registration_config AwsIotCaCertificate#registration_config}
    */
    readonly registrationConfig?: AwsIotCaCertificate.RegistrationConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_ca_certificate aws_iot_ca_certificate}
*/
export declare class AwsIotCaCertificate extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_iot_ca_certificate";
    /**
    * Generates CDKTN code for importing a AwsIotCaCertificate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsIotCaCertificate to import
    * @param importFromId The id of the existing AwsIotCaCertificate that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_ca_certificate#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsIotCaCertificate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_ca_certificate aws_iot_ca_certificate} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsIotCaCertificateConfig
    */
    constructor(scope: Construct, id: string, config: AwsIotCaCertificateConfig);
    private _active?;
    get active(): boolean | cdktn.IResolvable;
    set active(value: boolean | cdktn.IResolvable);
    get activeInput(): boolean | cdktn.IResolvable | undefined;
    private _allowAutoRegistration?;
    get allowAutoRegistration(): boolean | cdktn.IResolvable;
    set allowAutoRegistration(value: boolean | cdktn.IResolvable);
    get allowAutoRegistrationInput(): boolean | cdktn.IResolvable | undefined;
    get arn(): string;
    private _caCertificatePem?;
    get caCertificatePem(): string;
    set caCertificatePem(value: string);
    get caCertificatePemInput(): string | undefined;
    private _certificateMode?;
    get certificateMode(): string;
    set certificateMode(value: string);
    resetCertificateMode(): void;
    get certificateModeInput(): string | undefined;
    get customerVersion(): number;
    get generationId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _validity;
    get validity(): AwsIotCaCertificate.ValidityPropertyList;
    private _verificationCertificatePem?;
    get verificationCertificatePem(): string;
    set verificationCertificatePem(value: string);
    resetVerificationCertificatePem(): void;
    get verificationCertificatePemInput(): string | undefined;
    private _registrationConfig;
    get registrationConfig(): AwsIotCaCertificate.RegistrationConfigPropertyOutputReference;
    putRegistrationConfig(value: AwsIotCaCertificate.RegistrationConfigProperty): void;
    resetRegistrationConfig(): void;
    get registrationConfigInput(): AwsIotCaCertificate.RegistrationConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsIotCaCertificateValidityPropertyToTerraform(struct?: AwsIotCaCertificate.ValidityProperty): any;
export declare function awsIotCaCertificateValidityPropertyToHclTerraform(struct?: AwsIotCaCertificate.ValidityProperty): any;
export declare function awsIotCaCertificateRegistrationConfigPropertyToTerraform(struct?: AwsIotCaCertificate.RegistrationConfigPropertyOutputReference | AwsIotCaCertificate.RegistrationConfigProperty): any;
export declare function awsIotCaCertificateRegistrationConfigPropertyToHclTerraform(struct?: AwsIotCaCertificate.RegistrationConfigPropertyOutputReference | AwsIotCaCertificate.RegistrationConfigProperty): any;
export declare namespace AwsIotCaCertificate {
    interface ValidityProperty {
    }
    class ValidityPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ValidityProperty | undefined;
        set internalValue(value: ValidityProperty | undefined);
        get notAfter(): string;
        get notBefore(): string;
    }
    class ValidityPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ValidityPropertyOutputReference;
    }
    interface RegistrationConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_ca_certificate#role_arn AwsIotCaCertificate#role_arn}
        */
        readonly roleArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_ca_certificate#template_body AwsIotCaCertificate#template_body}
        */
        readonly templateBody?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_ca_certificate#template_name AwsIotCaCertificate#template_name}
        */
        readonly templateName?: string;
    }
    class RegistrationConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RegistrationConfigProperty | undefined;
        set internalValue(value: RegistrationConfigProperty | undefined);
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        resetRoleArn(): void;
        get roleArnInput(): string | undefined;
        private _templateBody?;
        get templateBody(): string;
        set templateBody(value: string);
        resetTemplateBody(): void;
        get templateBodyInput(): string | undefined;
        private _templateName?;
        get templateName(): string;
        set templateName(value: string);
        resetTemplateName(): void;
        get templateNameInput(): string | undefined;
    }
}
