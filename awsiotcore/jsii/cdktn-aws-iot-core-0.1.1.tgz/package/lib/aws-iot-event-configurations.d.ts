import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsIotEventConfigurationsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_event_configurations#event_configurations AwsIotEventConfigurations#event_configurations}
    */
    readonly eventConfigurations: {
        [key: string]: (boolean | cdktn.IResolvable);
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_event_configurations#id AwsIotEventConfigurations#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_event_configurations#region AwsIotEventConfigurations#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_event_configurations aws_iot_event_configurations}
*/
export declare class AwsIotEventConfigurations extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_iot_event_configurations";
    /**
    * Generates CDKTN code for importing a AwsIotEventConfigurations resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsIotEventConfigurations to import
    * @param importFromId The id of the existing AwsIotEventConfigurations that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_event_configurations#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsIotEventConfigurations to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_event_configurations aws_iot_event_configurations} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsIotEventConfigurationsConfig
    */
    constructor(scope: Construct, id: string, config: AwsIotEventConfigurationsConfig);
    private _eventConfigurations?;
    get eventConfigurations(): {
        [key: string]: (boolean | cdktn.IResolvable);
    };
    set eventConfigurations(value: {
        [key: string]: (boolean | cdktn.IResolvable);
    });
    get eventConfigurationsInput(): {
        [key: string]: boolean | cdktn.IResolvable;
    } | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
