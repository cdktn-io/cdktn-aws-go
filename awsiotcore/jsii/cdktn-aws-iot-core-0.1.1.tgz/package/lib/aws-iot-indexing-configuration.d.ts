import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsIotIndexingConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_indexing_configuration#id AwsIotIndexingConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_indexing_configuration#region AwsIotIndexingConfiguration#region}
    */
    readonly region?: string;
    /**
    * thing_group_indexing_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_indexing_configuration#thing_group_indexing_configuration AwsIotIndexingConfiguration#thing_group_indexing_configuration}
    */
    readonly thingGroupIndexingConfiguration?: AwsIotIndexingConfiguration.ThingGroupIndexingConfigurationProperty;
    /**
    * thing_indexing_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_indexing_configuration#thing_indexing_configuration AwsIotIndexingConfiguration#thing_indexing_configuration}
    */
    readonly thingIndexingConfiguration?: AwsIotIndexingConfiguration.ThingIndexingConfigurationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_indexing_configuration aws_iot_indexing_configuration}
*/
export declare class AwsIotIndexingConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_iot_indexing_configuration";
    /**
    * Generates CDKTN code for importing a AwsIotIndexingConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsIotIndexingConfiguration to import
    * @param importFromId The id of the existing AwsIotIndexingConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_indexing_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsIotIndexingConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_indexing_configuration aws_iot_indexing_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsIotIndexingConfigurationConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AwsIotIndexingConfigurationConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _thingGroupIndexingConfiguration;
    get thingGroupIndexingConfiguration(): AwsIotIndexingConfiguration.ThingGroupIndexingConfigurationPropertyOutputReference;
    putThingGroupIndexingConfiguration(value: AwsIotIndexingConfiguration.ThingGroupIndexingConfigurationProperty): void;
    resetThingGroupIndexingConfiguration(): void;
    get thingGroupIndexingConfigurationInput(): AwsIotIndexingConfiguration.ThingGroupIndexingConfigurationProperty | undefined;
    private _thingIndexingConfiguration;
    get thingIndexingConfiguration(): AwsIotIndexingConfiguration.ThingIndexingConfigurationPropertyOutputReference;
    putThingIndexingConfiguration(value: AwsIotIndexingConfiguration.ThingIndexingConfigurationProperty): void;
    resetThingIndexingConfiguration(): void;
    get thingIndexingConfigurationInput(): AwsIotIndexingConfiguration.ThingIndexingConfigurationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsIotIndexingConfigurationThingGroupIndexingConfigurationCustomFieldPropertyToTerraform(struct?: AwsIotIndexingConfiguration.ThingGroupIndexingConfigurationCustomFieldProperty | cdktn.IResolvable): any;
export declare function awsIotIndexingConfigurationThingGroupIndexingConfigurationCustomFieldPropertyToHclTerraform(struct?: AwsIotIndexingConfiguration.ThingGroupIndexingConfigurationCustomFieldProperty | cdktn.IResolvable): any;
export declare function awsIotIndexingConfigurationThingGroupIndexingConfigurationManagedFieldPropertyToTerraform(struct?: AwsIotIndexingConfiguration.ThingGroupIndexingConfigurationManagedFieldProperty | cdktn.IResolvable): any;
export declare function awsIotIndexingConfigurationThingGroupIndexingConfigurationManagedFieldPropertyToHclTerraform(struct?: AwsIotIndexingConfiguration.ThingGroupIndexingConfigurationManagedFieldProperty | cdktn.IResolvable): any;
export declare function awsIotIndexingConfigurationThingGroupIndexingConfigurationPropertyToTerraform(struct?: AwsIotIndexingConfiguration.ThingGroupIndexingConfigurationPropertyOutputReference | AwsIotIndexingConfiguration.ThingGroupIndexingConfigurationProperty): any;
export declare function awsIotIndexingConfigurationThingGroupIndexingConfigurationPropertyToHclTerraform(struct?: AwsIotIndexingConfiguration.ThingGroupIndexingConfigurationPropertyOutputReference | AwsIotIndexingConfiguration.ThingGroupIndexingConfigurationProperty): any;
export declare function awsIotIndexingConfigurationThingIndexingConfigurationCustomFieldPropertyToTerraform(struct?: AwsIotIndexingConfiguration.ThingIndexingConfigurationCustomFieldProperty | cdktn.IResolvable): any;
export declare function awsIotIndexingConfigurationThingIndexingConfigurationCustomFieldPropertyToHclTerraform(struct?: AwsIotIndexingConfiguration.ThingIndexingConfigurationCustomFieldProperty | cdktn.IResolvable): any;
export declare function awsIotIndexingConfigurationFilterPropertyToTerraform(struct?: AwsIotIndexingConfiguration.FilterPropertyOutputReference | AwsIotIndexingConfiguration.FilterProperty): any;
export declare function awsIotIndexingConfigurationFilterPropertyToHclTerraform(struct?: AwsIotIndexingConfiguration.FilterPropertyOutputReference | AwsIotIndexingConfiguration.FilterProperty): any;
export declare function awsIotIndexingConfigurationThingIndexingConfigurationManagedFieldPropertyToTerraform(struct?: AwsIotIndexingConfiguration.ThingIndexingConfigurationManagedFieldProperty | cdktn.IResolvable): any;
export declare function awsIotIndexingConfigurationThingIndexingConfigurationManagedFieldPropertyToHclTerraform(struct?: AwsIotIndexingConfiguration.ThingIndexingConfigurationManagedFieldProperty | cdktn.IResolvable): any;
export declare function awsIotIndexingConfigurationThingIndexingConfigurationPropertyToTerraform(struct?: AwsIotIndexingConfiguration.ThingIndexingConfigurationPropertyOutputReference | AwsIotIndexingConfiguration.ThingIndexingConfigurationProperty): any;
export declare function awsIotIndexingConfigurationThingIndexingConfigurationPropertyToHclTerraform(struct?: AwsIotIndexingConfiguration.ThingIndexingConfigurationPropertyOutputReference | AwsIotIndexingConfiguration.ThingIndexingConfigurationProperty): any;
export declare namespace AwsIotIndexingConfiguration {
    interface ThingGroupIndexingConfigurationCustomFieldProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_indexing_configuration#name AwsIotIndexingConfiguration#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_indexing_configuration#type AwsIotIndexingConfiguration#type}
        */
        readonly type?: string;
    }
    class ThingGroupIndexingConfigurationCustomFieldPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ThingGroupIndexingConfigurationCustomFieldProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ThingGroupIndexingConfigurationCustomFieldProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
    }
    class ThingGroupIndexingConfigurationCustomFieldPropertyList extends cdktn.ComplexList {
        internalValue?: ThingGroupIndexingConfigurationCustomFieldProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ThingGroupIndexingConfigurationCustomFieldPropertyOutputReference;
    }
    interface ThingGroupIndexingConfigurationManagedFieldProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_indexing_configuration#name AwsIotIndexingConfiguration#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_indexing_configuration#type AwsIotIndexingConfiguration#type}
        */
        readonly type?: string;
    }
    class ThingGroupIndexingConfigurationManagedFieldPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ThingGroupIndexingConfigurationManagedFieldProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ThingGroupIndexingConfigurationManagedFieldProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
    }
    class ThingGroupIndexingConfigurationManagedFieldPropertyList extends cdktn.ComplexList {
        internalValue?: ThingGroupIndexingConfigurationManagedFieldProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ThingGroupIndexingConfigurationManagedFieldPropertyOutputReference;
    }
    interface ThingGroupIndexingConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_indexing_configuration#thing_group_indexing_mode AwsIotIndexingConfiguration#thing_group_indexing_mode}
        */
        readonly thingGroupIndexingMode: string;
        /**
        * custom_field block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_indexing_configuration#custom_field AwsIotIndexingConfiguration#custom_field}
        */
        readonly customField?: ThingGroupIndexingConfigurationCustomFieldProperty[] | cdktn.IResolvable;
        /**
        * managed_field block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_indexing_configuration#managed_field AwsIotIndexingConfiguration#managed_field}
        */
        readonly managedField?: ThingGroupIndexingConfigurationManagedFieldProperty[] | cdktn.IResolvable;
    }
    class ThingGroupIndexingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ThingGroupIndexingConfigurationProperty | undefined;
        set internalValue(value: ThingGroupIndexingConfigurationProperty | undefined);
        private _thingGroupIndexingMode?;
        get thingGroupIndexingMode(): string;
        set thingGroupIndexingMode(value: string);
        get thingGroupIndexingModeInput(): string | undefined;
        private _customField;
        get customField(): ThingGroupIndexingConfigurationCustomFieldPropertyList;
        putCustomField(value: ThingGroupIndexingConfigurationCustomFieldProperty[] | cdktn.IResolvable): void;
        resetCustomField(): void;
        get customFieldInput(): cdktn.IResolvable | ThingGroupIndexingConfigurationCustomFieldProperty[] | undefined;
        private _managedField;
        get managedField(): ThingGroupIndexingConfigurationManagedFieldPropertyList;
        putManagedField(value: ThingGroupIndexingConfigurationManagedFieldProperty[] | cdktn.IResolvable): void;
        resetManagedField(): void;
        get managedFieldInput(): cdktn.IResolvable | ThingGroupIndexingConfigurationManagedFieldProperty[] | undefined;
    }
    interface ThingIndexingConfigurationCustomFieldProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_indexing_configuration#name AwsIotIndexingConfiguration#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_indexing_configuration#type AwsIotIndexingConfiguration#type}
        */
        readonly type?: string;
    }
    class ThingIndexingConfigurationCustomFieldPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ThingIndexingConfigurationCustomFieldProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ThingIndexingConfigurationCustomFieldProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
    }
    class ThingIndexingConfigurationCustomFieldPropertyList extends cdktn.ComplexList {
        internalValue?: ThingIndexingConfigurationCustomFieldProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ThingIndexingConfigurationCustomFieldPropertyOutputReference;
    }
    interface FilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_indexing_configuration#named_shadow_names AwsIotIndexingConfiguration#named_shadow_names}
        */
        readonly namedShadowNames?: string[];
    }
    class FilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterProperty | undefined;
        set internalValue(value: FilterProperty | undefined);
        private _namedShadowNames?;
        get namedShadowNames(): string[];
        set namedShadowNames(value: string[]);
        resetNamedShadowNames(): void;
        get namedShadowNamesInput(): string[] | undefined;
    }
    interface ThingIndexingConfigurationManagedFieldProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_indexing_configuration#name AwsIotIndexingConfiguration#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_indexing_configuration#type AwsIotIndexingConfiguration#type}
        */
        readonly type?: string;
    }
    class ThingIndexingConfigurationManagedFieldPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ThingIndexingConfigurationManagedFieldProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ThingIndexingConfigurationManagedFieldProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
    }
    class ThingIndexingConfigurationManagedFieldPropertyList extends cdktn.ComplexList {
        internalValue?: ThingIndexingConfigurationManagedFieldProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ThingIndexingConfigurationManagedFieldPropertyOutputReference;
    }
    interface ThingIndexingConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_indexing_configuration#device_defender_indexing_mode AwsIotIndexingConfiguration#device_defender_indexing_mode}
        */
        readonly deviceDefenderIndexingMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_indexing_configuration#named_shadow_indexing_mode AwsIotIndexingConfiguration#named_shadow_indexing_mode}
        */
        readonly namedShadowIndexingMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_indexing_configuration#thing_connectivity_indexing_mode AwsIotIndexingConfiguration#thing_connectivity_indexing_mode}
        */
        readonly thingConnectivityIndexingMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_indexing_configuration#thing_indexing_mode AwsIotIndexingConfiguration#thing_indexing_mode}
        */
        readonly thingIndexingMode: string;
        /**
        * custom_field block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_indexing_configuration#custom_field AwsIotIndexingConfiguration#custom_field}
        */
        readonly customField?: ThingIndexingConfigurationCustomFieldProperty[] | cdktn.IResolvable;
        /**
        * filter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_indexing_configuration#filter AwsIotIndexingConfiguration#filter}
        */
        readonly filter?: FilterProperty;
        /**
        * managed_field block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_indexing_configuration#managed_field AwsIotIndexingConfiguration#managed_field}
        */
        readonly managedField?: ThingIndexingConfigurationManagedFieldProperty[] | cdktn.IResolvable;
    }
    class ThingIndexingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ThingIndexingConfigurationProperty | undefined;
        set internalValue(value: ThingIndexingConfigurationProperty | undefined);
        private _deviceDefenderIndexingMode?;
        get deviceDefenderIndexingMode(): string;
        set deviceDefenderIndexingMode(value: string);
        resetDeviceDefenderIndexingMode(): void;
        get deviceDefenderIndexingModeInput(): string | undefined;
        private _namedShadowIndexingMode?;
        get namedShadowIndexingMode(): string;
        set namedShadowIndexingMode(value: string);
        resetNamedShadowIndexingMode(): void;
        get namedShadowIndexingModeInput(): string | undefined;
        private _thingConnectivityIndexingMode?;
        get thingConnectivityIndexingMode(): string;
        set thingConnectivityIndexingMode(value: string);
        resetThingConnectivityIndexingMode(): void;
        get thingConnectivityIndexingModeInput(): string | undefined;
        private _thingIndexingMode?;
        get thingIndexingMode(): string;
        set thingIndexingMode(value: string);
        get thingIndexingModeInput(): string | undefined;
        private _customField;
        get customField(): ThingIndexingConfigurationCustomFieldPropertyList;
        putCustomField(value: ThingIndexingConfigurationCustomFieldProperty[] | cdktn.IResolvable): void;
        resetCustomField(): void;
        get customFieldInput(): cdktn.IResolvable | ThingIndexingConfigurationCustomFieldProperty[] | undefined;
        private _filter;
        get filter(): FilterPropertyOutputReference;
        putFilter(value: FilterProperty): void;
        resetFilter(): void;
        get filterInput(): FilterProperty | undefined;
        private _managedField;
        get managedField(): ThingIndexingConfigurationManagedFieldPropertyList;
        putManagedField(value: ThingIndexingConfigurationManagedFieldProperty[] | cdktn.IResolvable): void;
        resetManagedField(): void;
        get managedFieldInput(): cdktn.IResolvable | ThingIndexingConfigurationManagedFieldProperty[] | undefined;
    }
}
