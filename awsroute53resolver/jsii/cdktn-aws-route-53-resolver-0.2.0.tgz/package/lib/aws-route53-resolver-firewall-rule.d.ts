import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfResolverFirewallRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_resolver_firewall_rule#action TfResolverFirewallRule#action}
    */
    readonly action: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_resolver_firewall_rule#block_override_dns_type TfResolverFirewallRule#block_override_dns_type}
    */
    readonly blockOverrideDnsType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_resolver_firewall_rule#block_override_domain TfResolverFirewallRule#block_override_domain}
    */
    readonly blockOverrideDomain?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_resolver_firewall_rule#block_override_ttl TfResolverFirewallRule#block_override_ttl}
    */
    readonly blockOverrideTtl?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_resolver_firewall_rule#block_response TfResolverFirewallRule#block_response}
    */
    readonly blockResponse?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_resolver_firewall_rule#confidence_threshold TfResolverFirewallRule#confidence_threshold}
    */
    readonly confidenceThreshold?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_resolver_firewall_rule#dns_threat_protection TfResolverFirewallRule#dns_threat_protection}
    */
    readonly dnsThreatProtection?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_resolver_firewall_rule#firewall_domain_list_id TfResolverFirewallRule#firewall_domain_list_id}
    */
    readonly firewallDomainListId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_resolver_firewall_rule#firewall_domain_redirection_action TfResolverFirewallRule#firewall_domain_redirection_action}
    */
    readonly firewallDomainRedirectionAction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_resolver_firewall_rule#firewall_rule_group_id TfResolverFirewallRule#firewall_rule_group_id}
    */
    readonly firewallRuleGroupId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_resolver_firewall_rule#id TfResolverFirewallRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_resolver_firewall_rule#name TfResolverFirewallRule#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_resolver_firewall_rule#priority TfResolverFirewallRule#priority}
    */
    readonly priority: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_resolver_firewall_rule#q_type TfResolverFirewallRule#q_type}
    */
    readonly qType?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_resolver_firewall_rule#region TfResolverFirewallRule#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_resolver_firewall_rule aws_route53_resolver_firewall_rule}
*/
export declare class TfResolverFirewallRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_route53_resolver_firewall_rule";
    /**
    * Generates CDKTN code for importing a TfResolverFirewallRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfResolverFirewallRule to import
    * @param importFromId The id of the existing TfResolverFirewallRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_resolver_firewall_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfResolverFirewallRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_resolver_firewall_rule aws_route53_resolver_firewall_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfResolverFirewallRuleConfig
    */
    constructor(scope: Construct, id: string, config: TfResolverFirewallRuleConfig);
    private _action?;
    get action(): string;
    set action(value: string);
    get actionInput(): string | undefined;
    private _blockOverrideDnsType?;
    get blockOverrideDnsType(): string;
    set blockOverrideDnsType(value: string);
    resetBlockOverrideDnsType(): void;
    get blockOverrideDnsTypeInput(): string | undefined;
    private _blockOverrideDomain?;
    get blockOverrideDomain(): string;
    set blockOverrideDomain(value: string);
    resetBlockOverrideDomain(): void;
    get blockOverrideDomainInput(): string | undefined;
    private _blockOverrideTtl?;
    get blockOverrideTtl(): number;
    set blockOverrideTtl(value: number);
    resetBlockOverrideTtl(): void;
    get blockOverrideTtlInput(): number | undefined;
    private _blockResponse?;
    get blockResponse(): string;
    set blockResponse(value: string);
    resetBlockResponse(): void;
    get blockResponseInput(): string | undefined;
    private _confidenceThreshold?;
    get confidenceThreshold(): string;
    set confidenceThreshold(value: string);
    resetConfidenceThreshold(): void;
    get confidenceThresholdInput(): string | undefined;
    private _dnsThreatProtection?;
    get dnsThreatProtection(): string;
    set dnsThreatProtection(value: string);
    resetDnsThreatProtection(): void;
    get dnsThreatProtectionInput(): string | undefined;
    private _firewallDomainListId?;
    get firewallDomainListId(): string;
    set firewallDomainListId(value: string);
    resetFirewallDomainListId(): void;
    get firewallDomainListIdInput(): string | undefined;
    private _firewallDomainRedirectionAction?;
    get firewallDomainRedirectionAction(): string;
    set firewallDomainRedirectionAction(value: string);
    resetFirewallDomainRedirectionAction(): void;
    get firewallDomainRedirectionActionInput(): string | undefined;
    private _firewallRuleGroupId?;
    get firewallRuleGroupId(): string;
    set firewallRuleGroupId(value: string);
    get firewallRuleGroupIdInput(): string | undefined;
    get firewallThreatProtectionId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    get priorityInput(): number | undefined;
    private _qType?;
    get qType(): string;
    set qType(value: string);
    resetQType(): void;
    get qTypeInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
