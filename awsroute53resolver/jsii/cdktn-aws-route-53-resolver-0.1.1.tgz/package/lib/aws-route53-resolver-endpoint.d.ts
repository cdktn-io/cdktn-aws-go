import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsRoute53ResolverEndpointConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_resolver_endpoint#direction AwsRoute53ResolverEndpoint#direction}
    */
    readonly direction: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_resolver_endpoint#id AwsRoute53ResolverEndpoint#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_resolver_endpoint#name AwsRoute53ResolverEndpoint#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_resolver_endpoint#protocols AwsRoute53ResolverEndpoint#protocols}
    */
    readonly protocols?: string[];
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_resolver_endpoint#region AwsRoute53ResolverEndpoint#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_resolver_endpoint#resolver_endpoint_type AwsRoute53ResolverEndpoint#resolver_endpoint_type}
    */
    readonly resolverEndpointType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_resolver_endpoint#rni_enhanced_metrics_enabled AwsRoute53ResolverEndpoint#rni_enhanced_metrics_enabled}
    */
    readonly rniEnhancedMetricsEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_resolver_endpoint#security_group_ids AwsRoute53ResolverEndpoint#security_group_ids}
    */
    readonly securityGroupIds: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_resolver_endpoint#tags AwsRoute53ResolverEndpoint#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_resolver_endpoint#tags_all AwsRoute53ResolverEndpoint#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_resolver_endpoint#target_name_server_metrics_enabled AwsRoute53ResolverEndpoint#target_name_server_metrics_enabled}
    */
    readonly targetNameServerMetricsEnabled?: boolean | cdktn.IResolvable;
    /**
    * ip_address block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_resolver_endpoint#ip_address AwsRoute53ResolverEndpoint#ip_address}
    */
    readonly ipAddress: AwsRoute53ResolverEndpoint.IpAddressProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_resolver_endpoint#timeouts AwsRoute53ResolverEndpoint#timeouts}
    */
    readonly timeouts?: AwsRoute53ResolverEndpoint.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_resolver_endpoint aws_route53_resolver_endpoint}
*/
export declare class AwsRoute53ResolverEndpoint extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_route53_resolver_endpoint";
    /**
    * Generates CDKTN code for importing a AwsRoute53ResolverEndpoint resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsRoute53ResolverEndpoint to import
    * @param importFromId The id of the existing AwsRoute53ResolverEndpoint that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_resolver_endpoint#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsRoute53ResolverEndpoint to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_resolver_endpoint aws_route53_resolver_endpoint} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsRoute53ResolverEndpointConfig
    */
    constructor(scope: Construct, id: string, config: AwsRoute53ResolverEndpointConfig);
    get arn(): string;
    private _direction?;
    get direction(): string;
    set direction(value: string);
    get directionInput(): string | undefined;
    get hostVpcId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _protocols?;
    get protocols(): string[];
    set protocols(value: string[]);
    resetProtocols(): void;
    get protocolsInput(): string[] | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resolverEndpointType?;
    get resolverEndpointType(): string;
    set resolverEndpointType(value: string);
    resetResolverEndpointType(): void;
    get resolverEndpointTypeInput(): string | undefined;
    private _rniEnhancedMetricsEnabled?;
    get rniEnhancedMetricsEnabled(): boolean | cdktn.IResolvable;
    set rniEnhancedMetricsEnabled(value: boolean | cdktn.IResolvable);
    resetRniEnhancedMetricsEnabled(): void;
    get rniEnhancedMetricsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _securityGroupIds?;
    get securityGroupIds(): string[];
    set securityGroupIds(value: string[]);
    get securityGroupIdsInput(): string[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _targetNameServerMetricsEnabled?;
    get targetNameServerMetricsEnabled(): boolean | cdktn.IResolvable;
    set targetNameServerMetricsEnabled(value: boolean | cdktn.IResolvable);
    resetTargetNameServerMetricsEnabled(): void;
    get targetNameServerMetricsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _ipAddress;
    get ipAddress(): AwsRoute53ResolverEndpoint.IpAddressPropertyList;
    putIpAddress(value: AwsRoute53ResolverEndpoint.IpAddressProperty[] | cdktn.IResolvable): void;
    get ipAddressInput(): cdktn.IResolvable | AwsRoute53ResolverEndpoint.IpAddressProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsRoute53ResolverEndpoint.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsRoute53ResolverEndpoint.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsRoute53ResolverEndpoint.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsRoute53ResolverEndpointIpAddressPropertyToTerraform(struct?: AwsRoute53ResolverEndpoint.IpAddressProperty | cdktn.IResolvable): any;
export declare function awsRoute53ResolverEndpointIpAddressPropertyToHclTerraform(struct?: AwsRoute53ResolverEndpoint.IpAddressProperty | cdktn.IResolvable): any;
export declare function awsRoute53ResolverEndpointTimeoutsPropertyToTerraform(struct?: AwsRoute53ResolverEndpoint.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsRoute53ResolverEndpointTimeoutsPropertyToHclTerraform(struct?: AwsRoute53ResolverEndpoint.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsRoute53ResolverEndpoint {
    interface IpAddressProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_resolver_endpoint#ip AwsRoute53ResolverEndpoint#ip}
        */
        readonly ip?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_resolver_endpoint#ipv6 AwsRoute53ResolverEndpoint#ipv6}
        */
        readonly ipv6?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_resolver_endpoint#subnet_id AwsRoute53ResolverEndpoint#subnet_id}
        */
        readonly subnetId: string;
    }
    class IpAddressPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IpAddressProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IpAddressProperty | cdktn.IResolvable | undefined);
        private _ip?;
        get ip(): string;
        set ip(value: string);
        resetIp(): void;
        get ipInput(): string | undefined;
        get ipId(): string;
        private _ipv6?;
        get ipv6(): string;
        set ipv6(value: string);
        resetIpv6(): void;
        get ipv6Input(): string | undefined;
        private _subnetId?;
        get subnetId(): string;
        set subnetId(value: string);
        get subnetIdInput(): string | undefined;
    }
    class IpAddressPropertyList extends cdktn.ComplexList {
        internalValue?: IpAddressProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IpAddressPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_resolver_endpoint#create AwsRoute53ResolverEndpoint#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_resolver_endpoint#delete AwsRoute53ResolverEndpoint#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_resolver_endpoint#update AwsRoute53ResolverEndpoint#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
