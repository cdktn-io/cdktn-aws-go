import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsObservabilityadminTelemetryEvaluationForOrganizationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_evaluation_for_organization#all_regions AwsObservabilityadminTelemetryEvaluationForOrganization#all_regions}
    */
    readonly allRegions?: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_evaluation_for_organization#region AwsObservabilityadminTelemetryEvaluationForOrganization#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_evaluation_for_organization#regions AwsObservabilityadminTelemetryEvaluationForOrganization#regions}
    */
    readonly regions?: string[];
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_evaluation_for_organization#timeouts AwsObservabilityadminTelemetryEvaluationForOrganization#timeouts}
    */
    readonly timeouts?: AwsObservabilityadminTelemetryEvaluationForOrganization.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_evaluation_for_organization aws_observabilityadmin_telemetry_evaluation_for_organization}
*/
export declare class AwsObservabilityadminTelemetryEvaluationForOrganization extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_observabilityadmin_telemetry_evaluation_for_organization";
    /**
    * Generates CDKTN code for importing a AwsObservabilityadminTelemetryEvaluationForOrganization resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsObservabilityadminTelemetryEvaluationForOrganization to import
    * @param importFromId The id of the existing AwsObservabilityadminTelemetryEvaluationForOrganization that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_evaluation_for_organization#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsObservabilityadminTelemetryEvaluationForOrganization to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_evaluation_for_organization aws_observabilityadmin_telemetry_evaluation_for_organization} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsObservabilityadminTelemetryEvaluationForOrganizationConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AwsObservabilityadminTelemetryEvaluationForOrganizationConfig);
    private _allRegions?;
    get allRegions(): boolean | cdktn.IResolvable;
    set allRegions(value: boolean | cdktn.IResolvable);
    resetAllRegions(): void;
    get allRegionsInput(): boolean | cdktn.IResolvable | undefined;
    get failureReason(): string;
    get homeRegion(): string;
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _regions?;
    get regions(): string[];
    set regions(value: string[]);
    resetRegions(): void;
    get regionsInput(): string[] | undefined;
    get status(): string;
    private _timeouts;
    get timeouts(): AwsObservabilityadminTelemetryEvaluationForOrganization.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsObservabilityadminTelemetryEvaluationForOrganization.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsObservabilityadminTelemetryEvaluationForOrganization.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsObservabilityadminTelemetryEvaluationForOrganizationTimeoutsPropertyToTerraform(struct?: AwsObservabilityadminTelemetryEvaluationForOrganization.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminTelemetryEvaluationForOrganizationTimeoutsPropertyToHclTerraform(struct?: AwsObservabilityadminTelemetryEvaluationForOrganization.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsObservabilityadminTelemetryEvaluationForOrganization {
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_evaluation_for_organization#create AwsObservabilityadminTelemetryEvaluationForOrganization#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_evaluation_for_organization#delete AwsObservabilityadminTelemetryEvaluationForOrganization#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
