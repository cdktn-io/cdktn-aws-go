import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsObservabilityadminCentralizationRuleForOrganizationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_centralization_rule_for_organization#region AwsObservabilityadminCentralizationRuleForOrganization#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_centralization_rule_for_organization#rule_name AwsObservabilityadminCentralizationRuleForOrganization#rule_name}
    */
    readonly ruleName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_centralization_rule_for_organization#tags AwsObservabilityadminCentralizationRuleForOrganization#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_centralization_rule_for_organization#rule AwsObservabilityadminCentralizationRuleForOrganization#rule}
    */
    readonly rule?: AwsObservabilityadminCentralizationRuleForOrganization.RuleProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_centralization_rule_for_organization#timeouts AwsObservabilityadminCentralizationRuleForOrganization#timeouts}
    */
    readonly timeouts?: AwsObservabilityadminCentralizationRuleForOrganization.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_centralization_rule_for_organization aws_observabilityadmin_centralization_rule_for_organization}
*/
export declare class AwsObservabilityadminCentralizationRuleForOrganization extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_observabilityadmin_centralization_rule_for_organization";
    /**
    * Generates CDKTN code for importing a AwsObservabilityadminCentralizationRuleForOrganization resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsObservabilityadminCentralizationRuleForOrganization to import
    * @param importFromId The id of the existing AwsObservabilityadminCentralizationRuleForOrganization that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_centralization_rule_for_organization#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsObservabilityadminCentralizationRuleForOrganization to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_centralization_rule_for_organization aws_observabilityadmin_centralization_rule_for_organization} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsObservabilityadminCentralizationRuleForOrganizationConfig
    */
    constructor(scope: Construct, id: string, config: AwsObservabilityadminCentralizationRuleForOrganizationConfig);
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get ruleArn(): string;
    private _ruleName?;
    get ruleName(): string;
    set ruleName(value: string);
    get ruleNameInput(): string | undefined;
    get tagPropagationFailureReason(): string;
    get tagPropagationStatus(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _rule;
    get rule(): AwsObservabilityadminCentralizationRuleForOrganization.RulePropertyList;
    putRule(value: AwsObservabilityadminCentralizationRuleForOrganization.RuleProperty[] | cdktn.IResolvable): void;
    resetRule(): void;
    get ruleInput(): cdktn.IResolvable | AwsObservabilityadminCentralizationRuleForOrganization.RuleProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsObservabilityadminCentralizationRuleForOrganization.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsObservabilityadminCentralizationRuleForOrganization.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsObservabilityadminCentralizationRuleForOrganization.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsObservabilityadminCentralizationRuleForOrganizationRuleDestinationDestinationLogsConfigurationBackupConfigurationPropertyToTerraform(struct?: AwsObservabilityadminCentralizationRuleForOrganization.RuleDestinationDestinationLogsConfigurationBackupConfigurationProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminCentralizationRuleForOrganizationRuleDestinationDestinationLogsConfigurationBackupConfigurationPropertyToHclTerraform(struct?: AwsObservabilityadminCentralizationRuleForOrganization.RuleDestinationDestinationLogsConfigurationBackupConfigurationProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminCentralizationRuleForOrganizationLogGroupNameConfigurationPropertyToTerraform(struct?: AwsObservabilityadminCentralizationRuleForOrganization.LogGroupNameConfigurationProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminCentralizationRuleForOrganizationLogGroupNameConfigurationPropertyToHclTerraform(struct?: AwsObservabilityadminCentralizationRuleForOrganization.LogGroupNameConfigurationProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminCentralizationRuleForOrganizationLogsEncryptionConfigurationPropertyToTerraform(struct?: AwsObservabilityadminCentralizationRuleForOrganization.LogsEncryptionConfigurationProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminCentralizationRuleForOrganizationLogsEncryptionConfigurationPropertyToHclTerraform(struct?: AwsObservabilityadminCentralizationRuleForOrganization.LogsEncryptionConfigurationProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminCentralizationRuleForOrganizationTagPropagationConfigurationPropertyToTerraform(struct?: AwsObservabilityadminCentralizationRuleForOrganization.TagPropagationConfigurationProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminCentralizationRuleForOrganizationTagPropagationConfigurationPropertyToHclTerraform(struct?: AwsObservabilityadminCentralizationRuleForOrganization.TagPropagationConfigurationProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminCentralizationRuleForOrganizationDestinationLogsConfigurationPropertyToTerraform(struct?: AwsObservabilityadminCentralizationRuleForOrganization.DestinationLogsConfigurationProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminCentralizationRuleForOrganizationDestinationLogsConfigurationPropertyToHclTerraform(struct?: AwsObservabilityadminCentralizationRuleForOrganization.DestinationLogsConfigurationProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminCentralizationRuleForOrganizationRuleDestinationDestinationMetricsConfigurationBackupConfigurationPropertyToTerraform(struct?: AwsObservabilityadminCentralizationRuleForOrganization.RuleDestinationDestinationMetricsConfigurationBackupConfigurationProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminCentralizationRuleForOrganizationRuleDestinationDestinationMetricsConfigurationBackupConfigurationPropertyToHclTerraform(struct?: AwsObservabilityadminCentralizationRuleForOrganization.RuleDestinationDestinationMetricsConfigurationBackupConfigurationProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminCentralizationRuleForOrganizationDestinationMetricsConfigurationPropertyToTerraform(struct?: AwsObservabilityadminCentralizationRuleForOrganization.DestinationMetricsConfigurationProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminCentralizationRuleForOrganizationDestinationMetricsConfigurationPropertyToHclTerraform(struct?: AwsObservabilityadminCentralizationRuleForOrganization.DestinationMetricsConfigurationProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminCentralizationRuleForOrganizationDestinationPropertyToTerraform(struct?: AwsObservabilityadminCentralizationRuleForOrganization.DestinationProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminCentralizationRuleForOrganizationDestinationPropertyToHclTerraform(struct?: AwsObservabilityadminCentralizationRuleForOrganization.DestinationProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminCentralizationRuleForOrganizationSourceLogsConfigurationPropertyToTerraform(struct?: AwsObservabilityadminCentralizationRuleForOrganization.SourceLogsConfigurationProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminCentralizationRuleForOrganizationSourceLogsConfigurationPropertyToHclTerraform(struct?: AwsObservabilityadminCentralizationRuleForOrganization.SourceLogsConfigurationProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminCentralizationRuleForOrganizationSourceMetricsConfigurationPropertyToTerraform(struct?: AwsObservabilityadminCentralizationRuleForOrganization.SourceMetricsConfigurationProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminCentralizationRuleForOrganizationSourceMetricsConfigurationPropertyToHclTerraform(struct?: AwsObservabilityadminCentralizationRuleForOrganization.SourceMetricsConfigurationProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminCentralizationRuleForOrganizationSourcePropertyToTerraform(struct?: AwsObservabilityadminCentralizationRuleForOrganization.SourceProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminCentralizationRuleForOrganizationSourcePropertyToHclTerraform(struct?: AwsObservabilityadminCentralizationRuleForOrganization.SourceProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminCentralizationRuleForOrganizationRulePropertyToTerraform(struct?: AwsObservabilityadminCentralizationRuleForOrganization.RuleProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminCentralizationRuleForOrganizationRulePropertyToHclTerraform(struct?: AwsObservabilityadminCentralizationRuleForOrganization.RuleProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminCentralizationRuleForOrganizationTimeoutsPropertyToTerraform(struct?: AwsObservabilityadminCentralizationRuleForOrganization.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminCentralizationRuleForOrganizationTimeoutsPropertyToHclTerraform(struct?: AwsObservabilityadminCentralizationRuleForOrganization.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsObservabilityadminCentralizationRuleForOrganization {
    interface RuleDestinationDestinationLogsConfigurationBackupConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_centralization_rule_for_organization#kms_key_arn AwsObservabilityadminCentralizationRuleForOrganization#kms_key_arn}
        */
        readonly kmsKeyArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_centralization_rule_for_organization#region AwsObservabilityadminCentralizationRuleForOrganization#region}
        */
        readonly region?: string;
    }
    class RuleDestinationDestinationLogsConfigurationBackupConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleDestinationDestinationLogsConfigurationBackupConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleDestinationDestinationLogsConfigurationBackupConfigurationProperty | cdktn.IResolvable | undefined);
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        resetKmsKeyArn(): void;
        get kmsKeyArnInput(): string | undefined;
        private _region?;
        get region(): string;
        set region(value: string);
        resetRegion(): void;
        get regionInput(): string | undefined;
    }
    class RuleDestinationDestinationLogsConfigurationBackupConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: RuleDestinationDestinationLogsConfigurationBackupConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleDestinationDestinationLogsConfigurationBackupConfigurationPropertyOutputReference;
    }
    interface LogGroupNameConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_centralization_rule_for_organization#log_group_name_pattern AwsObservabilityadminCentralizationRuleForOrganization#log_group_name_pattern}
        */
        readonly logGroupNamePattern: string;
    }
    class LogGroupNameConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LogGroupNameConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LogGroupNameConfigurationProperty | cdktn.IResolvable | undefined);
        private _logGroupNamePattern?;
        get logGroupNamePattern(): string;
        set logGroupNamePattern(value: string);
        get logGroupNamePatternInput(): string | undefined;
    }
    class LogGroupNameConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: LogGroupNameConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LogGroupNameConfigurationPropertyOutputReference;
    }
    interface LogsEncryptionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_centralization_rule_for_organization#encryption_conflict_resolution_strategy AwsObservabilityadminCentralizationRuleForOrganization#encryption_conflict_resolution_strategy}
        */
        readonly encryptionConflictResolutionStrategy?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_centralization_rule_for_organization#encryption_scope AwsObservabilityadminCentralizationRuleForOrganization#encryption_scope}
        */
        readonly encryptionScope?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_centralization_rule_for_organization#encryption_strategy AwsObservabilityadminCentralizationRuleForOrganization#encryption_strategy}
        */
        readonly encryptionStrategy: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_centralization_rule_for_organization#kms_key_arn AwsObservabilityadminCentralizationRuleForOrganization#kms_key_arn}
        */
        readonly kmsKeyArn?: string;
    }
    class LogsEncryptionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LogsEncryptionConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LogsEncryptionConfigurationProperty | cdktn.IResolvable | undefined);
        private _encryptionConflictResolutionStrategy?;
        get encryptionConflictResolutionStrategy(): string;
        set encryptionConflictResolutionStrategy(value: string);
        resetEncryptionConflictResolutionStrategy(): void;
        get encryptionConflictResolutionStrategyInput(): string | undefined;
        private _encryptionScope?;
        get encryptionScope(): string;
        set encryptionScope(value: string);
        resetEncryptionScope(): void;
        get encryptionScopeInput(): string | undefined;
        private _encryptionStrategy?;
        get encryptionStrategy(): string;
        set encryptionStrategy(value: string);
        get encryptionStrategyInput(): string | undefined;
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        resetKmsKeyArn(): void;
        get kmsKeyArnInput(): string | undefined;
    }
    class LogsEncryptionConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: LogsEncryptionConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LogsEncryptionConfigurationPropertyOutputReference;
    }
    interface TagPropagationConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_centralization_rule_for_organization#destination_role_arn AwsObservabilityadminCentralizationRuleForOrganization#destination_role_arn}
        */
        readonly destinationRoleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_centralization_rule_for_organization#tag_conflict_resolution_strategy AwsObservabilityadminCentralizationRuleForOrganization#tag_conflict_resolution_strategy}
        */
        readonly tagConflictResolutionStrategy?: string;
    }
    class TagPropagationConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TagPropagationConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TagPropagationConfigurationProperty | cdktn.IResolvable | undefined);
        private _destinationRoleArn?;
        get destinationRoleArn(): string;
        set destinationRoleArn(value: string);
        get destinationRoleArnInput(): string | undefined;
        private _tagConflictResolutionStrategy?;
        get tagConflictResolutionStrategy(): string;
        set tagConflictResolutionStrategy(value: string);
        resetTagConflictResolutionStrategy(): void;
        get tagConflictResolutionStrategyInput(): string | undefined;
    }
    class TagPropagationConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: TagPropagationConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TagPropagationConfigurationPropertyOutputReference;
    }
    interface DestinationLogsConfigurationProperty {
        /**
        * backup_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_centralization_rule_for_organization#backup_configuration AwsObservabilityadminCentralizationRuleForOrganization#backup_configuration}
        */
        readonly backupConfiguration?: RuleDestinationDestinationLogsConfigurationBackupConfigurationProperty[] | cdktn.IResolvable;
        /**
        * log_group_name_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_centralization_rule_for_organization#log_group_name_configuration AwsObservabilityadminCentralizationRuleForOrganization#log_group_name_configuration}
        */
        readonly logGroupNameConfiguration?: LogGroupNameConfigurationProperty[] | cdktn.IResolvable;
        /**
        * logs_encryption_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_centralization_rule_for_organization#logs_encryption_configuration AwsObservabilityadminCentralizationRuleForOrganization#logs_encryption_configuration}
        */
        readonly logsEncryptionConfiguration?: LogsEncryptionConfigurationProperty[] | cdktn.IResolvable;
        /**
        * tag_propagation_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_centralization_rule_for_organization#tag_propagation_configuration AwsObservabilityadminCentralizationRuleForOrganization#tag_propagation_configuration}
        */
        readonly tagPropagationConfiguration?: TagPropagationConfigurationProperty[] | cdktn.IResolvable;
    }
    class DestinationLogsConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DestinationLogsConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DestinationLogsConfigurationProperty | cdktn.IResolvable | undefined);
        private _backupConfiguration;
        get backupConfiguration(): RuleDestinationDestinationLogsConfigurationBackupConfigurationPropertyList;
        putBackupConfiguration(value: RuleDestinationDestinationLogsConfigurationBackupConfigurationProperty[] | cdktn.IResolvable): void;
        resetBackupConfiguration(): void;
        get backupConfigurationInput(): cdktn.IResolvable | RuleDestinationDestinationLogsConfigurationBackupConfigurationProperty[] | undefined;
        private _logGroupNameConfiguration;
        get logGroupNameConfiguration(): LogGroupNameConfigurationPropertyList;
        putLogGroupNameConfiguration(value: LogGroupNameConfigurationProperty[] | cdktn.IResolvable): void;
        resetLogGroupNameConfiguration(): void;
        get logGroupNameConfigurationInput(): cdktn.IResolvable | LogGroupNameConfigurationProperty[] | undefined;
        private _logsEncryptionConfiguration;
        get logsEncryptionConfiguration(): LogsEncryptionConfigurationPropertyList;
        putLogsEncryptionConfiguration(value: LogsEncryptionConfigurationProperty[] | cdktn.IResolvable): void;
        resetLogsEncryptionConfiguration(): void;
        get logsEncryptionConfigurationInput(): cdktn.IResolvable | LogsEncryptionConfigurationProperty[] | undefined;
        private _tagPropagationConfiguration;
        get tagPropagationConfiguration(): TagPropagationConfigurationPropertyList;
        putTagPropagationConfiguration(value: TagPropagationConfigurationProperty[] | cdktn.IResolvable): void;
        resetTagPropagationConfiguration(): void;
        get tagPropagationConfigurationInput(): cdktn.IResolvable | TagPropagationConfigurationProperty[] | undefined;
    }
    class DestinationLogsConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: DestinationLogsConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DestinationLogsConfigurationPropertyOutputReference;
    }
    interface RuleDestinationDestinationMetricsConfigurationBackupConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_centralization_rule_for_organization#region AwsObservabilityadminCentralizationRuleForOrganization#region}
        */
        readonly region: string;
    }
    class RuleDestinationDestinationMetricsConfigurationBackupConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleDestinationDestinationMetricsConfigurationBackupConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleDestinationDestinationMetricsConfigurationBackupConfigurationProperty | cdktn.IResolvable | undefined);
        private _region?;
        get region(): string;
        set region(value: string);
        get regionInput(): string | undefined;
    }
    class RuleDestinationDestinationMetricsConfigurationBackupConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: RuleDestinationDestinationMetricsConfigurationBackupConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleDestinationDestinationMetricsConfigurationBackupConfigurationPropertyOutputReference;
    }
    interface DestinationMetricsConfigurationProperty {
        /**
        * backup_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_centralization_rule_for_organization#backup_configuration AwsObservabilityadminCentralizationRuleForOrganization#backup_configuration}
        */
        readonly backupConfiguration?: RuleDestinationDestinationMetricsConfigurationBackupConfigurationProperty[] | cdktn.IResolvable;
    }
    class DestinationMetricsConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DestinationMetricsConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DestinationMetricsConfigurationProperty | cdktn.IResolvable | undefined);
        private _backupConfiguration;
        get backupConfiguration(): RuleDestinationDestinationMetricsConfigurationBackupConfigurationPropertyList;
        putBackupConfiguration(value: RuleDestinationDestinationMetricsConfigurationBackupConfigurationProperty[] | cdktn.IResolvable): void;
        resetBackupConfiguration(): void;
        get backupConfigurationInput(): cdktn.IResolvable | RuleDestinationDestinationMetricsConfigurationBackupConfigurationProperty[] | undefined;
    }
    class DestinationMetricsConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: DestinationMetricsConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DestinationMetricsConfigurationPropertyOutputReference;
    }
    interface DestinationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_centralization_rule_for_organization#account AwsObservabilityadminCentralizationRuleForOrganization#account}
        */
        readonly account: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_centralization_rule_for_organization#region AwsObservabilityadminCentralizationRuleForOrganization#region}
        */
        readonly region: string;
        /**
        * destination_logs_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_centralization_rule_for_organization#destination_logs_configuration AwsObservabilityadminCentralizationRuleForOrganization#destination_logs_configuration}
        */
        readonly destinationLogsConfiguration?: DestinationLogsConfigurationProperty[] | cdktn.IResolvable;
        /**
        * destination_metrics_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_centralization_rule_for_organization#destination_metrics_configuration AwsObservabilityadminCentralizationRuleForOrganization#destination_metrics_configuration}
        */
        readonly destinationMetricsConfiguration?: DestinationMetricsConfigurationProperty[] | cdktn.IResolvable;
    }
    class DestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DestinationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DestinationProperty | cdktn.IResolvable | undefined);
        private _account?;
        get account(): string;
        set account(value: string);
        get accountInput(): string | undefined;
        private _region?;
        get region(): string;
        set region(value: string);
        get regionInput(): string | undefined;
        private _destinationLogsConfiguration;
        get destinationLogsConfiguration(): DestinationLogsConfigurationPropertyList;
        putDestinationLogsConfiguration(value: DestinationLogsConfigurationProperty[] | cdktn.IResolvable): void;
        resetDestinationLogsConfiguration(): void;
        get destinationLogsConfigurationInput(): cdktn.IResolvable | DestinationLogsConfigurationProperty[] | undefined;
        private _destinationMetricsConfiguration;
        get destinationMetricsConfiguration(): DestinationMetricsConfigurationPropertyList;
        putDestinationMetricsConfiguration(value: DestinationMetricsConfigurationProperty[] | cdktn.IResolvable): void;
        resetDestinationMetricsConfiguration(): void;
        get destinationMetricsConfigurationInput(): cdktn.IResolvable | DestinationMetricsConfigurationProperty[] | undefined;
    }
    class DestinationPropertyList extends cdktn.ComplexList {
        internalValue?: DestinationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DestinationPropertyOutputReference;
    }
    interface SourceLogsConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_centralization_rule_for_organization#data_source_selection_criteria AwsObservabilityadminCentralizationRuleForOrganization#data_source_selection_criteria}
        */
        readonly dataSourceSelectionCriteria?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_centralization_rule_for_organization#encrypted_log_group_strategy AwsObservabilityadminCentralizationRuleForOrganization#encrypted_log_group_strategy}
        */
        readonly encryptedLogGroupStrategy: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_centralization_rule_for_organization#log_group_selection_criteria AwsObservabilityadminCentralizationRuleForOrganization#log_group_selection_criteria}
        */
        readonly logGroupSelectionCriteria?: string;
    }
    class SourceLogsConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SourceLogsConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SourceLogsConfigurationProperty | cdktn.IResolvable | undefined);
        private _dataSourceSelectionCriteria?;
        get dataSourceSelectionCriteria(): string;
        set dataSourceSelectionCriteria(value: string);
        resetDataSourceSelectionCriteria(): void;
        get dataSourceSelectionCriteriaInput(): string | undefined;
        private _encryptedLogGroupStrategy?;
        get encryptedLogGroupStrategy(): string;
        set encryptedLogGroupStrategy(value: string);
        get encryptedLogGroupStrategyInput(): string | undefined;
        private _logGroupSelectionCriteria?;
        get logGroupSelectionCriteria(): string;
        set logGroupSelectionCriteria(value: string);
        resetLogGroupSelectionCriteria(): void;
        get logGroupSelectionCriteriaInput(): string | undefined;
    }
    class SourceLogsConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: SourceLogsConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SourceLogsConfigurationPropertyOutputReference;
    }
    interface SourceMetricsConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_centralization_rule_for_organization#metrics_selection_criteria AwsObservabilityadminCentralizationRuleForOrganization#metrics_selection_criteria}
        */
        readonly metricsSelectionCriteria: string;
    }
    class SourceMetricsConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SourceMetricsConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SourceMetricsConfigurationProperty | cdktn.IResolvable | undefined);
        private _metricsSelectionCriteria?;
        get metricsSelectionCriteria(): string;
        set metricsSelectionCriteria(value: string);
        get metricsSelectionCriteriaInput(): string | undefined;
    }
    class SourceMetricsConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: SourceMetricsConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SourceMetricsConfigurationPropertyOutputReference;
    }
    interface SourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_centralization_rule_for_organization#regions AwsObservabilityadminCentralizationRuleForOrganization#regions}
        */
        readonly regions: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_centralization_rule_for_organization#scope AwsObservabilityadminCentralizationRuleForOrganization#scope}
        */
        readonly scope: string;
        /**
        * source_logs_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_centralization_rule_for_organization#source_logs_configuration AwsObservabilityadminCentralizationRuleForOrganization#source_logs_configuration}
        */
        readonly sourceLogsConfiguration?: SourceLogsConfigurationProperty[] | cdktn.IResolvable;
        /**
        * source_metrics_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_centralization_rule_for_organization#source_metrics_configuration AwsObservabilityadminCentralizationRuleForOrganization#source_metrics_configuration}
        */
        readonly sourceMetricsConfiguration?: SourceMetricsConfigurationProperty[] | cdktn.IResolvable;
    }
    class SourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SourceProperty | cdktn.IResolvable | undefined);
        private _regions?;
        get regions(): string[];
        set regions(value: string[]);
        get regionsInput(): string[] | undefined;
        private _scope?;
        get scope(): string;
        set scope(value: string);
        get scopeInput(): string | undefined;
        private _sourceLogsConfiguration;
        get sourceLogsConfiguration(): SourceLogsConfigurationPropertyList;
        putSourceLogsConfiguration(value: SourceLogsConfigurationProperty[] | cdktn.IResolvable): void;
        resetSourceLogsConfiguration(): void;
        get sourceLogsConfigurationInput(): cdktn.IResolvable | SourceLogsConfigurationProperty[] | undefined;
        private _sourceMetricsConfiguration;
        get sourceMetricsConfiguration(): SourceMetricsConfigurationPropertyList;
        putSourceMetricsConfiguration(value: SourceMetricsConfigurationProperty[] | cdktn.IResolvable): void;
        resetSourceMetricsConfiguration(): void;
        get sourceMetricsConfigurationInput(): cdktn.IResolvable | SourceMetricsConfigurationProperty[] | undefined;
    }
    class SourcePropertyList extends cdktn.ComplexList {
        internalValue?: SourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SourcePropertyOutputReference;
    }
    interface RuleProperty {
        /**
        * destination block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_centralization_rule_for_organization#destination AwsObservabilityadminCentralizationRuleForOrganization#destination}
        */
        readonly destination?: DestinationProperty[] | cdktn.IResolvable;
        /**
        * source block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_centralization_rule_for_organization#source AwsObservabilityadminCentralizationRuleForOrganization#source}
        */
        readonly source?: SourceProperty[] | cdktn.IResolvable;
    }
    class RulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleProperty | cdktn.IResolvable | undefined);
        private _destination;
        get destination(): DestinationPropertyList;
        putDestination(value: DestinationProperty[] | cdktn.IResolvable): void;
        resetDestination(): void;
        get destinationInput(): cdktn.IResolvable | DestinationProperty[] | undefined;
        private _source;
        get source(): SourcePropertyList;
        putSource(value: SourceProperty[] | cdktn.IResolvable): void;
        resetSource(): void;
        get sourceInput(): cdktn.IResolvable | SourceProperty[] | undefined;
    }
    class RulePropertyList extends cdktn.ComplexList {
        internalValue?: RuleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RulePropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_centralization_rule_for_organization#create AwsObservabilityadminCentralizationRuleForOrganization#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_centralization_rule_for_organization#update AwsObservabilityadminCentralizationRuleForOrganization#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
