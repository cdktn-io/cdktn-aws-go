import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsObservabilityadminTelemetryRuleForOrganizationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#region AwsObservabilityadminTelemetryRuleForOrganization#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#rule_name AwsObservabilityadminTelemetryRuleForOrganization#rule_name}
    */
    readonly ruleName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#tags AwsObservabilityadminTelemetryRuleForOrganization#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#rule AwsObservabilityadminTelemetryRuleForOrganization#rule}
    */
    readonly rule?: AwsObservabilityadminTelemetryRuleForOrganization.RuleProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#timeouts AwsObservabilityadminTelemetryRuleForOrganization#timeouts}
    */
    readonly timeouts?: AwsObservabilityadminTelemetryRuleForOrganization.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization aws_observabilityadmin_telemetry_rule_for_organization}
*/
export declare class AwsObservabilityadminTelemetryRuleForOrganization extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_observabilityadmin_telemetry_rule_for_organization";
    /**
    * Generates CDKTN code for importing a AwsObservabilityadminTelemetryRuleForOrganization resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsObservabilityadminTelemetryRuleForOrganization to import
    * @param importFromId The id of the existing AwsObservabilityadminTelemetryRuleForOrganization that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsObservabilityadminTelemetryRuleForOrganization to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization aws_observabilityadmin_telemetry_rule_for_organization} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsObservabilityadminTelemetryRuleForOrganizationConfig
    */
    constructor(scope: Construct, id: string, config: AwsObservabilityadminTelemetryRuleForOrganizationConfig);
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get ruleArn(): string;
    private _ruleName?;
    get ruleName(): string;
    set ruleName(value: string);
    get ruleNameInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _rule;
    get rule(): AwsObservabilityadminTelemetryRuleForOrganization.RulePropertyList;
    putRule(value: AwsObservabilityadminTelemetryRuleForOrganization.RuleProperty[] | cdktn.IResolvable): void;
    resetRule(): void;
    get ruleInput(): cdktn.IResolvable | AwsObservabilityadminTelemetryRuleForOrganization.RuleProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsObservabilityadminTelemetryRuleForOrganization.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsObservabilityadminTelemetryRuleForOrganization.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsObservabilityadminTelemetryRuleForOrganization.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsObservabilityadminTelemetryRuleForOrganizationFieldSelectorsPropertyToTerraform(struct?: AwsObservabilityadminTelemetryRuleForOrganization.FieldSelectorsProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminTelemetryRuleForOrganizationFieldSelectorsPropertyToHclTerraform(struct?: AwsObservabilityadminTelemetryRuleForOrganization.FieldSelectorsProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminTelemetryRuleForOrganizationAdvancedEventSelectorsPropertyToTerraform(struct?: AwsObservabilityadminTelemetryRuleForOrganization.AdvancedEventSelectorsProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminTelemetryRuleForOrganizationAdvancedEventSelectorsPropertyToHclTerraform(struct?: AwsObservabilityadminTelemetryRuleForOrganization.AdvancedEventSelectorsProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminTelemetryRuleForOrganizationCloudtrailParametersPropertyToTerraform(struct?: AwsObservabilityadminTelemetryRuleForOrganization.CloudtrailParametersProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminTelemetryRuleForOrganizationCloudtrailParametersPropertyToHclTerraform(struct?: AwsObservabilityadminTelemetryRuleForOrganization.CloudtrailParametersProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminTelemetryRuleForOrganizationElbLoadBalancerLoggingParametersPropertyToTerraform(struct?: AwsObservabilityadminTelemetryRuleForOrganization.ElbLoadBalancerLoggingParametersProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminTelemetryRuleForOrganizationElbLoadBalancerLoggingParametersPropertyToHclTerraform(struct?: AwsObservabilityadminTelemetryRuleForOrganization.ElbLoadBalancerLoggingParametersProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminTelemetryRuleForOrganizationLogDeliveryParametersPropertyToTerraform(struct?: AwsObservabilityadminTelemetryRuleForOrganization.LogDeliveryParametersProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminTelemetryRuleForOrganizationLogDeliveryParametersPropertyToHclTerraform(struct?: AwsObservabilityadminTelemetryRuleForOrganization.LogDeliveryParametersProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminTelemetryRuleForOrganizationMskMonitoringParametersPropertyToTerraform(struct?: AwsObservabilityadminTelemetryRuleForOrganization.MskMonitoringParametersProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminTelemetryRuleForOrganizationMskMonitoringParametersPropertyToHclTerraform(struct?: AwsObservabilityadminTelemetryRuleForOrganization.MskMonitoringParametersProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminTelemetryRuleForOrganizationVpcFlowLogParametersPropertyToTerraform(struct?: AwsObservabilityadminTelemetryRuleForOrganization.VpcFlowLogParametersProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminTelemetryRuleForOrganizationVpcFlowLogParametersPropertyToHclTerraform(struct?: AwsObservabilityadminTelemetryRuleForOrganization.VpcFlowLogParametersProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminTelemetryRuleForOrganizationActionConditionPropertyToTerraform(struct?: AwsObservabilityadminTelemetryRuleForOrganization.ActionConditionProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminTelemetryRuleForOrganizationActionConditionPropertyToHclTerraform(struct?: AwsObservabilityadminTelemetryRuleForOrganization.ActionConditionProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminTelemetryRuleForOrganizationLabelNameConditionPropertyToTerraform(struct?: AwsObservabilityadminTelemetryRuleForOrganization.LabelNameConditionProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminTelemetryRuleForOrganizationLabelNameConditionPropertyToHclTerraform(struct?: AwsObservabilityadminTelemetryRuleForOrganization.LabelNameConditionProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminTelemetryRuleForOrganizationConditionsPropertyToTerraform(struct?: AwsObservabilityadminTelemetryRuleForOrganization.ConditionsProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminTelemetryRuleForOrganizationConditionsPropertyToHclTerraform(struct?: AwsObservabilityadminTelemetryRuleForOrganization.ConditionsProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminTelemetryRuleForOrganizationFiltersPropertyToTerraform(struct?: AwsObservabilityadminTelemetryRuleForOrganization.FiltersProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminTelemetryRuleForOrganizationFiltersPropertyToHclTerraform(struct?: AwsObservabilityadminTelemetryRuleForOrganization.FiltersProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminTelemetryRuleForOrganizationLoggingFilterPropertyToTerraform(struct?: AwsObservabilityadminTelemetryRuleForOrganization.LoggingFilterProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminTelemetryRuleForOrganizationLoggingFilterPropertyToHclTerraform(struct?: AwsObservabilityadminTelemetryRuleForOrganization.LoggingFilterProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminTelemetryRuleForOrganizationSingleHeaderPropertyToTerraform(struct?: AwsObservabilityadminTelemetryRuleForOrganization.SingleHeaderProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminTelemetryRuleForOrganizationSingleHeaderPropertyToHclTerraform(struct?: AwsObservabilityadminTelemetryRuleForOrganization.SingleHeaderProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminTelemetryRuleForOrganizationRedactedFieldsPropertyToTerraform(struct?: AwsObservabilityadminTelemetryRuleForOrganization.RedactedFieldsProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminTelemetryRuleForOrganizationRedactedFieldsPropertyToHclTerraform(struct?: AwsObservabilityadminTelemetryRuleForOrganization.RedactedFieldsProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminTelemetryRuleForOrganizationWafLoggingParametersPropertyToTerraform(struct?: AwsObservabilityadminTelemetryRuleForOrganization.WafLoggingParametersProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminTelemetryRuleForOrganizationWafLoggingParametersPropertyToHclTerraform(struct?: AwsObservabilityadminTelemetryRuleForOrganization.WafLoggingParametersProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminTelemetryRuleForOrganizationDestinationConfigurationPropertyToTerraform(struct?: AwsObservabilityadminTelemetryRuleForOrganization.DestinationConfigurationProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminTelemetryRuleForOrganizationDestinationConfigurationPropertyToHclTerraform(struct?: AwsObservabilityadminTelemetryRuleForOrganization.DestinationConfigurationProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminTelemetryRuleForOrganizationRulePropertyToTerraform(struct?: AwsObservabilityadminTelemetryRuleForOrganization.RuleProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminTelemetryRuleForOrganizationRulePropertyToHclTerraform(struct?: AwsObservabilityadminTelemetryRuleForOrganization.RuleProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminTelemetryRuleForOrganizationTimeoutsPropertyToTerraform(struct?: AwsObservabilityadminTelemetryRuleForOrganization.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsObservabilityadminTelemetryRuleForOrganizationTimeoutsPropertyToHclTerraform(struct?: AwsObservabilityadminTelemetryRuleForOrganization.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsObservabilityadminTelemetryRuleForOrganization {
    interface FieldSelectorsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#ends_with AwsObservabilityadminTelemetryRuleForOrganization#ends_with}
        */
        readonly endsWith?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#equals AwsObservabilityadminTelemetryRuleForOrganization#equals}
        */
        readonly equalTo?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#field AwsObservabilityadminTelemetryRuleForOrganization#field}
        */
        readonly field: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#not_ends_with AwsObservabilityadminTelemetryRuleForOrganization#not_ends_with}
        */
        readonly notEndsWith?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#not_equals AwsObservabilityadminTelemetryRuleForOrganization#not_equals}
        */
        readonly notEquals?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#not_starts_with AwsObservabilityadminTelemetryRuleForOrganization#not_starts_with}
        */
        readonly notStartsWith?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#starts_with AwsObservabilityadminTelemetryRuleForOrganization#starts_with}
        */
        readonly startsWith?: string[];
    }
    class FieldSelectorsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FieldSelectorsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FieldSelectorsProperty | cdktn.IResolvable | undefined);
        private _endsWith?;
        get endsWith(): string[];
        set endsWith(value: string[]);
        resetEndsWith(): void;
        get endsWithInput(): string[] | undefined;
        private _equals?;
        get equalTo(): string[];
        set equalTo(value: string[]);
        resetEqualTo(): void;
        get equalToInput(): string[] | undefined;
        private _field?;
        get field(): string;
        set field(value: string);
        get fieldInput(): string | undefined;
        private _notEndsWith?;
        get notEndsWith(): string[];
        set notEndsWith(value: string[]);
        resetNotEndsWith(): void;
        get notEndsWithInput(): string[] | undefined;
        private _notEquals?;
        get notEquals(): string[];
        set notEquals(value: string[]);
        resetNotEquals(): void;
        get notEqualsInput(): string[] | undefined;
        private _notStartsWith?;
        get notStartsWith(): string[];
        set notStartsWith(value: string[]);
        resetNotStartsWith(): void;
        get notStartsWithInput(): string[] | undefined;
        private _startsWith?;
        get startsWith(): string[];
        set startsWith(value: string[]);
        resetStartsWith(): void;
        get startsWithInput(): string[] | undefined;
    }
    class FieldSelectorsPropertyList extends cdktn.ComplexList {
        internalValue?: FieldSelectorsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FieldSelectorsPropertyOutputReference;
    }
    interface AdvancedEventSelectorsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#name AwsObservabilityadminTelemetryRuleForOrganization#name}
        */
        readonly name?: string;
        /**
        * field_selectors block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#field_selectors AwsObservabilityadminTelemetryRuleForOrganization#field_selectors}
        */
        readonly fieldSelectors?: FieldSelectorsProperty[] | cdktn.IResolvable;
    }
    class AdvancedEventSelectorsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AdvancedEventSelectorsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AdvancedEventSelectorsProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _fieldSelectors;
        get fieldSelectors(): FieldSelectorsPropertyList;
        putFieldSelectors(value: FieldSelectorsProperty[] | cdktn.IResolvable): void;
        resetFieldSelectors(): void;
        get fieldSelectorsInput(): cdktn.IResolvable | FieldSelectorsProperty[] | undefined;
    }
    class AdvancedEventSelectorsPropertyList extends cdktn.ComplexList {
        internalValue?: AdvancedEventSelectorsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AdvancedEventSelectorsPropertyOutputReference;
    }
    interface CloudtrailParametersProperty {
        /**
        * advanced_event_selectors block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#advanced_event_selectors AwsObservabilityadminTelemetryRuleForOrganization#advanced_event_selectors}
        */
        readonly advancedEventSelectors?: AdvancedEventSelectorsProperty[] | cdktn.IResolvable;
    }
    class CloudtrailParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CloudtrailParametersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CloudtrailParametersProperty | cdktn.IResolvable | undefined);
        private _advancedEventSelectors;
        get advancedEventSelectors(): AdvancedEventSelectorsPropertyList;
        putAdvancedEventSelectors(value: AdvancedEventSelectorsProperty[] | cdktn.IResolvable): void;
        resetAdvancedEventSelectors(): void;
        get advancedEventSelectorsInput(): cdktn.IResolvable | AdvancedEventSelectorsProperty[] | undefined;
    }
    class CloudtrailParametersPropertyList extends cdktn.ComplexList {
        internalValue?: CloudtrailParametersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CloudtrailParametersPropertyOutputReference;
    }
    interface ElbLoadBalancerLoggingParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#field_delimiter AwsObservabilityadminTelemetryRuleForOrganization#field_delimiter}
        */
        readonly fieldDelimiter?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#output_format AwsObservabilityadminTelemetryRuleForOrganization#output_format}
        */
        readonly outputFormat?: string;
    }
    class ElbLoadBalancerLoggingParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ElbLoadBalancerLoggingParametersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ElbLoadBalancerLoggingParametersProperty | cdktn.IResolvable | undefined);
        private _fieldDelimiter?;
        get fieldDelimiter(): string;
        set fieldDelimiter(value: string);
        resetFieldDelimiter(): void;
        get fieldDelimiterInput(): string | undefined;
        private _outputFormat?;
        get outputFormat(): string;
        set outputFormat(value: string);
        resetOutputFormat(): void;
        get outputFormatInput(): string | undefined;
    }
    class ElbLoadBalancerLoggingParametersPropertyList extends cdktn.ComplexList {
        internalValue?: ElbLoadBalancerLoggingParametersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ElbLoadBalancerLoggingParametersPropertyOutputReference;
    }
    interface LogDeliveryParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#log_types AwsObservabilityadminTelemetryRuleForOrganization#log_types}
        */
        readonly logTypes?: string[];
    }
    class LogDeliveryParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LogDeliveryParametersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LogDeliveryParametersProperty | cdktn.IResolvable | undefined);
        private _logTypes?;
        get logTypes(): string[];
        set logTypes(value: string[]);
        resetLogTypes(): void;
        get logTypesInput(): string[] | undefined;
    }
    class LogDeliveryParametersPropertyList extends cdktn.ComplexList {
        internalValue?: LogDeliveryParametersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LogDeliveryParametersPropertyOutputReference;
    }
    interface MskMonitoringParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#enhanced_monitoring AwsObservabilityadminTelemetryRuleForOrganization#enhanced_monitoring}
        */
        readonly enhancedMonitoring?: string;
    }
    class MskMonitoringParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MskMonitoringParametersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MskMonitoringParametersProperty | cdktn.IResolvable | undefined);
        private _enhancedMonitoring?;
        get enhancedMonitoring(): string;
        set enhancedMonitoring(value: string);
        resetEnhancedMonitoring(): void;
        get enhancedMonitoringInput(): string | undefined;
    }
    class MskMonitoringParametersPropertyList extends cdktn.ComplexList {
        internalValue?: MskMonitoringParametersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MskMonitoringParametersPropertyOutputReference;
    }
    interface VpcFlowLogParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#log_format AwsObservabilityadminTelemetryRuleForOrganization#log_format}
        */
        readonly logFormat?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#max_aggregation_interval AwsObservabilityadminTelemetryRuleForOrganization#max_aggregation_interval}
        */
        readonly maxAggregationInterval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#traffic_type AwsObservabilityadminTelemetryRuleForOrganization#traffic_type}
        */
        readonly trafficType?: string;
    }
    class VpcFlowLogParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VpcFlowLogParametersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VpcFlowLogParametersProperty | cdktn.IResolvable | undefined);
        private _logFormat?;
        get logFormat(): string;
        set logFormat(value: string);
        resetLogFormat(): void;
        get logFormatInput(): string | undefined;
        private _maxAggregationInterval?;
        get maxAggregationInterval(): number;
        set maxAggregationInterval(value: number);
        resetMaxAggregationInterval(): void;
        get maxAggregationIntervalInput(): number | undefined;
        private _trafficType?;
        get trafficType(): string;
        set trafficType(value: string);
        resetTrafficType(): void;
        get trafficTypeInput(): string | undefined;
    }
    class VpcFlowLogParametersPropertyList extends cdktn.ComplexList {
        internalValue?: VpcFlowLogParametersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VpcFlowLogParametersPropertyOutputReference;
    }
    interface ActionConditionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#action AwsObservabilityadminTelemetryRuleForOrganization#action}
        */
        readonly action: string;
    }
    class ActionConditionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ActionConditionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ActionConditionProperty | cdktn.IResolvable | undefined);
        private _action?;
        get action(): string;
        set action(value: string);
        get actionInput(): string | undefined;
    }
    class ActionConditionPropertyList extends cdktn.ComplexList {
        internalValue?: ActionConditionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ActionConditionPropertyOutputReference;
    }
    interface LabelNameConditionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#label_name AwsObservabilityadminTelemetryRuleForOrganization#label_name}
        */
        readonly labelName?: string;
    }
    class LabelNameConditionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LabelNameConditionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LabelNameConditionProperty | cdktn.IResolvable | undefined);
        private _labelName?;
        get labelName(): string;
        set labelName(value: string);
        resetLabelName(): void;
        get labelNameInput(): string | undefined;
    }
    class LabelNameConditionPropertyList extends cdktn.ComplexList {
        internalValue?: LabelNameConditionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LabelNameConditionPropertyOutputReference;
    }
    interface ConditionsProperty {
        /**
        * action_condition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#action_condition AwsObservabilityadminTelemetryRuleForOrganization#action_condition}
        */
        readonly actionCondition?: ActionConditionProperty[] | cdktn.IResolvable;
        /**
        * label_name_condition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#label_name_condition AwsObservabilityadminTelemetryRuleForOrganization#label_name_condition}
        */
        readonly labelNameCondition?: LabelNameConditionProperty[] | cdktn.IResolvable;
    }
    class ConditionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConditionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConditionsProperty | cdktn.IResolvable | undefined);
        private _actionCondition;
        get actionCondition(): ActionConditionPropertyList;
        putActionCondition(value: ActionConditionProperty[] | cdktn.IResolvable): void;
        resetActionCondition(): void;
        get actionConditionInput(): cdktn.IResolvable | ActionConditionProperty[] | undefined;
        private _labelNameCondition;
        get labelNameCondition(): LabelNameConditionPropertyList;
        putLabelNameCondition(value: LabelNameConditionProperty[] | cdktn.IResolvable): void;
        resetLabelNameCondition(): void;
        get labelNameConditionInput(): cdktn.IResolvable | LabelNameConditionProperty[] | undefined;
    }
    class ConditionsPropertyList extends cdktn.ComplexList {
        internalValue?: ConditionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConditionsPropertyOutputReference;
    }
    interface FiltersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#behavior AwsObservabilityadminTelemetryRuleForOrganization#behavior}
        */
        readonly behavior?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#requirement AwsObservabilityadminTelemetryRuleForOrganization#requirement}
        */
        readonly requirement?: string;
        /**
        * conditions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#conditions AwsObservabilityadminTelemetryRuleForOrganization#conditions}
        */
        readonly conditions?: ConditionsProperty[] | cdktn.IResolvable;
    }
    class FiltersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FiltersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FiltersProperty | cdktn.IResolvable | undefined);
        private _behavior?;
        get behavior(): string;
        set behavior(value: string);
        resetBehavior(): void;
        get behaviorInput(): string | undefined;
        private _requirement?;
        get requirement(): string;
        set requirement(value: string);
        resetRequirement(): void;
        get requirementInput(): string | undefined;
        private _conditions;
        get conditions(): ConditionsPropertyList;
        putConditions(value: ConditionsProperty[] | cdktn.IResolvable): void;
        resetConditions(): void;
        get conditionsInput(): cdktn.IResolvable | ConditionsProperty[] | undefined;
    }
    class FiltersPropertyList extends cdktn.ComplexList {
        internalValue?: FiltersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FiltersPropertyOutputReference;
    }
    interface LoggingFilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#default_behavior AwsObservabilityadminTelemetryRuleForOrganization#default_behavior}
        */
        readonly defaultBehavior?: string;
        /**
        * filters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#filters AwsObservabilityadminTelemetryRuleForOrganization#filters}
        */
        readonly filters?: FiltersProperty[] | cdktn.IResolvable;
    }
    class LoggingFilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LoggingFilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LoggingFilterProperty | cdktn.IResolvable | undefined);
        private _defaultBehavior?;
        get defaultBehavior(): string;
        set defaultBehavior(value: string);
        resetDefaultBehavior(): void;
        get defaultBehaviorInput(): string | undefined;
        private _filters;
        get filters(): FiltersPropertyList;
        putFilters(value: FiltersProperty[] | cdktn.IResolvable): void;
        resetFilters(): void;
        get filtersInput(): cdktn.IResolvable | FiltersProperty[] | undefined;
    }
    class LoggingFilterPropertyList extends cdktn.ComplexList {
        internalValue?: LoggingFilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LoggingFilterPropertyOutputReference;
    }
    interface SingleHeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#name AwsObservabilityadminTelemetryRuleForOrganization#name}
        */
        readonly name: string;
    }
    class SingleHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SingleHeaderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SingleHeaderProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    class SingleHeaderPropertyList extends cdktn.ComplexList {
        internalValue?: SingleHeaderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SingleHeaderPropertyOutputReference;
    }
    interface RedactedFieldsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#method AwsObservabilityadminTelemetryRuleForOrganization#method}
        */
        readonly method?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#query_string AwsObservabilityadminTelemetryRuleForOrganization#query_string}
        */
        readonly queryString?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#uri_path AwsObservabilityadminTelemetryRuleForOrganization#uri_path}
        */
        readonly uriPath?: string;
        /**
        * single_header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#single_header AwsObservabilityadminTelemetryRuleForOrganization#single_header}
        */
        readonly singleHeader?: SingleHeaderProperty[] | cdktn.IResolvable;
    }
    class RedactedFieldsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RedactedFieldsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RedactedFieldsProperty | cdktn.IResolvable | undefined);
        private _method?;
        get method(): string;
        set method(value: string);
        resetMethod(): void;
        get methodInput(): string | undefined;
        private _queryString?;
        get queryString(): string;
        set queryString(value: string);
        resetQueryString(): void;
        get queryStringInput(): string | undefined;
        private _uriPath?;
        get uriPath(): string;
        set uriPath(value: string);
        resetUriPath(): void;
        get uriPathInput(): string | undefined;
        private _singleHeader;
        get singleHeader(): SingleHeaderPropertyList;
        putSingleHeader(value: SingleHeaderProperty[] | cdktn.IResolvable): void;
        resetSingleHeader(): void;
        get singleHeaderInput(): cdktn.IResolvable | SingleHeaderProperty[] | undefined;
    }
    class RedactedFieldsPropertyList extends cdktn.ComplexList {
        internalValue?: RedactedFieldsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RedactedFieldsPropertyOutputReference;
    }
    interface WafLoggingParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#log_type AwsObservabilityadminTelemetryRuleForOrganization#log_type}
        */
        readonly logType?: string;
        /**
        * logging_filter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#logging_filter AwsObservabilityadminTelemetryRuleForOrganization#logging_filter}
        */
        readonly loggingFilter?: LoggingFilterProperty[] | cdktn.IResolvable;
        /**
        * redacted_fields block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#redacted_fields AwsObservabilityadminTelemetryRuleForOrganization#redacted_fields}
        */
        readonly redactedFields?: RedactedFieldsProperty[] | cdktn.IResolvable;
    }
    class WafLoggingParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WafLoggingParametersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WafLoggingParametersProperty | cdktn.IResolvable | undefined);
        private _logType?;
        get logType(): string;
        set logType(value: string);
        resetLogType(): void;
        get logTypeInput(): string | undefined;
        private _loggingFilter;
        get loggingFilter(): LoggingFilterPropertyList;
        putLoggingFilter(value: LoggingFilterProperty[] | cdktn.IResolvable): void;
        resetLoggingFilter(): void;
        get loggingFilterInput(): cdktn.IResolvable | LoggingFilterProperty[] | undefined;
        private _redactedFields;
        get redactedFields(): RedactedFieldsPropertyList;
        putRedactedFields(value: RedactedFieldsProperty[] | cdktn.IResolvable): void;
        resetRedactedFields(): void;
        get redactedFieldsInput(): cdktn.IResolvable | RedactedFieldsProperty[] | undefined;
    }
    class WafLoggingParametersPropertyList extends cdktn.ComplexList {
        internalValue?: WafLoggingParametersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WafLoggingParametersPropertyOutputReference;
    }
    interface DestinationConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#destination_pattern AwsObservabilityadminTelemetryRuleForOrganization#destination_pattern}
        */
        readonly destinationPattern?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#destination_type AwsObservabilityadminTelemetryRuleForOrganization#destination_type}
        */
        readonly destinationType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#retention_in_days AwsObservabilityadminTelemetryRuleForOrganization#retention_in_days}
        */
        readonly retentionInDays?: number;
        /**
        * cloudtrail_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#cloudtrail_parameters AwsObservabilityadminTelemetryRuleForOrganization#cloudtrail_parameters}
        */
        readonly cloudtrailParameters?: CloudtrailParametersProperty[] | cdktn.IResolvable;
        /**
        * elb_load_balancer_logging_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#elb_load_balancer_logging_parameters AwsObservabilityadminTelemetryRuleForOrganization#elb_load_balancer_logging_parameters}
        */
        readonly elbLoadBalancerLoggingParameters?: ElbLoadBalancerLoggingParametersProperty[] | cdktn.IResolvable;
        /**
        * log_delivery_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#log_delivery_parameters AwsObservabilityadminTelemetryRuleForOrganization#log_delivery_parameters}
        */
        readonly logDeliveryParameters?: LogDeliveryParametersProperty[] | cdktn.IResolvable;
        /**
        * msk_monitoring_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#msk_monitoring_parameters AwsObservabilityadminTelemetryRuleForOrganization#msk_monitoring_parameters}
        */
        readonly mskMonitoringParameters?: MskMonitoringParametersProperty[] | cdktn.IResolvable;
        /**
        * vpc_flow_log_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#vpc_flow_log_parameters AwsObservabilityadminTelemetryRuleForOrganization#vpc_flow_log_parameters}
        */
        readonly vpcFlowLogParameters?: VpcFlowLogParametersProperty[] | cdktn.IResolvable;
        /**
        * waf_logging_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#waf_logging_parameters AwsObservabilityadminTelemetryRuleForOrganization#waf_logging_parameters}
        */
        readonly wafLoggingParameters?: WafLoggingParametersProperty[] | cdktn.IResolvable;
    }
    class DestinationConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DestinationConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DestinationConfigurationProperty | cdktn.IResolvable | undefined);
        private _destinationPattern?;
        get destinationPattern(): string;
        set destinationPattern(value: string);
        resetDestinationPattern(): void;
        get destinationPatternInput(): string | undefined;
        private _destinationType?;
        get destinationType(): string;
        set destinationType(value: string);
        resetDestinationType(): void;
        get destinationTypeInput(): string | undefined;
        private _retentionInDays?;
        get retentionInDays(): number;
        set retentionInDays(value: number);
        resetRetentionInDays(): void;
        get retentionInDaysInput(): number | undefined;
        private _cloudtrailParameters;
        get cloudtrailParameters(): CloudtrailParametersPropertyList;
        putCloudtrailParameters(value: CloudtrailParametersProperty[] | cdktn.IResolvable): void;
        resetCloudtrailParameters(): void;
        get cloudtrailParametersInput(): cdktn.IResolvable | CloudtrailParametersProperty[] | undefined;
        private _elbLoadBalancerLoggingParameters;
        get elbLoadBalancerLoggingParameters(): ElbLoadBalancerLoggingParametersPropertyList;
        putElbLoadBalancerLoggingParameters(value: ElbLoadBalancerLoggingParametersProperty[] | cdktn.IResolvable): void;
        resetElbLoadBalancerLoggingParameters(): void;
        get elbLoadBalancerLoggingParametersInput(): cdktn.IResolvable | ElbLoadBalancerLoggingParametersProperty[] | undefined;
        private _logDeliveryParameters;
        get logDeliveryParameters(): LogDeliveryParametersPropertyList;
        putLogDeliveryParameters(value: LogDeliveryParametersProperty[] | cdktn.IResolvable): void;
        resetLogDeliveryParameters(): void;
        get logDeliveryParametersInput(): cdktn.IResolvable | LogDeliveryParametersProperty[] | undefined;
        private _mskMonitoringParameters;
        get mskMonitoringParameters(): MskMonitoringParametersPropertyList;
        putMskMonitoringParameters(value: MskMonitoringParametersProperty[] | cdktn.IResolvable): void;
        resetMskMonitoringParameters(): void;
        get mskMonitoringParametersInput(): cdktn.IResolvable | MskMonitoringParametersProperty[] | undefined;
        private _vpcFlowLogParameters;
        get vpcFlowLogParameters(): VpcFlowLogParametersPropertyList;
        putVpcFlowLogParameters(value: VpcFlowLogParametersProperty[] | cdktn.IResolvable): void;
        resetVpcFlowLogParameters(): void;
        get vpcFlowLogParametersInput(): cdktn.IResolvable | VpcFlowLogParametersProperty[] | undefined;
        private _wafLoggingParameters;
        get wafLoggingParameters(): WafLoggingParametersPropertyList;
        putWafLoggingParameters(value: WafLoggingParametersProperty[] | cdktn.IResolvable): void;
        resetWafLoggingParameters(): void;
        get wafLoggingParametersInput(): cdktn.IResolvable | WafLoggingParametersProperty[] | undefined;
    }
    class DestinationConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: DestinationConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DestinationConfigurationPropertyOutputReference;
    }
    interface RuleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#all_regions AwsObservabilityadminTelemetryRuleForOrganization#all_regions}
        */
        readonly allRegions?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#allow_field_updates AwsObservabilityadminTelemetryRuleForOrganization#allow_field_updates}
        */
        readonly allowFieldUpdates?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#regions AwsObservabilityadminTelemetryRuleForOrganization#regions}
        */
        readonly regions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#resource_type AwsObservabilityadminTelemetryRuleForOrganization#resource_type}
        */
        readonly resourceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#scope AwsObservabilityadminTelemetryRuleForOrganization#scope}
        */
        readonly scope?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#selection_criteria AwsObservabilityadminTelemetryRuleForOrganization#selection_criteria}
        */
        readonly selectionCriteria?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#telemetry_source_types AwsObservabilityadminTelemetryRuleForOrganization#telemetry_source_types}
        */
        readonly telemetrySourceTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#telemetry_type AwsObservabilityadminTelemetryRuleForOrganization#telemetry_type}
        */
        readonly telemetryType: string;
        /**
        * destination_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#destination_configuration AwsObservabilityadminTelemetryRuleForOrganization#destination_configuration}
        */
        readonly destinationConfiguration?: DestinationConfigurationProperty[] | cdktn.IResolvable;
    }
    class RulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleProperty | cdktn.IResolvable | undefined);
        private _allRegions?;
        get allRegions(): boolean | cdktn.IResolvable;
        set allRegions(value: boolean | cdktn.IResolvable);
        resetAllRegions(): void;
        get allRegionsInput(): boolean | cdktn.IResolvable | undefined;
        private _allowFieldUpdates?;
        get allowFieldUpdates(): boolean | cdktn.IResolvable;
        set allowFieldUpdates(value: boolean | cdktn.IResolvable);
        resetAllowFieldUpdates(): void;
        get allowFieldUpdatesInput(): boolean | cdktn.IResolvable | undefined;
        private _regions?;
        get regions(): string[];
        set regions(value: string[]);
        resetRegions(): void;
        get regionsInput(): string[] | undefined;
        private _resourceType?;
        get resourceType(): string;
        set resourceType(value: string);
        resetResourceType(): void;
        get resourceTypeInput(): string | undefined;
        private _scope?;
        get scope(): string;
        set scope(value: string);
        resetScope(): void;
        get scopeInput(): string | undefined;
        private _selectionCriteria?;
        get selectionCriteria(): string;
        set selectionCriteria(value: string);
        resetSelectionCriteria(): void;
        get selectionCriteriaInput(): string | undefined;
        private _telemetrySourceTypes?;
        get telemetrySourceTypes(): string[];
        set telemetrySourceTypes(value: string[]);
        resetTelemetrySourceTypes(): void;
        get telemetrySourceTypesInput(): string[] | undefined;
        private _telemetryType?;
        get telemetryType(): string;
        set telemetryType(value: string);
        get telemetryTypeInput(): string | undefined;
        private _destinationConfiguration;
        get destinationConfiguration(): DestinationConfigurationPropertyList;
        putDestinationConfiguration(value: DestinationConfigurationProperty[] | cdktn.IResolvable): void;
        resetDestinationConfiguration(): void;
        get destinationConfigurationInput(): cdktn.IResolvable | DestinationConfigurationProperty[] | undefined;
    }
    class RulePropertyList extends cdktn.ComplexList {
        internalValue?: RuleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RulePropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#create AwsObservabilityadminTelemetryRuleForOrganization#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#delete AwsObservabilityadminTelemetryRuleForOrganization#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/observabilityadmin_telemetry_rule_for_organization#update AwsObservabilityadminTelemetryRuleForOrganization#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
