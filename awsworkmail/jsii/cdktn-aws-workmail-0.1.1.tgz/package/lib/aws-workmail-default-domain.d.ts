import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsWorkmailDefaultDomainConfig extends cdktn.TerraformMetaArguments {
    /**
    * Mail domain name to set as the default.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_default_domain#domain_name AwsWorkmailDefaultDomain#domain_name}
    */
    readonly domainName: string;
    /**
    * Identifier of the WorkMail organization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_default_domain#organization_id AwsWorkmailDefaultDomain#organization_id}
    */
    readonly organizationId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_default_domain#region AwsWorkmailDefaultDomain#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_default_domain aws_workmail_default_domain}
*/
export declare class AwsWorkmailDefaultDomain extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_workmail_default_domain";
    /**
    * Generates CDKTN code for importing a AwsWorkmailDefaultDomain resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsWorkmailDefaultDomain to import
    * @param importFromId The id of the existing AwsWorkmailDefaultDomain that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_default_domain#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsWorkmailDefaultDomain to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_default_domain aws_workmail_default_domain} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsWorkmailDefaultDomainConfig
    */
    constructor(scope: Construct, id: string, config: AwsWorkmailDefaultDomainConfig);
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    private _organizationId?;
    get organizationId(): string;
    set organizationId(value: string);
    get organizationIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
