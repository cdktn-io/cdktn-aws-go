import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsWorkmailUserConfig extends cdktn.TerraformMetaArguments {
    /**
    * City where the user is located.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_user#city AwsWorkmailUser#city}
    */
    readonly city?: string;
    /**
    * Company associated with the user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_user#company AwsWorkmailUser#company}
    */
    readonly company?: string;
    /**
    * Country where the user is located.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_user#country AwsWorkmailUser#country}
    */
    readonly country?: string;
    /**
    * Department associated with the user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_user#department AwsWorkmailUser#department}
    */
    readonly department?: string;
    /**
    * Display name of the user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_user#display_name AwsWorkmailUser#display_name}
    */
    readonly displayName: string;
    /**
    * Primary email address used to register the user with WorkMail.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_user#email AwsWorkmailUser#email}
    */
    readonly email: string;
    /**
    * First name of the user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_user#first_name AwsWorkmailUser#first_name}
    */
    readonly firstName?: string;
    /**
    * Whether to hide the user from the global address list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_user#hidden_from_global_address_list AwsWorkmailUser#hidden_from_global_address_list}
    */
    readonly hiddenFromGlobalAddressList?: boolean | cdktn.IResolvable;
    /**
    * User ID from IAM Identity Center associated with the user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_user#identity_provider_user_id AwsWorkmailUser#identity_provider_user_id}
    */
    readonly identityProviderUserId?: string;
    /**
    * Initials of the user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_user#initials AwsWorkmailUser#initials}
    */
    readonly initials?: string;
    /**
    * Job title of the user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_user#job_title AwsWorkmailUser#job_title}
    */
    readonly jobTitle?: string;
    /**
    * Last name of the user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_user#last_name AwsWorkmailUser#last_name}
    */
    readonly lastName?: string;
    /**
    * Username of the user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_user#name AwsWorkmailUser#name}
    */
    readonly name: string;
    /**
    * Office where the user is located.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_user#office AwsWorkmailUser#office}
    */
    readonly office?: string;
    /**
    * Identifier of the WorkMail organization where the user is managed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_user#organization_id AwsWorkmailUser#organization_id}
    */
    readonly organizationId: string;
    /**
    * Password to set for the user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_user#password AwsWorkmailUser#password}
    */
    readonly password?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_user#region AwsWorkmailUser#region}
    */
    readonly region?: string;
    /**
    * Street address of the user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_user#street AwsWorkmailUser#street}
    */
    readonly street?: string;
    /**
    * Telephone number of the user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_user#telephone AwsWorkmailUser#telephone}
    */
    readonly telephone?: string;
    /**
    * Role assigned to the user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_user#user_role AwsWorkmailUser#user_role}
    */
    readonly userRole?: string;
    /**
    * ZIP or postal code of the user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_user#zip_code AwsWorkmailUser#zip_code}
    */
    readonly zipCode?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_user aws_workmail_user}
*/
export declare class AwsWorkmailUser extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_workmail_user";
    /**
    * Generates CDKTN code for importing a AwsWorkmailUser resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsWorkmailUser to import
    * @param importFromId The id of the existing AwsWorkmailUser that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_user#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsWorkmailUser to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_user aws_workmail_user} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsWorkmailUserConfig
    */
    constructor(scope: Construct, id: string, config: AwsWorkmailUserConfig);
    private _city?;
    get city(): string;
    set city(value: string);
    resetCity(): void;
    get cityInput(): string | undefined;
    private _company?;
    get company(): string;
    set company(value: string);
    resetCompany(): void;
    get companyInput(): string | undefined;
    private _country?;
    get country(): string;
    set country(value: string);
    resetCountry(): void;
    get countryInput(): string | undefined;
    private _department?;
    get department(): string;
    set department(value: string);
    resetDepartment(): void;
    get departmentInput(): string | undefined;
    get disabledDate(): string;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _email?;
    get email(): string;
    set email(value: string);
    get emailInput(): string | undefined;
    get enabledDate(): string;
    private _firstName?;
    get firstName(): string;
    set firstName(value: string);
    resetFirstName(): void;
    get firstNameInput(): string | undefined;
    private _hiddenFromGlobalAddressList?;
    get hiddenFromGlobalAddressList(): boolean | cdktn.IResolvable;
    set hiddenFromGlobalAddressList(value: boolean | cdktn.IResolvable);
    resetHiddenFromGlobalAddressList(): void;
    get hiddenFromGlobalAddressListInput(): boolean | cdktn.IResolvable | undefined;
    get identityProviderIdentityStoreId(): string;
    private _identityProviderUserId?;
    get identityProviderUserId(): string;
    set identityProviderUserId(value: string);
    resetIdentityProviderUserId(): void;
    get identityProviderUserIdInput(): string | undefined;
    private _initials?;
    get initials(): string;
    set initials(value: string);
    resetInitials(): void;
    get initialsInput(): string | undefined;
    private _jobTitle?;
    get jobTitle(): string;
    set jobTitle(value: string);
    resetJobTitle(): void;
    get jobTitleInput(): string | undefined;
    private _lastName?;
    get lastName(): string;
    set lastName(value: string);
    resetLastName(): void;
    get lastNameInput(): string | undefined;
    get mailboxDeprovisionedDate(): string;
    get mailboxProvisionedDate(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _office?;
    get office(): string;
    set office(value: string);
    resetOffice(): void;
    get officeInput(): string | undefined;
    private _organizationId?;
    get organizationId(): string;
    set organizationId(value: string);
    get organizationIdInput(): string | undefined;
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get state(): string;
    private _street?;
    get street(): string;
    set street(value: string);
    resetStreet(): void;
    get streetInput(): string | undefined;
    private _telephone?;
    get telephone(): string;
    set telephone(value: string);
    resetTelephone(): void;
    get telephoneInput(): string | undefined;
    get userId(): string;
    private _userRole?;
    get userRole(): string;
    set userRole(value: string);
    resetUserRole(): void;
    get userRoleInput(): string | undefined;
    private _zipCode?;
    get zipCode(): string;
    set zipCode(value: string);
    resetZipCode(): void;
    get zipCodeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
