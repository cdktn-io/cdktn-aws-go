import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsWorkmailOrganizationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_organization#delete_directory AwsWorkmailOrganization#delete_directory}
    */
    readonly deleteDirectory?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_organization#delete_identity_center_application AwsWorkmailOrganization#delete_identity_center_application}
    */
    readonly deleteIdentityCenterApplication?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_organization#directory_id AwsWorkmailOrganization#directory_id}
    */
    readonly directoryId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_organization#interoperability_enabled AwsWorkmailOrganization#interoperability_enabled}
    */
    readonly interoperabilityEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_organization#kms_key_arn AwsWorkmailOrganization#kms_key_arn}
    */
    readonly kmsKeyArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_organization#organization_alias AwsWorkmailOrganization#organization_alias}
    */
    readonly organizationAlias: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_organization#region AwsWorkmailOrganization#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_organization#tags AwsWorkmailOrganization#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_organization#timeouts AwsWorkmailOrganization#timeouts}
    */
    readonly timeouts?: AwsWorkmailOrganization.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_organization aws_workmail_organization}
*/
export declare class AwsWorkmailOrganization extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_workmail_organization";
    /**
    * Generates CDKTN code for importing a AwsWorkmailOrganization resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsWorkmailOrganization to import
    * @param importFromId The id of the existing AwsWorkmailOrganization that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_organization#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsWorkmailOrganization to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_organization aws_workmail_organization} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsWorkmailOrganizationConfig
    */
    constructor(scope: Construct, id: string, config: AwsWorkmailOrganizationConfig);
    get arn(): string;
    get completedDate(): string;
    get defaultMailDomain(): string;
    private _deleteDirectory?;
    get deleteDirectory(): boolean | cdktn.IResolvable;
    set deleteDirectory(value: boolean | cdktn.IResolvable);
    resetDeleteDirectory(): void;
    get deleteDirectoryInput(): boolean | cdktn.IResolvable | undefined;
    private _deleteIdentityCenterApplication?;
    get deleteIdentityCenterApplication(): boolean | cdktn.IResolvable;
    set deleteIdentityCenterApplication(value: boolean | cdktn.IResolvable);
    resetDeleteIdentityCenterApplication(): void;
    get deleteIdentityCenterApplicationInput(): boolean | cdktn.IResolvable | undefined;
    private _directoryId?;
    get directoryId(): string;
    set directoryId(value: string);
    resetDirectoryId(): void;
    get directoryIdInput(): string | undefined;
    get directoryType(): string;
    private _interoperabilityEnabled?;
    get interoperabilityEnabled(): boolean | cdktn.IResolvable;
    set interoperabilityEnabled(value: boolean | cdktn.IResolvable);
    resetInteroperabilityEnabled(): void;
    get interoperabilityEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _kmsKeyArn?;
    get kmsKeyArn(): string;
    set kmsKeyArn(value: string);
    resetKmsKeyArn(): void;
    get kmsKeyArnInput(): string | undefined;
    get migrationAdmin(): string;
    private _organizationAlias?;
    get organizationAlias(): string;
    set organizationAlias(value: string);
    get organizationAliasInput(): string | undefined;
    get organizationId(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get state(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _timeouts;
    get timeouts(): AwsWorkmailOrganization.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsWorkmailOrganization.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsWorkmailOrganization.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsWorkmailOrganizationTimeoutsPropertyToTerraform(struct?: AwsWorkmailOrganization.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsWorkmailOrganizationTimeoutsPropertyToHclTerraform(struct?: AwsWorkmailOrganization.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsWorkmailOrganization {
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_organization#create AwsWorkmailOrganization#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_organization#delete AwsWorkmailOrganization#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
