import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsWorkmailDomainConfig extends cdktn.TerraformMetaArguments {
    /**
    * Mail domain name to register.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_domain#domain_name AwsWorkmailDomain#domain_name}
    */
    readonly domainName: string;
    /**
    * Identifier of the WorkMail organization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_domain#organization_id AwsWorkmailDomain#organization_id}
    */
    readonly organizationId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_domain#region AwsWorkmailDomain#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_domain aws_workmail_domain}
*/
export declare class AwsWorkmailDomain extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_workmail_domain";
    /**
    * Generates CDKTN code for importing a AwsWorkmailDomain resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsWorkmailDomain to import
    * @param importFromId The id of the existing AwsWorkmailDomain that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_domain#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsWorkmailDomain to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_domain aws_workmail_domain} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsWorkmailDomainConfig
    */
    constructor(scope: Construct, id: string, config: AwsWorkmailDomainConfig);
    get dkimVerificationStatus(): string;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    get isDefault(): cdktn.IResolvable;
    get isTestDomain(): cdktn.IResolvable;
    private _organizationId?;
    get organizationId(): string;
    set organizationId(value: string);
    get organizationIdInput(): string | undefined;
    get ownershipVerificationStatus(): string;
    private _records;
    get records(): AwsWorkmailDomain.RecordsPropertyList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsWorkmailDomainRecordsPropertyToTerraform(struct?: AwsWorkmailDomain.RecordsProperty): any;
export declare function awsWorkmailDomainRecordsPropertyToHclTerraform(struct?: AwsWorkmailDomain.RecordsProperty): any;
export declare namespace AwsWorkmailDomain {
    interface RecordsProperty {
    }
    class RecordsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RecordsProperty | undefined;
        set internalValue(value: RecordsProperty | undefined);
        get hostname(): string;
        get type(): string;
        get value(): string;
    }
    class RecordsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RecordsPropertyOutputReference;
    }
}
