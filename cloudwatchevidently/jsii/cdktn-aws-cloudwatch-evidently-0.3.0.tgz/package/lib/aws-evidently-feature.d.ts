import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsFeatureConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_feature#default_variation AwsFeature#default_variation}
    */
    readonly defaultVariation?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_feature#description AwsFeature#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_feature#entity_overrides AwsFeature#entity_overrides}
    */
    readonly entityOverrides?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_feature#evaluation_strategy AwsFeature#evaluation_strategy}
    */
    readonly evaluationStrategy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_feature#id AwsFeature#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_feature#name AwsFeature#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_feature#project AwsFeature#project}
    */
    readonly project: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_feature#region AwsFeature#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_feature#tags AwsFeature#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_feature#tags_all AwsFeature#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_feature#timeouts AwsFeature#timeouts}
    */
    readonly timeouts?: AwsFeature.TimeoutsProperty;
    /**
    * variations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_feature#variations AwsFeature#variations}
    */
    readonly variations: AwsFeature.VariationsProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_feature aws_evidently_feature}
*/
export declare class AwsFeature extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_evidently_feature";
    /**
    * Generates CDKTN code for importing a AwsFeature resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsFeature to import
    * @param importFromId The id of the existing AwsFeature that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_feature#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsFeature to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_feature aws_evidently_feature} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsFeatureConfig
    */
    constructor(scope: Construct, id: string, config: AwsFeatureConfig);
    get arn(): string;
    get createdTime(): string;
    private _defaultVariation?;
    get defaultVariation(): string;
    set defaultVariation(value: string);
    resetDefaultVariation(): void;
    get defaultVariationInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _entityOverrides?;
    get entityOverrides(): {
        [key: string]: string;
    };
    set entityOverrides(value: {
        [key: string]: string;
    });
    resetEntityOverrides(): void;
    get entityOverridesInput(): {
        [key: string]: string;
    } | undefined;
    private _evaluationRules;
    get evaluationRules(): AwsFeature.EvaluationRulesPropertyList;
    private _evaluationStrategy?;
    get evaluationStrategy(): string;
    set evaluationStrategy(value: string);
    resetEvaluationStrategy(): void;
    get evaluationStrategyInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastUpdatedTime(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get valueType(): string;
    private _timeouts;
    get timeouts(): AwsFeature.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsFeature.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): AwsFeature.TimeoutsProperty | cdktn.IResolvable | undefined;
    private _variations;
    get variations(): AwsFeature.VariationsPropertyList;
    putVariations(value: AwsFeature.VariationsProperty[] | cdktn.IResolvable): void;
    get variationsInput(): cdktn.IResolvable | AwsFeature.VariationsProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsFeatureEvaluationRulesPropertyToTerraform(struct?: AwsFeature.EvaluationRulesProperty): any;
export declare function awsFeatureEvaluationRulesPropertyToHclTerraform(struct?: AwsFeature.EvaluationRulesProperty): any;
export declare function awsFeatureTimeoutsPropertyToTerraform(struct?: AwsFeature.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsFeatureTimeoutsPropertyToHclTerraform(struct?: AwsFeature.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsFeatureValuePropertyToTerraform(struct?: AwsFeature.ValuePropertyOutputReference | AwsFeature.ValueProperty): any;
export declare function awsFeatureValuePropertyToHclTerraform(struct?: AwsFeature.ValuePropertyOutputReference | AwsFeature.ValueProperty): any;
export declare function awsFeatureVariationsPropertyToTerraform(struct?: AwsFeature.VariationsProperty | cdktn.IResolvable): any;
export declare function awsFeatureVariationsPropertyToHclTerraform(struct?: AwsFeature.VariationsProperty | cdktn.IResolvable): any;
export declare namespace AwsFeature {
    interface EvaluationRulesProperty {
    }
    class EvaluationRulesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EvaluationRulesProperty | undefined;
        set internalValue(value: EvaluationRulesProperty | undefined);
        get name(): string;
        get type(): string;
    }
    class EvaluationRulesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EvaluationRulesPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_feature#create AwsFeature#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_feature#delete AwsFeature#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_feature#update AwsFeature#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface ValueProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_feature#bool_value AwsFeature#bool_value}
        */
        readonly boolValue?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_feature#double_value AwsFeature#double_value}
        */
        readonly doubleValue?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_feature#long_value AwsFeature#long_value}
        */
        readonly longValue?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_feature#string_value AwsFeature#string_value}
        */
        readonly stringValue?: string;
    }
    class ValuePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ValueProperty | undefined;
        set internalValue(value: ValueProperty | undefined);
        private _boolValue?;
        get boolValue(): string;
        set boolValue(value: string);
        resetBoolValue(): void;
        get boolValueInput(): string | undefined;
        private _doubleValue?;
        get doubleValue(): string;
        set doubleValue(value: string);
        resetDoubleValue(): void;
        get doubleValueInput(): string | undefined;
        private _longValue?;
        get longValue(): string;
        set longValue(value: string);
        resetLongValue(): void;
        get longValueInput(): string | undefined;
        private _stringValue?;
        get stringValue(): string;
        set stringValue(value: string);
        resetStringValue(): void;
        get stringValueInput(): string | undefined;
    }
    interface VariationsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_feature#name AwsFeature#name}
        */
        readonly name: string;
        /**
        * value block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_feature#value AwsFeature#value}
        */
        readonly value: ValueProperty;
    }
    class VariationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VariationsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VariationsProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value;
        get value(): ValuePropertyOutputReference;
        putValue(value: ValueProperty): void;
        get valueInput(): ValueProperty | undefined;
    }
    class VariationsPropertyList extends cdktn.ComplexList {
        internalValue?: VariationsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VariationsPropertyOutputReference;
    }
}
