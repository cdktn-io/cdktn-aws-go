import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsLaunchConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#description AwsLaunch#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#id AwsLaunch#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#name AwsLaunch#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#project AwsLaunch#project}
    */
    readonly project: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#randomization_salt AwsLaunch#randomization_salt}
    */
    readonly randomizationSalt?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#region AwsLaunch#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#tags AwsLaunch#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#tags_all AwsLaunch#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * groups block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#groups AwsLaunch#groups}
    */
    readonly groups: AwsLaunch.GroupsProperty[] | cdktn.IResolvable;
    /**
    * metric_monitors block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#metric_monitors AwsLaunch#metric_monitors}
    */
    readonly metricMonitors?: AwsLaunch.MetricMonitorsProperty[] | cdktn.IResolvable;
    /**
    * scheduled_splits_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#scheduled_splits_config AwsLaunch#scheduled_splits_config}
    */
    readonly scheduledSplitsConfig?: AwsLaunch.ScheduledSplitsConfigProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#timeouts AwsLaunch#timeouts}
    */
    readonly timeouts?: AwsLaunch.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch aws_evidently_launch}
*/
export declare class AwsLaunch extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_evidently_launch";
    /**
    * Generates CDKTN code for importing a AwsLaunch resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsLaunch to import
    * @param importFromId The id of the existing AwsLaunch that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsLaunch to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch aws_evidently_launch} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsLaunchConfig
    */
    constructor(scope: Construct, id: string, config: AwsLaunchConfig);
    get arn(): string;
    get createdTime(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _execution;
    get execution(): AwsLaunch.ExecutionPropertyList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastUpdatedTime(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _randomizationSalt?;
    get randomizationSalt(): string;
    set randomizationSalt(value: string);
    resetRandomizationSalt(): void;
    get randomizationSaltInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    get statusReason(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get type(): string;
    private _groups;
    get groups(): AwsLaunch.GroupsPropertyList;
    putGroups(value: AwsLaunch.GroupsProperty[] | cdktn.IResolvable): void;
    get groupsInput(): cdktn.IResolvable | AwsLaunch.GroupsProperty[] | undefined;
    private _metricMonitors;
    get metricMonitors(): AwsLaunch.MetricMonitorsPropertyList;
    putMetricMonitors(value: AwsLaunch.MetricMonitorsProperty[] | cdktn.IResolvable): void;
    resetMetricMonitors(): void;
    get metricMonitorsInput(): cdktn.IResolvable | AwsLaunch.MetricMonitorsProperty[] | undefined;
    private _scheduledSplitsConfig;
    get scheduledSplitsConfig(): AwsLaunch.ScheduledSplitsConfigPropertyOutputReference;
    putScheduledSplitsConfig(value: AwsLaunch.ScheduledSplitsConfigProperty): void;
    resetScheduledSplitsConfig(): void;
    get scheduledSplitsConfigInput(): AwsLaunch.ScheduledSplitsConfigProperty | undefined;
    private _timeouts;
    get timeouts(): AwsLaunch.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsLaunch.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsLaunch.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsLaunchExecutionPropertyToTerraform(struct?: AwsLaunch.ExecutionProperty): any;
export declare function awsLaunchExecutionPropertyToHclTerraform(struct?: AwsLaunch.ExecutionProperty): any;
export declare function awsLaunchGroupsPropertyToTerraform(struct?: AwsLaunch.GroupsProperty | cdktn.IResolvable): any;
export declare function awsLaunchGroupsPropertyToHclTerraform(struct?: AwsLaunch.GroupsProperty | cdktn.IResolvable): any;
export declare function awsLaunchMetricDefinitionPropertyToTerraform(struct?: AwsLaunch.MetricDefinitionPropertyOutputReference | AwsLaunch.MetricDefinitionProperty): any;
export declare function awsLaunchMetricDefinitionPropertyToHclTerraform(struct?: AwsLaunch.MetricDefinitionPropertyOutputReference | AwsLaunch.MetricDefinitionProperty): any;
export declare function awsLaunchMetricMonitorsPropertyToTerraform(struct?: AwsLaunch.MetricMonitorsProperty | cdktn.IResolvable): any;
export declare function awsLaunchMetricMonitorsPropertyToHclTerraform(struct?: AwsLaunch.MetricMonitorsProperty | cdktn.IResolvable): any;
export declare function awsLaunchSegmentOverridesPropertyToTerraform(struct?: AwsLaunch.SegmentOverridesProperty | cdktn.IResolvable): any;
export declare function awsLaunchSegmentOverridesPropertyToHclTerraform(struct?: AwsLaunch.SegmentOverridesProperty | cdktn.IResolvable): any;
export declare function awsLaunchStepsPropertyToTerraform(struct?: AwsLaunch.StepsProperty | cdktn.IResolvable): any;
export declare function awsLaunchStepsPropertyToHclTerraform(struct?: AwsLaunch.StepsProperty | cdktn.IResolvable): any;
export declare function awsLaunchScheduledSplitsConfigPropertyToTerraform(struct?: AwsLaunch.ScheduledSplitsConfigPropertyOutputReference | AwsLaunch.ScheduledSplitsConfigProperty): any;
export declare function awsLaunchScheduledSplitsConfigPropertyToHclTerraform(struct?: AwsLaunch.ScheduledSplitsConfigPropertyOutputReference | AwsLaunch.ScheduledSplitsConfigProperty): any;
export declare function awsLaunchTimeoutsPropertyToTerraform(struct?: AwsLaunch.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsLaunchTimeoutsPropertyToHclTerraform(struct?: AwsLaunch.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsLaunch {
    interface ExecutionProperty {
    }
    class ExecutionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExecutionProperty | undefined;
        set internalValue(value: ExecutionProperty | undefined);
        get endedTime(): string;
        get startedTime(): string;
    }
    class ExecutionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExecutionPropertyOutputReference;
    }
    interface GroupsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#description AwsLaunch#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#feature AwsLaunch#feature}
        */
        readonly feature: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#name AwsLaunch#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#variation AwsLaunch#variation}
        */
        readonly variation: string;
    }
    class GroupsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GroupsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: GroupsProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _feature?;
        get feature(): string;
        set feature(value: string);
        get featureInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _variation?;
        get variation(): string;
        set variation(value: string);
        get variationInput(): string | undefined;
    }
    class GroupsPropertyList extends cdktn.ComplexList {
        internalValue?: GroupsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GroupsPropertyOutputReference;
    }
    interface MetricDefinitionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#entity_id_key AwsLaunch#entity_id_key}
        */
        readonly entityIdKey: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#event_pattern AwsLaunch#event_pattern}
        */
        readonly eventPattern?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#name AwsLaunch#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#unit_label AwsLaunch#unit_label}
        */
        readonly unitLabel?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#value_key AwsLaunch#value_key}
        */
        readonly valueKey: string;
    }
    class MetricDefinitionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MetricDefinitionProperty | undefined;
        set internalValue(value: MetricDefinitionProperty | undefined);
        private _entityIdKey?;
        get entityIdKey(): string;
        set entityIdKey(value: string);
        get entityIdKeyInput(): string | undefined;
        private _eventPattern?;
        get eventPattern(): string;
        set eventPattern(value: string);
        resetEventPattern(): void;
        get eventPatternInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _unitLabel?;
        get unitLabel(): string;
        set unitLabel(value: string);
        resetUnitLabel(): void;
        get unitLabelInput(): string | undefined;
        private _valueKey?;
        get valueKey(): string;
        set valueKey(value: string);
        get valueKeyInput(): string | undefined;
    }
    interface MetricMonitorsProperty {
        /**
        * metric_definition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#metric_definition AwsLaunch#metric_definition}
        */
        readonly metricDefinition: MetricDefinitionProperty;
    }
    class MetricMonitorsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MetricMonitorsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MetricMonitorsProperty | cdktn.IResolvable | undefined);
        private _metricDefinition;
        get metricDefinition(): MetricDefinitionPropertyOutputReference;
        putMetricDefinition(value: MetricDefinitionProperty): void;
        get metricDefinitionInput(): MetricDefinitionProperty | undefined;
    }
    class MetricMonitorsPropertyList extends cdktn.ComplexList {
        internalValue?: MetricMonitorsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MetricMonitorsPropertyOutputReference;
    }
    interface SegmentOverridesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#evaluation_order AwsLaunch#evaluation_order}
        */
        readonly evaluationOrder: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#segment AwsLaunch#segment}
        */
        readonly segment: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#weights AwsLaunch#weights}
        */
        readonly weights: {
            [key: string]: number;
        };
    }
    class SegmentOverridesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SegmentOverridesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SegmentOverridesProperty | cdktn.IResolvable | undefined);
        private _evaluationOrder?;
        get evaluationOrder(): number;
        set evaluationOrder(value: number);
        get evaluationOrderInput(): number | undefined;
        private _segment?;
        get segment(): string;
        set segment(value: string);
        get segmentInput(): string | undefined;
        private _weights?;
        get weights(): {
            [key: string]: number;
        };
        set weights(value: {
            [key: string]: number;
        });
        get weightsInput(): {
            [key: string]: number;
        } | undefined;
    }
    class SegmentOverridesPropertyList extends cdktn.ComplexList {
        internalValue?: SegmentOverridesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SegmentOverridesPropertyOutputReference;
    }
    interface StepsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#group_weights AwsLaunch#group_weights}
        */
        readonly groupWeights: {
            [key: string]: number;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#start_time AwsLaunch#start_time}
        */
        readonly startTime: string;
        /**
        * segment_overrides block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#segment_overrides AwsLaunch#segment_overrides}
        */
        readonly segmentOverrides?: SegmentOverridesProperty[] | cdktn.IResolvable;
    }
    class StepsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StepsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StepsProperty | cdktn.IResolvable | undefined);
        private _groupWeights?;
        get groupWeights(): {
            [key: string]: number;
        };
        set groupWeights(value: {
            [key: string]: number;
        });
        get groupWeightsInput(): {
            [key: string]: number;
        } | undefined;
        private _startTime?;
        get startTime(): string;
        set startTime(value: string);
        get startTimeInput(): string | undefined;
        private _segmentOverrides;
        get segmentOverrides(): SegmentOverridesPropertyList;
        putSegmentOverrides(value: SegmentOverridesProperty[] | cdktn.IResolvable): void;
        resetSegmentOverrides(): void;
        get segmentOverridesInput(): cdktn.IResolvable | SegmentOverridesProperty[] | undefined;
    }
    class StepsPropertyList extends cdktn.ComplexList {
        internalValue?: StepsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StepsPropertyOutputReference;
    }
    interface ScheduledSplitsConfigProperty {
        /**
        * steps block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#steps AwsLaunch#steps}
        */
        readonly steps: StepsProperty[] | cdktn.IResolvable;
    }
    class ScheduledSplitsConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ScheduledSplitsConfigProperty | undefined;
        set internalValue(value: ScheduledSplitsConfigProperty | undefined);
        private _steps;
        get steps(): StepsPropertyList;
        putSteps(value: StepsProperty[] | cdktn.IResolvable): void;
        get stepsInput(): cdktn.IResolvable | StepsProperty[] | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#create AwsLaunch#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#delete AwsLaunch#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/evidently_launch#update AwsLaunch#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
