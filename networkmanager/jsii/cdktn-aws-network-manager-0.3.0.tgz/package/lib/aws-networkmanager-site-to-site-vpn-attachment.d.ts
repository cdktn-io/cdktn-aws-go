import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSiteToSiteVpnAttachmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_site_to_site_vpn_attachment#core_network_id AwsSiteToSiteVpnAttachment#core_network_id}
    */
    readonly coreNetworkId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_site_to_site_vpn_attachment#id AwsSiteToSiteVpnAttachment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_site_to_site_vpn_attachment#routing_policy_label AwsSiteToSiteVpnAttachment#routing_policy_label}
    */
    readonly routingPolicyLabel?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_site_to_site_vpn_attachment#tags AwsSiteToSiteVpnAttachment#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_site_to_site_vpn_attachment#tags_all AwsSiteToSiteVpnAttachment#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_site_to_site_vpn_attachment#vpn_connection_arn AwsSiteToSiteVpnAttachment#vpn_connection_arn}
    */
    readonly vpnConnectionArn: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_site_to_site_vpn_attachment#timeouts AwsSiteToSiteVpnAttachment#timeouts}
    */
    readonly timeouts?: AwsSiteToSiteVpnAttachment.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_site_to_site_vpn_attachment aws_networkmanager_site_to_site_vpn_attachment}
*/
export declare class AwsSiteToSiteVpnAttachment extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_networkmanager_site_to_site_vpn_attachment";
    /**
    * Generates CDKTN code for importing a AwsSiteToSiteVpnAttachment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSiteToSiteVpnAttachment to import
    * @param importFromId The id of the existing AwsSiteToSiteVpnAttachment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_site_to_site_vpn_attachment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSiteToSiteVpnAttachment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_site_to_site_vpn_attachment aws_networkmanager_site_to_site_vpn_attachment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSiteToSiteVpnAttachmentConfig
    */
    constructor(scope: Construct, id: string, config: AwsSiteToSiteVpnAttachmentConfig);
    get arn(): string;
    get attachmentPolicyRuleNumber(): number;
    get attachmentType(): string;
    get coreNetworkArn(): string;
    private _coreNetworkId?;
    get coreNetworkId(): string;
    set coreNetworkId(value: string);
    get coreNetworkIdInput(): string | undefined;
    get edgeLocation(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get ownerAccountId(): string;
    get resourceArn(): string;
    private _routingPolicyLabel?;
    get routingPolicyLabel(): string;
    set routingPolicyLabel(value: string);
    resetRoutingPolicyLabel(): void;
    get routingPolicyLabelInput(): string | undefined;
    get segmentName(): string;
    get state(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _vpnConnectionArn?;
    get vpnConnectionArn(): string;
    set vpnConnectionArn(value: string);
    get vpnConnectionArnInput(): string | undefined;
    private _timeouts;
    get timeouts(): AwsSiteToSiteVpnAttachment.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsSiteToSiteVpnAttachment.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsSiteToSiteVpnAttachment.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsSiteToSiteVpnAttachmentTimeoutsPropertyToTerraform(struct?: AwsSiteToSiteVpnAttachment.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsSiteToSiteVpnAttachmentTimeoutsPropertyToHclTerraform(struct?: AwsSiteToSiteVpnAttachment.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsSiteToSiteVpnAttachment {
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_site_to_site_vpn_attachment#create AwsSiteToSiteVpnAttachment#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_site_to_site_vpn_attachment#delete AwsSiteToSiteVpnAttachment#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_site_to_site_vpn_attachment#update AwsSiteToSiteVpnAttachment#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
