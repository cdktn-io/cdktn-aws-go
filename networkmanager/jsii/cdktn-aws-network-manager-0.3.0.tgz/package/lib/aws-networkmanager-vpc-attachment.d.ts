import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsVpcAttachmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_vpc_attachment#core_network_id AwsVpcAttachment#core_network_id}
    */
    readonly coreNetworkId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_vpc_attachment#id AwsVpcAttachment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_vpc_attachment#routing_policy_label AwsVpcAttachment#routing_policy_label}
    */
    readonly routingPolicyLabel?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_vpc_attachment#subnet_arns AwsVpcAttachment#subnet_arns}
    */
    readonly subnetArns: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_vpc_attachment#tags AwsVpcAttachment#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_vpc_attachment#tags_all AwsVpcAttachment#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_vpc_attachment#vpc_arn AwsVpcAttachment#vpc_arn}
    */
    readonly vpcArn: string;
    /**
    * options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_vpc_attachment#options AwsVpcAttachment#options}
    */
    readonly options?: AwsVpcAttachment.OptionsProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_vpc_attachment#timeouts AwsVpcAttachment#timeouts}
    */
    readonly timeouts?: AwsVpcAttachment.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_vpc_attachment aws_networkmanager_vpc_attachment}
*/
export declare class AwsVpcAttachment extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_networkmanager_vpc_attachment";
    /**
    * Generates CDKTN code for importing a AwsVpcAttachment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsVpcAttachment to import
    * @param importFromId The id of the existing AwsVpcAttachment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_vpc_attachment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsVpcAttachment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_vpc_attachment aws_networkmanager_vpc_attachment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsVpcAttachmentConfig
    */
    constructor(scope: Construct, id: string, config: AwsVpcAttachmentConfig);
    get arn(): string;
    get attachmentPolicyRuleNumber(): number;
    get attachmentType(): string;
    get coreNetworkArn(): string;
    private _coreNetworkId?;
    get coreNetworkId(): string;
    set coreNetworkId(value: string);
    get coreNetworkIdInput(): string | undefined;
    get edgeLocation(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get ownerAccountId(): string;
    get resourceArn(): string;
    private _routingPolicyLabel?;
    get routingPolicyLabel(): string;
    set routingPolicyLabel(value: string);
    resetRoutingPolicyLabel(): void;
    get routingPolicyLabelInput(): string | undefined;
    get segmentName(): string;
    get state(): string;
    private _subnetArns?;
    get subnetArns(): string[];
    set subnetArns(value: string[]);
    get subnetArnsInput(): string[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _vpcArn?;
    get vpcArn(): string;
    set vpcArn(value: string);
    get vpcArnInput(): string | undefined;
    private _options;
    get options(): AwsVpcAttachment.OptionsPropertyOutputReference;
    putOptions(value: AwsVpcAttachment.OptionsProperty): void;
    resetOptions(): void;
    get optionsInput(): AwsVpcAttachment.OptionsProperty | undefined;
    private _timeouts;
    get timeouts(): AwsVpcAttachment.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsVpcAttachment.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsVpcAttachment.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsVpcAttachmentOptionsPropertyToTerraform(struct?: AwsVpcAttachment.OptionsPropertyOutputReference | AwsVpcAttachment.OptionsProperty): any;
export declare function awsVpcAttachmentOptionsPropertyToHclTerraform(struct?: AwsVpcAttachment.OptionsPropertyOutputReference | AwsVpcAttachment.OptionsProperty): any;
export declare function awsVpcAttachmentTimeoutsPropertyToTerraform(struct?: AwsVpcAttachment.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsVpcAttachmentTimeoutsPropertyToHclTerraform(struct?: AwsVpcAttachment.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsVpcAttachment {
    interface OptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_vpc_attachment#appliance_mode_support AwsVpcAttachment#appliance_mode_support}
        */
        readonly applianceModeSupport?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_vpc_attachment#dns_support AwsVpcAttachment#dns_support}
        */
        readonly dnsSupport?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_vpc_attachment#ipv6_support AwsVpcAttachment#ipv6_support}
        */
        readonly ipv6Support?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_vpc_attachment#security_group_referencing_support AwsVpcAttachment#security_group_referencing_support}
        */
        readonly securityGroupReferencingSupport?: boolean | cdktn.IResolvable;
    }
    class OptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OptionsProperty | undefined;
        set internalValue(value: OptionsProperty | undefined);
        private _applianceModeSupport?;
        get applianceModeSupport(): boolean | cdktn.IResolvable;
        set applianceModeSupport(value: boolean | cdktn.IResolvable);
        resetApplianceModeSupport(): void;
        get applianceModeSupportInput(): boolean | cdktn.IResolvable | undefined;
        private _dnsSupport?;
        get dnsSupport(): boolean | cdktn.IResolvable;
        set dnsSupport(value: boolean | cdktn.IResolvable);
        resetDnsSupport(): void;
        get dnsSupportInput(): boolean | cdktn.IResolvable | undefined;
        private _ipv6Support?;
        get ipv6Support(): boolean | cdktn.IResolvable;
        set ipv6Support(value: boolean | cdktn.IResolvable);
        resetIpv6Support(): void;
        get ipv6SupportInput(): boolean | cdktn.IResolvable | undefined;
        private _securityGroupReferencingSupport?;
        get securityGroupReferencingSupport(): boolean | cdktn.IResolvable;
        set securityGroupReferencingSupport(value: boolean | cdktn.IResolvable);
        resetSecurityGroupReferencingSupport(): void;
        get securityGroupReferencingSupportInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_vpc_attachment#create AwsVpcAttachment#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_vpc_attachment#delete AwsVpcAttachment#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_vpc_attachment#update AwsVpcAttachment#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
