import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDeviceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_device#description AwsDevice#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_device#global_network_id AwsDevice#global_network_id}
    */
    readonly globalNetworkId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_device#id AwsDevice#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_device#model AwsDevice#model}
    */
    readonly model?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_device#serial_number AwsDevice#serial_number}
    */
    readonly serialNumber?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_device#site_id AwsDevice#site_id}
    */
    readonly siteId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_device#tags AwsDevice#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_device#tags_all AwsDevice#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_device#type AwsDevice#type}
    */
    readonly type?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_device#vendor AwsDevice#vendor}
    */
    readonly vendor?: string;
    /**
    * aws_location block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_device#aws_location AwsDevice#aws_location}
    */
    readonly awsLocation?: AwsDevice.AwsLocationProperty;
    /**
    * location block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_device#location AwsDevice#location}
    */
    readonly location?: AwsDevice.LocationProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_device#timeouts AwsDevice#timeouts}
    */
    readonly timeouts?: AwsDevice.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_device aws_networkmanager_device}
*/
export declare class AwsDevice extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_networkmanager_device";
    /**
    * Generates CDKTN code for importing a AwsDevice resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDevice to import
    * @param importFromId The id of the existing AwsDevice that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_device#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDevice to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_device aws_networkmanager_device} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDeviceConfig
    */
    constructor(scope: Construct, id: string, config: AwsDeviceConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _globalNetworkId?;
    get globalNetworkId(): string;
    set globalNetworkId(value: string);
    get globalNetworkIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _model?;
    get model(): string;
    set model(value: string);
    resetModel(): void;
    get modelInput(): string | undefined;
    private _serialNumber?;
    get serialNumber(): string;
    set serialNumber(value: string);
    resetSerialNumber(): void;
    get serialNumberInput(): string | undefined;
    private _siteId?;
    get siteId(): string;
    set siteId(value: string);
    resetSiteId(): void;
    get siteIdInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _vendor?;
    get vendor(): string;
    set vendor(value: string);
    resetVendor(): void;
    get vendorInput(): string | undefined;
    private _awsLocation;
    get awsLocation(): AwsDevice.AwsLocationPropertyOutputReference;
    putAwsLocation(value: AwsDevice.AwsLocationProperty): void;
    resetAwsLocation(): void;
    get awsLocationInput(): AwsDevice.AwsLocationProperty | undefined;
    private _location;
    get location(): AwsDevice.LocationPropertyOutputReference;
    putLocation(value: AwsDevice.LocationProperty): void;
    resetLocation(): void;
    get locationInput(): AwsDevice.LocationProperty | undefined;
    private _timeouts;
    get timeouts(): AwsDevice.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsDevice.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsDevice.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsDeviceAwsLocationPropertyToTerraform(struct?: AwsDevice.AwsLocationPropertyOutputReference | AwsDevice.AwsLocationProperty): any;
export declare function awsDeviceAwsLocationPropertyToHclTerraform(struct?: AwsDevice.AwsLocationPropertyOutputReference | AwsDevice.AwsLocationProperty): any;
export declare function awsDeviceLocationPropertyToTerraform(struct?: AwsDevice.LocationPropertyOutputReference | AwsDevice.LocationProperty): any;
export declare function awsDeviceLocationPropertyToHclTerraform(struct?: AwsDevice.LocationPropertyOutputReference | AwsDevice.LocationProperty): any;
export declare function awsDeviceTimeoutsPropertyToTerraform(struct?: AwsDevice.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsDeviceTimeoutsPropertyToHclTerraform(struct?: AwsDevice.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsDevice {
    interface AwsLocationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_device#subnet_arn AwsDevice#subnet_arn}
        */
        readonly subnetArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_device#zone AwsDevice#zone}
        */
        readonly zone?: string;
    }
    class AwsLocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AwsLocationProperty | undefined;
        set internalValue(value: AwsLocationProperty | undefined);
        private _subnetArn?;
        get subnetArn(): string;
        set subnetArn(value: string);
        resetSubnetArn(): void;
        get subnetArnInput(): string | undefined;
        private _zone?;
        get zone(): string;
        set zone(value: string);
        resetZone(): void;
        get zoneInput(): string | undefined;
    }
    interface LocationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_device#address AwsDevice#address}
        */
        readonly address?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_device#latitude AwsDevice#latitude}
        */
        readonly latitude?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_device#longitude AwsDevice#longitude}
        */
        readonly longitude?: string;
    }
    class LocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LocationProperty | undefined;
        set internalValue(value: LocationProperty | undefined);
        private _address?;
        get address(): string;
        set address(value: string);
        resetAddress(): void;
        get addressInput(): string | undefined;
        private _latitude?;
        get latitude(): string;
        set latitude(value: string);
        resetLatitude(): void;
        get latitudeInput(): string | undefined;
        private _longitude?;
        get longitude(): string;
        set longitude(value: string);
        resetLongitude(): void;
        get longitudeInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_device#create AwsDevice#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_device#delete AwsDevice#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_device#update AwsDevice#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
