import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAttachmentRoutingPolicyLabelConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_attachment_routing_policy_label#attachment_id AwsAttachmentRoutingPolicyLabel#attachment_id}
    */
    readonly attachmentId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_attachment_routing_policy_label#core_network_id AwsAttachmentRoutingPolicyLabel#core_network_id}
    */
    readonly coreNetworkId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_attachment_routing_policy_label#routing_policy_label AwsAttachmentRoutingPolicyLabel#routing_policy_label}
    */
    readonly routingPolicyLabel: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_attachment_routing_policy_label aws_networkmanager_attachment_routing_policy_label}
*/
export declare class AwsAttachmentRoutingPolicyLabel extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_networkmanager_attachment_routing_policy_label";
    /**
    * Generates CDKTN code for importing a AwsAttachmentRoutingPolicyLabel resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsAttachmentRoutingPolicyLabel to import
    * @param importFromId The id of the existing AwsAttachmentRoutingPolicyLabel that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_attachment_routing_policy_label#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsAttachmentRoutingPolicyLabel to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_attachment_routing_policy_label aws_networkmanager_attachment_routing_policy_label} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAttachmentRoutingPolicyLabelConfig
    */
    constructor(scope: Construct, id: string, config: AwsAttachmentRoutingPolicyLabelConfig);
    private _attachmentId?;
    get attachmentId(): string;
    set attachmentId(value: string);
    get attachmentIdInput(): string | undefined;
    private _coreNetworkId?;
    get coreNetworkId(): string;
    set coreNetworkId(value: string);
    get coreNetworkIdInput(): string | undefined;
    private _routingPolicyLabel?;
    get routingPolicyLabel(): string;
    set routingPolicyLabel(value: string);
    get routingPolicyLabelInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
