import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAttachmentAccepterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_attachment_accepter#attachment_id AwsAttachmentAccepter#attachment_id}
    */
    readonly attachmentId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_attachment_accepter#attachment_type AwsAttachmentAccepter#attachment_type}
    */
    readonly attachmentType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_attachment_accepter#id AwsAttachmentAccepter#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_attachment_accepter#timeouts AwsAttachmentAccepter#timeouts}
    */
    readonly timeouts?: AwsAttachmentAccepter.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_attachment_accepter aws_networkmanager_attachment_accepter}
*/
export declare class AwsAttachmentAccepter extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_networkmanager_attachment_accepter";
    /**
    * Generates CDKTN code for importing a AwsAttachmentAccepter resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsAttachmentAccepter to import
    * @param importFromId The id of the existing AwsAttachmentAccepter that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_attachment_accepter#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsAttachmentAccepter to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_attachment_accepter aws_networkmanager_attachment_accepter} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAttachmentAccepterConfig
    */
    constructor(scope: Construct, id: string, config: AwsAttachmentAccepterConfig);
    private _attachmentId?;
    get attachmentId(): string;
    set attachmentId(value: string);
    get attachmentIdInput(): string | undefined;
    get attachmentPolicyRuleNumber(): number;
    private _attachmentType?;
    get attachmentType(): string;
    set attachmentType(value: string);
    get attachmentTypeInput(): string | undefined;
    get coreNetworkArn(): string;
    get coreNetworkId(): string;
    get edgeLocation(): string;
    get edgeLocations(): string[];
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get ownerAccountId(): string;
    get resourceArn(): string;
    get segmentName(): string;
    get state(): string;
    private _timeouts;
    get timeouts(): AwsAttachmentAccepter.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsAttachmentAccepter.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): AwsAttachmentAccepter.TimeoutsProperty | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsAttachmentAccepterTimeoutsPropertyToTerraform(struct?: AwsAttachmentAccepter.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsAttachmentAccepterTimeoutsPropertyToHclTerraform(struct?: AwsAttachmentAccepter.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsAttachmentAccepter {
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_attachment_accepter#create AwsAttachmentAccepter#create}
        */
        readonly create?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
    }
}
