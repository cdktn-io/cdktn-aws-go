import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDatasyncLocationAzureBlobConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_azure_blob#access_tier AwsDatasyncLocationAzureBlob#access_tier}
    */
    readonly accessTier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_azure_blob#agent_arns AwsDatasyncLocationAzureBlob#agent_arns}
    */
    readonly agentArns: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_azure_blob#authentication_type AwsDatasyncLocationAzureBlob#authentication_type}
    */
    readonly authenticationType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_azure_blob#blob_type AwsDatasyncLocationAzureBlob#blob_type}
    */
    readonly blobType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_azure_blob#container_url AwsDatasyncLocationAzureBlob#container_url}
    */
    readonly containerUrl: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_azure_blob#id AwsDatasyncLocationAzureBlob#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_azure_blob#region AwsDatasyncLocationAzureBlob#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_azure_blob#subdirectory AwsDatasyncLocationAzureBlob#subdirectory}
    */
    readonly subdirectory?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_azure_blob#tags AwsDatasyncLocationAzureBlob#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_azure_blob#tags_all AwsDatasyncLocationAzureBlob#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * sas_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_azure_blob#sas_configuration AwsDatasyncLocationAzureBlob#sas_configuration}
    */
    readonly sasConfiguration?: AwsDatasyncLocationAzureBlob.SasConfigurationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_azure_blob aws_datasync_location_azure_blob}
*/
export declare class AwsDatasyncLocationAzureBlob extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_datasync_location_azure_blob";
    /**
    * Generates CDKTN code for importing a AwsDatasyncLocationAzureBlob resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDatasyncLocationAzureBlob to import
    * @param importFromId The id of the existing AwsDatasyncLocationAzureBlob that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_azure_blob#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDatasyncLocationAzureBlob to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_azure_blob aws_datasync_location_azure_blob} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDatasyncLocationAzureBlobConfig
    */
    constructor(scope: Construct, id: string, config: AwsDatasyncLocationAzureBlobConfig);
    private _accessTier?;
    get accessTier(): string;
    set accessTier(value: string);
    resetAccessTier(): void;
    get accessTierInput(): string | undefined;
    private _agentArns?;
    get agentArns(): string[];
    set agentArns(value: string[]);
    get agentArnsInput(): string[] | undefined;
    get arn(): string;
    private _authenticationType?;
    get authenticationType(): string;
    set authenticationType(value: string);
    get authenticationTypeInput(): string | undefined;
    private _blobType?;
    get blobType(): string;
    set blobType(value: string);
    resetBlobType(): void;
    get blobTypeInput(): string | undefined;
    private _containerUrl?;
    get containerUrl(): string;
    set containerUrl(value: string);
    get containerUrlInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _subdirectory?;
    get subdirectory(): string;
    set subdirectory(value: string);
    resetSubdirectory(): void;
    get subdirectoryInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get uri(): string;
    private _sasConfiguration;
    get sasConfiguration(): AwsDatasyncLocationAzureBlob.SasConfigurationPropertyOutputReference;
    putSasConfiguration(value: AwsDatasyncLocationAzureBlob.SasConfigurationProperty): void;
    resetSasConfiguration(): void;
    get sasConfigurationInput(): AwsDatasyncLocationAzureBlob.SasConfigurationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsDatasyncLocationAzureBlobSasConfigurationPropertyToTerraform(struct?: AwsDatasyncLocationAzureBlob.SasConfigurationPropertyOutputReference | AwsDatasyncLocationAzureBlob.SasConfigurationProperty): any;
export declare function awsDatasyncLocationAzureBlobSasConfigurationPropertyToHclTerraform(struct?: AwsDatasyncLocationAzureBlob.SasConfigurationPropertyOutputReference | AwsDatasyncLocationAzureBlob.SasConfigurationProperty): any;
export declare namespace AwsDatasyncLocationAzureBlob {
    interface SasConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_azure_blob#token AwsDatasyncLocationAzureBlob#token}
        */
        readonly token: string;
    }
    class SasConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SasConfigurationProperty | undefined;
        set internalValue(value: SasConfigurationProperty | undefined);
        private _token?;
        get token(): string;
        set token(value: string);
        get tokenInput(): string | undefined;
    }
}
