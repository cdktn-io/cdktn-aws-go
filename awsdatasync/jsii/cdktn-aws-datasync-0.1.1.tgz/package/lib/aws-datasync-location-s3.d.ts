import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDatasyncLocationS3Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_s3#agent_arns AwsDatasyncLocationS3#agent_arns}
    */
    readonly agentArns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_s3#id AwsDatasyncLocationS3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_s3#region AwsDatasyncLocationS3#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_s3#s3_bucket_arn AwsDatasyncLocationS3#s3_bucket_arn}
    */
    readonly s3BucketArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_s3#s3_storage_class AwsDatasyncLocationS3#s3_storage_class}
    */
    readonly s3StorageClass?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_s3#subdirectory AwsDatasyncLocationS3#subdirectory}
    */
    readonly subdirectory: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_s3#tags AwsDatasyncLocationS3#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_s3#tags_all AwsDatasyncLocationS3#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * s3_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_s3#s3_config AwsDatasyncLocationS3#s3_config}
    */
    readonly s3Config: AwsDatasyncLocationS3.S3ConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_s3 aws_datasync_location_s3}
*/
export declare class AwsDatasyncLocationS3 extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_datasync_location_s3";
    /**
    * Generates CDKTN code for importing a AwsDatasyncLocationS3 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDatasyncLocationS3 to import
    * @param importFromId The id of the existing AwsDatasyncLocationS3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_s3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDatasyncLocationS3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_s3 aws_datasync_location_s3} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDatasyncLocationS3Config
    */
    constructor(scope: Construct, id: string, config: AwsDatasyncLocationS3Config);
    private _agentArns?;
    get agentArns(): string[];
    set agentArns(value: string[]);
    resetAgentArns(): void;
    get agentArnsInput(): string[] | undefined;
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _s3BucketArn?;
    get s3BucketArn(): string;
    set s3BucketArn(value: string);
    get s3BucketArnInput(): string | undefined;
    private _s3StorageClass?;
    get s3StorageClass(): string;
    set s3StorageClass(value: string);
    resetS3StorageClass(): void;
    get s3StorageClassInput(): string | undefined;
    private _subdirectory?;
    get subdirectory(): string;
    set subdirectory(value: string);
    get subdirectoryInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get uri(): string;
    private _s3Config;
    get s3Config(): AwsDatasyncLocationS3.S3ConfigPropertyOutputReference;
    putS3Config(value: AwsDatasyncLocationS3.S3ConfigProperty): void;
    get s3ConfigInput(): AwsDatasyncLocationS3.S3ConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsDatasyncLocationS3S3ConfigPropertyToTerraform(struct?: AwsDatasyncLocationS3.S3ConfigPropertyOutputReference | AwsDatasyncLocationS3.S3ConfigProperty): any;
export declare function awsDatasyncLocationS3S3ConfigPropertyToHclTerraform(struct?: AwsDatasyncLocationS3.S3ConfigPropertyOutputReference | AwsDatasyncLocationS3.S3ConfigProperty): any;
export declare namespace AwsDatasyncLocationS3 {
    interface S3ConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_s3#bucket_access_role_arn AwsDatasyncLocationS3#bucket_access_role_arn}
        */
        readonly bucketAccessRoleArn: string;
    }
    class S3ConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3ConfigProperty | undefined;
        set internalValue(value: S3ConfigProperty | undefined);
        private _bucketAccessRoleArn?;
        get bucketAccessRoleArn(): string;
        set bucketAccessRoleArn(value: string);
        get bucketAccessRoleArnInput(): string | undefined;
    }
}
