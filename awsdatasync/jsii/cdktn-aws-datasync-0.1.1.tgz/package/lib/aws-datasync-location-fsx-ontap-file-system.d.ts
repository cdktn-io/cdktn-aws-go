import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDatasyncLocationFsxOntapFileSystemConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_fsx_ontap_file_system#id AwsDatasyncLocationFsxOntapFileSystem#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_fsx_ontap_file_system#region AwsDatasyncLocationFsxOntapFileSystem#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_fsx_ontap_file_system#security_group_arns AwsDatasyncLocationFsxOntapFileSystem#security_group_arns}
    */
    readonly securityGroupArns: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_fsx_ontap_file_system#storage_virtual_machine_arn AwsDatasyncLocationFsxOntapFileSystem#storage_virtual_machine_arn}
    */
    readonly storageVirtualMachineArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_fsx_ontap_file_system#subdirectory AwsDatasyncLocationFsxOntapFileSystem#subdirectory}
    */
    readonly subdirectory?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_fsx_ontap_file_system#tags AwsDatasyncLocationFsxOntapFileSystem#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_fsx_ontap_file_system#tags_all AwsDatasyncLocationFsxOntapFileSystem#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * protocol block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_fsx_ontap_file_system#protocol AwsDatasyncLocationFsxOntapFileSystem#protocol}
    */
    readonly protocol: AwsDatasyncLocationFsxOntapFileSystem.ProtocolProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_fsx_ontap_file_system aws_datasync_location_fsx_ontap_file_system}
*/
export declare class AwsDatasyncLocationFsxOntapFileSystem extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_datasync_location_fsx_ontap_file_system";
    /**
    * Generates CDKTN code for importing a AwsDatasyncLocationFsxOntapFileSystem resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDatasyncLocationFsxOntapFileSystem to import
    * @param importFromId The id of the existing AwsDatasyncLocationFsxOntapFileSystem that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_fsx_ontap_file_system#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDatasyncLocationFsxOntapFileSystem to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_fsx_ontap_file_system aws_datasync_location_fsx_ontap_file_system} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDatasyncLocationFsxOntapFileSystemConfig
    */
    constructor(scope: Construct, id: string, config: AwsDatasyncLocationFsxOntapFileSystemConfig);
    get arn(): string;
    get creationTime(): string;
    get fsxFilesystemArn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _securityGroupArns?;
    get securityGroupArns(): string[];
    set securityGroupArns(value: string[]);
    get securityGroupArnsInput(): string[] | undefined;
    private _storageVirtualMachineArn?;
    get storageVirtualMachineArn(): string;
    set storageVirtualMachineArn(value: string);
    get storageVirtualMachineArnInput(): string | undefined;
    private _subdirectory?;
    get subdirectory(): string;
    set subdirectory(value: string);
    resetSubdirectory(): void;
    get subdirectoryInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get uri(): string;
    private _protocol;
    get protocol(): AwsDatasyncLocationFsxOntapFileSystem.ProtocolPropertyOutputReference;
    putProtocol(value: AwsDatasyncLocationFsxOntapFileSystem.ProtocolProperty): void;
    get protocolInput(): AwsDatasyncLocationFsxOntapFileSystem.ProtocolProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsDatasyncLocationFsxOntapFileSystemProtocolNfsMountOptionsPropertyToTerraform(struct?: AwsDatasyncLocationFsxOntapFileSystem.ProtocolNfsMountOptionsPropertyOutputReference | AwsDatasyncLocationFsxOntapFileSystem.ProtocolNfsMountOptionsProperty): any;
export declare function awsDatasyncLocationFsxOntapFileSystemProtocolNfsMountOptionsPropertyToHclTerraform(struct?: AwsDatasyncLocationFsxOntapFileSystem.ProtocolNfsMountOptionsPropertyOutputReference | AwsDatasyncLocationFsxOntapFileSystem.ProtocolNfsMountOptionsProperty): any;
export declare function awsDatasyncLocationFsxOntapFileSystemNfsPropertyToTerraform(struct?: AwsDatasyncLocationFsxOntapFileSystem.NfsPropertyOutputReference | AwsDatasyncLocationFsxOntapFileSystem.NfsProperty): any;
export declare function awsDatasyncLocationFsxOntapFileSystemNfsPropertyToHclTerraform(struct?: AwsDatasyncLocationFsxOntapFileSystem.NfsPropertyOutputReference | AwsDatasyncLocationFsxOntapFileSystem.NfsProperty): any;
export declare function awsDatasyncLocationFsxOntapFileSystemProtocolSmbMountOptionsPropertyToTerraform(struct?: AwsDatasyncLocationFsxOntapFileSystem.ProtocolSmbMountOptionsPropertyOutputReference | AwsDatasyncLocationFsxOntapFileSystem.ProtocolSmbMountOptionsProperty): any;
export declare function awsDatasyncLocationFsxOntapFileSystemProtocolSmbMountOptionsPropertyToHclTerraform(struct?: AwsDatasyncLocationFsxOntapFileSystem.ProtocolSmbMountOptionsPropertyOutputReference | AwsDatasyncLocationFsxOntapFileSystem.ProtocolSmbMountOptionsProperty): any;
export declare function awsDatasyncLocationFsxOntapFileSystemSmbPropertyToTerraform(struct?: AwsDatasyncLocationFsxOntapFileSystem.SmbPropertyOutputReference | AwsDatasyncLocationFsxOntapFileSystem.SmbProperty): any;
export declare function awsDatasyncLocationFsxOntapFileSystemSmbPropertyToHclTerraform(struct?: AwsDatasyncLocationFsxOntapFileSystem.SmbPropertyOutputReference | AwsDatasyncLocationFsxOntapFileSystem.SmbProperty): any;
export declare function awsDatasyncLocationFsxOntapFileSystemProtocolPropertyToTerraform(struct?: AwsDatasyncLocationFsxOntapFileSystem.ProtocolPropertyOutputReference | AwsDatasyncLocationFsxOntapFileSystem.ProtocolProperty): any;
export declare function awsDatasyncLocationFsxOntapFileSystemProtocolPropertyToHclTerraform(struct?: AwsDatasyncLocationFsxOntapFileSystem.ProtocolPropertyOutputReference | AwsDatasyncLocationFsxOntapFileSystem.ProtocolProperty): any;
export declare namespace AwsDatasyncLocationFsxOntapFileSystem {
    interface ProtocolNfsMountOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_fsx_ontap_file_system#version AwsDatasyncLocationFsxOntapFileSystem#version}
        */
        readonly version?: string;
    }
    class ProtocolNfsMountOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ProtocolNfsMountOptionsProperty | undefined;
        set internalValue(value: ProtocolNfsMountOptionsProperty | undefined);
        private _version?;
        get version(): string;
        set version(value: string);
        resetVersion(): void;
        get versionInput(): string | undefined;
    }
    interface NfsProperty {
        /**
        * mount_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_fsx_ontap_file_system#mount_options AwsDatasyncLocationFsxOntapFileSystem#mount_options}
        */
        readonly mountOptions: ProtocolNfsMountOptionsProperty;
    }
    class NfsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NfsProperty | undefined;
        set internalValue(value: NfsProperty | undefined);
        private _mountOptions;
        get mountOptions(): ProtocolNfsMountOptionsPropertyOutputReference;
        putMountOptions(value: ProtocolNfsMountOptionsProperty): void;
        get mountOptionsInput(): ProtocolNfsMountOptionsProperty | undefined;
    }
    interface ProtocolSmbMountOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_fsx_ontap_file_system#version AwsDatasyncLocationFsxOntapFileSystem#version}
        */
        readonly version?: string;
    }
    class ProtocolSmbMountOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ProtocolSmbMountOptionsProperty | undefined;
        set internalValue(value: ProtocolSmbMountOptionsProperty | undefined);
        private _version?;
        get version(): string;
        set version(value: string);
        resetVersion(): void;
        get versionInput(): string | undefined;
    }
    interface SmbProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_fsx_ontap_file_system#domain AwsDatasyncLocationFsxOntapFileSystem#domain}
        */
        readonly domain?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_fsx_ontap_file_system#password AwsDatasyncLocationFsxOntapFileSystem#password}
        */
        readonly password: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_fsx_ontap_file_system#user AwsDatasyncLocationFsxOntapFileSystem#user}
        */
        readonly user: string;
        /**
        * mount_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_fsx_ontap_file_system#mount_options AwsDatasyncLocationFsxOntapFileSystem#mount_options}
        */
        readonly mountOptions: ProtocolSmbMountOptionsProperty;
    }
    class SmbPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SmbProperty | undefined;
        set internalValue(value: SmbProperty | undefined);
        private _domain?;
        get domain(): string;
        set domain(value: string);
        resetDomain(): void;
        get domainInput(): string | undefined;
        private _password?;
        get password(): string;
        set password(value: string);
        get passwordInput(): string | undefined;
        private _user?;
        get user(): string;
        set user(value: string);
        get userInput(): string | undefined;
        private _mountOptions;
        get mountOptions(): ProtocolSmbMountOptionsPropertyOutputReference;
        putMountOptions(value: ProtocolSmbMountOptionsProperty): void;
        get mountOptionsInput(): ProtocolSmbMountOptionsProperty | undefined;
    }
    interface ProtocolProperty {
        /**
        * nfs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_fsx_ontap_file_system#nfs AwsDatasyncLocationFsxOntapFileSystem#nfs}
        */
        readonly nfs?: NfsProperty;
        /**
        * smb block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_location_fsx_ontap_file_system#smb AwsDatasyncLocationFsxOntapFileSystem#smb}
        */
        readonly smb?: SmbProperty;
    }
    class ProtocolPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ProtocolProperty | undefined;
        set internalValue(value: ProtocolProperty | undefined);
        private _nfs;
        get nfs(): NfsPropertyOutputReference;
        putNfs(value: NfsProperty): void;
        resetNfs(): void;
        get nfsInput(): NfsProperty | undefined;
        private _smb;
        get smb(): SmbPropertyOutputReference;
        putSmb(value: SmbProperty): void;
        resetSmb(): void;
        get smbInput(): SmbProperty | undefined;
    }
}
