import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfTaskConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task#cloudwatch_log_group_arn TfTask#cloudwatch_log_group_arn}
    */
    readonly cloudwatchLogGroupArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task#destination_location_arn TfTask#destination_location_arn}
    */
    readonly destinationLocationArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task#id TfTask#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task#name TfTask#name}
    */
    readonly name?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task#region TfTask#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task#source_location_arn TfTask#source_location_arn}
    */
    readonly sourceLocationArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task#tags TfTask#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task#tags_all TfTask#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task#task_mode TfTask#task_mode}
    */
    readonly taskMode?: string;
    /**
    * excludes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task#excludes TfTask#excludes}
    */
    readonly excludes?: TfTask.ExcludesProperty;
    /**
    * includes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task#includes TfTask#includes}
    */
    readonly includes?: TfTask.IncludesProperty;
    /**
    * options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task#options TfTask#options}
    */
    readonly options?: TfTask.OptionsProperty;
    /**
    * schedule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task#schedule TfTask#schedule}
    */
    readonly schedule?: TfTask.ScheduleProperty;
    /**
    * task_report_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task#task_report_config TfTask#task_report_config}
    */
    readonly taskReportConfig?: TfTask.TaskReportConfigProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task#timeouts TfTask#timeouts}
    */
    readonly timeouts?: TfTask.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task aws_datasync_task}
*/
export declare class TfTask extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_datasync_task";
    /**
    * Generates CDKTN code for importing a TfTask resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfTask to import
    * @param importFromId The id of the existing TfTask that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfTask to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task aws_datasync_task} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfTaskConfig
    */
    constructor(scope: Construct, id: string, config: TfTaskConfig);
    get arn(): string;
    private _cloudwatchLogGroupArn?;
    get cloudwatchLogGroupArn(): string;
    set cloudwatchLogGroupArn(value: string);
    resetCloudwatchLogGroupArn(): void;
    get cloudwatchLogGroupArnInput(): string | undefined;
    private _destinationLocationArn?;
    get destinationLocationArn(): string;
    set destinationLocationArn(value: string);
    get destinationLocationArnInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _sourceLocationArn?;
    get sourceLocationArn(): string;
    set sourceLocationArn(value: string);
    get sourceLocationArnInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _taskMode?;
    get taskMode(): string;
    set taskMode(value: string);
    resetTaskMode(): void;
    get taskModeInput(): string | undefined;
    private _excludes;
    get excludes(): TfTask.ExcludesPropertyOutputReference;
    putExcludes(value: TfTask.ExcludesProperty): void;
    resetExcludes(): void;
    get excludesInput(): TfTask.ExcludesProperty | undefined;
    private _includes;
    get includes(): TfTask.IncludesPropertyOutputReference;
    putIncludes(value: TfTask.IncludesProperty): void;
    resetIncludes(): void;
    get includesInput(): TfTask.IncludesProperty | undefined;
    private _options;
    get options(): TfTask.OptionsPropertyOutputReference;
    putOptions(value: TfTask.OptionsProperty): void;
    resetOptions(): void;
    get optionsInput(): TfTask.OptionsProperty | undefined;
    private _schedule;
    get schedule(): TfTask.SchedulePropertyOutputReference;
    putSchedule(value: TfTask.ScheduleProperty): void;
    resetSchedule(): void;
    get scheduleInput(): TfTask.ScheduleProperty | undefined;
    private _taskReportConfig;
    get taskReportConfig(): TfTask.TaskReportConfigPropertyOutputReference;
    putTaskReportConfig(value: TfTask.TaskReportConfigProperty): void;
    resetTaskReportConfig(): void;
    get taskReportConfigInput(): TfTask.TaskReportConfigProperty | undefined;
    private _timeouts;
    get timeouts(): TfTask.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfTask.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfTask.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfTaskExcludesPropertyToTerraform(struct?: TfTask.ExcludesPropertyOutputReference | TfTask.ExcludesProperty): any;
export declare function tfTaskExcludesPropertyToHclTerraform(struct?: TfTask.ExcludesPropertyOutputReference | TfTask.ExcludesProperty): any;
export declare function tfTaskIncludesPropertyToTerraform(struct?: TfTask.IncludesPropertyOutputReference | TfTask.IncludesProperty): any;
export declare function tfTaskIncludesPropertyToHclTerraform(struct?: TfTask.IncludesPropertyOutputReference | TfTask.IncludesProperty): any;
export declare function tfTaskOptionsPropertyToTerraform(struct?: TfTask.OptionsPropertyOutputReference | TfTask.OptionsProperty): any;
export declare function tfTaskOptionsPropertyToHclTerraform(struct?: TfTask.OptionsPropertyOutputReference | TfTask.OptionsProperty): any;
export declare function tfTaskSchedulePropertyToTerraform(struct?: TfTask.SchedulePropertyOutputReference | TfTask.ScheduleProperty): any;
export declare function tfTaskSchedulePropertyToHclTerraform(struct?: TfTask.SchedulePropertyOutputReference | TfTask.ScheduleProperty): any;
export declare function tfTaskReportOverridesPropertyToTerraform(struct?: TfTask.ReportOverridesPropertyOutputReference | TfTask.ReportOverridesProperty): any;
export declare function tfTaskReportOverridesPropertyToHclTerraform(struct?: TfTask.ReportOverridesPropertyOutputReference | TfTask.ReportOverridesProperty): any;
export declare function tfTaskS3DestinationPropertyToTerraform(struct?: TfTask.S3DestinationPropertyOutputReference | TfTask.S3DestinationProperty): any;
export declare function tfTaskS3DestinationPropertyToHclTerraform(struct?: TfTask.S3DestinationPropertyOutputReference | TfTask.S3DestinationProperty): any;
export declare function tfTaskTaskReportConfigPropertyToTerraform(struct?: TfTask.TaskReportConfigPropertyOutputReference | TfTask.TaskReportConfigProperty): any;
export declare function tfTaskTaskReportConfigPropertyToHclTerraform(struct?: TfTask.TaskReportConfigPropertyOutputReference | TfTask.TaskReportConfigProperty): any;
export declare function tfTaskTimeoutsPropertyToTerraform(struct?: TfTask.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfTaskTimeoutsPropertyToHclTerraform(struct?: TfTask.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfTask {
    interface ExcludesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task#filter_type TfTask#filter_type}
        */
        readonly filterType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task#value TfTask#value}
        */
        readonly value?: string;
    }
    class ExcludesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ExcludesProperty | undefined;
        set internalValue(value: ExcludesProperty | undefined);
        private _filterType?;
        get filterType(): string;
        set filterType(value: string);
        resetFilterType(): void;
        get filterTypeInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        resetValue(): void;
        get valueInput(): string | undefined;
    }
    interface IncludesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task#filter_type TfTask#filter_type}
        */
        readonly filterType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task#value TfTask#value}
        */
        readonly value?: string;
    }
    class IncludesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IncludesProperty | undefined;
        set internalValue(value: IncludesProperty | undefined);
        private _filterType?;
        get filterType(): string;
        set filterType(value: string);
        resetFilterType(): void;
        get filterTypeInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        resetValue(): void;
        get valueInput(): string | undefined;
    }
    interface OptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task#atime TfTask#atime}
        */
        readonly atime?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task#bytes_per_second TfTask#bytes_per_second}
        */
        readonly bytesPerSecond?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task#gid TfTask#gid}
        */
        readonly gid?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task#log_level TfTask#log_level}
        */
        readonly logLevel?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task#mtime TfTask#mtime}
        */
        readonly mtime?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task#object_tags TfTask#object_tags}
        */
        readonly objectTags?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task#overwrite_mode TfTask#overwrite_mode}
        */
        readonly overwriteMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task#posix_permissions TfTask#posix_permissions}
        */
        readonly posixPermissions?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task#preserve_deleted_files TfTask#preserve_deleted_files}
        */
        readonly preserveDeletedFiles?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task#preserve_devices TfTask#preserve_devices}
        */
        readonly preserveDevices?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task#security_descriptor_copy_flags TfTask#security_descriptor_copy_flags}
        */
        readonly securityDescriptorCopyFlags?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task#task_queueing TfTask#task_queueing}
        */
        readonly taskQueueing?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task#transfer_mode TfTask#transfer_mode}
        */
        readonly transferMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task#uid TfTask#uid}
        */
        readonly uid?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task#verify_mode TfTask#verify_mode}
        */
        readonly verifyMode?: string;
    }
    class OptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OptionsProperty | undefined;
        set internalValue(value: OptionsProperty | undefined);
        private _atime?;
        get atime(): string;
        set atime(value: string);
        resetAtime(): void;
        get atimeInput(): string | undefined;
        private _bytesPerSecond?;
        get bytesPerSecond(): number;
        set bytesPerSecond(value: number);
        resetBytesPerSecond(): void;
        get bytesPerSecondInput(): number | undefined;
        private _gid?;
        get gid(): string;
        set gid(value: string);
        resetGid(): void;
        get gidInput(): string | undefined;
        private _logLevel?;
        get logLevel(): string;
        set logLevel(value: string);
        resetLogLevel(): void;
        get logLevelInput(): string | undefined;
        private _mtime?;
        get mtime(): string;
        set mtime(value: string);
        resetMtime(): void;
        get mtimeInput(): string | undefined;
        private _objectTags?;
        get objectTags(): string;
        set objectTags(value: string);
        resetObjectTags(): void;
        get objectTagsInput(): string | undefined;
        private _overwriteMode?;
        get overwriteMode(): string;
        set overwriteMode(value: string);
        resetOverwriteMode(): void;
        get overwriteModeInput(): string | undefined;
        private _posixPermissions?;
        get posixPermissions(): string;
        set posixPermissions(value: string);
        resetPosixPermissions(): void;
        get posixPermissionsInput(): string | undefined;
        private _preserveDeletedFiles?;
        get preserveDeletedFiles(): string;
        set preserveDeletedFiles(value: string);
        resetPreserveDeletedFiles(): void;
        get preserveDeletedFilesInput(): string | undefined;
        private _preserveDevices?;
        get preserveDevices(): string;
        set preserveDevices(value: string);
        resetPreserveDevices(): void;
        get preserveDevicesInput(): string | undefined;
        private _securityDescriptorCopyFlags?;
        get securityDescriptorCopyFlags(): string;
        set securityDescriptorCopyFlags(value: string);
        resetSecurityDescriptorCopyFlags(): void;
        get securityDescriptorCopyFlagsInput(): string | undefined;
        private _taskQueueing?;
        get taskQueueing(): string;
        set taskQueueing(value: string);
        resetTaskQueueing(): void;
        get taskQueueingInput(): string | undefined;
        private _transferMode?;
        get transferMode(): string;
        set transferMode(value: string);
        resetTransferMode(): void;
        get transferModeInput(): string | undefined;
        private _uid?;
        get uid(): string;
        set uid(value: string);
        resetUid(): void;
        get uidInput(): string | undefined;
        private _verifyMode?;
        get verifyMode(): string;
        set verifyMode(value: string);
        resetVerifyMode(): void;
        get verifyModeInput(): string | undefined;
    }
    interface ScheduleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task#schedule_expression TfTask#schedule_expression}
        */
        readonly scheduleExpression: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task#status TfTask#status}
        */
        readonly status?: string;
    }
    class SchedulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ScheduleProperty | undefined;
        set internalValue(value: ScheduleProperty | undefined);
        private _scheduleExpression?;
        get scheduleExpression(): string;
        set scheduleExpression(value: string);
        get scheduleExpressionInput(): string | undefined;
        private _status?;
        get status(): string;
        set status(value: string);
        resetStatus(): void;
        get statusInput(): string | undefined;
    }
    interface ReportOverridesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task#deleted_override TfTask#deleted_override}
        */
        readonly deletedOverride?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task#skipped_override TfTask#skipped_override}
        */
        readonly skippedOverride?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task#transferred_override TfTask#transferred_override}
        */
        readonly transferredOverride?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task#verified_override TfTask#verified_override}
        */
        readonly verifiedOverride?: string;
    }
    class ReportOverridesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ReportOverridesProperty | undefined;
        set internalValue(value: ReportOverridesProperty | undefined);
        private _deletedOverride?;
        get deletedOverride(): string;
        set deletedOverride(value: string);
        resetDeletedOverride(): void;
        get deletedOverrideInput(): string | undefined;
        private _skippedOverride?;
        get skippedOverride(): string;
        set skippedOverride(value: string);
        resetSkippedOverride(): void;
        get skippedOverrideInput(): string | undefined;
        private _transferredOverride?;
        get transferredOverride(): string;
        set transferredOverride(value: string);
        resetTransferredOverride(): void;
        get transferredOverrideInput(): string | undefined;
        private _verifiedOverride?;
        get verifiedOverride(): string;
        set verifiedOverride(value: string);
        resetVerifiedOverride(): void;
        get verifiedOverrideInput(): string | undefined;
    }
    interface S3DestinationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task#bucket_access_role_arn TfTask#bucket_access_role_arn}
        */
        readonly bucketAccessRoleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task#s3_bucket_arn TfTask#s3_bucket_arn}
        */
        readonly s3BucketArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task#subdirectory TfTask#subdirectory}
        */
        readonly subdirectory?: string;
    }
    class S3DestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3DestinationProperty | undefined;
        set internalValue(value: S3DestinationProperty | undefined);
        private _bucketAccessRoleArn?;
        get bucketAccessRoleArn(): string;
        set bucketAccessRoleArn(value: string);
        get bucketAccessRoleArnInput(): string | undefined;
        private _s3BucketArn?;
        get s3BucketArn(): string;
        set s3BucketArn(value: string);
        get s3BucketArnInput(): string | undefined;
        private _subdirectory?;
        get subdirectory(): string;
        set subdirectory(value: string);
        resetSubdirectory(): void;
        get subdirectoryInput(): string | undefined;
    }
    interface TaskReportConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task#output_type TfTask#output_type}
        */
        readonly outputType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task#report_level TfTask#report_level}
        */
        readonly reportLevel?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task#s3_object_versioning TfTask#s3_object_versioning}
        */
        readonly s3ObjectVersioning?: string;
        /**
        * report_overrides block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task#report_overrides TfTask#report_overrides}
        */
        readonly reportOverrides?: ReportOverridesProperty;
        /**
        * s3_destination block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task#s3_destination TfTask#s3_destination}
        */
        readonly s3Destination: S3DestinationProperty;
    }
    class TaskReportConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TaskReportConfigProperty | undefined;
        set internalValue(value: TaskReportConfigProperty | undefined);
        private _outputType?;
        get outputType(): string;
        set outputType(value: string);
        resetOutputType(): void;
        get outputTypeInput(): string | undefined;
        private _reportLevel?;
        get reportLevel(): string;
        set reportLevel(value: string);
        resetReportLevel(): void;
        get reportLevelInput(): string | undefined;
        private _s3ObjectVersioning?;
        get s3ObjectVersioning(): string;
        set s3ObjectVersioning(value: string);
        resetS3ObjectVersioning(): void;
        get s3ObjectVersioningInput(): string | undefined;
        private _reportOverrides;
        get reportOverrides(): ReportOverridesPropertyOutputReference;
        putReportOverrides(value: ReportOverridesProperty): void;
        resetReportOverrides(): void;
        get reportOverridesInput(): ReportOverridesProperty | undefined;
        private _s3Destination;
        get s3Destination(): S3DestinationPropertyOutputReference;
        putS3Destination(value: S3DestinationProperty): void;
        get s3DestinationInput(): S3DestinationProperty | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datasync_task#create TfTask#create}
        */
        readonly create?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
    }
}
