import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfJobDefinitionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/batch_job_definition#arn DataTfJobDefinition#arn}
    */
    readonly arn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/batch_job_definition#name DataTfJobDefinition#name}
    */
    readonly name?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/batch_job_definition#region DataTfJobDefinition#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/batch_job_definition#revision DataTfJobDefinition#revision}
    */
    readonly revision?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/batch_job_definition#status DataTfJobDefinition#status}
    */
    readonly status?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/batch_job_definition aws_batch_job_definition}
*/
export declare class DataTfJobDefinition extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_batch_job_definition";
    /**
    * Generates CDKTN code for importing a DataTfJobDefinition resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfJobDefinition to import
    * @param importFromId The id of the existing DataTfJobDefinition that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/batch_job_definition#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfJobDefinition to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/batch_job_definition aws_batch_job_definition} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfJobDefinitionConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataTfJobDefinitionConfig);
    private _arn?;
    get arn(): string;
    set arn(value: string);
    resetArn(): void;
    get arnInput(): string | undefined;
    get arnPrefix(): string;
    get containerOrchestrationType(): string;
    private _eksProperties;
    get eksProperties(): DataTfJobDefinition.EksPropertiesPropertyList;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _nodeProperties;
    get nodeProperties(): DataTfJobDefinition.NodePropertiesPropertyList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _retryStrategy;
    get retryStrategy(): DataTfJobDefinition.RetryStrategyPropertyList;
    private _revision?;
    get revision(): number;
    set revision(value: number);
    resetRevision(): void;
    get revisionInput(): number | undefined;
    get schedulingPriority(): number;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _tags;
    get tags(): cdktn.StringMap;
    private _timeout;
    get timeout(): DataTfJobDefinition.TimeoutPropertyList;
    get type(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfJobDefinitionEksPropertiesPodPropertiesContainersEnvPropertyToTerraform(struct?: DataTfJobDefinition.EksPropertiesPodPropertiesContainersEnvProperty): any;
export declare function dataTfJobDefinitionEksPropertiesPodPropertiesContainersEnvPropertyToHclTerraform(struct?: DataTfJobDefinition.EksPropertiesPodPropertiesContainersEnvProperty): any;
export declare function dataTfJobDefinitionEksPropertiesPodPropertiesContainersResourcesPropertyToTerraform(struct?: DataTfJobDefinition.EksPropertiesPodPropertiesContainersResourcesProperty): any;
export declare function dataTfJobDefinitionEksPropertiesPodPropertiesContainersResourcesPropertyToHclTerraform(struct?: DataTfJobDefinition.EksPropertiesPodPropertiesContainersResourcesProperty): any;
export declare function dataTfJobDefinitionEksPropertiesPodPropertiesContainersSecurityContextPropertyToTerraform(struct?: DataTfJobDefinition.EksPropertiesPodPropertiesContainersSecurityContextProperty): any;
export declare function dataTfJobDefinitionEksPropertiesPodPropertiesContainersSecurityContextPropertyToHclTerraform(struct?: DataTfJobDefinition.EksPropertiesPodPropertiesContainersSecurityContextProperty): any;
export declare function dataTfJobDefinitionEksPropertiesPodPropertiesContainersVolumeMountsPropertyToTerraform(struct?: DataTfJobDefinition.EksPropertiesPodPropertiesContainersVolumeMountsProperty): any;
export declare function dataTfJobDefinitionEksPropertiesPodPropertiesContainersVolumeMountsPropertyToHclTerraform(struct?: DataTfJobDefinition.EksPropertiesPodPropertiesContainersVolumeMountsProperty): any;
export declare function dataTfJobDefinitionContainersPropertyToTerraform(struct?: DataTfJobDefinition.ContainersProperty): any;
export declare function dataTfJobDefinitionContainersPropertyToHclTerraform(struct?: DataTfJobDefinition.ContainersProperty): any;
export declare function dataTfJobDefinitionImagePullSecretsPropertyToTerraform(struct?: DataTfJobDefinition.ImagePullSecretsProperty): any;
export declare function dataTfJobDefinitionImagePullSecretsPropertyToHclTerraform(struct?: DataTfJobDefinition.ImagePullSecretsProperty): any;
export declare function dataTfJobDefinitionEksPropertiesPodPropertiesInitContainersEnvPropertyToTerraform(struct?: DataTfJobDefinition.EksPropertiesPodPropertiesInitContainersEnvProperty): any;
export declare function dataTfJobDefinitionEksPropertiesPodPropertiesInitContainersEnvPropertyToHclTerraform(struct?: DataTfJobDefinition.EksPropertiesPodPropertiesInitContainersEnvProperty): any;
export declare function dataTfJobDefinitionEksPropertiesPodPropertiesInitContainersResourcesPropertyToTerraform(struct?: DataTfJobDefinition.EksPropertiesPodPropertiesInitContainersResourcesProperty): any;
export declare function dataTfJobDefinitionEksPropertiesPodPropertiesInitContainersResourcesPropertyToHclTerraform(struct?: DataTfJobDefinition.EksPropertiesPodPropertiesInitContainersResourcesProperty): any;
export declare function dataTfJobDefinitionEksPropertiesPodPropertiesInitContainersSecurityContextPropertyToTerraform(struct?: DataTfJobDefinition.EksPropertiesPodPropertiesInitContainersSecurityContextProperty): any;
export declare function dataTfJobDefinitionEksPropertiesPodPropertiesInitContainersSecurityContextPropertyToHclTerraform(struct?: DataTfJobDefinition.EksPropertiesPodPropertiesInitContainersSecurityContextProperty): any;
export declare function dataTfJobDefinitionEksPropertiesPodPropertiesInitContainersVolumeMountsPropertyToTerraform(struct?: DataTfJobDefinition.EksPropertiesPodPropertiesInitContainersVolumeMountsProperty): any;
export declare function dataTfJobDefinitionEksPropertiesPodPropertiesInitContainersVolumeMountsPropertyToHclTerraform(struct?: DataTfJobDefinition.EksPropertiesPodPropertiesInitContainersVolumeMountsProperty): any;
export declare function dataTfJobDefinitionInitContainersPropertyToTerraform(struct?: DataTfJobDefinition.InitContainersProperty): any;
export declare function dataTfJobDefinitionInitContainersPropertyToHclTerraform(struct?: DataTfJobDefinition.InitContainersProperty): any;
export declare function dataTfJobDefinitionMetadataPropertyToTerraform(struct?: DataTfJobDefinition.MetadataProperty): any;
export declare function dataTfJobDefinitionMetadataPropertyToHclTerraform(struct?: DataTfJobDefinition.MetadataProperty): any;
export declare function dataTfJobDefinitionEmptyDirPropertyToTerraform(struct?: DataTfJobDefinition.EmptyDirProperty): any;
export declare function dataTfJobDefinitionEmptyDirPropertyToHclTerraform(struct?: DataTfJobDefinition.EmptyDirProperty): any;
export declare function dataTfJobDefinitionHostPathPropertyToTerraform(struct?: DataTfJobDefinition.HostPathProperty): any;
export declare function dataTfJobDefinitionHostPathPropertyToHclTerraform(struct?: DataTfJobDefinition.HostPathProperty): any;
export declare function dataTfJobDefinitionSecretPropertyToTerraform(struct?: DataTfJobDefinition.SecretProperty): any;
export declare function dataTfJobDefinitionSecretPropertyToHclTerraform(struct?: DataTfJobDefinition.SecretProperty): any;
export declare function dataTfJobDefinitionEksPropertiesPodPropertiesVolumesPropertyToTerraform(struct?: DataTfJobDefinition.EksPropertiesPodPropertiesVolumesProperty): any;
export declare function dataTfJobDefinitionEksPropertiesPodPropertiesVolumesPropertyToHclTerraform(struct?: DataTfJobDefinition.EksPropertiesPodPropertiesVolumesProperty): any;
export declare function dataTfJobDefinitionPodPropertiesPropertyToTerraform(struct?: DataTfJobDefinition.PodPropertiesProperty): any;
export declare function dataTfJobDefinitionPodPropertiesPropertyToHclTerraform(struct?: DataTfJobDefinition.PodPropertiesProperty): any;
export declare function dataTfJobDefinitionEksPropertiesPropertyToTerraform(struct?: DataTfJobDefinition.EksPropertiesProperty): any;
export declare function dataTfJobDefinitionEksPropertiesPropertyToHclTerraform(struct?: DataTfJobDefinition.EksPropertiesProperty): any;
export declare function dataTfJobDefinitionEnvironmentPropertyToTerraform(struct?: DataTfJobDefinition.EnvironmentProperty): any;
export declare function dataTfJobDefinitionEnvironmentPropertyToHclTerraform(struct?: DataTfJobDefinition.EnvironmentProperty): any;
export declare function dataTfJobDefinitionEphemeralStoragePropertyToTerraform(struct?: DataTfJobDefinition.EphemeralStorageProperty): any;
export declare function dataTfJobDefinitionEphemeralStoragePropertyToHclTerraform(struct?: DataTfJobDefinition.EphemeralStorageProperty): any;
export declare function dataTfJobDefinitionFargatePlatformConfigurationPropertyToTerraform(struct?: DataTfJobDefinition.FargatePlatformConfigurationProperty): any;
export declare function dataTfJobDefinitionFargatePlatformConfigurationPropertyToHclTerraform(struct?: DataTfJobDefinition.FargatePlatformConfigurationProperty): any;
export declare function dataTfJobDefinitionDevicesPropertyToTerraform(struct?: DataTfJobDefinition.DevicesProperty): any;
export declare function dataTfJobDefinitionDevicesPropertyToHclTerraform(struct?: DataTfJobDefinition.DevicesProperty): any;
export declare function dataTfJobDefinitionTmpfsPropertyToTerraform(struct?: DataTfJobDefinition.TmpfsProperty): any;
export declare function dataTfJobDefinitionTmpfsPropertyToHclTerraform(struct?: DataTfJobDefinition.TmpfsProperty): any;
export declare function dataTfJobDefinitionLinuxParametersPropertyToTerraform(struct?: DataTfJobDefinition.LinuxParametersProperty): any;
export declare function dataTfJobDefinitionLinuxParametersPropertyToHclTerraform(struct?: DataTfJobDefinition.LinuxParametersProperty): any;
export declare function dataTfJobDefinitionSecretOptionsPropertyToTerraform(struct?: DataTfJobDefinition.SecretOptionsProperty): any;
export declare function dataTfJobDefinitionSecretOptionsPropertyToHclTerraform(struct?: DataTfJobDefinition.SecretOptionsProperty): any;
export declare function dataTfJobDefinitionLogConfigurationPropertyToTerraform(struct?: DataTfJobDefinition.LogConfigurationProperty): any;
export declare function dataTfJobDefinitionLogConfigurationPropertyToHclTerraform(struct?: DataTfJobDefinition.LogConfigurationProperty): any;
export declare function dataTfJobDefinitionMountPointsPropertyToTerraform(struct?: DataTfJobDefinition.MountPointsProperty): any;
export declare function dataTfJobDefinitionMountPointsPropertyToHclTerraform(struct?: DataTfJobDefinition.MountPointsProperty): any;
export declare function dataTfJobDefinitionNetworkConfigurationPropertyToTerraform(struct?: DataTfJobDefinition.NetworkConfigurationProperty): any;
export declare function dataTfJobDefinitionNetworkConfigurationPropertyToHclTerraform(struct?: DataTfJobDefinition.NetworkConfigurationProperty): any;
export declare function dataTfJobDefinitionResourceRequirementsPropertyToTerraform(struct?: DataTfJobDefinition.ResourceRequirementsProperty): any;
export declare function dataTfJobDefinitionResourceRequirementsPropertyToHclTerraform(struct?: DataTfJobDefinition.ResourceRequirementsProperty): any;
export declare function dataTfJobDefinitionRuntimePlatformPropertyToTerraform(struct?: DataTfJobDefinition.RuntimePlatformProperty): any;
export declare function dataTfJobDefinitionRuntimePlatformPropertyToHclTerraform(struct?: DataTfJobDefinition.RuntimePlatformProperty): any;
export declare function dataTfJobDefinitionSecretsPropertyToTerraform(struct?: DataTfJobDefinition.SecretsProperty): any;
export declare function dataTfJobDefinitionSecretsPropertyToHclTerraform(struct?: DataTfJobDefinition.SecretsProperty): any;
export declare function dataTfJobDefinitionUlimitsPropertyToTerraform(struct?: DataTfJobDefinition.UlimitsProperty): any;
export declare function dataTfJobDefinitionUlimitsPropertyToHclTerraform(struct?: DataTfJobDefinition.UlimitsProperty): any;
export declare function dataTfJobDefinitionAuthorizationConfigPropertyToTerraform(struct?: DataTfJobDefinition.AuthorizationConfigProperty): any;
export declare function dataTfJobDefinitionAuthorizationConfigPropertyToHclTerraform(struct?: DataTfJobDefinition.AuthorizationConfigProperty): any;
export declare function dataTfJobDefinitionEfsVolumeConfigurationPropertyToTerraform(struct?: DataTfJobDefinition.EfsVolumeConfigurationProperty): any;
export declare function dataTfJobDefinitionEfsVolumeConfigurationPropertyToHclTerraform(struct?: DataTfJobDefinition.EfsVolumeConfigurationProperty): any;
export declare function dataTfJobDefinitionHostPropertyToTerraform(struct?: DataTfJobDefinition.HostProperty): any;
export declare function dataTfJobDefinitionHostPropertyToHclTerraform(struct?: DataTfJobDefinition.HostProperty): any;
export declare function dataTfJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesPropertyToTerraform(struct?: DataTfJobDefinition.NodePropertiesNodeRangePropertiesContainerVolumesProperty): any;
export declare function dataTfJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesPropertyToHclTerraform(struct?: DataTfJobDefinition.NodePropertiesNodeRangePropertiesContainerVolumesProperty): any;
export declare function dataTfJobDefinitionContainerPropertyToTerraform(struct?: DataTfJobDefinition.ContainerProperty): any;
export declare function dataTfJobDefinitionContainerPropertyToHclTerraform(struct?: DataTfJobDefinition.ContainerProperty): any;
export declare function dataTfJobDefinitionNodeRangePropertiesPropertyToTerraform(struct?: DataTfJobDefinition.NodeRangePropertiesProperty): any;
export declare function dataTfJobDefinitionNodeRangePropertiesPropertyToHclTerraform(struct?: DataTfJobDefinition.NodeRangePropertiesProperty): any;
export declare function dataTfJobDefinitionNodePropertiesPropertyToTerraform(struct?: DataTfJobDefinition.NodePropertiesProperty): any;
export declare function dataTfJobDefinitionNodePropertiesPropertyToHclTerraform(struct?: DataTfJobDefinition.NodePropertiesProperty): any;
export declare function dataTfJobDefinitionEvaluateOnExitPropertyToTerraform(struct?: DataTfJobDefinition.EvaluateOnExitProperty): any;
export declare function dataTfJobDefinitionEvaluateOnExitPropertyToHclTerraform(struct?: DataTfJobDefinition.EvaluateOnExitProperty): any;
export declare function dataTfJobDefinitionRetryStrategyPropertyToTerraform(struct?: DataTfJobDefinition.RetryStrategyProperty): any;
export declare function dataTfJobDefinitionRetryStrategyPropertyToHclTerraform(struct?: DataTfJobDefinition.RetryStrategyProperty): any;
export declare function dataTfJobDefinitionTimeoutPropertyToTerraform(struct?: DataTfJobDefinition.TimeoutProperty): any;
export declare function dataTfJobDefinitionTimeoutPropertyToHclTerraform(struct?: DataTfJobDefinition.TimeoutProperty): any;
export declare namespace DataTfJobDefinition {
    interface EksPropertiesPodPropertiesContainersEnvProperty {
    }
    class EksPropertiesPodPropertiesContainersEnvPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EksPropertiesPodPropertiesContainersEnvProperty | undefined;
        set internalValue(value: EksPropertiesPodPropertiesContainersEnvProperty | undefined);
        get name(): string;
        get value(): string;
    }
    class EksPropertiesPodPropertiesContainersEnvPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EksPropertiesPodPropertiesContainersEnvPropertyOutputReference;
    }
    interface EksPropertiesPodPropertiesContainersResourcesProperty {
    }
    class EksPropertiesPodPropertiesContainersResourcesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EksPropertiesPodPropertiesContainersResourcesProperty | undefined;
        set internalValue(value: EksPropertiesPodPropertiesContainersResourcesProperty | undefined);
        private _limits;
        get limits(): cdktn.StringMap;
        private _requests;
        get requests(): cdktn.StringMap;
    }
    class EksPropertiesPodPropertiesContainersResourcesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EksPropertiesPodPropertiesContainersResourcesPropertyOutputReference;
    }
    interface EksPropertiesPodPropertiesContainersSecurityContextProperty {
    }
    class EksPropertiesPodPropertiesContainersSecurityContextPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EksPropertiesPodPropertiesContainersSecurityContextProperty | undefined;
        set internalValue(value: EksPropertiesPodPropertiesContainersSecurityContextProperty | undefined);
        get allowPrivilegeEscalation(): cdktn.IResolvable;
        get privileged(): cdktn.IResolvable;
        get readOnlyRootFileSystem(): cdktn.IResolvable;
        get runAsGroup(): number;
        get runAsNonRoot(): cdktn.IResolvable;
        get runAsUser(): number;
    }
    class EksPropertiesPodPropertiesContainersSecurityContextPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EksPropertiesPodPropertiesContainersSecurityContextPropertyOutputReference;
    }
    interface EksPropertiesPodPropertiesContainersVolumeMountsProperty {
    }
    class EksPropertiesPodPropertiesContainersVolumeMountsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EksPropertiesPodPropertiesContainersVolumeMountsProperty | undefined;
        set internalValue(value: EksPropertiesPodPropertiesContainersVolumeMountsProperty | undefined);
        get mountPath(): string;
        get name(): string;
        get readOnly(): cdktn.IResolvable;
    }
    class EksPropertiesPodPropertiesContainersVolumeMountsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EksPropertiesPodPropertiesContainersVolumeMountsPropertyOutputReference;
    }
    interface ContainersProperty {
    }
    class ContainersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ContainersProperty | undefined;
        set internalValue(value: ContainersProperty | undefined);
        get args(): string[];
        get command(): string[];
        private _env;
        get env(): EksPropertiesPodPropertiesContainersEnvPropertyList;
        get image(): string;
        get imagePullPolicy(): string;
        get name(): string;
        private _resources;
        get resources(): EksPropertiesPodPropertiesContainersResourcesPropertyList;
        private _securityContext;
        get securityContext(): EksPropertiesPodPropertiesContainersSecurityContextPropertyList;
        private _volumeMounts;
        get volumeMounts(): EksPropertiesPodPropertiesContainersVolumeMountsPropertyList;
    }
    class ContainersPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ContainersPropertyOutputReference;
    }
    interface ImagePullSecretsProperty {
    }
    class ImagePullSecretsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ImagePullSecretsProperty | undefined;
        set internalValue(value: ImagePullSecretsProperty | undefined);
        get name(): string;
    }
    class ImagePullSecretsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ImagePullSecretsPropertyOutputReference;
    }
    interface EksPropertiesPodPropertiesInitContainersEnvProperty {
    }
    class EksPropertiesPodPropertiesInitContainersEnvPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EksPropertiesPodPropertiesInitContainersEnvProperty | undefined;
        set internalValue(value: EksPropertiesPodPropertiesInitContainersEnvProperty | undefined);
        get name(): string;
        get value(): string;
    }
    class EksPropertiesPodPropertiesInitContainersEnvPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EksPropertiesPodPropertiesInitContainersEnvPropertyOutputReference;
    }
    interface EksPropertiesPodPropertiesInitContainersResourcesProperty {
    }
    class EksPropertiesPodPropertiesInitContainersResourcesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EksPropertiesPodPropertiesInitContainersResourcesProperty | undefined;
        set internalValue(value: EksPropertiesPodPropertiesInitContainersResourcesProperty | undefined);
        private _limits;
        get limits(): cdktn.StringMap;
        private _requests;
        get requests(): cdktn.StringMap;
    }
    class EksPropertiesPodPropertiesInitContainersResourcesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EksPropertiesPodPropertiesInitContainersResourcesPropertyOutputReference;
    }
    interface EksPropertiesPodPropertiesInitContainersSecurityContextProperty {
    }
    class EksPropertiesPodPropertiesInitContainersSecurityContextPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EksPropertiesPodPropertiesInitContainersSecurityContextProperty | undefined;
        set internalValue(value: EksPropertiesPodPropertiesInitContainersSecurityContextProperty | undefined);
        get allowPrivilegeEscalation(): cdktn.IResolvable;
        get privileged(): cdktn.IResolvable;
        get readOnlyRootFileSystem(): cdktn.IResolvable;
        get runAsGroup(): number;
        get runAsNonRoot(): cdktn.IResolvable;
        get runAsUser(): number;
    }
    class EksPropertiesPodPropertiesInitContainersSecurityContextPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EksPropertiesPodPropertiesInitContainersSecurityContextPropertyOutputReference;
    }
    interface EksPropertiesPodPropertiesInitContainersVolumeMountsProperty {
    }
    class EksPropertiesPodPropertiesInitContainersVolumeMountsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EksPropertiesPodPropertiesInitContainersVolumeMountsProperty | undefined;
        set internalValue(value: EksPropertiesPodPropertiesInitContainersVolumeMountsProperty | undefined);
        get mountPath(): string;
        get name(): string;
        get readOnly(): cdktn.IResolvable;
    }
    class EksPropertiesPodPropertiesInitContainersVolumeMountsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EksPropertiesPodPropertiesInitContainersVolumeMountsPropertyOutputReference;
    }
    interface InitContainersProperty {
    }
    class InitContainersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InitContainersProperty | undefined;
        set internalValue(value: InitContainersProperty | undefined);
        get args(): string[];
        get command(): string[];
        private _env;
        get env(): EksPropertiesPodPropertiesInitContainersEnvPropertyList;
        get image(): string;
        get imagePullPolicy(): string;
        get name(): string;
        private _resources;
        get resources(): EksPropertiesPodPropertiesInitContainersResourcesPropertyList;
        private _securityContext;
        get securityContext(): EksPropertiesPodPropertiesInitContainersSecurityContextPropertyList;
        private _volumeMounts;
        get volumeMounts(): EksPropertiesPodPropertiesInitContainersVolumeMountsPropertyList;
    }
    class InitContainersPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InitContainersPropertyOutputReference;
    }
    interface MetadataProperty {
    }
    class MetadataPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MetadataProperty | undefined;
        set internalValue(value: MetadataProperty | undefined);
        private _labels;
        get labels(): cdktn.StringMap;
    }
    class MetadataPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MetadataPropertyOutputReference;
    }
    interface EmptyDirProperty {
    }
    class EmptyDirPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EmptyDirProperty | undefined;
        set internalValue(value: EmptyDirProperty | undefined);
        get medium(): string;
        get sizeLimit(): string;
    }
    class EmptyDirPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EmptyDirPropertyOutputReference;
    }
    interface HostPathProperty {
    }
    class HostPathPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HostPathProperty | undefined;
        set internalValue(value: HostPathProperty | undefined);
        get path(): string;
    }
    class HostPathPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HostPathPropertyOutputReference;
    }
    interface SecretProperty {
    }
    class SecretPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SecretProperty | undefined;
        set internalValue(value: SecretProperty | undefined);
        get optional(): cdktn.IResolvable;
        get secretName(): string;
    }
    class SecretPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SecretPropertyOutputReference;
    }
    interface EksPropertiesPodPropertiesVolumesProperty {
    }
    class EksPropertiesPodPropertiesVolumesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EksPropertiesPodPropertiesVolumesProperty | undefined;
        set internalValue(value: EksPropertiesPodPropertiesVolumesProperty | undefined);
        private _emptyDir;
        get emptyDir(): EmptyDirPropertyList;
        private _hostPath;
        get hostPath(): HostPathPropertyList;
        get name(): string;
        private _secret;
        get secret(): SecretPropertyList;
    }
    class EksPropertiesPodPropertiesVolumesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EksPropertiesPodPropertiesVolumesPropertyOutputReference;
    }
    interface PodPropertiesProperty {
    }
    class PodPropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PodPropertiesProperty | undefined;
        set internalValue(value: PodPropertiesProperty | undefined);
        private _containers;
        get containers(): ContainersPropertyList;
        get dnsPolicy(): string;
        get hostNetwork(): cdktn.IResolvable;
        private _imagePullSecrets;
        get imagePullSecrets(): ImagePullSecretsPropertyList;
        private _initContainers;
        get initContainers(): InitContainersPropertyList;
        private _metadata;
        get metadata(): MetadataPropertyList;
        get serviceAccountName(): string;
        get shareProcessNamespace(): cdktn.IResolvable;
        private _volumes;
        get volumes(): EksPropertiesPodPropertiesVolumesPropertyList;
    }
    class PodPropertiesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PodPropertiesPropertyOutputReference;
    }
    interface EksPropertiesProperty {
    }
    class EksPropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EksPropertiesProperty | undefined;
        set internalValue(value: EksPropertiesProperty | undefined);
        private _podProperties;
        get podProperties(): PodPropertiesPropertyList;
    }
    class EksPropertiesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EksPropertiesPropertyOutputReference;
    }
    interface EnvironmentProperty {
    }
    class EnvironmentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EnvironmentProperty | undefined;
        set internalValue(value: EnvironmentProperty | undefined);
        get name(): string;
        get value(): string;
    }
    class EnvironmentPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EnvironmentPropertyOutputReference;
    }
    interface EphemeralStorageProperty {
    }
    class EphemeralStoragePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EphemeralStorageProperty | undefined;
        set internalValue(value: EphemeralStorageProperty | undefined);
        get sizeInGib(): number;
    }
    class EphemeralStoragePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EphemeralStoragePropertyOutputReference;
    }
    interface FargatePlatformConfigurationProperty {
    }
    class FargatePlatformConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FargatePlatformConfigurationProperty | undefined;
        set internalValue(value: FargatePlatformConfigurationProperty | undefined);
        get platformVersion(): string;
    }
    class FargatePlatformConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FargatePlatformConfigurationPropertyOutputReference;
    }
    interface DevicesProperty {
    }
    class DevicesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DevicesProperty | undefined;
        set internalValue(value: DevicesProperty | undefined);
        get containerPath(): string;
        get hostPath(): string;
        get permissions(): string[];
    }
    class DevicesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DevicesPropertyOutputReference;
    }
    interface TmpfsProperty {
    }
    class TmpfsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TmpfsProperty | undefined;
        set internalValue(value: TmpfsProperty | undefined);
        get containerPath(): string;
        get mountOptions(): string[];
        get size(): number;
    }
    class TmpfsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TmpfsPropertyOutputReference;
    }
    interface LinuxParametersProperty {
    }
    class LinuxParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LinuxParametersProperty | undefined;
        set internalValue(value: LinuxParametersProperty | undefined);
        private _devices;
        get devices(): DevicesPropertyList;
        get initProcessEnabled(): cdktn.IResolvable;
        get maxSwap(): number;
        get sharedMemorySize(): number;
        get swappiness(): number;
        private _tmpfs;
        get tmpfs(): TmpfsPropertyList;
    }
    class LinuxParametersPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LinuxParametersPropertyOutputReference;
    }
    interface SecretOptionsProperty {
    }
    class SecretOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SecretOptionsProperty | undefined;
        set internalValue(value: SecretOptionsProperty | undefined);
        get name(): string;
        get valueFrom(): string;
    }
    class SecretOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SecretOptionsPropertyOutputReference;
    }
    interface LogConfigurationProperty {
    }
    class LogConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LogConfigurationProperty | undefined;
        set internalValue(value: LogConfigurationProperty | undefined);
        get logDriver(): string;
        private _options;
        get options(): cdktn.StringMap;
        private _secretOptions;
        get secretOptions(): SecretOptionsPropertyList;
    }
    class LogConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LogConfigurationPropertyOutputReference;
    }
    interface MountPointsProperty {
    }
    class MountPointsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MountPointsProperty | undefined;
        set internalValue(value: MountPointsProperty | undefined);
        get containerPath(): string;
        get readOnly(): cdktn.IResolvable;
        get sourceVolume(): string;
    }
    class MountPointsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MountPointsPropertyOutputReference;
    }
    interface NetworkConfigurationProperty {
    }
    class NetworkConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NetworkConfigurationProperty | undefined;
        set internalValue(value: NetworkConfigurationProperty | undefined);
        get assignPublicIp(): cdktn.IResolvable;
    }
    class NetworkConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NetworkConfigurationPropertyOutputReference;
    }
    interface ResourceRequirementsProperty {
    }
    class ResourceRequirementsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceRequirementsProperty | undefined;
        set internalValue(value: ResourceRequirementsProperty | undefined);
        get type(): string;
        get value(): string;
    }
    class ResourceRequirementsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceRequirementsPropertyOutputReference;
    }
    interface RuntimePlatformProperty {
    }
    class RuntimePlatformPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuntimePlatformProperty | undefined;
        set internalValue(value: RuntimePlatformProperty | undefined);
        get cpuArchitecture(): string;
        get operatingSystemFamily(): string;
    }
    class RuntimePlatformPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuntimePlatformPropertyOutputReference;
    }
    interface SecretsProperty {
    }
    class SecretsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SecretsProperty | undefined;
        set internalValue(value: SecretsProperty | undefined);
        get name(): string;
        get valueFrom(): string;
    }
    class SecretsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SecretsPropertyOutputReference;
    }
    interface UlimitsProperty {
    }
    class UlimitsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): UlimitsProperty | undefined;
        set internalValue(value: UlimitsProperty | undefined);
        get hardLimit(): number;
        get name(): string;
        get softLimit(): number;
    }
    class UlimitsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): UlimitsPropertyOutputReference;
    }
    interface AuthorizationConfigProperty {
    }
    class AuthorizationConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthorizationConfigProperty | undefined;
        set internalValue(value: AuthorizationConfigProperty | undefined);
        get accessPointId(): string;
        get iam(): string;
    }
    class AuthorizationConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthorizationConfigPropertyOutputReference;
    }
    interface EfsVolumeConfigurationProperty {
    }
    class EfsVolumeConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EfsVolumeConfigurationProperty | undefined;
        set internalValue(value: EfsVolumeConfigurationProperty | undefined);
        private _authorizationConfig;
        get authorizationConfig(): AuthorizationConfigPropertyList;
        get fileSystemId(): string;
        get rootDirectory(): string;
        get transitEncryption(): string;
        get transitEncryptionPort(): number;
    }
    class EfsVolumeConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EfsVolumeConfigurationPropertyOutputReference;
    }
    interface HostProperty {
    }
    class HostPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HostProperty | undefined;
        set internalValue(value: HostProperty | undefined);
        get sourcePath(): string;
    }
    class HostPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HostPropertyOutputReference;
    }
    interface NodePropertiesNodeRangePropertiesContainerVolumesProperty {
    }
    class NodePropertiesNodeRangePropertiesContainerVolumesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NodePropertiesNodeRangePropertiesContainerVolumesProperty | undefined;
        set internalValue(value: NodePropertiesNodeRangePropertiesContainerVolumesProperty | undefined);
        private _efsVolumeConfiguration;
        get efsVolumeConfiguration(): EfsVolumeConfigurationPropertyList;
        private _host;
        get host(): HostPropertyList;
        get name(): string;
    }
    class NodePropertiesNodeRangePropertiesContainerVolumesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NodePropertiesNodeRangePropertiesContainerVolumesPropertyOutputReference;
    }
    interface ContainerProperty {
    }
    class ContainerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ContainerProperty | undefined;
        set internalValue(value: ContainerProperty | undefined);
        get command(): string[];
        private _environment;
        get environment(): EnvironmentPropertyList;
        private _ephemeralStorage;
        get ephemeralStorage(): EphemeralStoragePropertyList;
        get executionRoleArn(): string;
        private _fargatePlatformConfiguration;
        get fargatePlatformConfiguration(): FargatePlatformConfigurationPropertyList;
        get image(): string;
        get instanceType(): string;
        get jobRoleArn(): string;
        private _linuxParameters;
        get linuxParameters(): LinuxParametersPropertyList;
        private _logConfiguration;
        get logConfiguration(): LogConfigurationPropertyList;
        private _mountPoints;
        get mountPoints(): MountPointsPropertyList;
        private _networkConfiguration;
        get networkConfiguration(): NetworkConfigurationPropertyList;
        get privileged(): cdktn.IResolvable;
        get readonlyRootFilesystem(): cdktn.IResolvable;
        private _resourceRequirements;
        get resourceRequirements(): ResourceRequirementsPropertyList;
        private _runtimePlatform;
        get runtimePlatform(): RuntimePlatformPropertyList;
        private _secrets;
        get secrets(): SecretsPropertyList;
        private _ulimits;
        get ulimits(): UlimitsPropertyList;
        get user(): string;
        private _volumes;
        get volumes(): NodePropertiesNodeRangePropertiesContainerVolumesPropertyList;
    }
    class ContainerPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ContainerPropertyOutputReference;
    }
    interface NodeRangePropertiesProperty {
    }
    class NodeRangePropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NodeRangePropertiesProperty | undefined;
        set internalValue(value: NodeRangePropertiesProperty | undefined);
        private _container;
        get container(): ContainerPropertyList;
        get targetNodes(): string;
    }
    class NodeRangePropertiesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NodeRangePropertiesPropertyOutputReference;
    }
    interface NodePropertiesProperty {
    }
    class NodePropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NodePropertiesProperty | undefined;
        set internalValue(value: NodePropertiesProperty | undefined);
        get mainNode(): number;
        private _nodeRangeProperties;
        get nodeRangeProperties(): NodeRangePropertiesPropertyList;
        get numNodes(): number;
    }
    class NodePropertiesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NodePropertiesPropertyOutputReference;
    }
    interface EvaluateOnExitProperty {
    }
    class EvaluateOnExitPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EvaluateOnExitProperty | undefined;
        set internalValue(value: EvaluateOnExitProperty | undefined);
        get action(): string;
        get onExitCode(): string;
        get onReason(): string;
        get onStatusReason(): string;
    }
    class EvaluateOnExitPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EvaluateOnExitPropertyOutputReference;
    }
    interface RetryStrategyProperty {
    }
    class RetryStrategyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RetryStrategyProperty | undefined;
        set internalValue(value: RetryStrategyProperty | undefined);
        get attempts(): number;
        private _evaluateOnExit;
        get evaluateOnExit(): EvaluateOnExitPropertyList;
    }
    class RetryStrategyPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RetryStrategyPropertyOutputReference;
    }
    interface TimeoutProperty {
    }
    class TimeoutPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TimeoutProperty | undefined;
        set internalValue(value: TimeoutProperty | undefined);
        get attemptDurationSeconds(): number;
    }
    class TimeoutPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TimeoutPropertyOutputReference;
    }
}
