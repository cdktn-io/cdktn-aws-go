import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfJobDefinitionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#container_properties TfJobDefinition#container_properties}
    */
    readonly containerProperties?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#deregister_on_new_revision TfJobDefinition#deregister_on_new_revision}
    */
    readonly deregisterOnNewRevision?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#ecs_properties TfJobDefinition#ecs_properties}
    */
    readonly ecsProperties?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#id TfJobDefinition#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#name TfJobDefinition#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#node_properties TfJobDefinition#node_properties}
    */
    readonly nodeProperties?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#parameters TfJobDefinition#parameters}
    */
    readonly parameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#platform_capabilities TfJobDefinition#platform_capabilities}
    */
    readonly platformCapabilities?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#propagate_tags TfJobDefinition#propagate_tags}
    */
    readonly propagateTags?: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#region TfJobDefinition#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#scheduling_priority TfJobDefinition#scheduling_priority}
    */
    readonly schedulingPriority?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#tags TfJobDefinition#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#tags_all TfJobDefinition#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#type TfJobDefinition#type}
    */
    readonly type: string;
    /**
    * eks_properties block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#eks_properties TfJobDefinition#eks_properties}
    */
    readonly eksProperties?: TfJobDefinition.EksPropertiesProperty;
    /**
    * retry_strategy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#retry_strategy TfJobDefinition#retry_strategy}
    */
    readonly retryStrategy?: TfJobDefinition.RetryStrategyProperty;
    /**
    * timeout block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#timeout TfJobDefinition#timeout}
    */
    readonly timeout?: TfJobDefinition.TimeoutProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition aws_batch_job_definition}
*/
export declare class TfJobDefinition extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_batch_job_definition";
    /**
    * Generates CDKTN code for importing a TfJobDefinition resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfJobDefinition to import
    * @param importFromId The id of the existing TfJobDefinition that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfJobDefinition to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition aws_batch_job_definition} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfJobDefinitionConfig
    */
    constructor(scope: Construct, id: string, config: TfJobDefinitionConfig);
    get arn(): string;
    get arnPrefix(): string;
    private _containerProperties?;
    get containerProperties(): string;
    set containerProperties(value: string);
    resetContainerProperties(): void;
    get containerPropertiesInput(): string | undefined;
    private _deregisterOnNewRevision?;
    get deregisterOnNewRevision(): boolean | cdktn.IResolvable;
    set deregisterOnNewRevision(value: boolean | cdktn.IResolvable);
    resetDeregisterOnNewRevision(): void;
    get deregisterOnNewRevisionInput(): boolean | cdktn.IResolvable | undefined;
    private _ecsProperties?;
    get ecsProperties(): string;
    set ecsProperties(value: string);
    resetEcsProperties(): void;
    get ecsPropertiesInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _nodeProperties?;
    get nodeProperties(): string;
    set nodeProperties(value: string);
    resetNodeProperties(): void;
    get nodePropertiesInput(): string | undefined;
    private _parameters?;
    get parameters(): {
        [key: string]: string;
    };
    set parameters(value: {
        [key: string]: string;
    });
    resetParameters(): void;
    get parametersInput(): {
        [key: string]: string;
    } | undefined;
    private _platformCapabilities?;
    get platformCapabilities(): string[];
    set platformCapabilities(value: string[]);
    resetPlatformCapabilities(): void;
    get platformCapabilitiesInput(): string[] | undefined;
    private _propagateTags?;
    get propagateTags(): boolean | cdktn.IResolvable;
    set propagateTags(value: boolean | cdktn.IResolvable);
    resetPropagateTags(): void;
    get propagateTagsInput(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get revision(): number;
    private _schedulingPriority?;
    get schedulingPriority(): number;
    set schedulingPriority(value: number);
    resetSchedulingPriority(): void;
    get schedulingPriorityInput(): number | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _eksProperties;
    get eksProperties(): TfJobDefinition.EksPropertiesPropertyOutputReference;
    putEksProperties(value: TfJobDefinition.EksPropertiesProperty): void;
    resetEksProperties(): void;
    get eksPropertiesInput(): TfJobDefinition.EksPropertiesProperty | undefined;
    private _retryStrategy;
    get retryStrategy(): TfJobDefinition.RetryStrategyPropertyOutputReference;
    putRetryStrategy(value: TfJobDefinition.RetryStrategyProperty): void;
    resetRetryStrategy(): void;
    get retryStrategyInput(): TfJobDefinition.RetryStrategyProperty | undefined;
    private _timeout;
    get timeout(): TfJobDefinition.TimeoutPropertyOutputReference;
    putTimeout(value: TfJobDefinition.TimeoutProperty): void;
    resetTimeout(): void;
    get timeoutInput(): TfJobDefinition.TimeoutProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfJobDefinitionEksPropertiesPodPropertiesContainersEnvPropertyToTerraform(struct?: TfJobDefinition.EksPropertiesPodPropertiesContainersEnvProperty | cdktn.IResolvable): any;
export declare function tfJobDefinitionEksPropertiesPodPropertiesContainersEnvPropertyToHclTerraform(struct?: TfJobDefinition.EksPropertiesPodPropertiesContainersEnvProperty | cdktn.IResolvable): any;
export declare function tfJobDefinitionEksPropertiesPodPropertiesContainersResourcesPropertyToTerraform(struct?: TfJobDefinition.EksPropertiesPodPropertiesContainersResourcesPropertyOutputReference | TfJobDefinition.EksPropertiesPodPropertiesContainersResourcesProperty): any;
export declare function tfJobDefinitionEksPropertiesPodPropertiesContainersResourcesPropertyToHclTerraform(struct?: TfJobDefinition.EksPropertiesPodPropertiesContainersResourcesPropertyOutputReference | TfJobDefinition.EksPropertiesPodPropertiesContainersResourcesProperty): any;
export declare function tfJobDefinitionEksPropertiesPodPropertiesContainersSecurityContextPropertyToTerraform(struct?: TfJobDefinition.EksPropertiesPodPropertiesContainersSecurityContextPropertyOutputReference | TfJobDefinition.EksPropertiesPodPropertiesContainersSecurityContextProperty): any;
export declare function tfJobDefinitionEksPropertiesPodPropertiesContainersSecurityContextPropertyToHclTerraform(struct?: TfJobDefinition.EksPropertiesPodPropertiesContainersSecurityContextPropertyOutputReference | TfJobDefinition.EksPropertiesPodPropertiesContainersSecurityContextProperty): any;
export declare function tfJobDefinitionEksPropertiesPodPropertiesContainersVolumeMountsPropertyToTerraform(struct?: TfJobDefinition.EksPropertiesPodPropertiesContainersVolumeMountsProperty | cdktn.IResolvable): any;
export declare function tfJobDefinitionEksPropertiesPodPropertiesContainersVolumeMountsPropertyToHclTerraform(struct?: TfJobDefinition.EksPropertiesPodPropertiesContainersVolumeMountsProperty | cdktn.IResolvable): any;
export declare function tfJobDefinitionContainersPropertyToTerraform(struct?: TfJobDefinition.ContainersProperty | cdktn.IResolvable): any;
export declare function tfJobDefinitionContainersPropertyToHclTerraform(struct?: TfJobDefinition.ContainersProperty | cdktn.IResolvable): any;
export declare function tfJobDefinitionImagePullSecretPropertyToTerraform(struct?: TfJobDefinition.ImagePullSecretProperty | cdktn.IResolvable): any;
export declare function tfJobDefinitionImagePullSecretPropertyToHclTerraform(struct?: TfJobDefinition.ImagePullSecretProperty | cdktn.IResolvable): any;
export declare function tfJobDefinitionEksPropertiesPodPropertiesInitContainersEnvPropertyToTerraform(struct?: TfJobDefinition.EksPropertiesPodPropertiesInitContainersEnvProperty | cdktn.IResolvable): any;
export declare function tfJobDefinitionEksPropertiesPodPropertiesInitContainersEnvPropertyToHclTerraform(struct?: TfJobDefinition.EksPropertiesPodPropertiesInitContainersEnvProperty | cdktn.IResolvable): any;
export declare function tfJobDefinitionEksPropertiesPodPropertiesInitContainersResourcesPropertyToTerraform(struct?: TfJobDefinition.EksPropertiesPodPropertiesInitContainersResourcesPropertyOutputReference | TfJobDefinition.EksPropertiesPodPropertiesInitContainersResourcesProperty): any;
export declare function tfJobDefinitionEksPropertiesPodPropertiesInitContainersResourcesPropertyToHclTerraform(struct?: TfJobDefinition.EksPropertiesPodPropertiesInitContainersResourcesPropertyOutputReference | TfJobDefinition.EksPropertiesPodPropertiesInitContainersResourcesProperty): any;
export declare function tfJobDefinitionEksPropertiesPodPropertiesInitContainersSecurityContextPropertyToTerraform(struct?: TfJobDefinition.EksPropertiesPodPropertiesInitContainersSecurityContextPropertyOutputReference | TfJobDefinition.EksPropertiesPodPropertiesInitContainersSecurityContextProperty): any;
export declare function tfJobDefinitionEksPropertiesPodPropertiesInitContainersSecurityContextPropertyToHclTerraform(struct?: TfJobDefinition.EksPropertiesPodPropertiesInitContainersSecurityContextPropertyOutputReference | TfJobDefinition.EksPropertiesPodPropertiesInitContainersSecurityContextProperty): any;
export declare function tfJobDefinitionEksPropertiesPodPropertiesInitContainersVolumeMountsPropertyToTerraform(struct?: TfJobDefinition.EksPropertiesPodPropertiesInitContainersVolumeMountsProperty | cdktn.IResolvable): any;
export declare function tfJobDefinitionEksPropertiesPodPropertiesInitContainersVolumeMountsPropertyToHclTerraform(struct?: TfJobDefinition.EksPropertiesPodPropertiesInitContainersVolumeMountsProperty | cdktn.IResolvable): any;
export declare function tfJobDefinitionInitContainersPropertyToTerraform(struct?: TfJobDefinition.InitContainersProperty | cdktn.IResolvable): any;
export declare function tfJobDefinitionInitContainersPropertyToHclTerraform(struct?: TfJobDefinition.InitContainersProperty | cdktn.IResolvable): any;
export declare function tfJobDefinitionMetadataPropertyToTerraform(struct?: TfJobDefinition.MetadataPropertyOutputReference | TfJobDefinition.MetadataProperty): any;
export declare function tfJobDefinitionMetadataPropertyToHclTerraform(struct?: TfJobDefinition.MetadataPropertyOutputReference | TfJobDefinition.MetadataProperty): any;
export declare function tfJobDefinitionEmptyDirPropertyToTerraform(struct?: TfJobDefinition.EmptyDirPropertyOutputReference | TfJobDefinition.EmptyDirProperty): any;
export declare function tfJobDefinitionEmptyDirPropertyToHclTerraform(struct?: TfJobDefinition.EmptyDirPropertyOutputReference | TfJobDefinition.EmptyDirProperty): any;
export declare function tfJobDefinitionHostPathPropertyToTerraform(struct?: TfJobDefinition.HostPathPropertyOutputReference | TfJobDefinition.HostPathProperty): any;
export declare function tfJobDefinitionHostPathPropertyToHclTerraform(struct?: TfJobDefinition.HostPathPropertyOutputReference | TfJobDefinition.HostPathProperty): any;
export declare function tfJobDefinitionSecretPropertyToTerraform(struct?: TfJobDefinition.SecretPropertyOutputReference | TfJobDefinition.SecretProperty): any;
export declare function tfJobDefinitionSecretPropertyToHclTerraform(struct?: TfJobDefinition.SecretPropertyOutputReference | TfJobDefinition.SecretProperty): any;
export declare function tfJobDefinitionVolumesPropertyToTerraform(struct?: TfJobDefinition.VolumesProperty | cdktn.IResolvable): any;
export declare function tfJobDefinitionVolumesPropertyToHclTerraform(struct?: TfJobDefinition.VolumesProperty | cdktn.IResolvable): any;
export declare function tfJobDefinitionPodPropertiesPropertyToTerraform(struct?: TfJobDefinition.PodPropertiesPropertyOutputReference | TfJobDefinition.PodPropertiesProperty): any;
export declare function tfJobDefinitionPodPropertiesPropertyToHclTerraform(struct?: TfJobDefinition.PodPropertiesPropertyOutputReference | TfJobDefinition.PodPropertiesProperty): any;
export declare function tfJobDefinitionEksPropertiesPropertyToTerraform(struct?: TfJobDefinition.EksPropertiesPropertyOutputReference | TfJobDefinition.EksPropertiesProperty): any;
export declare function tfJobDefinitionEksPropertiesPropertyToHclTerraform(struct?: TfJobDefinition.EksPropertiesPropertyOutputReference | TfJobDefinition.EksPropertiesProperty): any;
export declare function tfJobDefinitionEvaluateOnExitPropertyToTerraform(struct?: TfJobDefinition.EvaluateOnExitProperty | cdktn.IResolvable): any;
export declare function tfJobDefinitionEvaluateOnExitPropertyToHclTerraform(struct?: TfJobDefinition.EvaluateOnExitProperty | cdktn.IResolvable): any;
export declare function tfJobDefinitionRetryStrategyPropertyToTerraform(struct?: TfJobDefinition.RetryStrategyPropertyOutputReference | TfJobDefinition.RetryStrategyProperty): any;
export declare function tfJobDefinitionRetryStrategyPropertyToHclTerraform(struct?: TfJobDefinition.RetryStrategyPropertyOutputReference | TfJobDefinition.RetryStrategyProperty): any;
export declare function tfJobDefinitionTimeoutPropertyToTerraform(struct?: TfJobDefinition.TimeoutPropertyOutputReference | TfJobDefinition.TimeoutProperty): any;
export declare function tfJobDefinitionTimeoutPropertyToHclTerraform(struct?: TfJobDefinition.TimeoutPropertyOutputReference | TfJobDefinition.TimeoutProperty): any;
export declare namespace TfJobDefinition {
    interface EksPropertiesPodPropertiesContainersEnvProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#name TfJobDefinition#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#value TfJobDefinition#value}
        */
        readonly value: string;
    }
    class EksPropertiesPodPropertiesContainersEnvPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EksPropertiesPodPropertiesContainersEnvProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EksPropertiesPodPropertiesContainersEnvProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class EksPropertiesPodPropertiesContainersEnvPropertyList extends cdktn.ComplexList {
        internalValue?: EksPropertiesPodPropertiesContainersEnvProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EksPropertiesPodPropertiesContainersEnvPropertyOutputReference;
    }
    interface EksPropertiesPodPropertiesContainersResourcesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#limits TfJobDefinition#limits}
        */
        readonly limits?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#requests TfJobDefinition#requests}
        */
        readonly requests?: {
            [key: string]: string;
        };
    }
    class EksPropertiesPodPropertiesContainersResourcesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EksPropertiesPodPropertiesContainersResourcesProperty | undefined;
        set internalValue(value: EksPropertiesPodPropertiesContainersResourcesProperty | undefined);
        private _limits?;
        get limits(): {
            [key: string]: string;
        };
        set limits(value: {
            [key: string]: string;
        });
        resetLimits(): void;
        get limitsInput(): {
            [key: string]: string;
        } | undefined;
        private _requests?;
        get requests(): {
            [key: string]: string;
        };
        set requests(value: {
            [key: string]: string;
        });
        resetRequests(): void;
        get requestsInput(): {
            [key: string]: string;
        } | undefined;
    }
    interface EksPropertiesPodPropertiesContainersSecurityContextProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#allow_privilege_escalation TfJobDefinition#allow_privilege_escalation}
        */
        readonly allowPrivilegeEscalation?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#privileged TfJobDefinition#privileged}
        */
        readonly privileged?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#read_only_root_file_system TfJobDefinition#read_only_root_file_system}
        */
        readonly readOnlyRootFileSystem?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#run_as_group TfJobDefinition#run_as_group}
        */
        readonly runAsGroup?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#run_as_non_root TfJobDefinition#run_as_non_root}
        */
        readonly runAsNonRoot?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#run_as_user TfJobDefinition#run_as_user}
        */
        readonly runAsUser?: number;
    }
    class EksPropertiesPodPropertiesContainersSecurityContextPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EksPropertiesPodPropertiesContainersSecurityContextProperty | undefined;
        set internalValue(value: EksPropertiesPodPropertiesContainersSecurityContextProperty | undefined);
        private _allowPrivilegeEscalation?;
        get allowPrivilegeEscalation(): boolean | cdktn.IResolvable;
        set allowPrivilegeEscalation(value: boolean | cdktn.IResolvable);
        resetAllowPrivilegeEscalation(): void;
        get allowPrivilegeEscalationInput(): boolean | cdktn.IResolvable | undefined;
        private _privileged?;
        get privileged(): boolean | cdktn.IResolvable;
        set privileged(value: boolean | cdktn.IResolvable);
        resetPrivileged(): void;
        get privilegedInput(): boolean | cdktn.IResolvable | undefined;
        private _readOnlyRootFileSystem?;
        get readOnlyRootFileSystem(): boolean | cdktn.IResolvable;
        set readOnlyRootFileSystem(value: boolean | cdktn.IResolvable);
        resetReadOnlyRootFileSystem(): void;
        get readOnlyRootFileSystemInput(): boolean | cdktn.IResolvable | undefined;
        private _runAsGroup?;
        get runAsGroup(): number;
        set runAsGroup(value: number);
        resetRunAsGroup(): void;
        get runAsGroupInput(): number | undefined;
        private _runAsNonRoot?;
        get runAsNonRoot(): boolean | cdktn.IResolvable;
        set runAsNonRoot(value: boolean | cdktn.IResolvable);
        resetRunAsNonRoot(): void;
        get runAsNonRootInput(): boolean | cdktn.IResolvable | undefined;
        private _runAsUser?;
        get runAsUser(): number;
        set runAsUser(value: number);
        resetRunAsUser(): void;
        get runAsUserInput(): number | undefined;
    }
    interface EksPropertiesPodPropertiesContainersVolumeMountsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#mount_path TfJobDefinition#mount_path}
        */
        readonly mountPath: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#name TfJobDefinition#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#read_only TfJobDefinition#read_only}
        */
        readonly readOnly?: boolean | cdktn.IResolvable;
    }
    class EksPropertiesPodPropertiesContainersVolumeMountsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EksPropertiesPodPropertiesContainersVolumeMountsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EksPropertiesPodPropertiesContainersVolumeMountsProperty | cdktn.IResolvable | undefined);
        private _mountPath?;
        get mountPath(): string;
        set mountPath(value: string);
        get mountPathInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _readOnly?;
        get readOnly(): boolean | cdktn.IResolvable;
        set readOnly(value: boolean | cdktn.IResolvable);
        resetReadOnly(): void;
        get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    }
    class EksPropertiesPodPropertiesContainersVolumeMountsPropertyList extends cdktn.ComplexList {
        internalValue?: EksPropertiesPodPropertiesContainersVolumeMountsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EksPropertiesPodPropertiesContainersVolumeMountsPropertyOutputReference;
    }
    interface ContainersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#args TfJobDefinition#args}
        */
        readonly args?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#command TfJobDefinition#command}
        */
        readonly command?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#image TfJobDefinition#image}
        */
        readonly image: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#image_pull_policy TfJobDefinition#image_pull_policy}
        */
        readonly imagePullPolicy?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#name TfJobDefinition#name}
        */
        readonly name?: string;
        /**
        * env block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#env TfJobDefinition#env}
        */
        readonly env?: EksPropertiesPodPropertiesContainersEnvProperty[] | cdktn.IResolvable;
        /**
        * resources block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#resources TfJobDefinition#resources}
        */
        readonly resources?: EksPropertiesPodPropertiesContainersResourcesProperty;
        /**
        * security_context block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#security_context TfJobDefinition#security_context}
        */
        readonly securityContext?: EksPropertiesPodPropertiesContainersSecurityContextProperty;
        /**
        * volume_mounts block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#volume_mounts TfJobDefinition#volume_mounts}
        */
        readonly volumeMounts?: EksPropertiesPodPropertiesContainersVolumeMountsProperty[] | cdktn.IResolvable;
    }
    class ContainersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ContainersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ContainersProperty | cdktn.IResolvable | undefined);
        private _args?;
        get args(): string[];
        set args(value: string[]);
        resetArgs(): void;
        get argsInput(): string[] | undefined;
        private _command?;
        get command(): string[];
        set command(value: string[]);
        resetCommand(): void;
        get commandInput(): string[] | undefined;
        private _image?;
        get image(): string;
        set image(value: string);
        get imageInput(): string | undefined;
        private _imagePullPolicy?;
        get imagePullPolicy(): string;
        set imagePullPolicy(value: string);
        resetImagePullPolicy(): void;
        get imagePullPolicyInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _env;
        get env(): EksPropertiesPodPropertiesContainersEnvPropertyList;
        putEnv(value: EksPropertiesPodPropertiesContainersEnvProperty[] | cdktn.IResolvable): void;
        resetEnv(): void;
        get envInput(): cdktn.IResolvable | EksPropertiesPodPropertiesContainersEnvProperty[] | undefined;
        private _resources;
        get resources(): EksPropertiesPodPropertiesContainersResourcesPropertyOutputReference;
        putResources(value: EksPropertiesPodPropertiesContainersResourcesProperty): void;
        resetResources(): void;
        get resourcesInput(): EksPropertiesPodPropertiesContainersResourcesProperty | undefined;
        private _securityContext;
        get securityContext(): EksPropertiesPodPropertiesContainersSecurityContextPropertyOutputReference;
        putSecurityContext(value: EksPropertiesPodPropertiesContainersSecurityContextProperty): void;
        resetSecurityContext(): void;
        get securityContextInput(): EksPropertiesPodPropertiesContainersSecurityContextProperty | undefined;
        private _volumeMounts;
        get volumeMounts(): EksPropertiesPodPropertiesContainersVolumeMountsPropertyList;
        putVolumeMounts(value: EksPropertiesPodPropertiesContainersVolumeMountsProperty[] | cdktn.IResolvable): void;
        resetVolumeMounts(): void;
        get volumeMountsInput(): cdktn.IResolvable | EksPropertiesPodPropertiesContainersVolumeMountsProperty[] | undefined;
    }
    class ContainersPropertyList extends cdktn.ComplexList {
        internalValue?: ContainersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ContainersPropertyOutputReference;
    }
    interface ImagePullSecretProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#name TfJobDefinition#name}
        */
        readonly name: string;
    }
    class ImagePullSecretPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ImagePullSecretProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ImagePullSecretProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    class ImagePullSecretPropertyList extends cdktn.ComplexList {
        internalValue?: ImagePullSecretProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ImagePullSecretPropertyOutputReference;
    }
    interface EksPropertiesPodPropertiesInitContainersEnvProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#name TfJobDefinition#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#value TfJobDefinition#value}
        */
        readonly value: string;
    }
    class EksPropertiesPodPropertiesInitContainersEnvPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EksPropertiesPodPropertiesInitContainersEnvProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EksPropertiesPodPropertiesInitContainersEnvProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class EksPropertiesPodPropertiesInitContainersEnvPropertyList extends cdktn.ComplexList {
        internalValue?: EksPropertiesPodPropertiesInitContainersEnvProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EksPropertiesPodPropertiesInitContainersEnvPropertyOutputReference;
    }
    interface EksPropertiesPodPropertiesInitContainersResourcesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#limits TfJobDefinition#limits}
        */
        readonly limits?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#requests TfJobDefinition#requests}
        */
        readonly requests?: {
            [key: string]: string;
        };
    }
    class EksPropertiesPodPropertiesInitContainersResourcesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EksPropertiesPodPropertiesInitContainersResourcesProperty | undefined;
        set internalValue(value: EksPropertiesPodPropertiesInitContainersResourcesProperty | undefined);
        private _limits?;
        get limits(): {
            [key: string]: string;
        };
        set limits(value: {
            [key: string]: string;
        });
        resetLimits(): void;
        get limitsInput(): {
            [key: string]: string;
        } | undefined;
        private _requests?;
        get requests(): {
            [key: string]: string;
        };
        set requests(value: {
            [key: string]: string;
        });
        resetRequests(): void;
        get requestsInput(): {
            [key: string]: string;
        } | undefined;
    }
    interface EksPropertiesPodPropertiesInitContainersSecurityContextProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#allow_privilege_escalation TfJobDefinition#allow_privilege_escalation}
        */
        readonly allowPrivilegeEscalation?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#privileged TfJobDefinition#privileged}
        */
        readonly privileged?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#read_only_root_file_system TfJobDefinition#read_only_root_file_system}
        */
        readonly readOnlyRootFileSystem?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#run_as_group TfJobDefinition#run_as_group}
        */
        readonly runAsGroup?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#run_as_non_root TfJobDefinition#run_as_non_root}
        */
        readonly runAsNonRoot?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#run_as_user TfJobDefinition#run_as_user}
        */
        readonly runAsUser?: number;
    }
    class EksPropertiesPodPropertiesInitContainersSecurityContextPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EksPropertiesPodPropertiesInitContainersSecurityContextProperty | undefined;
        set internalValue(value: EksPropertiesPodPropertiesInitContainersSecurityContextProperty | undefined);
        private _allowPrivilegeEscalation?;
        get allowPrivilegeEscalation(): boolean | cdktn.IResolvable;
        set allowPrivilegeEscalation(value: boolean | cdktn.IResolvable);
        resetAllowPrivilegeEscalation(): void;
        get allowPrivilegeEscalationInput(): boolean | cdktn.IResolvable | undefined;
        private _privileged?;
        get privileged(): boolean | cdktn.IResolvable;
        set privileged(value: boolean | cdktn.IResolvable);
        resetPrivileged(): void;
        get privilegedInput(): boolean | cdktn.IResolvable | undefined;
        private _readOnlyRootFileSystem?;
        get readOnlyRootFileSystem(): boolean | cdktn.IResolvable;
        set readOnlyRootFileSystem(value: boolean | cdktn.IResolvable);
        resetReadOnlyRootFileSystem(): void;
        get readOnlyRootFileSystemInput(): boolean | cdktn.IResolvable | undefined;
        private _runAsGroup?;
        get runAsGroup(): number;
        set runAsGroup(value: number);
        resetRunAsGroup(): void;
        get runAsGroupInput(): number | undefined;
        private _runAsNonRoot?;
        get runAsNonRoot(): boolean | cdktn.IResolvable;
        set runAsNonRoot(value: boolean | cdktn.IResolvable);
        resetRunAsNonRoot(): void;
        get runAsNonRootInput(): boolean | cdktn.IResolvable | undefined;
        private _runAsUser?;
        get runAsUser(): number;
        set runAsUser(value: number);
        resetRunAsUser(): void;
        get runAsUserInput(): number | undefined;
    }
    interface EksPropertiesPodPropertiesInitContainersVolumeMountsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#mount_path TfJobDefinition#mount_path}
        */
        readonly mountPath: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#name TfJobDefinition#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#read_only TfJobDefinition#read_only}
        */
        readonly readOnly?: boolean | cdktn.IResolvable;
    }
    class EksPropertiesPodPropertiesInitContainersVolumeMountsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EksPropertiesPodPropertiesInitContainersVolumeMountsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EksPropertiesPodPropertiesInitContainersVolumeMountsProperty | cdktn.IResolvable | undefined);
        private _mountPath?;
        get mountPath(): string;
        set mountPath(value: string);
        get mountPathInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _readOnly?;
        get readOnly(): boolean | cdktn.IResolvable;
        set readOnly(value: boolean | cdktn.IResolvable);
        resetReadOnly(): void;
        get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    }
    class EksPropertiesPodPropertiesInitContainersVolumeMountsPropertyList extends cdktn.ComplexList {
        internalValue?: EksPropertiesPodPropertiesInitContainersVolumeMountsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EksPropertiesPodPropertiesInitContainersVolumeMountsPropertyOutputReference;
    }
    interface InitContainersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#args TfJobDefinition#args}
        */
        readonly args?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#command TfJobDefinition#command}
        */
        readonly command?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#image TfJobDefinition#image}
        */
        readonly image: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#image_pull_policy TfJobDefinition#image_pull_policy}
        */
        readonly imagePullPolicy?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#name TfJobDefinition#name}
        */
        readonly name?: string;
        /**
        * env block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#env TfJobDefinition#env}
        */
        readonly env?: EksPropertiesPodPropertiesInitContainersEnvProperty[] | cdktn.IResolvable;
        /**
        * resources block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#resources TfJobDefinition#resources}
        */
        readonly resources?: EksPropertiesPodPropertiesInitContainersResourcesProperty;
        /**
        * security_context block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#security_context TfJobDefinition#security_context}
        */
        readonly securityContext?: EksPropertiesPodPropertiesInitContainersSecurityContextProperty;
        /**
        * volume_mounts block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#volume_mounts TfJobDefinition#volume_mounts}
        */
        readonly volumeMounts?: EksPropertiesPodPropertiesInitContainersVolumeMountsProperty[] | cdktn.IResolvable;
    }
    class InitContainersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InitContainersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InitContainersProperty | cdktn.IResolvable | undefined);
        private _args?;
        get args(): string[];
        set args(value: string[]);
        resetArgs(): void;
        get argsInput(): string[] | undefined;
        private _command?;
        get command(): string[];
        set command(value: string[]);
        resetCommand(): void;
        get commandInput(): string[] | undefined;
        private _image?;
        get image(): string;
        set image(value: string);
        get imageInput(): string | undefined;
        private _imagePullPolicy?;
        get imagePullPolicy(): string;
        set imagePullPolicy(value: string);
        resetImagePullPolicy(): void;
        get imagePullPolicyInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _env;
        get env(): EksPropertiesPodPropertiesInitContainersEnvPropertyList;
        putEnv(value: EksPropertiesPodPropertiesInitContainersEnvProperty[] | cdktn.IResolvable): void;
        resetEnv(): void;
        get envInput(): cdktn.IResolvable | EksPropertiesPodPropertiesInitContainersEnvProperty[] | undefined;
        private _resources;
        get resources(): EksPropertiesPodPropertiesInitContainersResourcesPropertyOutputReference;
        putResources(value: EksPropertiesPodPropertiesInitContainersResourcesProperty): void;
        resetResources(): void;
        get resourcesInput(): EksPropertiesPodPropertiesInitContainersResourcesProperty | undefined;
        private _securityContext;
        get securityContext(): EksPropertiesPodPropertiesInitContainersSecurityContextPropertyOutputReference;
        putSecurityContext(value: EksPropertiesPodPropertiesInitContainersSecurityContextProperty): void;
        resetSecurityContext(): void;
        get securityContextInput(): EksPropertiesPodPropertiesInitContainersSecurityContextProperty | undefined;
        private _volumeMounts;
        get volumeMounts(): EksPropertiesPodPropertiesInitContainersVolumeMountsPropertyList;
        putVolumeMounts(value: EksPropertiesPodPropertiesInitContainersVolumeMountsProperty[] | cdktn.IResolvable): void;
        resetVolumeMounts(): void;
        get volumeMountsInput(): cdktn.IResolvable | EksPropertiesPodPropertiesInitContainersVolumeMountsProperty[] | undefined;
    }
    class InitContainersPropertyList extends cdktn.ComplexList {
        internalValue?: InitContainersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InitContainersPropertyOutputReference;
    }
    interface MetadataProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#labels TfJobDefinition#labels}
        */
        readonly labels?: {
            [key: string]: string;
        };
    }
    class MetadataPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MetadataProperty | undefined;
        set internalValue(value: MetadataProperty | undefined);
        private _labels?;
        get labels(): {
            [key: string]: string;
        };
        set labels(value: {
            [key: string]: string;
        });
        resetLabels(): void;
        get labelsInput(): {
            [key: string]: string;
        } | undefined;
    }
    interface EmptyDirProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#medium TfJobDefinition#medium}
        */
        readonly medium?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#size_limit TfJobDefinition#size_limit}
        */
        readonly sizeLimit: string;
    }
    class EmptyDirPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EmptyDirProperty | undefined;
        set internalValue(value: EmptyDirProperty | undefined);
        private _medium?;
        get medium(): string;
        set medium(value: string);
        resetMedium(): void;
        get mediumInput(): string | undefined;
        private _sizeLimit?;
        get sizeLimit(): string;
        set sizeLimit(value: string);
        get sizeLimitInput(): string | undefined;
    }
    interface HostPathProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#path TfJobDefinition#path}
        */
        readonly path: string;
    }
    class HostPathPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HostPathProperty | undefined;
        set internalValue(value: HostPathProperty | undefined);
        private _path?;
        get path(): string;
        set path(value: string);
        get pathInput(): string | undefined;
    }
    interface SecretProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#optional TfJobDefinition#optional}
        */
        readonly optional?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#secret_name TfJobDefinition#secret_name}
        */
        readonly secretName: string;
    }
    class SecretPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SecretProperty | undefined;
        set internalValue(value: SecretProperty | undefined);
        private _optional?;
        get optional(): boolean | cdktn.IResolvable;
        set optional(value: boolean | cdktn.IResolvable);
        resetOptional(): void;
        get optionalInput(): boolean | cdktn.IResolvable | undefined;
        private _secretName?;
        get secretName(): string;
        set secretName(value: string);
        get secretNameInput(): string | undefined;
    }
    interface VolumesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#name TfJobDefinition#name}
        */
        readonly name?: string;
        /**
        * empty_dir block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#empty_dir TfJobDefinition#empty_dir}
        */
        readonly emptyDir?: EmptyDirProperty;
        /**
        * host_path block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#host_path TfJobDefinition#host_path}
        */
        readonly hostPath?: HostPathProperty;
        /**
        * secret block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#secret TfJobDefinition#secret}
        */
        readonly secret?: SecretProperty;
    }
    class VolumesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VolumesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VolumesProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _emptyDir;
        get emptyDir(): EmptyDirPropertyOutputReference;
        putEmptyDir(value: EmptyDirProperty): void;
        resetEmptyDir(): void;
        get emptyDirInput(): EmptyDirProperty | undefined;
        private _hostPath;
        get hostPath(): HostPathPropertyOutputReference;
        putHostPath(value: HostPathProperty): void;
        resetHostPath(): void;
        get hostPathInput(): HostPathProperty | undefined;
        private _secret;
        get secret(): SecretPropertyOutputReference;
        putSecret(value: SecretProperty): void;
        resetSecret(): void;
        get secretInput(): SecretProperty | undefined;
    }
    class VolumesPropertyList extends cdktn.ComplexList {
        internalValue?: VolumesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VolumesPropertyOutputReference;
    }
    interface PodPropertiesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#dns_policy TfJobDefinition#dns_policy}
        */
        readonly dnsPolicy?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#host_network TfJobDefinition#host_network}
        */
        readonly hostNetwork?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#service_account_name TfJobDefinition#service_account_name}
        */
        readonly serviceAccountName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#share_process_namespace TfJobDefinition#share_process_namespace}
        */
        readonly shareProcessNamespace?: boolean | cdktn.IResolvable;
        /**
        * containers block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#containers TfJobDefinition#containers}
        */
        readonly containers: ContainersProperty[] | cdktn.IResolvable;
        /**
        * image_pull_secret block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#image_pull_secret TfJobDefinition#image_pull_secret}
        */
        readonly imagePullSecret?: ImagePullSecretProperty[] | cdktn.IResolvable;
        /**
        * init_containers block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#init_containers TfJobDefinition#init_containers}
        */
        readonly initContainers?: InitContainersProperty[] | cdktn.IResolvable;
        /**
        * metadata block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#metadata TfJobDefinition#metadata}
        */
        readonly metadata?: MetadataProperty;
        /**
        * volumes block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#volumes TfJobDefinition#volumes}
        */
        readonly volumes?: VolumesProperty[] | cdktn.IResolvable;
    }
    class PodPropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PodPropertiesProperty | undefined;
        set internalValue(value: PodPropertiesProperty | undefined);
        private _dnsPolicy?;
        get dnsPolicy(): string;
        set dnsPolicy(value: string);
        resetDnsPolicy(): void;
        get dnsPolicyInput(): string | undefined;
        private _hostNetwork?;
        get hostNetwork(): boolean | cdktn.IResolvable;
        set hostNetwork(value: boolean | cdktn.IResolvable);
        resetHostNetwork(): void;
        get hostNetworkInput(): boolean | cdktn.IResolvable | undefined;
        private _serviceAccountName?;
        get serviceAccountName(): string;
        set serviceAccountName(value: string);
        resetServiceAccountName(): void;
        get serviceAccountNameInput(): string | undefined;
        private _shareProcessNamespace?;
        get shareProcessNamespace(): boolean | cdktn.IResolvable;
        set shareProcessNamespace(value: boolean | cdktn.IResolvable);
        resetShareProcessNamespace(): void;
        get shareProcessNamespaceInput(): boolean | cdktn.IResolvable | undefined;
        private _containers;
        get containers(): ContainersPropertyList;
        putContainers(value: ContainersProperty[] | cdktn.IResolvable): void;
        get containersInput(): cdktn.IResolvable | ContainersProperty[] | undefined;
        private _imagePullSecret;
        get imagePullSecret(): ImagePullSecretPropertyList;
        putImagePullSecret(value: ImagePullSecretProperty[] | cdktn.IResolvable): void;
        resetImagePullSecret(): void;
        get imagePullSecretInput(): cdktn.IResolvable | ImagePullSecretProperty[] | undefined;
        private _initContainers;
        get initContainers(): InitContainersPropertyList;
        putInitContainers(value: InitContainersProperty[] | cdktn.IResolvable): void;
        resetInitContainers(): void;
        get initContainersInput(): cdktn.IResolvable | InitContainersProperty[] | undefined;
        private _metadata;
        get metadata(): MetadataPropertyOutputReference;
        putMetadata(value: MetadataProperty): void;
        resetMetadata(): void;
        get metadataInput(): MetadataProperty | undefined;
        private _volumes;
        get volumes(): VolumesPropertyList;
        putVolumes(value: VolumesProperty[] | cdktn.IResolvable): void;
        resetVolumes(): void;
        get volumesInput(): cdktn.IResolvable | VolumesProperty[] | undefined;
    }
    interface EksPropertiesProperty {
        /**
        * pod_properties block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#pod_properties TfJobDefinition#pod_properties}
        */
        readonly podProperties: PodPropertiesProperty;
    }
    class EksPropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EksPropertiesProperty | undefined;
        set internalValue(value: EksPropertiesProperty | undefined);
        private _podProperties;
        get podProperties(): PodPropertiesPropertyOutputReference;
        putPodProperties(value: PodPropertiesProperty): void;
        get podPropertiesInput(): PodPropertiesProperty | undefined;
    }
    interface EvaluateOnExitProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#action TfJobDefinition#action}
        */
        readonly action: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#on_exit_code TfJobDefinition#on_exit_code}
        */
        readonly onExitCode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#on_reason TfJobDefinition#on_reason}
        */
        readonly onReason?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#on_status_reason TfJobDefinition#on_status_reason}
        */
        readonly onStatusReason?: string;
    }
    class EvaluateOnExitPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EvaluateOnExitProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EvaluateOnExitProperty | cdktn.IResolvable | undefined);
        private _action?;
        get action(): string;
        set action(value: string);
        get actionInput(): string | undefined;
        private _onExitCode?;
        get onExitCode(): string;
        set onExitCode(value: string);
        resetOnExitCode(): void;
        get onExitCodeInput(): string | undefined;
        private _onReason?;
        get onReason(): string;
        set onReason(value: string);
        resetOnReason(): void;
        get onReasonInput(): string | undefined;
        private _onStatusReason?;
        get onStatusReason(): string;
        set onStatusReason(value: string);
        resetOnStatusReason(): void;
        get onStatusReasonInput(): string | undefined;
    }
    class EvaluateOnExitPropertyList extends cdktn.ComplexList {
        internalValue?: EvaluateOnExitProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EvaluateOnExitPropertyOutputReference;
    }
    interface RetryStrategyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#attempts TfJobDefinition#attempts}
        */
        readonly attempts?: number;
        /**
        * evaluate_on_exit block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#evaluate_on_exit TfJobDefinition#evaluate_on_exit}
        */
        readonly evaluateOnExit?: EvaluateOnExitProperty[] | cdktn.IResolvable;
    }
    class RetryStrategyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RetryStrategyProperty | undefined;
        set internalValue(value: RetryStrategyProperty | undefined);
        private _attempts?;
        get attempts(): number;
        set attempts(value: number);
        resetAttempts(): void;
        get attemptsInput(): number | undefined;
        private _evaluateOnExit;
        get evaluateOnExit(): EvaluateOnExitPropertyList;
        putEvaluateOnExit(value: EvaluateOnExitProperty[] | cdktn.IResolvable): void;
        resetEvaluateOnExit(): void;
        get evaluateOnExitInput(): cdktn.IResolvable | EvaluateOnExitProperty[] | undefined;
    }
    interface TimeoutProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#attempt_duration_seconds TfJobDefinition#attempt_duration_seconds}
        */
        readonly attemptDurationSeconds?: number;
    }
    class TimeoutPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutProperty | undefined;
        set internalValue(value: TimeoutProperty | undefined);
        private _attemptDurationSeconds?;
        get attemptDurationSeconds(): number;
        set attemptDurationSeconds(value: number);
        resetAttemptDurationSeconds(): void;
        get attemptDurationSecondsInput(): number | undefined;
    }
}
