import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfJobQueueConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_queue#name TfJobQueue#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_queue#priority TfJobQueue#priority}
    */
    readonly priority: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_queue#region TfJobQueue#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_queue#scheduling_policy_arn TfJobQueue#scheduling_policy_arn}
    */
    readonly schedulingPolicyArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_queue#state TfJobQueue#state}
    */
    readonly state: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_queue#tags TfJobQueue#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * compute_environment_order block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_queue#compute_environment_order TfJobQueue#compute_environment_order}
    */
    readonly computeEnvironmentOrder?: TfJobQueue.ComputeEnvironmentOrderProperty[] | cdktn.IResolvable;
    /**
    * job_state_time_limit_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_queue#job_state_time_limit_action TfJobQueue#job_state_time_limit_action}
    */
    readonly jobStateTimeLimitAction?: TfJobQueue.JobStateTimeLimitActionProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_queue#timeouts TfJobQueue#timeouts}
    */
    readonly timeouts?: TfJobQueue.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_queue aws_batch_job_queue}
*/
export declare class TfJobQueue extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_batch_job_queue";
    /**
    * Generates CDKTN code for importing a TfJobQueue resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfJobQueue to import
    * @param importFromId The id of the existing TfJobQueue that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_queue#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfJobQueue to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_queue aws_batch_job_queue} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfJobQueueConfig
    */
    constructor(scope: Construct, id: string, config: TfJobQueueConfig);
    get arn(): string;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    get priorityInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _schedulingPolicyArn?;
    get schedulingPolicyArn(): string;
    set schedulingPolicyArn(value: string);
    resetSchedulingPolicyArn(): void;
    get schedulingPolicyArnInput(): string | undefined;
    private _state?;
    get state(): string;
    set state(value: string);
    get stateInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _computeEnvironmentOrder;
    get computeEnvironmentOrder(): TfJobQueue.ComputeEnvironmentOrderPropertyList;
    putComputeEnvironmentOrder(value: TfJobQueue.ComputeEnvironmentOrderProperty[] | cdktn.IResolvable): void;
    resetComputeEnvironmentOrder(): void;
    get computeEnvironmentOrderInput(): cdktn.IResolvable | TfJobQueue.ComputeEnvironmentOrderProperty[] | undefined;
    private _jobStateTimeLimitAction;
    get jobStateTimeLimitAction(): TfJobQueue.JobStateTimeLimitActionPropertyList;
    putJobStateTimeLimitAction(value: TfJobQueue.JobStateTimeLimitActionProperty[] | cdktn.IResolvable): void;
    resetJobStateTimeLimitAction(): void;
    get jobStateTimeLimitActionInput(): cdktn.IResolvable | TfJobQueue.JobStateTimeLimitActionProperty[] | undefined;
    private _timeouts;
    get timeouts(): TfJobQueue.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfJobQueue.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfJobQueue.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfJobQueueComputeEnvironmentOrderPropertyToTerraform(struct?: TfJobQueue.ComputeEnvironmentOrderProperty | cdktn.IResolvable): any;
export declare function tfJobQueueComputeEnvironmentOrderPropertyToHclTerraform(struct?: TfJobQueue.ComputeEnvironmentOrderProperty | cdktn.IResolvable): any;
export declare function tfJobQueueJobStateTimeLimitActionPropertyToTerraform(struct?: TfJobQueue.JobStateTimeLimitActionProperty | cdktn.IResolvable): any;
export declare function tfJobQueueJobStateTimeLimitActionPropertyToHclTerraform(struct?: TfJobQueue.JobStateTimeLimitActionProperty | cdktn.IResolvable): any;
export declare function tfJobQueueTimeoutsPropertyToTerraform(struct?: TfJobQueue.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfJobQueueTimeoutsPropertyToHclTerraform(struct?: TfJobQueue.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfJobQueue {
    interface ComputeEnvironmentOrderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_queue#compute_environment TfJobQueue#compute_environment}
        */
        readonly computeEnvironment: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_queue#order TfJobQueue#order}
        */
        readonly order: number;
    }
    class ComputeEnvironmentOrderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ComputeEnvironmentOrderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ComputeEnvironmentOrderProperty | cdktn.IResolvable | undefined);
        private _computeEnvironment?;
        get computeEnvironment(): string;
        set computeEnvironment(value: string);
        get computeEnvironmentInput(): string | undefined;
        private _order?;
        get order(): number;
        set order(value: number);
        get orderInput(): number | undefined;
    }
    class ComputeEnvironmentOrderPropertyList extends cdktn.ComplexList {
        internalValue?: ComputeEnvironmentOrderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ComputeEnvironmentOrderPropertyOutputReference;
    }
    interface JobStateTimeLimitActionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_queue#action TfJobQueue#action}
        */
        readonly action: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_queue#max_time_seconds TfJobQueue#max_time_seconds}
        */
        readonly maxTimeSeconds: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_queue#reason TfJobQueue#reason}
        */
        readonly reason: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_queue#state TfJobQueue#state}
        */
        readonly state: string;
    }
    class JobStateTimeLimitActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): JobStateTimeLimitActionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: JobStateTimeLimitActionProperty | cdktn.IResolvable | undefined);
        private _action?;
        get action(): string;
        set action(value: string);
        get actionInput(): string | undefined;
        private _maxTimeSeconds?;
        get maxTimeSeconds(): number;
        set maxTimeSeconds(value: number);
        get maxTimeSecondsInput(): number | undefined;
        private _reason?;
        get reason(): string;
        set reason(value: string);
        get reasonInput(): string | undefined;
        private _state?;
        get state(): string;
        set state(value: string);
        get stateInput(): string | undefined;
    }
    class JobStateTimeLimitActionPropertyList extends cdktn.ComplexList {
        internalValue?: JobStateTimeLimitActionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): JobStateTimeLimitActionPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_queue#create TfJobQueue#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_queue#delete TfJobQueue#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_queue#update TfJobQueue#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
