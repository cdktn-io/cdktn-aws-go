import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfComputeEnvironmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_compute_environment#id TfComputeEnvironment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_compute_environment#name TfComputeEnvironment#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_compute_environment#name_prefix TfComputeEnvironment#name_prefix}
    */
    readonly namePrefix?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_compute_environment#region TfComputeEnvironment#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_compute_environment#service_role TfComputeEnvironment#service_role}
    */
    readonly serviceRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_compute_environment#state TfComputeEnvironment#state}
    */
    readonly state?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_compute_environment#tags TfComputeEnvironment#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_compute_environment#tags_all TfComputeEnvironment#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_compute_environment#type TfComputeEnvironment#type}
    */
    readonly type: string;
    /**
    * compute_resources block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_compute_environment#compute_resources TfComputeEnvironment#compute_resources}
    */
    readonly computeResources?: TfComputeEnvironment.ComputeResourcesProperty;
    /**
    * eks_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_compute_environment#eks_configuration TfComputeEnvironment#eks_configuration}
    */
    readonly eksConfiguration?: TfComputeEnvironment.EksConfigurationProperty;
    /**
    * update_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_compute_environment#update_policy TfComputeEnvironment#update_policy}
    */
    readonly updatePolicy?: TfComputeEnvironment.UpdatePolicyProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_compute_environment aws_batch_compute_environment}
*/
export declare class TfComputeEnvironment extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_batch_compute_environment";
    /**
    * Generates CDKTN code for importing a TfComputeEnvironment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfComputeEnvironment to import
    * @param importFromId The id of the existing TfComputeEnvironment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_compute_environment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfComputeEnvironment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_compute_environment aws_batch_compute_environment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfComputeEnvironmentConfig
    */
    constructor(scope: Construct, id: string, config: TfComputeEnvironmentConfig);
    get arn(): string;
    get ecsClusterArn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namePrefix?;
    get namePrefix(): string;
    set namePrefix(value: string);
    resetNamePrefix(): void;
    get namePrefixInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _serviceRole?;
    get serviceRole(): string;
    set serviceRole(value: string);
    resetServiceRole(): void;
    get serviceRoleInput(): string | undefined;
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
    get status(): string;
    get statusReason(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _computeResources;
    get computeResources(): TfComputeEnvironment.ComputeResourcesPropertyOutputReference;
    putComputeResources(value: TfComputeEnvironment.ComputeResourcesProperty): void;
    resetComputeResources(): void;
    get computeResourcesInput(): TfComputeEnvironment.ComputeResourcesProperty | undefined;
    private _eksConfiguration;
    get eksConfiguration(): TfComputeEnvironment.EksConfigurationPropertyOutputReference;
    putEksConfiguration(value: TfComputeEnvironment.EksConfigurationProperty): void;
    resetEksConfiguration(): void;
    get eksConfigurationInput(): TfComputeEnvironment.EksConfigurationProperty | undefined;
    private _updatePolicy;
    get updatePolicy(): TfComputeEnvironment.UpdatePolicyPropertyOutputReference;
    putUpdatePolicy(value: TfComputeEnvironment.UpdatePolicyProperty): void;
    resetUpdatePolicy(): void;
    get updatePolicyInput(): TfComputeEnvironment.UpdatePolicyProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfComputeEnvironmentEc2ConfigurationPropertyToTerraform(struct?: TfComputeEnvironment.Ec2ConfigurationProperty | cdktn.IResolvable): any;
export declare function tfComputeEnvironmentEc2ConfigurationPropertyToHclTerraform(struct?: TfComputeEnvironment.Ec2ConfigurationProperty | cdktn.IResolvable): any;
export declare function tfComputeEnvironmentLaunchTemplatePropertyToTerraform(struct?: TfComputeEnvironment.LaunchTemplatePropertyOutputReference | TfComputeEnvironment.LaunchTemplateProperty): any;
export declare function tfComputeEnvironmentLaunchTemplatePropertyToHclTerraform(struct?: TfComputeEnvironment.LaunchTemplatePropertyOutputReference | TfComputeEnvironment.LaunchTemplateProperty): any;
export declare function tfComputeEnvironmentComputeResourcesPropertyToTerraform(struct?: TfComputeEnvironment.ComputeResourcesPropertyOutputReference | TfComputeEnvironment.ComputeResourcesProperty): any;
export declare function tfComputeEnvironmentComputeResourcesPropertyToHclTerraform(struct?: TfComputeEnvironment.ComputeResourcesPropertyOutputReference | TfComputeEnvironment.ComputeResourcesProperty): any;
export declare function tfComputeEnvironmentEksConfigurationPropertyToTerraform(struct?: TfComputeEnvironment.EksConfigurationPropertyOutputReference | TfComputeEnvironment.EksConfigurationProperty): any;
export declare function tfComputeEnvironmentEksConfigurationPropertyToHclTerraform(struct?: TfComputeEnvironment.EksConfigurationPropertyOutputReference | TfComputeEnvironment.EksConfigurationProperty): any;
export declare function tfComputeEnvironmentUpdatePolicyPropertyToTerraform(struct?: TfComputeEnvironment.UpdatePolicyPropertyOutputReference | TfComputeEnvironment.UpdatePolicyProperty): any;
export declare function tfComputeEnvironmentUpdatePolicyPropertyToHclTerraform(struct?: TfComputeEnvironment.UpdatePolicyPropertyOutputReference | TfComputeEnvironment.UpdatePolicyProperty): any;
export declare namespace TfComputeEnvironment {
    interface Ec2ConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_compute_environment#image_id_override TfComputeEnvironment#image_id_override}
        */
        readonly imageIdOverride?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_compute_environment#image_kubernetes_version TfComputeEnvironment#image_kubernetes_version}
        */
        readonly imageKubernetesVersion?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_compute_environment#image_type TfComputeEnvironment#image_type}
        */
        readonly imageType?: string;
    }
    class Ec2ConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): Ec2ConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: Ec2ConfigurationProperty | cdktn.IResolvable | undefined);
        private _imageIdOverride?;
        get imageIdOverride(): string;
        set imageIdOverride(value: string);
        resetImageIdOverride(): void;
        get imageIdOverrideInput(): string | undefined;
        private _imageKubernetesVersion?;
        get imageKubernetesVersion(): string;
        set imageKubernetesVersion(value: string);
        resetImageKubernetesVersion(): void;
        get imageKubernetesVersionInput(): string | undefined;
        private _imageType?;
        get imageType(): string;
        set imageType(value: string);
        resetImageType(): void;
        get imageTypeInput(): string | undefined;
    }
    class Ec2ConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: Ec2ConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): Ec2ConfigurationPropertyOutputReference;
    }
    interface LaunchTemplateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_compute_environment#launch_template_id TfComputeEnvironment#launch_template_id}
        */
        readonly launchTemplateId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_compute_environment#launch_template_name TfComputeEnvironment#launch_template_name}
        */
        readonly launchTemplateName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_compute_environment#version TfComputeEnvironment#version}
        */
        readonly version?: string;
    }
    class LaunchTemplatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LaunchTemplateProperty | undefined;
        set internalValue(value: LaunchTemplateProperty | undefined);
        private _launchTemplateId?;
        get launchTemplateId(): string;
        set launchTemplateId(value: string);
        resetLaunchTemplateId(): void;
        get launchTemplateIdInput(): string | undefined;
        private _launchTemplateName?;
        get launchTemplateName(): string;
        set launchTemplateName(value: string);
        resetLaunchTemplateName(): void;
        get launchTemplateNameInput(): string | undefined;
        private _version?;
        get version(): string;
        set version(value: string);
        resetVersion(): void;
        get versionInput(): string | undefined;
    }
    interface ComputeResourcesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_compute_environment#allocation_strategy TfComputeEnvironment#allocation_strategy}
        */
        readonly allocationStrategy?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_compute_environment#bid_percentage TfComputeEnvironment#bid_percentage}
        */
        readonly bidPercentage?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_compute_environment#desired_vcpus TfComputeEnvironment#desired_vcpus}
        */
        readonly desiredVcpus?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_compute_environment#ec2_key_pair TfComputeEnvironment#ec2_key_pair}
        */
        readonly ec2KeyPair?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_compute_environment#image_id TfComputeEnvironment#image_id}
        */
        readonly imageId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_compute_environment#instance_role TfComputeEnvironment#instance_role}
        */
        readonly instanceRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_compute_environment#instance_type TfComputeEnvironment#instance_type}
        */
        readonly instanceType?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_compute_environment#max_vcpus TfComputeEnvironment#max_vcpus}
        */
        readonly maxVcpus: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_compute_environment#min_vcpus TfComputeEnvironment#min_vcpus}
        */
        readonly minVcpus?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_compute_environment#placement_group TfComputeEnvironment#placement_group}
        */
        readonly placementGroup?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_compute_environment#security_group_ids TfComputeEnvironment#security_group_ids}
        */
        readonly securityGroupIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_compute_environment#spot_iam_fleet_role TfComputeEnvironment#spot_iam_fleet_role}
        */
        readonly spotIamFleetRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_compute_environment#subnets TfComputeEnvironment#subnets}
        */
        readonly subnets: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_compute_environment#tags TfComputeEnvironment#tags}
        */
        readonly tags?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_compute_environment#type TfComputeEnvironment#type}
        */
        readonly type: string;
        /**
        * ec2_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_compute_environment#ec2_configuration TfComputeEnvironment#ec2_configuration}
        */
        readonly ec2Configuration?: Ec2ConfigurationProperty[] | cdktn.IResolvable;
        /**
        * launch_template block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_compute_environment#launch_template TfComputeEnvironment#launch_template}
        */
        readonly launchTemplate?: LaunchTemplateProperty;
    }
    class ComputeResourcesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ComputeResourcesProperty | undefined;
        set internalValue(value: ComputeResourcesProperty | undefined);
        private _allocationStrategy?;
        get allocationStrategy(): string;
        set allocationStrategy(value: string);
        resetAllocationStrategy(): void;
        get allocationStrategyInput(): string | undefined;
        private _bidPercentage?;
        get bidPercentage(): number;
        set bidPercentage(value: number);
        resetBidPercentage(): void;
        get bidPercentageInput(): number | undefined;
        private _desiredVcpus?;
        get desiredVcpus(): number;
        set desiredVcpus(value: number);
        resetDesiredVcpus(): void;
        get desiredVcpusInput(): number | undefined;
        private _ec2KeyPair?;
        get ec2KeyPair(): string;
        set ec2KeyPair(value: string);
        resetEc2KeyPair(): void;
        get ec2KeyPairInput(): string | undefined;
        private _imageId?;
        get imageId(): string;
        set imageId(value: string);
        resetImageId(): void;
        get imageIdInput(): string | undefined;
        private _instanceRole?;
        get instanceRole(): string;
        set instanceRole(value: string);
        resetInstanceRole(): void;
        get instanceRoleInput(): string | undefined;
        private _instanceType?;
        get instanceType(): string[];
        set instanceType(value: string[]);
        resetInstanceType(): void;
        get instanceTypeInput(): string[] | undefined;
        private _maxVcpus?;
        get maxVcpus(): number;
        set maxVcpus(value: number);
        get maxVcpusInput(): number | undefined;
        private _minVcpus?;
        get minVcpus(): number;
        set minVcpus(value: number);
        resetMinVcpus(): void;
        get minVcpusInput(): number | undefined;
        private _placementGroup?;
        get placementGroup(): string;
        set placementGroup(value: string);
        resetPlacementGroup(): void;
        get placementGroupInput(): string | undefined;
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        resetSecurityGroupIds(): void;
        get securityGroupIdsInput(): string[] | undefined;
        private _spotIamFleetRole?;
        get spotIamFleetRole(): string;
        set spotIamFleetRole(value: string);
        resetSpotIamFleetRole(): void;
        get spotIamFleetRoleInput(): string | undefined;
        private _subnets?;
        get subnets(): string[];
        set subnets(value: string[]);
        get subnetsInput(): string[] | undefined;
        private _tags?;
        get tags(): {
            [key: string]: string;
        };
        set tags(value: {
            [key: string]: string;
        });
        resetTags(): void;
        get tagsInput(): {
            [key: string]: string;
        } | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _ec2Configuration;
        get ec2Configuration(): Ec2ConfigurationPropertyList;
        putEc2Configuration(value: Ec2ConfigurationProperty[] | cdktn.IResolvable): void;
        resetEc2Configuration(): void;
        get ec2ConfigurationInput(): cdktn.IResolvable | Ec2ConfigurationProperty[] | undefined;
        private _launchTemplate;
        get launchTemplate(): LaunchTemplatePropertyOutputReference;
        putLaunchTemplate(value: LaunchTemplateProperty): void;
        resetLaunchTemplate(): void;
        get launchTemplateInput(): LaunchTemplateProperty | undefined;
    }
    interface EksConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_compute_environment#eks_cluster_arn TfComputeEnvironment#eks_cluster_arn}
        */
        readonly eksClusterArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_compute_environment#kubernetes_namespace TfComputeEnvironment#kubernetes_namespace}
        */
        readonly kubernetesNamespace: string;
    }
    class EksConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EksConfigurationProperty | undefined;
        set internalValue(value: EksConfigurationProperty | undefined);
        private _eksClusterArn?;
        get eksClusterArn(): string;
        set eksClusterArn(value: string);
        get eksClusterArnInput(): string | undefined;
        private _kubernetesNamespace?;
        get kubernetesNamespace(): string;
        set kubernetesNamespace(value: string);
        get kubernetesNamespaceInput(): string | undefined;
    }
    interface UpdatePolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_compute_environment#job_execution_timeout_minutes TfComputeEnvironment#job_execution_timeout_minutes}
        */
        readonly jobExecutionTimeoutMinutes?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_compute_environment#terminate_jobs_on_update TfComputeEnvironment#terminate_jobs_on_update}
        */
        readonly terminateJobsOnUpdate?: boolean | cdktn.IResolvable;
    }
    class UpdatePolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UpdatePolicyProperty | undefined;
        set internalValue(value: UpdatePolicyProperty | undefined);
        private _jobExecutionTimeoutMinutes?;
        get jobExecutionTimeoutMinutes(): number;
        set jobExecutionTimeoutMinutes(value: number);
        resetJobExecutionTimeoutMinutes(): void;
        get jobExecutionTimeoutMinutesInput(): number | undefined;
        private _terminateJobsOnUpdate?;
        get terminateJobsOnUpdate(): boolean | cdktn.IResolvable;
        set terminateJobsOnUpdate(value: boolean | cdktn.IResolvable);
        resetTerminateJobsOnUpdate(): void;
        get terminateJobsOnUpdateInput(): boolean | cdktn.IResolvable | undefined;
    }
}
