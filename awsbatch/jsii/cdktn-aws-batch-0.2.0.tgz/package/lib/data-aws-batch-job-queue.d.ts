import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfJobQueueConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/batch_job_queue#id DataTfJobQueue#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/batch_job_queue#name DataTfJobQueue#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/batch_job_queue#region DataTfJobQueue#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/batch_job_queue#tags DataTfJobQueue#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/batch_job_queue aws_batch_job_queue}
*/
export declare class DataTfJobQueue extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_batch_job_queue";
    /**
    * Generates CDKTN code for importing a DataTfJobQueue resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfJobQueue to import
    * @param importFromId The id of the existing DataTfJobQueue that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/batch_job_queue#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfJobQueue to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/batch_job_queue aws_batch_job_queue} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfJobQueueConfig
    */
    constructor(scope: Construct, id: string, config: DataTfJobQueueConfig);
    get arn(): string;
    private _computeEnvironmentOrder;
    get computeEnvironmentOrder(): DataTfJobQueue.ComputeEnvironmentOrderPropertyList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _jobStateTimeLimitAction;
    get jobStateTimeLimitAction(): DataTfJobQueue.JobStateTimeLimitActionPropertyList;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get priority(): number;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get schedulingPolicyArn(): string;
    get state(): string;
    get status(): string;
    get statusReason(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfJobQueueComputeEnvironmentOrderPropertyToTerraform(struct?: DataTfJobQueue.ComputeEnvironmentOrderProperty): any;
export declare function dataTfJobQueueComputeEnvironmentOrderPropertyToHclTerraform(struct?: DataTfJobQueue.ComputeEnvironmentOrderProperty): any;
export declare function dataTfJobQueueJobStateTimeLimitActionPropertyToTerraform(struct?: DataTfJobQueue.JobStateTimeLimitActionProperty): any;
export declare function dataTfJobQueueJobStateTimeLimitActionPropertyToHclTerraform(struct?: DataTfJobQueue.JobStateTimeLimitActionProperty): any;
export declare namespace DataTfJobQueue {
    interface ComputeEnvironmentOrderProperty {
    }
    class ComputeEnvironmentOrderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ComputeEnvironmentOrderProperty | undefined;
        set internalValue(value: ComputeEnvironmentOrderProperty | undefined);
        get computeEnvironment(): string;
        get order(): number;
    }
    class ComputeEnvironmentOrderPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ComputeEnvironmentOrderPropertyOutputReference;
    }
    interface JobStateTimeLimitActionProperty {
    }
    class JobStateTimeLimitActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): JobStateTimeLimitActionProperty | undefined;
        set internalValue(value: JobStateTimeLimitActionProperty | undefined);
        get action(): string;
        get maxTimeSeconds(): number;
        get reason(): string;
        get state(): string;
    }
    class JobStateTimeLimitActionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): JobStateTimeLimitActionPropertyOutputReference;
    }
}
