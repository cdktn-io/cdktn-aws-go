import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsBatchJobDefinitionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/batch_job_definition#arn DataAwsBatchJobDefinition#arn}
    */
    readonly arn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/batch_job_definition#name DataAwsBatchJobDefinition#name}
    */
    readonly name?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/batch_job_definition#region DataAwsBatchJobDefinition#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/batch_job_definition#revision DataAwsBatchJobDefinition#revision}
    */
    readonly revision?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/batch_job_definition#status DataAwsBatchJobDefinition#status}
    */
    readonly status?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/batch_job_definition aws_batch_job_definition}
*/
export declare class DataAwsBatchJobDefinition extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_batch_job_definition";
    /**
    * Generates CDKTN code for importing a DataAwsBatchJobDefinition resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsBatchJobDefinition to import
    * @param importFromId The id of the existing DataAwsBatchJobDefinition that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/batch_job_definition#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsBatchJobDefinition to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/batch_job_definition aws_batch_job_definition} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsBatchJobDefinitionConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsBatchJobDefinitionConfig);
    private _arn?;
    get arn(): string;
    set arn(value: string);
    resetArn(): void;
    get arnInput(): string | undefined;
    get arnPrefix(): string;
    get containerOrchestrationType(): string;
    private _eksProperties;
    get eksProperties(): DataAwsBatchJobDefinition.EksPropertiesPropertyList;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _nodeProperties;
    get nodeProperties(): DataAwsBatchJobDefinition.NodePropertiesPropertyList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _retryStrategy;
    get retryStrategy(): DataAwsBatchJobDefinition.RetryStrategyPropertyList;
    private _revision?;
    get revision(): number;
    set revision(value: number);
    resetRevision(): void;
    get revisionInput(): number | undefined;
    get schedulingPriority(): number;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _tags;
    get tags(): cdktn.StringMap;
    private _timeout;
    get timeout(): DataAwsBatchJobDefinition.TimeoutPropertyList;
    get type(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsBatchJobDefinitionEksPropertiesPodPropertiesContainersEnvPropertyToTerraform(struct?: DataAwsBatchJobDefinition.EksPropertiesPodPropertiesContainersEnvProperty): any;
export declare function dataAwsBatchJobDefinitionEksPropertiesPodPropertiesContainersEnvPropertyToHclTerraform(struct?: DataAwsBatchJobDefinition.EksPropertiesPodPropertiesContainersEnvProperty): any;
export declare function dataAwsBatchJobDefinitionEksPropertiesPodPropertiesContainersResourcesPropertyToTerraform(struct?: DataAwsBatchJobDefinition.EksPropertiesPodPropertiesContainersResourcesProperty): any;
export declare function dataAwsBatchJobDefinitionEksPropertiesPodPropertiesContainersResourcesPropertyToHclTerraform(struct?: DataAwsBatchJobDefinition.EksPropertiesPodPropertiesContainersResourcesProperty): any;
export declare function dataAwsBatchJobDefinitionEksPropertiesPodPropertiesContainersSecurityContextPropertyToTerraform(struct?: DataAwsBatchJobDefinition.EksPropertiesPodPropertiesContainersSecurityContextProperty): any;
export declare function dataAwsBatchJobDefinitionEksPropertiesPodPropertiesContainersSecurityContextPropertyToHclTerraform(struct?: DataAwsBatchJobDefinition.EksPropertiesPodPropertiesContainersSecurityContextProperty): any;
export declare function dataAwsBatchJobDefinitionEksPropertiesPodPropertiesContainersVolumeMountsPropertyToTerraform(struct?: DataAwsBatchJobDefinition.EksPropertiesPodPropertiesContainersVolumeMountsProperty): any;
export declare function dataAwsBatchJobDefinitionEksPropertiesPodPropertiesContainersVolumeMountsPropertyToHclTerraform(struct?: DataAwsBatchJobDefinition.EksPropertiesPodPropertiesContainersVolumeMountsProperty): any;
export declare function dataAwsBatchJobDefinitionContainersPropertyToTerraform(struct?: DataAwsBatchJobDefinition.ContainersProperty): any;
export declare function dataAwsBatchJobDefinitionContainersPropertyToHclTerraform(struct?: DataAwsBatchJobDefinition.ContainersProperty): any;
export declare function dataAwsBatchJobDefinitionImagePullSecretsPropertyToTerraform(struct?: DataAwsBatchJobDefinition.ImagePullSecretsProperty): any;
export declare function dataAwsBatchJobDefinitionImagePullSecretsPropertyToHclTerraform(struct?: DataAwsBatchJobDefinition.ImagePullSecretsProperty): any;
export declare function dataAwsBatchJobDefinitionEksPropertiesPodPropertiesInitContainersEnvPropertyToTerraform(struct?: DataAwsBatchJobDefinition.EksPropertiesPodPropertiesInitContainersEnvProperty): any;
export declare function dataAwsBatchJobDefinitionEksPropertiesPodPropertiesInitContainersEnvPropertyToHclTerraform(struct?: DataAwsBatchJobDefinition.EksPropertiesPodPropertiesInitContainersEnvProperty): any;
export declare function dataAwsBatchJobDefinitionEksPropertiesPodPropertiesInitContainersResourcesPropertyToTerraform(struct?: DataAwsBatchJobDefinition.EksPropertiesPodPropertiesInitContainersResourcesProperty): any;
export declare function dataAwsBatchJobDefinitionEksPropertiesPodPropertiesInitContainersResourcesPropertyToHclTerraform(struct?: DataAwsBatchJobDefinition.EksPropertiesPodPropertiesInitContainersResourcesProperty): any;
export declare function dataAwsBatchJobDefinitionEksPropertiesPodPropertiesInitContainersSecurityContextPropertyToTerraform(struct?: DataAwsBatchJobDefinition.EksPropertiesPodPropertiesInitContainersSecurityContextProperty): any;
export declare function dataAwsBatchJobDefinitionEksPropertiesPodPropertiesInitContainersSecurityContextPropertyToHclTerraform(struct?: DataAwsBatchJobDefinition.EksPropertiesPodPropertiesInitContainersSecurityContextProperty): any;
export declare function dataAwsBatchJobDefinitionEksPropertiesPodPropertiesInitContainersVolumeMountsPropertyToTerraform(struct?: DataAwsBatchJobDefinition.EksPropertiesPodPropertiesInitContainersVolumeMountsProperty): any;
export declare function dataAwsBatchJobDefinitionEksPropertiesPodPropertiesInitContainersVolumeMountsPropertyToHclTerraform(struct?: DataAwsBatchJobDefinition.EksPropertiesPodPropertiesInitContainersVolumeMountsProperty): any;
export declare function dataAwsBatchJobDefinitionInitContainersPropertyToTerraform(struct?: DataAwsBatchJobDefinition.InitContainersProperty): any;
export declare function dataAwsBatchJobDefinitionInitContainersPropertyToHclTerraform(struct?: DataAwsBatchJobDefinition.InitContainersProperty): any;
export declare function dataAwsBatchJobDefinitionMetadataPropertyToTerraform(struct?: DataAwsBatchJobDefinition.MetadataProperty): any;
export declare function dataAwsBatchJobDefinitionMetadataPropertyToHclTerraform(struct?: DataAwsBatchJobDefinition.MetadataProperty): any;
export declare function dataAwsBatchJobDefinitionEmptyDirPropertyToTerraform(struct?: DataAwsBatchJobDefinition.EmptyDirProperty): any;
export declare function dataAwsBatchJobDefinitionEmptyDirPropertyToHclTerraform(struct?: DataAwsBatchJobDefinition.EmptyDirProperty): any;
export declare function dataAwsBatchJobDefinitionHostPathPropertyToTerraform(struct?: DataAwsBatchJobDefinition.HostPathProperty): any;
export declare function dataAwsBatchJobDefinitionHostPathPropertyToHclTerraform(struct?: DataAwsBatchJobDefinition.HostPathProperty): any;
export declare function dataAwsBatchJobDefinitionSecretPropertyToTerraform(struct?: DataAwsBatchJobDefinition.SecretProperty): any;
export declare function dataAwsBatchJobDefinitionSecretPropertyToHclTerraform(struct?: DataAwsBatchJobDefinition.SecretProperty): any;
export declare function dataAwsBatchJobDefinitionEksPropertiesPodPropertiesVolumesPropertyToTerraform(struct?: DataAwsBatchJobDefinition.EksPropertiesPodPropertiesVolumesProperty): any;
export declare function dataAwsBatchJobDefinitionEksPropertiesPodPropertiesVolumesPropertyToHclTerraform(struct?: DataAwsBatchJobDefinition.EksPropertiesPodPropertiesVolumesProperty): any;
export declare function dataAwsBatchJobDefinitionPodPropertiesPropertyToTerraform(struct?: DataAwsBatchJobDefinition.PodPropertiesProperty): any;
export declare function dataAwsBatchJobDefinitionPodPropertiesPropertyToHclTerraform(struct?: DataAwsBatchJobDefinition.PodPropertiesProperty): any;
export declare function dataAwsBatchJobDefinitionEksPropertiesPropertyToTerraform(struct?: DataAwsBatchJobDefinition.EksPropertiesProperty): any;
export declare function dataAwsBatchJobDefinitionEksPropertiesPropertyToHclTerraform(struct?: DataAwsBatchJobDefinition.EksPropertiesProperty): any;
export declare function dataAwsBatchJobDefinitionEnvironmentPropertyToTerraform(struct?: DataAwsBatchJobDefinition.EnvironmentProperty): any;
export declare function dataAwsBatchJobDefinitionEnvironmentPropertyToHclTerraform(struct?: DataAwsBatchJobDefinition.EnvironmentProperty): any;
export declare function dataAwsBatchJobDefinitionEphemeralStoragePropertyToTerraform(struct?: DataAwsBatchJobDefinition.EphemeralStorageProperty): any;
export declare function dataAwsBatchJobDefinitionEphemeralStoragePropertyToHclTerraform(struct?: DataAwsBatchJobDefinition.EphemeralStorageProperty): any;
export declare function dataAwsBatchJobDefinitionFargatePlatformConfigurationPropertyToTerraform(struct?: DataAwsBatchJobDefinition.FargatePlatformConfigurationProperty): any;
export declare function dataAwsBatchJobDefinitionFargatePlatformConfigurationPropertyToHclTerraform(struct?: DataAwsBatchJobDefinition.FargatePlatformConfigurationProperty): any;
export declare function dataAwsBatchJobDefinitionDevicesPropertyToTerraform(struct?: DataAwsBatchJobDefinition.DevicesProperty): any;
export declare function dataAwsBatchJobDefinitionDevicesPropertyToHclTerraform(struct?: DataAwsBatchJobDefinition.DevicesProperty): any;
export declare function dataAwsBatchJobDefinitionTmpfsPropertyToTerraform(struct?: DataAwsBatchJobDefinition.TmpfsProperty): any;
export declare function dataAwsBatchJobDefinitionTmpfsPropertyToHclTerraform(struct?: DataAwsBatchJobDefinition.TmpfsProperty): any;
export declare function dataAwsBatchJobDefinitionLinuxParametersPropertyToTerraform(struct?: DataAwsBatchJobDefinition.LinuxParametersProperty): any;
export declare function dataAwsBatchJobDefinitionLinuxParametersPropertyToHclTerraform(struct?: DataAwsBatchJobDefinition.LinuxParametersProperty): any;
export declare function dataAwsBatchJobDefinitionSecretOptionsPropertyToTerraform(struct?: DataAwsBatchJobDefinition.SecretOptionsProperty): any;
export declare function dataAwsBatchJobDefinitionSecretOptionsPropertyToHclTerraform(struct?: DataAwsBatchJobDefinition.SecretOptionsProperty): any;
export declare function dataAwsBatchJobDefinitionLogConfigurationPropertyToTerraform(struct?: DataAwsBatchJobDefinition.LogConfigurationProperty): any;
export declare function dataAwsBatchJobDefinitionLogConfigurationPropertyToHclTerraform(struct?: DataAwsBatchJobDefinition.LogConfigurationProperty): any;
export declare function dataAwsBatchJobDefinitionMountPointsPropertyToTerraform(struct?: DataAwsBatchJobDefinition.MountPointsProperty): any;
export declare function dataAwsBatchJobDefinitionMountPointsPropertyToHclTerraform(struct?: DataAwsBatchJobDefinition.MountPointsProperty): any;
export declare function dataAwsBatchJobDefinitionNetworkConfigurationPropertyToTerraform(struct?: DataAwsBatchJobDefinition.NetworkConfigurationProperty): any;
export declare function dataAwsBatchJobDefinitionNetworkConfigurationPropertyToHclTerraform(struct?: DataAwsBatchJobDefinition.NetworkConfigurationProperty): any;
export declare function dataAwsBatchJobDefinitionResourceRequirementsPropertyToTerraform(struct?: DataAwsBatchJobDefinition.ResourceRequirementsProperty): any;
export declare function dataAwsBatchJobDefinitionResourceRequirementsPropertyToHclTerraform(struct?: DataAwsBatchJobDefinition.ResourceRequirementsProperty): any;
export declare function dataAwsBatchJobDefinitionRuntimePlatformPropertyToTerraform(struct?: DataAwsBatchJobDefinition.RuntimePlatformProperty): any;
export declare function dataAwsBatchJobDefinitionRuntimePlatformPropertyToHclTerraform(struct?: DataAwsBatchJobDefinition.RuntimePlatformProperty): any;
export declare function dataAwsBatchJobDefinitionSecretsPropertyToTerraform(struct?: DataAwsBatchJobDefinition.SecretsProperty): any;
export declare function dataAwsBatchJobDefinitionSecretsPropertyToHclTerraform(struct?: DataAwsBatchJobDefinition.SecretsProperty): any;
export declare function dataAwsBatchJobDefinitionUlimitsPropertyToTerraform(struct?: DataAwsBatchJobDefinition.UlimitsProperty): any;
export declare function dataAwsBatchJobDefinitionUlimitsPropertyToHclTerraform(struct?: DataAwsBatchJobDefinition.UlimitsProperty): any;
export declare function dataAwsBatchJobDefinitionAuthorizationConfigPropertyToTerraform(struct?: DataAwsBatchJobDefinition.AuthorizationConfigProperty): any;
export declare function dataAwsBatchJobDefinitionAuthorizationConfigPropertyToHclTerraform(struct?: DataAwsBatchJobDefinition.AuthorizationConfigProperty): any;
export declare function dataAwsBatchJobDefinitionEfsVolumeConfigurationPropertyToTerraform(struct?: DataAwsBatchJobDefinition.EfsVolumeConfigurationProperty): any;
export declare function dataAwsBatchJobDefinitionEfsVolumeConfigurationPropertyToHclTerraform(struct?: DataAwsBatchJobDefinition.EfsVolumeConfigurationProperty): any;
export declare function dataAwsBatchJobDefinitionHostPropertyToTerraform(struct?: DataAwsBatchJobDefinition.HostProperty): any;
export declare function dataAwsBatchJobDefinitionHostPropertyToHclTerraform(struct?: DataAwsBatchJobDefinition.HostProperty): any;
export declare function dataAwsBatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesPropertyToTerraform(struct?: DataAwsBatchJobDefinition.NodePropertiesNodeRangePropertiesContainerVolumesProperty): any;
export declare function dataAwsBatchJobDefinitionNodePropertiesNodeRangePropertiesContainerVolumesPropertyToHclTerraform(struct?: DataAwsBatchJobDefinition.NodePropertiesNodeRangePropertiesContainerVolumesProperty): any;
export declare function dataAwsBatchJobDefinitionContainerPropertyToTerraform(struct?: DataAwsBatchJobDefinition.ContainerProperty): any;
export declare function dataAwsBatchJobDefinitionContainerPropertyToHclTerraform(struct?: DataAwsBatchJobDefinition.ContainerProperty): any;
export declare function dataAwsBatchJobDefinitionNodeRangePropertiesPropertyToTerraform(struct?: DataAwsBatchJobDefinition.NodeRangePropertiesProperty): any;
export declare function dataAwsBatchJobDefinitionNodeRangePropertiesPropertyToHclTerraform(struct?: DataAwsBatchJobDefinition.NodeRangePropertiesProperty): any;
export declare function dataAwsBatchJobDefinitionNodePropertiesPropertyToTerraform(struct?: DataAwsBatchJobDefinition.NodePropertiesProperty): any;
export declare function dataAwsBatchJobDefinitionNodePropertiesPropertyToHclTerraform(struct?: DataAwsBatchJobDefinition.NodePropertiesProperty): any;
export declare function dataAwsBatchJobDefinitionEvaluateOnExitPropertyToTerraform(struct?: DataAwsBatchJobDefinition.EvaluateOnExitProperty): any;
export declare function dataAwsBatchJobDefinitionEvaluateOnExitPropertyToHclTerraform(struct?: DataAwsBatchJobDefinition.EvaluateOnExitProperty): any;
export declare function dataAwsBatchJobDefinitionRetryStrategyPropertyToTerraform(struct?: DataAwsBatchJobDefinition.RetryStrategyProperty): any;
export declare function dataAwsBatchJobDefinitionRetryStrategyPropertyToHclTerraform(struct?: DataAwsBatchJobDefinition.RetryStrategyProperty): any;
export declare function dataAwsBatchJobDefinitionTimeoutPropertyToTerraform(struct?: DataAwsBatchJobDefinition.TimeoutProperty): any;
export declare function dataAwsBatchJobDefinitionTimeoutPropertyToHclTerraform(struct?: DataAwsBatchJobDefinition.TimeoutProperty): any;
export declare namespace DataAwsBatchJobDefinition {
    interface EksPropertiesPodPropertiesContainersEnvProperty {
    }
    class EksPropertiesPodPropertiesContainersEnvPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EksPropertiesPodPropertiesContainersEnvProperty | undefined;
        set internalValue(value: EksPropertiesPodPropertiesContainersEnvProperty | undefined);
        get name(): string;
        get value(): string;
    }
    class EksPropertiesPodPropertiesContainersEnvPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EksPropertiesPodPropertiesContainersEnvPropertyOutputReference;
    }
    interface EksPropertiesPodPropertiesContainersResourcesProperty {
    }
    class EksPropertiesPodPropertiesContainersResourcesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EksPropertiesPodPropertiesContainersResourcesProperty | undefined;
        set internalValue(value: EksPropertiesPodPropertiesContainersResourcesProperty | undefined);
        private _limits;
        get limits(): cdktn.StringMap;
        private _requests;
        get requests(): cdktn.StringMap;
    }
    class EksPropertiesPodPropertiesContainersResourcesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EksPropertiesPodPropertiesContainersResourcesPropertyOutputReference;
    }
    interface EksPropertiesPodPropertiesContainersSecurityContextProperty {
    }
    class EksPropertiesPodPropertiesContainersSecurityContextPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EksPropertiesPodPropertiesContainersSecurityContextProperty | undefined;
        set internalValue(value: EksPropertiesPodPropertiesContainersSecurityContextProperty | undefined);
        get allowPrivilegeEscalation(): cdktn.IResolvable;
        get privileged(): cdktn.IResolvable;
        get readOnlyRootFileSystem(): cdktn.IResolvable;
        get runAsGroup(): number;
        get runAsNonRoot(): cdktn.IResolvable;
        get runAsUser(): number;
    }
    class EksPropertiesPodPropertiesContainersSecurityContextPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EksPropertiesPodPropertiesContainersSecurityContextPropertyOutputReference;
    }
    interface EksPropertiesPodPropertiesContainersVolumeMountsProperty {
    }
    class EksPropertiesPodPropertiesContainersVolumeMountsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EksPropertiesPodPropertiesContainersVolumeMountsProperty | undefined;
        set internalValue(value: EksPropertiesPodPropertiesContainersVolumeMountsProperty | undefined);
        get mountPath(): string;
        get name(): string;
        get readOnly(): cdktn.IResolvable;
    }
    class EksPropertiesPodPropertiesContainersVolumeMountsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EksPropertiesPodPropertiesContainersVolumeMountsPropertyOutputReference;
    }
    interface ContainersProperty {
    }
    class ContainersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ContainersProperty | undefined;
        set internalValue(value: ContainersProperty | undefined);
        get args(): string[];
        get command(): string[];
        private _env;
        get env(): EksPropertiesPodPropertiesContainersEnvPropertyList;
        get image(): string;
        get imagePullPolicy(): string;
        get name(): string;
        private _resources;
        get resources(): EksPropertiesPodPropertiesContainersResourcesPropertyList;
        private _securityContext;
        get securityContext(): EksPropertiesPodPropertiesContainersSecurityContextPropertyList;
        private _volumeMounts;
        get volumeMounts(): EksPropertiesPodPropertiesContainersVolumeMountsPropertyList;
    }
    class ContainersPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ContainersPropertyOutputReference;
    }
    interface ImagePullSecretsProperty {
    }
    class ImagePullSecretsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ImagePullSecretsProperty | undefined;
        set internalValue(value: ImagePullSecretsProperty | undefined);
        get name(): string;
    }
    class ImagePullSecretsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ImagePullSecretsPropertyOutputReference;
    }
    interface EksPropertiesPodPropertiesInitContainersEnvProperty {
    }
    class EksPropertiesPodPropertiesInitContainersEnvPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EksPropertiesPodPropertiesInitContainersEnvProperty | undefined;
        set internalValue(value: EksPropertiesPodPropertiesInitContainersEnvProperty | undefined);
        get name(): string;
        get value(): string;
    }
    class EksPropertiesPodPropertiesInitContainersEnvPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EksPropertiesPodPropertiesInitContainersEnvPropertyOutputReference;
    }
    interface EksPropertiesPodPropertiesInitContainersResourcesProperty {
    }
    class EksPropertiesPodPropertiesInitContainersResourcesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EksPropertiesPodPropertiesInitContainersResourcesProperty | undefined;
        set internalValue(value: EksPropertiesPodPropertiesInitContainersResourcesProperty | undefined);
        private _limits;
        get limits(): cdktn.StringMap;
        private _requests;
        get requests(): cdktn.StringMap;
    }
    class EksPropertiesPodPropertiesInitContainersResourcesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EksPropertiesPodPropertiesInitContainersResourcesPropertyOutputReference;
    }
    interface EksPropertiesPodPropertiesInitContainersSecurityContextProperty {
    }
    class EksPropertiesPodPropertiesInitContainersSecurityContextPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EksPropertiesPodPropertiesInitContainersSecurityContextProperty | undefined;
        set internalValue(value: EksPropertiesPodPropertiesInitContainersSecurityContextProperty | undefined);
        get allowPrivilegeEscalation(): cdktn.IResolvable;
        get privileged(): cdktn.IResolvable;
        get readOnlyRootFileSystem(): cdktn.IResolvable;
        get runAsGroup(): number;
        get runAsNonRoot(): cdktn.IResolvable;
        get runAsUser(): number;
    }
    class EksPropertiesPodPropertiesInitContainersSecurityContextPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EksPropertiesPodPropertiesInitContainersSecurityContextPropertyOutputReference;
    }
    interface EksPropertiesPodPropertiesInitContainersVolumeMountsProperty {
    }
    class EksPropertiesPodPropertiesInitContainersVolumeMountsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EksPropertiesPodPropertiesInitContainersVolumeMountsProperty | undefined;
        set internalValue(value: EksPropertiesPodPropertiesInitContainersVolumeMountsProperty | undefined);
        get mountPath(): string;
        get name(): string;
        get readOnly(): cdktn.IResolvable;
    }
    class EksPropertiesPodPropertiesInitContainersVolumeMountsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EksPropertiesPodPropertiesInitContainersVolumeMountsPropertyOutputReference;
    }
    interface InitContainersProperty {
    }
    class InitContainersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InitContainersProperty | undefined;
        set internalValue(value: InitContainersProperty | undefined);
        get args(): string[];
        get command(): string[];
        private _env;
        get env(): EksPropertiesPodPropertiesInitContainersEnvPropertyList;
        get image(): string;
        get imagePullPolicy(): string;
        get name(): string;
        private _resources;
        get resources(): EksPropertiesPodPropertiesInitContainersResourcesPropertyList;
        private _securityContext;
        get securityContext(): EksPropertiesPodPropertiesInitContainersSecurityContextPropertyList;
        private _volumeMounts;
        get volumeMounts(): EksPropertiesPodPropertiesInitContainersVolumeMountsPropertyList;
    }
    class InitContainersPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InitContainersPropertyOutputReference;
    }
    interface MetadataProperty {
    }
    class MetadataPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MetadataProperty | undefined;
        set internalValue(value: MetadataProperty | undefined);
        private _labels;
        get labels(): cdktn.StringMap;
    }
    class MetadataPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MetadataPropertyOutputReference;
    }
    interface EmptyDirProperty {
    }
    class EmptyDirPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EmptyDirProperty | undefined;
        set internalValue(value: EmptyDirProperty | undefined);
        get medium(): string;
        get sizeLimit(): string;
    }
    class EmptyDirPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EmptyDirPropertyOutputReference;
    }
    interface HostPathProperty {
    }
    class HostPathPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HostPathProperty | undefined;
        set internalValue(value: HostPathProperty | undefined);
        get path(): string;
    }
    class HostPathPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HostPathPropertyOutputReference;
    }
    interface SecretProperty {
    }
    class SecretPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SecretProperty | undefined;
        set internalValue(value: SecretProperty | undefined);
        get optional(): cdktn.IResolvable;
        get secretName(): string;
    }
    class SecretPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SecretPropertyOutputReference;
    }
    interface EksPropertiesPodPropertiesVolumesProperty {
    }
    class EksPropertiesPodPropertiesVolumesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EksPropertiesPodPropertiesVolumesProperty | undefined;
        set internalValue(value: EksPropertiesPodPropertiesVolumesProperty | undefined);
        private _emptyDir;
        get emptyDir(): EmptyDirPropertyList;
        private _hostPath;
        get hostPath(): HostPathPropertyList;
        get name(): string;
        private _secret;
        get secret(): SecretPropertyList;
    }
    class EksPropertiesPodPropertiesVolumesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EksPropertiesPodPropertiesVolumesPropertyOutputReference;
    }
    interface PodPropertiesProperty {
    }
    class PodPropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PodPropertiesProperty | undefined;
        set internalValue(value: PodPropertiesProperty | undefined);
        private _containers;
        get containers(): ContainersPropertyList;
        get dnsPolicy(): string;
        get hostNetwork(): cdktn.IResolvable;
        private _imagePullSecrets;
        get imagePullSecrets(): ImagePullSecretsPropertyList;
        private _initContainers;
        get initContainers(): InitContainersPropertyList;
        private _metadata;
        get metadata(): MetadataPropertyList;
        get serviceAccountName(): string;
        get shareProcessNamespace(): cdktn.IResolvable;
        private _volumes;
        get volumes(): EksPropertiesPodPropertiesVolumesPropertyList;
    }
    class PodPropertiesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PodPropertiesPropertyOutputReference;
    }
    interface EksPropertiesProperty {
    }
    class EksPropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EksPropertiesProperty | undefined;
        set internalValue(value: EksPropertiesProperty | undefined);
        private _podProperties;
        get podProperties(): PodPropertiesPropertyList;
    }
    class EksPropertiesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EksPropertiesPropertyOutputReference;
    }
    interface EnvironmentProperty {
    }
    class EnvironmentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EnvironmentProperty | undefined;
        set internalValue(value: EnvironmentProperty | undefined);
        get name(): string;
        get value(): string;
    }
    class EnvironmentPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EnvironmentPropertyOutputReference;
    }
    interface EphemeralStorageProperty {
    }
    class EphemeralStoragePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EphemeralStorageProperty | undefined;
        set internalValue(value: EphemeralStorageProperty | undefined);
        get sizeInGib(): number;
    }
    class EphemeralStoragePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EphemeralStoragePropertyOutputReference;
    }
    interface FargatePlatformConfigurationProperty {
    }
    class FargatePlatformConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FargatePlatformConfigurationProperty | undefined;
        set internalValue(value: FargatePlatformConfigurationProperty | undefined);
        get platformVersion(): string;
    }
    class FargatePlatformConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FargatePlatformConfigurationPropertyOutputReference;
    }
    interface DevicesProperty {
    }
    class DevicesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DevicesProperty | undefined;
        set internalValue(value: DevicesProperty | undefined);
        get containerPath(): string;
        get hostPath(): string;
        get permissions(): string[];
    }
    class DevicesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DevicesPropertyOutputReference;
    }
    interface TmpfsProperty {
    }
    class TmpfsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TmpfsProperty | undefined;
        set internalValue(value: TmpfsProperty | undefined);
        get containerPath(): string;
        get mountOptions(): string[];
        get size(): number;
    }
    class TmpfsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TmpfsPropertyOutputReference;
    }
    interface LinuxParametersProperty {
    }
    class LinuxParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LinuxParametersProperty | undefined;
        set internalValue(value: LinuxParametersProperty | undefined);
        private _devices;
        get devices(): DevicesPropertyList;
        get initProcessEnabled(): cdktn.IResolvable;
        get maxSwap(): number;
        get sharedMemorySize(): number;
        get swappiness(): number;
        private _tmpfs;
        get tmpfs(): TmpfsPropertyList;
    }
    class LinuxParametersPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LinuxParametersPropertyOutputReference;
    }
    interface SecretOptionsProperty {
    }
    class SecretOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SecretOptionsProperty | undefined;
        set internalValue(value: SecretOptionsProperty | undefined);
        get name(): string;
        get valueFrom(): string;
    }
    class SecretOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SecretOptionsPropertyOutputReference;
    }
    interface LogConfigurationProperty {
    }
    class LogConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LogConfigurationProperty | undefined;
        set internalValue(value: LogConfigurationProperty | undefined);
        get logDriver(): string;
        private _options;
        get options(): cdktn.StringMap;
        private _secretOptions;
        get secretOptions(): SecretOptionsPropertyList;
    }
    class LogConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LogConfigurationPropertyOutputReference;
    }
    interface MountPointsProperty {
    }
    class MountPointsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MountPointsProperty | undefined;
        set internalValue(value: MountPointsProperty | undefined);
        get containerPath(): string;
        get readOnly(): cdktn.IResolvable;
        get sourceVolume(): string;
    }
    class MountPointsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MountPointsPropertyOutputReference;
    }
    interface NetworkConfigurationProperty {
    }
    class NetworkConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NetworkConfigurationProperty | undefined;
        set internalValue(value: NetworkConfigurationProperty | undefined);
        get assignPublicIp(): cdktn.IResolvable;
    }
    class NetworkConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NetworkConfigurationPropertyOutputReference;
    }
    interface ResourceRequirementsProperty {
    }
    class ResourceRequirementsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceRequirementsProperty | undefined;
        set internalValue(value: ResourceRequirementsProperty | undefined);
        get type(): string;
        get value(): string;
    }
    class ResourceRequirementsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceRequirementsPropertyOutputReference;
    }
    interface RuntimePlatformProperty {
    }
    class RuntimePlatformPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuntimePlatformProperty | undefined;
        set internalValue(value: RuntimePlatformProperty | undefined);
        get cpuArchitecture(): string;
        get operatingSystemFamily(): string;
    }
    class RuntimePlatformPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuntimePlatformPropertyOutputReference;
    }
    interface SecretsProperty {
    }
    class SecretsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SecretsProperty | undefined;
        set internalValue(value: SecretsProperty | undefined);
        get name(): string;
        get valueFrom(): string;
    }
    class SecretsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SecretsPropertyOutputReference;
    }
    interface UlimitsProperty {
    }
    class UlimitsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): UlimitsProperty | undefined;
        set internalValue(value: UlimitsProperty | undefined);
        get hardLimit(): number;
        get name(): string;
        get softLimit(): number;
    }
    class UlimitsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): UlimitsPropertyOutputReference;
    }
    interface AuthorizationConfigProperty {
    }
    class AuthorizationConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthorizationConfigProperty | undefined;
        set internalValue(value: AuthorizationConfigProperty | undefined);
        get accessPointId(): string;
        get iam(): string;
    }
    class AuthorizationConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthorizationConfigPropertyOutputReference;
    }
    interface EfsVolumeConfigurationProperty {
    }
    class EfsVolumeConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EfsVolumeConfigurationProperty | undefined;
        set internalValue(value: EfsVolumeConfigurationProperty | undefined);
        private _authorizationConfig;
        get authorizationConfig(): AuthorizationConfigPropertyList;
        get fileSystemId(): string;
        get rootDirectory(): string;
        get transitEncryption(): string;
        get transitEncryptionPort(): number;
    }
    class EfsVolumeConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EfsVolumeConfigurationPropertyOutputReference;
    }
    interface HostProperty {
    }
    class HostPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HostProperty | undefined;
        set internalValue(value: HostProperty | undefined);
        get sourcePath(): string;
    }
    class HostPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HostPropertyOutputReference;
    }
    interface NodePropertiesNodeRangePropertiesContainerVolumesProperty {
    }
    class NodePropertiesNodeRangePropertiesContainerVolumesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NodePropertiesNodeRangePropertiesContainerVolumesProperty | undefined;
        set internalValue(value: NodePropertiesNodeRangePropertiesContainerVolumesProperty | undefined);
        private _efsVolumeConfiguration;
        get efsVolumeConfiguration(): EfsVolumeConfigurationPropertyList;
        private _host;
        get host(): HostPropertyList;
        get name(): string;
    }
    class NodePropertiesNodeRangePropertiesContainerVolumesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NodePropertiesNodeRangePropertiesContainerVolumesPropertyOutputReference;
    }
    interface ContainerProperty {
    }
    class ContainerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ContainerProperty | undefined;
        set internalValue(value: ContainerProperty | undefined);
        get command(): string[];
        private _environment;
        get environment(): EnvironmentPropertyList;
        private _ephemeralStorage;
        get ephemeralStorage(): EphemeralStoragePropertyList;
        get executionRoleArn(): string;
        private _fargatePlatformConfiguration;
        get fargatePlatformConfiguration(): FargatePlatformConfigurationPropertyList;
        get image(): string;
        get instanceType(): string;
        get jobRoleArn(): string;
        private _linuxParameters;
        get linuxParameters(): LinuxParametersPropertyList;
        private _logConfiguration;
        get logConfiguration(): LogConfigurationPropertyList;
        private _mountPoints;
        get mountPoints(): MountPointsPropertyList;
        private _networkConfiguration;
        get networkConfiguration(): NetworkConfigurationPropertyList;
        get privileged(): cdktn.IResolvable;
        get readonlyRootFilesystem(): cdktn.IResolvable;
        private _resourceRequirements;
        get resourceRequirements(): ResourceRequirementsPropertyList;
        private _runtimePlatform;
        get runtimePlatform(): RuntimePlatformPropertyList;
        private _secrets;
        get secrets(): SecretsPropertyList;
        private _ulimits;
        get ulimits(): UlimitsPropertyList;
        get user(): string;
        private _volumes;
        get volumes(): NodePropertiesNodeRangePropertiesContainerVolumesPropertyList;
    }
    class ContainerPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ContainerPropertyOutputReference;
    }
    interface NodeRangePropertiesProperty {
    }
    class NodeRangePropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NodeRangePropertiesProperty | undefined;
        set internalValue(value: NodeRangePropertiesProperty | undefined);
        private _container;
        get container(): ContainerPropertyList;
        get targetNodes(): string;
    }
    class NodeRangePropertiesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NodeRangePropertiesPropertyOutputReference;
    }
    interface NodePropertiesProperty {
    }
    class NodePropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NodePropertiesProperty | undefined;
        set internalValue(value: NodePropertiesProperty | undefined);
        get mainNode(): number;
        private _nodeRangeProperties;
        get nodeRangeProperties(): NodeRangePropertiesPropertyList;
        get numNodes(): number;
    }
    class NodePropertiesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NodePropertiesPropertyOutputReference;
    }
    interface EvaluateOnExitProperty {
    }
    class EvaluateOnExitPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EvaluateOnExitProperty | undefined;
        set internalValue(value: EvaluateOnExitProperty | undefined);
        get action(): string;
        get onExitCode(): string;
        get onReason(): string;
        get onStatusReason(): string;
    }
    class EvaluateOnExitPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EvaluateOnExitPropertyOutputReference;
    }
    interface RetryStrategyProperty {
    }
    class RetryStrategyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RetryStrategyProperty | undefined;
        set internalValue(value: RetryStrategyProperty | undefined);
        get attempts(): number;
        private _evaluateOnExit;
        get evaluateOnExit(): EvaluateOnExitPropertyList;
    }
    class RetryStrategyPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RetryStrategyPropertyOutputReference;
    }
    interface TimeoutProperty {
    }
    class TimeoutPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TimeoutProperty | undefined;
        set internalValue(value: TimeoutProperty | undefined);
        get attemptDurationSeconds(): number;
    }
    class TimeoutPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TimeoutPropertyOutputReference;
    }
}
