import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsMethodSettingsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_method_settings#id AwsMethodSettings#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_method_settings#method_path AwsMethodSettings#method_path}
    */
    readonly methodPath: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_method_settings#region AwsMethodSettings#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_method_settings#rest_api_id AwsMethodSettings#rest_api_id}
    */
    readonly restApiId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_method_settings#stage_name AwsMethodSettings#stage_name}
    */
    readonly stageName: string;
    /**
    * settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_method_settings#settings AwsMethodSettings#settings}
    */
    readonly settings: AwsMethodSettings.SettingsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_method_settings aws_api_gateway_method_settings}
*/
export declare class AwsMethodSettings extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_api_gateway_method_settings";
    /**
    * Generates CDKTN code for importing a AwsMethodSettings resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsMethodSettings to import
    * @param importFromId The id of the existing AwsMethodSettings that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_method_settings#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsMethodSettings to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_method_settings aws_api_gateway_method_settings} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsMethodSettingsConfig
    */
    constructor(scope: Construct, id: string, config: AwsMethodSettingsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _methodPath?;
    get methodPath(): string;
    set methodPath(value: string);
    get methodPathInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _restApiId?;
    get restApiId(): string;
    set restApiId(value: string);
    get restApiIdInput(): string | undefined;
    private _stageName?;
    get stageName(): string;
    set stageName(value: string);
    get stageNameInput(): string | undefined;
    private _settings;
    get settings(): AwsMethodSettings.SettingsPropertyOutputReference;
    putSettings(value: AwsMethodSettings.SettingsProperty): void;
    get settingsInput(): AwsMethodSettings.SettingsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsMethodSettingsSettingsPropertyToTerraform(struct?: AwsMethodSettings.SettingsPropertyOutputReference | AwsMethodSettings.SettingsProperty): any;
export declare function awsMethodSettingsSettingsPropertyToHclTerraform(struct?: AwsMethodSettings.SettingsPropertyOutputReference | AwsMethodSettings.SettingsProperty): any;
export declare namespace AwsMethodSettings {
    interface SettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_method_settings#cache_data_encrypted AwsMethodSettings#cache_data_encrypted}
        */
        readonly cacheDataEncrypted?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_method_settings#cache_ttl_in_seconds AwsMethodSettings#cache_ttl_in_seconds}
        */
        readonly cacheTtlInSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_method_settings#caching_enabled AwsMethodSettings#caching_enabled}
        */
        readonly cachingEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_method_settings#data_trace_enabled AwsMethodSettings#data_trace_enabled}
        */
        readonly dataTraceEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_method_settings#logging_level AwsMethodSettings#logging_level}
        */
        readonly loggingLevel?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_method_settings#metrics_enabled AwsMethodSettings#metrics_enabled}
        */
        readonly metricsEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_method_settings#require_authorization_for_cache_control AwsMethodSettings#require_authorization_for_cache_control}
        */
        readonly requireAuthorizationForCacheControl?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_method_settings#throttling_burst_limit AwsMethodSettings#throttling_burst_limit}
        */
        readonly throttlingBurstLimit?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_method_settings#throttling_rate_limit AwsMethodSettings#throttling_rate_limit}
        */
        readonly throttlingRateLimit?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_method_settings#unauthorized_cache_control_header_strategy AwsMethodSettings#unauthorized_cache_control_header_strategy}
        */
        readonly unauthorizedCacheControlHeaderStrategy?: string;
    }
    class SettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SettingsProperty | undefined;
        set internalValue(value: SettingsProperty | undefined);
        private _cacheDataEncrypted?;
        get cacheDataEncrypted(): boolean | cdktn.IResolvable;
        set cacheDataEncrypted(value: boolean | cdktn.IResolvable);
        resetCacheDataEncrypted(): void;
        get cacheDataEncryptedInput(): boolean | cdktn.IResolvable | undefined;
        private _cacheTtlInSeconds?;
        get cacheTtlInSeconds(): number;
        set cacheTtlInSeconds(value: number);
        resetCacheTtlInSeconds(): void;
        get cacheTtlInSecondsInput(): number | undefined;
        private _cachingEnabled?;
        get cachingEnabled(): boolean | cdktn.IResolvable;
        set cachingEnabled(value: boolean | cdktn.IResolvable);
        resetCachingEnabled(): void;
        get cachingEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _dataTraceEnabled?;
        get dataTraceEnabled(): boolean | cdktn.IResolvable;
        set dataTraceEnabled(value: boolean | cdktn.IResolvable);
        resetDataTraceEnabled(): void;
        get dataTraceEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _loggingLevel?;
        get loggingLevel(): string;
        set loggingLevel(value: string);
        resetLoggingLevel(): void;
        get loggingLevelInput(): string | undefined;
        private _metricsEnabled?;
        get metricsEnabled(): boolean | cdktn.IResolvable;
        set metricsEnabled(value: boolean | cdktn.IResolvable);
        resetMetricsEnabled(): void;
        get metricsEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _requireAuthorizationForCacheControl?;
        get requireAuthorizationForCacheControl(): boolean | cdktn.IResolvable;
        set requireAuthorizationForCacheControl(value: boolean | cdktn.IResolvable);
        resetRequireAuthorizationForCacheControl(): void;
        get requireAuthorizationForCacheControlInput(): boolean | cdktn.IResolvable | undefined;
        private _throttlingBurstLimit?;
        get throttlingBurstLimit(): number;
        set throttlingBurstLimit(value: number);
        resetThrottlingBurstLimit(): void;
        get throttlingBurstLimitInput(): number | undefined;
        private _throttlingRateLimit?;
        get throttlingRateLimit(): number;
        set throttlingRateLimit(value: number);
        resetThrottlingRateLimit(): void;
        get throttlingRateLimitInput(): number | undefined;
        private _unauthorizedCacheControlHeaderStrategy?;
        get unauthorizedCacheControlHeaderStrategy(): string;
        set unauthorizedCacheControlHeaderStrategy(value: string);
        resetUnauthorizedCacheControlHeaderStrategy(): void;
        get unauthorizedCacheControlHeaderStrategyInput(): string | undefined;
    }
}
