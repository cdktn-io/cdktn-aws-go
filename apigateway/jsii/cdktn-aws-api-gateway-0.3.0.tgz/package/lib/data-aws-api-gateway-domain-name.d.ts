import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsDomainNameConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/api_gateway_domain_name#domain_name DataAwsDomainName#domain_name}
    */
    readonly domainName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/api_gateway_domain_name#domain_name_id DataAwsDomainName#domain_name_id}
    */
    readonly domainNameId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/api_gateway_domain_name#id DataAwsDomainName#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/api_gateway_domain_name#region DataAwsDomainName#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/api_gateway_domain_name#tags DataAwsDomainName#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/api_gateway_domain_name aws_api_gateway_domain_name}
*/
export declare class DataAwsDomainName extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_api_gateway_domain_name";
    /**
    * Generates CDKTN code for importing a DataAwsDomainName resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsDomainName to import
    * @param importFromId The id of the existing DataAwsDomainName that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/api_gateway_domain_name#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsDomainName to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/api_gateway_domain_name aws_api_gateway_domain_name} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsDomainNameConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsDomainNameConfig);
    get arn(): string;
    get certificateArn(): string;
    get certificateName(): string;
    get certificateUploadDate(): string;
    get cloudfrontDomainName(): string;
    get cloudfrontZoneId(): string;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    private _domainNameId?;
    get domainNameId(): string;
    set domainNameId(value: string);
    resetDomainNameId(): void;
    get domainNameIdInput(): string | undefined;
    get endpointAccessMode(): string;
    private _endpointConfiguration;
    get endpointConfiguration(): DataAwsDomainName.EndpointConfigurationPropertyList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get policy(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get regionalCertificateArn(): string;
    get regionalCertificateName(): string;
    get regionalDomainName(): string;
    get regionalZoneId(): string;
    get securityPolicy(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsDomainNameEndpointConfigurationPropertyToTerraform(struct?: DataAwsDomainName.EndpointConfigurationProperty): any;
export declare function dataAwsDomainNameEndpointConfigurationPropertyToHclTerraform(struct?: DataAwsDomainName.EndpointConfigurationProperty): any;
export declare namespace DataAwsDomainName {
    interface EndpointConfigurationProperty {
    }
    class EndpointConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EndpointConfigurationProperty | undefined;
        set internalValue(value: EndpointConfigurationProperty | undefined);
        get ipAddressType(): string;
        get types(): string[];
    }
    class EndpointConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EndpointConfigurationPropertyOutputReference;
    }
}
