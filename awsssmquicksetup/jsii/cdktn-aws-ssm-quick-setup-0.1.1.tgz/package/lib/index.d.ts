export * from './aws-ssmquicksetup-configuration-manager';
