import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSsmquicksetupConfigurationManagerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmquicksetup_configuration_manager#description AwsSsmquicksetupConfigurationManager#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmquicksetup_configuration_manager#name AwsSsmquicksetupConfigurationManager#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmquicksetup_configuration_manager#region AwsSsmquicksetupConfigurationManager#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmquicksetup_configuration_manager#tags AwsSsmquicksetupConfigurationManager#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * configuration_definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmquicksetup_configuration_manager#configuration_definition AwsSsmquicksetupConfigurationManager#configuration_definition}
    */
    readonly configurationDefinition?: AwsSsmquicksetupConfigurationManager.ConfigurationDefinitionProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmquicksetup_configuration_manager#timeouts AwsSsmquicksetupConfigurationManager#timeouts}
    */
    readonly timeouts?: AwsSsmquicksetupConfigurationManager.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmquicksetup_configuration_manager aws_ssmquicksetup_configuration_manager}
*/
export declare class AwsSsmquicksetupConfigurationManager extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ssmquicksetup_configuration_manager";
    /**
    * Generates CDKTN code for importing a AwsSsmquicksetupConfigurationManager resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSsmquicksetupConfigurationManager to import
    * @param importFromId The id of the existing AwsSsmquicksetupConfigurationManager that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmquicksetup_configuration_manager#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSsmquicksetupConfigurationManager to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmquicksetup_configuration_manager aws_ssmquicksetup_configuration_manager} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSsmquicksetupConfigurationManagerConfig
    */
    constructor(scope: Construct, id: string, config: AwsSsmquicksetupConfigurationManagerConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get managerArn(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _statusSummaries;
    get statusSummaries(): AwsSsmquicksetupConfigurationManager.StatusSummariesPropertyList;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _configurationDefinition;
    get configurationDefinition(): AwsSsmquicksetupConfigurationManager.ConfigurationDefinitionPropertyList;
    putConfigurationDefinition(value: AwsSsmquicksetupConfigurationManager.ConfigurationDefinitionProperty[] | cdktn.IResolvable): void;
    resetConfigurationDefinition(): void;
    get configurationDefinitionInput(): cdktn.IResolvable | AwsSsmquicksetupConfigurationManager.ConfigurationDefinitionProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsSsmquicksetupConfigurationManager.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsSsmquicksetupConfigurationManager.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsSsmquicksetupConfigurationManager.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsSsmquicksetupConfigurationManagerStatusSummariesPropertyToTerraform(struct?: AwsSsmquicksetupConfigurationManager.StatusSummariesProperty): any;
export declare function awsSsmquicksetupConfigurationManagerStatusSummariesPropertyToHclTerraform(struct?: AwsSsmquicksetupConfigurationManager.StatusSummariesProperty): any;
export declare function awsSsmquicksetupConfigurationManagerConfigurationDefinitionPropertyToTerraform(struct?: AwsSsmquicksetupConfigurationManager.ConfigurationDefinitionProperty | cdktn.IResolvable): any;
export declare function awsSsmquicksetupConfigurationManagerConfigurationDefinitionPropertyToHclTerraform(struct?: AwsSsmquicksetupConfigurationManager.ConfigurationDefinitionProperty | cdktn.IResolvable): any;
export declare function awsSsmquicksetupConfigurationManagerTimeoutsPropertyToTerraform(struct?: AwsSsmquicksetupConfigurationManager.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsSsmquicksetupConfigurationManagerTimeoutsPropertyToHclTerraform(struct?: AwsSsmquicksetupConfigurationManager.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsSsmquicksetupConfigurationManager {
    interface StatusSummariesProperty {
    }
    class StatusSummariesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StatusSummariesProperty | undefined;
        set internalValue(value: StatusSummariesProperty | undefined);
        get status(): string;
        get statusMessage(): string;
        get statusType(): string;
    }
    class StatusSummariesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StatusSummariesPropertyOutputReference;
    }
    interface ConfigurationDefinitionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmquicksetup_configuration_manager#local_deployment_administration_role_arn AwsSsmquicksetupConfigurationManager#local_deployment_administration_role_arn}
        */
        readonly localDeploymentAdministrationRoleArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmquicksetup_configuration_manager#local_deployment_execution_role_name AwsSsmquicksetupConfigurationManager#local_deployment_execution_role_name}
        */
        readonly localDeploymentExecutionRoleName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmquicksetup_configuration_manager#parameters AwsSsmquicksetupConfigurationManager#parameters}
        */
        readonly parameters: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmquicksetup_configuration_manager#type AwsSsmquicksetupConfigurationManager#type}
        */
        readonly type: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmquicksetup_configuration_manager#type_version AwsSsmquicksetupConfigurationManager#type_version}
        */
        readonly typeVersion?: string;
    }
    class ConfigurationDefinitionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConfigurationDefinitionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConfigurationDefinitionProperty | cdktn.IResolvable | undefined);
        get id(): string;
        private _localDeploymentAdministrationRoleArn?;
        get localDeploymentAdministrationRoleArn(): string;
        set localDeploymentAdministrationRoleArn(value: string);
        resetLocalDeploymentAdministrationRoleArn(): void;
        get localDeploymentAdministrationRoleArnInput(): string | undefined;
        private _localDeploymentExecutionRoleName?;
        get localDeploymentExecutionRoleName(): string;
        set localDeploymentExecutionRoleName(value: string);
        resetLocalDeploymentExecutionRoleName(): void;
        get localDeploymentExecutionRoleNameInput(): string | undefined;
        private _parameters?;
        get parameters(): {
            [key: string]: string;
        };
        set parameters(value: {
            [key: string]: string;
        });
        get parametersInput(): {
            [key: string]: string;
        } | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _typeVersion?;
        get typeVersion(): string;
        set typeVersion(value: string);
        resetTypeVersion(): void;
        get typeVersionInput(): string | undefined;
    }
    class ConfigurationDefinitionPropertyList extends cdktn.ComplexList {
        internalValue?: ConfigurationDefinitionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConfigurationDefinitionPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmquicksetup_configuration_manager#create AwsSsmquicksetupConfigurationManager#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmquicksetup_configuration_manager#delete AwsSsmquicksetupConfigurationManager#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmquicksetup_configuration_manager#update AwsSsmquicksetupConfigurationManager#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
