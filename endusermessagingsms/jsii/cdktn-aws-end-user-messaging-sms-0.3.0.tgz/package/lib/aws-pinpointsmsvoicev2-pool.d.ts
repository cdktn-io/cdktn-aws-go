import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsPoolConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether deletion protection is enabled. When `true`, the pool cannot be deleted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_pool#deletion_protection_enabled AwsPool#deletion_protection_enabled}
    */
    readonly deletionProtectionEnabled?: boolean | cdktn.IResolvable;
    /**
    * Two-character code, in ISO 3166-1 alpha-2 format, for the country or region of the pool. This field is optional for origination identity types that are not country-specific.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_pool#iso_country_code AwsPool#iso_country_code}
    */
    readonly isoCountryCode?: string;
    /**
    * Type of message.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_pool#message_type AwsPool#message_type}
    */
    readonly messageType: string;
    /**
    * Name of the opt-out list to associate with the pool. Inherited from the initial origination identity when omitted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_pool#opt_out_list_name AwsPool#opt_out_list_name}
    */
    readonly optOutListName?: string;
    /**
    * Set of origination identity ARNs to associate with the pool. At least one origination identity is required at creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_pool#origination_identities AwsPool#origination_identities}
    */
    readonly originationIdentities: string[];
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_pool#region AwsPool#region}
    */
    readonly region?: string;
    /**
    * Whether the pool relies on self-managed opt-out handling. When `false`, AWS auto-replies to HELP/STOP requests and manages the opt-out list. Inherited from the initial origination identity when omitted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_pool#self_managed_opt_outs_enabled AwsPool#self_managed_opt_outs_enabled}
    */
    readonly selfManagedOptOutsEnabled?: boolean | cdktn.IResolvable;
    /**
    * Whether shared routes are enabled for the pool. When `true`, messages may use shared phone numbers or sender IDs in countries that allow it.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_pool#shared_routes_enabled AwsPool#shared_routes_enabled}
    */
    readonly sharedRoutesEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_pool#tags AwsPool#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * ARN of the two-way channel that receives inbound messages.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_pool#two_way_channel_arn AwsPool#two_way_channel_arn}
    */
    readonly twoWayChannelArn?: string;
    /**
    * ARN of the IAM role that End User Messaging SMS assumes to publish inbound messages to the two-way channel.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_pool#two_way_channel_role AwsPool#two_way_channel_role}
    */
    readonly twoWayChannelRole?: string;
    /**
    * Whether inbound message reception is enabled for the pool.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_pool#two_way_enabled AwsPool#two_way_enabled}
    */
    readonly twoWayEnabled?: boolean | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_pool#timeouts AwsPool#timeouts}
    */
    readonly timeouts?: AwsPool.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_pool aws_pinpointsmsvoicev2_pool}
*/
export declare class AwsPool extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_pinpointsmsvoicev2_pool";
    /**
    * Generates CDKTN code for importing a AwsPool resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsPool to import
    * @param importFromId The id of the existing AwsPool that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_pool#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsPool to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_pool aws_pinpointsmsvoicev2_pool} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsPoolConfig
    */
    constructor(scope: Construct, id: string, config: AwsPoolConfig);
    get arn(): string;
    private _deletionProtectionEnabled?;
    get deletionProtectionEnabled(): boolean | cdktn.IResolvable;
    set deletionProtectionEnabled(value: boolean | cdktn.IResolvable);
    resetDeletionProtectionEnabled(): void;
    get deletionProtectionEnabledInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    private _isoCountryCode?;
    get isoCountryCode(): string;
    set isoCountryCode(value: string);
    resetIsoCountryCode(): void;
    get isoCountryCodeInput(): string | undefined;
    private _messageType?;
    get messageType(): string;
    set messageType(value: string);
    get messageTypeInput(): string | undefined;
    private _optOutListName?;
    get optOutListName(): string;
    set optOutListName(value: string);
    resetOptOutListName(): void;
    get optOutListNameInput(): string | undefined;
    private _originationIdentities?;
    get originationIdentities(): string[];
    set originationIdentities(value: string[]);
    get originationIdentitiesInput(): string[] | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _selfManagedOptOutsEnabled?;
    get selfManagedOptOutsEnabled(): boolean | cdktn.IResolvable;
    set selfManagedOptOutsEnabled(value: boolean | cdktn.IResolvable);
    resetSelfManagedOptOutsEnabled(): void;
    get selfManagedOptOutsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _sharedRoutesEnabled?;
    get sharedRoutesEnabled(): boolean | cdktn.IResolvable;
    set sharedRoutesEnabled(value: boolean | cdktn.IResolvable);
    resetSharedRoutesEnabled(): void;
    get sharedRoutesEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _twoWayChannelArn?;
    get twoWayChannelArn(): string;
    set twoWayChannelArn(value: string);
    resetTwoWayChannelArn(): void;
    get twoWayChannelArnInput(): string | undefined;
    private _twoWayChannelRole?;
    get twoWayChannelRole(): string;
    set twoWayChannelRole(value: string);
    resetTwoWayChannelRole(): void;
    get twoWayChannelRoleInput(): string | undefined;
    private _twoWayEnabled?;
    get twoWayEnabled(): boolean | cdktn.IResolvable;
    set twoWayEnabled(value: boolean | cdktn.IResolvable);
    resetTwoWayEnabled(): void;
    get twoWayEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _timeouts;
    get timeouts(): AwsPool.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsPool.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsPool.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsPoolTimeoutsPropertyToTerraform(struct?: AwsPool.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsPoolTimeoutsPropertyToHclTerraform(struct?: AwsPool.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsPool {
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_pool#create AwsPool#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_pool#delete AwsPool#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_pool#update AwsPool#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
