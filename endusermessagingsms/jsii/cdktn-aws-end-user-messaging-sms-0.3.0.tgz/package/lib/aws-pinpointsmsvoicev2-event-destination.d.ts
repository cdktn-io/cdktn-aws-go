import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsEventDestinationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Name of the configuration set this event destination belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_event_destination#configuration_set_name AwsEventDestination#configuration_set_name}
    */
    readonly configurationSetName: string;
    /**
    * Whether the event destination is enabled. Defaults to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_event_destination#enabled AwsEventDestination#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Name of the event destination.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_event_destination#event_destination_name AwsEventDestination#event_destination_name}
    */
    readonly eventDestinationName: string;
    /**
    * Event types for which the destination receives records.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_event_destination#matching_event_types AwsEventDestination#matching_event_types}
    */
    readonly matchingEventTypes: string[];
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_event_destination#region AwsEventDestination#region}
    */
    readonly region?: string;
    /**
    * cloudwatch_logs_destination block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_event_destination#cloudwatch_logs_destination AwsEventDestination#cloudwatch_logs_destination}
    */
    readonly cloudwatchLogsDestination?: AwsEventDestination.CloudwatchLogsDestinationProperty[] | cdktn.IResolvable;
    /**
    * kinesis_firehose_destination block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_event_destination#kinesis_firehose_destination AwsEventDestination#kinesis_firehose_destination}
    */
    readonly kinesisFirehoseDestination?: AwsEventDestination.KinesisFirehoseDestinationProperty[] | cdktn.IResolvable;
    /**
    * sns_destination block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_event_destination#sns_destination AwsEventDestination#sns_destination}
    */
    readonly snsDestination?: AwsEventDestination.SnsDestinationProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_event_destination aws_pinpointsmsvoicev2_event_destination}
*/
export declare class AwsEventDestination extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_pinpointsmsvoicev2_event_destination";
    /**
    * Generates CDKTN code for importing a AwsEventDestination resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsEventDestination to import
    * @param importFromId The id of the existing AwsEventDestination that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_event_destination#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsEventDestination to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_event_destination aws_pinpointsmsvoicev2_event_destination} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsEventDestinationConfig
    */
    constructor(scope: Construct, id: string, config: AwsEventDestinationConfig);
    get configurationSetArn(): string;
    private _configurationSetName?;
    get configurationSetName(): string;
    set configurationSetName(value: string);
    get configurationSetNameInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _eventDestinationName?;
    get eventDestinationName(): string;
    set eventDestinationName(value: string);
    get eventDestinationNameInput(): string | undefined;
    private _matchingEventTypes?;
    get matchingEventTypes(): string[];
    set matchingEventTypes(value: string[]);
    get matchingEventTypesInput(): string[] | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _cloudwatchLogsDestination;
    get cloudwatchLogsDestination(): AwsEventDestination.CloudwatchLogsDestinationPropertyList;
    putCloudwatchLogsDestination(value: AwsEventDestination.CloudwatchLogsDestinationProperty[] | cdktn.IResolvable): void;
    resetCloudwatchLogsDestination(): void;
    get cloudwatchLogsDestinationInput(): cdktn.IResolvable | AwsEventDestination.CloudwatchLogsDestinationProperty[] | undefined;
    private _kinesisFirehoseDestination;
    get kinesisFirehoseDestination(): AwsEventDestination.KinesisFirehoseDestinationPropertyList;
    putKinesisFirehoseDestination(value: AwsEventDestination.KinesisFirehoseDestinationProperty[] | cdktn.IResolvable): void;
    resetKinesisFirehoseDestination(): void;
    get kinesisFirehoseDestinationInput(): cdktn.IResolvable | AwsEventDestination.KinesisFirehoseDestinationProperty[] | undefined;
    private _snsDestination;
    get snsDestination(): AwsEventDestination.SnsDestinationPropertyList;
    putSnsDestination(value: AwsEventDestination.SnsDestinationProperty[] | cdktn.IResolvable): void;
    resetSnsDestination(): void;
    get snsDestinationInput(): cdktn.IResolvable | AwsEventDestination.SnsDestinationProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsEventDestinationCloudwatchLogsDestinationPropertyToTerraform(struct?: AwsEventDestination.CloudwatchLogsDestinationProperty | cdktn.IResolvable): any;
export declare function awsEventDestinationCloudwatchLogsDestinationPropertyToHclTerraform(struct?: AwsEventDestination.CloudwatchLogsDestinationProperty | cdktn.IResolvable): any;
export declare function awsEventDestinationKinesisFirehoseDestinationPropertyToTerraform(struct?: AwsEventDestination.KinesisFirehoseDestinationProperty | cdktn.IResolvable): any;
export declare function awsEventDestinationKinesisFirehoseDestinationPropertyToHclTerraform(struct?: AwsEventDestination.KinesisFirehoseDestinationProperty | cdktn.IResolvable): any;
export declare function awsEventDestinationSnsDestinationPropertyToTerraform(struct?: AwsEventDestination.SnsDestinationProperty | cdktn.IResolvable): any;
export declare function awsEventDestinationSnsDestinationPropertyToHclTerraform(struct?: AwsEventDestination.SnsDestinationProperty | cdktn.IResolvable): any;
export declare namespace AwsEventDestination {
    interface CloudwatchLogsDestinationProperty {
        /**
        * ARN of the IAM role that End User Messaging SMS assumes to write to the log group.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_event_destination#iam_role_arn AwsEventDestination#iam_role_arn}
        */
        readonly iamRoleArn: string;
        /**
        * ARN of the Amazon CloudWatch log group that receives the events.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_event_destination#log_group_arn AwsEventDestination#log_group_arn}
        */
        readonly logGroupArn: string;
    }
    class CloudwatchLogsDestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CloudwatchLogsDestinationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CloudwatchLogsDestinationProperty | cdktn.IResolvable | undefined);
        private _iamRoleArn?;
        get iamRoleArn(): string;
        set iamRoleArn(value: string);
        get iamRoleArnInput(): string | undefined;
        private _logGroupArn?;
        get logGroupArn(): string;
        set logGroupArn(value: string);
        get logGroupArnInput(): string | undefined;
    }
    class CloudwatchLogsDestinationPropertyList extends cdktn.ComplexList {
        internalValue?: CloudwatchLogsDestinationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CloudwatchLogsDestinationPropertyOutputReference;
    }
    interface KinesisFirehoseDestinationProperty {
        /**
        * ARN of the Amazon Data Firehose delivery stream that receives the events.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_event_destination#delivery_stream_arn AwsEventDestination#delivery_stream_arn}
        */
        readonly deliveryStreamArn: string;
        /**
        * ARN of the IAM role that End User Messaging SMS assumes to write to the delivery stream.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_event_destination#iam_role_arn AwsEventDestination#iam_role_arn}
        */
        readonly iamRoleArn: string;
    }
    class KinesisFirehoseDestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KinesisFirehoseDestinationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: KinesisFirehoseDestinationProperty | cdktn.IResolvable | undefined);
        private _deliveryStreamArn?;
        get deliveryStreamArn(): string;
        set deliveryStreamArn(value: string);
        get deliveryStreamArnInput(): string | undefined;
        private _iamRoleArn?;
        get iamRoleArn(): string;
        set iamRoleArn(value: string);
        get iamRoleArnInput(): string | undefined;
    }
    class KinesisFirehoseDestinationPropertyList extends cdktn.ComplexList {
        internalValue?: KinesisFirehoseDestinationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KinesisFirehoseDestinationPropertyOutputReference;
    }
    interface SnsDestinationProperty {
        /**
        * ARN of the Amazon SNS topic that receives the events.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_event_destination#topic_arn AwsEventDestination#topic_arn}
        */
        readonly topicArn: string;
    }
    class SnsDestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SnsDestinationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SnsDestinationProperty | cdktn.IResolvable | undefined);
        private _topicArn?;
        get topicArn(): string;
        set topicArn(value: string);
        get topicArnInput(): string | undefined;
    }
    class SnsDestinationPropertyList extends cdktn.ComplexList {
        internalValue?: SnsDestinationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SnsDestinationPropertyOutputReference;
    }
}
