import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAttributeGroupAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * ID of the application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalogappregistry_attribute_group_association#application_id AwsAttributeGroupAssociation#application_id}
    */
    readonly applicationId: string;
    /**
    * ID of the attribute group to associate with the application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalogappregistry_attribute_group_association#attribute_group_id AwsAttributeGroupAssociation#attribute_group_id}
    */
    readonly attributeGroupId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalogappregistry_attribute_group_association#region AwsAttributeGroupAssociation#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalogappregistry_attribute_group_association aws_servicecatalogappregistry_attribute_group_association}
*/
export declare class AwsAttributeGroupAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_servicecatalogappregistry_attribute_group_association";
    /**
    * Generates CDKTN code for importing a AwsAttributeGroupAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsAttributeGroupAssociation to import
    * @param importFromId The id of the existing AwsAttributeGroupAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalogappregistry_attribute_group_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsAttributeGroupAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalogappregistry_attribute_group_association aws_servicecatalogappregistry_attribute_group_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAttributeGroupAssociationConfig
    */
    constructor(scope: Construct, id: string, config: AwsAttributeGroupAssociationConfig);
    private _applicationId?;
    get applicationId(): string;
    set applicationId(value: string);
    get applicationIdInput(): string | undefined;
    private _attributeGroupId?;
    get attributeGroupId(): string;
    set attributeGroupId(value: string);
    get attributeGroupIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
