import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsTableConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#default_time_to_live AwsTable#default_time_to_live}
    */
    readonly defaultTimeToLive?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#id AwsTable#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#keyspace_name AwsTable#keyspace_name}
    */
    readonly keyspaceName: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#region AwsTable#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#table_name AwsTable#table_name}
    */
    readonly tableName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#tags AwsTable#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#tags_all AwsTable#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * capacity_specification block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#capacity_specification AwsTable#capacity_specification}
    */
    readonly capacitySpecification?: AwsTable.CapacitySpecificationProperty;
    /**
    * client_side_timestamps block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#client_side_timestamps AwsTable#client_side_timestamps}
    */
    readonly clientSideTimestamps?: AwsTable.ClientSideTimestampsProperty;
    /**
    * comment block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#comment AwsTable#comment}
    */
    readonly comment?: AwsTable.CommentProperty;
    /**
    * encryption_specification block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#encryption_specification AwsTable#encryption_specification}
    */
    readonly encryptionSpecification?: AwsTable.EncryptionSpecificationProperty;
    /**
    * point_in_time_recovery block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#point_in_time_recovery AwsTable#point_in_time_recovery}
    */
    readonly pointInTimeRecovery?: AwsTable.PointInTimeRecoveryProperty;
    /**
    * schema_definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#schema_definition AwsTable#schema_definition}
    */
    readonly schemaDefinition: AwsTable.SchemaDefinitionProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#timeouts AwsTable#timeouts}
    */
    readonly timeouts?: AwsTable.TimeoutsProperty;
    /**
    * ttl block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#ttl AwsTable#ttl}
    */
    readonly ttl?: AwsTable.TtlProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table aws_keyspaces_table}
*/
export declare class AwsTable extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_keyspaces_table";
    /**
    * Generates CDKTN code for importing a AwsTable resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsTable to import
    * @param importFromId The id of the existing AwsTable that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsTable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table aws_keyspaces_table} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsTableConfig
    */
    constructor(scope: Construct, id: string, config: AwsTableConfig);
    get arn(): string;
    private _defaultTimeToLive?;
    get defaultTimeToLive(): number;
    set defaultTimeToLive(value: number);
    resetDefaultTimeToLive(): void;
    get defaultTimeToLiveInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _keyspaceName?;
    get keyspaceName(): string;
    set keyspaceName(value: string);
    get keyspaceNameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tableName?;
    get tableName(): string;
    set tableName(value: string);
    get tableNameInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _capacitySpecification;
    get capacitySpecification(): AwsTable.CapacitySpecificationPropertyOutputReference;
    putCapacitySpecification(value: AwsTable.CapacitySpecificationProperty): void;
    resetCapacitySpecification(): void;
    get capacitySpecificationInput(): AwsTable.CapacitySpecificationProperty | undefined;
    private _clientSideTimestamps;
    get clientSideTimestamps(): AwsTable.ClientSideTimestampsPropertyOutputReference;
    putClientSideTimestamps(value: AwsTable.ClientSideTimestampsProperty): void;
    resetClientSideTimestamps(): void;
    get clientSideTimestampsInput(): AwsTable.ClientSideTimestampsProperty | undefined;
    private _comment;
    get comment(): AwsTable.CommentPropertyOutputReference;
    putComment(value: AwsTable.CommentProperty): void;
    resetComment(): void;
    get commentInput(): AwsTable.CommentProperty | undefined;
    private _encryptionSpecification;
    get encryptionSpecification(): AwsTable.EncryptionSpecificationPropertyOutputReference;
    putEncryptionSpecification(value: AwsTable.EncryptionSpecificationProperty): void;
    resetEncryptionSpecification(): void;
    get encryptionSpecificationInput(): AwsTable.EncryptionSpecificationProperty | undefined;
    private _pointInTimeRecovery;
    get pointInTimeRecovery(): AwsTable.PointInTimeRecoveryPropertyOutputReference;
    putPointInTimeRecovery(value: AwsTable.PointInTimeRecoveryProperty): void;
    resetPointInTimeRecovery(): void;
    get pointInTimeRecoveryInput(): AwsTable.PointInTimeRecoveryProperty | undefined;
    private _schemaDefinition;
    get schemaDefinition(): AwsTable.SchemaDefinitionPropertyOutputReference;
    putSchemaDefinition(value: AwsTable.SchemaDefinitionProperty): void;
    get schemaDefinitionInput(): AwsTable.SchemaDefinitionProperty | undefined;
    private _timeouts;
    get timeouts(): AwsTable.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsTable.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsTable.TimeoutsProperty | undefined;
    private _ttl;
    get ttl(): AwsTable.TtlPropertyOutputReference;
    putTtl(value: AwsTable.TtlProperty): void;
    resetTtl(): void;
    get ttlInput(): AwsTable.TtlProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsTableCapacitySpecificationPropertyToTerraform(struct?: AwsTable.CapacitySpecificationPropertyOutputReference | AwsTable.CapacitySpecificationProperty): any;
export declare function awsTableCapacitySpecificationPropertyToHclTerraform(struct?: AwsTable.CapacitySpecificationPropertyOutputReference | AwsTable.CapacitySpecificationProperty): any;
export declare function awsTableClientSideTimestampsPropertyToTerraform(struct?: AwsTable.ClientSideTimestampsPropertyOutputReference | AwsTable.ClientSideTimestampsProperty): any;
export declare function awsTableClientSideTimestampsPropertyToHclTerraform(struct?: AwsTable.ClientSideTimestampsPropertyOutputReference | AwsTable.ClientSideTimestampsProperty): any;
export declare function awsTableCommentPropertyToTerraform(struct?: AwsTable.CommentPropertyOutputReference | AwsTable.CommentProperty): any;
export declare function awsTableCommentPropertyToHclTerraform(struct?: AwsTable.CommentPropertyOutputReference | AwsTable.CommentProperty): any;
export declare function awsTableEncryptionSpecificationPropertyToTerraform(struct?: AwsTable.EncryptionSpecificationPropertyOutputReference | AwsTable.EncryptionSpecificationProperty): any;
export declare function awsTableEncryptionSpecificationPropertyToHclTerraform(struct?: AwsTable.EncryptionSpecificationPropertyOutputReference | AwsTable.EncryptionSpecificationProperty): any;
export declare function awsTablePointInTimeRecoveryPropertyToTerraform(struct?: AwsTable.PointInTimeRecoveryPropertyOutputReference | AwsTable.PointInTimeRecoveryProperty): any;
export declare function awsTablePointInTimeRecoveryPropertyToHclTerraform(struct?: AwsTable.PointInTimeRecoveryPropertyOutputReference | AwsTable.PointInTimeRecoveryProperty): any;
export declare function awsTableClusteringKeyPropertyToTerraform(struct?: AwsTable.ClusteringKeyProperty | cdktn.IResolvable): any;
export declare function awsTableClusteringKeyPropertyToHclTerraform(struct?: AwsTable.ClusteringKeyProperty | cdktn.IResolvable): any;
export declare function awsTableColumnPropertyToTerraform(struct?: AwsTable.ColumnProperty | cdktn.IResolvable): any;
export declare function awsTableColumnPropertyToHclTerraform(struct?: AwsTable.ColumnProperty | cdktn.IResolvable): any;
export declare function awsTablePartitionKeyPropertyToTerraform(struct?: AwsTable.PartitionKeyProperty | cdktn.IResolvable): any;
export declare function awsTablePartitionKeyPropertyToHclTerraform(struct?: AwsTable.PartitionKeyProperty | cdktn.IResolvable): any;
export declare function awsTableStaticColumnPropertyToTerraform(struct?: AwsTable.StaticColumnProperty | cdktn.IResolvable): any;
export declare function awsTableStaticColumnPropertyToHclTerraform(struct?: AwsTable.StaticColumnProperty | cdktn.IResolvable): any;
export declare function awsTableSchemaDefinitionPropertyToTerraform(struct?: AwsTable.SchemaDefinitionPropertyOutputReference | AwsTable.SchemaDefinitionProperty): any;
export declare function awsTableSchemaDefinitionPropertyToHclTerraform(struct?: AwsTable.SchemaDefinitionPropertyOutputReference | AwsTable.SchemaDefinitionProperty): any;
export declare function awsTableTimeoutsPropertyToTerraform(struct?: AwsTable.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsTableTimeoutsPropertyToHclTerraform(struct?: AwsTable.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsTableTtlPropertyToTerraform(struct?: AwsTable.TtlPropertyOutputReference | AwsTable.TtlProperty): any;
export declare function awsTableTtlPropertyToHclTerraform(struct?: AwsTable.TtlPropertyOutputReference | AwsTable.TtlProperty): any;
export declare namespace AwsTable {
    interface CapacitySpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#read_capacity_units AwsTable#read_capacity_units}
        */
        readonly readCapacityUnits?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#throughput_mode AwsTable#throughput_mode}
        */
        readonly throughputMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#write_capacity_units AwsTable#write_capacity_units}
        */
        readonly writeCapacityUnits?: number;
    }
    class CapacitySpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CapacitySpecificationProperty | undefined;
        set internalValue(value: CapacitySpecificationProperty | undefined);
        private _readCapacityUnits?;
        get readCapacityUnits(): number;
        set readCapacityUnits(value: number);
        resetReadCapacityUnits(): void;
        get readCapacityUnitsInput(): number | undefined;
        private _throughputMode?;
        get throughputMode(): string;
        set throughputMode(value: string);
        resetThroughputMode(): void;
        get throughputModeInput(): string | undefined;
        private _writeCapacityUnits?;
        get writeCapacityUnits(): number;
        set writeCapacityUnits(value: number);
        resetWriteCapacityUnits(): void;
        get writeCapacityUnitsInput(): number | undefined;
    }
    interface ClientSideTimestampsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#status AwsTable#status}
        */
        readonly status: string;
    }
    class ClientSideTimestampsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ClientSideTimestampsProperty | undefined;
        set internalValue(value: ClientSideTimestampsProperty | undefined);
        private _status?;
        get status(): string;
        set status(value: string);
        get statusInput(): string | undefined;
    }
    interface CommentProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#message AwsTable#message}
        */
        readonly message?: string;
    }
    class CommentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CommentProperty | undefined;
        set internalValue(value: CommentProperty | undefined);
        private _message?;
        get message(): string;
        set message(value: string);
        resetMessage(): void;
        get messageInput(): string | undefined;
    }
    interface EncryptionSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#kms_key_identifier AwsTable#kms_key_identifier}
        */
        readonly kmsKeyIdentifier?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#type AwsTable#type}
        */
        readonly type?: string;
    }
    class EncryptionSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncryptionSpecificationProperty | undefined;
        set internalValue(value: EncryptionSpecificationProperty | undefined);
        private _kmsKeyIdentifier?;
        get kmsKeyIdentifier(): string;
        set kmsKeyIdentifier(value: string);
        resetKmsKeyIdentifier(): void;
        get kmsKeyIdentifierInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
    }
    interface PointInTimeRecoveryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#status AwsTable#status}
        */
        readonly status?: string;
    }
    class PointInTimeRecoveryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PointInTimeRecoveryProperty | undefined;
        set internalValue(value: PointInTimeRecoveryProperty | undefined);
        private _status?;
        get status(): string;
        set status(value: string);
        resetStatus(): void;
        get statusInput(): string | undefined;
    }
    interface ClusteringKeyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#name AwsTable#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#order_by AwsTable#order_by}
        */
        readonly orderBy: string;
    }
    class ClusteringKeyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ClusteringKeyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ClusteringKeyProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _orderBy?;
        get orderBy(): string;
        set orderBy(value: string);
        get orderByInput(): string | undefined;
    }
    class ClusteringKeyPropertyList extends cdktn.ComplexList {
        internalValue?: ClusteringKeyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ClusteringKeyPropertyOutputReference;
    }
    interface ColumnProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#name AwsTable#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#type AwsTable#type}
        */
        readonly type: string;
    }
    class ColumnPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ColumnProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ColumnProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class ColumnPropertyList extends cdktn.ComplexList {
        internalValue?: ColumnProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ColumnPropertyOutputReference;
    }
    interface PartitionKeyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#name AwsTable#name}
        */
        readonly name: string;
    }
    class PartitionKeyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PartitionKeyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PartitionKeyProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    class PartitionKeyPropertyList extends cdktn.ComplexList {
        internalValue?: PartitionKeyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PartitionKeyPropertyOutputReference;
    }
    interface StaticColumnProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#name AwsTable#name}
        */
        readonly name: string;
    }
    class StaticColumnPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StaticColumnProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StaticColumnProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    class StaticColumnPropertyList extends cdktn.ComplexList {
        internalValue?: StaticColumnProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StaticColumnPropertyOutputReference;
    }
    interface SchemaDefinitionProperty {
        /**
        * clustering_key block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#clustering_key AwsTable#clustering_key}
        */
        readonly clusteringKey?: ClusteringKeyProperty[] | cdktn.IResolvable;
        /**
        * column block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#column AwsTable#column}
        */
        readonly column: ColumnProperty[] | cdktn.IResolvable;
        /**
        * partition_key block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#partition_key AwsTable#partition_key}
        */
        readonly partitionKey: PartitionKeyProperty[] | cdktn.IResolvable;
        /**
        * static_column block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#static_column AwsTable#static_column}
        */
        readonly staticColumn?: StaticColumnProperty[] | cdktn.IResolvable;
    }
    class SchemaDefinitionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SchemaDefinitionProperty | undefined;
        set internalValue(value: SchemaDefinitionProperty | undefined);
        private _clusteringKey;
        get clusteringKey(): ClusteringKeyPropertyList;
        putClusteringKey(value: ClusteringKeyProperty[] | cdktn.IResolvable): void;
        resetClusteringKey(): void;
        get clusteringKeyInput(): cdktn.IResolvable | ClusteringKeyProperty[] | undefined;
        private _column;
        get column(): ColumnPropertyList;
        putColumn(value: ColumnProperty[] | cdktn.IResolvable): void;
        get columnInput(): cdktn.IResolvable | ColumnProperty[] | undefined;
        private _partitionKey;
        get partitionKey(): PartitionKeyPropertyList;
        putPartitionKey(value: PartitionKeyProperty[] | cdktn.IResolvable): void;
        get partitionKeyInput(): cdktn.IResolvable | PartitionKeyProperty[] | undefined;
        private _staticColumn;
        get staticColumn(): StaticColumnPropertyList;
        putStaticColumn(value: StaticColumnProperty[] | cdktn.IResolvable): void;
        resetStaticColumn(): void;
        get staticColumnInput(): cdktn.IResolvable | StaticColumnProperty[] | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#create AwsTable#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#delete AwsTable#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#update AwsTable#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface TtlProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#status AwsTable#status}
        */
        readonly status: string;
    }
    class TtlPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TtlProperty | undefined;
        set internalValue(value: TtlProperty | undefined);
        private _status?;
        get status(): string;
        set status(value: string);
        get statusInput(): string | undefined;
    }
}
