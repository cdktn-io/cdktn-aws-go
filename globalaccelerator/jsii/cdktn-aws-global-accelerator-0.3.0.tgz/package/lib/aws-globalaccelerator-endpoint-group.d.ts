import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsEndpointGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_endpoint_group#endpoint_group_region AwsEndpointGroup#endpoint_group_region}
    */
    readonly endpointGroupRegion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_endpoint_group#health_check_interval_seconds AwsEndpointGroup#health_check_interval_seconds}
    */
    readonly healthCheckIntervalSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_endpoint_group#health_check_path AwsEndpointGroup#health_check_path}
    */
    readonly healthCheckPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_endpoint_group#health_check_port AwsEndpointGroup#health_check_port}
    */
    readonly healthCheckPort?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_endpoint_group#health_check_protocol AwsEndpointGroup#health_check_protocol}
    */
    readonly healthCheckProtocol?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_endpoint_group#id AwsEndpointGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_endpoint_group#listener_arn AwsEndpointGroup#listener_arn}
    */
    readonly listenerArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_endpoint_group#threshold_count AwsEndpointGroup#threshold_count}
    */
    readonly thresholdCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_endpoint_group#traffic_dial_percentage AwsEndpointGroup#traffic_dial_percentage}
    */
    readonly trafficDialPercentage?: number;
    /**
    * endpoint_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_endpoint_group#endpoint_configuration AwsEndpointGroup#endpoint_configuration}
    */
    readonly endpointConfiguration?: AwsEndpointGroup.EndpointConfigurationProperty[] | cdktn.IResolvable;
    /**
    * port_override block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_endpoint_group#port_override AwsEndpointGroup#port_override}
    */
    readonly portOverride?: AwsEndpointGroup.PortOverrideProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_endpoint_group#timeouts AwsEndpointGroup#timeouts}
    */
    readonly timeouts?: AwsEndpointGroup.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_endpoint_group aws_globalaccelerator_endpoint_group}
*/
export declare class AwsEndpointGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_globalaccelerator_endpoint_group";
    /**
    * Generates CDKTN code for importing a AwsEndpointGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsEndpointGroup to import
    * @param importFromId The id of the existing AwsEndpointGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_endpoint_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsEndpointGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_endpoint_group aws_globalaccelerator_endpoint_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsEndpointGroupConfig
    */
    constructor(scope: Construct, id: string, config: AwsEndpointGroupConfig);
    get arn(): string;
    private _endpointGroupRegion?;
    get endpointGroupRegion(): string;
    set endpointGroupRegion(value: string);
    resetEndpointGroupRegion(): void;
    get endpointGroupRegionInput(): string | undefined;
    private _healthCheckIntervalSeconds?;
    get healthCheckIntervalSeconds(): number;
    set healthCheckIntervalSeconds(value: number);
    resetHealthCheckIntervalSeconds(): void;
    get healthCheckIntervalSecondsInput(): number | undefined;
    private _healthCheckPath?;
    get healthCheckPath(): string;
    set healthCheckPath(value: string);
    resetHealthCheckPath(): void;
    get healthCheckPathInput(): string | undefined;
    private _healthCheckPort?;
    get healthCheckPort(): number;
    set healthCheckPort(value: number);
    resetHealthCheckPort(): void;
    get healthCheckPortInput(): number | undefined;
    private _healthCheckProtocol?;
    get healthCheckProtocol(): string;
    set healthCheckProtocol(value: string);
    resetHealthCheckProtocol(): void;
    get healthCheckProtocolInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _listenerArn?;
    get listenerArn(): string;
    set listenerArn(value: string);
    get listenerArnInput(): string | undefined;
    private _thresholdCount?;
    get thresholdCount(): number;
    set thresholdCount(value: number);
    resetThresholdCount(): void;
    get thresholdCountInput(): number | undefined;
    private _trafficDialPercentage?;
    get trafficDialPercentage(): number;
    set trafficDialPercentage(value: number);
    resetTrafficDialPercentage(): void;
    get trafficDialPercentageInput(): number | undefined;
    private _endpointConfiguration;
    get endpointConfiguration(): AwsEndpointGroup.EndpointConfigurationPropertyList;
    putEndpointConfiguration(value: AwsEndpointGroup.EndpointConfigurationProperty[] | cdktn.IResolvable): void;
    resetEndpointConfiguration(): void;
    get endpointConfigurationInput(): cdktn.IResolvable | AwsEndpointGroup.EndpointConfigurationProperty[] | undefined;
    private _portOverride;
    get portOverride(): AwsEndpointGroup.PortOverridePropertyList;
    putPortOverride(value: AwsEndpointGroup.PortOverrideProperty[] | cdktn.IResolvable): void;
    resetPortOverride(): void;
    get portOverrideInput(): cdktn.IResolvable | AwsEndpointGroup.PortOverrideProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsEndpointGroup.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsEndpointGroup.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsEndpointGroup.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsEndpointGroupEndpointConfigurationPropertyToTerraform(struct?: AwsEndpointGroup.EndpointConfigurationProperty | cdktn.IResolvable): any;
export declare function awsEndpointGroupEndpointConfigurationPropertyToHclTerraform(struct?: AwsEndpointGroup.EndpointConfigurationProperty | cdktn.IResolvable): any;
export declare function awsEndpointGroupPortOverridePropertyToTerraform(struct?: AwsEndpointGroup.PortOverrideProperty | cdktn.IResolvable): any;
export declare function awsEndpointGroupPortOverridePropertyToHclTerraform(struct?: AwsEndpointGroup.PortOverrideProperty | cdktn.IResolvable): any;
export declare function awsEndpointGroupTimeoutsPropertyToTerraform(struct?: AwsEndpointGroup.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsEndpointGroupTimeoutsPropertyToHclTerraform(struct?: AwsEndpointGroup.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsEndpointGroup {
    interface EndpointConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_endpoint_group#attachment_arn AwsEndpointGroup#attachment_arn}
        */
        readonly attachmentArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_endpoint_group#client_ip_preservation_enabled AwsEndpointGroup#client_ip_preservation_enabled}
        */
        readonly clientIpPreservationEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_endpoint_group#endpoint_id AwsEndpointGroup#endpoint_id}
        */
        readonly endpointId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_endpoint_group#weight AwsEndpointGroup#weight}
        */
        readonly weight?: number;
    }
    class EndpointConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EndpointConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EndpointConfigurationProperty | cdktn.IResolvable | undefined);
        private _attachmentArn?;
        get attachmentArn(): string;
        set attachmentArn(value: string);
        resetAttachmentArn(): void;
        get attachmentArnInput(): string | undefined;
        private _clientIpPreservationEnabled?;
        get clientIpPreservationEnabled(): boolean | cdktn.IResolvable;
        set clientIpPreservationEnabled(value: boolean | cdktn.IResolvable);
        resetClientIpPreservationEnabled(): void;
        get clientIpPreservationEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _endpointId?;
        get endpointId(): string;
        set endpointId(value: string);
        resetEndpointId(): void;
        get endpointIdInput(): string | undefined;
        private _weight?;
        get weight(): number;
        set weight(value: number);
        resetWeight(): void;
        get weightInput(): number | undefined;
    }
    class EndpointConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: EndpointConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EndpointConfigurationPropertyOutputReference;
    }
    interface PortOverrideProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_endpoint_group#endpoint_port AwsEndpointGroup#endpoint_port}
        */
        readonly endpointPort: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_endpoint_group#listener_port AwsEndpointGroup#listener_port}
        */
        readonly listenerPort: number;
    }
    class PortOverridePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PortOverrideProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PortOverrideProperty | cdktn.IResolvable | undefined);
        private _endpointPort?;
        get endpointPort(): number;
        set endpointPort(value: number);
        get endpointPortInput(): number | undefined;
        private _listenerPort?;
        get listenerPort(): number;
        set listenerPort(value: number);
        get listenerPortInput(): number | undefined;
    }
    class PortOverridePropertyList extends cdktn.ComplexList {
        internalValue?: PortOverrideProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PortOverridePropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_endpoint_group#create AwsEndpointGroup#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_endpoint_group#delete AwsEndpointGroup#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_endpoint_group#update AwsEndpointGroup#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
