import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsEmrcontainersJobTemplateConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_job_template#id AwsEmrcontainersJobTemplate#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_job_template#kms_key_arn AwsEmrcontainersJobTemplate#kms_key_arn}
    */
    readonly kmsKeyArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_job_template#name AwsEmrcontainersJobTemplate#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_job_template#region AwsEmrcontainersJobTemplate#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_job_template#tags AwsEmrcontainersJobTemplate#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_job_template#tags_all AwsEmrcontainersJobTemplate#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * job_template_data block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_job_template#job_template_data AwsEmrcontainersJobTemplate#job_template_data}
    */
    readonly jobTemplateData: AwsEmrcontainersJobTemplate.JobTemplateDataProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_job_template#timeouts AwsEmrcontainersJobTemplate#timeouts}
    */
    readonly timeouts?: AwsEmrcontainersJobTemplate.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_job_template aws_emrcontainers_job_template}
*/
export declare class AwsEmrcontainersJobTemplate extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_emrcontainers_job_template";
    /**
    * Generates CDKTN code for importing a AwsEmrcontainersJobTemplate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsEmrcontainersJobTemplate to import
    * @param importFromId The id of the existing AwsEmrcontainersJobTemplate that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_job_template#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsEmrcontainersJobTemplate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_job_template aws_emrcontainers_job_template} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsEmrcontainersJobTemplateConfig
    */
    constructor(scope: Construct, id: string, config: AwsEmrcontainersJobTemplateConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _kmsKeyArn?;
    get kmsKeyArn(): string;
    set kmsKeyArn(value: string);
    resetKmsKeyArn(): void;
    get kmsKeyArnInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _jobTemplateData;
    get jobTemplateData(): AwsEmrcontainersJobTemplate.JobTemplateDataPropertyOutputReference;
    putJobTemplateData(value: AwsEmrcontainersJobTemplate.JobTemplateDataProperty): void;
    get jobTemplateDataInput(): AwsEmrcontainersJobTemplate.JobTemplateDataProperty | undefined;
    private _timeouts;
    get timeouts(): AwsEmrcontainersJobTemplate.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsEmrcontainersJobTemplate.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): AwsEmrcontainersJobTemplate.TimeoutsProperty | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsEmrcontainersJobTemplateConfigurationsPropertyToTerraform(struct?: AwsEmrcontainersJobTemplate.ConfigurationsProperty | cdktn.IResolvable): any;
export declare function awsEmrcontainersJobTemplateConfigurationsPropertyToHclTerraform(struct?: AwsEmrcontainersJobTemplate.ConfigurationsProperty | cdktn.IResolvable): any;
export declare function awsEmrcontainersJobTemplateApplicationConfigurationPropertyToTerraform(struct?: AwsEmrcontainersJobTemplate.ApplicationConfigurationProperty | cdktn.IResolvable): any;
export declare function awsEmrcontainersJobTemplateApplicationConfigurationPropertyToHclTerraform(struct?: AwsEmrcontainersJobTemplate.ApplicationConfigurationProperty | cdktn.IResolvable): any;
export declare function awsEmrcontainersJobTemplateCloudWatchMonitoringConfigurationPropertyToTerraform(struct?: AwsEmrcontainersJobTemplate.CloudWatchMonitoringConfigurationPropertyOutputReference | AwsEmrcontainersJobTemplate.CloudWatchMonitoringConfigurationProperty): any;
export declare function awsEmrcontainersJobTemplateCloudWatchMonitoringConfigurationPropertyToHclTerraform(struct?: AwsEmrcontainersJobTemplate.CloudWatchMonitoringConfigurationPropertyOutputReference | AwsEmrcontainersJobTemplate.CloudWatchMonitoringConfigurationProperty): any;
export declare function awsEmrcontainersJobTemplateS3MonitoringConfigurationPropertyToTerraform(struct?: AwsEmrcontainersJobTemplate.S3MonitoringConfigurationPropertyOutputReference | AwsEmrcontainersJobTemplate.S3MonitoringConfigurationProperty): any;
export declare function awsEmrcontainersJobTemplateS3MonitoringConfigurationPropertyToHclTerraform(struct?: AwsEmrcontainersJobTemplate.S3MonitoringConfigurationPropertyOutputReference | AwsEmrcontainersJobTemplate.S3MonitoringConfigurationProperty): any;
export declare function awsEmrcontainersJobTemplateMonitoringConfigurationPropertyToTerraform(struct?: AwsEmrcontainersJobTemplate.MonitoringConfigurationPropertyOutputReference | AwsEmrcontainersJobTemplate.MonitoringConfigurationProperty): any;
export declare function awsEmrcontainersJobTemplateMonitoringConfigurationPropertyToHclTerraform(struct?: AwsEmrcontainersJobTemplate.MonitoringConfigurationPropertyOutputReference | AwsEmrcontainersJobTemplate.MonitoringConfigurationProperty): any;
export declare function awsEmrcontainersJobTemplateConfigurationOverridesPropertyToTerraform(struct?: AwsEmrcontainersJobTemplate.ConfigurationOverridesPropertyOutputReference | AwsEmrcontainersJobTemplate.ConfigurationOverridesProperty): any;
export declare function awsEmrcontainersJobTemplateConfigurationOverridesPropertyToHclTerraform(struct?: AwsEmrcontainersJobTemplate.ConfigurationOverridesPropertyOutputReference | AwsEmrcontainersJobTemplate.ConfigurationOverridesProperty): any;
export declare function awsEmrcontainersJobTemplateSparkSqlJobDriverPropertyToTerraform(struct?: AwsEmrcontainersJobTemplate.SparkSqlJobDriverPropertyOutputReference | AwsEmrcontainersJobTemplate.SparkSqlJobDriverProperty): any;
export declare function awsEmrcontainersJobTemplateSparkSqlJobDriverPropertyToHclTerraform(struct?: AwsEmrcontainersJobTemplate.SparkSqlJobDriverPropertyOutputReference | AwsEmrcontainersJobTemplate.SparkSqlJobDriverProperty): any;
export declare function awsEmrcontainersJobTemplateSparkSubmitJobDriverPropertyToTerraform(struct?: AwsEmrcontainersJobTemplate.SparkSubmitJobDriverPropertyOutputReference | AwsEmrcontainersJobTemplate.SparkSubmitJobDriverProperty): any;
export declare function awsEmrcontainersJobTemplateSparkSubmitJobDriverPropertyToHclTerraform(struct?: AwsEmrcontainersJobTemplate.SparkSubmitJobDriverPropertyOutputReference | AwsEmrcontainersJobTemplate.SparkSubmitJobDriverProperty): any;
export declare function awsEmrcontainersJobTemplateJobDriverPropertyToTerraform(struct?: AwsEmrcontainersJobTemplate.JobDriverPropertyOutputReference | AwsEmrcontainersJobTemplate.JobDriverProperty): any;
export declare function awsEmrcontainersJobTemplateJobDriverPropertyToHclTerraform(struct?: AwsEmrcontainersJobTemplate.JobDriverPropertyOutputReference | AwsEmrcontainersJobTemplate.JobDriverProperty): any;
export declare function awsEmrcontainersJobTemplateJobTemplateDataPropertyToTerraform(struct?: AwsEmrcontainersJobTemplate.JobTemplateDataPropertyOutputReference | AwsEmrcontainersJobTemplate.JobTemplateDataProperty): any;
export declare function awsEmrcontainersJobTemplateJobTemplateDataPropertyToHclTerraform(struct?: AwsEmrcontainersJobTemplate.JobTemplateDataPropertyOutputReference | AwsEmrcontainersJobTemplate.JobTemplateDataProperty): any;
export declare function awsEmrcontainersJobTemplateTimeoutsPropertyToTerraform(struct?: AwsEmrcontainersJobTemplate.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsEmrcontainersJobTemplateTimeoutsPropertyToHclTerraform(struct?: AwsEmrcontainersJobTemplate.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsEmrcontainersJobTemplate {
    interface ConfigurationsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_job_template#classification AwsEmrcontainersJobTemplate#classification}
        */
        readonly classification?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_job_template#properties AwsEmrcontainersJobTemplate#properties}
        */
        readonly properties?: {
            [key: string]: string;
        };
    }
    class ConfigurationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConfigurationsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConfigurationsProperty | cdktn.IResolvable | undefined);
        private _classification?;
        get classification(): string;
        set classification(value: string);
        resetClassification(): void;
        get classificationInput(): string | undefined;
        private _properties?;
        get properties(): {
            [key: string]: string;
        };
        set properties(value: {
            [key: string]: string;
        });
        resetProperties(): void;
        get propertiesInput(): {
            [key: string]: string;
        } | undefined;
    }
    class ConfigurationsPropertyList extends cdktn.ComplexList {
        internalValue?: ConfigurationsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConfigurationsPropertyOutputReference;
    }
    interface ApplicationConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_job_template#classification AwsEmrcontainersJobTemplate#classification}
        */
        readonly classification: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_job_template#properties AwsEmrcontainersJobTemplate#properties}
        */
        readonly properties?: {
            [key: string]: string;
        };
        /**
        * configurations block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_job_template#configurations AwsEmrcontainersJobTemplate#configurations}
        */
        readonly configurations?: ConfigurationsProperty[] | cdktn.IResolvable;
    }
    class ApplicationConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ApplicationConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ApplicationConfigurationProperty | cdktn.IResolvable | undefined);
        private _classification?;
        get classification(): string;
        set classification(value: string);
        get classificationInput(): string | undefined;
        private _properties?;
        get properties(): {
            [key: string]: string;
        };
        set properties(value: {
            [key: string]: string;
        });
        resetProperties(): void;
        get propertiesInput(): {
            [key: string]: string;
        } | undefined;
        private _configurations;
        get configurations(): ConfigurationsPropertyList;
        putConfigurations(value: ConfigurationsProperty[] | cdktn.IResolvable): void;
        resetConfigurations(): void;
        get configurationsInput(): cdktn.IResolvable | ConfigurationsProperty[] | undefined;
    }
    class ApplicationConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: ApplicationConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ApplicationConfigurationPropertyOutputReference;
    }
    interface CloudWatchMonitoringConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_job_template#log_group_name AwsEmrcontainersJobTemplate#log_group_name}
        */
        readonly logGroupName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_job_template#log_stream_name_prefix AwsEmrcontainersJobTemplate#log_stream_name_prefix}
        */
        readonly logStreamNamePrefix?: string;
    }
    class CloudWatchMonitoringConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CloudWatchMonitoringConfigurationProperty | undefined;
        set internalValue(value: CloudWatchMonitoringConfigurationProperty | undefined);
        private _logGroupName?;
        get logGroupName(): string;
        set logGroupName(value: string);
        get logGroupNameInput(): string | undefined;
        private _logStreamNamePrefix?;
        get logStreamNamePrefix(): string;
        set logStreamNamePrefix(value: string);
        resetLogStreamNamePrefix(): void;
        get logStreamNamePrefixInput(): string | undefined;
    }
    interface S3MonitoringConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_job_template#log_uri AwsEmrcontainersJobTemplate#log_uri}
        */
        readonly logUri: string;
    }
    class S3MonitoringConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3MonitoringConfigurationProperty | undefined;
        set internalValue(value: S3MonitoringConfigurationProperty | undefined);
        private _logUri?;
        get logUri(): string;
        set logUri(value: string);
        get logUriInput(): string | undefined;
    }
    interface MonitoringConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_job_template#persistent_app_ui AwsEmrcontainersJobTemplate#persistent_app_ui}
        */
        readonly persistentAppUi?: string;
        /**
        * cloud_watch_monitoring_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_job_template#cloud_watch_monitoring_configuration AwsEmrcontainersJobTemplate#cloud_watch_monitoring_configuration}
        */
        readonly cloudWatchMonitoringConfiguration?: CloudWatchMonitoringConfigurationProperty;
        /**
        * s3_monitoring_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_job_template#s3_monitoring_configuration AwsEmrcontainersJobTemplate#s3_monitoring_configuration}
        */
        readonly s3MonitoringConfiguration?: S3MonitoringConfigurationProperty;
    }
    class MonitoringConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MonitoringConfigurationProperty | undefined;
        set internalValue(value: MonitoringConfigurationProperty | undefined);
        private _persistentAppUi?;
        get persistentAppUi(): string;
        set persistentAppUi(value: string);
        resetPersistentAppUi(): void;
        get persistentAppUiInput(): string | undefined;
        private _cloudWatchMonitoringConfiguration;
        get cloudWatchMonitoringConfiguration(): CloudWatchMonitoringConfigurationPropertyOutputReference;
        putCloudWatchMonitoringConfiguration(value: CloudWatchMonitoringConfigurationProperty): void;
        resetCloudWatchMonitoringConfiguration(): void;
        get cloudWatchMonitoringConfigurationInput(): CloudWatchMonitoringConfigurationProperty | undefined;
        private _s3MonitoringConfiguration;
        get s3MonitoringConfiguration(): S3MonitoringConfigurationPropertyOutputReference;
        putS3MonitoringConfiguration(value: S3MonitoringConfigurationProperty): void;
        resetS3MonitoringConfiguration(): void;
        get s3MonitoringConfigurationInput(): S3MonitoringConfigurationProperty | undefined;
    }
    interface ConfigurationOverridesProperty {
        /**
        * application_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_job_template#application_configuration AwsEmrcontainersJobTemplate#application_configuration}
        */
        readonly applicationConfiguration?: ApplicationConfigurationProperty[] | cdktn.IResolvable;
        /**
        * monitoring_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_job_template#monitoring_configuration AwsEmrcontainersJobTemplate#monitoring_configuration}
        */
        readonly monitoringConfiguration?: MonitoringConfigurationProperty;
    }
    class ConfigurationOverridesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConfigurationOverridesProperty | undefined;
        set internalValue(value: ConfigurationOverridesProperty | undefined);
        private _applicationConfiguration;
        get applicationConfiguration(): ApplicationConfigurationPropertyList;
        putApplicationConfiguration(value: ApplicationConfigurationProperty[] | cdktn.IResolvable): void;
        resetApplicationConfiguration(): void;
        get applicationConfigurationInput(): cdktn.IResolvable | ApplicationConfigurationProperty[] | undefined;
        private _monitoringConfiguration;
        get monitoringConfiguration(): MonitoringConfigurationPropertyOutputReference;
        putMonitoringConfiguration(value: MonitoringConfigurationProperty): void;
        resetMonitoringConfiguration(): void;
        get monitoringConfigurationInput(): MonitoringConfigurationProperty | undefined;
    }
    interface SparkSqlJobDriverProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_job_template#entry_point AwsEmrcontainersJobTemplate#entry_point}
        */
        readonly entryPoint?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_job_template#spark_sql_parameters AwsEmrcontainersJobTemplate#spark_sql_parameters}
        */
        readonly sparkSqlParameters?: string;
    }
    class SparkSqlJobDriverPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SparkSqlJobDriverProperty | undefined;
        set internalValue(value: SparkSqlJobDriverProperty | undefined);
        private _entryPoint?;
        get entryPoint(): string;
        set entryPoint(value: string);
        resetEntryPoint(): void;
        get entryPointInput(): string | undefined;
        private _sparkSqlParameters?;
        get sparkSqlParameters(): string;
        set sparkSqlParameters(value: string);
        resetSparkSqlParameters(): void;
        get sparkSqlParametersInput(): string | undefined;
    }
    interface SparkSubmitJobDriverProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_job_template#entry_point AwsEmrcontainersJobTemplate#entry_point}
        */
        readonly entryPoint: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_job_template#entry_point_arguments AwsEmrcontainersJobTemplate#entry_point_arguments}
        */
        readonly entryPointArguments?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_job_template#spark_submit_parameters AwsEmrcontainersJobTemplate#spark_submit_parameters}
        */
        readonly sparkSubmitParameters?: string;
    }
    class SparkSubmitJobDriverPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SparkSubmitJobDriverProperty | undefined;
        set internalValue(value: SparkSubmitJobDriverProperty | undefined);
        private _entryPoint?;
        get entryPoint(): string;
        set entryPoint(value: string);
        get entryPointInput(): string | undefined;
        private _entryPointArguments?;
        get entryPointArguments(): string[];
        set entryPointArguments(value: string[]);
        resetEntryPointArguments(): void;
        get entryPointArgumentsInput(): string[] | undefined;
        private _sparkSubmitParameters?;
        get sparkSubmitParameters(): string;
        set sparkSubmitParameters(value: string);
        resetSparkSubmitParameters(): void;
        get sparkSubmitParametersInput(): string | undefined;
    }
    interface JobDriverProperty {
        /**
        * spark_sql_job_driver block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_job_template#spark_sql_job_driver AwsEmrcontainersJobTemplate#spark_sql_job_driver}
        */
        readonly sparkSqlJobDriver?: SparkSqlJobDriverProperty;
        /**
        * spark_submit_job_driver block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_job_template#spark_submit_job_driver AwsEmrcontainersJobTemplate#spark_submit_job_driver}
        */
        readonly sparkSubmitJobDriver?: SparkSubmitJobDriverProperty;
    }
    class JobDriverPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): JobDriverProperty | undefined;
        set internalValue(value: JobDriverProperty | undefined);
        private _sparkSqlJobDriver;
        get sparkSqlJobDriver(): SparkSqlJobDriverPropertyOutputReference;
        putSparkSqlJobDriver(value: SparkSqlJobDriverProperty): void;
        resetSparkSqlJobDriver(): void;
        get sparkSqlJobDriverInput(): SparkSqlJobDriverProperty | undefined;
        private _sparkSubmitJobDriver;
        get sparkSubmitJobDriver(): SparkSubmitJobDriverPropertyOutputReference;
        putSparkSubmitJobDriver(value: SparkSubmitJobDriverProperty): void;
        resetSparkSubmitJobDriver(): void;
        get sparkSubmitJobDriverInput(): SparkSubmitJobDriverProperty | undefined;
    }
    interface JobTemplateDataProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_job_template#execution_role_arn AwsEmrcontainersJobTemplate#execution_role_arn}
        */
        readonly executionRoleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_job_template#job_tags AwsEmrcontainersJobTemplate#job_tags}
        */
        readonly jobTags?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_job_template#release_label AwsEmrcontainersJobTemplate#release_label}
        */
        readonly releaseLabel: string;
        /**
        * configuration_overrides block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_job_template#configuration_overrides AwsEmrcontainersJobTemplate#configuration_overrides}
        */
        readonly configurationOverrides?: ConfigurationOverridesProperty;
        /**
        * job_driver block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_job_template#job_driver AwsEmrcontainersJobTemplate#job_driver}
        */
        readonly jobDriver: JobDriverProperty;
    }
    class JobTemplateDataPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): JobTemplateDataProperty | undefined;
        set internalValue(value: JobTemplateDataProperty | undefined);
        private _executionRoleArn?;
        get executionRoleArn(): string;
        set executionRoleArn(value: string);
        get executionRoleArnInput(): string | undefined;
        private _jobTags?;
        get jobTags(): {
            [key: string]: string;
        };
        set jobTags(value: {
            [key: string]: string;
        });
        resetJobTags(): void;
        get jobTagsInput(): {
            [key: string]: string;
        } | undefined;
        private _releaseLabel?;
        get releaseLabel(): string;
        set releaseLabel(value: string);
        get releaseLabelInput(): string | undefined;
        private _configurationOverrides;
        get configurationOverrides(): ConfigurationOverridesPropertyOutputReference;
        putConfigurationOverrides(value: ConfigurationOverridesProperty): void;
        resetConfigurationOverrides(): void;
        get configurationOverridesInput(): ConfigurationOverridesProperty | undefined;
        private _jobDriver;
        get jobDriver(): JobDriverPropertyOutputReference;
        putJobDriver(value: JobDriverProperty): void;
        get jobDriverInput(): JobDriverProperty | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_job_template#delete AwsEmrcontainersJobTemplate#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
