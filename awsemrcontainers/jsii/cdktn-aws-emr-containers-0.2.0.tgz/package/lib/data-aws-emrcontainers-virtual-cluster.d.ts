import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfVirtualClusterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/emrcontainers_virtual_cluster#id DataTfVirtualCluster#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/emrcontainers_virtual_cluster#region DataTfVirtualCluster#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/emrcontainers_virtual_cluster#tags DataTfVirtualCluster#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/emrcontainers_virtual_cluster#virtual_cluster_id DataTfVirtualCluster#virtual_cluster_id}
    */
    readonly virtualClusterId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/emrcontainers_virtual_cluster aws_emrcontainers_virtual_cluster}
*/
export declare class DataTfVirtualCluster extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_emrcontainers_virtual_cluster";
    /**
    * Generates CDKTN code for importing a DataTfVirtualCluster resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfVirtualCluster to import
    * @param importFromId The id of the existing DataTfVirtualCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/emrcontainers_virtual_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfVirtualCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/emrcontainers_virtual_cluster aws_emrcontainers_virtual_cluster} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfVirtualClusterConfig
    */
    constructor(scope: Construct, id: string, config: DataTfVirtualClusterConfig);
    get arn(): string;
    private _containerProvider;
    get containerProvider(): DataTfVirtualCluster.ContainerProviderPropertyList;
    get createdAt(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get name(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get state(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _virtualClusterId?;
    get virtualClusterId(): string;
    set virtualClusterId(value: string);
    get virtualClusterIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfVirtualClusterEksInfoPropertyToTerraform(struct?: DataTfVirtualCluster.EksInfoProperty): any;
export declare function dataTfVirtualClusterEksInfoPropertyToHclTerraform(struct?: DataTfVirtualCluster.EksInfoProperty): any;
export declare function dataTfVirtualClusterInfoPropertyToTerraform(struct?: DataTfVirtualCluster.InfoProperty): any;
export declare function dataTfVirtualClusterInfoPropertyToHclTerraform(struct?: DataTfVirtualCluster.InfoProperty): any;
export declare function dataTfVirtualClusterContainerProviderPropertyToTerraform(struct?: DataTfVirtualCluster.ContainerProviderProperty): any;
export declare function dataTfVirtualClusterContainerProviderPropertyToHclTerraform(struct?: DataTfVirtualCluster.ContainerProviderProperty): any;
export declare namespace DataTfVirtualCluster {
    interface EksInfoProperty {
    }
    class EksInfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EksInfoProperty | undefined;
        set internalValue(value: EksInfoProperty | undefined);
        get namespace(): string;
    }
    class EksInfoPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EksInfoPropertyOutputReference;
    }
    interface InfoProperty {
    }
    class InfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InfoProperty | undefined;
        set internalValue(value: InfoProperty | undefined);
        private _eksInfo;
        get eksInfo(): EksInfoPropertyList;
    }
    class InfoPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InfoPropertyOutputReference;
    }
    interface ContainerProviderProperty {
    }
    class ContainerProviderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ContainerProviderProperty | undefined;
        set internalValue(value: ContainerProviderProperty | undefined);
        get id(): string;
        private _info;
        get info(): InfoPropertyList;
        get type(): string;
    }
    class ContainerProviderPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ContainerProviderPropertyOutputReference;
    }
}
