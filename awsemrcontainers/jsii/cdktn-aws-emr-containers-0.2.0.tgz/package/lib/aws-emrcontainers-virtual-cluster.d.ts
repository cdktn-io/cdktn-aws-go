import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfVirtualClusterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_virtual_cluster#id TfVirtualCluster#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_virtual_cluster#name TfVirtualCluster#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_virtual_cluster#region TfVirtualCluster#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_virtual_cluster#tags TfVirtualCluster#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_virtual_cluster#tags_all TfVirtualCluster#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * container_provider block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_virtual_cluster#container_provider TfVirtualCluster#container_provider}
    */
    readonly containerProvider: TfVirtualCluster.ContainerProviderProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_virtual_cluster#timeouts TfVirtualCluster#timeouts}
    */
    readonly timeouts?: TfVirtualCluster.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_virtual_cluster aws_emrcontainers_virtual_cluster}
*/
export declare class TfVirtualCluster extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_emrcontainers_virtual_cluster";
    /**
    * Generates CDKTN code for importing a TfVirtualCluster resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfVirtualCluster to import
    * @param importFromId The id of the existing TfVirtualCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_virtual_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfVirtualCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_virtual_cluster aws_emrcontainers_virtual_cluster} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfVirtualClusterConfig
    */
    constructor(scope: Construct, id: string, config: TfVirtualClusterConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _containerProvider;
    get containerProvider(): TfVirtualCluster.ContainerProviderPropertyOutputReference;
    putContainerProvider(value: TfVirtualCluster.ContainerProviderProperty): void;
    get containerProviderInput(): TfVirtualCluster.ContainerProviderProperty | undefined;
    private _timeouts;
    get timeouts(): TfVirtualCluster.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfVirtualCluster.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfVirtualCluster.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfVirtualClusterEksInfoPropertyToTerraform(struct?: TfVirtualCluster.EksInfoPropertyOutputReference | TfVirtualCluster.EksInfoProperty): any;
export declare function tfVirtualClusterEksInfoPropertyToHclTerraform(struct?: TfVirtualCluster.EksInfoPropertyOutputReference | TfVirtualCluster.EksInfoProperty): any;
export declare function tfVirtualClusterInfoPropertyToTerraform(struct?: TfVirtualCluster.InfoPropertyOutputReference | TfVirtualCluster.InfoProperty): any;
export declare function tfVirtualClusterInfoPropertyToHclTerraform(struct?: TfVirtualCluster.InfoPropertyOutputReference | TfVirtualCluster.InfoProperty): any;
export declare function tfVirtualClusterContainerProviderPropertyToTerraform(struct?: TfVirtualCluster.ContainerProviderPropertyOutputReference | TfVirtualCluster.ContainerProviderProperty): any;
export declare function tfVirtualClusterContainerProviderPropertyToHclTerraform(struct?: TfVirtualCluster.ContainerProviderPropertyOutputReference | TfVirtualCluster.ContainerProviderProperty): any;
export declare function tfVirtualClusterTimeoutsPropertyToTerraform(struct?: TfVirtualCluster.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfVirtualClusterTimeoutsPropertyToHclTerraform(struct?: TfVirtualCluster.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfVirtualCluster {
    interface EksInfoProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_virtual_cluster#namespace TfVirtualCluster#namespace}
        */
        readonly namespace?: string;
    }
    class EksInfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EksInfoProperty | undefined;
        set internalValue(value: EksInfoProperty | undefined);
        private _namespace?;
        get namespace(): string;
        set namespace(value: string);
        resetNamespace(): void;
        get namespaceInput(): string | undefined;
    }
    interface InfoProperty {
        /**
        * eks_info block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_virtual_cluster#eks_info TfVirtualCluster#eks_info}
        */
        readonly eksInfo: EksInfoProperty;
    }
    class InfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InfoProperty | undefined;
        set internalValue(value: InfoProperty | undefined);
        private _eksInfo;
        get eksInfo(): EksInfoPropertyOutputReference;
        putEksInfo(value: EksInfoProperty): void;
        get eksInfoInput(): EksInfoProperty | undefined;
    }
    interface ContainerProviderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_virtual_cluster#id TfVirtualCluster#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_virtual_cluster#type TfVirtualCluster#type}
        */
        readonly type: string;
        /**
        * info block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_virtual_cluster#info TfVirtualCluster#info}
        */
        readonly info: InfoProperty;
    }
    class ContainerProviderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ContainerProviderProperty | undefined;
        set internalValue(value: ContainerProviderProperty | undefined);
        private _id?;
        get id(): string;
        set id(value: string);
        get idInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _info;
        get info(): InfoPropertyOutputReference;
        putInfo(value: InfoProperty): void;
        get infoInput(): InfoProperty | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_virtual_cluster#delete TfVirtualCluster#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
