import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsHostConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codeconnections_host#name AwsHost#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codeconnections_host#provider_endpoint AwsHost#provider_endpoint}
    */
    readonly providerEndpoint: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codeconnections_host#provider_type AwsHost#provider_type}
    */
    readonly providerType: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codeconnections_host#region AwsHost#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codeconnections_host#tags AwsHost#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codeconnections_host#timeouts AwsHost#timeouts}
    */
    readonly timeouts?: AwsHost.TimeoutsProperty;
    /**
    * vpc_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codeconnections_host#vpc_configuration AwsHost#vpc_configuration}
    */
    readonly vpcConfiguration?: AwsHost.VpcConfigurationProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codeconnections_host aws_codeconnections_host}
*/
export declare class AwsHost extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_codeconnections_host";
    /**
    * Generates CDKTN code for importing a AwsHost resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsHost to import
    * @param importFromId The id of the existing AwsHost that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codeconnections_host#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsHost to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codeconnections_host aws_codeconnections_host} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsHostConfig
    */
    constructor(scope: Construct, id: string, config: AwsHostConfig);
    get arn(): string;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerEndpoint?;
    get providerEndpoint(): string;
    set providerEndpoint(value: string);
    get providerEndpointInput(): string | undefined;
    private _providerType?;
    get providerType(): string;
    set providerType(value: string);
    get providerTypeInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _timeouts;
    get timeouts(): AwsHost.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsHost.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsHost.TimeoutsProperty | undefined;
    private _vpcConfiguration;
    get vpcConfiguration(): AwsHost.VpcConfigurationPropertyList;
    putVpcConfiguration(value: AwsHost.VpcConfigurationProperty[] | cdktn.IResolvable): void;
    resetVpcConfiguration(): void;
    get vpcConfigurationInput(): cdktn.IResolvable | AwsHost.VpcConfigurationProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsHostTimeoutsPropertyToTerraform(struct?: AwsHost.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsHostTimeoutsPropertyToHclTerraform(struct?: AwsHost.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsHostVpcConfigurationPropertyToTerraform(struct?: AwsHost.VpcConfigurationProperty | cdktn.IResolvable): any;
export declare function awsHostVpcConfigurationPropertyToHclTerraform(struct?: AwsHost.VpcConfigurationProperty | cdktn.IResolvable): any;
export declare namespace AwsHost {
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codeconnections_host#create AwsHost#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codeconnections_host#delete AwsHost#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codeconnections_host#update AwsHost#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface VpcConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codeconnections_host#security_group_ids AwsHost#security_group_ids}
        */
        readonly securityGroupIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codeconnections_host#subnet_ids AwsHost#subnet_ids}
        */
        readonly subnetIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codeconnections_host#tls_certificate AwsHost#tls_certificate}
        */
        readonly tlsCertificate?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codeconnections_host#vpc_id AwsHost#vpc_id}
        */
        readonly vpcId: string;
    }
    class VpcConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VpcConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VpcConfigurationProperty | cdktn.IResolvable | undefined);
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        get subnetIdsInput(): string[] | undefined;
        private _tlsCertificate?;
        get tlsCertificate(): string;
        set tlsCertificate(value: string);
        resetTlsCertificate(): void;
        get tlsCertificateInput(): string | undefined;
        private _vpcId?;
        get vpcId(): string;
        set vpcId(value: string);
        get vpcIdInput(): string | undefined;
    }
    class VpcConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: VpcConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VpcConfigurationPropertyOutputReference;
    }
}
