import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAlbTargetGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group#connection_termination AwsAlbTargetGroup#connection_termination}
    */
    readonly connectionTermination?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group#deregistration_delay AwsAlbTargetGroup#deregistration_delay}
    */
    readonly deregistrationDelay?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group#id AwsAlbTargetGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group#ip_address_type AwsAlbTargetGroup#ip_address_type}
    */
    readonly ipAddressType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group#lambda_multi_value_headers_enabled AwsAlbTargetGroup#lambda_multi_value_headers_enabled}
    */
    readonly lambdaMultiValueHeadersEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group#load_balancing_algorithm_type AwsAlbTargetGroup#load_balancing_algorithm_type}
    */
    readonly loadBalancingAlgorithmType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group#load_balancing_anomaly_mitigation AwsAlbTargetGroup#load_balancing_anomaly_mitigation}
    */
    readonly loadBalancingAnomalyMitigation?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group#load_balancing_cross_zone_enabled AwsAlbTargetGroup#load_balancing_cross_zone_enabled}
    */
    readonly loadBalancingCrossZoneEnabled?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group#name AwsAlbTargetGroup#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group#name_prefix AwsAlbTargetGroup#name_prefix}
    */
    readonly namePrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group#port AwsAlbTargetGroup#port}
    */
    readonly port?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group#preserve_client_ip AwsAlbTargetGroup#preserve_client_ip}
    */
    readonly preserveClientIp?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group#protocol AwsAlbTargetGroup#protocol}
    */
    readonly protocol?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group#protocol_version AwsAlbTargetGroup#protocol_version}
    */
    readonly protocolVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group#proxy_protocol_v2 AwsAlbTargetGroup#proxy_protocol_v2}
    */
    readonly proxyProtocolV2?: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group#region AwsAlbTargetGroup#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group#slow_start AwsAlbTargetGroup#slow_start}
    */
    readonly slowStart?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group#tags AwsAlbTargetGroup#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group#tags_all AwsAlbTargetGroup#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group#target_control_port AwsAlbTargetGroup#target_control_port}
    */
    readonly targetControlPort?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group#target_type AwsAlbTargetGroup#target_type}
    */
    readonly targetType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group#vpc_id AwsAlbTargetGroup#vpc_id}
    */
    readonly vpcId?: string;
    /**
    * health_check block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group#health_check AwsAlbTargetGroup#health_check}
    */
    readonly healthCheck?: AwsAlbTargetGroup.HealthCheckProperty;
    /**
    * stickiness block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group#stickiness AwsAlbTargetGroup#stickiness}
    */
    readonly stickiness?: AwsAlbTargetGroup.StickinessProperty;
    /**
    * target_failover block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group#target_failover AwsAlbTargetGroup#target_failover}
    */
    readonly targetFailover?: AwsAlbTargetGroup.TargetFailoverProperty[] | cdktn.IResolvable;
    /**
    * target_group_health block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group#target_group_health AwsAlbTargetGroup#target_group_health}
    */
    readonly targetGroupHealth?: AwsAlbTargetGroup.TargetGroupHealthProperty;
    /**
    * target_health_state block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group#target_health_state AwsAlbTargetGroup#target_health_state}
    */
    readonly targetHealthState?: AwsAlbTargetGroup.TargetHealthStateProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group aws_alb_target_group}
*/
export declare class AwsAlbTargetGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_alb_target_group";
    /**
    * Generates CDKTN code for importing a AwsAlbTargetGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsAlbTargetGroup to import
    * @param importFromId The id of the existing AwsAlbTargetGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsAlbTargetGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group aws_alb_target_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAlbTargetGroupConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AwsAlbTargetGroupConfig);
    get arn(): string;
    get arnSuffix(): string;
    private _connectionTermination?;
    get connectionTermination(): boolean | cdktn.IResolvable;
    set connectionTermination(value: boolean | cdktn.IResolvable);
    resetConnectionTermination(): void;
    get connectionTerminationInput(): boolean | cdktn.IResolvable | undefined;
    private _deregistrationDelay?;
    get deregistrationDelay(): string;
    set deregistrationDelay(value: string);
    resetDeregistrationDelay(): void;
    get deregistrationDelayInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ipAddressType?;
    get ipAddressType(): string;
    set ipAddressType(value: string);
    resetIpAddressType(): void;
    get ipAddressTypeInput(): string | undefined;
    private _lambdaMultiValueHeadersEnabled?;
    get lambdaMultiValueHeadersEnabled(): boolean | cdktn.IResolvable;
    set lambdaMultiValueHeadersEnabled(value: boolean | cdktn.IResolvable);
    resetLambdaMultiValueHeadersEnabled(): void;
    get lambdaMultiValueHeadersEnabledInput(): boolean | cdktn.IResolvable | undefined;
    get loadBalancerArns(): string[];
    private _loadBalancingAlgorithmType?;
    get loadBalancingAlgorithmType(): string;
    set loadBalancingAlgorithmType(value: string);
    resetLoadBalancingAlgorithmType(): void;
    get loadBalancingAlgorithmTypeInput(): string | undefined;
    private _loadBalancingAnomalyMitigation?;
    get loadBalancingAnomalyMitigation(): string;
    set loadBalancingAnomalyMitigation(value: string);
    resetLoadBalancingAnomalyMitigation(): void;
    get loadBalancingAnomalyMitigationInput(): string | undefined;
    private _loadBalancingCrossZoneEnabled?;
    get loadBalancingCrossZoneEnabled(): string;
    set loadBalancingCrossZoneEnabled(value: string);
    resetLoadBalancingCrossZoneEnabled(): void;
    get loadBalancingCrossZoneEnabledInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namePrefix?;
    get namePrefix(): string;
    set namePrefix(value: string);
    resetNamePrefix(): void;
    get namePrefixInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
    private _preserveClientIp?;
    get preserveClientIp(): string;
    set preserveClientIp(value: string);
    resetPreserveClientIp(): void;
    get preserveClientIpInput(): string | undefined;
    private _protocol?;
    get protocol(): string;
    set protocol(value: string);
    resetProtocol(): void;
    get protocolInput(): string | undefined;
    private _protocolVersion?;
    get protocolVersion(): string;
    set protocolVersion(value: string);
    resetProtocolVersion(): void;
    get protocolVersionInput(): string | undefined;
    private _proxyProtocolV2?;
    get proxyProtocolV2(): boolean | cdktn.IResolvable;
    set proxyProtocolV2(value: boolean | cdktn.IResolvable);
    resetProxyProtocolV2(): void;
    get proxyProtocolV2Input(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _slowStart?;
    get slowStart(): number;
    set slowStart(value: number);
    resetSlowStart(): void;
    get slowStartInput(): number | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _targetControlPort?;
    get targetControlPort(): number;
    set targetControlPort(value: number);
    resetTargetControlPort(): void;
    get targetControlPortInput(): number | undefined;
    private _targetType?;
    get targetType(): string;
    set targetType(value: string);
    resetTargetType(): void;
    get targetTypeInput(): string | undefined;
    private _vpcId?;
    get vpcId(): string;
    set vpcId(value: string);
    resetVpcId(): void;
    get vpcIdInput(): string | undefined;
    private _healthCheck;
    get healthCheck(): AwsAlbTargetGroup.HealthCheckPropertyOutputReference;
    putHealthCheck(value: AwsAlbTargetGroup.HealthCheckProperty): void;
    resetHealthCheck(): void;
    get healthCheckInput(): AwsAlbTargetGroup.HealthCheckProperty | undefined;
    private _stickiness;
    get stickiness(): AwsAlbTargetGroup.StickinessPropertyOutputReference;
    putStickiness(value: AwsAlbTargetGroup.StickinessProperty): void;
    resetStickiness(): void;
    get stickinessInput(): AwsAlbTargetGroup.StickinessProperty | undefined;
    private _targetFailover;
    get targetFailover(): AwsAlbTargetGroup.TargetFailoverPropertyList;
    putTargetFailover(value: AwsAlbTargetGroup.TargetFailoverProperty[] | cdktn.IResolvable): void;
    resetTargetFailover(): void;
    get targetFailoverInput(): cdktn.IResolvable | AwsAlbTargetGroup.TargetFailoverProperty[] | undefined;
    private _targetGroupHealth;
    get targetGroupHealth(): AwsAlbTargetGroup.TargetGroupHealthPropertyOutputReference;
    putTargetGroupHealth(value: AwsAlbTargetGroup.TargetGroupHealthProperty): void;
    resetTargetGroupHealth(): void;
    get targetGroupHealthInput(): AwsAlbTargetGroup.TargetGroupHealthProperty | undefined;
    private _targetHealthState;
    get targetHealthState(): AwsAlbTargetGroup.TargetHealthStatePropertyList;
    putTargetHealthState(value: AwsAlbTargetGroup.TargetHealthStateProperty[] | cdktn.IResolvable): void;
    resetTargetHealthState(): void;
    get targetHealthStateInput(): cdktn.IResolvable | AwsAlbTargetGroup.TargetHealthStateProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsAlbTargetGroupHealthCheckPropertyToTerraform(struct?: AwsAlbTargetGroup.HealthCheckPropertyOutputReference | AwsAlbTargetGroup.HealthCheckProperty): any;
export declare function awsAlbTargetGroupHealthCheckPropertyToHclTerraform(struct?: AwsAlbTargetGroup.HealthCheckPropertyOutputReference | AwsAlbTargetGroup.HealthCheckProperty): any;
export declare function awsAlbTargetGroupStickinessPropertyToTerraform(struct?: AwsAlbTargetGroup.StickinessPropertyOutputReference | AwsAlbTargetGroup.StickinessProperty): any;
export declare function awsAlbTargetGroupStickinessPropertyToHclTerraform(struct?: AwsAlbTargetGroup.StickinessPropertyOutputReference | AwsAlbTargetGroup.StickinessProperty): any;
export declare function awsAlbTargetGroupTargetFailoverPropertyToTerraform(struct?: AwsAlbTargetGroup.TargetFailoverProperty | cdktn.IResolvable): any;
export declare function awsAlbTargetGroupTargetFailoverPropertyToHclTerraform(struct?: AwsAlbTargetGroup.TargetFailoverProperty | cdktn.IResolvable): any;
export declare function awsAlbTargetGroupDnsFailoverPropertyToTerraform(struct?: AwsAlbTargetGroup.DnsFailoverPropertyOutputReference | AwsAlbTargetGroup.DnsFailoverProperty): any;
export declare function awsAlbTargetGroupDnsFailoverPropertyToHclTerraform(struct?: AwsAlbTargetGroup.DnsFailoverPropertyOutputReference | AwsAlbTargetGroup.DnsFailoverProperty): any;
export declare function awsAlbTargetGroupUnhealthyStateRoutingPropertyToTerraform(struct?: AwsAlbTargetGroup.UnhealthyStateRoutingPropertyOutputReference | AwsAlbTargetGroup.UnhealthyStateRoutingProperty): any;
export declare function awsAlbTargetGroupUnhealthyStateRoutingPropertyToHclTerraform(struct?: AwsAlbTargetGroup.UnhealthyStateRoutingPropertyOutputReference | AwsAlbTargetGroup.UnhealthyStateRoutingProperty): any;
export declare function awsAlbTargetGroupTargetGroupHealthPropertyToTerraform(struct?: AwsAlbTargetGroup.TargetGroupHealthPropertyOutputReference | AwsAlbTargetGroup.TargetGroupHealthProperty): any;
export declare function awsAlbTargetGroupTargetGroupHealthPropertyToHclTerraform(struct?: AwsAlbTargetGroup.TargetGroupHealthPropertyOutputReference | AwsAlbTargetGroup.TargetGroupHealthProperty): any;
export declare function awsAlbTargetGroupTargetHealthStatePropertyToTerraform(struct?: AwsAlbTargetGroup.TargetHealthStateProperty | cdktn.IResolvable): any;
export declare function awsAlbTargetGroupTargetHealthStatePropertyToHclTerraform(struct?: AwsAlbTargetGroup.TargetHealthStateProperty | cdktn.IResolvable): any;
export declare namespace AwsAlbTargetGroup {
    interface HealthCheckProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group#enabled AwsAlbTargetGroup#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group#healthy_threshold AwsAlbTargetGroup#healthy_threshold}
        */
        readonly healthyThreshold?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group#interval AwsAlbTargetGroup#interval}
        */
        readonly interval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group#matcher AwsAlbTargetGroup#matcher}
        */
        readonly matcher?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group#path AwsAlbTargetGroup#path}
        */
        readonly path?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group#port AwsAlbTargetGroup#port}
        */
        readonly port?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group#protocol AwsAlbTargetGroup#protocol}
        */
        readonly protocol?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group#timeout AwsAlbTargetGroup#timeout}
        */
        readonly timeout?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group#unhealthy_threshold AwsAlbTargetGroup#unhealthy_threshold}
        */
        readonly unhealthyThreshold?: number;
    }
    class HealthCheckPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HealthCheckProperty | undefined;
        set internalValue(value: HealthCheckProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _healthyThreshold?;
        get healthyThreshold(): number;
        set healthyThreshold(value: number);
        resetHealthyThreshold(): void;
        get healthyThresholdInput(): number | undefined;
        private _interval?;
        get interval(): number;
        set interval(value: number);
        resetInterval(): void;
        get intervalInput(): number | undefined;
        private _matcher?;
        get matcher(): string;
        set matcher(value: string);
        resetMatcher(): void;
        get matcherInput(): string | undefined;
        private _path?;
        get path(): string;
        set path(value: string);
        resetPath(): void;
        get pathInput(): string | undefined;
        private _port?;
        get port(): string;
        set port(value: string);
        resetPort(): void;
        get portInput(): string | undefined;
        private _protocol?;
        get protocol(): string;
        set protocol(value: string);
        resetProtocol(): void;
        get protocolInput(): string | undefined;
        private _timeout?;
        get timeout(): number;
        set timeout(value: number);
        resetTimeout(): void;
        get timeoutInput(): number | undefined;
        private _unhealthyThreshold?;
        get unhealthyThreshold(): number;
        set unhealthyThreshold(value: number);
        resetUnhealthyThreshold(): void;
        get unhealthyThresholdInput(): number | undefined;
    }
    interface StickinessProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group#cookie_duration AwsAlbTargetGroup#cookie_duration}
        */
        readonly cookieDuration?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group#cookie_name AwsAlbTargetGroup#cookie_name}
        */
        readonly cookieName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group#enabled AwsAlbTargetGroup#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group#type AwsAlbTargetGroup#type}
        */
        readonly type: string;
    }
    class StickinessPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StickinessProperty | undefined;
        set internalValue(value: StickinessProperty | undefined);
        private _cookieDuration?;
        get cookieDuration(): number;
        set cookieDuration(value: number);
        resetCookieDuration(): void;
        get cookieDurationInput(): number | undefined;
        private _cookieName?;
        get cookieName(): string;
        set cookieName(value: string);
        resetCookieName(): void;
        get cookieNameInput(): string | undefined;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    interface TargetFailoverProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group#on_deregistration AwsAlbTargetGroup#on_deregistration}
        */
        readonly onDeregistration: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group#on_unhealthy AwsAlbTargetGroup#on_unhealthy}
        */
        readonly onUnhealthy: string;
    }
    class TargetFailoverPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetFailoverProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetFailoverProperty | cdktn.IResolvable | undefined);
        private _onDeregistration?;
        get onDeregistration(): string;
        set onDeregistration(value: string);
        get onDeregistrationInput(): string | undefined;
        private _onUnhealthy?;
        get onUnhealthy(): string;
        set onUnhealthy(value: string);
        get onUnhealthyInput(): string | undefined;
    }
    class TargetFailoverPropertyList extends cdktn.ComplexList {
        internalValue?: TargetFailoverProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetFailoverPropertyOutputReference;
    }
    interface DnsFailoverProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group#minimum_healthy_targets_count AwsAlbTargetGroup#minimum_healthy_targets_count}
        */
        readonly minimumHealthyTargetsCount?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group#minimum_healthy_targets_percentage AwsAlbTargetGroup#minimum_healthy_targets_percentage}
        */
        readonly minimumHealthyTargetsPercentage?: string;
    }
    class DnsFailoverPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DnsFailoverProperty | undefined;
        set internalValue(value: DnsFailoverProperty | undefined);
        private _minimumHealthyTargetsCount?;
        get minimumHealthyTargetsCount(): string;
        set minimumHealthyTargetsCount(value: string);
        resetMinimumHealthyTargetsCount(): void;
        get minimumHealthyTargetsCountInput(): string | undefined;
        private _minimumHealthyTargetsPercentage?;
        get minimumHealthyTargetsPercentage(): string;
        set minimumHealthyTargetsPercentage(value: string);
        resetMinimumHealthyTargetsPercentage(): void;
        get minimumHealthyTargetsPercentageInput(): string | undefined;
    }
    interface UnhealthyStateRoutingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group#minimum_healthy_targets_count AwsAlbTargetGroup#minimum_healthy_targets_count}
        */
        readonly minimumHealthyTargetsCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group#minimum_healthy_targets_percentage AwsAlbTargetGroup#minimum_healthy_targets_percentage}
        */
        readonly minimumHealthyTargetsPercentage?: string;
    }
    class UnhealthyStateRoutingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UnhealthyStateRoutingProperty | undefined;
        set internalValue(value: UnhealthyStateRoutingProperty | undefined);
        private _minimumHealthyTargetsCount?;
        get minimumHealthyTargetsCount(): number;
        set minimumHealthyTargetsCount(value: number);
        resetMinimumHealthyTargetsCount(): void;
        get minimumHealthyTargetsCountInput(): number | undefined;
        private _minimumHealthyTargetsPercentage?;
        get minimumHealthyTargetsPercentage(): string;
        set minimumHealthyTargetsPercentage(value: string);
        resetMinimumHealthyTargetsPercentage(): void;
        get minimumHealthyTargetsPercentageInput(): string | undefined;
    }
    interface TargetGroupHealthProperty {
        /**
        * dns_failover block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group#dns_failover AwsAlbTargetGroup#dns_failover}
        */
        readonly dnsFailover?: DnsFailoverProperty;
        /**
        * unhealthy_state_routing block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group#unhealthy_state_routing AwsAlbTargetGroup#unhealthy_state_routing}
        */
        readonly unhealthyStateRouting?: UnhealthyStateRoutingProperty;
    }
    class TargetGroupHealthPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TargetGroupHealthProperty | undefined;
        set internalValue(value: TargetGroupHealthProperty | undefined);
        private _dnsFailover;
        get dnsFailover(): DnsFailoverPropertyOutputReference;
        putDnsFailover(value: DnsFailoverProperty): void;
        resetDnsFailover(): void;
        get dnsFailoverInput(): DnsFailoverProperty | undefined;
        private _unhealthyStateRouting;
        get unhealthyStateRouting(): UnhealthyStateRoutingPropertyOutputReference;
        putUnhealthyStateRouting(value: UnhealthyStateRoutingProperty): void;
        resetUnhealthyStateRouting(): void;
        get unhealthyStateRoutingInput(): UnhealthyStateRoutingProperty | undefined;
    }
    interface TargetHealthStateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group#enable_unhealthy_connection_termination AwsAlbTargetGroup#enable_unhealthy_connection_termination}
        */
        readonly enableUnhealthyConnectionTermination: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_target_group#unhealthy_draining_interval AwsAlbTargetGroup#unhealthy_draining_interval}
        */
        readonly unhealthyDrainingInterval?: number;
    }
    class TargetHealthStatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetHealthStateProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetHealthStateProperty | cdktn.IResolvable | undefined);
        private _enableUnhealthyConnectionTermination?;
        get enableUnhealthyConnectionTermination(): boolean | cdktn.IResolvable;
        set enableUnhealthyConnectionTermination(value: boolean | cdktn.IResolvable);
        get enableUnhealthyConnectionTerminationInput(): boolean | cdktn.IResolvable | undefined;
        private _unhealthyDrainingInterval?;
        get unhealthyDrainingInterval(): number;
        set unhealthyDrainingInterval(value: number);
        resetUnhealthyDrainingInterval(): void;
        get unhealthyDrainingIntervalInput(): number | undefined;
    }
    class TargetHealthStatePropertyList extends cdktn.ComplexList {
        internalValue?: TargetHealthStateProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetHealthStatePropertyOutputReference;
    }
}
