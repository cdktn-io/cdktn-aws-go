import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAlbConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#client_keep_alive AwsAlb#client_keep_alive}
    */
    readonly clientKeepAlive?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#customer_owned_ipv4_pool AwsAlb#customer_owned_ipv4_pool}
    */
    readonly customerOwnedIpv4Pool?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#desync_mitigation_mode AwsAlb#desync_mitigation_mode}
    */
    readonly desyncMitigationMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#dns_record_client_routing_policy AwsAlb#dns_record_client_routing_policy}
    */
    readonly dnsRecordClientRoutingPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#drop_invalid_header_fields AwsAlb#drop_invalid_header_fields}
    */
    readonly dropInvalidHeaderFields?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#enable_cross_zone_load_balancing AwsAlb#enable_cross_zone_load_balancing}
    */
    readonly enableCrossZoneLoadBalancing?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#enable_deletion_protection AwsAlb#enable_deletion_protection}
    */
    readonly enableDeletionProtection?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#enable_http2 AwsAlb#enable_http2}
    */
    readonly enableHttp2?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#enable_prefix_for_ipv6_source_nat AwsAlb#enable_prefix_for_ipv6_source_nat}
    */
    readonly enablePrefixForIpv6SourceNat?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#enable_tls_version_and_cipher_suite_headers AwsAlb#enable_tls_version_and_cipher_suite_headers}
    */
    readonly enableTlsVersionAndCipherSuiteHeaders?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#enable_waf_fail_open AwsAlb#enable_waf_fail_open}
    */
    readonly enableWafFailOpen?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#enable_xff_client_port AwsAlb#enable_xff_client_port}
    */
    readonly enableXffClientPort?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#enable_zonal_shift AwsAlb#enable_zonal_shift}
    */
    readonly enableZonalShift?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#enforce_security_group_inbound_rules_on_private_link_traffic AwsAlb#enforce_security_group_inbound_rules_on_private_link_traffic}
    */
    readonly enforceSecurityGroupInboundRulesOnPrivateLinkTraffic?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#id AwsAlb#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#idle_timeout AwsAlb#idle_timeout}
    */
    readonly idleTimeout?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#internal AwsAlb#internal}
    */
    readonly internal?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#ip_address_type AwsAlb#ip_address_type}
    */
    readonly ipAddressType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#load_balancer_type AwsAlb#load_balancer_type}
    */
    readonly loadBalancerType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#name AwsAlb#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#name_prefix AwsAlb#name_prefix}
    */
    readonly namePrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#preserve_host_header AwsAlb#preserve_host_header}
    */
    readonly preserveHostHeader?: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#region AwsAlb#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#secondary_ips_auto_assigned_per_subnet AwsAlb#secondary_ips_auto_assigned_per_subnet}
    */
    readonly secondaryIpsAutoAssignedPerSubnet?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#security_groups AwsAlb#security_groups}
    */
    readonly securityGroups?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#subnets AwsAlb#subnets}
    */
    readonly subnets?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#tags AwsAlb#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#tags_all AwsAlb#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#xff_header_processing_mode AwsAlb#xff_header_processing_mode}
    */
    readonly xffHeaderProcessingMode?: string;
    /**
    * access_logs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#access_logs AwsAlb#access_logs}
    */
    readonly accessLogs?: AwsAlb.AccessLogsProperty;
    /**
    * connection_logs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#connection_logs AwsAlb#connection_logs}
    */
    readonly connectionLogs?: AwsAlb.ConnectionLogsProperty;
    /**
    * health_check_logs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#health_check_logs AwsAlb#health_check_logs}
    */
    readonly healthCheckLogs?: AwsAlb.HealthCheckLogsProperty;
    /**
    * ipam_pools block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#ipam_pools AwsAlb#ipam_pools}
    */
    readonly ipamPools?: AwsAlb.IpamPoolsProperty;
    /**
    * minimum_load_balancer_capacity block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#minimum_load_balancer_capacity AwsAlb#minimum_load_balancer_capacity}
    */
    readonly minimumLoadBalancerCapacity?: AwsAlb.MinimumLoadBalancerCapacityProperty;
    /**
    * subnet_mapping block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#subnet_mapping AwsAlb#subnet_mapping}
    */
    readonly subnetMapping?: AwsAlb.SubnetMappingProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#timeouts AwsAlb#timeouts}
    */
    readonly timeouts?: AwsAlb.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb aws_alb}
*/
export declare class AwsAlb extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_alb";
    /**
    * Generates CDKTN code for importing a AwsAlb resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsAlb to import
    * @param importFromId The id of the existing AwsAlb that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsAlb to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb aws_alb} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAlbConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AwsAlbConfig);
    get arn(): string;
    get arnSuffix(): string;
    private _clientKeepAlive?;
    get clientKeepAlive(): number;
    set clientKeepAlive(value: number);
    resetClientKeepAlive(): void;
    get clientKeepAliveInput(): number | undefined;
    private _customerOwnedIpv4Pool?;
    get customerOwnedIpv4Pool(): string;
    set customerOwnedIpv4Pool(value: string);
    resetCustomerOwnedIpv4Pool(): void;
    get customerOwnedIpv4PoolInput(): string | undefined;
    private _desyncMitigationMode?;
    get desyncMitigationMode(): string;
    set desyncMitigationMode(value: string);
    resetDesyncMitigationMode(): void;
    get desyncMitigationModeInput(): string | undefined;
    get dnsName(): string;
    private _dnsRecordClientRoutingPolicy?;
    get dnsRecordClientRoutingPolicy(): string;
    set dnsRecordClientRoutingPolicy(value: string);
    resetDnsRecordClientRoutingPolicy(): void;
    get dnsRecordClientRoutingPolicyInput(): string | undefined;
    private _dropInvalidHeaderFields?;
    get dropInvalidHeaderFields(): boolean | cdktn.IResolvable;
    set dropInvalidHeaderFields(value: boolean | cdktn.IResolvable);
    resetDropInvalidHeaderFields(): void;
    get dropInvalidHeaderFieldsInput(): boolean | cdktn.IResolvable | undefined;
    private _enableCrossZoneLoadBalancing?;
    get enableCrossZoneLoadBalancing(): boolean | cdktn.IResolvable;
    set enableCrossZoneLoadBalancing(value: boolean | cdktn.IResolvable);
    resetEnableCrossZoneLoadBalancing(): void;
    get enableCrossZoneLoadBalancingInput(): boolean | cdktn.IResolvable | undefined;
    private _enableDeletionProtection?;
    get enableDeletionProtection(): boolean | cdktn.IResolvable;
    set enableDeletionProtection(value: boolean | cdktn.IResolvable);
    resetEnableDeletionProtection(): void;
    get enableDeletionProtectionInput(): boolean | cdktn.IResolvable | undefined;
    private _enableHttp2?;
    get enableHttp2(): boolean | cdktn.IResolvable;
    set enableHttp2(value: boolean | cdktn.IResolvable);
    resetEnableHttp2(): void;
    get enableHttp2Input(): boolean | cdktn.IResolvable | undefined;
    private _enablePrefixForIpv6SourceNat?;
    get enablePrefixForIpv6SourceNat(): string;
    set enablePrefixForIpv6SourceNat(value: string);
    resetEnablePrefixForIpv6SourceNat(): void;
    get enablePrefixForIpv6SourceNatInput(): string | undefined;
    private _enableTlsVersionAndCipherSuiteHeaders?;
    get enableTlsVersionAndCipherSuiteHeaders(): boolean | cdktn.IResolvable;
    set enableTlsVersionAndCipherSuiteHeaders(value: boolean | cdktn.IResolvable);
    resetEnableTlsVersionAndCipherSuiteHeaders(): void;
    get enableTlsVersionAndCipherSuiteHeadersInput(): boolean | cdktn.IResolvable | undefined;
    private _enableWafFailOpen?;
    get enableWafFailOpen(): boolean | cdktn.IResolvable;
    set enableWafFailOpen(value: boolean | cdktn.IResolvable);
    resetEnableWafFailOpen(): void;
    get enableWafFailOpenInput(): boolean | cdktn.IResolvable | undefined;
    private _enableXffClientPort?;
    get enableXffClientPort(): boolean | cdktn.IResolvable;
    set enableXffClientPort(value: boolean | cdktn.IResolvable);
    resetEnableXffClientPort(): void;
    get enableXffClientPortInput(): boolean | cdktn.IResolvable | undefined;
    private _enableZonalShift?;
    get enableZonalShift(): boolean | cdktn.IResolvable;
    set enableZonalShift(value: boolean | cdktn.IResolvable);
    resetEnableZonalShift(): void;
    get enableZonalShiftInput(): boolean | cdktn.IResolvable | undefined;
    private _enforceSecurityGroupInboundRulesOnPrivateLinkTraffic?;
    get enforceSecurityGroupInboundRulesOnPrivateLinkTraffic(): string;
    set enforceSecurityGroupInboundRulesOnPrivateLinkTraffic(value: string);
    resetEnforceSecurityGroupInboundRulesOnPrivateLinkTraffic(): void;
    get enforceSecurityGroupInboundRulesOnPrivateLinkTrafficInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _idleTimeout?;
    get idleTimeout(): number;
    set idleTimeout(value: number);
    resetIdleTimeout(): void;
    get idleTimeoutInput(): number | undefined;
    private _internal?;
    get internal(): boolean | cdktn.IResolvable;
    set internal(value: boolean | cdktn.IResolvable);
    resetInternal(): void;
    get internalInput(): boolean | cdktn.IResolvable | undefined;
    private _ipAddressType?;
    get ipAddressType(): string;
    set ipAddressType(value: string);
    resetIpAddressType(): void;
    get ipAddressTypeInput(): string | undefined;
    private _loadBalancerType?;
    get loadBalancerType(): string;
    set loadBalancerType(value: string);
    resetLoadBalancerType(): void;
    get loadBalancerTypeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namePrefix?;
    get namePrefix(): string;
    set namePrefix(value: string);
    resetNamePrefix(): void;
    get namePrefixInput(): string | undefined;
    private _preserveHostHeader?;
    get preserveHostHeader(): boolean | cdktn.IResolvable;
    set preserveHostHeader(value: boolean | cdktn.IResolvable);
    resetPreserveHostHeader(): void;
    get preserveHostHeaderInput(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _secondaryIpsAutoAssignedPerSubnet?;
    get secondaryIpsAutoAssignedPerSubnet(): number;
    set secondaryIpsAutoAssignedPerSubnet(value: number);
    resetSecondaryIpsAutoAssignedPerSubnet(): void;
    get secondaryIpsAutoAssignedPerSubnetInput(): number | undefined;
    private _securityGroups?;
    get securityGroups(): string[];
    set securityGroups(value: string[]);
    resetSecurityGroups(): void;
    get securityGroupsInput(): string[] | undefined;
    private _subnets?;
    get subnets(): string[];
    set subnets(value: string[]);
    resetSubnets(): void;
    get subnetsInput(): string[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get vpcId(): string;
    private _xffHeaderProcessingMode?;
    get xffHeaderProcessingMode(): string;
    set xffHeaderProcessingMode(value: string);
    resetXffHeaderProcessingMode(): void;
    get xffHeaderProcessingModeInput(): string | undefined;
    get zoneId(): string;
    private _accessLogs;
    get accessLogs(): AwsAlb.AccessLogsPropertyOutputReference;
    putAccessLogs(value: AwsAlb.AccessLogsProperty): void;
    resetAccessLogs(): void;
    get accessLogsInput(): AwsAlb.AccessLogsProperty | undefined;
    private _connectionLogs;
    get connectionLogs(): AwsAlb.ConnectionLogsPropertyOutputReference;
    putConnectionLogs(value: AwsAlb.ConnectionLogsProperty): void;
    resetConnectionLogs(): void;
    get connectionLogsInput(): AwsAlb.ConnectionLogsProperty | undefined;
    private _healthCheckLogs;
    get healthCheckLogs(): AwsAlb.HealthCheckLogsPropertyOutputReference;
    putHealthCheckLogs(value: AwsAlb.HealthCheckLogsProperty): void;
    resetHealthCheckLogs(): void;
    get healthCheckLogsInput(): AwsAlb.HealthCheckLogsProperty | undefined;
    private _ipamPools;
    get ipamPools(): AwsAlb.IpamPoolsPropertyOutputReference;
    putIpamPools(value: AwsAlb.IpamPoolsProperty): void;
    resetIpamPools(): void;
    get ipamPoolsInput(): AwsAlb.IpamPoolsProperty | undefined;
    private _minimumLoadBalancerCapacity;
    get minimumLoadBalancerCapacity(): AwsAlb.MinimumLoadBalancerCapacityPropertyOutputReference;
    putMinimumLoadBalancerCapacity(value: AwsAlb.MinimumLoadBalancerCapacityProperty): void;
    resetMinimumLoadBalancerCapacity(): void;
    get minimumLoadBalancerCapacityInput(): AwsAlb.MinimumLoadBalancerCapacityProperty | undefined;
    private _subnetMapping;
    get subnetMapping(): AwsAlb.SubnetMappingPropertyList;
    putSubnetMapping(value: AwsAlb.SubnetMappingProperty[] | cdktn.IResolvable): void;
    resetSubnetMapping(): void;
    get subnetMappingInput(): cdktn.IResolvable | AwsAlb.SubnetMappingProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsAlb.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsAlb.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsAlb.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsAlbAccessLogsPropertyToTerraform(struct?: AwsAlb.AccessLogsPropertyOutputReference | AwsAlb.AccessLogsProperty): any;
export declare function awsAlbAccessLogsPropertyToHclTerraform(struct?: AwsAlb.AccessLogsPropertyOutputReference | AwsAlb.AccessLogsProperty): any;
export declare function awsAlbConnectionLogsPropertyToTerraform(struct?: AwsAlb.ConnectionLogsPropertyOutputReference | AwsAlb.ConnectionLogsProperty): any;
export declare function awsAlbConnectionLogsPropertyToHclTerraform(struct?: AwsAlb.ConnectionLogsPropertyOutputReference | AwsAlb.ConnectionLogsProperty): any;
export declare function awsAlbHealthCheckLogsPropertyToTerraform(struct?: AwsAlb.HealthCheckLogsPropertyOutputReference | AwsAlb.HealthCheckLogsProperty): any;
export declare function awsAlbHealthCheckLogsPropertyToHclTerraform(struct?: AwsAlb.HealthCheckLogsPropertyOutputReference | AwsAlb.HealthCheckLogsProperty): any;
export declare function awsAlbIpamPoolsPropertyToTerraform(struct?: AwsAlb.IpamPoolsPropertyOutputReference | AwsAlb.IpamPoolsProperty): any;
export declare function awsAlbIpamPoolsPropertyToHclTerraform(struct?: AwsAlb.IpamPoolsPropertyOutputReference | AwsAlb.IpamPoolsProperty): any;
export declare function awsAlbMinimumLoadBalancerCapacityPropertyToTerraform(struct?: AwsAlb.MinimumLoadBalancerCapacityPropertyOutputReference | AwsAlb.MinimumLoadBalancerCapacityProperty): any;
export declare function awsAlbMinimumLoadBalancerCapacityPropertyToHclTerraform(struct?: AwsAlb.MinimumLoadBalancerCapacityPropertyOutputReference | AwsAlb.MinimumLoadBalancerCapacityProperty): any;
export declare function awsAlbSubnetMappingPropertyToTerraform(struct?: AwsAlb.SubnetMappingProperty | cdktn.IResolvable): any;
export declare function awsAlbSubnetMappingPropertyToHclTerraform(struct?: AwsAlb.SubnetMappingProperty | cdktn.IResolvable): any;
export declare function awsAlbTimeoutsPropertyToTerraform(struct?: AwsAlb.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsAlbTimeoutsPropertyToHclTerraform(struct?: AwsAlb.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsAlb {
    interface AccessLogsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#bucket AwsAlb#bucket}
        */
        readonly bucket: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#enabled AwsAlb#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#prefix AwsAlb#prefix}
        */
        readonly prefix?: string;
    }
    class AccessLogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AccessLogsProperty | undefined;
        set internalValue(value: AccessLogsProperty | undefined);
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        get bucketInput(): string | undefined;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
    }
    interface ConnectionLogsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#bucket AwsAlb#bucket}
        */
        readonly bucket: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#enabled AwsAlb#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#prefix AwsAlb#prefix}
        */
        readonly prefix?: string;
    }
    class ConnectionLogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConnectionLogsProperty | undefined;
        set internalValue(value: ConnectionLogsProperty | undefined);
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        get bucketInput(): string | undefined;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
    }
    interface HealthCheckLogsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#bucket AwsAlb#bucket}
        */
        readonly bucket: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#enabled AwsAlb#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#prefix AwsAlb#prefix}
        */
        readonly prefix?: string;
    }
    class HealthCheckLogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HealthCheckLogsProperty | undefined;
        set internalValue(value: HealthCheckLogsProperty | undefined);
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        get bucketInput(): string | undefined;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
    }
    interface IpamPoolsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#ipv4_ipam_pool_id AwsAlb#ipv4_ipam_pool_id}
        */
        readonly ipv4IpamPoolId: string;
    }
    class IpamPoolsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IpamPoolsProperty | undefined;
        set internalValue(value: IpamPoolsProperty | undefined);
        private _ipv4IpamPoolId?;
        get ipv4IpamPoolId(): string;
        set ipv4IpamPoolId(value: string);
        get ipv4IpamPoolIdInput(): string | undefined;
    }
    interface MinimumLoadBalancerCapacityProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#capacity_units AwsAlb#capacity_units}
        */
        readonly capacityUnits: number;
    }
    class MinimumLoadBalancerCapacityPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MinimumLoadBalancerCapacityProperty | undefined;
        set internalValue(value: MinimumLoadBalancerCapacityProperty | undefined);
        private _capacityUnits?;
        get capacityUnits(): number;
        set capacityUnits(value: number);
        get capacityUnitsInput(): number | undefined;
    }
    interface SubnetMappingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#allocation_id AwsAlb#allocation_id}
        */
        readonly allocationId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#ipv6_address AwsAlb#ipv6_address}
        */
        readonly ipv6Address?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#private_ipv4_address AwsAlb#private_ipv4_address}
        */
        readonly privateIpv4Address?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#subnet_id AwsAlb#subnet_id}
        */
        readonly subnetId: string;
    }
    class SubnetMappingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SubnetMappingProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SubnetMappingProperty | cdktn.IResolvable | undefined);
        private _allocationId?;
        get allocationId(): string;
        set allocationId(value: string);
        resetAllocationId(): void;
        get allocationIdInput(): string | undefined;
        private _ipv6Address?;
        get ipv6Address(): string;
        set ipv6Address(value: string);
        resetIpv6Address(): void;
        get ipv6AddressInput(): string | undefined;
        get outpostId(): string;
        private _privateIpv4Address?;
        get privateIpv4Address(): string;
        set privateIpv4Address(value: string);
        resetPrivateIpv4Address(): void;
        get privateIpv4AddressInput(): string | undefined;
        private _subnetId?;
        get subnetId(): string;
        set subnetId(value: string);
        get subnetIdInput(): string | undefined;
    }
    class SubnetMappingPropertyList extends cdktn.ComplexList {
        internalValue?: SubnetMappingProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SubnetMappingPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#create AwsAlb#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#delete AwsAlb#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb#update AwsAlb#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
