import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsLbConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb#arn DataAwsLb#arn}
    */
    readonly arn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb#id DataAwsLb#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb#name DataAwsLb#name}
    */
    readonly name?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb#region DataAwsLb#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb#tags DataAwsLb#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb#timeouts DataAwsLb#timeouts}
    */
    readonly timeouts?: DataAwsLb.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb aws_lb}
*/
export declare class DataAwsLb extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_lb";
    /**
    * Generates CDKTN code for importing a DataAwsLb resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsLb to import
    * @param importFromId The id of the existing DataAwsLb that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsLb to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb aws_lb} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsLbConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsLbConfig);
    private _accessLogs;
    get accessLogs(): DataAwsLb.AccessLogsPropertyList;
    private _arn?;
    get arn(): string;
    set arn(value: string);
    resetArn(): void;
    get arnInput(): string | undefined;
    get arnSuffix(): string;
    get clientKeepAlive(): number;
    private _connectionLogs;
    get connectionLogs(): DataAwsLb.ConnectionLogsPropertyList;
    get customerOwnedIpv4Pool(): string;
    get desyncMitigationMode(): string;
    get dnsName(): string;
    get dnsRecordClientRoutingPolicy(): string;
    get dropInvalidHeaderFields(): cdktn.IResolvable;
    get enableCrossZoneLoadBalancing(): cdktn.IResolvable;
    get enableDeletionProtection(): cdktn.IResolvable;
    get enableHttp2(): cdktn.IResolvable;
    get enablePrefixForIpv6SourceNat(): string;
    get enableTlsVersionAndCipherSuiteHeaders(): cdktn.IResolvable;
    get enableWafFailOpen(): cdktn.IResolvable;
    get enableXffClientPort(): cdktn.IResolvable;
    get enableZonalShift(): cdktn.IResolvable;
    get enforceSecurityGroupInboundRulesOnPrivateLinkTraffic(): string;
    private _healthCheckLogs;
    get healthCheckLogs(): DataAwsLb.HealthCheckLogsPropertyList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get idleTimeout(): number;
    get internal(): cdktn.IResolvable;
    get ipAddressType(): string;
    private _ipamPools;
    get ipamPools(): DataAwsLb.IpamPoolsPropertyList;
    get loadBalancerType(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get preserveHostHeader(): cdktn.IResolvable;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get secondaryIpsAutoAssignedPerSubnet(): number;
    get securityGroups(): string[];
    private _subnetMapping;
    get subnetMapping(): DataAwsLb.SubnetMappingPropertyList;
    get subnets(): string[];
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    get vpcId(): string;
    get xffHeaderProcessingMode(): string;
    get zoneId(): string;
    private _timeouts;
    get timeouts(): DataAwsLb.TimeoutsPropertyOutputReference;
    putTimeouts(value: DataAwsLb.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAwsLb.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsLbAccessLogsPropertyToTerraform(struct?: DataAwsLb.AccessLogsProperty): any;
export declare function dataAwsLbAccessLogsPropertyToHclTerraform(struct?: DataAwsLb.AccessLogsProperty): any;
export declare function dataAwsLbConnectionLogsPropertyToTerraform(struct?: DataAwsLb.ConnectionLogsProperty): any;
export declare function dataAwsLbConnectionLogsPropertyToHclTerraform(struct?: DataAwsLb.ConnectionLogsProperty): any;
export declare function dataAwsLbHealthCheckLogsPropertyToTerraform(struct?: DataAwsLb.HealthCheckLogsProperty): any;
export declare function dataAwsLbHealthCheckLogsPropertyToHclTerraform(struct?: DataAwsLb.HealthCheckLogsProperty): any;
export declare function dataAwsLbIpamPoolsPropertyToTerraform(struct?: DataAwsLb.IpamPoolsProperty): any;
export declare function dataAwsLbIpamPoolsPropertyToHclTerraform(struct?: DataAwsLb.IpamPoolsProperty): any;
export declare function dataAwsLbSubnetMappingPropertyToTerraform(struct?: DataAwsLb.SubnetMappingProperty): any;
export declare function dataAwsLbSubnetMappingPropertyToHclTerraform(struct?: DataAwsLb.SubnetMappingProperty): any;
export declare function dataAwsLbTimeoutsPropertyToTerraform(struct?: DataAwsLb.TimeoutsProperty | cdktn.IResolvable): any;
export declare function dataAwsLbTimeoutsPropertyToHclTerraform(struct?: DataAwsLb.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace DataAwsLb {
    interface AccessLogsProperty {
    }
    class AccessLogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AccessLogsProperty | undefined;
        set internalValue(value: AccessLogsProperty | undefined);
        get bucket(): string;
        get enabled(): cdktn.IResolvable;
        get prefix(): string;
    }
    class AccessLogsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AccessLogsPropertyOutputReference;
    }
    interface ConnectionLogsProperty {
    }
    class ConnectionLogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConnectionLogsProperty | undefined;
        set internalValue(value: ConnectionLogsProperty | undefined);
        get bucket(): string;
        get enabled(): cdktn.IResolvable;
        get prefix(): string;
    }
    class ConnectionLogsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConnectionLogsPropertyOutputReference;
    }
    interface HealthCheckLogsProperty {
    }
    class HealthCheckLogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HealthCheckLogsProperty | undefined;
        set internalValue(value: HealthCheckLogsProperty | undefined);
        get bucket(): string;
        get enabled(): cdktn.IResolvable;
        get prefix(): string;
    }
    class HealthCheckLogsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HealthCheckLogsPropertyOutputReference;
    }
    interface IpamPoolsProperty {
    }
    class IpamPoolsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IpamPoolsProperty | undefined;
        set internalValue(value: IpamPoolsProperty | undefined);
        get ipv4IpamPoolId(): string;
    }
    class IpamPoolsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IpamPoolsPropertyOutputReference;
    }
    interface SubnetMappingProperty {
    }
    class SubnetMappingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SubnetMappingProperty | undefined;
        set internalValue(value: SubnetMappingProperty | undefined);
        get allocationId(): string;
        get ipv6Address(): string;
        get outpostId(): string;
        get privateIpv4Address(): string;
        get subnetId(): string;
    }
    class SubnetMappingPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SubnetMappingPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb#read DataAwsLb#read}
        */
        readonly read?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _read?;
        get read(): string;
        set read(value: string);
        resetRead(): void;
        get readInput(): string | undefined;
    }
}
