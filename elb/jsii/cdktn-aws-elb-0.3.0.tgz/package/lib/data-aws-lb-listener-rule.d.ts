import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsListenerRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#arn DataAwsListenerRule#arn}
    */
    readonly arn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#listener_arn DataAwsListenerRule#listener_arn}
    */
    readonly listenerArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#priority DataAwsListenerRule#priority}
    */
    readonly priority?: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#region DataAwsListenerRule#region}
    */
    readonly region?: string;
    /**
    * action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#action DataAwsListenerRule#action}
    */
    readonly action?: DataAwsListenerRule.ActionProperty[] | cdktn.IResolvable;
    /**
    * condition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#condition DataAwsListenerRule#condition}
    */
    readonly condition?: DataAwsListenerRule.ConditionProperty[] | cdktn.IResolvable;
    /**
    * transform block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#transform DataAwsListenerRule#transform}
    */
    readonly transform?: DataAwsListenerRule.TransformProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule aws_lb_listener_rule}
*/
export declare class DataAwsListenerRule extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_lb_listener_rule";
    /**
    * Generates CDKTN code for importing a DataAwsListenerRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsListenerRule to import
    * @param importFromId The id of the existing DataAwsListenerRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsListenerRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule aws_lb_listener_rule} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsListenerRuleConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsListenerRuleConfig);
    private _arn?;
    get arn(): string;
    set arn(value: string);
    resetArn(): void;
    get arnInput(): string | undefined;
    private _listenerArn?;
    get listenerArn(): string;
    set listenerArn(value: string);
    resetListenerArn(): void;
    get listenerArnInput(): string | undefined;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    resetPriority(): void;
    get priorityInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags;
    get tags(): cdktn.StringMap;
    private _action;
    get action(): DataAwsListenerRule.ActionPropertyList;
    putAction(value: DataAwsListenerRule.ActionProperty[] | cdktn.IResolvable): void;
    resetAction(): void;
    get actionInput(): cdktn.IResolvable | DataAwsListenerRule.ActionProperty[] | undefined;
    private _condition;
    get condition(): DataAwsListenerRule.ConditionPropertyList;
    putCondition(value: DataAwsListenerRule.ConditionProperty[] | cdktn.IResolvable): void;
    resetCondition(): void;
    get conditionInput(): cdktn.IResolvable | DataAwsListenerRule.ConditionProperty[] | undefined;
    private _transform;
    get transform(): DataAwsListenerRule.TransformPropertyList;
    putTransform(value: DataAwsListenerRule.TransformProperty[] | cdktn.IResolvable): void;
    resetTransform(): void;
    get transformInput(): cdktn.IResolvable | DataAwsListenerRule.TransformProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsListenerRuleAuthenticateCognitoPropertyToTerraform(struct?: DataAwsListenerRule.AuthenticateCognitoProperty | cdktn.IResolvable): any;
export declare function dataAwsListenerRuleAuthenticateCognitoPropertyToHclTerraform(struct?: DataAwsListenerRule.AuthenticateCognitoProperty | cdktn.IResolvable): any;
export declare function dataAwsListenerRuleAuthenticateOidcPropertyToTerraform(struct?: DataAwsListenerRule.AuthenticateOidcProperty | cdktn.IResolvable): any;
export declare function dataAwsListenerRuleAuthenticateOidcPropertyToHclTerraform(struct?: DataAwsListenerRule.AuthenticateOidcProperty | cdktn.IResolvable): any;
export declare function dataAwsListenerRuleFixedResponsePropertyToTerraform(struct?: DataAwsListenerRule.FixedResponseProperty | cdktn.IResolvable): any;
export declare function dataAwsListenerRuleFixedResponsePropertyToHclTerraform(struct?: DataAwsListenerRule.FixedResponseProperty | cdktn.IResolvable): any;
export declare function dataAwsListenerRuleStickinessPropertyToTerraform(struct?: DataAwsListenerRule.StickinessProperty | cdktn.IResolvable): any;
export declare function dataAwsListenerRuleStickinessPropertyToHclTerraform(struct?: DataAwsListenerRule.StickinessProperty | cdktn.IResolvable): any;
export declare function dataAwsListenerRuleTargetGroupPropertyToTerraform(struct?: DataAwsListenerRule.TargetGroupProperty | cdktn.IResolvable): any;
export declare function dataAwsListenerRuleTargetGroupPropertyToHclTerraform(struct?: DataAwsListenerRule.TargetGroupProperty | cdktn.IResolvable): any;
export declare function dataAwsListenerRuleForwardPropertyToTerraform(struct?: DataAwsListenerRule.ForwardProperty | cdktn.IResolvable): any;
export declare function dataAwsListenerRuleForwardPropertyToHclTerraform(struct?: DataAwsListenerRule.ForwardProperty | cdktn.IResolvable): any;
export declare function dataAwsListenerRuleAdditionalClaimPropertyToTerraform(struct?: DataAwsListenerRule.AdditionalClaimProperty | cdktn.IResolvable): any;
export declare function dataAwsListenerRuleAdditionalClaimPropertyToHclTerraform(struct?: DataAwsListenerRule.AdditionalClaimProperty | cdktn.IResolvable): any;
export declare function dataAwsListenerRuleJwtValidationPropertyToTerraform(struct?: DataAwsListenerRule.JwtValidationProperty | cdktn.IResolvable): any;
export declare function dataAwsListenerRuleJwtValidationPropertyToHclTerraform(struct?: DataAwsListenerRule.JwtValidationProperty | cdktn.IResolvable): any;
export declare function dataAwsListenerRuleRedirectPropertyToTerraform(struct?: DataAwsListenerRule.RedirectProperty | cdktn.IResolvable): any;
export declare function dataAwsListenerRuleRedirectPropertyToHclTerraform(struct?: DataAwsListenerRule.RedirectProperty | cdktn.IResolvable): any;
export declare function dataAwsListenerRuleActionPropertyToTerraform(struct?: DataAwsListenerRule.ActionProperty | cdktn.IResolvable): any;
export declare function dataAwsListenerRuleActionPropertyToHclTerraform(struct?: DataAwsListenerRule.ActionProperty | cdktn.IResolvable): any;
export declare function dataAwsListenerRuleHostHeaderPropertyToTerraform(struct?: DataAwsListenerRule.HostHeaderProperty | cdktn.IResolvable): any;
export declare function dataAwsListenerRuleHostHeaderPropertyToHclTerraform(struct?: DataAwsListenerRule.HostHeaderProperty | cdktn.IResolvable): any;
export declare function dataAwsListenerRuleHttpHeaderPropertyToTerraform(struct?: DataAwsListenerRule.HttpHeaderProperty | cdktn.IResolvable): any;
export declare function dataAwsListenerRuleHttpHeaderPropertyToHclTerraform(struct?: DataAwsListenerRule.HttpHeaderProperty | cdktn.IResolvable): any;
export declare function dataAwsListenerRuleHttpRequestMethodPropertyToTerraform(struct?: DataAwsListenerRule.HttpRequestMethodProperty | cdktn.IResolvable): any;
export declare function dataAwsListenerRuleHttpRequestMethodPropertyToHclTerraform(struct?: DataAwsListenerRule.HttpRequestMethodProperty | cdktn.IResolvable): any;
export declare function dataAwsListenerRulePathPatternPropertyToTerraform(struct?: DataAwsListenerRule.PathPatternProperty | cdktn.IResolvable): any;
export declare function dataAwsListenerRulePathPatternPropertyToHclTerraform(struct?: DataAwsListenerRule.PathPatternProperty | cdktn.IResolvable): any;
export declare function dataAwsListenerRuleValuesPropertyToTerraform(struct?: DataAwsListenerRule.ValuesProperty | cdktn.IResolvable): any;
export declare function dataAwsListenerRuleValuesPropertyToHclTerraform(struct?: DataAwsListenerRule.ValuesProperty | cdktn.IResolvable): any;
export declare function dataAwsListenerRuleQueryStringPropertyToTerraform(struct?: DataAwsListenerRule.QueryStringProperty | cdktn.IResolvable): any;
export declare function dataAwsListenerRuleQueryStringPropertyToHclTerraform(struct?: DataAwsListenerRule.QueryStringProperty | cdktn.IResolvable): any;
export declare function dataAwsListenerRuleSourceIpPropertyToTerraform(struct?: DataAwsListenerRule.SourceIpProperty | cdktn.IResolvable): any;
export declare function dataAwsListenerRuleSourceIpPropertyToHclTerraform(struct?: DataAwsListenerRule.SourceIpProperty | cdktn.IResolvable): any;
export declare function dataAwsListenerRuleConditionPropertyToTerraform(struct?: DataAwsListenerRule.ConditionProperty | cdktn.IResolvable): any;
export declare function dataAwsListenerRuleConditionPropertyToHclTerraform(struct?: DataAwsListenerRule.ConditionProperty | cdktn.IResolvable): any;
export declare function dataAwsListenerRuleTransformHostHeaderRewriteConfigRewritePropertyToTerraform(struct?: DataAwsListenerRule.TransformHostHeaderRewriteConfigRewriteProperty | cdktn.IResolvable): any;
export declare function dataAwsListenerRuleTransformHostHeaderRewriteConfigRewritePropertyToHclTerraform(struct?: DataAwsListenerRule.TransformHostHeaderRewriteConfigRewriteProperty | cdktn.IResolvable): any;
export declare function dataAwsListenerRuleHostHeaderRewriteConfigPropertyToTerraform(struct?: DataAwsListenerRule.HostHeaderRewriteConfigProperty | cdktn.IResolvable): any;
export declare function dataAwsListenerRuleHostHeaderRewriteConfigPropertyToHclTerraform(struct?: DataAwsListenerRule.HostHeaderRewriteConfigProperty | cdktn.IResolvable): any;
export declare function dataAwsListenerRuleTransformUrlRewriteConfigRewritePropertyToTerraform(struct?: DataAwsListenerRule.TransformUrlRewriteConfigRewriteProperty | cdktn.IResolvable): any;
export declare function dataAwsListenerRuleTransformUrlRewriteConfigRewritePropertyToHclTerraform(struct?: DataAwsListenerRule.TransformUrlRewriteConfigRewriteProperty | cdktn.IResolvable): any;
export declare function dataAwsListenerRuleUrlRewriteConfigPropertyToTerraform(struct?: DataAwsListenerRule.UrlRewriteConfigProperty | cdktn.IResolvable): any;
export declare function dataAwsListenerRuleUrlRewriteConfigPropertyToHclTerraform(struct?: DataAwsListenerRule.UrlRewriteConfigProperty | cdktn.IResolvable): any;
export declare function dataAwsListenerRuleTransformPropertyToTerraform(struct?: DataAwsListenerRule.TransformProperty | cdktn.IResolvable): any;
export declare function dataAwsListenerRuleTransformPropertyToHclTerraform(struct?: DataAwsListenerRule.TransformProperty | cdktn.IResolvable): any;
export declare namespace DataAwsListenerRule {
    interface AuthenticateCognitoProperty {
    }
    class AuthenticateCognitoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthenticateCognitoProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AuthenticateCognitoProperty | cdktn.IResolvable | undefined);
        private _authenticationRequestExtraParams;
        get authenticationRequestExtraParams(): cdktn.StringMap;
        get onUnauthenticatedRequest(): string;
        get scope(): string;
        get sessionCookieName(): string;
        get sessionTimeout(): number;
        get userPoolArn(): string;
        get userPoolClientId(): string;
        get userPoolDomain(): string;
    }
    class AuthenticateCognitoPropertyList extends cdktn.ComplexList {
        internalValue?: AuthenticateCognitoProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthenticateCognitoPropertyOutputReference;
    }
    interface AuthenticateOidcProperty {
    }
    class AuthenticateOidcPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthenticateOidcProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AuthenticateOidcProperty | cdktn.IResolvable | undefined);
        private _authenticationRequestExtraParams;
        get authenticationRequestExtraParams(): cdktn.StringMap;
        get authorizationEndpoint(): string;
        get clientId(): string;
        get issuer(): string;
        get onUnauthenticatedRequest(): string;
        get scope(): string;
        get sessionCookieName(): string;
        get sessionTimeout(): number;
        get tokenEndpoint(): string;
        get userInfoEndpoint(): string;
    }
    class AuthenticateOidcPropertyList extends cdktn.ComplexList {
        internalValue?: AuthenticateOidcProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthenticateOidcPropertyOutputReference;
    }
    interface FixedResponseProperty {
    }
    class FixedResponsePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FixedResponseProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FixedResponseProperty | cdktn.IResolvable | undefined);
        get contentType(): string;
        get messageBody(): string;
        get statusCode(): string;
    }
    class FixedResponsePropertyList extends cdktn.ComplexList {
        internalValue?: FixedResponseProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FixedResponsePropertyOutputReference;
    }
    interface StickinessProperty {
    }
    class StickinessPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StickinessProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StickinessProperty | cdktn.IResolvable | undefined);
        get duration(): number;
        get enabled(): cdktn.IResolvable;
    }
    class StickinessPropertyList extends cdktn.ComplexList {
        internalValue?: StickinessProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StickinessPropertyOutputReference;
    }
    interface TargetGroupProperty {
    }
    class TargetGroupPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetGroupProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetGroupProperty | cdktn.IResolvable | undefined);
        get arn(): string;
        get weight(): number;
    }
    class TargetGroupPropertyList extends cdktn.ComplexList {
        internalValue?: TargetGroupProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetGroupPropertyOutputReference;
    }
    interface ForwardProperty {
        /**
        * stickiness block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#stickiness DataAwsListenerRule#stickiness}
        */
        readonly stickiness?: StickinessProperty[] | cdktn.IResolvable;
        /**
        * target_group block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#target_group DataAwsListenerRule#target_group}
        */
        readonly targetGroup?: TargetGroupProperty[] | cdktn.IResolvable;
    }
    class ForwardPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ForwardProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ForwardProperty | cdktn.IResolvable | undefined);
        private _stickiness;
        get stickiness(): StickinessPropertyList;
        putStickiness(value: StickinessProperty[] | cdktn.IResolvable): void;
        resetStickiness(): void;
        get stickinessInput(): cdktn.IResolvable | StickinessProperty[] | undefined;
        private _targetGroup;
        get targetGroup(): TargetGroupPropertyList;
        putTargetGroup(value: TargetGroupProperty[] | cdktn.IResolvable): void;
        resetTargetGroup(): void;
        get targetGroupInput(): cdktn.IResolvable | TargetGroupProperty[] | undefined;
    }
    class ForwardPropertyList extends cdktn.ComplexList {
        internalValue?: ForwardProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ForwardPropertyOutputReference;
    }
    interface AdditionalClaimProperty {
    }
    class AdditionalClaimPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AdditionalClaimProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AdditionalClaimProperty | cdktn.IResolvable | undefined);
        get format(): string;
        get name(): string;
        get values(): string[];
    }
    class AdditionalClaimPropertyList extends cdktn.ComplexList {
        internalValue?: AdditionalClaimProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AdditionalClaimPropertyOutputReference;
    }
    interface JwtValidationProperty {
        /**
        * additional_claim block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#additional_claim DataAwsListenerRule#additional_claim}
        */
        readonly additionalClaim?: AdditionalClaimProperty[] | cdktn.IResolvable;
    }
    class JwtValidationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): JwtValidationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: JwtValidationProperty | cdktn.IResolvable | undefined);
        get issuer(): string;
        get jwksEndpoint(): string;
        private _additionalClaim;
        get additionalClaim(): AdditionalClaimPropertyList;
        putAdditionalClaim(value: AdditionalClaimProperty[] | cdktn.IResolvable): void;
        resetAdditionalClaim(): void;
        get additionalClaimInput(): cdktn.IResolvable | AdditionalClaimProperty[] | undefined;
    }
    class JwtValidationPropertyList extends cdktn.ComplexList {
        internalValue?: JwtValidationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): JwtValidationPropertyOutputReference;
    }
    interface RedirectProperty {
    }
    class RedirectPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RedirectProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RedirectProperty | cdktn.IResolvable | undefined);
        get host(): string;
        get path(): string;
        get port(): string;
        get protocol(): string;
        get query(): string;
        get statusCode(): string;
    }
    class RedirectPropertyList extends cdktn.ComplexList {
        internalValue?: RedirectProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RedirectPropertyOutputReference;
    }
    interface ActionProperty {
        /**
        * authenticate_cognito block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#authenticate_cognito DataAwsListenerRule#authenticate_cognito}
        */
        readonly authenticateCognito?: AuthenticateCognitoProperty[] | cdktn.IResolvable;
        /**
        * authenticate_oidc block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#authenticate_oidc DataAwsListenerRule#authenticate_oidc}
        */
        readonly authenticateOidc?: AuthenticateOidcProperty[] | cdktn.IResolvable;
        /**
        * fixed_response block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#fixed_response DataAwsListenerRule#fixed_response}
        */
        readonly fixedResponse?: FixedResponseProperty[] | cdktn.IResolvable;
        /**
        * forward block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#forward DataAwsListenerRule#forward}
        */
        readonly forward?: ForwardProperty[] | cdktn.IResolvable;
        /**
        * jwt_validation block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#jwt_validation DataAwsListenerRule#jwt_validation}
        */
        readonly jwtValidation?: JwtValidationProperty[] | cdktn.IResolvable;
        /**
        * redirect block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#redirect DataAwsListenerRule#redirect}
        */
        readonly redirect?: RedirectProperty[] | cdktn.IResolvable;
    }
    class ActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ActionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ActionProperty | cdktn.IResolvable | undefined);
        get order(): number;
        get type(): string;
        private _authenticateCognito;
        get authenticateCognito(): AuthenticateCognitoPropertyList;
        putAuthenticateCognito(value: AuthenticateCognitoProperty[] | cdktn.IResolvable): void;
        resetAuthenticateCognito(): void;
        get authenticateCognitoInput(): cdktn.IResolvable | AuthenticateCognitoProperty[] | undefined;
        private _authenticateOidc;
        get authenticateOidc(): AuthenticateOidcPropertyList;
        putAuthenticateOidc(value: AuthenticateOidcProperty[] | cdktn.IResolvable): void;
        resetAuthenticateOidc(): void;
        get authenticateOidcInput(): cdktn.IResolvable | AuthenticateOidcProperty[] | undefined;
        private _fixedResponse;
        get fixedResponse(): FixedResponsePropertyList;
        putFixedResponse(value: FixedResponseProperty[] | cdktn.IResolvable): void;
        resetFixedResponse(): void;
        get fixedResponseInput(): cdktn.IResolvable | FixedResponseProperty[] | undefined;
        private _forward;
        get forward(): ForwardPropertyList;
        putForward(value: ForwardProperty[] | cdktn.IResolvable): void;
        resetForward(): void;
        get forwardInput(): cdktn.IResolvable | ForwardProperty[] | undefined;
        private _jwtValidation;
        get jwtValidation(): JwtValidationPropertyList;
        putJwtValidation(value: JwtValidationProperty[] | cdktn.IResolvable): void;
        resetJwtValidation(): void;
        get jwtValidationInput(): cdktn.IResolvable | JwtValidationProperty[] | undefined;
        private _redirect;
        get redirect(): RedirectPropertyList;
        putRedirect(value: RedirectProperty[] | cdktn.IResolvable): void;
        resetRedirect(): void;
        get redirectInput(): cdktn.IResolvable | RedirectProperty[] | undefined;
    }
    class ActionPropertyList extends cdktn.ComplexList {
        internalValue?: ActionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ActionPropertyOutputReference;
    }
    interface HostHeaderProperty {
    }
    class HostHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HostHeaderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: HostHeaderProperty | cdktn.IResolvable | undefined);
        get regexValues(): string[];
        get values(): string[];
    }
    class HostHeaderPropertyList extends cdktn.ComplexList {
        internalValue?: HostHeaderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HostHeaderPropertyOutputReference;
    }
    interface HttpHeaderProperty {
    }
    class HttpHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HttpHeaderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: HttpHeaderProperty | cdktn.IResolvable | undefined);
        get httpHeaderName(): string;
        get regexValues(): string[];
        get values(): string[];
    }
    class HttpHeaderPropertyList extends cdktn.ComplexList {
        internalValue?: HttpHeaderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HttpHeaderPropertyOutputReference;
    }
    interface HttpRequestMethodProperty {
    }
    class HttpRequestMethodPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HttpRequestMethodProperty | cdktn.IResolvable | undefined;
        set internalValue(value: HttpRequestMethodProperty | cdktn.IResolvable | undefined);
        get values(): string[];
    }
    class HttpRequestMethodPropertyList extends cdktn.ComplexList {
        internalValue?: HttpRequestMethodProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HttpRequestMethodPropertyOutputReference;
    }
    interface PathPatternProperty {
    }
    class PathPatternPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PathPatternProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PathPatternProperty | cdktn.IResolvable | undefined);
        get regexValues(): string[];
        get values(): string[];
    }
    class PathPatternPropertyList extends cdktn.ComplexList {
        internalValue?: PathPatternProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PathPatternPropertyOutputReference;
    }
    interface ValuesProperty {
    }
    class ValuesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ValuesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ValuesProperty | cdktn.IResolvable | undefined);
        get key(): string;
        get value(): string;
    }
    class ValuesPropertyList extends cdktn.ComplexList {
        internalValue?: ValuesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ValuesPropertyOutputReference;
    }
    interface QueryStringProperty {
        /**
        * values block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#values DataAwsListenerRule#values}
        */
        readonly values?: ValuesProperty[] | cdktn.IResolvable;
    }
    class QueryStringPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): QueryStringProperty | cdktn.IResolvable | undefined;
        set internalValue(value: QueryStringProperty | cdktn.IResolvable | undefined);
        private _values;
        get values(): ValuesPropertyList;
        putValues(value: ValuesProperty[] | cdktn.IResolvable): void;
        resetValues(): void;
        get valuesInput(): cdktn.IResolvable | ValuesProperty[] | undefined;
    }
    class QueryStringPropertyList extends cdktn.ComplexList {
        internalValue?: QueryStringProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): QueryStringPropertyOutputReference;
    }
    interface SourceIpProperty {
    }
    class SourceIpPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SourceIpProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SourceIpProperty | cdktn.IResolvable | undefined);
        get ipAddressType(): string;
        get values(): string[];
    }
    class SourceIpPropertyList extends cdktn.ComplexList {
        internalValue?: SourceIpProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SourceIpPropertyOutputReference;
    }
    interface ConditionProperty {
        /**
        * host_header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#host_header DataAwsListenerRule#host_header}
        */
        readonly hostHeader?: HostHeaderProperty[] | cdktn.IResolvable;
        /**
        * http_header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#http_header DataAwsListenerRule#http_header}
        */
        readonly httpHeader?: HttpHeaderProperty[] | cdktn.IResolvable;
        /**
        * http_request_method block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#http_request_method DataAwsListenerRule#http_request_method}
        */
        readonly httpRequestMethod?: HttpRequestMethodProperty[] | cdktn.IResolvable;
        /**
        * path_pattern block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#path_pattern DataAwsListenerRule#path_pattern}
        */
        readonly pathPattern?: PathPatternProperty[] | cdktn.IResolvable;
        /**
        * query_string block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#query_string DataAwsListenerRule#query_string}
        */
        readonly queryString?: QueryStringProperty[] | cdktn.IResolvable;
        /**
        * source_ip block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#source_ip DataAwsListenerRule#source_ip}
        */
        readonly sourceIp?: SourceIpProperty[] | cdktn.IResolvable;
    }
    class ConditionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConditionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConditionProperty | cdktn.IResolvable | undefined);
        private _hostHeader;
        get hostHeader(): HostHeaderPropertyList;
        putHostHeader(value: HostHeaderProperty[] | cdktn.IResolvable): void;
        resetHostHeader(): void;
        get hostHeaderInput(): cdktn.IResolvable | HostHeaderProperty[] | undefined;
        private _httpHeader;
        get httpHeader(): HttpHeaderPropertyList;
        putHttpHeader(value: HttpHeaderProperty[] | cdktn.IResolvable): void;
        resetHttpHeader(): void;
        get httpHeaderInput(): cdktn.IResolvable | HttpHeaderProperty[] | undefined;
        private _httpRequestMethod;
        get httpRequestMethod(): HttpRequestMethodPropertyList;
        putHttpRequestMethod(value: HttpRequestMethodProperty[] | cdktn.IResolvable): void;
        resetHttpRequestMethod(): void;
        get httpRequestMethodInput(): cdktn.IResolvable | HttpRequestMethodProperty[] | undefined;
        private _pathPattern;
        get pathPattern(): PathPatternPropertyList;
        putPathPattern(value: PathPatternProperty[] | cdktn.IResolvable): void;
        resetPathPattern(): void;
        get pathPatternInput(): cdktn.IResolvable | PathPatternProperty[] | undefined;
        private _queryString;
        get queryString(): QueryStringPropertyList;
        putQueryString(value: QueryStringProperty[] | cdktn.IResolvable): void;
        resetQueryString(): void;
        get queryStringInput(): cdktn.IResolvable | QueryStringProperty[] | undefined;
        private _sourceIp;
        get sourceIp(): SourceIpPropertyList;
        putSourceIp(value: SourceIpProperty[] | cdktn.IResolvable): void;
        resetSourceIp(): void;
        get sourceIpInput(): cdktn.IResolvable | SourceIpProperty[] | undefined;
    }
    class ConditionPropertyList extends cdktn.ComplexList {
        internalValue?: ConditionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConditionPropertyOutputReference;
    }
    interface TransformHostHeaderRewriteConfigRewriteProperty {
    }
    class TransformHostHeaderRewriteConfigRewritePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TransformHostHeaderRewriteConfigRewriteProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TransformHostHeaderRewriteConfigRewriteProperty | cdktn.IResolvable | undefined);
        get regex(): string;
        get replace(): string;
    }
    class TransformHostHeaderRewriteConfigRewritePropertyList extends cdktn.ComplexList {
        internalValue?: TransformHostHeaderRewriteConfigRewriteProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TransformHostHeaderRewriteConfigRewritePropertyOutputReference;
    }
    interface HostHeaderRewriteConfigProperty {
        /**
        * rewrite block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#rewrite DataAwsListenerRule#rewrite}
        */
        readonly rewrite?: TransformHostHeaderRewriteConfigRewriteProperty[] | cdktn.IResolvable;
    }
    class HostHeaderRewriteConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HostHeaderRewriteConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: HostHeaderRewriteConfigProperty | cdktn.IResolvable | undefined);
        private _rewrite;
        get rewrite(): TransformHostHeaderRewriteConfigRewritePropertyList;
        putRewrite(value: TransformHostHeaderRewriteConfigRewriteProperty[] | cdktn.IResolvable): void;
        resetRewrite(): void;
        get rewriteInput(): cdktn.IResolvable | TransformHostHeaderRewriteConfigRewriteProperty[] | undefined;
    }
    class HostHeaderRewriteConfigPropertyList extends cdktn.ComplexList {
        internalValue?: HostHeaderRewriteConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HostHeaderRewriteConfigPropertyOutputReference;
    }
    interface TransformUrlRewriteConfigRewriteProperty {
    }
    class TransformUrlRewriteConfigRewritePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TransformUrlRewriteConfigRewriteProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TransformUrlRewriteConfigRewriteProperty | cdktn.IResolvable | undefined);
        get regex(): string;
        get replace(): string;
    }
    class TransformUrlRewriteConfigRewritePropertyList extends cdktn.ComplexList {
        internalValue?: TransformUrlRewriteConfigRewriteProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TransformUrlRewriteConfigRewritePropertyOutputReference;
    }
    interface UrlRewriteConfigProperty {
        /**
        * rewrite block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#rewrite DataAwsListenerRule#rewrite}
        */
        readonly rewrite?: TransformUrlRewriteConfigRewriteProperty[] | cdktn.IResolvable;
    }
    class UrlRewriteConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): UrlRewriteConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: UrlRewriteConfigProperty | cdktn.IResolvable | undefined);
        private _rewrite;
        get rewrite(): TransformUrlRewriteConfigRewritePropertyList;
        putRewrite(value: TransformUrlRewriteConfigRewriteProperty[] | cdktn.IResolvable): void;
        resetRewrite(): void;
        get rewriteInput(): cdktn.IResolvable | TransformUrlRewriteConfigRewriteProperty[] | undefined;
    }
    class UrlRewriteConfigPropertyList extends cdktn.ComplexList {
        internalValue?: UrlRewriteConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): UrlRewriteConfigPropertyOutputReference;
    }
    interface TransformProperty {
        /**
        * host_header_rewrite_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#host_header_rewrite_config DataAwsListenerRule#host_header_rewrite_config}
        */
        readonly hostHeaderRewriteConfig?: HostHeaderRewriteConfigProperty[] | cdktn.IResolvable;
        /**
        * url_rewrite_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#url_rewrite_config DataAwsListenerRule#url_rewrite_config}
        */
        readonly urlRewriteConfig?: UrlRewriteConfigProperty[] | cdktn.IResolvable;
    }
    class TransformPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TransformProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TransformProperty | cdktn.IResolvable | undefined);
        get type(): string;
        private _hostHeaderRewriteConfig;
        get hostHeaderRewriteConfig(): HostHeaderRewriteConfigPropertyList;
        putHostHeaderRewriteConfig(value: HostHeaderRewriteConfigProperty[] | cdktn.IResolvable): void;
        resetHostHeaderRewriteConfig(): void;
        get hostHeaderRewriteConfigInput(): cdktn.IResolvable | HostHeaderRewriteConfigProperty[] | undefined;
        private _urlRewriteConfig;
        get urlRewriteConfig(): UrlRewriteConfigPropertyList;
        putUrlRewriteConfig(value: UrlRewriteConfigProperty[] | cdktn.IResolvable): void;
        resetUrlRewriteConfig(): void;
        get urlRewriteConfigInput(): cdktn.IResolvable | UrlRewriteConfigProperty[] | undefined;
    }
    class TransformPropertyList extends cdktn.ComplexList {
        internalValue?: TransformProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TransformPropertyOutputReference;
    }
}
