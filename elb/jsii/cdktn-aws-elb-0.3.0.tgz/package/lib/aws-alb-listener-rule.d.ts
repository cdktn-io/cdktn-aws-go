import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAlbListenerRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#id AwsAlbListenerRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#listener_arn AwsAlbListenerRule#listener_arn}
    */
    readonly listenerArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#priority AwsAlbListenerRule#priority}
    */
    readonly priority?: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#region AwsAlbListenerRule#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#tags AwsAlbListenerRule#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#tags_all AwsAlbListenerRule#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#action AwsAlbListenerRule#action}
    */
    readonly action: AwsAlbListenerRule.ActionProperty[] | cdktn.IResolvable;
    /**
    * condition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#condition AwsAlbListenerRule#condition}
    */
    readonly condition: AwsAlbListenerRule.ConditionProperty[] | cdktn.IResolvable;
    /**
    * transform block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#transform AwsAlbListenerRule#transform}
    */
    readonly transform?: AwsAlbListenerRule.TransformProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule aws_alb_listener_rule}
*/
export declare class AwsAlbListenerRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_alb_listener_rule";
    /**
    * Generates CDKTN code for importing a AwsAlbListenerRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsAlbListenerRule to import
    * @param importFromId The id of the existing AwsAlbListenerRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsAlbListenerRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule aws_alb_listener_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAlbListenerRuleConfig
    */
    constructor(scope: Construct, id: string, config: AwsAlbListenerRuleConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _listenerArn?;
    get listenerArn(): string;
    set listenerArn(value: string);
    get listenerArnInput(): string | undefined;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    resetPriority(): void;
    get priorityInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _action;
    get action(): AwsAlbListenerRule.ActionPropertyList;
    putAction(value: AwsAlbListenerRule.ActionProperty[] | cdktn.IResolvable): void;
    get actionInput(): cdktn.IResolvable | AwsAlbListenerRule.ActionProperty[] | undefined;
    private _condition;
    get condition(): AwsAlbListenerRule.ConditionPropertyList;
    putCondition(value: AwsAlbListenerRule.ConditionProperty[] | cdktn.IResolvable): void;
    get conditionInput(): cdktn.IResolvable | AwsAlbListenerRule.ConditionProperty[] | undefined;
    private _transform;
    get transform(): AwsAlbListenerRule.TransformPropertyList;
    putTransform(value: AwsAlbListenerRule.TransformProperty[] | cdktn.IResolvable): void;
    resetTransform(): void;
    get transformInput(): cdktn.IResolvable | AwsAlbListenerRule.TransformProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsAlbListenerRuleAuthenticateCognitoPropertyToTerraform(struct?: AwsAlbListenerRule.AuthenticateCognitoPropertyOutputReference | AwsAlbListenerRule.AuthenticateCognitoProperty): any;
export declare function awsAlbListenerRuleAuthenticateCognitoPropertyToHclTerraform(struct?: AwsAlbListenerRule.AuthenticateCognitoPropertyOutputReference | AwsAlbListenerRule.AuthenticateCognitoProperty): any;
export declare function awsAlbListenerRuleAuthenticateOidcPropertyToTerraform(struct?: AwsAlbListenerRule.AuthenticateOidcPropertyOutputReference | AwsAlbListenerRule.AuthenticateOidcProperty): any;
export declare function awsAlbListenerRuleAuthenticateOidcPropertyToHclTerraform(struct?: AwsAlbListenerRule.AuthenticateOidcPropertyOutputReference | AwsAlbListenerRule.AuthenticateOidcProperty): any;
export declare function awsAlbListenerRuleFixedResponsePropertyToTerraform(struct?: AwsAlbListenerRule.FixedResponsePropertyOutputReference | AwsAlbListenerRule.FixedResponseProperty): any;
export declare function awsAlbListenerRuleFixedResponsePropertyToHclTerraform(struct?: AwsAlbListenerRule.FixedResponsePropertyOutputReference | AwsAlbListenerRule.FixedResponseProperty): any;
export declare function awsAlbListenerRuleStickinessPropertyToTerraform(struct?: AwsAlbListenerRule.StickinessPropertyOutputReference | AwsAlbListenerRule.StickinessProperty): any;
export declare function awsAlbListenerRuleStickinessPropertyToHclTerraform(struct?: AwsAlbListenerRule.StickinessPropertyOutputReference | AwsAlbListenerRule.StickinessProperty): any;
export declare function awsAlbListenerRuleTargetGroupPropertyToTerraform(struct?: AwsAlbListenerRule.TargetGroupProperty | cdktn.IResolvable): any;
export declare function awsAlbListenerRuleTargetGroupPropertyToHclTerraform(struct?: AwsAlbListenerRule.TargetGroupProperty | cdktn.IResolvable): any;
export declare function awsAlbListenerRuleForwardPropertyToTerraform(struct?: AwsAlbListenerRule.ForwardPropertyOutputReference | AwsAlbListenerRule.ForwardProperty): any;
export declare function awsAlbListenerRuleForwardPropertyToHclTerraform(struct?: AwsAlbListenerRule.ForwardPropertyOutputReference | AwsAlbListenerRule.ForwardProperty): any;
export declare function awsAlbListenerRuleAdditionalClaimPropertyToTerraform(struct?: AwsAlbListenerRule.AdditionalClaimProperty | cdktn.IResolvable): any;
export declare function awsAlbListenerRuleAdditionalClaimPropertyToHclTerraform(struct?: AwsAlbListenerRule.AdditionalClaimProperty | cdktn.IResolvable): any;
export declare function awsAlbListenerRuleJwtValidationPropertyToTerraform(struct?: AwsAlbListenerRule.JwtValidationPropertyOutputReference | AwsAlbListenerRule.JwtValidationProperty): any;
export declare function awsAlbListenerRuleJwtValidationPropertyToHclTerraform(struct?: AwsAlbListenerRule.JwtValidationPropertyOutputReference | AwsAlbListenerRule.JwtValidationProperty): any;
export declare function awsAlbListenerRuleRedirectPropertyToTerraform(struct?: AwsAlbListenerRule.RedirectPropertyOutputReference | AwsAlbListenerRule.RedirectProperty): any;
export declare function awsAlbListenerRuleRedirectPropertyToHclTerraform(struct?: AwsAlbListenerRule.RedirectPropertyOutputReference | AwsAlbListenerRule.RedirectProperty): any;
export declare function awsAlbListenerRuleActionPropertyToTerraform(struct?: AwsAlbListenerRule.ActionProperty | cdktn.IResolvable): any;
export declare function awsAlbListenerRuleActionPropertyToHclTerraform(struct?: AwsAlbListenerRule.ActionProperty | cdktn.IResolvable): any;
export declare function awsAlbListenerRuleHostHeaderPropertyToTerraform(struct?: AwsAlbListenerRule.HostHeaderPropertyOutputReference | AwsAlbListenerRule.HostHeaderProperty): any;
export declare function awsAlbListenerRuleHostHeaderPropertyToHclTerraform(struct?: AwsAlbListenerRule.HostHeaderPropertyOutputReference | AwsAlbListenerRule.HostHeaderProperty): any;
export declare function awsAlbListenerRuleHttpHeaderPropertyToTerraform(struct?: AwsAlbListenerRule.HttpHeaderPropertyOutputReference | AwsAlbListenerRule.HttpHeaderProperty): any;
export declare function awsAlbListenerRuleHttpHeaderPropertyToHclTerraform(struct?: AwsAlbListenerRule.HttpHeaderPropertyOutputReference | AwsAlbListenerRule.HttpHeaderProperty): any;
export declare function awsAlbListenerRuleHttpRequestMethodPropertyToTerraform(struct?: AwsAlbListenerRule.HttpRequestMethodPropertyOutputReference | AwsAlbListenerRule.HttpRequestMethodProperty): any;
export declare function awsAlbListenerRuleHttpRequestMethodPropertyToHclTerraform(struct?: AwsAlbListenerRule.HttpRequestMethodPropertyOutputReference | AwsAlbListenerRule.HttpRequestMethodProperty): any;
export declare function awsAlbListenerRulePathPatternPropertyToTerraform(struct?: AwsAlbListenerRule.PathPatternPropertyOutputReference | AwsAlbListenerRule.PathPatternProperty): any;
export declare function awsAlbListenerRulePathPatternPropertyToHclTerraform(struct?: AwsAlbListenerRule.PathPatternPropertyOutputReference | AwsAlbListenerRule.PathPatternProperty): any;
export declare function awsAlbListenerRuleQueryStringPropertyToTerraform(struct?: AwsAlbListenerRule.QueryStringProperty | cdktn.IResolvable): any;
export declare function awsAlbListenerRuleQueryStringPropertyToHclTerraform(struct?: AwsAlbListenerRule.QueryStringProperty | cdktn.IResolvable): any;
export declare function awsAlbListenerRuleSourceIpPropertyToTerraform(struct?: AwsAlbListenerRule.SourceIpPropertyOutputReference | AwsAlbListenerRule.SourceIpProperty): any;
export declare function awsAlbListenerRuleSourceIpPropertyToHclTerraform(struct?: AwsAlbListenerRule.SourceIpPropertyOutputReference | AwsAlbListenerRule.SourceIpProperty): any;
export declare function awsAlbListenerRuleConditionPropertyToTerraform(struct?: AwsAlbListenerRule.ConditionProperty | cdktn.IResolvable): any;
export declare function awsAlbListenerRuleConditionPropertyToHclTerraform(struct?: AwsAlbListenerRule.ConditionProperty | cdktn.IResolvable): any;
export declare function awsAlbListenerRuleTransformHostHeaderRewriteConfigRewritePropertyToTerraform(struct?: AwsAlbListenerRule.TransformHostHeaderRewriteConfigRewritePropertyOutputReference | AwsAlbListenerRule.TransformHostHeaderRewriteConfigRewriteProperty): any;
export declare function awsAlbListenerRuleTransformHostHeaderRewriteConfigRewritePropertyToHclTerraform(struct?: AwsAlbListenerRule.TransformHostHeaderRewriteConfigRewritePropertyOutputReference | AwsAlbListenerRule.TransformHostHeaderRewriteConfigRewriteProperty): any;
export declare function awsAlbListenerRuleHostHeaderRewriteConfigPropertyToTerraform(struct?: AwsAlbListenerRule.HostHeaderRewriteConfigPropertyOutputReference | AwsAlbListenerRule.HostHeaderRewriteConfigProperty): any;
export declare function awsAlbListenerRuleHostHeaderRewriteConfigPropertyToHclTerraform(struct?: AwsAlbListenerRule.HostHeaderRewriteConfigPropertyOutputReference | AwsAlbListenerRule.HostHeaderRewriteConfigProperty): any;
export declare function awsAlbListenerRuleTransformUrlRewriteConfigRewritePropertyToTerraform(struct?: AwsAlbListenerRule.TransformUrlRewriteConfigRewritePropertyOutputReference | AwsAlbListenerRule.TransformUrlRewriteConfigRewriteProperty): any;
export declare function awsAlbListenerRuleTransformUrlRewriteConfigRewritePropertyToHclTerraform(struct?: AwsAlbListenerRule.TransformUrlRewriteConfigRewritePropertyOutputReference | AwsAlbListenerRule.TransformUrlRewriteConfigRewriteProperty): any;
export declare function awsAlbListenerRuleUrlRewriteConfigPropertyToTerraform(struct?: AwsAlbListenerRule.UrlRewriteConfigPropertyOutputReference | AwsAlbListenerRule.UrlRewriteConfigProperty): any;
export declare function awsAlbListenerRuleUrlRewriteConfigPropertyToHclTerraform(struct?: AwsAlbListenerRule.UrlRewriteConfigPropertyOutputReference | AwsAlbListenerRule.UrlRewriteConfigProperty): any;
export declare function awsAlbListenerRuleTransformPropertyToTerraform(struct?: AwsAlbListenerRule.TransformProperty | cdktn.IResolvable): any;
export declare function awsAlbListenerRuleTransformPropertyToHclTerraform(struct?: AwsAlbListenerRule.TransformProperty | cdktn.IResolvable): any;
export declare namespace AwsAlbListenerRule {
    interface AuthenticateCognitoProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#authentication_request_extra_params AwsAlbListenerRule#authentication_request_extra_params}
        */
        readonly authenticationRequestExtraParams?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#on_unauthenticated_request AwsAlbListenerRule#on_unauthenticated_request}
        */
        readonly onUnauthenticatedRequest?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#scope AwsAlbListenerRule#scope}
        */
        readonly scope?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#session_cookie_name AwsAlbListenerRule#session_cookie_name}
        */
        readonly sessionCookieName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#session_timeout AwsAlbListenerRule#session_timeout}
        */
        readonly sessionTimeout?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#user_pool_arn AwsAlbListenerRule#user_pool_arn}
        */
        readonly userPoolArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#user_pool_client_id AwsAlbListenerRule#user_pool_client_id}
        */
        readonly userPoolClientId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#user_pool_domain AwsAlbListenerRule#user_pool_domain}
        */
        readonly userPoolDomain: string;
    }
    class AuthenticateCognitoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AuthenticateCognitoProperty | undefined;
        set internalValue(value: AuthenticateCognitoProperty | undefined);
        private _authenticationRequestExtraParams?;
        get authenticationRequestExtraParams(): {
            [key: string]: string;
        };
        set authenticationRequestExtraParams(value: {
            [key: string]: string;
        });
        resetAuthenticationRequestExtraParams(): void;
        get authenticationRequestExtraParamsInput(): {
            [key: string]: string;
        } | undefined;
        private _onUnauthenticatedRequest?;
        get onUnauthenticatedRequest(): string;
        set onUnauthenticatedRequest(value: string);
        resetOnUnauthenticatedRequest(): void;
        get onUnauthenticatedRequestInput(): string | undefined;
        private _scope?;
        get scope(): string;
        set scope(value: string);
        resetScope(): void;
        get scopeInput(): string | undefined;
        private _sessionCookieName?;
        get sessionCookieName(): string;
        set sessionCookieName(value: string);
        resetSessionCookieName(): void;
        get sessionCookieNameInput(): string | undefined;
        private _sessionTimeout?;
        get sessionTimeout(): number;
        set sessionTimeout(value: number);
        resetSessionTimeout(): void;
        get sessionTimeoutInput(): number | undefined;
        private _userPoolArn?;
        get userPoolArn(): string;
        set userPoolArn(value: string);
        get userPoolArnInput(): string | undefined;
        private _userPoolClientId?;
        get userPoolClientId(): string;
        set userPoolClientId(value: string);
        get userPoolClientIdInput(): string | undefined;
        private _userPoolDomain?;
        get userPoolDomain(): string;
        set userPoolDomain(value: string);
        get userPoolDomainInput(): string | undefined;
    }
    interface AuthenticateOidcProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#authentication_request_extra_params AwsAlbListenerRule#authentication_request_extra_params}
        */
        readonly authenticationRequestExtraParams?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#authorization_endpoint AwsAlbListenerRule#authorization_endpoint}
        */
        readonly authorizationEndpoint: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#client_id AwsAlbListenerRule#client_id}
        */
        readonly clientId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#client_secret AwsAlbListenerRule#client_secret}
        */
        readonly clientSecret: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#issuer AwsAlbListenerRule#issuer}
        */
        readonly issuer: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#on_unauthenticated_request AwsAlbListenerRule#on_unauthenticated_request}
        */
        readonly onUnauthenticatedRequest?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#scope AwsAlbListenerRule#scope}
        */
        readonly scope?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#session_cookie_name AwsAlbListenerRule#session_cookie_name}
        */
        readonly sessionCookieName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#session_timeout AwsAlbListenerRule#session_timeout}
        */
        readonly sessionTimeout?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#token_endpoint AwsAlbListenerRule#token_endpoint}
        */
        readonly tokenEndpoint: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#user_info_endpoint AwsAlbListenerRule#user_info_endpoint}
        */
        readonly userInfoEndpoint: string;
    }
    class AuthenticateOidcPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AuthenticateOidcProperty | undefined;
        set internalValue(value: AuthenticateOidcProperty | undefined);
        private _authenticationRequestExtraParams?;
        get authenticationRequestExtraParams(): {
            [key: string]: string;
        };
        set authenticationRequestExtraParams(value: {
            [key: string]: string;
        });
        resetAuthenticationRequestExtraParams(): void;
        get authenticationRequestExtraParamsInput(): {
            [key: string]: string;
        } | undefined;
        private _authorizationEndpoint?;
        get authorizationEndpoint(): string;
        set authorizationEndpoint(value: string);
        get authorizationEndpointInput(): string | undefined;
        private _clientId?;
        get clientId(): string;
        set clientId(value: string);
        get clientIdInput(): string | undefined;
        private _clientSecret?;
        get clientSecret(): string;
        set clientSecret(value: string);
        get clientSecretInput(): string | undefined;
        private _issuer?;
        get issuer(): string;
        set issuer(value: string);
        get issuerInput(): string | undefined;
        private _onUnauthenticatedRequest?;
        get onUnauthenticatedRequest(): string;
        set onUnauthenticatedRequest(value: string);
        resetOnUnauthenticatedRequest(): void;
        get onUnauthenticatedRequestInput(): string | undefined;
        private _scope?;
        get scope(): string;
        set scope(value: string);
        resetScope(): void;
        get scopeInput(): string | undefined;
        private _sessionCookieName?;
        get sessionCookieName(): string;
        set sessionCookieName(value: string);
        resetSessionCookieName(): void;
        get sessionCookieNameInput(): string | undefined;
        private _sessionTimeout?;
        get sessionTimeout(): number;
        set sessionTimeout(value: number);
        resetSessionTimeout(): void;
        get sessionTimeoutInput(): number | undefined;
        private _tokenEndpoint?;
        get tokenEndpoint(): string;
        set tokenEndpoint(value: string);
        get tokenEndpointInput(): string | undefined;
        private _userInfoEndpoint?;
        get userInfoEndpoint(): string;
        set userInfoEndpoint(value: string);
        get userInfoEndpointInput(): string | undefined;
    }
    interface FixedResponseProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#content_type AwsAlbListenerRule#content_type}
        */
        readonly contentType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#message_body AwsAlbListenerRule#message_body}
        */
        readonly messageBody?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#status_code AwsAlbListenerRule#status_code}
        */
        readonly statusCode?: string;
    }
    class FixedResponsePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FixedResponseProperty | undefined;
        set internalValue(value: FixedResponseProperty | undefined);
        private _contentType?;
        get contentType(): string;
        set contentType(value: string);
        get contentTypeInput(): string | undefined;
        private _messageBody?;
        get messageBody(): string;
        set messageBody(value: string);
        resetMessageBody(): void;
        get messageBodyInput(): string | undefined;
        private _statusCode?;
        get statusCode(): string;
        set statusCode(value: string);
        resetStatusCode(): void;
        get statusCodeInput(): string | undefined;
    }
    interface StickinessProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#duration AwsAlbListenerRule#duration}
        */
        readonly duration: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#enabled AwsAlbListenerRule#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
    }
    class StickinessPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StickinessProperty | undefined;
        set internalValue(value: StickinessProperty | undefined);
        private _duration?;
        get duration(): number;
        set duration(value: number);
        get durationInput(): number | undefined;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface TargetGroupProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#arn AwsAlbListenerRule#arn}
        */
        readonly arn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#weight AwsAlbListenerRule#weight}
        */
        readonly weight?: number;
    }
    class TargetGroupPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetGroupProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetGroupProperty | cdktn.IResolvable | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
        private _weight?;
        get weight(): number;
        set weight(value: number);
        resetWeight(): void;
        get weightInput(): number | undefined;
    }
    class TargetGroupPropertyList extends cdktn.ComplexList {
        internalValue?: TargetGroupProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetGroupPropertyOutputReference;
    }
    interface ForwardProperty {
        /**
        * stickiness block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#stickiness AwsAlbListenerRule#stickiness}
        */
        readonly stickiness?: StickinessProperty;
        /**
        * target_group block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#target_group AwsAlbListenerRule#target_group}
        */
        readonly targetGroup: TargetGroupProperty[] | cdktn.IResolvable;
    }
    class ForwardPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ForwardProperty | undefined;
        set internalValue(value: ForwardProperty | undefined);
        private _stickiness;
        get stickiness(): StickinessPropertyOutputReference;
        putStickiness(value: StickinessProperty): void;
        resetStickiness(): void;
        get stickinessInput(): StickinessProperty | undefined;
        private _targetGroup;
        get targetGroup(): TargetGroupPropertyList;
        putTargetGroup(value: TargetGroupProperty[] | cdktn.IResolvable): void;
        get targetGroupInput(): cdktn.IResolvable | TargetGroupProperty[] | undefined;
    }
    interface AdditionalClaimProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#format AwsAlbListenerRule#format}
        */
        readonly format: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#name AwsAlbListenerRule#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#values AwsAlbListenerRule#values}
        */
        readonly values: string[];
    }
    class AdditionalClaimPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AdditionalClaimProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AdditionalClaimProperty | cdktn.IResolvable | undefined);
        private _format?;
        get format(): string;
        set format(value: string);
        get formatInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class AdditionalClaimPropertyList extends cdktn.ComplexList {
        internalValue?: AdditionalClaimProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AdditionalClaimPropertyOutputReference;
    }
    interface JwtValidationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#issuer AwsAlbListenerRule#issuer}
        */
        readonly issuer: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#jwks_endpoint AwsAlbListenerRule#jwks_endpoint}
        */
        readonly jwksEndpoint: string;
        /**
        * additional_claim block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#additional_claim AwsAlbListenerRule#additional_claim}
        */
        readonly additionalClaim?: AdditionalClaimProperty[] | cdktn.IResolvable;
    }
    class JwtValidationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): JwtValidationProperty | undefined;
        set internalValue(value: JwtValidationProperty | undefined);
        private _issuer?;
        get issuer(): string;
        set issuer(value: string);
        get issuerInput(): string | undefined;
        private _jwksEndpoint?;
        get jwksEndpoint(): string;
        set jwksEndpoint(value: string);
        get jwksEndpointInput(): string | undefined;
        private _additionalClaim;
        get additionalClaim(): AdditionalClaimPropertyList;
        putAdditionalClaim(value: AdditionalClaimProperty[] | cdktn.IResolvable): void;
        resetAdditionalClaim(): void;
        get additionalClaimInput(): cdktn.IResolvable | AdditionalClaimProperty[] | undefined;
    }
    interface RedirectProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#host AwsAlbListenerRule#host}
        */
        readonly host?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#path AwsAlbListenerRule#path}
        */
        readonly path?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#port AwsAlbListenerRule#port}
        */
        readonly port?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#protocol AwsAlbListenerRule#protocol}
        */
        readonly protocol?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#query AwsAlbListenerRule#query}
        */
        readonly query?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#status_code AwsAlbListenerRule#status_code}
        */
        readonly statusCode: string;
    }
    class RedirectPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RedirectProperty | undefined;
        set internalValue(value: RedirectProperty | undefined);
        private _host?;
        get host(): string;
        set host(value: string);
        resetHost(): void;
        get hostInput(): string | undefined;
        private _path?;
        get path(): string;
        set path(value: string);
        resetPath(): void;
        get pathInput(): string | undefined;
        private _port?;
        get port(): string;
        set port(value: string);
        resetPort(): void;
        get portInput(): string | undefined;
        private _protocol?;
        get protocol(): string;
        set protocol(value: string);
        resetProtocol(): void;
        get protocolInput(): string | undefined;
        private _query?;
        get query(): string;
        set query(value: string);
        resetQuery(): void;
        get queryInput(): string | undefined;
        private _statusCode?;
        get statusCode(): string;
        set statusCode(value: string);
        get statusCodeInput(): string | undefined;
    }
    interface ActionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#order AwsAlbListenerRule#order}
        */
        readonly order?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#target_group_arn AwsAlbListenerRule#target_group_arn}
        */
        readonly targetGroupArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#type AwsAlbListenerRule#type}
        */
        readonly type: string;
        /**
        * authenticate_cognito block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#authenticate_cognito AwsAlbListenerRule#authenticate_cognito}
        */
        readonly authenticateCognito?: AuthenticateCognitoProperty;
        /**
        * authenticate_oidc block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#authenticate_oidc AwsAlbListenerRule#authenticate_oidc}
        */
        readonly authenticateOidc?: AuthenticateOidcProperty;
        /**
        * fixed_response block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#fixed_response AwsAlbListenerRule#fixed_response}
        */
        readonly fixedResponse?: FixedResponseProperty;
        /**
        * forward block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#forward AwsAlbListenerRule#forward}
        */
        readonly forward?: ForwardProperty;
        /**
        * jwt_validation block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#jwt_validation AwsAlbListenerRule#jwt_validation}
        */
        readonly jwtValidation?: JwtValidationProperty;
        /**
        * redirect block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#redirect AwsAlbListenerRule#redirect}
        */
        readonly redirect?: RedirectProperty;
    }
    class ActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ActionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ActionProperty | cdktn.IResolvable | undefined);
        private _order?;
        get order(): number;
        set order(value: number);
        resetOrder(): void;
        get orderInput(): number | undefined;
        private _targetGroupArn?;
        get targetGroupArn(): string;
        set targetGroupArn(value: string);
        resetTargetGroupArn(): void;
        get targetGroupArnInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _authenticateCognito;
        get authenticateCognito(): AuthenticateCognitoPropertyOutputReference;
        putAuthenticateCognito(value: AuthenticateCognitoProperty): void;
        resetAuthenticateCognito(): void;
        get authenticateCognitoInput(): AuthenticateCognitoProperty | undefined;
        private _authenticateOidc;
        get authenticateOidc(): AuthenticateOidcPropertyOutputReference;
        putAuthenticateOidc(value: AuthenticateOidcProperty): void;
        resetAuthenticateOidc(): void;
        get authenticateOidcInput(): AuthenticateOidcProperty | undefined;
        private _fixedResponse;
        get fixedResponse(): FixedResponsePropertyOutputReference;
        putFixedResponse(value: FixedResponseProperty): void;
        resetFixedResponse(): void;
        get fixedResponseInput(): FixedResponseProperty | undefined;
        private _forward;
        get forward(): ForwardPropertyOutputReference;
        putForward(value: ForwardProperty): void;
        resetForward(): void;
        get forwardInput(): ForwardProperty | undefined;
        private _jwtValidation;
        get jwtValidation(): JwtValidationPropertyOutputReference;
        putJwtValidation(value: JwtValidationProperty): void;
        resetJwtValidation(): void;
        get jwtValidationInput(): JwtValidationProperty | undefined;
        private _redirect;
        get redirect(): RedirectPropertyOutputReference;
        putRedirect(value: RedirectProperty): void;
        resetRedirect(): void;
        get redirectInput(): RedirectProperty | undefined;
    }
    class ActionPropertyList extends cdktn.ComplexList {
        internalValue?: ActionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ActionPropertyOutputReference;
    }
    interface HostHeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#regex_values AwsAlbListenerRule#regex_values}
        */
        readonly regexValues?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#values AwsAlbListenerRule#values}
        */
        readonly values?: string[];
    }
    class HostHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HostHeaderProperty | undefined;
        set internalValue(value: HostHeaderProperty | undefined);
        private _regexValues?;
        get regexValues(): string[];
        set regexValues(value: string[]);
        resetRegexValues(): void;
        get regexValuesInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface HttpHeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#http_header_name AwsAlbListenerRule#http_header_name}
        */
        readonly httpHeaderName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#regex_values AwsAlbListenerRule#regex_values}
        */
        readonly regexValues?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#values AwsAlbListenerRule#values}
        */
        readonly values?: string[];
    }
    class HttpHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HttpHeaderProperty | undefined;
        set internalValue(value: HttpHeaderProperty | undefined);
        private _httpHeaderName?;
        get httpHeaderName(): string;
        set httpHeaderName(value: string);
        get httpHeaderNameInput(): string | undefined;
        private _regexValues?;
        get regexValues(): string[];
        set regexValues(value: string[]);
        resetRegexValues(): void;
        get regexValuesInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface HttpRequestMethodProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#values AwsAlbListenerRule#values}
        */
        readonly values: string[];
    }
    class HttpRequestMethodPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HttpRequestMethodProperty | undefined;
        set internalValue(value: HttpRequestMethodProperty | undefined);
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    interface PathPatternProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#regex_values AwsAlbListenerRule#regex_values}
        */
        readonly regexValues?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#values AwsAlbListenerRule#values}
        */
        readonly values?: string[];
    }
    class PathPatternPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PathPatternProperty | undefined;
        set internalValue(value: PathPatternProperty | undefined);
        private _regexValues?;
        get regexValues(): string[];
        set regexValues(value: string[]);
        resetRegexValues(): void;
        get regexValuesInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface QueryStringProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#key AwsAlbListenerRule#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#value AwsAlbListenerRule#value}
        */
        readonly value: string;
    }
    class QueryStringPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): QueryStringProperty | cdktn.IResolvable | undefined;
        set internalValue(value: QueryStringProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class QueryStringPropertyList extends cdktn.ComplexList {
        internalValue?: QueryStringProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): QueryStringPropertyOutputReference;
    }
    interface SourceIpProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#ip_address_type AwsAlbListenerRule#ip_address_type}
        */
        readonly ipAddressType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#values AwsAlbListenerRule#values}
        */
        readonly values?: string[];
    }
    class SourceIpPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceIpProperty | undefined;
        set internalValue(value: SourceIpProperty | undefined);
        private _ipAddressType?;
        get ipAddressType(): string;
        set ipAddressType(value: string);
        resetIpAddressType(): void;
        get ipAddressTypeInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface ConditionProperty {
        /**
        * host_header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#host_header AwsAlbListenerRule#host_header}
        */
        readonly hostHeader?: HostHeaderProperty;
        /**
        * http_header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#http_header AwsAlbListenerRule#http_header}
        */
        readonly httpHeader?: HttpHeaderProperty;
        /**
        * http_request_method block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#http_request_method AwsAlbListenerRule#http_request_method}
        */
        readonly httpRequestMethod?: HttpRequestMethodProperty;
        /**
        * path_pattern block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#path_pattern AwsAlbListenerRule#path_pattern}
        */
        readonly pathPattern?: PathPatternProperty;
        /**
        * query_string block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#query_string AwsAlbListenerRule#query_string}
        */
        readonly queryString?: QueryStringProperty[] | cdktn.IResolvable;
        /**
        * source_ip block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#source_ip AwsAlbListenerRule#source_ip}
        */
        readonly sourceIp?: SourceIpProperty;
    }
    class ConditionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConditionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConditionProperty | cdktn.IResolvable | undefined);
        private _hostHeader;
        get hostHeader(): HostHeaderPropertyOutputReference;
        putHostHeader(value: HostHeaderProperty): void;
        resetHostHeader(): void;
        get hostHeaderInput(): HostHeaderProperty | undefined;
        private _httpHeader;
        get httpHeader(): HttpHeaderPropertyOutputReference;
        putHttpHeader(value: HttpHeaderProperty): void;
        resetHttpHeader(): void;
        get httpHeaderInput(): HttpHeaderProperty | undefined;
        private _httpRequestMethod;
        get httpRequestMethod(): HttpRequestMethodPropertyOutputReference;
        putHttpRequestMethod(value: HttpRequestMethodProperty): void;
        resetHttpRequestMethod(): void;
        get httpRequestMethodInput(): HttpRequestMethodProperty | undefined;
        private _pathPattern;
        get pathPattern(): PathPatternPropertyOutputReference;
        putPathPattern(value: PathPatternProperty): void;
        resetPathPattern(): void;
        get pathPatternInput(): PathPatternProperty | undefined;
        private _queryString;
        get queryString(): QueryStringPropertyList;
        putQueryString(value: QueryStringProperty[] | cdktn.IResolvable): void;
        resetQueryString(): void;
        get queryStringInput(): cdktn.IResolvable | QueryStringProperty[] | undefined;
        private _sourceIp;
        get sourceIp(): SourceIpPropertyOutputReference;
        putSourceIp(value: SourceIpProperty): void;
        resetSourceIp(): void;
        get sourceIpInput(): SourceIpProperty | undefined;
    }
    class ConditionPropertyList extends cdktn.ComplexList {
        internalValue?: ConditionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConditionPropertyOutputReference;
    }
    interface TransformHostHeaderRewriteConfigRewriteProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#regex AwsAlbListenerRule#regex}
        */
        readonly regex: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#replace AwsAlbListenerRule#replace}
        */
        readonly replace: string;
    }
    class TransformHostHeaderRewriteConfigRewritePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TransformHostHeaderRewriteConfigRewriteProperty | undefined;
        set internalValue(value: TransformHostHeaderRewriteConfigRewriteProperty | undefined);
        private _regex?;
        get regex(): string;
        set regex(value: string);
        get regexInput(): string | undefined;
        private _replace?;
        get replace(): string;
        set replace(value: string);
        get replaceInput(): string | undefined;
    }
    interface HostHeaderRewriteConfigProperty {
        /**
        * rewrite block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#rewrite AwsAlbListenerRule#rewrite}
        */
        readonly rewrite?: TransformHostHeaderRewriteConfigRewriteProperty;
    }
    class HostHeaderRewriteConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HostHeaderRewriteConfigProperty | undefined;
        set internalValue(value: HostHeaderRewriteConfigProperty | undefined);
        private _rewrite;
        get rewrite(): TransformHostHeaderRewriteConfigRewritePropertyOutputReference;
        putRewrite(value: TransformHostHeaderRewriteConfigRewriteProperty): void;
        resetRewrite(): void;
        get rewriteInput(): TransformHostHeaderRewriteConfigRewriteProperty | undefined;
    }
    interface TransformUrlRewriteConfigRewriteProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#regex AwsAlbListenerRule#regex}
        */
        readonly regex: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#replace AwsAlbListenerRule#replace}
        */
        readonly replace: string;
    }
    class TransformUrlRewriteConfigRewritePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TransformUrlRewriteConfigRewriteProperty | undefined;
        set internalValue(value: TransformUrlRewriteConfigRewriteProperty | undefined);
        private _regex?;
        get regex(): string;
        set regex(value: string);
        get regexInput(): string | undefined;
        private _replace?;
        get replace(): string;
        set replace(value: string);
        get replaceInput(): string | undefined;
    }
    interface UrlRewriteConfigProperty {
        /**
        * rewrite block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#rewrite AwsAlbListenerRule#rewrite}
        */
        readonly rewrite?: TransformUrlRewriteConfigRewriteProperty;
    }
    class UrlRewriteConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UrlRewriteConfigProperty | undefined;
        set internalValue(value: UrlRewriteConfigProperty | undefined);
        private _rewrite;
        get rewrite(): TransformUrlRewriteConfigRewritePropertyOutputReference;
        putRewrite(value: TransformUrlRewriteConfigRewriteProperty): void;
        resetRewrite(): void;
        get rewriteInput(): TransformUrlRewriteConfigRewriteProperty | undefined;
    }
    interface TransformProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#type AwsAlbListenerRule#type}
        */
        readonly type: string;
        /**
        * host_header_rewrite_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#host_header_rewrite_config AwsAlbListenerRule#host_header_rewrite_config}
        */
        readonly hostHeaderRewriteConfig?: HostHeaderRewriteConfigProperty;
        /**
        * url_rewrite_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/alb_listener_rule#url_rewrite_config AwsAlbListenerRule#url_rewrite_config}
        */
        readonly urlRewriteConfig?: UrlRewriteConfigProperty;
    }
    class TransformPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TransformProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TransformProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _hostHeaderRewriteConfig;
        get hostHeaderRewriteConfig(): HostHeaderRewriteConfigPropertyOutputReference;
        putHostHeaderRewriteConfig(value: HostHeaderRewriteConfigProperty): void;
        resetHostHeaderRewriteConfig(): void;
        get hostHeaderRewriteConfigInput(): HostHeaderRewriteConfigProperty | undefined;
        private _urlRewriteConfig;
        get urlRewriteConfig(): UrlRewriteConfigPropertyOutputReference;
        putUrlRewriteConfig(value: UrlRewriteConfigProperty): void;
        resetUrlRewriteConfig(): void;
        get urlRewriteConfigInput(): UrlRewriteConfigProperty | undefined;
    }
    class TransformPropertyList extends cdktn.ComplexList {
        internalValue?: TransformProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TransformPropertyOutputReference;
    }
}
