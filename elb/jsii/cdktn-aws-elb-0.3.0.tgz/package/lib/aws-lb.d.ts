import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsLbConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#client_keep_alive AwsLb#client_keep_alive}
    */
    readonly clientKeepAlive?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#customer_owned_ipv4_pool AwsLb#customer_owned_ipv4_pool}
    */
    readonly customerOwnedIpv4Pool?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#desync_mitigation_mode AwsLb#desync_mitigation_mode}
    */
    readonly desyncMitigationMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#dns_record_client_routing_policy AwsLb#dns_record_client_routing_policy}
    */
    readonly dnsRecordClientRoutingPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#drop_invalid_header_fields AwsLb#drop_invalid_header_fields}
    */
    readonly dropInvalidHeaderFields?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#enable_cross_zone_load_balancing AwsLb#enable_cross_zone_load_balancing}
    */
    readonly enableCrossZoneLoadBalancing?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#enable_deletion_protection AwsLb#enable_deletion_protection}
    */
    readonly enableDeletionProtection?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#enable_http2 AwsLb#enable_http2}
    */
    readonly enableHttp2?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#enable_prefix_for_ipv6_source_nat AwsLb#enable_prefix_for_ipv6_source_nat}
    */
    readonly enablePrefixForIpv6SourceNat?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#enable_tls_version_and_cipher_suite_headers AwsLb#enable_tls_version_and_cipher_suite_headers}
    */
    readonly enableTlsVersionAndCipherSuiteHeaders?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#enable_waf_fail_open AwsLb#enable_waf_fail_open}
    */
    readonly enableWafFailOpen?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#enable_xff_client_port AwsLb#enable_xff_client_port}
    */
    readonly enableXffClientPort?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#enable_zonal_shift AwsLb#enable_zonal_shift}
    */
    readonly enableZonalShift?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#enforce_security_group_inbound_rules_on_private_link_traffic AwsLb#enforce_security_group_inbound_rules_on_private_link_traffic}
    */
    readonly enforceSecurityGroupInboundRulesOnPrivateLinkTraffic?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#id AwsLb#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#idle_timeout AwsLb#idle_timeout}
    */
    readonly idleTimeout?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#internal AwsLb#internal}
    */
    readonly internal?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#ip_address_type AwsLb#ip_address_type}
    */
    readonly ipAddressType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#load_balancer_type AwsLb#load_balancer_type}
    */
    readonly loadBalancerType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#name AwsLb#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#name_prefix AwsLb#name_prefix}
    */
    readonly namePrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#preserve_host_header AwsLb#preserve_host_header}
    */
    readonly preserveHostHeader?: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#region AwsLb#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#secondary_ips_auto_assigned_per_subnet AwsLb#secondary_ips_auto_assigned_per_subnet}
    */
    readonly secondaryIpsAutoAssignedPerSubnet?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#security_groups AwsLb#security_groups}
    */
    readonly securityGroups?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#subnets AwsLb#subnets}
    */
    readonly subnets?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#tags AwsLb#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#tags_all AwsLb#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#xff_header_processing_mode AwsLb#xff_header_processing_mode}
    */
    readonly xffHeaderProcessingMode?: string;
    /**
    * access_logs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#access_logs AwsLb#access_logs}
    */
    readonly accessLogs?: AwsLb.AccessLogsProperty;
    /**
    * connection_logs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#connection_logs AwsLb#connection_logs}
    */
    readonly connectionLogs?: AwsLb.ConnectionLogsProperty;
    /**
    * health_check_logs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#health_check_logs AwsLb#health_check_logs}
    */
    readonly healthCheckLogs?: AwsLb.HealthCheckLogsProperty;
    /**
    * ipam_pools block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#ipam_pools AwsLb#ipam_pools}
    */
    readonly ipamPools?: AwsLb.IpamPoolsProperty;
    /**
    * minimum_load_balancer_capacity block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#minimum_load_balancer_capacity AwsLb#minimum_load_balancer_capacity}
    */
    readonly minimumLoadBalancerCapacity?: AwsLb.MinimumLoadBalancerCapacityProperty;
    /**
    * subnet_mapping block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#subnet_mapping AwsLb#subnet_mapping}
    */
    readonly subnetMapping?: AwsLb.SubnetMappingProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#timeouts AwsLb#timeouts}
    */
    readonly timeouts?: AwsLb.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb aws_lb}
*/
export declare class AwsLb extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_lb";
    /**
    * Generates CDKTN code for importing a AwsLb resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsLb to import
    * @param importFromId The id of the existing AwsLb that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsLb to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb aws_lb} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsLbConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AwsLbConfig);
    get arn(): string;
    get arnSuffix(): string;
    private _clientKeepAlive?;
    get clientKeepAlive(): number;
    set clientKeepAlive(value: number);
    resetClientKeepAlive(): void;
    get clientKeepAliveInput(): number | undefined;
    private _customerOwnedIpv4Pool?;
    get customerOwnedIpv4Pool(): string;
    set customerOwnedIpv4Pool(value: string);
    resetCustomerOwnedIpv4Pool(): void;
    get customerOwnedIpv4PoolInput(): string | undefined;
    private _desyncMitigationMode?;
    get desyncMitigationMode(): string;
    set desyncMitigationMode(value: string);
    resetDesyncMitigationMode(): void;
    get desyncMitigationModeInput(): string | undefined;
    get dnsName(): string;
    private _dnsRecordClientRoutingPolicy?;
    get dnsRecordClientRoutingPolicy(): string;
    set dnsRecordClientRoutingPolicy(value: string);
    resetDnsRecordClientRoutingPolicy(): void;
    get dnsRecordClientRoutingPolicyInput(): string | undefined;
    private _dropInvalidHeaderFields?;
    get dropInvalidHeaderFields(): boolean | cdktn.IResolvable;
    set dropInvalidHeaderFields(value: boolean | cdktn.IResolvable);
    resetDropInvalidHeaderFields(): void;
    get dropInvalidHeaderFieldsInput(): boolean | cdktn.IResolvable | undefined;
    private _enableCrossZoneLoadBalancing?;
    get enableCrossZoneLoadBalancing(): boolean | cdktn.IResolvable;
    set enableCrossZoneLoadBalancing(value: boolean | cdktn.IResolvable);
    resetEnableCrossZoneLoadBalancing(): void;
    get enableCrossZoneLoadBalancingInput(): boolean | cdktn.IResolvable | undefined;
    private _enableDeletionProtection?;
    get enableDeletionProtection(): boolean | cdktn.IResolvable;
    set enableDeletionProtection(value: boolean | cdktn.IResolvable);
    resetEnableDeletionProtection(): void;
    get enableDeletionProtectionInput(): boolean | cdktn.IResolvable | undefined;
    private _enableHttp2?;
    get enableHttp2(): boolean | cdktn.IResolvable;
    set enableHttp2(value: boolean | cdktn.IResolvable);
    resetEnableHttp2(): void;
    get enableHttp2Input(): boolean | cdktn.IResolvable | undefined;
    private _enablePrefixForIpv6SourceNat?;
    get enablePrefixForIpv6SourceNat(): string;
    set enablePrefixForIpv6SourceNat(value: string);
    resetEnablePrefixForIpv6SourceNat(): void;
    get enablePrefixForIpv6SourceNatInput(): string | undefined;
    private _enableTlsVersionAndCipherSuiteHeaders?;
    get enableTlsVersionAndCipherSuiteHeaders(): boolean | cdktn.IResolvable;
    set enableTlsVersionAndCipherSuiteHeaders(value: boolean | cdktn.IResolvable);
    resetEnableTlsVersionAndCipherSuiteHeaders(): void;
    get enableTlsVersionAndCipherSuiteHeadersInput(): boolean | cdktn.IResolvable | undefined;
    private _enableWafFailOpen?;
    get enableWafFailOpen(): boolean | cdktn.IResolvable;
    set enableWafFailOpen(value: boolean | cdktn.IResolvable);
    resetEnableWafFailOpen(): void;
    get enableWafFailOpenInput(): boolean | cdktn.IResolvable | undefined;
    private _enableXffClientPort?;
    get enableXffClientPort(): boolean | cdktn.IResolvable;
    set enableXffClientPort(value: boolean | cdktn.IResolvable);
    resetEnableXffClientPort(): void;
    get enableXffClientPortInput(): boolean | cdktn.IResolvable | undefined;
    private _enableZonalShift?;
    get enableZonalShift(): boolean | cdktn.IResolvable;
    set enableZonalShift(value: boolean | cdktn.IResolvable);
    resetEnableZonalShift(): void;
    get enableZonalShiftInput(): boolean | cdktn.IResolvable | undefined;
    private _enforceSecurityGroupInboundRulesOnPrivateLinkTraffic?;
    get enforceSecurityGroupInboundRulesOnPrivateLinkTraffic(): string;
    set enforceSecurityGroupInboundRulesOnPrivateLinkTraffic(value: string);
    resetEnforceSecurityGroupInboundRulesOnPrivateLinkTraffic(): void;
    get enforceSecurityGroupInboundRulesOnPrivateLinkTrafficInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _idleTimeout?;
    get idleTimeout(): number;
    set idleTimeout(value: number);
    resetIdleTimeout(): void;
    get idleTimeoutInput(): number | undefined;
    private _internal?;
    get internal(): boolean | cdktn.IResolvable;
    set internal(value: boolean | cdktn.IResolvable);
    resetInternal(): void;
    get internalInput(): boolean | cdktn.IResolvable | undefined;
    private _ipAddressType?;
    get ipAddressType(): string;
    set ipAddressType(value: string);
    resetIpAddressType(): void;
    get ipAddressTypeInput(): string | undefined;
    private _loadBalancerType?;
    get loadBalancerType(): string;
    set loadBalancerType(value: string);
    resetLoadBalancerType(): void;
    get loadBalancerTypeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namePrefix?;
    get namePrefix(): string;
    set namePrefix(value: string);
    resetNamePrefix(): void;
    get namePrefixInput(): string | undefined;
    private _preserveHostHeader?;
    get preserveHostHeader(): boolean | cdktn.IResolvable;
    set preserveHostHeader(value: boolean | cdktn.IResolvable);
    resetPreserveHostHeader(): void;
    get preserveHostHeaderInput(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _secondaryIpsAutoAssignedPerSubnet?;
    get secondaryIpsAutoAssignedPerSubnet(): number;
    set secondaryIpsAutoAssignedPerSubnet(value: number);
    resetSecondaryIpsAutoAssignedPerSubnet(): void;
    get secondaryIpsAutoAssignedPerSubnetInput(): number | undefined;
    private _securityGroups?;
    get securityGroups(): string[];
    set securityGroups(value: string[]);
    resetSecurityGroups(): void;
    get securityGroupsInput(): string[] | undefined;
    private _subnets?;
    get subnets(): string[];
    set subnets(value: string[]);
    resetSubnets(): void;
    get subnetsInput(): string[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get vpcId(): string;
    private _xffHeaderProcessingMode?;
    get xffHeaderProcessingMode(): string;
    set xffHeaderProcessingMode(value: string);
    resetXffHeaderProcessingMode(): void;
    get xffHeaderProcessingModeInput(): string | undefined;
    get zoneId(): string;
    private _accessLogs;
    get accessLogs(): AwsLb.AccessLogsPropertyOutputReference;
    putAccessLogs(value: AwsLb.AccessLogsProperty): void;
    resetAccessLogs(): void;
    get accessLogsInput(): AwsLb.AccessLogsProperty | undefined;
    private _connectionLogs;
    get connectionLogs(): AwsLb.ConnectionLogsPropertyOutputReference;
    putConnectionLogs(value: AwsLb.ConnectionLogsProperty): void;
    resetConnectionLogs(): void;
    get connectionLogsInput(): AwsLb.ConnectionLogsProperty | undefined;
    private _healthCheckLogs;
    get healthCheckLogs(): AwsLb.HealthCheckLogsPropertyOutputReference;
    putHealthCheckLogs(value: AwsLb.HealthCheckLogsProperty): void;
    resetHealthCheckLogs(): void;
    get healthCheckLogsInput(): AwsLb.HealthCheckLogsProperty | undefined;
    private _ipamPools;
    get ipamPools(): AwsLb.IpamPoolsPropertyOutputReference;
    putIpamPools(value: AwsLb.IpamPoolsProperty): void;
    resetIpamPools(): void;
    get ipamPoolsInput(): AwsLb.IpamPoolsProperty | undefined;
    private _minimumLoadBalancerCapacity;
    get minimumLoadBalancerCapacity(): AwsLb.MinimumLoadBalancerCapacityPropertyOutputReference;
    putMinimumLoadBalancerCapacity(value: AwsLb.MinimumLoadBalancerCapacityProperty): void;
    resetMinimumLoadBalancerCapacity(): void;
    get minimumLoadBalancerCapacityInput(): AwsLb.MinimumLoadBalancerCapacityProperty | undefined;
    private _subnetMapping;
    get subnetMapping(): AwsLb.SubnetMappingPropertyList;
    putSubnetMapping(value: AwsLb.SubnetMappingProperty[] | cdktn.IResolvable): void;
    resetSubnetMapping(): void;
    get subnetMappingInput(): cdktn.IResolvable | AwsLb.SubnetMappingProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsLb.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsLb.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsLb.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsLbAccessLogsPropertyToTerraform(struct?: AwsLb.AccessLogsPropertyOutputReference | AwsLb.AccessLogsProperty): any;
export declare function awsLbAccessLogsPropertyToHclTerraform(struct?: AwsLb.AccessLogsPropertyOutputReference | AwsLb.AccessLogsProperty): any;
export declare function awsLbConnectionLogsPropertyToTerraform(struct?: AwsLb.ConnectionLogsPropertyOutputReference | AwsLb.ConnectionLogsProperty): any;
export declare function awsLbConnectionLogsPropertyToHclTerraform(struct?: AwsLb.ConnectionLogsPropertyOutputReference | AwsLb.ConnectionLogsProperty): any;
export declare function awsLbHealthCheckLogsPropertyToTerraform(struct?: AwsLb.HealthCheckLogsPropertyOutputReference | AwsLb.HealthCheckLogsProperty): any;
export declare function awsLbHealthCheckLogsPropertyToHclTerraform(struct?: AwsLb.HealthCheckLogsPropertyOutputReference | AwsLb.HealthCheckLogsProperty): any;
export declare function awsLbIpamPoolsPropertyToTerraform(struct?: AwsLb.IpamPoolsPropertyOutputReference | AwsLb.IpamPoolsProperty): any;
export declare function awsLbIpamPoolsPropertyToHclTerraform(struct?: AwsLb.IpamPoolsPropertyOutputReference | AwsLb.IpamPoolsProperty): any;
export declare function awsLbMinimumLoadBalancerCapacityPropertyToTerraform(struct?: AwsLb.MinimumLoadBalancerCapacityPropertyOutputReference | AwsLb.MinimumLoadBalancerCapacityProperty): any;
export declare function awsLbMinimumLoadBalancerCapacityPropertyToHclTerraform(struct?: AwsLb.MinimumLoadBalancerCapacityPropertyOutputReference | AwsLb.MinimumLoadBalancerCapacityProperty): any;
export declare function awsLbSubnetMappingPropertyToTerraform(struct?: AwsLb.SubnetMappingProperty | cdktn.IResolvable): any;
export declare function awsLbSubnetMappingPropertyToHclTerraform(struct?: AwsLb.SubnetMappingProperty | cdktn.IResolvable): any;
export declare function awsLbTimeoutsPropertyToTerraform(struct?: AwsLb.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsLbTimeoutsPropertyToHclTerraform(struct?: AwsLb.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsLb {
    interface AccessLogsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#bucket AwsLb#bucket}
        */
        readonly bucket: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#enabled AwsLb#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#prefix AwsLb#prefix}
        */
        readonly prefix?: string;
    }
    class AccessLogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AccessLogsProperty | undefined;
        set internalValue(value: AccessLogsProperty | undefined);
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        get bucketInput(): string | undefined;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
    }
    interface ConnectionLogsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#bucket AwsLb#bucket}
        */
        readonly bucket: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#enabled AwsLb#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#prefix AwsLb#prefix}
        */
        readonly prefix?: string;
    }
    class ConnectionLogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConnectionLogsProperty | undefined;
        set internalValue(value: ConnectionLogsProperty | undefined);
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        get bucketInput(): string | undefined;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
    }
    interface HealthCheckLogsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#bucket AwsLb#bucket}
        */
        readonly bucket: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#enabled AwsLb#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#prefix AwsLb#prefix}
        */
        readonly prefix?: string;
    }
    class HealthCheckLogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HealthCheckLogsProperty | undefined;
        set internalValue(value: HealthCheckLogsProperty | undefined);
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        get bucketInput(): string | undefined;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
    }
    interface IpamPoolsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#ipv4_ipam_pool_id AwsLb#ipv4_ipam_pool_id}
        */
        readonly ipv4IpamPoolId: string;
    }
    class IpamPoolsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IpamPoolsProperty | undefined;
        set internalValue(value: IpamPoolsProperty | undefined);
        private _ipv4IpamPoolId?;
        get ipv4IpamPoolId(): string;
        set ipv4IpamPoolId(value: string);
        get ipv4IpamPoolIdInput(): string | undefined;
    }
    interface MinimumLoadBalancerCapacityProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#capacity_units AwsLb#capacity_units}
        */
        readonly capacityUnits: number;
    }
    class MinimumLoadBalancerCapacityPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MinimumLoadBalancerCapacityProperty | undefined;
        set internalValue(value: MinimumLoadBalancerCapacityProperty | undefined);
        private _capacityUnits?;
        get capacityUnits(): number;
        set capacityUnits(value: number);
        get capacityUnitsInput(): number | undefined;
    }
    interface SubnetMappingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#allocation_id AwsLb#allocation_id}
        */
        readonly allocationId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#ipv6_address AwsLb#ipv6_address}
        */
        readonly ipv6Address?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#private_ipv4_address AwsLb#private_ipv4_address}
        */
        readonly privateIpv4Address?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#subnet_id AwsLb#subnet_id}
        */
        readonly subnetId: string;
    }
    class SubnetMappingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SubnetMappingProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SubnetMappingProperty | cdktn.IResolvable | undefined);
        private _allocationId?;
        get allocationId(): string;
        set allocationId(value: string);
        resetAllocationId(): void;
        get allocationIdInput(): string | undefined;
        private _ipv6Address?;
        get ipv6Address(): string;
        set ipv6Address(value: string);
        resetIpv6Address(): void;
        get ipv6AddressInput(): string | undefined;
        get outpostId(): string;
        private _privateIpv4Address?;
        get privateIpv4Address(): string;
        set privateIpv4Address(value: string);
        resetPrivateIpv4Address(): void;
        get privateIpv4AddressInput(): string | undefined;
        private _subnetId?;
        get subnetId(): string;
        set subnetId(value: string);
        get subnetIdInput(): string | undefined;
    }
    class SubnetMappingPropertyList extends cdktn.ComplexList {
        internalValue?: SubnetMappingProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SubnetMappingPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#create AwsLb#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#delete AwsLb#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#update AwsLb#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
