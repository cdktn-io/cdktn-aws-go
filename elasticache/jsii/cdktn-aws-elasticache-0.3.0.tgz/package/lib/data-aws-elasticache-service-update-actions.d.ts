import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsServiceUpdateActionsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elasticache_service_update_actions#cache_cluster_id DataAwsServiceUpdateActions#cache_cluster_id}
    */
    readonly cacheClusterId?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elasticache_service_update_actions#region DataAwsServiceUpdateActions#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elasticache_service_update_actions#replication_group_id DataAwsServiceUpdateActions#replication_group_id}
    */
    readonly replicationGroupId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elasticache_service_update_actions#service_update_status DataAwsServiceUpdateActions#service_update_status}
    */
    readonly serviceUpdateStatus?: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elasticache_service_update_actions aws_elasticache_service_update_actions}
*/
export declare class DataAwsServiceUpdateActions extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_elasticache_service_update_actions";
    /**
    * Generates CDKTN code for importing a DataAwsServiceUpdateActions resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsServiceUpdateActions to import
    * @param importFromId The id of the existing DataAwsServiceUpdateActions that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elasticache_service_update_actions#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsServiceUpdateActions to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elasticache_service_update_actions aws_elasticache_service_update_actions} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsServiceUpdateActionsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsServiceUpdateActionsConfig);
    private _cacheClusterId?;
    get cacheClusterId(): string;
    set cacheClusterId(value: string);
    resetCacheClusterId(): void;
    get cacheClusterIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _replicationGroupId?;
    get replicationGroupId(): string;
    set replicationGroupId(value: string);
    resetReplicationGroupId(): void;
    get replicationGroupIdInput(): string | undefined;
    private _serviceUpdateStatus?;
    get serviceUpdateStatus(): string[];
    set serviceUpdateStatus(value: string[]);
    resetServiceUpdateStatus(): void;
    get serviceUpdateStatusInput(): string[] | undefined;
    private _updateActions;
    get updateActions(): DataAwsServiceUpdateActions.UpdateActionsPropertyList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsServiceUpdateActionsUpdateActionsPropertyToTerraform(struct?: DataAwsServiceUpdateActions.UpdateActionsProperty): any;
export declare function dataAwsServiceUpdateActionsUpdateActionsPropertyToHclTerraform(struct?: DataAwsServiceUpdateActions.UpdateActionsProperty): any;
export declare namespace DataAwsServiceUpdateActions {
    interface UpdateActionsProperty {
    }
    class UpdateActionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): UpdateActionsProperty | undefined;
        set internalValue(value: UpdateActionsProperty | undefined);
        get cacheClusterId(): string;
        get engine(): string;
        get estimatedUpdateTime(): string;
        get recommendedApplyByDate(): string;
        get releaseDate(): string;
        get replicationGroupId(): string;
        get serviceUpdateName(): string;
        get serviceUpdateSeverity(): string;
        get serviceUpdateStatus(): string;
        get serviceUpdateType(): string;
        get updateActionStatus(): string;
    }
    class UpdateActionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): UpdateActionsPropertyOutputReference;
    }
}
