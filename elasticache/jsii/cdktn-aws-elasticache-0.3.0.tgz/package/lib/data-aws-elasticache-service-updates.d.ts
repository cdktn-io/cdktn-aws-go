import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsServiceUpdatesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elasticache_service_updates#region DataAwsServiceUpdates#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elasticache_service_updates#status DataAwsServiceUpdates#status}
    */
    readonly status?: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elasticache_service_updates aws_elasticache_service_updates}
*/
export declare class DataAwsServiceUpdates extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_elasticache_service_updates";
    /**
    * Generates CDKTN code for importing a DataAwsServiceUpdates resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsServiceUpdates to import
    * @param importFromId The id of the existing DataAwsServiceUpdates that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elasticache_service_updates#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsServiceUpdates to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elasticache_service_updates aws_elasticache_service_updates} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsServiceUpdatesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsServiceUpdatesConfig);
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _serviceUpdates;
    get serviceUpdates(): DataAwsServiceUpdates.ServiceUpdatesPropertyList;
    private _status?;
    get status(): string[];
    set status(value: string[]);
    resetStatus(): void;
    get statusInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsServiceUpdatesServiceUpdatesPropertyToTerraform(struct?: DataAwsServiceUpdates.ServiceUpdatesProperty): any;
export declare function dataAwsServiceUpdatesServiceUpdatesPropertyToHclTerraform(struct?: DataAwsServiceUpdates.ServiceUpdatesProperty): any;
export declare namespace DataAwsServiceUpdates {
    interface ServiceUpdatesProperty {
    }
    class ServiceUpdatesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ServiceUpdatesProperty | undefined;
        set internalValue(value: ServiceUpdatesProperty | undefined);
        get autoUpdateAfterRecommendedApplyByDate(): cdktn.IResolvable;
        get description(): string;
        get endDate(): string;
        get engine(): string;
        get engineVersion(): string;
        get estimatedUpdateTime(): string;
        get name(): string;
        get recommendedApplyByDate(): string;
        get releaseDate(): string;
        get severity(): string;
        get status(): string;
        get type(): string;
    }
    class ServiceUpdatesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ServiceUpdatesPropertyOutputReference;
    }
}
