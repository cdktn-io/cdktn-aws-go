import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsReservedCacheNodeConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_reserved_cache_node#cache_node_count AwsReservedCacheNode#cache_node_count}
    */
    readonly cacheNodeCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_reserved_cache_node#id AwsReservedCacheNode#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_reserved_cache_node#region AwsReservedCacheNode#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_reserved_cache_node#reserved_cache_nodes_offering_id AwsReservedCacheNode#reserved_cache_nodes_offering_id}
    */
    readonly reservedCacheNodesOfferingId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_reserved_cache_node#tags AwsReservedCacheNode#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_reserved_cache_node#timeouts AwsReservedCacheNode#timeouts}
    */
    readonly timeouts?: AwsReservedCacheNode.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_reserved_cache_node aws_elasticache_reserved_cache_node}
*/
export declare class AwsReservedCacheNode extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_elasticache_reserved_cache_node";
    /**
    * Generates CDKTN code for importing a AwsReservedCacheNode resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsReservedCacheNode to import
    * @param importFromId The id of the existing AwsReservedCacheNode that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_reserved_cache_node#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsReservedCacheNode to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_reserved_cache_node aws_elasticache_reserved_cache_node} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsReservedCacheNodeConfig
    */
    constructor(scope: Construct, id: string, config: AwsReservedCacheNodeConfig);
    get arn(): string;
    private _cacheNodeCount?;
    get cacheNodeCount(): number;
    set cacheNodeCount(value: number);
    resetCacheNodeCount(): void;
    get cacheNodeCountInput(): number | undefined;
    get cacheNodeType(): string;
    get duration(): string;
    get fixedPrice(): number;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get offeringType(): string;
    get productDescription(): string;
    private _recurringCharges;
    get recurringCharges(): AwsReservedCacheNode.RecurringChargesPropertyList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _reservedCacheNodesOfferingId?;
    get reservedCacheNodesOfferingId(): string;
    set reservedCacheNodesOfferingId(value: string);
    get reservedCacheNodesOfferingIdInput(): string | undefined;
    get startTime(): string;
    get state(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    get usagePrice(): number;
    private _timeouts;
    get timeouts(): AwsReservedCacheNode.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsReservedCacheNode.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsReservedCacheNode.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsReservedCacheNodeRecurringChargesPropertyToTerraform(struct?: AwsReservedCacheNode.RecurringChargesProperty): any;
export declare function awsReservedCacheNodeRecurringChargesPropertyToHclTerraform(struct?: AwsReservedCacheNode.RecurringChargesProperty): any;
export declare function awsReservedCacheNodeTimeoutsPropertyToTerraform(struct?: AwsReservedCacheNode.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsReservedCacheNodeTimeoutsPropertyToHclTerraform(struct?: AwsReservedCacheNode.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsReservedCacheNode {
    interface RecurringChargesProperty {
    }
    class RecurringChargesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RecurringChargesProperty | undefined;
        set internalValue(value: RecurringChargesProperty | undefined);
        get recurringChargeAmount(): number;
        get recurringChargeFrequency(): string;
    }
    class RecurringChargesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RecurringChargesPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_reserved_cache_node#create AwsReservedCacheNode#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_reserved_cache_node#delete AwsReservedCacheNode#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_reserved_cache_node#update AwsReservedCacheNode#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
