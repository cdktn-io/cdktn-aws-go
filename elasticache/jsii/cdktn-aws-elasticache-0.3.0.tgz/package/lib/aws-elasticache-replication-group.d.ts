import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsReplicationGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#apply_immediately AwsReplicationGroup#apply_immediately}
    */
    readonly applyImmediately?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#at_rest_encryption_enabled AwsReplicationGroup#at_rest_encryption_enabled}
    */
    readonly atRestEncryptionEnabled?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#auth_token AwsReplicationGroup#auth_token}
    */
    readonly authToken?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#auth_token_update_strategy AwsReplicationGroup#auth_token_update_strategy}
    */
    readonly authTokenUpdateStrategy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#auth_token_wo AwsReplicationGroup#auth_token_wo}
    */
    readonly authTokenWo?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#auth_token_wo_version AwsReplicationGroup#auth_token_wo_version}
    */
    readonly authTokenWoVersion?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#auto_minor_version_upgrade AwsReplicationGroup#auto_minor_version_upgrade}
    */
    readonly autoMinorVersionUpgrade?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#automatic_failover_enabled AwsReplicationGroup#automatic_failover_enabled}
    */
    readonly automaticFailoverEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#cluster_mode AwsReplicationGroup#cluster_mode}
    */
    readonly clusterMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#data_tiering_enabled AwsReplicationGroup#data_tiering_enabled}
    */
    readonly dataTieringEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#description AwsReplicationGroup#description}
    */
    readonly description: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#durability AwsReplicationGroup#durability}
    */
    readonly durability?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#engine AwsReplicationGroup#engine}
    */
    readonly engine?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#engine_version AwsReplicationGroup#engine_version}
    */
    readonly engineVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#final_snapshot_identifier AwsReplicationGroup#final_snapshot_identifier}
    */
    readonly finalSnapshotIdentifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#global_replication_group_id AwsReplicationGroup#global_replication_group_id}
    */
    readonly globalReplicationGroupId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#id AwsReplicationGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#ip_discovery AwsReplicationGroup#ip_discovery}
    */
    readonly ipDiscovery?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#kms_key_id AwsReplicationGroup#kms_key_id}
    */
    readonly kmsKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#maintenance_window AwsReplicationGroup#maintenance_window}
    */
    readonly maintenanceWindow?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#multi_az_enabled AwsReplicationGroup#multi_az_enabled}
    */
    readonly multiAzEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#network_type AwsReplicationGroup#network_type}
    */
    readonly networkType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#node_type AwsReplicationGroup#node_type}
    */
    readonly nodeType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#notification_topic_arn AwsReplicationGroup#notification_topic_arn}
    */
    readonly notificationTopicArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#num_cache_clusters AwsReplicationGroup#num_cache_clusters}
    */
    readonly numCacheClusters?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#num_node_groups AwsReplicationGroup#num_node_groups}
    */
    readonly numNodeGroups?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#parameter_group_name AwsReplicationGroup#parameter_group_name}
    */
    readonly parameterGroupName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#port AwsReplicationGroup#port}
    */
    readonly port?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#preferred_cache_cluster_azs AwsReplicationGroup#preferred_cache_cluster_azs}
    */
    readonly preferredCacheClusterAzs?: string[];
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#region AwsReplicationGroup#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#replicas_per_node_group AwsReplicationGroup#replicas_per_node_group}
    */
    readonly replicasPerNodeGroup?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#replication_group_id AwsReplicationGroup#replication_group_id}
    */
    readonly replicationGroupId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#security_group_ids AwsReplicationGroup#security_group_ids}
    */
    readonly securityGroupIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#security_group_names AwsReplicationGroup#security_group_names}
    */
    readonly securityGroupNames?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#snapshot_arns AwsReplicationGroup#snapshot_arns}
    */
    readonly snapshotArns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#snapshot_name AwsReplicationGroup#snapshot_name}
    */
    readonly snapshotName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#snapshot_retention_limit AwsReplicationGroup#snapshot_retention_limit}
    */
    readonly snapshotRetentionLimit?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#snapshot_window AwsReplicationGroup#snapshot_window}
    */
    readonly snapshotWindow?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#subnet_group_name AwsReplicationGroup#subnet_group_name}
    */
    readonly subnetGroupName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#tags AwsReplicationGroup#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#tags_all AwsReplicationGroup#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#transit_encryption_enabled AwsReplicationGroup#transit_encryption_enabled}
    */
    readonly transitEncryptionEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#transit_encryption_mode AwsReplicationGroup#transit_encryption_mode}
    */
    readonly transitEncryptionMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#user_group_ids AwsReplicationGroup#user_group_ids}
    */
    readonly userGroupIds?: string[];
    /**
    * log_delivery_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#log_delivery_configuration AwsReplicationGroup#log_delivery_configuration}
    */
    readonly logDeliveryConfiguration?: AwsReplicationGroup.LogDeliveryConfigurationProperty[] | cdktn.IResolvable;
    /**
    * node_group_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#node_group_configuration AwsReplicationGroup#node_group_configuration}
    */
    readonly nodeGroupConfiguration?: AwsReplicationGroup.NodeGroupConfigurationProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#timeouts AwsReplicationGroup#timeouts}
    */
    readonly timeouts?: AwsReplicationGroup.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group aws_elasticache_replication_group}
*/
export declare class AwsReplicationGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_elasticache_replication_group";
    /**
    * Generates CDKTN code for importing a AwsReplicationGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsReplicationGroup to import
    * @param importFromId The id of the existing AwsReplicationGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsReplicationGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group aws_elasticache_replication_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsReplicationGroupConfig
    */
    constructor(scope: Construct, id: string, config: AwsReplicationGroupConfig);
    private _applyImmediately?;
    get applyImmediately(): boolean | cdktn.IResolvable;
    set applyImmediately(value: boolean | cdktn.IResolvable);
    resetApplyImmediately(): void;
    get applyImmediatelyInput(): boolean | cdktn.IResolvable | undefined;
    get arn(): string;
    private _atRestEncryptionEnabled?;
    get atRestEncryptionEnabled(): string;
    set atRestEncryptionEnabled(value: string);
    resetAtRestEncryptionEnabled(): void;
    get atRestEncryptionEnabledInput(): string | undefined;
    private _authToken?;
    get authToken(): string;
    set authToken(value: string);
    resetAuthToken(): void;
    get authTokenInput(): string | undefined;
    private _authTokenUpdateStrategy?;
    get authTokenUpdateStrategy(): string;
    set authTokenUpdateStrategy(value: string);
    resetAuthTokenUpdateStrategy(): void;
    get authTokenUpdateStrategyInput(): string | undefined;
    private _authTokenWo?;
    /**
    * @deprecated Write-only: the provider never returns this value; reading it always yields null by protocol contract. The getter remains for compatibility and will be removed in a future prebuilt-provider major.
    */
    get authTokenWo(): string;
    set authTokenWo(value: string);
    resetAuthTokenWo(): void;
    get authTokenWoInput(): string | undefined;
    private _authTokenWoVersion?;
    get authTokenWoVersion(): number;
    set authTokenWoVersion(value: number);
    resetAuthTokenWoVersion(): void;
    get authTokenWoVersionInput(): number | undefined;
    private _autoMinorVersionUpgrade?;
    get autoMinorVersionUpgrade(): string;
    set autoMinorVersionUpgrade(value: string);
    resetAutoMinorVersionUpgrade(): void;
    get autoMinorVersionUpgradeInput(): string | undefined;
    private _automaticFailoverEnabled?;
    get automaticFailoverEnabled(): boolean | cdktn.IResolvable;
    set automaticFailoverEnabled(value: boolean | cdktn.IResolvable);
    resetAutomaticFailoverEnabled(): void;
    get automaticFailoverEnabledInput(): boolean | cdktn.IResolvable | undefined;
    get clusterEnabled(): cdktn.IResolvable;
    private _clusterMode?;
    get clusterMode(): string;
    set clusterMode(value: string);
    resetClusterMode(): void;
    get clusterModeInput(): string | undefined;
    get configurationEndpointAddress(): string;
    private _dataTieringEnabled?;
    get dataTieringEnabled(): boolean | cdktn.IResolvable;
    set dataTieringEnabled(value: boolean | cdktn.IResolvable);
    resetDataTieringEnabled(): void;
    get dataTieringEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    private _durability?;
    get durability(): string;
    set durability(value: string);
    resetDurability(): void;
    get durabilityInput(): string | undefined;
    private _engine?;
    get engine(): string;
    set engine(value: string);
    resetEngine(): void;
    get engineInput(): string | undefined;
    private _engineVersion?;
    get engineVersion(): string;
    set engineVersion(value: string);
    resetEngineVersion(): void;
    get engineVersionInput(): string | undefined;
    get engineVersionActual(): string;
    private _finalSnapshotIdentifier?;
    get finalSnapshotIdentifier(): string;
    set finalSnapshotIdentifier(value: string);
    resetFinalSnapshotIdentifier(): void;
    get finalSnapshotIdentifierInput(): string | undefined;
    private _globalReplicationGroupId?;
    get globalReplicationGroupId(): string;
    set globalReplicationGroupId(value: string);
    resetGlobalReplicationGroupId(): void;
    get globalReplicationGroupIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ipDiscovery?;
    get ipDiscovery(): string;
    set ipDiscovery(value: string);
    resetIpDiscovery(): void;
    get ipDiscoveryInput(): string | undefined;
    private _kmsKeyId?;
    get kmsKeyId(): string;
    set kmsKeyId(value: string);
    resetKmsKeyId(): void;
    get kmsKeyIdInput(): string | undefined;
    private _maintenanceWindow?;
    get maintenanceWindow(): string;
    set maintenanceWindow(value: string);
    resetMaintenanceWindow(): void;
    get maintenanceWindowInput(): string | undefined;
    get memberClusters(): string[];
    private _multiAzEnabled?;
    get multiAzEnabled(): boolean | cdktn.IResolvable;
    set multiAzEnabled(value: boolean | cdktn.IResolvable);
    resetMultiAzEnabled(): void;
    get multiAzEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _networkType?;
    get networkType(): string;
    set networkType(value: string);
    resetNetworkType(): void;
    get networkTypeInput(): string | undefined;
    private _nodeType?;
    get nodeType(): string;
    set nodeType(value: string);
    resetNodeType(): void;
    get nodeTypeInput(): string | undefined;
    private _notificationTopicArn?;
    get notificationTopicArn(): string;
    set notificationTopicArn(value: string);
    resetNotificationTopicArn(): void;
    get notificationTopicArnInput(): string | undefined;
    private _numCacheClusters?;
    get numCacheClusters(): number;
    set numCacheClusters(value: number);
    resetNumCacheClusters(): void;
    get numCacheClustersInput(): number | undefined;
    private _numNodeGroups?;
    get numNodeGroups(): number;
    set numNodeGroups(value: number);
    resetNumNodeGroups(): void;
    get numNodeGroupsInput(): number | undefined;
    private _parameterGroupName?;
    get parameterGroupName(): string;
    set parameterGroupName(value: string);
    resetParameterGroupName(): void;
    get parameterGroupNameInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
    private _preferredCacheClusterAzs?;
    get preferredCacheClusterAzs(): string[];
    set preferredCacheClusterAzs(value: string[]);
    resetPreferredCacheClusterAzs(): void;
    get preferredCacheClusterAzsInput(): string[] | undefined;
    get primaryEndpointAddress(): string;
    get readerEndpointAddress(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _replicasPerNodeGroup?;
    get replicasPerNodeGroup(): number;
    set replicasPerNodeGroup(value: number);
    resetReplicasPerNodeGroup(): void;
    get replicasPerNodeGroupInput(): number | undefined;
    private _replicationGroupId?;
    get replicationGroupId(): string;
    set replicationGroupId(value: string);
    get replicationGroupIdInput(): string | undefined;
    private _securityGroupIds?;
    get securityGroupIds(): string[];
    set securityGroupIds(value: string[]);
    resetSecurityGroupIds(): void;
    get securityGroupIdsInput(): string[] | undefined;
    private _securityGroupNames?;
    get securityGroupNames(): string[];
    set securityGroupNames(value: string[]);
    resetSecurityGroupNames(): void;
    get securityGroupNamesInput(): string[] | undefined;
    private _snapshotArns?;
    get snapshotArns(): string[];
    set snapshotArns(value: string[]);
    resetSnapshotArns(): void;
    get snapshotArnsInput(): string[] | undefined;
    private _snapshotName?;
    get snapshotName(): string;
    set snapshotName(value: string);
    resetSnapshotName(): void;
    get snapshotNameInput(): string | undefined;
    private _snapshotRetentionLimit?;
    get snapshotRetentionLimit(): number;
    set snapshotRetentionLimit(value: number);
    resetSnapshotRetentionLimit(): void;
    get snapshotRetentionLimitInput(): number | undefined;
    private _snapshotWindow?;
    get snapshotWindow(): string;
    set snapshotWindow(value: string);
    resetSnapshotWindow(): void;
    get snapshotWindowInput(): string | undefined;
    private _subnetGroupName?;
    get subnetGroupName(): string;
    set subnetGroupName(value: string);
    resetSubnetGroupName(): void;
    get subnetGroupNameInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _transitEncryptionEnabled?;
    get transitEncryptionEnabled(): boolean | cdktn.IResolvable;
    set transitEncryptionEnabled(value: boolean | cdktn.IResolvable);
    resetTransitEncryptionEnabled(): void;
    get transitEncryptionEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _transitEncryptionMode?;
    get transitEncryptionMode(): string;
    set transitEncryptionMode(value: string);
    resetTransitEncryptionMode(): void;
    get transitEncryptionModeInput(): string | undefined;
    private _userGroupIds?;
    get userGroupIds(): string[];
    set userGroupIds(value: string[]);
    resetUserGroupIds(): void;
    get userGroupIdsInput(): string[] | undefined;
    private _logDeliveryConfiguration;
    get logDeliveryConfiguration(): AwsReplicationGroup.LogDeliveryConfigurationPropertyList;
    putLogDeliveryConfiguration(value: AwsReplicationGroup.LogDeliveryConfigurationProperty[] | cdktn.IResolvable): void;
    resetLogDeliveryConfiguration(): void;
    get logDeliveryConfigurationInput(): cdktn.IResolvable | AwsReplicationGroup.LogDeliveryConfigurationProperty[] | undefined;
    private _nodeGroupConfiguration;
    get nodeGroupConfiguration(): AwsReplicationGroup.NodeGroupConfigurationPropertyList;
    putNodeGroupConfiguration(value: AwsReplicationGroup.NodeGroupConfigurationProperty[] | cdktn.IResolvable): void;
    resetNodeGroupConfiguration(): void;
    get nodeGroupConfigurationInput(): cdktn.IResolvable | AwsReplicationGroup.NodeGroupConfigurationProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsReplicationGroup.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsReplicationGroup.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsReplicationGroup.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsReplicationGroupLogDeliveryConfigurationPropertyToTerraform(struct?: AwsReplicationGroup.LogDeliveryConfigurationProperty | cdktn.IResolvable): any;
export declare function awsReplicationGroupLogDeliveryConfigurationPropertyToHclTerraform(struct?: AwsReplicationGroup.LogDeliveryConfigurationProperty | cdktn.IResolvable): any;
export declare function awsReplicationGroupNodeGroupConfigurationPropertyToTerraform(struct?: AwsReplicationGroup.NodeGroupConfigurationProperty | cdktn.IResolvable): any;
export declare function awsReplicationGroupNodeGroupConfigurationPropertyToHclTerraform(struct?: AwsReplicationGroup.NodeGroupConfigurationProperty | cdktn.IResolvable): any;
export declare function awsReplicationGroupTimeoutsPropertyToTerraform(struct?: AwsReplicationGroup.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsReplicationGroupTimeoutsPropertyToHclTerraform(struct?: AwsReplicationGroup.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsReplicationGroup {
    interface LogDeliveryConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#destination AwsReplicationGroup#destination}
        */
        readonly destination: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#destination_type AwsReplicationGroup#destination_type}
        */
        readonly destinationType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#log_format AwsReplicationGroup#log_format}
        */
        readonly logFormat: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#log_type AwsReplicationGroup#log_type}
        */
        readonly logType: string;
    }
    class LogDeliveryConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LogDeliveryConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LogDeliveryConfigurationProperty | cdktn.IResolvable | undefined);
        private _destination?;
        get destination(): string;
        set destination(value: string);
        get destinationInput(): string | undefined;
        private _destinationType?;
        get destinationType(): string;
        set destinationType(value: string);
        get destinationTypeInput(): string | undefined;
        private _logFormat?;
        get logFormat(): string;
        set logFormat(value: string);
        get logFormatInput(): string | undefined;
        private _logType?;
        get logType(): string;
        set logType(value: string);
        get logTypeInput(): string | undefined;
    }
    class LogDeliveryConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: LogDeliveryConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LogDeliveryConfigurationPropertyOutputReference;
    }
    interface NodeGroupConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#node_group_id AwsReplicationGroup#node_group_id}
        */
        readonly nodeGroupId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#primary_availability_zone AwsReplicationGroup#primary_availability_zone}
        */
        readonly primaryAvailabilityZone?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#primary_outpost_arn AwsReplicationGroup#primary_outpost_arn}
        */
        readonly primaryOutpostArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#replica_availability_zones AwsReplicationGroup#replica_availability_zones}
        */
        readonly replicaAvailabilityZones?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#replica_count AwsReplicationGroup#replica_count}
        */
        readonly replicaCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#replica_outpost_arns AwsReplicationGroup#replica_outpost_arns}
        */
        readonly replicaOutpostArns?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#slots AwsReplicationGroup#slots}
        */
        readonly slots?: string;
    }
    class NodeGroupConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NodeGroupConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NodeGroupConfigurationProperty | cdktn.IResolvable | undefined);
        private _nodeGroupId?;
        get nodeGroupId(): string;
        set nodeGroupId(value: string);
        resetNodeGroupId(): void;
        get nodeGroupIdInput(): string | undefined;
        private _primaryAvailabilityZone?;
        get primaryAvailabilityZone(): string;
        set primaryAvailabilityZone(value: string);
        resetPrimaryAvailabilityZone(): void;
        get primaryAvailabilityZoneInput(): string | undefined;
        private _primaryOutpostArn?;
        get primaryOutpostArn(): string;
        set primaryOutpostArn(value: string);
        resetPrimaryOutpostArn(): void;
        get primaryOutpostArnInput(): string | undefined;
        private _replicaAvailabilityZones?;
        get replicaAvailabilityZones(): string[];
        set replicaAvailabilityZones(value: string[]);
        resetReplicaAvailabilityZones(): void;
        get replicaAvailabilityZonesInput(): string[] | undefined;
        private _replicaCount?;
        get replicaCount(): number;
        set replicaCount(value: number);
        resetReplicaCount(): void;
        get replicaCountInput(): number | undefined;
        private _replicaOutpostArns?;
        get replicaOutpostArns(): string[];
        set replicaOutpostArns(value: string[]);
        resetReplicaOutpostArns(): void;
        get replicaOutpostArnsInput(): string[] | undefined;
        private _slots?;
        get slots(): string;
        set slots(value: string);
        resetSlots(): void;
        get slotsInput(): string | undefined;
    }
    class NodeGroupConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: NodeGroupConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NodeGroupConfigurationPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#create AwsReplicationGroup#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#delete AwsReplicationGroup#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_replication_group#update AwsReplicationGroup#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
