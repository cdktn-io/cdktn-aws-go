import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfSavingsPlanConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the Savings Plan.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/savingsplans_savings_plan#savings_plan_id DataTfSavingsPlan#savings_plan_id}
    */
    readonly savingsPlanId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/savingsplans_savings_plan aws_savingsplans_savings_plan}
*/
export declare class DataTfSavingsPlan extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_savingsplans_savings_plan";
    /**
    * Generates CDKTN code for importing a DataTfSavingsPlan resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfSavingsPlan to import
    * @param importFromId The id of the existing DataTfSavingsPlan that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/savingsplans_savings_plan#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfSavingsPlan to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/savingsplans_savings_plan aws_savingsplans_savings_plan} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfSavingsPlanConfig
    */
    constructor(scope: Construct, id: string, config: DataTfSavingsPlanConfig);
    get commitment(): string;
    get currency(): string;
    get description(): string;
    get ec2InstanceFamily(): string;
    get end(): string;
    get offeringId(): string;
    get paymentOption(): string;
    get productTypes(): string[];
    get purchaseTime(): string;
    get recurringPaymentAmount(): string;
    get region(): string;
    get returnableUntil(): string;
    get savingsPlanArn(): string;
    private _savingsPlanId?;
    get savingsPlanId(): string;
    set savingsPlanId(value: string);
    get savingsPlanIdInput(): string | undefined;
    get savingsPlanOfferingId(): string;
    get savingsPlanType(): string;
    get start(): string;
    get state(): string;
    private _tags;
    get tags(): cdktn.StringMap;
    get termDurationInSeconds(): number;
    get upfrontPaymentAmount(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
