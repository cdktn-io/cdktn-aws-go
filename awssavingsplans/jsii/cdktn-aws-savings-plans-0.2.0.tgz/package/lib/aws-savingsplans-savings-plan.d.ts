import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfSavingsPlanConfig extends cdktn.TerraformMetaArguments {
    /**
    * The hourly commitment, in USD.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/savingsplans_savings_plan#commitment TfSavingsPlan#commitment}
    */
    readonly commitment: string;
    /**
    * The time at which to purchase the Savings Plan, in UTC format (YYYY-MM-DDTHH:MM:SSZ).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/savingsplans_savings_plan#purchase_time TfSavingsPlan#purchase_time}
    */
    readonly purchaseTime?: string;
    /**
    * The unique ID of a Savings Plan offering.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/savingsplans_savings_plan#savings_plan_offering_id TfSavingsPlan#savings_plan_offering_id}
    */
    readonly savingsPlanOfferingId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/savingsplans_savings_plan#tags TfSavingsPlan#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * The up-front payment amount.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/savingsplans_savings_plan#upfront_payment_amount TfSavingsPlan#upfront_payment_amount}
    */
    readonly upfrontPaymentAmount?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/savingsplans_savings_plan#timeouts TfSavingsPlan#timeouts}
    */
    readonly timeouts?: TfSavingsPlan.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/savingsplans_savings_plan aws_savingsplans_savings_plan}
*/
export declare class TfSavingsPlan extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_savingsplans_savings_plan";
    /**
    * Generates CDKTN code for importing a TfSavingsPlan resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfSavingsPlan to import
    * @param importFromId The id of the existing TfSavingsPlan that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/savingsplans_savings_plan#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfSavingsPlan to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/savingsplans_savings_plan aws_savingsplans_savings_plan} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfSavingsPlanConfig
    */
    constructor(scope: Construct, id: string, config: TfSavingsPlanConfig);
    private _commitment?;
    get commitment(): string;
    set commitment(value: string);
    get commitmentInput(): string | undefined;
    get currency(): string;
    get description(): string;
    get ec2InstanceFamily(): string;
    get end(): string;
    get offeringId(): string;
    get paymentOption(): string;
    get productTypes(): string[];
    private _purchaseTime?;
    get purchaseTime(): string;
    set purchaseTime(value: string);
    resetPurchaseTime(): void;
    get purchaseTimeInput(): string | undefined;
    get recurringPaymentAmount(): string;
    get region(): string;
    get returnableUntil(): string;
    get savingsPlanArn(): string;
    get savingsPlanId(): string;
    private _savingsPlanOfferingId?;
    get savingsPlanOfferingId(): string;
    set savingsPlanOfferingId(value: string);
    get savingsPlanOfferingIdInput(): string | undefined;
    get savingsPlanType(): string;
    get start(): string;
    get state(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    get termDurationInSeconds(): number;
    private _upfrontPaymentAmount?;
    get upfrontPaymentAmount(): string;
    set upfrontPaymentAmount(value: string);
    resetUpfrontPaymentAmount(): void;
    get upfrontPaymentAmountInput(): string | undefined;
    private _timeouts;
    get timeouts(): TfSavingsPlan.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfSavingsPlan.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): TfSavingsPlan.TimeoutsProperty | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfSavingsPlanTimeoutsPropertyToTerraform(struct?: TfSavingsPlan.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfSavingsPlanTimeoutsPropertyToHclTerraform(struct?: TfSavingsPlan.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfSavingsPlan {
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/savingsplans_savings_plan#create TfSavingsPlan#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/savingsplans_savings_plan#delete TfSavingsPlan#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
