import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAuditmanagerAssessmentDelegationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_assessment_delegation#assessment_id AwsAuditmanagerAssessmentDelegation#assessment_id}
    */
    readonly assessmentId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_assessment_delegation#comment AwsAuditmanagerAssessmentDelegation#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_assessment_delegation#control_set_id AwsAuditmanagerAssessmentDelegation#control_set_id}
    */
    readonly controlSetId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_assessment_delegation#region AwsAuditmanagerAssessmentDelegation#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_assessment_delegation#role_arn AwsAuditmanagerAssessmentDelegation#role_arn}
    */
    readonly roleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_assessment_delegation#role_type AwsAuditmanagerAssessmentDelegation#role_type}
    */
    readonly roleType: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_assessment_delegation aws_auditmanager_assessment_delegation}
*/
export declare class AwsAuditmanagerAssessmentDelegation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_auditmanager_assessment_delegation";
    /**
    * Generates CDKTN code for importing a AwsAuditmanagerAssessmentDelegation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsAuditmanagerAssessmentDelegation to import
    * @param importFromId The id of the existing AwsAuditmanagerAssessmentDelegation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_assessment_delegation#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsAuditmanagerAssessmentDelegation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_assessment_delegation aws_auditmanager_assessment_delegation} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAuditmanagerAssessmentDelegationConfig
    */
    constructor(scope: Construct, id: string, config: AwsAuditmanagerAssessmentDelegationConfig);
    private _assessmentId?;
    get assessmentId(): string;
    set assessmentId(value: string);
    get assessmentIdInput(): string | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _controlSetId?;
    get controlSetId(): string;
    set controlSetId(value: string);
    get controlSetIdInput(): string | undefined;
    get delegationId(): string;
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    private _roleType?;
    get roleType(): string;
    set roleType(value: string);
    get roleTypeInput(): string | undefined;
    get status(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
