import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAuditmanagerAssessmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_assessment#description AwsAuditmanagerAssessment#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_assessment#framework_id AwsAuditmanagerAssessment#framework_id}
    */
    readonly frameworkId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_assessment#name AwsAuditmanagerAssessment#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_assessment#region AwsAuditmanagerAssessment#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_assessment#tags AwsAuditmanagerAssessment#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * assessment_reports_destination block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_assessment#assessment_reports_destination AwsAuditmanagerAssessment#assessment_reports_destination}
    */
    readonly assessmentReportsDestination?: AwsAuditmanagerAssessment.AssessmentReportsDestinationProperty[] | cdktn.IResolvable;
    /**
    * roles block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_assessment#roles AwsAuditmanagerAssessment#roles}
    */
    readonly roles?: AwsAuditmanagerAssessment.RolesProperty[] | cdktn.IResolvable;
    /**
    * scope block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_assessment#scope AwsAuditmanagerAssessment#scope}
    */
    readonly scope?: AwsAuditmanagerAssessment.ScopeProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_assessment aws_auditmanager_assessment}
*/
export declare class AwsAuditmanagerAssessment extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_auditmanager_assessment";
    /**
    * Generates CDKTN code for importing a AwsAuditmanagerAssessment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsAuditmanagerAssessment to import
    * @param importFromId The id of the existing AwsAuditmanagerAssessment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_assessment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsAuditmanagerAssessment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_assessment aws_auditmanager_assessment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAuditmanagerAssessmentConfig
    */
    constructor(scope: Construct, id: string, config: AwsAuditmanagerAssessmentConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _frameworkId?;
    get frameworkId(): string;
    set frameworkId(value: string);
    get frameworkIdInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _rolesAll;
    get rolesAll(): AwsAuditmanagerAssessment.RolesAllPropertyList;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _assessmentReportsDestination;
    get assessmentReportsDestination(): AwsAuditmanagerAssessment.AssessmentReportsDestinationPropertyList;
    putAssessmentReportsDestination(value: AwsAuditmanagerAssessment.AssessmentReportsDestinationProperty[] | cdktn.IResolvable): void;
    resetAssessmentReportsDestination(): void;
    get assessmentReportsDestinationInput(): cdktn.IResolvable | AwsAuditmanagerAssessment.AssessmentReportsDestinationProperty[] | undefined;
    private _roles;
    get roles(): AwsAuditmanagerAssessment.RolesPropertyList;
    putRoles(value: AwsAuditmanagerAssessment.RolesProperty[] | cdktn.IResolvable): void;
    resetRoles(): void;
    get rolesInput(): cdktn.IResolvable | AwsAuditmanagerAssessment.RolesProperty[] | undefined;
    private _scope;
    get scope(): AwsAuditmanagerAssessment.ScopePropertyList;
    putScope(value: AwsAuditmanagerAssessment.ScopeProperty[] | cdktn.IResolvable): void;
    resetScope(): void;
    get scopeInput(): cdktn.IResolvable | AwsAuditmanagerAssessment.ScopeProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsAuditmanagerAssessmentRolesAllPropertyToTerraform(struct?: AwsAuditmanagerAssessment.RolesAllProperty): any;
export declare function awsAuditmanagerAssessmentRolesAllPropertyToHclTerraform(struct?: AwsAuditmanagerAssessment.RolesAllProperty): any;
export declare function awsAuditmanagerAssessmentAssessmentReportsDestinationPropertyToTerraform(struct?: AwsAuditmanagerAssessment.AssessmentReportsDestinationProperty | cdktn.IResolvable): any;
export declare function awsAuditmanagerAssessmentAssessmentReportsDestinationPropertyToHclTerraform(struct?: AwsAuditmanagerAssessment.AssessmentReportsDestinationProperty | cdktn.IResolvable): any;
export declare function awsAuditmanagerAssessmentRolesPropertyToTerraform(struct?: AwsAuditmanagerAssessment.RolesProperty | cdktn.IResolvable): any;
export declare function awsAuditmanagerAssessmentRolesPropertyToHclTerraform(struct?: AwsAuditmanagerAssessment.RolesProperty | cdktn.IResolvable): any;
export declare function awsAuditmanagerAssessmentAwsAccountsPropertyToTerraform(struct?: AwsAuditmanagerAssessment.AwsAccountsProperty | cdktn.IResolvable): any;
export declare function awsAuditmanagerAssessmentAwsAccountsPropertyToHclTerraform(struct?: AwsAuditmanagerAssessment.AwsAccountsProperty | cdktn.IResolvable): any;
export declare function awsAuditmanagerAssessmentAwsServicesPropertyToTerraform(struct?: AwsAuditmanagerAssessment.AwsServicesProperty | cdktn.IResolvable): any;
export declare function awsAuditmanagerAssessmentAwsServicesPropertyToHclTerraform(struct?: AwsAuditmanagerAssessment.AwsServicesProperty | cdktn.IResolvable): any;
export declare function awsAuditmanagerAssessmentScopePropertyToTerraform(struct?: AwsAuditmanagerAssessment.ScopeProperty | cdktn.IResolvable): any;
export declare function awsAuditmanagerAssessmentScopePropertyToHclTerraform(struct?: AwsAuditmanagerAssessment.ScopeProperty | cdktn.IResolvable): any;
export declare namespace AwsAuditmanagerAssessment {
    interface RolesAllProperty {
    }
    class RolesAllPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RolesAllProperty | undefined;
        set internalValue(value: RolesAllProperty | undefined);
        get roleArn(): string;
        get roleType(): string;
    }
    class RolesAllPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RolesAllPropertyOutputReference;
    }
    interface AssessmentReportsDestinationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_assessment#destination AwsAuditmanagerAssessment#destination}
        */
        readonly destination: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_assessment#destination_type AwsAuditmanagerAssessment#destination_type}
        */
        readonly destinationType: string;
    }
    class AssessmentReportsDestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AssessmentReportsDestinationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AssessmentReportsDestinationProperty | cdktn.IResolvable | undefined);
        private _destination?;
        get destination(): string;
        set destination(value: string);
        get destinationInput(): string | undefined;
        private _destinationType?;
        get destinationType(): string;
        set destinationType(value: string);
        get destinationTypeInput(): string | undefined;
    }
    class AssessmentReportsDestinationPropertyList extends cdktn.ComplexList {
        internalValue?: AssessmentReportsDestinationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AssessmentReportsDestinationPropertyOutputReference;
    }
    interface RolesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_assessment#role_arn AwsAuditmanagerAssessment#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_assessment#role_type AwsAuditmanagerAssessment#role_type}
        */
        readonly roleType: string;
    }
    class RolesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RolesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RolesProperty | cdktn.IResolvable | undefined);
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _roleType?;
        get roleType(): string;
        set roleType(value: string);
        get roleTypeInput(): string | undefined;
    }
    class RolesPropertyList extends cdktn.ComplexList {
        internalValue?: RolesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RolesPropertyOutputReference;
    }
    interface AwsAccountsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_assessment#id AwsAuditmanagerAssessment#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id: string;
    }
    class AwsAccountsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AwsAccountsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AwsAccountsProperty | cdktn.IResolvable | undefined);
        private _id?;
        get id(): string;
        set id(value: string);
        get idInput(): string | undefined;
    }
    class AwsAccountsPropertyList extends cdktn.ComplexList {
        internalValue?: AwsAccountsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AwsAccountsPropertyOutputReference;
    }
    interface AwsServicesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_assessment#service_name AwsAuditmanagerAssessment#service_name}
        */
        readonly serviceName: string;
    }
    class AwsServicesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AwsServicesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AwsServicesProperty | cdktn.IResolvable | undefined);
        private _serviceName?;
        get serviceName(): string;
        set serviceName(value: string);
        get serviceNameInput(): string | undefined;
    }
    class AwsServicesPropertyList extends cdktn.ComplexList {
        internalValue?: AwsServicesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AwsServicesPropertyOutputReference;
    }
    interface ScopeProperty {
        /**
        * aws_accounts block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_assessment#aws_accounts AwsAuditmanagerAssessment#aws_accounts}
        */
        readonly awsAccounts?: AwsAccountsProperty[] | cdktn.IResolvable;
        /**
        * aws_services block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_assessment#aws_services AwsAuditmanagerAssessment#aws_services}
        */
        readonly awsServices?: AwsServicesProperty[] | cdktn.IResolvable;
    }
    class ScopePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ScopeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ScopeProperty | cdktn.IResolvable | undefined);
        private _awsAccounts;
        get awsAccounts(): AwsAccountsPropertyList;
        putAwsAccounts(value: AwsAccountsProperty[] | cdktn.IResolvable): void;
        resetAwsAccounts(): void;
        get awsAccountsInput(): cdktn.IResolvable | AwsAccountsProperty[] | undefined;
        private _awsServices;
        get awsServices(): AwsServicesPropertyList;
        putAwsServices(value: AwsServicesProperty[] | cdktn.IResolvable): void;
        resetAwsServices(): void;
        get awsServicesInput(): cdktn.IResolvable | AwsServicesProperty[] | undefined;
    }
    class ScopePropertyList extends cdktn.ComplexList {
        internalValue?: ScopeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ScopePropertyOutputReference;
    }
}
