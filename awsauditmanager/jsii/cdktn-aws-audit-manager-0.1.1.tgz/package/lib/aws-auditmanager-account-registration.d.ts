import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAuditmanagerAccountRegistrationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_account_registration#delegated_admin_account AwsAuditmanagerAccountRegistration#delegated_admin_account}
    */
    readonly delegatedAdminAccount?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_account_registration#deregister_on_destroy AwsAuditmanagerAccountRegistration#deregister_on_destroy}
    */
    readonly deregisterOnDestroy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_account_registration#kms_key AwsAuditmanagerAccountRegistration#kms_key}
    */
    readonly kmsKey?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_account_registration#region AwsAuditmanagerAccountRegistration#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_account_registration aws_auditmanager_account_registration}
*/
export declare class AwsAuditmanagerAccountRegistration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_auditmanager_account_registration";
    /**
    * Generates CDKTN code for importing a AwsAuditmanagerAccountRegistration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsAuditmanagerAccountRegistration to import
    * @param importFromId The id of the existing AwsAuditmanagerAccountRegistration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_account_registration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsAuditmanagerAccountRegistration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_account_registration aws_auditmanager_account_registration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAuditmanagerAccountRegistrationConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AwsAuditmanagerAccountRegistrationConfig);
    private _delegatedAdminAccount?;
    get delegatedAdminAccount(): string;
    set delegatedAdminAccount(value: string);
    resetDelegatedAdminAccount(): void;
    get delegatedAdminAccountInput(): string | undefined;
    private _deregisterOnDestroy?;
    get deregisterOnDestroy(): boolean | cdktn.IResolvable;
    set deregisterOnDestroy(value: boolean | cdktn.IResolvable);
    resetDeregisterOnDestroy(): void;
    get deregisterOnDestroyInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    private _kmsKey?;
    get kmsKey(): string;
    set kmsKey(value: string);
    resetKmsKey(): void;
    get kmsKeyInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
