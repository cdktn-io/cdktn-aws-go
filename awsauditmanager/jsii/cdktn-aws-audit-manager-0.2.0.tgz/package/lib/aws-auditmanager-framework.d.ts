import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfFrameworkConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_framework#compliance_type TfFramework#compliance_type}
    */
    readonly complianceType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_framework#description TfFramework#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_framework#name TfFramework#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_framework#region TfFramework#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_framework#tags TfFramework#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * control_sets block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_framework#control_sets TfFramework#control_sets}
    */
    readonly controlSets?: TfFramework.ControlSetsProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_framework aws_auditmanager_framework}
*/
export declare class TfFramework extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_auditmanager_framework";
    /**
    * Generates CDKTN code for importing a TfFramework resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfFramework to import
    * @param importFromId The id of the existing TfFramework that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_framework#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfFramework to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_framework aws_auditmanager_framework} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfFrameworkConfig
    */
    constructor(scope: Construct, id: string, config: TfFrameworkConfig);
    get arn(): string;
    private _complianceType?;
    get complianceType(): string;
    set complianceType(value: string);
    resetComplianceType(): void;
    get complianceTypeInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get frameworkType(): string;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _controlSets;
    get controlSets(): TfFramework.ControlSetsPropertyList;
    putControlSets(value: TfFramework.ControlSetsProperty[] | cdktn.IResolvable): void;
    resetControlSets(): void;
    get controlSetsInput(): cdktn.IResolvable | TfFramework.ControlSetsProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfFrameworkControlsPropertyToTerraform(struct?: TfFramework.ControlsProperty | cdktn.IResolvable): any;
export declare function tfFrameworkControlsPropertyToHclTerraform(struct?: TfFramework.ControlsProperty | cdktn.IResolvable): any;
export declare function tfFrameworkControlSetsPropertyToTerraform(struct?: TfFramework.ControlSetsProperty | cdktn.IResolvable): any;
export declare function tfFrameworkControlSetsPropertyToHclTerraform(struct?: TfFramework.ControlSetsProperty | cdktn.IResolvable): any;
export declare namespace TfFramework {
    interface ControlsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_framework#id TfFramework#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id: string;
    }
    class ControlsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ControlsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ControlsProperty | cdktn.IResolvable | undefined);
        private _id?;
        get id(): string;
        set id(value: string);
        get idInput(): string | undefined;
    }
    class ControlsPropertyList extends cdktn.ComplexList {
        internalValue?: ControlsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ControlsPropertyOutputReference;
    }
    interface ControlSetsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_framework#name TfFramework#name}
        */
        readonly name: string;
        /**
        * controls block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_framework#controls TfFramework#controls}
        */
        readonly controls?: ControlsProperty[] | cdktn.IResolvable;
    }
    class ControlSetsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ControlSetsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ControlSetsProperty | cdktn.IResolvable | undefined);
        get id(): string;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _controls;
        get controls(): ControlsPropertyList;
        putControls(value: ControlsProperty[] | cdktn.IResolvable): void;
        resetControls(): void;
        get controlsInput(): cdktn.IResolvable | ControlsProperty[] | undefined;
    }
    class ControlSetsPropertyList extends cdktn.ComplexList {
        internalValue?: ControlSetsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ControlSetsPropertyOutputReference;
    }
}
