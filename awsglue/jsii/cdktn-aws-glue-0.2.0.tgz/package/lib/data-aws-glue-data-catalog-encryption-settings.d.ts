import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfDataCatalogEncryptionSettingsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/glue_data_catalog_encryption_settings#catalog_id DataTfDataCatalogEncryptionSettings#catalog_id}
    */
    readonly catalogId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/glue_data_catalog_encryption_settings#id DataTfDataCatalogEncryptionSettings#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/glue_data_catalog_encryption_settings#region DataTfDataCatalogEncryptionSettings#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/glue_data_catalog_encryption_settings aws_glue_data_catalog_encryption_settings}
*/
export declare class DataTfDataCatalogEncryptionSettings extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_glue_data_catalog_encryption_settings";
    /**
    * Generates CDKTN code for importing a DataTfDataCatalogEncryptionSettings resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfDataCatalogEncryptionSettings to import
    * @param importFromId The id of the existing DataTfDataCatalogEncryptionSettings that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/glue_data_catalog_encryption_settings#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfDataCatalogEncryptionSettings to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/glue_data_catalog_encryption_settings aws_glue_data_catalog_encryption_settings} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfDataCatalogEncryptionSettingsConfig
    */
    constructor(scope: Construct, id: string, config: DataTfDataCatalogEncryptionSettingsConfig);
    private _catalogId?;
    get catalogId(): string;
    set catalogId(value: string);
    get catalogIdInput(): string | undefined;
    private _dataCatalogEncryptionSettings;
    get dataCatalogEncryptionSettings(): DataTfDataCatalogEncryptionSettings.DataCatalogEncryptionSettingsPropertyList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfDataCatalogEncryptionSettingsConnectionPasswordEncryptionPropertyToTerraform(struct?: DataTfDataCatalogEncryptionSettings.ConnectionPasswordEncryptionProperty): any;
export declare function dataTfDataCatalogEncryptionSettingsConnectionPasswordEncryptionPropertyToHclTerraform(struct?: DataTfDataCatalogEncryptionSettings.ConnectionPasswordEncryptionProperty): any;
export declare function dataTfDataCatalogEncryptionSettingsEncryptionAtRestPropertyToTerraform(struct?: DataTfDataCatalogEncryptionSettings.EncryptionAtRestProperty): any;
export declare function dataTfDataCatalogEncryptionSettingsEncryptionAtRestPropertyToHclTerraform(struct?: DataTfDataCatalogEncryptionSettings.EncryptionAtRestProperty): any;
export declare function dataTfDataCatalogEncryptionSettingsDataCatalogEncryptionSettingsPropertyToTerraform(struct?: DataTfDataCatalogEncryptionSettings.DataCatalogEncryptionSettingsProperty): any;
export declare function dataTfDataCatalogEncryptionSettingsDataCatalogEncryptionSettingsPropertyToHclTerraform(struct?: DataTfDataCatalogEncryptionSettings.DataCatalogEncryptionSettingsProperty): any;
export declare namespace DataTfDataCatalogEncryptionSettings {
    interface ConnectionPasswordEncryptionProperty {
    }
    class ConnectionPasswordEncryptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConnectionPasswordEncryptionProperty | undefined;
        set internalValue(value: ConnectionPasswordEncryptionProperty | undefined);
        get awsKmsKeyId(): string;
        get returnConnectionPasswordEncrypted(): cdktn.IResolvable;
    }
    class ConnectionPasswordEncryptionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConnectionPasswordEncryptionPropertyOutputReference;
    }
    interface EncryptionAtRestProperty {
    }
    class EncryptionAtRestPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EncryptionAtRestProperty | undefined;
        set internalValue(value: EncryptionAtRestProperty | undefined);
        get catalogEncryptionMode(): string;
        get catalogEncryptionServiceRole(): string;
        get sseAwsKmsKeyId(): string;
    }
    class EncryptionAtRestPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EncryptionAtRestPropertyOutputReference;
    }
    interface DataCatalogEncryptionSettingsProperty {
    }
    class DataCatalogEncryptionSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataCatalogEncryptionSettingsProperty | undefined;
        set internalValue(value: DataCatalogEncryptionSettingsProperty | undefined);
        private _connectionPasswordEncryption;
        get connectionPasswordEncryption(): ConnectionPasswordEncryptionPropertyList;
        private _encryptionAtRest;
        get encryptionAtRest(): EncryptionAtRestPropertyList;
    }
    class DataCatalogEncryptionSettingsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataCatalogEncryptionSettingsPropertyOutputReference;
    }
}
