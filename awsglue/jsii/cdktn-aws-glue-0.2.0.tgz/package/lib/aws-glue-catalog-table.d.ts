import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfCatalogTableConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#catalog_id TfCatalogTable#catalog_id}
    */
    readonly catalogId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#database_name TfCatalogTable#database_name}
    */
    readonly databaseName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#description TfCatalogTable#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#id TfCatalogTable#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#name TfCatalogTable#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#owner TfCatalogTable#owner}
    */
    readonly owner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#parameters TfCatalogTable#parameters}
    */
    readonly parameters?: {
        [key: string]: string;
    };
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#region TfCatalogTable#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#retention TfCatalogTable#retention}
    */
    readonly retention?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#table_type TfCatalogTable#table_type}
    */
    readonly tableType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#view_expanded_text TfCatalogTable#view_expanded_text}
    */
    readonly viewExpandedText?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#view_original_text TfCatalogTable#view_original_text}
    */
    readonly viewOriginalText?: string;
    /**
    * open_table_format_input block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#open_table_format_input TfCatalogTable#open_table_format_input}
    */
    readonly openTableFormatInput?: TfCatalogTable.OpenTableFormatInputProperty;
    /**
    * partition_index block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#partition_index TfCatalogTable#partition_index}
    */
    readonly partitionIndex?: TfCatalogTable.PartitionIndexProperty[] | cdktn.IResolvable;
    /**
    * partition_keys block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#partition_keys TfCatalogTable#partition_keys}
    */
    readonly partitionKeys?: TfCatalogTable.PartitionKeysProperty[] | cdktn.IResolvable;
    /**
    * storage_descriptor block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#storage_descriptor TfCatalogTable#storage_descriptor}
    */
    readonly storageDescriptor?: TfCatalogTable.StorageDescriptorProperty;
    /**
    * target_table block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#target_table TfCatalogTable#target_table}
    */
    readonly targetTable?: TfCatalogTable.TargetTableProperty;
    /**
    * view_definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#view_definition TfCatalogTable#view_definition}
    */
    readonly viewDefinition?: TfCatalogTable.ViewDefinitionProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table aws_glue_catalog_table}
*/
export declare class TfCatalogTable extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_glue_catalog_table";
    /**
    * Generates CDKTN code for importing a TfCatalogTable resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfCatalogTable to import
    * @param importFromId The id of the existing TfCatalogTable that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfCatalogTable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table aws_glue_catalog_table} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfCatalogTableConfig
    */
    constructor(scope: Construct, id: string, config: TfCatalogTableConfig);
    get arn(): string;
    private _catalogId?;
    get catalogId(): string;
    set catalogId(value: string);
    resetCatalogId(): void;
    get catalogIdInput(): string | undefined;
    private _databaseName?;
    get databaseName(): string;
    set databaseName(value: string);
    get databaseNameInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    resetOwner(): void;
    get ownerInput(): string | undefined;
    private _parameters?;
    get parameters(): {
        [key: string]: string;
    };
    set parameters(value: {
        [key: string]: string;
    });
    resetParameters(): void;
    get parametersInput(): {
        [key: string]: string;
    } | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _retention?;
    get retention(): number;
    set retention(value: number);
    resetRetention(): void;
    get retentionInput(): number | undefined;
    private _tableType?;
    get tableType(): string;
    set tableType(value: string);
    resetTableType(): void;
    get tableTypeInput(): string | undefined;
    private _viewExpandedText?;
    get viewExpandedText(): string;
    set viewExpandedText(value: string);
    resetViewExpandedText(): void;
    get viewExpandedTextInput(): string | undefined;
    private _viewOriginalText?;
    get viewOriginalText(): string;
    set viewOriginalText(value: string);
    resetViewOriginalText(): void;
    get viewOriginalTextInput(): string | undefined;
    private _openTableFormatInput;
    get openTableFormatInput(): TfCatalogTable.OpenTableFormatInputPropertyOutputReference;
    putOpenTableFormatInput(value: TfCatalogTable.OpenTableFormatInputProperty): void;
    resetOpenTableFormatInput(): void;
    get openTableFormatInputInput(): TfCatalogTable.OpenTableFormatInputProperty | undefined;
    private _partitionIndex;
    get partitionIndex(): TfCatalogTable.PartitionIndexPropertyList;
    putPartitionIndex(value: TfCatalogTable.PartitionIndexProperty[] | cdktn.IResolvable): void;
    resetPartitionIndex(): void;
    get partitionIndexInput(): cdktn.IResolvable | TfCatalogTable.PartitionIndexProperty[] | undefined;
    private _partitionKeys;
    get partitionKeys(): TfCatalogTable.PartitionKeysPropertyList;
    putPartitionKeys(value: TfCatalogTable.PartitionKeysProperty[] | cdktn.IResolvable): void;
    resetPartitionKeys(): void;
    get partitionKeysInput(): cdktn.IResolvable | TfCatalogTable.PartitionKeysProperty[] | undefined;
    private _storageDescriptor;
    get storageDescriptor(): TfCatalogTable.StorageDescriptorPropertyOutputReference;
    putStorageDescriptor(value: TfCatalogTable.StorageDescriptorProperty): void;
    resetStorageDescriptor(): void;
    get storageDescriptorInput(): TfCatalogTable.StorageDescriptorProperty | undefined;
    private _targetTable;
    get targetTable(): TfCatalogTable.TargetTablePropertyOutputReference;
    putTargetTable(value: TfCatalogTable.TargetTableProperty): void;
    resetTargetTable(): void;
    get targetTableInput(): TfCatalogTable.TargetTableProperty | undefined;
    private _viewDefinition;
    get viewDefinition(): TfCatalogTable.ViewDefinitionPropertyOutputReference;
    putViewDefinition(value: TfCatalogTable.ViewDefinitionProperty): void;
    resetViewDefinition(): void;
    get viewDefinitionInput(): TfCatalogTable.ViewDefinitionProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfCatalogTableOpenTableFormatInputIcebergInputIcebergTableInputPartitionSpecFieldsPropertyToTerraform(struct?: TfCatalogTable.OpenTableFormatInputIcebergInputIcebergTableInputPartitionSpecFieldsProperty | cdktn.IResolvable): any;
export declare function tfCatalogTableOpenTableFormatInputIcebergInputIcebergTableInputPartitionSpecFieldsPropertyToHclTerraform(struct?: TfCatalogTable.OpenTableFormatInputIcebergInputIcebergTableInputPartitionSpecFieldsProperty | cdktn.IResolvable): any;
export declare function tfCatalogTablePartitionSpecPropertyToTerraform(struct?: TfCatalogTable.PartitionSpecPropertyOutputReference | TfCatalogTable.PartitionSpecProperty): any;
export declare function tfCatalogTablePartitionSpecPropertyToHclTerraform(struct?: TfCatalogTable.PartitionSpecPropertyOutputReference | TfCatalogTable.PartitionSpecProperty): any;
export declare function tfCatalogTableOpenTableFormatInputIcebergInputIcebergTableInputSchemaFieldsPropertyToTerraform(struct?: TfCatalogTable.OpenTableFormatInputIcebergInputIcebergTableInputSchemaFieldsProperty | cdktn.IResolvable): any;
export declare function tfCatalogTableOpenTableFormatInputIcebergInputIcebergTableInputSchemaFieldsPropertyToHclTerraform(struct?: TfCatalogTable.OpenTableFormatInputIcebergInputIcebergTableInputSchemaFieldsProperty | cdktn.IResolvable): any;
export declare function tfCatalogTableSchemaPropertyToTerraform(struct?: TfCatalogTable.SchemaPropertyOutputReference | TfCatalogTable.SchemaProperty): any;
export declare function tfCatalogTableSchemaPropertyToHclTerraform(struct?: TfCatalogTable.SchemaPropertyOutputReference | TfCatalogTable.SchemaProperty): any;
export declare function tfCatalogTableOpenTableFormatInputIcebergInputIcebergTableInputSortOrderFieldsPropertyToTerraform(struct?: TfCatalogTable.OpenTableFormatInputIcebergInputIcebergTableInputSortOrderFieldsProperty | cdktn.IResolvable): any;
export declare function tfCatalogTableOpenTableFormatInputIcebergInputIcebergTableInputSortOrderFieldsPropertyToHclTerraform(struct?: TfCatalogTable.OpenTableFormatInputIcebergInputIcebergTableInputSortOrderFieldsProperty | cdktn.IResolvable): any;
export declare function tfCatalogTableSortOrderPropertyToTerraform(struct?: TfCatalogTable.SortOrderPropertyOutputReference | TfCatalogTable.SortOrderProperty): any;
export declare function tfCatalogTableSortOrderPropertyToHclTerraform(struct?: TfCatalogTable.SortOrderPropertyOutputReference | TfCatalogTable.SortOrderProperty): any;
export declare function tfCatalogTableIcebergTableInputPropertyToTerraform(struct?: TfCatalogTable.IcebergTableInputPropertyOutputReference | TfCatalogTable.IcebergTableInputProperty): any;
export declare function tfCatalogTableIcebergTableInputPropertyToHclTerraform(struct?: TfCatalogTable.IcebergTableInputPropertyOutputReference | TfCatalogTable.IcebergTableInputProperty): any;
export declare function tfCatalogTableIcebergInputPropertyToTerraform(struct?: TfCatalogTable.IcebergInputPropertyOutputReference | TfCatalogTable.IcebergInputProperty): any;
export declare function tfCatalogTableIcebergInputPropertyToHclTerraform(struct?: TfCatalogTable.IcebergInputPropertyOutputReference | TfCatalogTable.IcebergInputProperty): any;
export declare function tfCatalogTableOpenTableFormatInputPropertyToTerraform(struct?: TfCatalogTable.OpenTableFormatInputPropertyOutputReference | TfCatalogTable.OpenTableFormatInputProperty): any;
export declare function tfCatalogTableOpenTableFormatInputPropertyToHclTerraform(struct?: TfCatalogTable.OpenTableFormatInputPropertyOutputReference | TfCatalogTable.OpenTableFormatInputProperty): any;
export declare function tfCatalogTablePartitionIndexPropertyToTerraform(struct?: TfCatalogTable.PartitionIndexProperty | cdktn.IResolvable): any;
export declare function tfCatalogTablePartitionIndexPropertyToHclTerraform(struct?: TfCatalogTable.PartitionIndexProperty | cdktn.IResolvable): any;
export declare function tfCatalogTablePartitionKeysPropertyToTerraform(struct?: TfCatalogTable.PartitionKeysProperty | cdktn.IResolvable): any;
export declare function tfCatalogTablePartitionKeysPropertyToHclTerraform(struct?: TfCatalogTable.PartitionKeysProperty | cdktn.IResolvable): any;
export declare function tfCatalogTableColumnsPropertyToTerraform(struct?: TfCatalogTable.ColumnsProperty | cdktn.IResolvable): any;
export declare function tfCatalogTableColumnsPropertyToHclTerraform(struct?: TfCatalogTable.ColumnsProperty | cdktn.IResolvable): any;
export declare function tfCatalogTableSchemaIdPropertyToTerraform(struct?: TfCatalogTable.SchemaIdPropertyOutputReference | TfCatalogTable.SchemaIdProperty): any;
export declare function tfCatalogTableSchemaIdPropertyToHclTerraform(struct?: TfCatalogTable.SchemaIdPropertyOutputReference | TfCatalogTable.SchemaIdProperty): any;
export declare function tfCatalogTableSchemaReferencePropertyToTerraform(struct?: TfCatalogTable.SchemaReferencePropertyOutputReference | TfCatalogTable.SchemaReferenceProperty): any;
export declare function tfCatalogTableSchemaReferencePropertyToHclTerraform(struct?: TfCatalogTable.SchemaReferencePropertyOutputReference | TfCatalogTable.SchemaReferenceProperty): any;
export declare function tfCatalogTableSerDeInfoPropertyToTerraform(struct?: TfCatalogTable.SerDeInfoPropertyOutputReference | TfCatalogTable.SerDeInfoProperty): any;
export declare function tfCatalogTableSerDeInfoPropertyToHclTerraform(struct?: TfCatalogTable.SerDeInfoPropertyOutputReference | TfCatalogTable.SerDeInfoProperty): any;
export declare function tfCatalogTableSkewedInfoPropertyToTerraform(struct?: TfCatalogTable.SkewedInfoPropertyOutputReference | TfCatalogTable.SkewedInfoProperty): any;
export declare function tfCatalogTableSkewedInfoPropertyToHclTerraform(struct?: TfCatalogTable.SkewedInfoPropertyOutputReference | TfCatalogTable.SkewedInfoProperty): any;
export declare function tfCatalogTableSortColumnsPropertyToTerraform(struct?: TfCatalogTable.SortColumnsProperty | cdktn.IResolvable): any;
export declare function tfCatalogTableSortColumnsPropertyToHclTerraform(struct?: TfCatalogTable.SortColumnsProperty | cdktn.IResolvable): any;
export declare function tfCatalogTableStorageDescriptorPropertyToTerraform(struct?: TfCatalogTable.StorageDescriptorPropertyOutputReference | TfCatalogTable.StorageDescriptorProperty): any;
export declare function tfCatalogTableStorageDescriptorPropertyToHclTerraform(struct?: TfCatalogTable.StorageDescriptorPropertyOutputReference | TfCatalogTable.StorageDescriptorProperty): any;
export declare function tfCatalogTableTargetTablePropertyToTerraform(struct?: TfCatalogTable.TargetTablePropertyOutputReference | TfCatalogTable.TargetTableProperty): any;
export declare function tfCatalogTableTargetTablePropertyToHclTerraform(struct?: TfCatalogTable.TargetTablePropertyOutputReference | TfCatalogTable.TargetTableProperty): any;
export declare function tfCatalogTableRepresentationsPropertyToTerraform(struct?: TfCatalogTable.RepresentationsProperty | cdktn.IResolvable): any;
export declare function tfCatalogTableRepresentationsPropertyToHclTerraform(struct?: TfCatalogTable.RepresentationsProperty | cdktn.IResolvable): any;
export declare function tfCatalogTableViewDefinitionPropertyToTerraform(struct?: TfCatalogTable.ViewDefinitionPropertyOutputReference | TfCatalogTable.ViewDefinitionProperty): any;
export declare function tfCatalogTableViewDefinitionPropertyToHclTerraform(struct?: TfCatalogTable.ViewDefinitionPropertyOutputReference | TfCatalogTable.ViewDefinitionProperty): any;
export declare namespace TfCatalogTable {
    interface OpenTableFormatInputIcebergInputIcebergTableInputPartitionSpecFieldsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#field_id TfCatalogTable#field_id}
        */
        readonly fieldId?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#name TfCatalogTable#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#source_id TfCatalogTable#source_id}
        */
        readonly sourceId: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#transform TfCatalogTable#transform}
        */
        readonly transform: string;
    }
    class OpenTableFormatInputIcebergInputIcebergTableInputPartitionSpecFieldsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OpenTableFormatInputIcebergInputIcebergTableInputPartitionSpecFieldsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OpenTableFormatInputIcebergInputIcebergTableInputPartitionSpecFieldsProperty | cdktn.IResolvable | undefined);
        private _fieldId?;
        get fieldId(): number;
        set fieldId(value: number);
        resetFieldId(): void;
        get fieldIdInput(): number | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _sourceId?;
        get sourceId(): number;
        set sourceId(value: number);
        get sourceIdInput(): number | undefined;
        private _transform?;
        get transform(): string;
        set transform(value: string);
        get transformInput(): string | undefined;
    }
    class OpenTableFormatInputIcebergInputIcebergTableInputPartitionSpecFieldsPropertyList extends cdktn.ComplexList {
        internalValue?: OpenTableFormatInputIcebergInputIcebergTableInputPartitionSpecFieldsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OpenTableFormatInputIcebergInputIcebergTableInputPartitionSpecFieldsPropertyOutputReference;
    }
    interface PartitionSpecProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#spec_id TfCatalogTable#spec_id}
        */
        readonly specId?: number;
        /**
        * fields block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#fields TfCatalogTable#fields}
        */
        readonly fields: OpenTableFormatInputIcebergInputIcebergTableInputPartitionSpecFieldsProperty[] | cdktn.IResolvable;
    }
    class PartitionSpecPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PartitionSpecProperty | undefined;
        set internalValue(value: PartitionSpecProperty | undefined);
        private _specId?;
        get specId(): number;
        set specId(value: number);
        resetSpecId(): void;
        get specIdInput(): number | undefined;
        private _fields;
        get fields(): OpenTableFormatInputIcebergInputIcebergTableInputPartitionSpecFieldsPropertyList;
        putFields(value: OpenTableFormatInputIcebergInputIcebergTableInputPartitionSpecFieldsProperty[] | cdktn.IResolvable): void;
        get fieldsInput(): cdktn.IResolvable | OpenTableFormatInputIcebergInputIcebergTableInputPartitionSpecFieldsProperty[] | undefined;
    }
    interface OpenTableFormatInputIcebergInputIcebergTableInputSchemaFieldsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#doc TfCatalogTable#doc}
        */
        readonly doc?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#id TfCatalogTable#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#initial_default TfCatalogTable#initial_default}
        */
        readonly initialDefault?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#name TfCatalogTable#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#required TfCatalogTable#required}
        */
        readonly required: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#type TfCatalogTable#type}
        */
        readonly type: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#write_default TfCatalogTable#write_default}
        */
        readonly writeDefault?: string;
    }
    class OpenTableFormatInputIcebergInputIcebergTableInputSchemaFieldsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OpenTableFormatInputIcebergInputIcebergTableInputSchemaFieldsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OpenTableFormatInputIcebergInputIcebergTableInputSchemaFieldsProperty | cdktn.IResolvable | undefined);
        private _doc?;
        get doc(): string;
        set doc(value: string);
        resetDoc(): void;
        get docInput(): string | undefined;
        private _id?;
        get id(): number;
        set id(value: number);
        get idInput(): number | undefined;
        private _initialDefault?;
        get initialDefault(): string;
        set initialDefault(value: string);
        resetInitialDefault(): void;
        get initialDefaultInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _required?;
        get required(): boolean | cdktn.IResolvable;
        set required(value: boolean | cdktn.IResolvable);
        get requiredInput(): boolean | cdktn.IResolvable | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _writeDefault?;
        get writeDefault(): string;
        set writeDefault(value: string);
        resetWriteDefault(): void;
        get writeDefaultInput(): string | undefined;
    }
    class OpenTableFormatInputIcebergInputIcebergTableInputSchemaFieldsPropertyList extends cdktn.ComplexList {
        internalValue?: OpenTableFormatInputIcebergInputIcebergTableInputSchemaFieldsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OpenTableFormatInputIcebergInputIcebergTableInputSchemaFieldsPropertyOutputReference;
    }
    interface SchemaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#identifier_field_ids TfCatalogTable#identifier_field_ids}
        */
        readonly identifierFieldIds?: number[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#schema_id TfCatalogTable#schema_id}
        */
        readonly schemaId?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#type TfCatalogTable#type}
        */
        readonly type?: string;
        /**
        * fields block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#fields TfCatalogTable#fields}
        */
        readonly fields: OpenTableFormatInputIcebergInputIcebergTableInputSchemaFieldsProperty[] | cdktn.IResolvable;
    }
    class SchemaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SchemaProperty | undefined;
        set internalValue(value: SchemaProperty | undefined);
        private _identifierFieldIds?;
        get identifierFieldIds(): number[];
        set identifierFieldIds(value: number[]);
        resetIdentifierFieldIds(): void;
        get identifierFieldIdsInput(): number[] | undefined;
        private _schemaId?;
        get schemaId(): number;
        set schemaId(value: number);
        resetSchemaId(): void;
        get schemaIdInput(): number | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
        private _fields;
        get fields(): OpenTableFormatInputIcebergInputIcebergTableInputSchemaFieldsPropertyList;
        putFields(value: OpenTableFormatInputIcebergInputIcebergTableInputSchemaFieldsProperty[] | cdktn.IResolvable): void;
        get fieldsInput(): cdktn.IResolvable | OpenTableFormatInputIcebergInputIcebergTableInputSchemaFieldsProperty[] | undefined;
    }
    interface OpenTableFormatInputIcebergInputIcebergTableInputSortOrderFieldsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#direction TfCatalogTable#direction}
        */
        readonly direction: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#null_order TfCatalogTable#null_order}
        */
        readonly nullOrder: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#source_id TfCatalogTable#source_id}
        */
        readonly sourceId: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#transform TfCatalogTable#transform}
        */
        readonly transform: string;
    }
    class OpenTableFormatInputIcebergInputIcebergTableInputSortOrderFieldsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OpenTableFormatInputIcebergInputIcebergTableInputSortOrderFieldsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OpenTableFormatInputIcebergInputIcebergTableInputSortOrderFieldsProperty | cdktn.IResolvable | undefined);
        private _direction?;
        get direction(): string;
        set direction(value: string);
        get directionInput(): string | undefined;
        private _nullOrder?;
        get nullOrder(): string;
        set nullOrder(value: string);
        get nullOrderInput(): string | undefined;
        private _sourceId?;
        get sourceId(): number;
        set sourceId(value: number);
        get sourceIdInput(): number | undefined;
        private _transform?;
        get transform(): string;
        set transform(value: string);
        get transformInput(): string | undefined;
    }
    class OpenTableFormatInputIcebergInputIcebergTableInputSortOrderFieldsPropertyList extends cdktn.ComplexList {
        internalValue?: OpenTableFormatInputIcebergInputIcebergTableInputSortOrderFieldsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OpenTableFormatInputIcebergInputIcebergTableInputSortOrderFieldsPropertyOutputReference;
    }
    interface SortOrderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#order_id TfCatalogTable#order_id}
        */
        readonly orderId: number;
        /**
        * fields block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#fields TfCatalogTable#fields}
        */
        readonly fields: OpenTableFormatInputIcebergInputIcebergTableInputSortOrderFieldsProperty[] | cdktn.IResolvable;
    }
    class SortOrderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SortOrderProperty | undefined;
        set internalValue(value: SortOrderProperty | undefined);
        private _orderId?;
        get orderId(): number;
        set orderId(value: number);
        get orderIdInput(): number | undefined;
        private _fields;
        get fields(): OpenTableFormatInputIcebergInputIcebergTableInputSortOrderFieldsPropertyList;
        putFields(value: OpenTableFormatInputIcebergInputIcebergTableInputSortOrderFieldsProperty[] | cdktn.IResolvable): void;
        get fieldsInput(): cdktn.IResolvable | OpenTableFormatInputIcebergInputIcebergTableInputSortOrderFieldsProperty[] | undefined;
    }
    interface IcebergTableInputProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#location TfCatalogTable#location}
        */
        readonly location: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#properties TfCatalogTable#properties}
        */
        readonly properties?: {
            [key: string]: string;
        };
        /**
        * partition_spec block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#partition_spec TfCatalogTable#partition_spec}
        */
        readonly partitionSpec?: PartitionSpecProperty;
        /**
        * schema block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#schema TfCatalogTable#schema}
        */
        readonly schema: SchemaProperty;
        /**
        * sort_order block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#sort_order TfCatalogTable#sort_order}
        */
        readonly sortOrder?: SortOrderProperty;
    }
    class IcebergTableInputPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IcebergTableInputProperty | undefined;
        set internalValue(value: IcebergTableInputProperty | undefined);
        private _location?;
        get location(): string;
        set location(value: string);
        get locationInput(): string | undefined;
        private _properties?;
        get properties(): {
            [key: string]: string;
        };
        set properties(value: {
            [key: string]: string;
        });
        resetProperties(): void;
        get propertiesInput(): {
            [key: string]: string;
        } | undefined;
        private _partitionSpec;
        get partitionSpec(): PartitionSpecPropertyOutputReference;
        putPartitionSpec(value: PartitionSpecProperty): void;
        resetPartitionSpec(): void;
        get partitionSpecInput(): PartitionSpecProperty | undefined;
        private _schema;
        get schema(): SchemaPropertyOutputReference;
        putSchema(value: SchemaProperty): void;
        get schemaInput(): SchemaProperty | undefined;
        private _sortOrder;
        get sortOrder(): SortOrderPropertyOutputReference;
        putSortOrder(value: SortOrderProperty): void;
        resetSortOrder(): void;
        get sortOrderInput(): SortOrderProperty | undefined;
    }
    interface IcebergInputProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#metadata_operation TfCatalogTable#metadata_operation}
        */
        readonly metadataOperation: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#version TfCatalogTable#version}
        */
        readonly version?: string;
        /**
        * iceberg_table_input block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#iceberg_table_input TfCatalogTable#iceberg_table_input}
        */
        readonly icebergTableInput?: IcebergTableInputProperty;
    }
    class IcebergInputPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IcebergInputProperty | undefined;
        set internalValue(value: IcebergInputProperty | undefined);
        private _metadataOperation?;
        get metadataOperation(): string;
        set metadataOperation(value: string);
        get metadataOperationInput(): string | undefined;
        private _version?;
        get version(): string;
        set version(value: string);
        resetVersion(): void;
        get versionInput(): string | undefined;
        private _icebergTableInput;
        get icebergTableInput(): IcebergTableInputPropertyOutputReference;
        putIcebergTableInput(value: IcebergTableInputProperty): void;
        resetIcebergTableInput(): void;
        get icebergTableInputInput(): IcebergTableInputProperty | undefined;
    }
    interface OpenTableFormatInputProperty {
        /**
        * iceberg_input block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#iceberg_input TfCatalogTable#iceberg_input}
        */
        readonly icebergInput: IcebergInputProperty;
    }
    class OpenTableFormatInputPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OpenTableFormatInputProperty | undefined;
        set internalValue(value: OpenTableFormatInputProperty | undefined);
        private _icebergInput;
        get icebergInput(): IcebergInputPropertyOutputReference;
        putIcebergInput(value: IcebergInputProperty): void;
        get icebergInputInput(): IcebergInputProperty | undefined;
    }
    interface PartitionIndexProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#index_name TfCatalogTable#index_name}
        */
        readonly indexName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#keys TfCatalogTable#keys}
        */
        readonly keys: string[];
    }
    class PartitionIndexPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PartitionIndexProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PartitionIndexProperty | cdktn.IResolvable | undefined);
        private _indexName?;
        get indexName(): string;
        set indexName(value: string);
        get indexNameInput(): string | undefined;
        get indexStatus(): string;
        private _keys?;
        get keys(): string[];
        set keys(value: string[]);
        get keysInput(): string[] | undefined;
    }
    class PartitionIndexPropertyList extends cdktn.ComplexList {
        internalValue?: PartitionIndexProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PartitionIndexPropertyOutputReference;
    }
    interface PartitionKeysProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#comment TfCatalogTable#comment}
        */
        readonly comment?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#name TfCatalogTable#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#parameters TfCatalogTable#parameters}
        */
        readonly parameters?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#type TfCatalogTable#type}
        */
        readonly type?: string;
    }
    class PartitionKeysPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PartitionKeysProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PartitionKeysProperty | cdktn.IResolvable | undefined);
        private _comment?;
        get comment(): string;
        set comment(value: string);
        resetComment(): void;
        get commentInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _parameters?;
        get parameters(): {
            [key: string]: string;
        };
        set parameters(value: {
            [key: string]: string;
        });
        resetParameters(): void;
        get parametersInput(): {
            [key: string]: string;
        } | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
    }
    class PartitionKeysPropertyList extends cdktn.ComplexList {
        internalValue?: PartitionKeysProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PartitionKeysPropertyOutputReference;
    }
    interface ColumnsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#comment TfCatalogTable#comment}
        */
        readonly comment?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#name TfCatalogTable#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#parameters TfCatalogTable#parameters}
        */
        readonly parameters?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#type TfCatalogTable#type}
        */
        readonly type?: string;
    }
    class ColumnsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ColumnsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ColumnsProperty | cdktn.IResolvable | undefined);
        private _comment?;
        get comment(): string;
        set comment(value: string);
        resetComment(): void;
        get commentInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _parameters?;
        get parameters(): {
            [key: string]: string;
        };
        set parameters(value: {
            [key: string]: string;
        });
        resetParameters(): void;
        get parametersInput(): {
            [key: string]: string;
        } | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
    }
    class ColumnsPropertyList extends cdktn.ComplexList {
        internalValue?: ColumnsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ColumnsPropertyOutputReference;
    }
    interface SchemaIdProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#registry_name TfCatalogTable#registry_name}
        */
        readonly registryName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#schema_arn TfCatalogTable#schema_arn}
        */
        readonly schemaArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#schema_name TfCatalogTable#schema_name}
        */
        readonly schemaName?: string;
    }
    class SchemaIdPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SchemaIdProperty | undefined;
        set internalValue(value: SchemaIdProperty | undefined);
        private _registryName?;
        get registryName(): string;
        set registryName(value: string);
        resetRegistryName(): void;
        get registryNameInput(): string | undefined;
        private _schemaArn?;
        get schemaArn(): string;
        set schemaArn(value: string);
        resetSchemaArn(): void;
        get schemaArnInput(): string | undefined;
        private _schemaName?;
        get schemaName(): string;
        set schemaName(value: string);
        resetSchemaName(): void;
        get schemaNameInput(): string | undefined;
    }
    interface SchemaReferenceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#schema_version_id TfCatalogTable#schema_version_id}
        */
        readonly schemaVersionId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#schema_version_number TfCatalogTable#schema_version_number}
        */
        readonly schemaVersionNumber: number;
        /**
        * schema_id block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#schema_id TfCatalogTable#schema_id}
        */
        readonly schemaId?: SchemaIdProperty;
    }
    class SchemaReferencePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SchemaReferenceProperty | undefined;
        set internalValue(value: SchemaReferenceProperty | undefined);
        private _schemaVersionId?;
        get schemaVersionId(): string;
        set schemaVersionId(value: string);
        resetSchemaVersionId(): void;
        get schemaVersionIdInput(): string | undefined;
        private _schemaVersionNumber?;
        get schemaVersionNumber(): number;
        set schemaVersionNumber(value: number);
        get schemaVersionNumberInput(): number | undefined;
        private _schemaId;
        get schemaId(): SchemaIdPropertyOutputReference;
        putSchemaId(value: SchemaIdProperty): void;
        resetSchemaId(): void;
        get schemaIdInput(): SchemaIdProperty | undefined;
    }
    interface SerDeInfoProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#name TfCatalogTable#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#parameters TfCatalogTable#parameters}
        */
        readonly parameters?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#serialization_library TfCatalogTable#serialization_library}
        */
        readonly serializationLibrary?: string;
    }
    class SerDeInfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SerDeInfoProperty | undefined;
        set internalValue(value: SerDeInfoProperty | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _parameters?;
        get parameters(): {
            [key: string]: string;
        };
        set parameters(value: {
            [key: string]: string;
        });
        resetParameters(): void;
        get parametersInput(): {
            [key: string]: string;
        } | undefined;
        private _serializationLibrary?;
        get serializationLibrary(): string;
        set serializationLibrary(value: string);
        resetSerializationLibrary(): void;
        get serializationLibraryInput(): string | undefined;
    }
    interface SkewedInfoProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#skewed_column_names TfCatalogTable#skewed_column_names}
        */
        readonly skewedColumnNames?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#skewed_column_value_location_maps TfCatalogTable#skewed_column_value_location_maps}
        */
        readonly skewedColumnValueLocationMaps?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#skewed_column_values TfCatalogTable#skewed_column_values}
        */
        readonly skewedColumnValues?: string[];
    }
    class SkewedInfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SkewedInfoProperty | undefined;
        set internalValue(value: SkewedInfoProperty | undefined);
        private _skewedColumnNames?;
        get skewedColumnNames(): string[];
        set skewedColumnNames(value: string[]);
        resetSkewedColumnNames(): void;
        get skewedColumnNamesInput(): string[] | undefined;
        private _skewedColumnValueLocationMaps?;
        get skewedColumnValueLocationMaps(): {
            [key: string]: string;
        };
        set skewedColumnValueLocationMaps(value: {
            [key: string]: string;
        });
        resetSkewedColumnValueLocationMaps(): void;
        get skewedColumnValueLocationMapsInput(): {
            [key: string]: string;
        } | undefined;
        private _skewedColumnValues?;
        get skewedColumnValues(): string[];
        set skewedColumnValues(value: string[]);
        resetSkewedColumnValues(): void;
        get skewedColumnValuesInput(): string[] | undefined;
    }
    interface SortColumnsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#column TfCatalogTable#column}
        */
        readonly column: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#sort_order TfCatalogTable#sort_order}
        */
        readonly sortOrder: number;
    }
    class SortColumnsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SortColumnsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SortColumnsProperty | cdktn.IResolvable | undefined);
        private _column?;
        get column(): string;
        set column(value: string);
        get columnInput(): string | undefined;
        private _sortOrder?;
        get sortOrder(): number;
        set sortOrder(value: number);
        get sortOrderInput(): number | undefined;
    }
    class SortColumnsPropertyList extends cdktn.ComplexList {
        internalValue?: SortColumnsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SortColumnsPropertyOutputReference;
    }
    interface StorageDescriptorProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#additional_locations TfCatalogTable#additional_locations}
        */
        readonly additionalLocations?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#bucket_columns TfCatalogTable#bucket_columns}
        */
        readonly bucketColumns?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#compressed TfCatalogTable#compressed}
        */
        readonly compressed?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#input_format TfCatalogTable#input_format}
        */
        readonly inputFormat?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#location TfCatalogTable#location}
        */
        readonly location?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#number_of_buckets TfCatalogTable#number_of_buckets}
        */
        readonly numberOfBuckets?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#output_format TfCatalogTable#output_format}
        */
        readonly outputFormat?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#parameters TfCatalogTable#parameters}
        */
        readonly parameters?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#stored_as_sub_directories TfCatalogTable#stored_as_sub_directories}
        */
        readonly storedAsSubDirectories?: boolean | cdktn.IResolvable;
        /**
        * columns block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#columns TfCatalogTable#columns}
        */
        readonly columns?: ColumnsProperty[] | cdktn.IResolvable;
        /**
        * schema_reference block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#schema_reference TfCatalogTable#schema_reference}
        */
        readonly schemaReference?: SchemaReferenceProperty;
        /**
        * ser_de_info block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#ser_de_info TfCatalogTable#ser_de_info}
        */
        readonly serDeInfo?: SerDeInfoProperty;
        /**
        * skewed_info block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#skewed_info TfCatalogTable#skewed_info}
        */
        readonly skewedInfo?: SkewedInfoProperty;
        /**
        * sort_columns block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#sort_columns TfCatalogTable#sort_columns}
        */
        readonly sortColumns?: SortColumnsProperty[] | cdktn.IResolvable;
    }
    class StorageDescriptorPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StorageDescriptorProperty | undefined;
        set internalValue(value: StorageDescriptorProperty | undefined);
        private _additionalLocations?;
        get additionalLocations(): string[];
        set additionalLocations(value: string[]);
        resetAdditionalLocations(): void;
        get additionalLocationsInput(): string[] | undefined;
        private _bucketColumns?;
        get bucketColumns(): string[];
        set bucketColumns(value: string[]);
        resetBucketColumns(): void;
        get bucketColumnsInput(): string[] | undefined;
        private _compressed?;
        get compressed(): boolean | cdktn.IResolvable;
        set compressed(value: boolean | cdktn.IResolvable);
        resetCompressed(): void;
        get compressedInput(): boolean | cdktn.IResolvable | undefined;
        private _inputFormat?;
        get inputFormat(): string;
        set inputFormat(value: string);
        resetInputFormat(): void;
        get inputFormatInput(): string | undefined;
        private _location?;
        get location(): string;
        set location(value: string);
        resetLocation(): void;
        get locationInput(): string | undefined;
        private _numberOfBuckets?;
        get numberOfBuckets(): number;
        set numberOfBuckets(value: number);
        resetNumberOfBuckets(): void;
        get numberOfBucketsInput(): number | undefined;
        private _outputFormat?;
        get outputFormat(): string;
        set outputFormat(value: string);
        resetOutputFormat(): void;
        get outputFormatInput(): string | undefined;
        private _parameters?;
        get parameters(): {
            [key: string]: string;
        };
        set parameters(value: {
            [key: string]: string;
        });
        resetParameters(): void;
        get parametersInput(): {
            [key: string]: string;
        } | undefined;
        private _storedAsSubDirectories?;
        get storedAsSubDirectories(): boolean | cdktn.IResolvable;
        set storedAsSubDirectories(value: boolean | cdktn.IResolvable);
        resetStoredAsSubDirectories(): void;
        get storedAsSubDirectoriesInput(): boolean | cdktn.IResolvable | undefined;
        private _columns;
        get columns(): ColumnsPropertyList;
        putColumns(value: ColumnsProperty[] | cdktn.IResolvable): void;
        resetColumns(): void;
        get columnsInput(): cdktn.IResolvable | ColumnsProperty[] | undefined;
        private _schemaReference;
        get schemaReference(): SchemaReferencePropertyOutputReference;
        putSchemaReference(value: SchemaReferenceProperty): void;
        resetSchemaReference(): void;
        get schemaReferenceInput(): SchemaReferenceProperty | undefined;
        private _serDeInfo;
        get serDeInfo(): SerDeInfoPropertyOutputReference;
        putSerDeInfo(value: SerDeInfoProperty): void;
        resetSerDeInfo(): void;
        get serDeInfoInput(): SerDeInfoProperty | undefined;
        private _skewedInfo;
        get skewedInfo(): SkewedInfoPropertyOutputReference;
        putSkewedInfo(value: SkewedInfoProperty): void;
        resetSkewedInfo(): void;
        get skewedInfoInput(): SkewedInfoProperty | undefined;
        private _sortColumns;
        get sortColumns(): SortColumnsPropertyList;
        putSortColumns(value: SortColumnsProperty[] | cdktn.IResolvable): void;
        resetSortColumns(): void;
        get sortColumnsInput(): cdktn.IResolvable | SortColumnsProperty[] | undefined;
    }
    interface TargetTableProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#catalog_id TfCatalogTable#catalog_id}
        */
        readonly catalogId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#database_name TfCatalogTable#database_name}
        */
        readonly databaseName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#name TfCatalogTable#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#region TfCatalogTable#region}
        */
        readonly region?: string;
    }
    class TargetTablePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TargetTableProperty | undefined;
        set internalValue(value: TargetTableProperty | undefined);
        private _catalogId?;
        get catalogId(): string;
        set catalogId(value: string);
        get catalogIdInput(): string | undefined;
        private _databaseName?;
        get databaseName(): string;
        set databaseName(value: string);
        get databaseNameInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _region?;
        get region(): string;
        set region(value: string);
        resetRegion(): void;
        get regionInput(): string | undefined;
    }
    interface RepresentationsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#dialect TfCatalogTable#dialect}
        */
        readonly dialect?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#dialect_version TfCatalogTable#dialect_version}
        */
        readonly dialectVersion?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#validation_connection TfCatalogTable#validation_connection}
        */
        readonly validationConnection?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#view_expanded_text TfCatalogTable#view_expanded_text}
        */
        readonly viewExpandedText?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#view_original_text TfCatalogTable#view_original_text}
        */
        readonly viewOriginalText?: string;
    }
    class RepresentationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RepresentationsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RepresentationsProperty | cdktn.IResolvable | undefined);
        private _dialect?;
        get dialect(): string;
        set dialect(value: string);
        resetDialect(): void;
        get dialectInput(): string | undefined;
        private _dialectVersion?;
        get dialectVersion(): string;
        set dialectVersion(value: string);
        resetDialectVersion(): void;
        get dialectVersionInput(): string | undefined;
        private _validationConnection?;
        get validationConnection(): string;
        set validationConnection(value: string);
        resetValidationConnection(): void;
        get validationConnectionInput(): string | undefined;
        private _viewExpandedText?;
        get viewExpandedText(): string;
        set viewExpandedText(value: string);
        resetViewExpandedText(): void;
        get viewExpandedTextInput(): string | undefined;
        private _viewOriginalText?;
        get viewOriginalText(): string;
        set viewOriginalText(value: string);
        resetViewOriginalText(): void;
        get viewOriginalTextInput(): string | undefined;
    }
    class RepresentationsPropertyList extends cdktn.ComplexList {
        internalValue?: RepresentationsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RepresentationsPropertyOutputReference;
    }
    interface ViewDefinitionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#definer TfCatalogTable#definer}
        */
        readonly definer?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#is_protected TfCatalogTable#is_protected}
        */
        readonly isProtected?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#last_refresh_type TfCatalogTable#last_refresh_type}
        */
        readonly lastRefreshType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#refresh_seconds TfCatalogTable#refresh_seconds}
        */
        readonly refreshSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#sub_object_version_ids TfCatalogTable#sub_object_version_ids}
        */
        readonly subObjectVersionIds?: number[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#sub_objects TfCatalogTable#sub_objects}
        */
        readonly subObjects?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#view_version_id TfCatalogTable#view_version_id}
        */
        readonly viewVersionId?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#view_version_token TfCatalogTable#view_version_token}
        */
        readonly viewVersionToken?: string;
        /**
        * representations block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#representations TfCatalogTable#representations}
        */
        readonly representations?: RepresentationsProperty[] | cdktn.IResolvable;
    }
    class ViewDefinitionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ViewDefinitionProperty | undefined;
        set internalValue(value: ViewDefinitionProperty | undefined);
        private _definer?;
        get definer(): string;
        set definer(value: string);
        resetDefiner(): void;
        get definerInput(): string | undefined;
        private _isProtected?;
        get isProtected(): boolean | cdktn.IResolvable;
        set isProtected(value: boolean | cdktn.IResolvable);
        resetIsProtected(): void;
        get isProtectedInput(): boolean | cdktn.IResolvable | undefined;
        private _lastRefreshType?;
        get lastRefreshType(): string;
        set lastRefreshType(value: string);
        resetLastRefreshType(): void;
        get lastRefreshTypeInput(): string | undefined;
        private _refreshSeconds?;
        get refreshSeconds(): number;
        set refreshSeconds(value: number);
        resetRefreshSeconds(): void;
        get refreshSecondsInput(): number | undefined;
        private _subObjectVersionIds?;
        get subObjectVersionIds(): number[];
        set subObjectVersionIds(value: number[]);
        resetSubObjectVersionIds(): void;
        get subObjectVersionIdsInput(): number[] | undefined;
        private _subObjects?;
        get subObjects(): string[];
        set subObjects(value: string[]);
        resetSubObjects(): void;
        get subObjectsInput(): string[] | undefined;
        private _viewVersionId?;
        get viewVersionId(): number;
        set viewVersionId(value: number);
        resetViewVersionId(): void;
        get viewVersionIdInput(): number | undefined;
        private _viewVersionToken?;
        get viewVersionToken(): string;
        set viewVersionToken(value: string);
        resetViewVersionToken(): void;
        get viewVersionTokenInput(): string | undefined;
        private _representations;
        get representations(): RepresentationsPropertyList;
        putRepresentations(value: RepresentationsProperty[] | cdktn.IResolvable): void;
        resetRepresentations(): void;
        get representationsInput(): cdktn.IResolvable | RepresentationsProperty[] | undefined;
    }
}
