import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfTriggerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_trigger#description TfTrigger#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_trigger#enabled TfTrigger#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_trigger#id TfTrigger#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_trigger#name TfTrigger#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_trigger#region TfTrigger#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_trigger#schedule TfTrigger#schedule}
    */
    readonly schedule?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_trigger#start_on_creation TfTrigger#start_on_creation}
    */
    readonly startOnCreation?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_trigger#tags TfTrigger#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_trigger#tags_all TfTrigger#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_trigger#type TfTrigger#type}
    */
    readonly type: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_trigger#workflow_name TfTrigger#workflow_name}
    */
    readonly workflowName?: string;
    /**
    * actions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_trigger#actions TfTrigger#actions}
    */
    readonly actions: TfTrigger.ActionsProperty[] | cdktn.IResolvable;
    /**
    * event_batching_condition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_trigger#event_batching_condition TfTrigger#event_batching_condition}
    */
    readonly eventBatchingCondition?: TfTrigger.EventBatchingConditionProperty[] | cdktn.IResolvable;
    /**
    * predicate block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_trigger#predicate TfTrigger#predicate}
    */
    readonly predicate?: TfTrigger.PredicateProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_trigger#timeouts TfTrigger#timeouts}
    */
    readonly timeouts?: TfTrigger.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_trigger aws_glue_trigger}
*/
export declare class TfTrigger extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_glue_trigger";
    /**
    * Generates CDKTN code for importing a TfTrigger resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfTrigger to import
    * @param importFromId The id of the existing TfTrigger that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_trigger#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfTrigger to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_trigger aws_glue_trigger} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfTriggerConfig
    */
    constructor(scope: Construct, id: string, config: TfTriggerConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _schedule?;
    get schedule(): string;
    set schedule(value: string);
    resetSchedule(): void;
    get scheduleInput(): string | undefined;
    private _startOnCreation?;
    get startOnCreation(): boolean | cdktn.IResolvable;
    set startOnCreation(value: boolean | cdktn.IResolvable);
    resetStartOnCreation(): void;
    get startOnCreationInput(): boolean | cdktn.IResolvable | undefined;
    get state(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _workflowName?;
    get workflowName(): string;
    set workflowName(value: string);
    resetWorkflowName(): void;
    get workflowNameInput(): string | undefined;
    private _actions;
    get actions(): TfTrigger.ActionsPropertyList;
    putActions(value: TfTrigger.ActionsProperty[] | cdktn.IResolvable): void;
    get actionsInput(): cdktn.IResolvable | TfTrigger.ActionsProperty[] | undefined;
    private _eventBatchingCondition;
    get eventBatchingCondition(): TfTrigger.EventBatchingConditionPropertyList;
    putEventBatchingCondition(value: TfTrigger.EventBatchingConditionProperty[] | cdktn.IResolvable): void;
    resetEventBatchingCondition(): void;
    get eventBatchingConditionInput(): cdktn.IResolvable | TfTrigger.EventBatchingConditionProperty[] | undefined;
    private _predicate;
    get predicate(): TfTrigger.PredicatePropertyOutputReference;
    putPredicate(value: TfTrigger.PredicateProperty): void;
    resetPredicate(): void;
    get predicateInput(): TfTrigger.PredicateProperty | undefined;
    private _timeouts;
    get timeouts(): TfTrigger.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfTrigger.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfTrigger.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfTriggerNotificationPropertyPropertyToTerraform(struct?: TfTrigger.NotificationPropertyPropertyOutputReference | TfTrigger.NotificationPropertyProperty): any;
export declare function tfTriggerNotificationPropertyPropertyToHclTerraform(struct?: TfTrigger.NotificationPropertyPropertyOutputReference | TfTrigger.NotificationPropertyProperty): any;
export declare function tfTriggerActionsPropertyToTerraform(struct?: TfTrigger.ActionsProperty | cdktn.IResolvable): any;
export declare function tfTriggerActionsPropertyToHclTerraform(struct?: TfTrigger.ActionsProperty | cdktn.IResolvable): any;
export declare function tfTriggerEventBatchingConditionPropertyToTerraform(struct?: TfTrigger.EventBatchingConditionProperty | cdktn.IResolvable): any;
export declare function tfTriggerEventBatchingConditionPropertyToHclTerraform(struct?: TfTrigger.EventBatchingConditionProperty | cdktn.IResolvable): any;
export declare function tfTriggerConditionsPropertyToTerraform(struct?: TfTrigger.ConditionsProperty | cdktn.IResolvable): any;
export declare function tfTriggerConditionsPropertyToHclTerraform(struct?: TfTrigger.ConditionsProperty | cdktn.IResolvable): any;
export declare function tfTriggerPredicatePropertyToTerraform(struct?: TfTrigger.PredicatePropertyOutputReference | TfTrigger.PredicateProperty): any;
export declare function tfTriggerPredicatePropertyToHclTerraform(struct?: TfTrigger.PredicatePropertyOutputReference | TfTrigger.PredicateProperty): any;
export declare function tfTriggerTimeoutsPropertyToTerraform(struct?: TfTrigger.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfTriggerTimeoutsPropertyToHclTerraform(struct?: TfTrigger.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfTrigger {
    interface NotificationPropertyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_trigger#notify_delay_after TfTrigger#notify_delay_after}
        */
        readonly notifyDelayAfter?: number;
    }
    class NotificationPropertyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NotificationPropertyProperty | undefined;
        set internalValue(value: NotificationPropertyProperty | undefined);
        private _notifyDelayAfter?;
        get notifyDelayAfter(): number;
        set notifyDelayAfter(value: number);
        resetNotifyDelayAfter(): void;
        get notifyDelayAfterInput(): number | undefined;
    }
    interface ActionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_trigger#arguments TfTrigger#arguments}
        */
        readonly arguments?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_trigger#crawler_name TfTrigger#crawler_name}
        */
        readonly crawlerName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_trigger#job_name TfTrigger#job_name}
        */
        readonly jobName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_trigger#security_configuration TfTrigger#security_configuration}
        */
        readonly securityConfiguration?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_trigger#timeout TfTrigger#timeout}
        */
        readonly timeout?: number;
        /**
        * notification_property block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_trigger#notification_property TfTrigger#notification_property}
        */
        readonly notificationProperty?: NotificationPropertyProperty;
    }
    class ActionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ActionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ActionsProperty | cdktn.IResolvable | undefined);
        private _arguments?;
        get arguments(): {
            [key: string]: string;
        };
        set arguments(value: {
            [key: string]: string;
        });
        resetArguments(): void;
        get argumentsInput(): {
            [key: string]: string;
        } | undefined;
        private _crawlerName?;
        get crawlerName(): string;
        set crawlerName(value: string);
        resetCrawlerName(): void;
        get crawlerNameInput(): string | undefined;
        private _jobName?;
        get jobName(): string;
        set jobName(value: string);
        resetJobName(): void;
        get jobNameInput(): string | undefined;
        private _securityConfiguration?;
        get securityConfiguration(): string;
        set securityConfiguration(value: string);
        resetSecurityConfiguration(): void;
        get securityConfigurationInput(): string | undefined;
        private _timeout?;
        get timeout(): number;
        set timeout(value: number);
        resetTimeout(): void;
        get timeoutInput(): number | undefined;
        private _notificationProperty;
        get notificationProperty(): NotificationPropertyPropertyOutputReference;
        putNotificationProperty(value: NotificationPropertyProperty): void;
        resetNotificationProperty(): void;
        get notificationPropertyInput(): NotificationPropertyProperty | undefined;
    }
    class ActionsPropertyList extends cdktn.ComplexList {
        internalValue?: ActionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ActionsPropertyOutputReference;
    }
    interface EventBatchingConditionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_trigger#batch_size TfTrigger#batch_size}
        */
        readonly batchSize: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_trigger#batch_window TfTrigger#batch_window}
        */
        readonly batchWindow?: number;
    }
    class EventBatchingConditionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EventBatchingConditionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EventBatchingConditionProperty | cdktn.IResolvable | undefined);
        private _batchSize?;
        get batchSize(): number;
        set batchSize(value: number);
        get batchSizeInput(): number | undefined;
        private _batchWindow?;
        get batchWindow(): number;
        set batchWindow(value: number);
        resetBatchWindow(): void;
        get batchWindowInput(): number | undefined;
    }
    class EventBatchingConditionPropertyList extends cdktn.ComplexList {
        internalValue?: EventBatchingConditionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EventBatchingConditionPropertyOutputReference;
    }
    interface ConditionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_trigger#crawl_state TfTrigger#crawl_state}
        */
        readonly crawlState?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_trigger#crawler_name TfTrigger#crawler_name}
        */
        readonly crawlerName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_trigger#job_name TfTrigger#job_name}
        */
        readonly jobName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_trigger#logical_operator TfTrigger#logical_operator}
        */
        readonly logicalOperator?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_trigger#state TfTrigger#state}
        */
        readonly state?: string;
    }
    class ConditionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConditionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConditionsProperty | cdktn.IResolvable | undefined);
        private _crawlState?;
        get crawlState(): string;
        set crawlState(value: string);
        resetCrawlState(): void;
        get crawlStateInput(): string | undefined;
        private _crawlerName?;
        get crawlerName(): string;
        set crawlerName(value: string);
        resetCrawlerName(): void;
        get crawlerNameInput(): string | undefined;
        private _jobName?;
        get jobName(): string;
        set jobName(value: string);
        resetJobName(): void;
        get jobNameInput(): string | undefined;
        private _logicalOperator?;
        get logicalOperator(): string;
        set logicalOperator(value: string);
        resetLogicalOperator(): void;
        get logicalOperatorInput(): string | undefined;
        private _state?;
        get state(): string;
        set state(value: string);
        resetState(): void;
        get stateInput(): string | undefined;
    }
    class ConditionsPropertyList extends cdktn.ComplexList {
        internalValue?: ConditionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConditionsPropertyOutputReference;
    }
    interface PredicateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_trigger#logical TfTrigger#logical}
        */
        readonly logical?: string;
        /**
        * conditions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_trigger#conditions TfTrigger#conditions}
        */
        readonly conditions: ConditionsProperty[] | cdktn.IResolvable;
    }
    class PredicatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PredicateProperty | undefined;
        set internalValue(value: PredicateProperty | undefined);
        private _logical?;
        get logical(): string;
        set logical(value: string);
        resetLogical(): void;
        get logicalInput(): string | undefined;
        private _conditions;
        get conditions(): ConditionsPropertyList;
        putConditions(value: ConditionsProperty[] | cdktn.IResolvable): void;
        get conditionsInput(): cdktn.IResolvable | ConditionsProperty[] | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_trigger#create TfTrigger#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_trigger#delete TfTrigger#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_trigger#update TfTrigger#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
