import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfCatalogConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/glue_catalog#name DataTfCatalog#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/glue_catalog#region DataTfCatalog#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/glue_catalog aws_glue_catalog}
*/
export declare class DataTfCatalog extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_glue_catalog";
    /**
    * Generates CDKTN code for importing a DataTfCatalog resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfCatalog to import
    * @param importFromId The id of the existing DataTfCatalog that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/glue_catalog#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfCatalog to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/glue_catalog aws_glue_catalog} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfCatalogConfig
    */
    constructor(scope: Construct, id: string, config: DataTfCatalogConfig);
    get allowFullTableExternalDataAccess(): string;
    get arn(): string;
    get catalogId(): string;
    private _catalogProperties;
    get catalogProperties(): DataTfCatalog.CatalogPropertiesPropertyList;
    private _createDatabaseDefaultPermissions;
    get createDatabaseDefaultPermissions(): DataTfCatalog.CreateDatabaseDefaultPermissionsPropertyList;
    private _createTableDefaultPermissions;
    get createTableDefaultPermissions(): DataTfCatalog.CreateTableDefaultPermissionsPropertyList;
    get createTime(): string;
    get description(): string;
    private _federatedCatalog;
    get federatedCatalog(): DataTfCatalog.FederatedCatalogPropertyList;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parameters;
    get parameters(): cdktn.StringMap;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags;
    get tags(): cdktn.StringMap;
    private _targetRedshiftCatalog;
    get targetRedshiftCatalog(): DataTfCatalog.TargetRedshiftCatalogPropertyList;
    get updateTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfCatalogDataLakeAccessPropertiesPropertyToTerraform(struct?: DataTfCatalog.DataLakeAccessPropertiesProperty): any;
export declare function dataTfCatalogDataLakeAccessPropertiesPropertyToHclTerraform(struct?: DataTfCatalog.DataLakeAccessPropertiesProperty): any;
export declare function dataTfCatalogIcebergOptimizationPropertiesPropertyToTerraform(struct?: DataTfCatalog.IcebergOptimizationPropertiesProperty): any;
export declare function dataTfCatalogIcebergOptimizationPropertiesPropertyToHclTerraform(struct?: DataTfCatalog.IcebergOptimizationPropertiesProperty): any;
export declare function dataTfCatalogCatalogPropertiesPropertyToTerraform(struct?: DataTfCatalog.CatalogPropertiesProperty): any;
export declare function dataTfCatalogCatalogPropertiesPropertyToHclTerraform(struct?: DataTfCatalog.CatalogPropertiesProperty): any;
export declare function dataTfCatalogCreateDatabaseDefaultPermissionsPrincipalPropertyToTerraform(struct?: DataTfCatalog.CreateDatabaseDefaultPermissionsPrincipalProperty): any;
export declare function dataTfCatalogCreateDatabaseDefaultPermissionsPrincipalPropertyToHclTerraform(struct?: DataTfCatalog.CreateDatabaseDefaultPermissionsPrincipalProperty): any;
export declare function dataTfCatalogCreateDatabaseDefaultPermissionsPropertyToTerraform(struct?: DataTfCatalog.CreateDatabaseDefaultPermissionsProperty): any;
export declare function dataTfCatalogCreateDatabaseDefaultPermissionsPropertyToHclTerraform(struct?: DataTfCatalog.CreateDatabaseDefaultPermissionsProperty): any;
export declare function dataTfCatalogCreateTableDefaultPermissionsPrincipalPropertyToTerraform(struct?: DataTfCatalog.CreateTableDefaultPermissionsPrincipalProperty): any;
export declare function dataTfCatalogCreateTableDefaultPermissionsPrincipalPropertyToHclTerraform(struct?: DataTfCatalog.CreateTableDefaultPermissionsPrincipalProperty): any;
export declare function dataTfCatalogCreateTableDefaultPermissionsPropertyToTerraform(struct?: DataTfCatalog.CreateTableDefaultPermissionsProperty): any;
export declare function dataTfCatalogCreateTableDefaultPermissionsPropertyToHclTerraform(struct?: DataTfCatalog.CreateTableDefaultPermissionsProperty): any;
export declare function dataTfCatalogFederatedCatalogPropertyToTerraform(struct?: DataTfCatalog.FederatedCatalogProperty): any;
export declare function dataTfCatalogFederatedCatalogPropertyToHclTerraform(struct?: DataTfCatalog.FederatedCatalogProperty): any;
export declare function dataTfCatalogTargetRedshiftCatalogPropertyToTerraform(struct?: DataTfCatalog.TargetRedshiftCatalogProperty): any;
export declare function dataTfCatalogTargetRedshiftCatalogPropertyToHclTerraform(struct?: DataTfCatalog.TargetRedshiftCatalogProperty): any;
export declare namespace DataTfCatalog {
    interface DataLakeAccessPropertiesProperty {
    }
    class DataLakeAccessPropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataLakeAccessPropertiesProperty | undefined;
        set internalValue(value: DataLakeAccessPropertiesProperty | undefined);
        get catalogType(): string;
        get dataLakeAccess(): cdktn.IResolvable;
        get dataTransferRole(): string;
        get kmsKey(): string;
        get managedWorkgroupName(): string;
        get managedWorkgroupStatus(): string;
        get redshiftDatabaseName(): string;
        get statusMessage(): string;
    }
    class DataLakeAccessPropertiesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataLakeAccessPropertiesPropertyOutputReference;
    }
    interface IcebergOptimizationPropertiesProperty {
    }
    class IcebergOptimizationPropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IcebergOptimizationPropertiesProperty | undefined;
        set internalValue(value: IcebergOptimizationPropertiesProperty | undefined);
        private _compaction;
        get compaction(): cdktn.StringMap;
        private _orphanFileDeletion;
        get orphanFileDeletion(): cdktn.StringMap;
        private _retention;
        get retention(): cdktn.StringMap;
        get roleArn(): string;
    }
    class IcebergOptimizationPropertiesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IcebergOptimizationPropertiesPropertyOutputReference;
    }
    interface CatalogPropertiesProperty {
    }
    class CatalogPropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CatalogPropertiesProperty | undefined;
        set internalValue(value: CatalogPropertiesProperty | undefined);
        private _customProperties;
        get customProperties(): cdktn.StringMap;
        private _dataLakeAccessProperties;
        get dataLakeAccessProperties(): DataLakeAccessPropertiesPropertyList;
        private _icebergOptimizationProperties;
        get icebergOptimizationProperties(): IcebergOptimizationPropertiesPropertyList;
    }
    class CatalogPropertiesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CatalogPropertiesPropertyOutputReference;
    }
    interface CreateDatabaseDefaultPermissionsPrincipalProperty {
    }
    class CreateDatabaseDefaultPermissionsPrincipalPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CreateDatabaseDefaultPermissionsPrincipalProperty | undefined;
        set internalValue(value: CreateDatabaseDefaultPermissionsPrincipalProperty | undefined);
        get dataLakePrincipalIdentifier(): string;
    }
    class CreateDatabaseDefaultPermissionsPrincipalPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CreateDatabaseDefaultPermissionsPrincipalPropertyOutputReference;
    }
    interface CreateDatabaseDefaultPermissionsProperty {
    }
    class CreateDatabaseDefaultPermissionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CreateDatabaseDefaultPermissionsProperty | undefined;
        set internalValue(value: CreateDatabaseDefaultPermissionsProperty | undefined);
        get permissions(): string[];
        private _principal;
        get principal(): CreateDatabaseDefaultPermissionsPrincipalPropertyList;
    }
    class CreateDatabaseDefaultPermissionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CreateDatabaseDefaultPermissionsPropertyOutputReference;
    }
    interface CreateTableDefaultPermissionsPrincipalProperty {
    }
    class CreateTableDefaultPermissionsPrincipalPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CreateTableDefaultPermissionsPrincipalProperty | undefined;
        set internalValue(value: CreateTableDefaultPermissionsPrincipalProperty | undefined);
        get dataLakePrincipalIdentifier(): string;
    }
    class CreateTableDefaultPermissionsPrincipalPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CreateTableDefaultPermissionsPrincipalPropertyOutputReference;
    }
    interface CreateTableDefaultPermissionsProperty {
    }
    class CreateTableDefaultPermissionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CreateTableDefaultPermissionsProperty | undefined;
        set internalValue(value: CreateTableDefaultPermissionsProperty | undefined);
        get permissions(): string[];
        private _principal;
        get principal(): CreateTableDefaultPermissionsPrincipalPropertyList;
    }
    class CreateTableDefaultPermissionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CreateTableDefaultPermissionsPropertyOutputReference;
    }
    interface FederatedCatalogProperty {
    }
    class FederatedCatalogPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FederatedCatalogProperty | undefined;
        set internalValue(value: FederatedCatalogProperty | undefined);
        get connectionName(): string;
        get connectionType(): string;
        get identifier(): string;
    }
    class FederatedCatalogPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FederatedCatalogPropertyOutputReference;
    }
    interface TargetRedshiftCatalogProperty {
    }
    class TargetRedshiftCatalogPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetRedshiftCatalogProperty | undefined;
        set internalValue(value: TargetRedshiftCatalogProperty | undefined);
        get catalogArn(): string;
    }
    class TargetRedshiftCatalogPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetRedshiftCatalogPropertyOutputReference;
    }
}
