import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfConnectionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_connection#athena_properties TfConnection#athena_properties}
    */
    readonly athenaProperties?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_connection#catalog_id TfConnection#catalog_id}
    */
    readonly catalogId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_connection#connection_properties TfConnection#connection_properties}
    */
    readonly connectionProperties?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_connection#connection_type TfConnection#connection_type}
    */
    readonly connectionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_connection#description TfConnection#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_connection#id TfConnection#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_connection#match_criteria TfConnection#match_criteria}
    */
    readonly matchCriteria?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_connection#name TfConnection#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_connection#region TfConnection#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_connection#tags TfConnection#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_connection#tags_all TfConnection#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * authentication_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_connection#authentication_configuration TfConnection#authentication_configuration}
    */
    readonly authenticationConfiguration?: TfConnection.AuthenticationConfigurationProperty;
    /**
    * physical_connection_requirements block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_connection#physical_connection_requirements TfConnection#physical_connection_requirements}
    */
    readonly physicalConnectionRequirements?: TfConnection.PhysicalConnectionRequirementsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_connection aws_glue_connection}
*/
export declare class TfConnection extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_glue_connection";
    /**
    * Generates CDKTN code for importing a TfConnection resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfConnection to import
    * @param importFromId The id of the existing TfConnection that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_connection#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfConnection to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_connection aws_glue_connection} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfConnectionConfig
    */
    constructor(scope: Construct, id: string, config: TfConnectionConfig);
    get arn(): string;
    private _athenaProperties?;
    get athenaProperties(): {
        [key: string]: string;
    };
    set athenaProperties(value: {
        [key: string]: string;
    });
    resetAthenaProperties(): void;
    get athenaPropertiesInput(): {
        [key: string]: string;
    } | undefined;
    private _catalogId?;
    get catalogId(): string;
    set catalogId(value: string);
    resetCatalogId(): void;
    get catalogIdInput(): string | undefined;
    private _connectionProperties?;
    get connectionProperties(): {
        [key: string]: string;
    };
    set connectionProperties(value: {
        [key: string]: string;
    });
    resetConnectionProperties(): void;
    get connectionPropertiesInput(): {
        [key: string]: string;
    } | undefined;
    private _connectionType?;
    get connectionType(): string;
    set connectionType(value: string);
    resetConnectionType(): void;
    get connectionTypeInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _matchCriteria?;
    get matchCriteria(): string[];
    set matchCriteria(value: string[]);
    resetMatchCriteria(): void;
    get matchCriteriaInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _authenticationConfiguration;
    get authenticationConfiguration(): TfConnection.AuthenticationConfigurationPropertyOutputReference;
    putAuthenticationConfiguration(value: TfConnection.AuthenticationConfigurationProperty): void;
    resetAuthenticationConfiguration(): void;
    get authenticationConfigurationInput(): TfConnection.AuthenticationConfigurationProperty | undefined;
    private _physicalConnectionRequirements;
    get physicalConnectionRequirements(): TfConnection.PhysicalConnectionRequirementsPropertyOutputReference;
    putPhysicalConnectionRequirements(value: TfConnection.PhysicalConnectionRequirementsProperty): void;
    resetPhysicalConnectionRequirements(): void;
    get physicalConnectionRequirementsInput(): TfConnection.PhysicalConnectionRequirementsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfConnectionBasicAuthenticationCredentialsPropertyToTerraform(struct?: TfConnection.BasicAuthenticationCredentialsPropertyOutputReference | TfConnection.BasicAuthenticationCredentialsProperty): any;
export declare function tfConnectionBasicAuthenticationCredentialsPropertyToHclTerraform(struct?: TfConnection.BasicAuthenticationCredentialsPropertyOutputReference | TfConnection.BasicAuthenticationCredentialsProperty): any;
export declare function tfConnectionAuthorizationCodePropertiesPropertyToTerraform(struct?: TfConnection.AuthorizationCodePropertiesPropertyOutputReference | TfConnection.AuthorizationCodePropertiesProperty): any;
export declare function tfConnectionAuthorizationCodePropertiesPropertyToHclTerraform(struct?: TfConnection.AuthorizationCodePropertiesPropertyOutputReference | TfConnection.AuthorizationCodePropertiesProperty): any;
export declare function tfConnectionOauth2ClientApplicationPropertyToTerraform(struct?: TfConnection.Oauth2ClientApplicationPropertyOutputReference | TfConnection.Oauth2ClientApplicationProperty): any;
export declare function tfConnectionOauth2ClientApplicationPropertyToHclTerraform(struct?: TfConnection.Oauth2ClientApplicationPropertyOutputReference | TfConnection.Oauth2ClientApplicationProperty): any;
export declare function tfConnectionOauth2CredentialsPropertyToTerraform(struct?: TfConnection.Oauth2CredentialsPropertyOutputReference | TfConnection.Oauth2CredentialsProperty): any;
export declare function tfConnectionOauth2CredentialsPropertyToHclTerraform(struct?: TfConnection.Oauth2CredentialsPropertyOutputReference | TfConnection.Oauth2CredentialsProperty): any;
export declare function tfConnectionOauth2PropertiesPropertyToTerraform(struct?: TfConnection.Oauth2PropertiesPropertyOutputReference | TfConnection.Oauth2PropertiesProperty): any;
export declare function tfConnectionOauth2PropertiesPropertyToHclTerraform(struct?: TfConnection.Oauth2PropertiesPropertyOutputReference | TfConnection.Oauth2PropertiesProperty): any;
export declare function tfConnectionAuthenticationConfigurationPropertyToTerraform(struct?: TfConnection.AuthenticationConfigurationPropertyOutputReference | TfConnection.AuthenticationConfigurationProperty): any;
export declare function tfConnectionAuthenticationConfigurationPropertyToHclTerraform(struct?: TfConnection.AuthenticationConfigurationPropertyOutputReference | TfConnection.AuthenticationConfigurationProperty): any;
export declare function tfConnectionPhysicalConnectionRequirementsPropertyToTerraform(struct?: TfConnection.PhysicalConnectionRequirementsPropertyOutputReference | TfConnection.PhysicalConnectionRequirementsProperty): any;
export declare function tfConnectionPhysicalConnectionRequirementsPropertyToHclTerraform(struct?: TfConnection.PhysicalConnectionRequirementsPropertyOutputReference | TfConnection.PhysicalConnectionRequirementsProperty): any;
export declare namespace TfConnection {
    interface BasicAuthenticationCredentialsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_connection#password TfConnection#password}
        */
        readonly password: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_connection#username TfConnection#username}
        */
        readonly username: string;
    }
    class BasicAuthenticationCredentialsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BasicAuthenticationCredentialsProperty | undefined;
        set internalValue(value: BasicAuthenticationCredentialsProperty | undefined);
        private _password?;
        get password(): string;
        set password(value: string);
        get passwordInput(): string | undefined;
        private _username?;
        get username(): string;
        set username(value: string);
        get usernameInput(): string | undefined;
    }
    interface AuthorizationCodePropertiesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_connection#authorization_code TfConnection#authorization_code}
        */
        readonly authorizationCode: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_connection#redirect_uri TfConnection#redirect_uri}
        */
        readonly redirectUri: string;
    }
    class AuthorizationCodePropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AuthorizationCodePropertiesProperty | undefined;
        set internalValue(value: AuthorizationCodePropertiesProperty | undefined);
        private _authorizationCode?;
        get authorizationCode(): string;
        set authorizationCode(value: string);
        get authorizationCodeInput(): string | undefined;
        private _redirectUri?;
        get redirectUri(): string;
        set redirectUri(value: string);
        get redirectUriInput(): string | undefined;
    }
    interface Oauth2ClientApplicationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_connection#aws_managed_client_application_reference TfConnection#aws_managed_client_application_reference}
        */
        readonly awsManagedClientApplicationReference?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_connection#user_managed_client_application_client_id TfConnection#user_managed_client_application_client_id}
        */
        readonly userManagedClientApplicationClientId?: string;
    }
    class Oauth2ClientApplicationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): Oauth2ClientApplicationProperty | undefined;
        set internalValue(value: Oauth2ClientApplicationProperty | undefined);
        private _awsManagedClientApplicationReference?;
        get awsManagedClientApplicationReference(): string;
        set awsManagedClientApplicationReference(value: string);
        resetAwsManagedClientApplicationReference(): void;
        get awsManagedClientApplicationReferenceInput(): string | undefined;
        private _userManagedClientApplicationClientId?;
        get userManagedClientApplicationClientId(): string;
        set userManagedClientApplicationClientId(value: string);
        resetUserManagedClientApplicationClientId(): void;
        get userManagedClientApplicationClientIdInput(): string | undefined;
    }
    interface Oauth2CredentialsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_connection#access_token TfConnection#access_token}
        */
        readonly accessToken?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_connection#jwt_token TfConnection#jwt_token}
        */
        readonly jwtToken?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_connection#refresh_token TfConnection#refresh_token}
        */
        readonly refreshToken?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_connection#user_managed_client_application_client_secret TfConnection#user_managed_client_application_client_secret}
        */
        readonly userManagedClientApplicationClientSecret?: string;
    }
    class Oauth2CredentialsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): Oauth2CredentialsProperty | undefined;
        set internalValue(value: Oauth2CredentialsProperty | undefined);
        private _accessToken?;
        get accessToken(): string;
        set accessToken(value: string);
        resetAccessToken(): void;
        get accessTokenInput(): string | undefined;
        private _jwtToken?;
        get jwtToken(): string;
        set jwtToken(value: string);
        resetJwtToken(): void;
        get jwtTokenInput(): string | undefined;
        private _refreshToken?;
        get refreshToken(): string;
        set refreshToken(value: string);
        resetRefreshToken(): void;
        get refreshTokenInput(): string | undefined;
        private _userManagedClientApplicationClientSecret?;
        get userManagedClientApplicationClientSecret(): string;
        set userManagedClientApplicationClientSecret(value: string);
        resetUserManagedClientApplicationClientSecret(): void;
        get userManagedClientApplicationClientSecretInput(): string | undefined;
    }
    interface Oauth2PropertiesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_connection#oauth2_grant_type TfConnection#oauth2_grant_type}
        */
        readonly oauth2GrantType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_connection#token_url TfConnection#token_url}
        */
        readonly tokenUrl?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_connection#token_url_parameters_map TfConnection#token_url_parameters_map}
        */
        readonly tokenUrlParametersMap?: {
            [key: string]: string;
        };
        /**
        * authorization_code_properties block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_connection#authorization_code_properties TfConnection#authorization_code_properties}
        */
        readonly authorizationCodeProperties?: AuthorizationCodePropertiesProperty;
        /**
        * oauth2_client_application block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_connection#oauth2_client_application TfConnection#oauth2_client_application}
        */
        readonly oauth2ClientApplication?: Oauth2ClientApplicationProperty;
        /**
        * oauth2_credentials block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_connection#oauth2_credentials TfConnection#oauth2_credentials}
        */
        readonly oauth2Credentials?: Oauth2CredentialsProperty;
    }
    class Oauth2PropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): Oauth2PropertiesProperty | undefined;
        set internalValue(value: Oauth2PropertiesProperty | undefined);
        private _oauth2GrantType?;
        get oauth2GrantType(): string;
        set oauth2GrantType(value: string);
        resetOauth2GrantType(): void;
        get oauth2GrantTypeInput(): string | undefined;
        private _tokenUrl?;
        get tokenUrl(): string;
        set tokenUrl(value: string);
        resetTokenUrl(): void;
        get tokenUrlInput(): string | undefined;
        private _tokenUrlParametersMap?;
        get tokenUrlParametersMap(): {
            [key: string]: string;
        };
        set tokenUrlParametersMap(value: {
            [key: string]: string;
        });
        resetTokenUrlParametersMap(): void;
        get tokenUrlParametersMapInput(): {
            [key: string]: string;
        } | undefined;
        private _authorizationCodeProperties;
        get authorizationCodeProperties(): AuthorizationCodePropertiesPropertyOutputReference;
        putAuthorizationCodeProperties(value: AuthorizationCodePropertiesProperty): void;
        resetAuthorizationCodeProperties(): void;
        get authorizationCodePropertiesInput(): AuthorizationCodePropertiesProperty | undefined;
        private _oauth2ClientApplication;
        get oauth2ClientApplication(): Oauth2ClientApplicationPropertyOutputReference;
        putOauth2ClientApplication(value: Oauth2ClientApplicationProperty): void;
        resetOauth2ClientApplication(): void;
        get oauth2ClientApplicationInput(): Oauth2ClientApplicationProperty | undefined;
        private _oauth2Credentials;
        get oauth2Credentials(): Oauth2CredentialsPropertyOutputReference;
        putOauth2Credentials(value: Oauth2CredentialsProperty): void;
        resetOauth2Credentials(): void;
        get oauth2CredentialsInput(): Oauth2CredentialsProperty | undefined;
    }
    interface AuthenticationConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_connection#authentication_type TfConnection#authentication_type}
        */
        readonly authenticationType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_connection#custom_authentication_credentials TfConnection#custom_authentication_credentials}
        */
        readonly customAuthenticationCredentials?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_connection#kms_key_arn TfConnection#kms_key_arn}
        */
        readonly kmsKeyArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_connection#secret_arn TfConnection#secret_arn}
        */
        readonly secretArn?: string;
        /**
        * basic_authentication_credentials block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_connection#basic_authentication_credentials TfConnection#basic_authentication_credentials}
        */
        readonly basicAuthenticationCredentials?: BasicAuthenticationCredentialsProperty;
        /**
        * oauth2_properties block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_connection#oauth2_properties TfConnection#oauth2_properties}
        */
        readonly oauth2Properties?: Oauth2PropertiesProperty;
    }
    class AuthenticationConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AuthenticationConfigurationProperty | undefined;
        set internalValue(value: AuthenticationConfigurationProperty | undefined);
        private _authenticationType?;
        get authenticationType(): string;
        set authenticationType(value: string);
        get authenticationTypeInput(): string | undefined;
        private _customAuthenticationCredentials?;
        get customAuthenticationCredentials(): {
            [key: string]: string;
        };
        set customAuthenticationCredentials(value: {
            [key: string]: string;
        });
        resetCustomAuthenticationCredentials(): void;
        get customAuthenticationCredentialsInput(): {
            [key: string]: string;
        } | undefined;
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        resetKmsKeyArn(): void;
        get kmsKeyArnInput(): string | undefined;
        private _secretArn?;
        get secretArn(): string;
        set secretArn(value: string);
        resetSecretArn(): void;
        get secretArnInput(): string | undefined;
        private _basicAuthenticationCredentials;
        get basicAuthenticationCredentials(): BasicAuthenticationCredentialsPropertyOutputReference;
        putBasicAuthenticationCredentials(value: BasicAuthenticationCredentialsProperty): void;
        resetBasicAuthenticationCredentials(): void;
        get basicAuthenticationCredentialsInput(): BasicAuthenticationCredentialsProperty | undefined;
        private _oauth2Properties;
        get oauth2Properties(): Oauth2PropertiesPropertyOutputReference;
        putOauth2Properties(value: Oauth2PropertiesProperty): void;
        resetOauth2Properties(): void;
        get oauth2PropertiesInput(): Oauth2PropertiesProperty | undefined;
    }
    interface PhysicalConnectionRequirementsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_connection#availability_zone TfConnection#availability_zone}
        */
        readonly availabilityZone?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_connection#security_group_id_list TfConnection#security_group_id_list}
        */
        readonly securityGroupIdList?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_connection#subnet_id TfConnection#subnet_id}
        */
        readonly subnetId?: string;
    }
    class PhysicalConnectionRequirementsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PhysicalConnectionRequirementsProperty | undefined;
        set internalValue(value: PhysicalConnectionRequirementsProperty | undefined);
        private _availabilityZone?;
        get availabilityZone(): string;
        set availabilityZone(value: string);
        resetAvailabilityZone(): void;
        get availabilityZoneInput(): string | undefined;
        private _securityGroupIdList?;
        get securityGroupIdList(): string[];
        set securityGroupIdList(value: string[]);
        resetSecurityGroupIdList(): void;
        get securityGroupIdListInput(): string[] | undefined;
        private _subnetId?;
        get subnetId(): string;
        set subnetId(value: string);
        resetSubnetId(): void;
        get subnetIdInput(): string | undefined;
    }
}
