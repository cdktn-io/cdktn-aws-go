import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfCatalogConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog#allow_full_table_external_data_access TfCatalog#allow_full_table_external_data_access}
    */
    readonly allowFullTableExternalDataAccess?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog#description TfCatalog#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog#name TfCatalog#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog#overwrite_child_resource_permissions_with_default TfCatalog#overwrite_child_resource_permissions_with_default}
    */
    readonly overwriteChildResourcePermissionsWithDefault?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog#parameters TfCatalog#parameters}
    */
    readonly parameters?: {
        [key: string]: string;
    };
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog#region TfCatalog#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog#tags TfCatalog#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * catalog_properties block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog#catalog_properties TfCatalog#catalog_properties}
    */
    readonly catalogProperties?: TfCatalog.CatalogPropertiesProperty[] | cdktn.IResolvable;
    /**
    * create_database_default_permissions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog#create_database_default_permissions TfCatalog#create_database_default_permissions}
    */
    readonly createDatabaseDefaultPermissions?: TfCatalog.CreateDatabaseDefaultPermissionsProperty[] | cdktn.IResolvable;
    /**
    * create_table_default_permissions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog#create_table_default_permissions TfCatalog#create_table_default_permissions}
    */
    readonly createTableDefaultPermissions?: TfCatalog.CreateTableDefaultPermissionsProperty[] | cdktn.IResolvable;
    /**
    * federated_catalog block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog#federated_catalog TfCatalog#federated_catalog}
    */
    readonly federatedCatalog?: TfCatalog.FederatedCatalogProperty[] | cdktn.IResolvable;
    /**
    * target_redshift_catalog block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog#target_redshift_catalog TfCatalog#target_redshift_catalog}
    */
    readonly targetRedshiftCatalog?: TfCatalog.TargetRedshiftCatalogProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog#timeouts TfCatalog#timeouts}
    */
    readonly timeouts?: TfCatalog.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog aws_glue_catalog}
*/
export declare class TfCatalog extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_glue_catalog";
    /**
    * Generates CDKTN code for importing a TfCatalog resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfCatalog to import
    * @param importFromId The id of the existing TfCatalog that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfCatalog to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog aws_glue_catalog} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfCatalogConfig
    */
    constructor(scope: Construct, id: string, config: TfCatalogConfig);
    private _allowFullTableExternalDataAccess?;
    get allowFullTableExternalDataAccess(): string;
    set allowFullTableExternalDataAccess(value: string);
    resetAllowFullTableExternalDataAccess(): void;
    get allowFullTableExternalDataAccessInput(): string | undefined;
    get arn(): string;
    get catalogId(): string;
    get createTime(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _overwriteChildResourcePermissionsWithDefault?;
    get overwriteChildResourcePermissionsWithDefault(): string;
    set overwriteChildResourcePermissionsWithDefault(value: string);
    resetOverwriteChildResourcePermissionsWithDefault(): void;
    get overwriteChildResourcePermissionsWithDefaultInput(): string | undefined;
    private _parameters?;
    get parameters(): {
        [key: string]: string;
    };
    set parameters(value: {
        [key: string]: string;
    });
    resetParameters(): void;
    get parametersInput(): {
        [key: string]: string;
    } | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    get updateTime(): string;
    private _catalogProperties;
    get catalogProperties(): TfCatalog.CatalogPropertiesPropertyList;
    putCatalogProperties(value: TfCatalog.CatalogPropertiesProperty[] | cdktn.IResolvable): void;
    resetCatalogProperties(): void;
    get catalogPropertiesInput(): cdktn.IResolvable | TfCatalog.CatalogPropertiesProperty[] | undefined;
    private _createDatabaseDefaultPermissions;
    get createDatabaseDefaultPermissions(): TfCatalog.CreateDatabaseDefaultPermissionsPropertyList;
    putCreateDatabaseDefaultPermissions(value: TfCatalog.CreateDatabaseDefaultPermissionsProperty[] | cdktn.IResolvable): void;
    resetCreateDatabaseDefaultPermissions(): void;
    get createDatabaseDefaultPermissionsInput(): cdktn.IResolvable | TfCatalog.CreateDatabaseDefaultPermissionsProperty[] | undefined;
    private _createTableDefaultPermissions;
    get createTableDefaultPermissions(): TfCatalog.CreateTableDefaultPermissionsPropertyList;
    putCreateTableDefaultPermissions(value: TfCatalog.CreateTableDefaultPermissionsProperty[] | cdktn.IResolvable): void;
    resetCreateTableDefaultPermissions(): void;
    get createTableDefaultPermissionsInput(): cdktn.IResolvable | TfCatalog.CreateTableDefaultPermissionsProperty[] | undefined;
    private _federatedCatalog;
    get federatedCatalog(): TfCatalog.FederatedCatalogPropertyList;
    putFederatedCatalog(value: TfCatalog.FederatedCatalogProperty[] | cdktn.IResolvable): void;
    resetFederatedCatalog(): void;
    get federatedCatalogInput(): cdktn.IResolvable | TfCatalog.FederatedCatalogProperty[] | undefined;
    private _targetRedshiftCatalog;
    get targetRedshiftCatalog(): TfCatalog.TargetRedshiftCatalogPropertyList;
    putTargetRedshiftCatalog(value: TfCatalog.TargetRedshiftCatalogProperty[] | cdktn.IResolvable): void;
    resetTargetRedshiftCatalog(): void;
    get targetRedshiftCatalogInput(): cdktn.IResolvable | TfCatalog.TargetRedshiftCatalogProperty[] | undefined;
    private _timeouts;
    get timeouts(): TfCatalog.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfCatalog.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfCatalog.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfCatalogDataLakeAccessPropertiesPropertyToTerraform(struct?: TfCatalog.DataLakeAccessPropertiesProperty | cdktn.IResolvable): any;
export declare function tfCatalogDataLakeAccessPropertiesPropertyToHclTerraform(struct?: TfCatalog.DataLakeAccessPropertiesProperty | cdktn.IResolvable): any;
export declare function tfCatalogIcebergOptimizationPropertiesPropertyToTerraform(struct?: TfCatalog.IcebergOptimizationPropertiesProperty | cdktn.IResolvable): any;
export declare function tfCatalogIcebergOptimizationPropertiesPropertyToHclTerraform(struct?: TfCatalog.IcebergOptimizationPropertiesProperty | cdktn.IResolvable): any;
export declare function tfCatalogCatalogPropertiesPropertyToTerraform(struct?: TfCatalog.CatalogPropertiesProperty | cdktn.IResolvable): any;
export declare function tfCatalogCatalogPropertiesPropertyToHclTerraform(struct?: TfCatalog.CatalogPropertiesProperty | cdktn.IResolvable): any;
export declare function tfCatalogCreateDatabaseDefaultPermissionsPrincipalPropertyToTerraform(struct?: TfCatalog.CreateDatabaseDefaultPermissionsPrincipalProperty | cdktn.IResolvable): any;
export declare function tfCatalogCreateDatabaseDefaultPermissionsPrincipalPropertyToHclTerraform(struct?: TfCatalog.CreateDatabaseDefaultPermissionsPrincipalProperty | cdktn.IResolvable): any;
export declare function tfCatalogCreateDatabaseDefaultPermissionsPropertyToTerraform(struct?: TfCatalog.CreateDatabaseDefaultPermissionsProperty | cdktn.IResolvable): any;
export declare function tfCatalogCreateDatabaseDefaultPermissionsPropertyToHclTerraform(struct?: TfCatalog.CreateDatabaseDefaultPermissionsProperty | cdktn.IResolvable): any;
export declare function tfCatalogCreateTableDefaultPermissionsPrincipalPropertyToTerraform(struct?: TfCatalog.CreateTableDefaultPermissionsPrincipalProperty | cdktn.IResolvable): any;
export declare function tfCatalogCreateTableDefaultPermissionsPrincipalPropertyToHclTerraform(struct?: TfCatalog.CreateTableDefaultPermissionsPrincipalProperty | cdktn.IResolvable): any;
export declare function tfCatalogCreateTableDefaultPermissionsPropertyToTerraform(struct?: TfCatalog.CreateTableDefaultPermissionsProperty | cdktn.IResolvable): any;
export declare function tfCatalogCreateTableDefaultPermissionsPropertyToHclTerraform(struct?: TfCatalog.CreateTableDefaultPermissionsProperty | cdktn.IResolvable): any;
export declare function tfCatalogFederatedCatalogPropertyToTerraform(struct?: TfCatalog.FederatedCatalogProperty | cdktn.IResolvable): any;
export declare function tfCatalogFederatedCatalogPropertyToHclTerraform(struct?: TfCatalog.FederatedCatalogProperty | cdktn.IResolvable): any;
export declare function tfCatalogTargetRedshiftCatalogPropertyToTerraform(struct?: TfCatalog.TargetRedshiftCatalogProperty | cdktn.IResolvable): any;
export declare function tfCatalogTargetRedshiftCatalogPropertyToHclTerraform(struct?: TfCatalog.TargetRedshiftCatalogProperty | cdktn.IResolvable): any;
export declare function tfCatalogTimeoutsPropertyToTerraform(struct?: TfCatalog.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfCatalogTimeoutsPropertyToHclTerraform(struct?: TfCatalog.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfCatalog {
    interface DataLakeAccessPropertiesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog#catalog_type TfCatalog#catalog_type}
        */
        readonly catalogType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog#data_lake_access TfCatalog#data_lake_access}
        */
        readonly dataLakeAccess?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog#data_transfer_role TfCatalog#data_transfer_role}
        */
        readonly dataTransferRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog#kms_key TfCatalog#kms_key}
        */
        readonly kmsKey?: string;
    }
    class DataLakeAccessPropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataLakeAccessPropertiesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DataLakeAccessPropertiesProperty | cdktn.IResolvable | undefined);
        private _catalogType?;
        get catalogType(): string;
        set catalogType(value: string);
        resetCatalogType(): void;
        get catalogTypeInput(): string | undefined;
        private _dataLakeAccess?;
        get dataLakeAccess(): boolean | cdktn.IResolvable;
        set dataLakeAccess(value: boolean | cdktn.IResolvable);
        resetDataLakeAccess(): void;
        get dataLakeAccessInput(): boolean | cdktn.IResolvable | undefined;
        private _dataTransferRole?;
        get dataTransferRole(): string;
        set dataTransferRole(value: string);
        resetDataTransferRole(): void;
        get dataTransferRoleInput(): string | undefined;
        private _kmsKey?;
        get kmsKey(): string;
        set kmsKey(value: string);
        resetKmsKey(): void;
        get kmsKeyInput(): string | undefined;
        get managedWorkgroupName(): string;
        get managedWorkgroupStatus(): string;
        get redshiftDatabaseName(): string;
        get statusMessage(): string;
    }
    class DataLakeAccessPropertiesPropertyList extends cdktn.ComplexList {
        internalValue?: DataLakeAccessPropertiesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataLakeAccessPropertiesPropertyOutputReference;
    }
    interface IcebergOptimizationPropertiesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog#compaction TfCatalog#compaction}
        */
        readonly compaction?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog#orphan_file_deletion TfCatalog#orphan_file_deletion}
        */
        readonly orphanFileDeletion?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog#retention TfCatalog#retention}
        */
        readonly retention?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog#role_arn TfCatalog#role_arn}
        */
        readonly roleArn?: string;
    }
    class IcebergOptimizationPropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IcebergOptimizationPropertiesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IcebergOptimizationPropertiesProperty | cdktn.IResolvable | undefined);
        private _compaction?;
        get compaction(): {
            [key: string]: string;
        };
        set compaction(value: {
            [key: string]: string;
        });
        resetCompaction(): void;
        get compactionInput(): {
            [key: string]: string;
        } | undefined;
        private _orphanFileDeletion?;
        get orphanFileDeletion(): {
            [key: string]: string;
        };
        set orphanFileDeletion(value: {
            [key: string]: string;
        });
        resetOrphanFileDeletion(): void;
        get orphanFileDeletionInput(): {
            [key: string]: string;
        } | undefined;
        private _retention?;
        get retention(): {
            [key: string]: string;
        };
        set retention(value: {
            [key: string]: string;
        });
        resetRetention(): void;
        get retentionInput(): {
            [key: string]: string;
        } | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        resetRoleArn(): void;
        get roleArnInput(): string | undefined;
    }
    class IcebergOptimizationPropertiesPropertyList extends cdktn.ComplexList {
        internalValue?: IcebergOptimizationPropertiesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IcebergOptimizationPropertiesPropertyOutputReference;
    }
    interface CatalogPropertiesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog#custom_properties TfCatalog#custom_properties}
        */
        readonly customProperties?: {
            [key: string]: string;
        };
        /**
        * data_lake_access_properties block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog#data_lake_access_properties TfCatalog#data_lake_access_properties}
        */
        readonly dataLakeAccessProperties?: DataLakeAccessPropertiesProperty[] | cdktn.IResolvable;
        /**
        * iceberg_optimization_properties block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog#iceberg_optimization_properties TfCatalog#iceberg_optimization_properties}
        */
        readonly icebergOptimizationProperties?: IcebergOptimizationPropertiesProperty[] | cdktn.IResolvable;
    }
    class CatalogPropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CatalogPropertiesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CatalogPropertiesProperty | cdktn.IResolvable | undefined);
        private _customProperties?;
        get customProperties(): {
            [key: string]: string;
        };
        set customProperties(value: {
            [key: string]: string;
        });
        resetCustomProperties(): void;
        get customPropertiesInput(): {
            [key: string]: string;
        } | undefined;
        private _dataLakeAccessProperties;
        get dataLakeAccessProperties(): DataLakeAccessPropertiesPropertyList;
        putDataLakeAccessProperties(value: DataLakeAccessPropertiesProperty[] | cdktn.IResolvable): void;
        resetDataLakeAccessProperties(): void;
        get dataLakeAccessPropertiesInput(): cdktn.IResolvable | DataLakeAccessPropertiesProperty[] | undefined;
        private _icebergOptimizationProperties;
        get icebergOptimizationProperties(): IcebergOptimizationPropertiesPropertyList;
        putIcebergOptimizationProperties(value: IcebergOptimizationPropertiesProperty[] | cdktn.IResolvable): void;
        resetIcebergOptimizationProperties(): void;
        get icebergOptimizationPropertiesInput(): cdktn.IResolvable | IcebergOptimizationPropertiesProperty[] | undefined;
    }
    class CatalogPropertiesPropertyList extends cdktn.ComplexList {
        internalValue?: CatalogPropertiesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CatalogPropertiesPropertyOutputReference;
    }
    interface CreateDatabaseDefaultPermissionsPrincipalProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog#data_lake_principal_identifier TfCatalog#data_lake_principal_identifier}
        */
        readonly dataLakePrincipalIdentifier?: string;
    }
    class CreateDatabaseDefaultPermissionsPrincipalPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CreateDatabaseDefaultPermissionsPrincipalProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CreateDatabaseDefaultPermissionsPrincipalProperty | cdktn.IResolvable | undefined);
        private _dataLakePrincipalIdentifier?;
        get dataLakePrincipalIdentifier(): string;
        set dataLakePrincipalIdentifier(value: string);
        resetDataLakePrincipalIdentifier(): void;
        get dataLakePrincipalIdentifierInput(): string | undefined;
    }
    class CreateDatabaseDefaultPermissionsPrincipalPropertyList extends cdktn.ComplexList {
        internalValue?: CreateDatabaseDefaultPermissionsPrincipalProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CreateDatabaseDefaultPermissionsPrincipalPropertyOutputReference;
    }
    interface CreateDatabaseDefaultPermissionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog#permissions TfCatalog#permissions}
        */
        readonly permissions?: string[];
        /**
        * principal block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog#principal TfCatalog#principal}
        */
        readonly principal?: CreateDatabaseDefaultPermissionsPrincipalProperty[] | cdktn.IResolvable;
    }
    class CreateDatabaseDefaultPermissionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CreateDatabaseDefaultPermissionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CreateDatabaseDefaultPermissionsProperty | cdktn.IResolvable | undefined);
        private _permissions?;
        get permissions(): string[];
        set permissions(value: string[]);
        resetPermissions(): void;
        get permissionsInput(): string[] | undefined;
        private _principal;
        get principal(): CreateDatabaseDefaultPermissionsPrincipalPropertyList;
        putPrincipal(value: CreateDatabaseDefaultPermissionsPrincipalProperty[] | cdktn.IResolvable): void;
        resetPrincipal(): void;
        get principalInput(): cdktn.IResolvable | CreateDatabaseDefaultPermissionsPrincipalProperty[] | undefined;
    }
    class CreateDatabaseDefaultPermissionsPropertyList extends cdktn.ComplexList {
        internalValue?: CreateDatabaseDefaultPermissionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CreateDatabaseDefaultPermissionsPropertyOutputReference;
    }
    interface CreateTableDefaultPermissionsPrincipalProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog#data_lake_principal_identifier TfCatalog#data_lake_principal_identifier}
        */
        readonly dataLakePrincipalIdentifier?: string;
    }
    class CreateTableDefaultPermissionsPrincipalPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CreateTableDefaultPermissionsPrincipalProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CreateTableDefaultPermissionsPrincipalProperty | cdktn.IResolvable | undefined);
        private _dataLakePrincipalIdentifier?;
        get dataLakePrincipalIdentifier(): string;
        set dataLakePrincipalIdentifier(value: string);
        resetDataLakePrincipalIdentifier(): void;
        get dataLakePrincipalIdentifierInput(): string | undefined;
    }
    class CreateTableDefaultPermissionsPrincipalPropertyList extends cdktn.ComplexList {
        internalValue?: CreateTableDefaultPermissionsPrincipalProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CreateTableDefaultPermissionsPrincipalPropertyOutputReference;
    }
    interface CreateTableDefaultPermissionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog#permissions TfCatalog#permissions}
        */
        readonly permissions?: string[];
        /**
        * principal block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog#principal TfCatalog#principal}
        */
        readonly principal?: CreateTableDefaultPermissionsPrincipalProperty[] | cdktn.IResolvable;
    }
    class CreateTableDefaultPermissionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CreateTableDefaultPermissionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CreateTableDefaultPermissionsProperty | cdktn.IResolvable | undefined);
        private _permissions?;
        get permissions(): string[];
        set permissions(value: string[]);
        resetPermissions(): void;
        get permissionsInput(): string[] | undefined;
        private _principal;
        get principal(): CreateTableDefaultPermissionsPrincipalPropertyList;
        putPrincipal(value: CreateTableDefaultPermissionsPrincipalProperty[] | cdktn.IResolvable): void;
        resetPrincipal(): void;
        get principalInput(): cdktn.IResolvable | CreateTableDefaultPermissionsPrincipalProperty[] | undefined;
    }
    class CreateTableDefaultPermissionsPropertyList extends cdktn.ComplexList {
        internalValue?: CreateTableDefaultPermissionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CreateTableDefaultPermissionsPropertyOutputReference;
    }
    interface FederatedCatalogProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog#connection_name TfCatalog#connection_name}
        */
        readonly connectionName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog#connection_type TfCatalog#connection_type}
        */
        readonly connectionType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog#identifier TfCatalog#identifier}
        */
        readonly identifier?: string;
    }
    class FederatedCatalogPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FederatedCatalogProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FederatedCatalogProperty | cdktn.IResolvable | undefined);
        private _connectionName?;
        get connectionName(): string;
        set connectionName(value: string);
        resetConnectionName(): void;
        get connectionNameInput(): string | undefined;
        private _connectionType?;
        get connectionType(): string;
        set connectionType(value: string);
        resetConnectionType(): void;
        get connectionTypeInput(): string | undefined;
        private _identifier?;
        get identifier(): string;
        set identifier(value: string);
        resetIdentifier(): void;
        get identifierInput(): string | undefined;
    }
    class FederatedCatalogPropertyList extends cdktn.ComplexList {
        internalValue?: FederatedCatalogProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FederatedCatalogPropertyOutputReference;
    }
    interface TargetRedshiftCatalogProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog#catalog_arn TfCatalog#catalog_arn}
        */
        readonly catalogArn: string;
    }
    class TargetRedshiftCatalogPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetRedshiftCatalogProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetRedshiftCatalogProperty | cdktn.IResolvable | undefined);
        private _catalogArn?;
        get catalogArn(): string;
        set catalogArn(value: string);
        get catalogArnInput(): string | undefined;
    }
    class TargetRedshiftCatalogPropertyList extends cdktn.ComplexList {
        internalValue?: TargetRedshiftCatalogProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetRedshiftCatalogPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog#create TfCatalog#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog#delete TfCatalog#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog#update TfCatalog#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
