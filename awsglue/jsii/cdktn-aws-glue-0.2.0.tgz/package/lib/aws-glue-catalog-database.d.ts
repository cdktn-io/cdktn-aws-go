import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfCatalogDatabaseConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_database#catalog_id TfCatalogDatabase#catalog_id}
    */
    readonly catalogId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_database#description TfCatalogDatabase#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_database#id TfCatalogDatabase#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_database#location_uri TfCatalogDatabase#location_uri}
    */
    readonly locationUri?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_database#name TfCatalogDatabase#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_database#parameters TfCatalogDatabase#parameters}
    */
    readonly parameters?: {
        [key: string]: string;
    };
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_database#region TfCatalogDatabase#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_database#tags TfCatalogDatabase#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_database#tags_all TfCatalogDatabase#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * create_table_default_permission block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_database#create_table_default_permission TfCatalogDatabase#create_table_default_permission}
    */
    readonly createTableDefaultPermission?: TfCatalogDatabase.CreateTableDefaultPermissionProperty[] | cdktn.IResolvable;
    /**
    * federated_database block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_database#federated_database TfCatalogDatabase#federated_database}
    */
    readonly federatedDatabase?: TfCatalogDatabase.FederatedDatabaseProperty;
    /**
    * target_database block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_database#target_database TfCatalogDatabase#target_database}
    */
    readonly targetDatabase?: TfCatalogDatabase.TargetDatabaseProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_database aws_glue_catalog_database}
*/
export declare class TfCatalogDatabase extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_glue_catalog_database";
    /**
    * Generates CDKTN code for importing a TfCatalogDatabase resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfCatalogDatabase to import
    * @param importFromId The id of the existing TfCatalogDatabase that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_database#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfCatalogDatabase to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_database aws_glue_catalog_database} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfCatalogDatabaseConfig
    */
    constructor(scope: Construct, id: string, config: TfCatalogDatabaseConfig);
    get arn(): string;
    private _catalogId?;
    get catalogId(): string;
    set catalogId(value: string);
    resetCatalogId(): void;
    get catalogIdInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _locationUri?;
    get locationUri(): string;
    set locationUri(value: string);
    resetLocationUri(): void;
    get locationUriInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parameters?;
    get parameters(): {
        [key: string]: string;
    };
    set parameters(value: {
        [key: string]: string;
    });
    resetParameters(): void;
    get parametersInput(): {
        [key: string]: string;
    } | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _createTableDefaultPermission;
    get createTableDefaultPermission(): TfCatalogDatabase.CreateTableDefaultPermissionPropertyList;
    putCreateTableDefaultPermission(value: TfCatalogDatabase.CreateTableDefaultPermissionProperty[] | cdktn.IResolvable): void;
    resetCreateTableDefaultPermission(): void;
    get createTableDefaultPermissionInput(): cdktn.IResolvable | TfCatalogDatabase.CreateTableDefaultPermissionProperty[] | undefined;
    private _federatedDatabase;
    get federatedDatabase(): TfCatalogDatabase.FederatedDatabasePropertyOutputReference;
    putFederatedDatabase(value: TfCatalogDatabase.FederatedDatabaseProperty): void;
    resetFederatedDatabase(): void;
    get federatedDatabaseInput(): TfCatalogDatabase.FederatedDatabaseProperty | undefined;
    private _targetDatabase;
    get targetDatabase(): TfCatalogDatabase.TargetDatabasePropertyOutputReference;
    putTargetDatabase(value: TfCatalogDatabase.TargetDatabaseProperty): void;
    resetTargetDatabase(): void;
    get targetDatabaseInput(): TfCatalogDatabase.TargetDatabaseProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfCatalogDatabasePrincipalPropertyToTerraform(struct?: TfCatalogDatabase.PrincipalPropertyOutputReference | TfCatalogDatabase.PrincipalProperty): any;
export declare function tfCatalogDatabasePrincipalPropertyToHclTerraform(struct?: TfCatalogDatabase.PrincipalPropertyOutputReference | TfCatalogDatabase.PrincipalProperty): any;
export declare function tfCatalogDatabaseCreateTableDefaultPermissionPropertyToTerraform(struct?: TfCatalogDatabase.CreateTableDefaultPermissionProperty | cdktn.IResolvable): any;
export declare function tfCatalogDatabaseCreateTableDefaultPermissionPropertyToHclTerraform(struct?: TfCatalogDatabase.CreateTableDefaultPermissionProperty | cdktn.IResolvable): any;
export declare function tfCatalogDatabaseFederatedDatabasePropertyToTerraform(struct?: TfCatalogDatabase.FederatedDatabasePropertyOutputReference | TfCatalogDatabase.FederatedDatabaseProperty): any;
export declare function tfCatalogDatabaseFederatedDatabasePropertyToHclTerraform(struct?: TfCatalogDatabase.FederatedDatabasePropertyOutputReference | TfCatalogDatabase.FederatedDatabaseProperty): any;
export declare function tfCatalogDatabaseTargetDatabasePropertyToTerraform(struct?: TfCatalogDatabase.TargetDatabasePropertyOutputReference | TfCatalogDatabase.TargetDatabaseProperty): any;
export declare function tfCatalogDatabaseTargetDatabasePropertyToHclTerraform(struct?: TfCatalogDatabase.TargetDatabasePropertyOutputReference | TfCatalogDatabase.TargetDatabaseProperty): any;
export declare namespace TfCatalogDatabase {
    interface PrincipalProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_database#data_lake_principal_identifier TfCatalogDatabase#data_lake_principal_identifier}
        */
        readonly dataLakePrincipalIdentifier?: string;
    }
    class PrincipalPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PrincipalProperty | undefined;
        set internalValue(value: PrincipalProperty | undefined);
        private _dataLakePrincipalIdentifier?;
        get dataLakePrincipalIdentifier(): string;
        set dataLakePrincipalIdentifier(value: string);
        resetDataLakePrincipalIdentifier(): void;
        get dataLakePrincipalIdentifierInput(): string | undefined;
    }
    interface CreateTableDefaultPermissionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_database#permissions TfCatalogDatabase#permissions}
        */
        readonly permissions?: string[];
        /**
        * principal block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_database#principal TfCatalogDatabase#principal}
        */
        readonly principal?: PrincipalProperty;
    }
    class CreateTableDefaultPermissionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CreateTableDefaultPermissionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CreateTableDefaultPermissionProperty | cdktn.IResolvable | undefined);
        private _permissions?;
        get permissions(): string[];
        set permissions(value: string[]);
        resetPermissions(): void;
        get permissionsInput(): string[] | undefined;
        private _principal;
        get principal(): PrincipalPropertyOutputReference;
        putPrincipal(value: PrincipalProperty): void;
        resetPrincipal(): void;
        get principalInput(): PrincipalProperty | undefined;
    }
    class CreateTableDefaultPermissionPropertyList extends cdktn.ComplexList {
        internalValue?: CreateTableDefaultPermissionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CreateTableDefaultPermissionPropertyOutputReference;
    }
    interface FederatedDatabaseProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_database#connection_name TfCatalogDatabase#connection_name}
        */
        readonly connectionName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_database#identifier TfCatalogDatabase#identifier}
        */
        readonly identifier?: string;
    }
    class FederatedDatabasePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FederatedDatabaseProperty | undefined;
        set internalValue(value: FederatedDatabaseProperty | undefined);
        private _connectionName?;
        get connectionName(): string;
        set connectionName(value: string);
        resetConnectionName(): void;
        get connectionNameInput(): string | undefined;
        private _identifier?;
        get identifier(): string;
        set identifier(value: string);
        resetIdentifier(): void;
        get identifierInput(): string | undefined;
    }
    interface TargetDatabaseProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_database#catalog_id TfCatalogDatabase#catalog_id}
        */
        readonly catalogId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_database#database_name TfCatalogDatabase#database_name}
        */
        readonly databaseName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_database#region TfCatalogDatabase#region}
        */
        readonly region?: string;
    }
    class TargetDatabasePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TargetDatabaseProperty | undefined;
        set internalValue(value: TargetDatabaseProperty | undefined);
        private _catalogId?;
        get catalogId(): string;
        set catalogId(value: string);
        get catalogIdInput(): string | undefined;
        private _databaseName?;
        get databaseName(): string;
        set databaseName(value: string);
        get databaseNameInput(): string | undefined;
        private _region?;
        get region(): string;
        set region(value: string);
        resetRegion(): void;
        get regionInput(): string | undefined;
    }
}
